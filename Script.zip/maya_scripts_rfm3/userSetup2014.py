import site
import os.path
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OpenMaya
import sys
import re

global OSTYPE
OSTYPE = sys.platform
batchMode = cmds.about(b=True)
if not batchMode:
	if OSTYPE == "win32":
		OSTYPE="//Server-3d/Project"
		site.addsitedir(OSTYPE+'/lib/soft/Python2014/Lib/site-packages')

		import sys, os
		sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
		sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')

		import re
		#from PyQt4 import QtCore, QtGui
		from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
		import socket
		import MySQLdb as mb
		import sip
		import maya.cmds as cmds
		import maya.OpenMayaUI as apiUI

		import melnik_setup
		import ClientServer
		import chekProject		
	else:
		OSTYPE="/Server-3d/Project"
        site.addsitedir(OSTYPE+'/lib/soft/Python2013_lin')

        import sys, os
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')

        import re
        #from PyQt4 import QtCore, QtGui
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI

        import melnik_setup
        import ClientServer
        import chekProject	

def resolfReferencePath(retCode, fileObject, clientData):
    rel = fileObject.expandedFullName()                         
    if sys.platform == "win32":
        if rel.capitalize()[:18] == "/Server-3d/Project":
            rel = "//Server-3d/Project" + rel[18:]
            print "Callback was changed %s" % rel
        if rel.capitalize()[:2] == "p:":
            rel = "//Server-3d/Project" + rel[2:]
            print "Callback was changed %s" % rel
    else:
        if rel.capitalize()[:19] == "//server-3d/project":
            rel = "/Server-3d/Project" + rel[19:]
            print "Callback was changed %s" % rel
        if rel.capitalize()[:2] == "p:":
            rel = "/Server-3d/Project" + rel[2:]
            print "Callback was changed %s" % rel

    fileObject.setRawFullName(rel)
    OpenMaya.MScriptUtil.setBool(retCode, True)
     
id = OpenMaya.MSceneMessage.addCheckFileCallback(OpenMaya.MSceneMessage.kBeforeReferenceCheck, resolfReferencePath)


def resolfImageFilePath(clientData):
    OSTYPE = sys.platform
    if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
    else:
        OSTYPE="/Server-3d/Project"
    #print("\n\nresolf path OSTYPE: "+OSTYPE+"\n\n")

    filePaths = cmds.ls(type="file",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".fileTextureName")
        if OSTYPE == "//Server-3d/Project":
            if path.capitalize()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".fileTextureName","//Server-3d/Project" + path[18:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[18:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".fileTextureName","//Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.capitalize()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".fileTextureName","/Server-3d/Project" + path[19:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".fileTextureName","/Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[2:])

    filePaths = cmds.ls(type="RMSEnvLight",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".rman__EnvMap")
        if OSTYPE == "//Server-3d/Project":
            if path.capitalize()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".rman__EnvMap","//server-3d/Project" + path[18:],type="string")
                print "File was changed %s" % ("//server-3d/Project" + path[18:])
        elif OSTYPE == "/Server-3d/Project":
            if path.capitalize()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[19:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[19:])

    filePaths = cmds.ls(type="RenderManLight",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".shadername")
        if OSTYPE == "//Server-3d/Project":
            if path.capitalize()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".shadername","//Server-3d/Project" + path[18:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[18:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".shadername","//Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.capitalize()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".shadername","/Server-3d/Project" + path[19:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".shadername","/Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[2:])

    filePaths = cmds.ls(type="RenderManEnvLightShape",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".rman__EnvMap")
        if OSTYPE == "//Server-3d/Project":
            if path.capitalize()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".rman__EnvMap","//Server-3d/Project" + path[18:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[18:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".rman__EnvMap","//Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.capitalize()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[19:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.capitalize()[:2] == "p:":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[2:],type="string")
                print "File was changed %s" % ("/Server-3d/Project" + path[2:])
     
id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterOpen, resolfImageFilePath)
id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterImport, resolfImageFilePath)
id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterReference, resolfImageFilePath)
