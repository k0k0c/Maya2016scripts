#SaveLoadRefState
#import SaveLoadRefState;reload(SaveLoadRefState);SaveLoadRefState.createDialogWindow()

import maya.cmds as cmds
import ast

def createDialogWindow():
	if cmds.window("SaveLoadReferences_window", exists=True):
		cmds.deleteUI("SaveLoadReferences_window", window=True)
	cmds.window("SaveLoadReferences_window", title='Save/Load references statement', sizeable=False, height=500,width=500)
	cmds.frameLayout("SaveLoadReferences_layout",labelVisible=0, borderStyle="etchedOut",collapsable=0,parent='SaveLoadReferences_window')
	cmds.button('SaveLoadReferences_SaveButton', label='Save loaded references', backgroundColor=[0.1,0.3,0.1], h=75, w=300, command='SaveLoadRefState.saveLoadStatesReferences("save")')
	cmds.button('SaveLoadReferences_LoadButton', label='Load saves refences', backgroundColor=[0.1,0.3,0.1], h=75, w=300, command='SaveLoadRefState.saveLoadStatesReferences("load")')
	cmds.button('SaveLoadReferences_CloseButton', label='Close', h=75, w=300, backgroundColor=[0.3,0.15,0.15], command='cmds.deleteUI("SaveLoadReferences_window", window=True)')
	cmds.rowColumnLayout("SaveReferenceState_ColumnSave", numberOfRows=1, columnSpacing=(1,60), parent='SaveLoadReferences_layout')
	cmds.checkBoxGrp('SaveReferenceState_checkBoxSave', label='Save scene: ', value1=1, parent='SaveReferenceState_ColumnSave')
	cmds.checkBoxGrp('SaveReferenceState_checkBoxLoad', label='Save enable:', value1=0, parent='SaveReferenceState_ColumnSave', changeCommand='SaveLoadRefState.refenceSaveStatement_checkButton("SaveReferenceState_checkBoxLoad")')
	cmds.showWindow('SaveLoadReferences_window')
	refenceSaveStatement_checkButton(None)
	refenceSaveStatement_checkButton("SaveReferenceState_checkBoxLoad")

def saveLoadStatesReferences(mode):
	if mode=='save': 
		if cmds.attributeQuery('referenceList', node='|persp', exists=True) is False:
			cmds.addAttr('|persp', longName='referenceList', hidden=True, dataType='string')
		if cmds.attributeQuery('referenceListBackUp', node='|persp', exists=True) is False:
			cmds.addAttr('|persp', longName='referenceListBackUp', hidden=True, dataType='string')	
		if (cmds.getAttr('|persp.referenceList')!=None):
			cmds.setAttr('|persp.referenceListBackUp', str(cmds.getAttr('|persp.referenceList')), type='string')	
		reference_list=[]
		reference_name=[]
		node_list=cmds.ls(readOnly=True, geometry=True, long=True)
		refenceSaveStatement_checkButton(None)
		cmds.checkBoxGrp('SaveReferenceState_checkBoxLoad', edit=True, value1=False)
		refenceSaveStatement_checkButton('SaveReferenceState_checkBoxLoad')
		for i in range(0, len(node_list)):
			ref_name_TEMP=cmds.referenceQuery(node_list[i], referenceNode=True)
			if ref_name_TEMP not in reference_name:
				reference_name.append(ref_name_TEMP)
		for i in range(0, len(reference_name)):
			reference_path=referenceOpenHiearchyToRef(reference_name[i])
			reference_list.append(reference_path)
		cmds.setAttr('|persp.referenceList', reference_list, type='string')
		if cmds.checkBoxGrp('SaveReferenceState_checkBoxSave', query=True, value1=True) is True:
			cmds.file(force=True, save=True)
	if mode=='load': 
		refences_nodes=cmds.getAttr('|persp.referenceList')
		refences_nodes=ast.literal_eval(refences_nodes)
		for i in range(0, len(refences_nodes)):
			for x in xrange((len(refences_nodes[i])-1), -1, -1):
				if cmds.referenceQuery(refences_nodes[i][x], isLoaded=True)is False:
					ref_filename=cmds.referenceQuery(refences_nodes[i][x], filename=True)
					cmds.file(ref_filename, loadNoReferences=True, loadReference=True)
				
def referenceOpenHiearchyToRef(reference_target):
	reference_parent=cmds.referenceQuery(reference_target, referenceNode=True, parent=True)
	reference_temp_array=[reference_target]
	if reference_parent:
		reference_temp_array.append(reference_parent)				
		while True:
			reference_temp=cmds.referenceQuery(reference_parent, referenceNode=True, parent=True)
			reference_parent=reference_temp
			if reference_parent:
				reference_temp_array.append(reference_temp)
			else:
				break
	if len(reference_temp_array)>0:	
		return reference_temp_array
		
def refenceSaveStatement_checkButton(name_button):
	if name_button==None:
		if cmds.attributeQuery('referenceList', node='|persp', exists=True):
			cmds.button("SaveLoadReferences_LoadButton", edit=True, backgroundColor=[0.1,0.3,0.1], enable=True)
		else:
			cmds.button("SaveLoadReferences_LoadButton", edit=True, backgroundColor=[0.3,0.2,0.2], enable=False)
	else:		
		state_var=cmds.checkBoxGrp(name_button, query=True, value1=True)
		if state_var is True:
			cmds.button("SaveLoadReferences_SaveButton", edit=True, backgroundColor=[0.1,0.3,0.1], enable=True)
			cmds.checkBoxGrp("SaveReferenceState_checkBoxSave", edit=True, enable=True)
		elif state_var is False:
			cmds.button("SaveLoadReferences_SaveButton", edit=True, backgroundColor=[0.3,0.2,0.2], enable=False)
			cmds.checkBoxGrp("SaveReferenceState_checkBoxSave", edit=True, enable=False)		