To use this script, all you need to do is to:

1) Load the .mel file to your script editor.
2) Select all.
3) Click and drag to the shelf to make a shelf button.
4) Done. You don't need to put in your scripts folder.





With this script you can do;

1) Crease edges or vertices of a polygon object simply by writing down the value.(Or Ctrl + clickDrag)

2) Finding out what values selected edges/vertices have been creased with.
(The value field will show the value when you select components. If each selection is not the same, it will turn red.
And it will show the average of the values that components possess. Besides you can see the min and max values in
your selection at the below two fields.)

3) Selecting the components between specified crease values.
( you can select all edges with crease by entering number between 0 and 50 for example)

4) You can reset your crease values of selected edges or vertices or all together.
(Note that construction history will remain but the crease values will be 0)


Written By O�uzhan Kukul - Character Animator