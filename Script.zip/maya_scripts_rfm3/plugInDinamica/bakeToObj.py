import maya.cmds as cmds
import maya.mel as mel
import os.path
import maya.OpenMaya as OpenMaya

ewin = "bakeObjWin"
iwin = "importObjWin"
pluginPath=""
exportdir=""

def findPluginPath():
    plugin_paths = mel.eval("getenv MAYA_PLUG_IN_PATH").split(";")
    plugin_name="objExport.bundle"
    for path in plugin_paths:
        if os.path.exists(os.path.join(path,plugin_name)):
            return os.path.join(path,plugin_name)
    return os.path.join(plugin_paths[1],plugin_name)
    
def loadPlugin():
    global pluginInitStatus, pluginPath
    print "Loading plugin " + str(pluginPath)
    pluginInitStatus = cmds.pluginInfo(pluginPath, q=1, l=1)
    if pluginInitStatus==False:
        cmds.loadPlugin(pluginPath)
    print "Plugin " + pluginPath + " Loaded."

def unloadPlugin():
    global pluginInitStatus, pluginPath
    
    if pluginInitStatus == False:
        cmds.unloadPlugin(pluginPath)                   
        
    print "Plugin " + pluginPath + " Unloaded."        

def selObjs():
    global bakeObjs, objsField
    bakeObjs = cmds.ls(sl=1)
    txt = ""
    for o in bakeObjs:
        txt +=o + ", "
    print txt[:30] + ".."    
    cmds.textFieldButtonGrp(objsField, e=1, text=txt[:30] + "..")
    
def browseFolderCallback(fileName, fileType):
    global exportDir, dirTxt
    while not os.path.isdir(fileName):
        cmds.confirmDialog(message="Please select a folder")
        browseFolder()
    exportDir = fileName
    cmds.textFieldButtonGrp(dirTxt, e=1, text = exportDir)
    return
    
def browseFolder():
    mayaFolder = cmds.workspace(q=1, dir=1)
    cmds.fileBrowserDialog(mode=4, fileCommand=browseFolderCallback, actionName="Pick Folder")

def makeBakeDirs():
    global bakeObjs, exportDir
    
    for obj in bakeObjs:
        if not os.path.exists(os.path.join(exportDir, obj)):
            os.mkdir(os.path.join(exportDir,obj))
    
def bakeObjs(self):
    global dirTxt, framesTxt, bakeObjs, exportDir
    
    initTime = cmds.currentTime(q=1)
    startFrame = cmds.intFieldGrp(framesTxt, q=1, v1=1)
    endFrame = cmds.intFieldGrp(framesTxt, q=1, v2=1)
    
    makeBakeDirs()
    
    for obj in bakeObjs:
        cmds.select(obj, r=1)
        for time in range(startFrame, endFrame+1):
            cmds.currentTime(time)     
            fn = os.path.join(os.path.join(exportDir,obj), obj) + "_" + str(time)
            print fn
            cmds.file(fn, op="groups=0;ptgroups=0;materials=0;smoothing=1;normals=1", typ="OBJexport", pr=1, es=1)
    
    cmds.currentTime(initTime)
    OpenMaya.MGlobal.displayInfo("Objects exported correctly")
    
def displayExportUI():
    global ewin, dirTxt, objsField, framesTxt
    
    ff = cmds.playbackOptions(q=1, min=1)
    lf = cmds.playbackOptions(q=1, max=1)
    #Delete main Gui if exists
    if cmds.window(ewin, exists=1):
        cmds.deleteUI(ewin, window=1)    
    
    ewin = cmds.window(title="Export Obj sequence")
    
    cmds.columnLayout(adj=1, rs=10)
    
    cmds.frameLayout( label='Objects and dir', labelAlign='top', borderStyle='in' )
    cmds.columnLayout(adj=1)
    objsField = cmds.textFieldButtonGrp(label='Objects', text='', buttonLabel='<<<', ed=0, adj=1, cw3=[50,180,50], bc=selObjs)
    dirTxt = cmds.textFieldButtonGrp(label='Export dir', bc=browseFolder, buttonLabel='<<<', ed=0, adj=1, cw3=[50,180,50])
    cmds.setParent('..')
    cmds.setParent('..')
    
    cmds.frameLayout( label='Frames:', labelAlign='top', borderStyle='in' )
    framesTxt = cmds.intFieldGrp(nf=2, label='From, to', value1=ff, value2=lf)
    cmds.setParent('..')
    cmds.button(label="Export", c=bakeObjs)    
    
    cmds.window(ewin, e=1, w=350, h=195, s=0)
    cmds.showWindow(ewin)

def browseImportFolderCallback(fileName, fileType):
    global importDir, idirTxt, importBtn
    if os.path.isdir(fileName):
        importDir = fileName
        cmds.textFieldButtonGrp(idirTxt, e=1, text = importDir)
        cmds.button(importBtn, e=1, en=1)
        folders = getBakeFolders(importDir)    
        for f in folders:
              importObjs.append(f)
        cmds.textScrollList(iObjsList, numberOfRows=len(folders), e=1, allowMultiSelection=True, append=folders,ai=1, ra=1)    
    return

def browseImportFolder():
    global iObjsList, importObjs
    importObjs=list()
    mayaFolder = cmds.workspace(q=1, dir=1)
    cmds.fileBrowserDialog(mode=4, fileCommand=browseImportFolderCallback, actionName="Pick Folder")    

def getBakeFolders(root=""):
     return [f for f in os.listdir(root) if os.path.isdir(os.path.join(root, f))]

def importObjects(self):
    global iObjsList, importObjs
    
    for obj in importObjs:
        objList=list()
        groupName = obj + "_geo_cache"
        if cmds.objExists(groupName) == False:
            cmds.group(em=1, n=groupName)
        objDir = os.path.join(importDir, obj)
        files = [f for f in os.listdir(objDir) if f.endswith(".obj")]
        for f in files:
            fp = os.path.join(objDir, f)
            print fp
            objName = f.split(".")[0]
            iobjs = cmds.file(fp, i=1, type="OBJ", options="mo=1", ra=True, rpr="", rnn=1) 
            for o in iobjs:
                try:
                    cmds.parent(o, groupName)
                    objList.append(o.split("|")[-1])
                except:
                    pass
        createExpression(obj, objList)        
            
def createExpression(obj, objList):
    exp="$frame = `currentTime -q`;\n";
    for o in objList:
        split = o.split("_")
        no = split[-2]
        exp+="if ($frame==" + no + ") " +o +".visibility=1; else " +o +".visibility=0;\n";
    cmds.expression(name=obj + "_driver", string=exp)
            
def displayImportUI():
    global iwin, idirTxt, iObjsList, importBtn
    
    #Delete main Gui if exists
    if cmds.window(iwin, exists=1):
        cmds.deleteUI(iwin, window=1)    
    
    iwin = cmds.window(title="Import Obj sequence")
    
    cmds.columnLayout(adj=1, rs=10)
    
    cmds.frameLayout( label='Objects and dir', labelAlign='top', borderStyle='in' )
    cmds.columnLayout(adj=1)
    idirTxt = cmds.textFieldButtonGrp(label='Import dir', bc=browseImportFolder, buttonLabel='<<<', ed=0, adj=1, cw3=[50,180,50])
    iObjsList = cmds.textScrollList()
    cmds.setParent('..')
    cmds.setParent('..')
    
    importBtn = cmds.button(label="Import", c=importObjects, en=0)    
    
    cmds.window(iwin, e=1, w=350, h=195, s=0)
    cmds.showWindow(iwin)


def init():
    global pluginPath
    
    #pluginPath= findPluginPath()
    pluginPath='C:\\Program Files\\Autodesk\\Maya2012\\bin\plug-ins\\objExport.mll'
    loadPlugin()

#init()
#displayExportUI()