######################################################
## Viewport Render Script v 4.00                    ##
##--------------------------------------------------##
## Script Written by Lucas morgan.                  ##
## Other scripts, information,                      ##
## the most current version of this,                ##
## and my entire portfolio may be viewed at:        ##
## http://www.enviral-design.com/                   ##
##--------------------------------------------------##
## If you would like to use any part of this script ##
## in your own, or for any commercial purposes,     ##
## I would be grateful to know of it, and a small   ##
## credit somewhere would be very much appreciated. ##
## I can be contacted at:                           ##
## lucasm@enviral-design.com                        ##
######################################################

## To run this script, copy all of the text in this window into the python tab of your maya script editor.

## In the event that you need to stop the script, please create a dummy file in the root of your c drive named "breakPy"
##	Create without an extension, and at the next step the script will stop. Be sure to delete afterwards, or the script 
##	will not run until it is gone.

##Update V4
##	-This scrupt now works with versions of maya newer  than 2009

import maya.cmds as cmds
import maya.mel as mel
import os

mayaVersion = int(mel.eval("float $mayaVersion = `getApplicationVersionAsFloat` ;  "))
print mayaVersion

editor = 'renderView'

#deletes old window and preference, if it still exists

if(cmds.window('uiWindow_vpr', q=1, ex=1)):
	cmds.deleteUI('uiWindow_vpr')
if(cmds.windowPref('uiWindow_vpr', q=1, ex=1)):
	cmds.windowPref('uiWindow_vpr', r=1)
	
def dirPath(filePath, fileType):
	cmds.textFieldButtonGrp('Dir', edit=True, text=str(filePath))
	return 1

def renderWindowNameGet():
	renderWindowName = cmds.getPanel(sty = "renderWindowPanel")
	renderWindowName = renderWindowName [0]
	return renderWindowName

renderWindowNameGet()
rvn = renderWindowNameGet()
print rvn

def renderStart(self):
	filePathStr = cmds.textFieldButtonGrp('Dir', query = True, text = True)
	fileNameStr = cmds.textFieldGrp('fileName', query = True, text = True)
	startFrame = int(cmds.textFieldGrp('sf', query = True, text = True))
	endFrame = int(cmds.textFieldGrp('ef', query = True, text = True))
	frameCounter = endFrame - startFrame
	frameNumber = int(cmds.textFieldGrp('fn_s', query = True, text = True))
	semiFullPath = filePathStr + "/" + fileNameStr + "_"
	semiFullPath_two = semiFullPath.replace('/', '//')
	startFrame_melStr = 'mel.eval("currentTime ' + str(startFrame) + ';")'
	exec(startFrame_melStr)

	while(frameCounter >= 0):
		optionOne = 'renderWindowSaveImageCallback "renderView" "' + semiFullPath_two + '000' + str(frameNumber) + '" "image";'
		optionTwo = 'renderWindowSaveImageCallback "renderView" "' + semiFullPath_two + '00' + str(frameNumber) + '" "image";'
		optionThree = 'renderWindowSaveImageCallback "renderView" "' + semiFullPath_two + '0' + str(frameNumber) + '" "image";'
		optionFour = 'renderWindowSaveImageCallback "renderView" "' + semiFullPath_two + str(frameNumber) + '" "image";'
		
		if os.path.exists("c:/breakPy"):
			break
		mel.eval("renderWindowRenderRegion renderView;")
		if(frameNumber <=9):
			if(mayaVersion<=2009):
				mel.eval(optionOne)
			else:
				cmds.renderWindowEditor(editor, e=True, writeImage=(semiFullPath_two + '000' + str(frameNumber))) 
		elif(frameNumber <=99):
			if(mayaVersion<=2009):
				mel.eval(optionTwo)
			else:
				cmds.renderWindowEditor(editor, e=True, writeImage=(semiFullPath_two + '00' + str(frameNumber))) 
		elif(frameNumber <=999):
			if(mayaVersion<=2009):
				mel.eval(optionThree)
			else:
				cmds.renderWindowEditor(editor, e=True, writeImage=(semiFullPath_two + '0' + str(frameNumber))) 
		else:
			if(mayaVersion<=2009):
				mel.eval(optionFour)
			else:
				cmds.renderWindowEditor(editor, e=True, writeImage=(semiFullPath_two + str(frameNumber))) 
		mel.eval("playButtonStepForward;")
		frameCounter = frameCounter - 1
		frameNumber = frameNumber + 1

	print "Finished"

def makeGui():
	# Make a new window
	uiWindow_vpr = cmds.window('uiWindow_vpr', title="Viewport Batch Render", iconName='uiWindow_vpr', widthHeight=(330, 160) )
	#this is the overall wrapper layout, column format, 
	#so that the controls or row layouts under it fall in line.
	cmds.columnLayout('uiColWrapper', w = 375, adjustableColumn=False, parent = 'uiWindow_vpr' )
	cmds.text( label='Settings', align='left', parent = 'uiColWrapper')
	cmds.textFieldGrp('fileName', label='Name Prefix', text='(name goes here)', parent = 'uiWindow_vpr', cw2 = [80, 190])
	cmds.textFieldButtonGrp('Dir', label='Directory Path', cw3 = [80,190,50], text='(browse for directory)', buttonLabel='browse', buttonCommand=browseIt, parent = 'uiColWrapper')
	cmds.rowLayout('startEndLyt', nc = 2, cw2 = [150,50])
	cmds.textFieldGrp('sf', label='Start Frame', text='1', parent = 'startEndLyt', cw2 = [80, 50])
	cmds.textFieldGrp('ef', label='End Frame', text='24', parent = 'startEndLyt', cw2 = [70, 50])
	cmds.textFieldGrp('fn_s', label='Label Start', text='1', parent = 'uiColWrapper', cw2 = [80, 50])
	cmds.button('renderStart', label = "Start Render!", parent = 'uiColWrapper', width = 322, command = renderStart)
	cmds.showWindow( uiWindow_vpr )

def browseIt():
	cmds.fileBrowserDialog( m=4, fc=dirPath, ft='directory', an='Choose Directory')
	return

makeGui()

