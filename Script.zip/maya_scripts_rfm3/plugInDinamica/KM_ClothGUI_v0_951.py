###  KM Cloth GUI v0.951 by JP Felipe                                                              ###
###  Downloaded from www.kollaborativemedium.com                                                   ###
###  Creative Commons License Attribution-ShareAlike                                               ###
###  For brief description of CC License BY-SA go to www.creativecommons.org/licenses/by-sa/3.0    ###



import maya.cmds as cmds
import maya.mel as mel

class myUI() :
    
    def __init__(self) :
        
        
        self.winName = 'KM_Cloth_GUI'
        self.UI()
       

    def UI(self) :
        if cmds.window(self.winName, q=True, exists=True):
            cmds.deleteUI( self.winName, window=True)
        if cmds.windowPref(self.winName, exists=True ): 
            cmds.windowPref(self.winName, remove=True)


        
        cmds.window(self.winName, wh=(500,700), s=False, rtf=True, tlb=True, bgc=[0.2,0.2,0.2])
        
        
        self.form = cmds.formLayout('formParent', numberOfDivisions=700)
        
        lghtBtn = [0.45,0.45,0.45]
        medBtn = [0.25,0.25,0.25]
        darkBtn = [0.15,0.15,0.15]
        self.b1 = cmds.button('Enable All Nuclei', w=150, h=32, bgc=[0.75,0.75,0.75], c=self.eNucleus)
        self.b2 = cmds.button('Disable All Nuclei', w=150, h=32, bgc=[0.75,0.75,0.75], c=self.dNucleus)
        self.b3 = cmds.button('Create Collider', w=150, bgc=darkBtn, c=self.cCollider)
        self.b4 = cmds.button('Create nCloth', w=150, bgc=darkBtn, c=self.cNCloth)
        self.b5 = cmds.button('Remove nCloth', w=150, bgc=darkBtn, c=self.rNCloth)
        self.b6 = cmds.button('Delete History', w=150, bgc=darkBtn, c=self.dClothHist)
        self.wb = cmds.symbolButton(image='posAir.png', c=self.createWCTRL, w=80, h=58, bgc=[0.2,0.2,0.2])
        self.gb = cmds.symbolButton(image='posGravity.png', c=self.createGCTRL, w=80, h=58, bgc=[0.2,0.2,0.2])
        self.TSL = cmds.textScrollList('nclothList', ams=True, sc=self.listSelected, w=310, h=250)
        self.b7 = cmds.button('Refresh List', w=170, bgc=darkBtn, c=self.refreshTSLButton)  
        self.b8 = cmds.button('Enable All Selected', w=170, bgc=darkBtn, c=self.eSelected)
        self.b9 = cmds.button('Disable All Selected', w=170, bgc=darkBtn, c=self.dSelected)
        self.b10 = cmds.button('Paint nCloth Vertex', w=170, h=40, bgc=medBtn)
        cmds.popupMenu()
        cmds.menuItem('Collide Strength', c=self.paintCollideStrength)
        cmds.menuItem('Thickness', c=self.paintThickness)
        cmds.menuItem('Bounce', c=self.paintBounce)
        cmds.menuItem('Friction', c=self.paintFriction)
        cmds.menuItem('Stickiness', c=self.paintStickiness)
        cmds.menuItem('Field Magnitude', c=self.paintFieldMagnitude)
        cmds.menuItem('Mass', c=self.paintMass)
        cmds.menuItem('Stretch', c=self.paintStretch)
        cmds.menuItem('Bend', c=self.paintBend)
        cmds.menuItem('Bend Angle Dropoff', c=self.paintBendAngleDropoff)
        cmds.menuItem('Restitution Angle', c=self.paintRestitutionAngle)
        cmds.menuItem('Damp', c=self.paintDamp)
        cmds.menuItem('Wrinkle', c=self.paintWrinkle)
        cmds.menuItem('Rigidity', c=self.paintRigidity)
        cmds.menuItem('Deform', c=self.paintDeform)
        cmds.menuItem('Input Attract', c=self.paintInputAttract)
        cmds.menuItem('Rest Length Scale', c=self.paintRestLengthScale)
        cmds.menuItem('Lift', c=self.paintLift)
        cmds.menuItem('Drag', c=self.paintDrag)
        cmds.menuItem('Tangential Drag', c=self.paintTangentialDrag)        
        self.t1 = cmds.text('Cache Name:')
        self.tFG1 = cmds.textField('Cache Name', w=310)
        self.b11 = cmds.button('Create Cache', w=100, h=30, bgc=darkBtn, c=self.cCacheName)
        self.b11a = cmds.button('cOpt', l='Opt', w=25, bgc=lghtBtn, c=self.cCacheOpt )
        self.b12 = cmds.button('Merge Cache', w=100,  h=30, bgc=darkBtn, c=self.mCacheName)
        self.b12a = cmds.button('mOpt', l='Opt', w=25, bgc=lghtBtn, c=self.mCacheOpt)
        self.b13 = cmds.button('Trax Editor', w=170, h=40, bgc=lghtBtn, c=self.trax)
        self.b24 = cmds.button('Enable Cache', w=120, bgc=darkBtn, c=self.enCache)
        self.b25 = cmds.button('Disable Cache', w=120, bgc=darkBtn, c=self.disCache)
        self.b26 = cmds.button('Paint Cache Weights', w=170, h=40, bgc=darkBtn)
        self.b21 = cmds.button('Delete Cache', w=170, h=40, bgc=darkBtn, c=self.delCache)
        self.b14 = cmds.button('Attach Cache', w=120, bgc=darkBtn, c=self.attCache)
        self.b15 = cmds.button('Append Cache', w=120, bgc=lghtBtn, c=self.appCache)
        self.b19 = cmds.button('Replace Cache', w=120, bgc=lghtBtn, c=self.repCache)
        self.b20 = cmds.button('Del Cache Frame',  w=120, bgc=lghtBtn, c=self.delCacheFrame)
        self.b16 = cmds.button('Create Constraint', w=150, h=40, bgc=medBtn)
        cmds.popupMenu()
        cmds.menuItem('Transform', c=self.tConstraint)
        cmds.menuItem('Component To Component', c=self.c2cConstraint)
        cmds.menuItem('Point To Surface', c=self.p2sConstraint)
        cmds.menuItem('Slide On Surface', c=self.sosConstraint)
        cmds.menuItem('Weld Adjacent Borders', c=self.wabConstraint)
        cmds.menuItem('Force Field', c=self.ffConstraint)
        cmds.menuItem('Attract to Matching Mesh', c=self.a2mmConstraint)
        cmds.menuItem('Tearable Surface', c=self.tsConstraint)
        cmds.menuItem('Disable Collision', c=self.dcConstraint)
        cmds.menuItem('Exclude Collide Pairs', c=self.ecpConstraint)        
        self.b17 = cmds.button('Constraint Membership', w=150, h=40, bgc=medBtn)
        cmds.popupMenu()
        cmds.menuItem('Select Members', c=self.sMembers)
        cmds.menuItem('Replace Members', c=self.repMembers)
        cmds.menuItem('Add Members', c=self.aMembers)
        cmds.menuItem('Remove Members', c=self.remMembers)        
        self.b18 = cmds.button('Paint Constraint Weights', w=150, h=40, bgc=medBtn)
        cmds.popupMenu()
        cmds.menuItem('Strength', c=self.paintCStrength)
        cmds.menuItem('Glue Strength', c=self.paintCGlueStrength)
        cmds.menuItem('Weight', c=self.paintCWeight) 
        self.b22 = cmds.button('Select Geo Node', w=170, bgc=darkBtn, c=self.convToGeo)        
        self.cB1 = cmds.checkBox('nuclei', value=1, cc=self.nucleiToggle)
        self.cB2 = cmds.checkBox('nRigids', value=1, cc=self.nRigidsToggle)
        self.cB3 = cmds.checkBox('nCloths', value=1, cc=self.nClothsToggle)
        self.cB4 = cmds.checkBox('nConstraints', value=1, cc=self.nConstraintsToggle)
        self.b23 = cmds.symbolButton(image='interactivePlayback.xpm', c=self.interactivePlayback, w=80, h=55, bgc=[0.2,0.2,0.2])   
        self.queryList = ['nRigid', 'nucleus', 'nCloth', 'dynamicConstraint']
              
        cmds.formLayout(self.form, edit=True, attachForm=[
        (self.b1, 'top', 30), (self.b1, 'left', 100), 
        (self.b2, 'top', 30), (self.b2, 'right', 100),
        (self.b3, 'top', 90), (self.b3, 'left', 45), 
        (self.b4, 'top', 125), (self.b4, 'left', 45), 
        (self.TSL, 'top', 195), (self.TSL, 'left', 45), 
        (self.b7, 'top', 185), (self.b7, 'right', 45), 
        (self.b8, 'top', 220), (self.b8, 'right', 45),
        (self.b9, 'top', 255), (self.b9, 'right', 45), 
        (self.b10, 'top', 330), (self.b10, 'right', 45),
        (self.tFG1, 'top', 480), (self.tFG1, 'left', 45), 
        (self.b11, 'top', 510), (self.b11, 'left', 45), 
        (self.b11a, 'top', 510), (self.b11a, 'left', 155),
        (self.b12, 'top', 510), (self.b12, 'left', 220), 
        (self.b12a, 'top', 510), (self.b12a, 'left', 330), 
        (self.b13, 'top', 385), (self.b13, 'right', 45), 
        (self.b18, 'top', 630), (self.b18, 'right', 45), 
        (self.b23, 'top', 557), (self.b23, 'left', 45),
        (self.b16, 'top', 630), (self.b16, 'left', 45), 
        (self.b19, 'right', 45), (self.b19, 'top', 557), 
        (self.b20, 'right', 45), (self.b20, 'top', 587), 
        (self.b21, 'top', 495), (self.b21, 'right', 45), 
        (self.b26, 'top', 440), (self.b26, 'right', 45), 
        (self.t1, 'top', 465), (self.t1, 'left', 150), 
        (self.b22, 'top', 290), (self.b22, 'right', 45)], 
        attachPosition=[
        (self.b5, 'left', 215, 0), (self.b5, 'top', 0, 90), 
        (self.b6, 'left', 215, 0), (self.b6, 'top', 0, 125),
        (self.wb, 'left', 385, 0), (self.wb, 'top', 0, 90), 
        (self.gb, 'left', 485, 0), (self.gb, 'top', 0, 90),
        (self.b17, 'left', 235, 0), (self.b17, 'top', 0, 630), 
        (self.b14, 'top', 0, 557), (self.b14, 'left', 305, 0), 
        (self.b15, 'top', 0, 587), (self.b15, 'left', 305, 0),
        (self.b24, 'top', 0, 557), (self.b24, 'left', 155, 0),
        (self.b25, 'top', 0, 587), (self.b25, 'left', 155, 0), 
        (self.cB1, 'top', 0, 175), (self.cB1, 'left', 50,0),
        (self.cB2, 'top', 0, 175), (self.cB2, 'left', 120, 0), 
        (self.cB3, 'top', 0, 175), (self.cB3, 'left', 190,0), 
        (self.cB4, 'top', 0, 175), (self.cB4, 'left', 260,0)])

        
         
        cmds.showWindow(self.winName)
        
        self.populateTSL()
            
    def nucleiToggle(self, *args):
        if cmds.checkBox(self.cB1, q=True, v=True):
            self.queryList.append('nucleus')
        else :
            self.queryList.remove('nucleus')
        self.refreshTSL()
            
    def nRigidsToggle(self, *args):
        if cmds.checkBox(self.cB2, q=True, v=True):
            self.queryList.append('nRigid')
        else :
            self.queryList.remove('nRigid')
        self.refreshTSL()
            
    def nClothsToggle(self, *args):
        if cmds.checkBox(self.cB3, q=True, v=True):
            self.queryList.append('nCloth')
        else :
            self.queryList.remove('nCloth')
        self.refreshTSL()

    def nConstraintsToggle(self, *args):
        if cmds.checkBox(self.cB4, q=True, v=True):
            self.queryList.append('dynamicConstraint')
        else :
            self.queryList.remove('dynamicConstraint')
        self.refreshTSL()

    def eNucleus(self, *args):
        for eachObj in cmds.ls(type='nucleus') : 
            cmds.setAttr('%s.enable' % eachObj, 1)
            
    def dNucleus(self, *args):
        for eachObj in cmds.ls(type='nucleus') : 
            cmds.setAttr('%s.enable' % eachObj, 0) 

    def cCollider(self, *args):
        mel.eval('makeCollideNCloth');
        self.refreshTSL()
    
    def cNCloth(self, *args):
        mel.eval('nClothCreate');
        self.refreshTSL()

    def rNCloth(self, *args):
        mel.eval('removeNCloth "selected"')
        self.refreshTSL()
        
    def dClothHist(self, *args):
        mel.eval('doDeleteNClothHistory(1, {"pre"})')

    def listSelected(self):
        alist=cmds.textScrollList(self.TSL, q=True, da=True, si=True)
        cmds.select (alist)

    def populateTSL(self):
        cmds.textScrollList(self.TSL, e=True, ra=True)
        self.queryList = list(set(self.queryList))
        for atype in self.queryList:
            alist= cmds.ls(type=atype)
            for item in alist:
                cmds.textScrollList(self.TSL, e=True, a=item)
    
    def refreshTSLButton(self, *args):
        self.refreshTSL()
    
    def refreshTSL(self):
        cmds.textScrollList(self.TSL, e=True, ra=True)
        self.queryList = list(set(self.queryList))
        for atype in self.queryList:
            alist= cmds.ls(type=atype)
            for item in alist:
                cmds.textScrollList(self.TSL, e=True, a=item)

    def eSelected(self, *args):
        for eachObj in cmds.ls(sl=True) : 
            if objExists ('%s.enable' % eachObj) is True:
                cmds.setAttr('%s.enable' % eachObj, 1)
            elif objExists ('%s.isDynamic' % eachObj) is True:
                cmds.setAttr('%s.isDynamic' % eachObj, 1) 
    
    def dSelected(self, *args):
        for eachObj in cmds.ls(sl=True) : 
            if objExists ('%s.enable' % eachObj) is True:
                cmds.setAttr('%s.enable' % eachObj, 0)
            elif objExists ('%s.isDynamic' % eachObj) is True:
                cmds.setAttr('%s.isDynamic' % eachObj, 0) 

    def cCacheName(self, *args):
        cacheNameVal=cmds.textField(self.tFG1, q=True, tx=True)
        mel.eval('doCreateNclothCache 4 { "2", "1", "10", "OneFilePerFrame", "1", "","0","%s.xml","0", "add", "0", "1", "1","0","1" } ' % cacheNameVal)
    
    def cCacheOpt(self, *args):
        mel.eval('nClothCacheOpt')

    def mCacheName(self, *args):
        cacheNameVal=cmds.textField(self.tFG1, q=True, tx=True)
        mel.eval('doCreateNclothCache 4 { "2", "1", "10", "OneFilePerFrame", "1", "","0","%s.xml","0", "merge", "0", "1", "1","0","1" } ' % cacheNameVal)
        
    def mCacheOpt(self, *args):
        mel.eval('nClothMergeCacheOpt')

    def enCache(self, *args):
        mel.eval('setCacheEnable 1 0 {}')
    
    def disCache(self, *args):
        mel.eval('setCacheEnable 0 0 {}')     
    
    def delCache(self, *args):
        mel.eval('deleteCacheFile 3 { "keep", "", "nCloth" }')

    def attCache(self, *args):
        mel.eval('attachNclothCache') 

    def appCache(self, *args):
        mel.eval('nClothAppendOpt') 

    def repCache(self, *args):
        mel.eval('nClothReplaceCacheOpt') 

    def delCacheFrame(self, *args):
        mel.eval('nClothDeleteCacheFramesOpt')

    def trax(self, *args):
        mel.eval('CharacterAnimationEditor')

    def interactivePlayback(self, *args):
        mel.eval('InteractivePlayback')
        
    def convToGeo(self, *args):
        alist=cmds.textScrollList(self.TSL, q=True, da=True, si=True)
        selectInputMeshList = []
        selectMeshLinkList = []
        for item in alist:
            itemType=cmds.nodeType(item)
            if itemType in ['nRigid', 'nCloth',]:
                inputMesh=cmds.listConnections('%s.inputMesh' %item, s=True, d=False)[0]
                selectInputMeshList.append(inputMesh)
                if inputMesh: 
                    meshLink=cmds.listConnections(inputMesh, d=True, s=False, t='transform')
                    if isinstance(meshLink,list):
                        meshLink=meshLink[0]
                if meshLink:
                    selectMeshLinkList.append(meshLink)
        cmds.select(selectInputMeshList)      ## << Tab this line in if commengint out above 3 lines                 ###
  
            
## Defining paint ncloth vertex commands
        
    def paintCollideStrength(self, *args):
        mel.eval('setNClothMapType("collideStrength","",1); artAttrNClothToolScript 4 collideStrength');
        mel.eval('NClothPaintCallback ""');
        
    def paintThickness(self, *args):
        mel.eval('setNClothMapType("thickness","",1); artAttrNClothToolScript 4 thickness');
        mel.eval('NClothPaintCallback ""');    

    def paintBounce(self, *args):
        mel.eval('setNClothMapType("bounce","",1); artAttrNClothToolScript 4 bounce');
        mel.eval('NClothPaintCallback ""'); 

    def paintFriction(self, *args):
        mel.eval('setNClothMapType("friction","",1); artAttrNClothToolScript 4 friction');
        mel.eval('NClothPaintCallback ""'); 

    def paintStickiness(self, *args):
        mel.eval('setNClothMapType("stickiness","",1); artAttrNClothToolScript 4 stickiness');
        mel.eval('NClothPaintCallback ""'); 

    def paintFieldMagnitude(self, *args):
        mel.eval('setNClothMapType("fieldMagnitude","",1); artAttrNClothToolScript 4 fieldMagnitude');
        mel.eval('NClothPaintCallback ""'); 

    def paintMass(self, *args):
        mel.eval('setNClothMapType("mass","",1); artAttrNClothToolScript 4 mass');
        mel.eval('NClothPaintCallback ""'); 

    def paintStretch(self, *args):
        mel.eval('setNClothMapType("stretch","",1); artAttrNClothToolScript 4 stretch');
        mel.eval('NClothPaintCallback ""'); 

    def paintBend(self, *args):
        mel.eval('setNClothMapType("bend","",1); artAttrNClothToolScript 4 bend');
        mel.eval('NClothPaintCallback ""'); 

    def paintBendAngleDropoff(self, *args):
        mel.eval('setNClothMapType("bendAngleDropoff","",1); artAttrNClothToolScript 4 bendAngleDropoff');
        mel.eval('NClothPaintCallback ""'); 

    def paintRestitutionAngle(self, *args):
        mel.eval('setNClothMapType("restitutionAngle","",1); artAttrNClothToolScript 4 restitutionAngle');
        mel.eval('NClothPaintCallback ""'); 

    def paintDamp(self, *args):
        mel.eval('setNClothMapType("damp","",1); artAttrNClothToolScript 4 damp');
        mel.eval('NClothPaintCallback ""'); 

    def paintWrinkle(self, *args):
        mel.eval('setNClothMapType("wrinkle","",1); artAttrNClothToolScript 4 wrinkle');
        mel.eval('NClothPaintCallback ""'); 

    def paintRigidity(self, *args):
        mel.eval('setNClothMapType("rigidity","",1); artAttrNClothToolScript 4 rigidity');
        mel.eval('NClothPaintCallback ""'); 

    def paintDeform(self, *args):
        mel.eval('setNClothMapType("deform","",1); artAttrNClothToolScript 4 deform');
        mel.eval('NClothPaintCallback ""'); 

    def paintInputAttract(self, *args):
        mel.eval('setNClothMapType("inputAttract","",1); artAttrNClothToolScript 4 inputAttract');
        mel.eval('NClothPaintCallback ""'); 

    def paintRestLengthScale(self, *args):
        mel.eval('setNClothMapType("restLengthScale","",1); artAttrNClothToolScript 4 restLengthScale');
        mel.eval('NClothPaintCallback ""'); 

    def paintLift(self, *args):
        mel.eval('setNClothMapType("lift","",1); artAttrNClothToolScript 4 lift');
        mel.eval('NClothPaintCallback ""'); 

    def paintDrag(self, *args):
        mel.eval('setNClothMapType("drag","",1); artAttrNClothToolScript 4 drag');
        mel.eval('NClothPaintCallback ""'); 

    def paintTangentialDrag(self, *args):
        mel.eval('setNClothMapType("tangentialDrag","",1); artAttrNClothToolScript 4 tangentialDrag');
        mel.eval('NClothPaintCallback ""'); 

## defining create constraint dropdown menu commands

    def tConstraint(self, *args):
        mel.eval('createNConstraint transform 0')
        self.refreshTSL()
        
    def c2cConstraint(self, *args):
        mel.eval('createNConstraint pointToPoint 0')
        self.refreshTSL()
        
    def p2sConstraint(self, *args):
        mel.eval('createNConstraint pointToSurface 0') 
        self.refreshTSL()       
        
    def sosConstraint(self, *args):
        mel.eval('createNConstraint slideOnSurface 0')
        self.refreshTSL() 
                       
    def wabConstraint(self, *args):
        mel.eval('createNConstraint weldBorders 0')
        self.refreshTSL()
        
    def ffConstraint(self, *args):
        mel.eval('createNConstraint force 0')
        self.refreshTSL()
        
    def a2mmConstraint(self, *args):
        mel.eval('createNConstraint match 0')
        self.refreshTSL()
        
    def tsConstraint(self, *args):
        mel.eval('createNConstraint tearableSurface 0')
        self.refreshTSL()
        
    def dcConstraint(self, *args):
        mel.eval('createNConstraint disableCollision 0')
        self.refreshTSL()

    def ecpConstraint(self, *args):
        mel.eval('createNConstraint collisionExclusion 0')
        self.refreshTSL()

## defining constraint membership dropdown menu commands

    def sMembers(self, *args):
        mel.eval('dynamicConstraintMembership "select"')    

    def repMembers(self, *args):
        mel.eval('dynamicConstraintMembership "replace"')  

    def aMembers(self, *args):
        mel.eval('dynamicConstraintMembership "add"')  

    def remMembers(self, *args):
        mel.eval('dynamicConstraintMembership "remove"') 

## defining paint constraint weights dropdown menu commnands

    def paintCStrength(self, *args):
        mel.eval('setNComponentMapType("strength",1); artAttrNComponentToolScript 4 strength; NComponentPaintCallback "";')
        
    def paintCGlueStrength(self, *args):
        mel.eval('setNComponentMapType("glueStrength",1); artAttrNComponentToolScript 4 glueStrength; NComponentPaintCallback "";')

    def paintCWeight(self, *args):
        mel.eval('setNComponentMapType("weight",1); artAttrNComponentToolScript 4 weight; NComponentPaintCallback "";')
        
## defining create nucleus wind/gravity control commands

    def createWCTRL(self, *args):
        if cmds.objExists('windCTRL'):
            cmds.error ('WindCTRL already exists')
            cmds.select('windCtrl')
        else :
            cmds.curve(n='pvWindArrow', d=1, p=[(0, 15, 0), (-3, 4, -3), (3, 4, -3), (0, 15, 0), (3, 4, 3), (-3, 4, 3), (0, 15, 0), (3, 4, -3), 
                            (1, 4, -1), (2, -15, -2), (-2, -15, -2), (-1, 4, -1), (-3, 4, -3), (-3, 4, 3), (-1, 4, 1), (-2, -15, 2), (2, -15, 2), 
                            (1, 4, 1), (3, 4, 3), (3, 4, -3), (1, 4, -1), (-1, 4, -1), (-1, 4, 1), (1, 4, 1), (1, 4, -1), (1, 4, -1), (2, -15, -2), 
                            (2, -15, 2), (-2, -15, 2), (-2, -15, -2)], k=range(30))
            cmds.rotate (0, 0, -90)
            cmds.makeIdentity(apply=True, t=True, r=True, s=True, n=True)
            cmds.rename('curveShape1', 'pvWindArrowShape')
            cmds.spaceLocator(n='pvWindOrigin')
            cmds.setAttr('pvWindOrigin.visibility', 0)
            cmds.spaceLocator(n='pvWindAim')
            cmds.setAttr('pvWindAim.visibility', 0)
            cmds.group('pvWindAim', n='pvWindAim_Null')
            cmds.setAttr('pvWindAim.translateX', 1 )
            cmds.aimConstraint('pvWindAim', 'pvWindOrigin')
            cmds.group('pvWindArrow', n='windCTRL')
            cmds.parentConstraint('windCTRL', 'pvWindAim_Null')
            cmds.select('pvWindArrowShape', 'windCTRL')
            cmds.parent(r=True, s=True)
            cmds.delete('pvWindArrow')
            cmds.pointConstraint('windCTRL', 'pvWindOrigin')
            cmds.pickWalk(direction="up")
            cmds.addAttr(ln='dynamicAmplitude', nn='Dynamic  Amplitude', at='float', dv=1)
            cmds.connectAttr('windCTRL.dynamicAmplitude','pvWindAim.translateX')
            cmds.setAttr('windCTRL.dynamicAmplitude', k=True)
            cmds.setAttr('pvWindArrowShape.overrideEnabled', 1)
            cmds.setAttr('pvWindArrowShape.overrideColor', 18)
            cmds.group('pvWindOrigin', 'pvWindAim_Null', 'windCTRL', n='windCTRL_GRP')
            cmds.setAttr('windCTRL_GRP.translateX', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.translateY', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.translateZ', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.rotateX', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.rotateY', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.rotateZ', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.scaleX', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.scaleY', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.scaleZ', k=False, l=True)
            cmds.setAttr('windCTRL_GRP.visibility', k=False, l=True)
            for eachNucleus in cmds.ls(type='nucleus') :
                cmds.connectAttr ('pvWindOrigin_aimConstraint1.constraintVectorX', '%s.windDirectionX' % eachNucleus)
                cmds.connectAttr ('pvWindOrigin_aimConstraint1.constraintVectorY', '%s.windDirectionY' % eachNucleus)
                cmds.connectAttr ('pvWindOrigin_aimConstraint1.constraintVectorZ', '%s.windDirectionZ' % eachNucleus)
            cmds.select('windCTRL');

    def createGCTRL(self, *args):
        if cmds.objExists('gravCTRL'):
            cmds.error ('gravCTRL already exists')
            cmds.select('gravCTRL')
        else :
            cmds.curve(n='pvGravArrow', d=1, p=[(0, 15, 0), (-4, 4, -4), (4, 4, -4), (0, 15, 0), (4, 4, 4), (-4, 4, 4), (0, 15, 0), (4, 4, -4), 
                            (2, 4, -2), (3, -15, -3), (-3, -15, -3), (-2, 4, -2), (-4, 4, -4), (-4, 4, 4), (-2, 4, 2), (-3, -15, 3), (3, -15, 3), 
                            (2, 4, 2), (4, 4, 4), (4, 4, -4), (2, 4, -2), (-2, 4, -2), (-2, 4, 2), (2, 4, 2), (2, 4, -2), (2, 4, -2), (3, -15, -3), 
                            (3, -15, 3), (-3, -15, 3), (-3, -15, -3)], k=range(30))
            cmds.rotate (180, 0, 0)
            cmds.makeIdentity(apply=True, t=True, r=True, s=True, n=True)
            cmds.rename('curveShape1', 'pvGravArrowShape')
            cmds.spaceLocator(n='pvGravOrigin')
            cmds.setAttr('pvGravOrigin.visibility', 0)      
            cmds.spaceLocator(n='pvGravAim')
            cmds.setAttr('pvGravAim.visibility', 0)
            cmds.group('pvGravAim', n='pvGravAim_Null')
            cmds.setAttr('pvGravAim.translateY', -1 )
            cmds.aimConstraint('pvGravAim', 'pvGravOrigin')
            cmds.group('pvGravArrow', n='gravCTRL')
            cmds.parentConstraint('gravCTRL', 'pvGravAim_Null')
            cmds.select('pvGravArrowShape', 'gravCTRL')
            cmds.parent(r=True, s=True)
            cmds.delete('pvGravArrow')
            cmds.pointConstraint('gravCTRL', 'pvGravOrigin')
            cmds.pickWalk(direction="up")
            cmds.addAttr(ln='dynamicAmplitude', nn='Dynamic  Amplitude', at='float', dv=1);
            cmds.setAttr('gravCTRL.dynamicAmplitude', k=True)
            cmds.expression(s='pvGravAim.translateY=gravCTRL.dynamicAmplitude*-1')
            cmds.setAttr('pvGravArrowShape.overrideEnabled', 1)
            cmds.setAttr('pvGravArrowShape.overrideColor', 11)
            cmds.group('pvGravOrigin', 'pvGravAim_Null', 'gravCTRL', n='gravCTRL_GRP')
            cmds.setAttr('gravCTRL_GRP.translateX', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.translateY', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.translateZ', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.rotateX', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.rotateY', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.rotateZ', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.scaleX', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.scaleY', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.scaleZ', k=False, l=True)
            cmds.setAttr('gravCTRL_GRP.visibility', k=False, l=True)
            for eachNucleus in cmds.ls(type='nucleus') :
                cmds.connectAttr ('pvGravOrigin_aimConstraint1.constraintVectorX', '%s.gravityDirectionX' % eachNucleus)
                cmds.connectAttr ('pvGravOrigin_aimConstraint1.constraintVectorY', '%s.gravityDirectionY' % eachNucleus)
                cmds.connectAttr ('pvGravOrigin_aimConstraint1.constraintVectorZ', '%s.gravityDirectionZ' % eachNucleus)
            cmds.select('gravCTRL');





instanceUI = myUI()

