#====================================================
# BatchRenderView v2.0.1.34
# 
# Script by: Hazem M. Sabry
# any suggestions / bugs don't hisitate to contact me
#
# Email: hmsabry.voxel@gmail.com
# Website: www.hmsabryworks.com
#====================================================

import maya.cmds as cmds
import maya.mel
import pickle
import time
import os
import random
import smtplib
import socket
from tempfile import gettempdir
from socket import gethostname

DBpath = "%s%s_database_%s.txt" % (cmds.workspace( q=True, rootDirectory=True),gethostname(), cmds.file(q=True, sn=True, shn=True)[:-3])
mailTimer = "%s%s_mailTimer.txt" % (cmds.workspace( q=True, rootDirectory=True),cmds.file(q=True, sn=True, shn=True)[:-3])
mailTimerTMP = "%s%s_mailTimer_tmp.txt" % (cmds.workspace( q=True, rootDirectory=True),cmds.file(q=True, sn=True, shn=True)[:-3])
renderComplete = "%s%s_renderComplete.txt" % (cmds.workspace( q=True, rootDirectory=True),cmds.file(q=True, sn=True, shn=True)[:-3])
mailSettingsFile = "%s\\_mailsettings.txt" % gettempdir()
tmpCach = "%s%s_database.txt" % (cmds.workspace( q=True, rootDirectory=True),cmds.file(q=True, sn=True, shn=True)[:-3])

scriptVersion = "V2.0.1"
stopRender = False
renderJobType = None

safeDuration = (0.3,1)
renderMaxTimes = 4

selectedCameras = None
selectedLayers = None
imageName = None

minStart = None
maxEnd = None

gmailAccount = None
gmailPass = None
mailTo = None
MailSubjectField = None
mailEvery = None
mailError = False

mailling = False

connectJob = False

frameRangeList = []
RenderingRangeList = []

infoColor = [0.4,0.6,0.4]
warningColor = [0.6,0.3,0.3]
normalColor = [0.23,0.23,0.23]
markerColor = [0.3,0.4,0.45]
markerColor2 = [0.437,0.437,0.567]

mailEnding = "\n\n_________________________________\n\n"
mailEnding+= " Thank you for using \nBatchRenderView (%s)\nPlease if you have any suggestions / bugs don't hisitate to contact me\n"% scriptVersion
mailEnding+= " www.hmsabryworks.com"


def cleanup(exactFile=[]):
	if exactFile == []:
		fileList = [mailTimer, mailTimerTMP, tmpCach, renderComplete]
	else:
		fileList = [exactFile]
	for file in fileList:
		try:
			if os.path.exists(file) == True:
					os.remove(file)
		except Exception as e:
			pass

def progressWin(timeRange = None):
	global stopRender
	amount = 0
	cmds.progressWindow(title='Rendering progress', progress=amount, status='Rendered: 0%', isInterruptable=True )
	escape = False
	
	if timeRange != None:
		sleep = timeRange
	else:
		sleep = random.uniform(safeDuration[0], safeDuration[1])
	for i in range(1):
		time.sleep(sleep)
		cmds.progressWindow( edit=True, progress=i, status=('Rendered: ' + `i` + '%' ) )
		if cmds.progressWindow( query=True, isCancelled=True ):
			escape = True
			stopRender = True
			break
	
	cmds.progressWindow(endProgress=1)
	
	return escape

	
def minutes(sec):
	output = ""
	list = []
	list.append(('Days', int(time.strftime("%j", time.gmtime(sec)))-1))
	list.append(('Hours', int(time.strftime("%H", time.gmtime(sec)))))
	list.append(('Minutes', int(time.strftime("%M", time.gmtime(sec)))))
	list.append(('Seconds', int(time.strftime("%S", time.gmtime(sec)))))

	for i in range(len(list)):
		if list[i][1] != 0:
			while(i < (len(list))):
				output += ("(%s)%s.  " % (list[i][1], list[i][0]))
				i+=1
			break
	return(output)
	
	
def outPutWindow(state, message):
	if (cmds.window("outPutWind", q=1, exists=1)): 
			cmds.deleteUI("outPutWind")
	outPutWinMessage = cmds.window( "outPutWind",title="Batch render view - output window", resizeToFitChildren = False, sizeable = False)

	cmds.columnLayout( adjustableColumn=True, h=200)
	
	if state=='error':
		cmds.text(label="User Error", align="center", font = "boldLabelFont", bgc=warningColor, h = 30)
	
	cmds.separator(h=20, style='out')
	cmds.separator(h=20, style='none')
	cmds.text(label=message, align="center")
	cmds.separator(h=20, style='none')
	cmds.separator(h=20, style='out')

	
	cmds.showWindow(outPutWinMessage)
		
	
def maillingTimer(state):
	global stopRender
	
	while(True):
		if os.path.exists(mailTimerTMP) == True:
			x = progressWin()
			if x == True:
				stopRender = True
				break
		else:
			mailTimerTmpFile = open(str(mailTimerTMP), 'wb')
			pickle.dump(gethostname(), mailTimerTmpFile, -1)
			mailTimerTmpFile.close()
			break

	if state == 'r':
		if os.path.exists(mailTimer) == True:
			mailFile = open(str(mailTimer), 'rb')
			timeNow = pickle.load(mailFile)
			mailFile.close()
			cleanup(mailTimerTMP)
			return(timeNow)
		else:
			state = 'w'
	
	if state == 'w':
		mailFile = open(str(mailTimer), 'wb')
		timeNow = time.time()
		pickle.dump(timeNow, mailFile, -1)
		mailFile.close()
		cleanup(mailTimerTMP)
		return(timeNow)


def firstMailgetter(*args):
	global gmailAccount
	global gmailPass
	global mailTo
	global MailSubjectField
	
	global stopRender
	
	gmailAccount = None
	gmailPass = None
	mailTo = None
	MailSubjectField = None
	
	stopRender = False
	
	cmds.button( "configMail", e=True, label = "Mail configured", bgc = infoColor)
	cmds.checkBox("sendMailCheck", e=True, enable = False)
	cmds.text("sendEvery", e=True, enable = False)
	
	if gmailAccount == "" or gmailPass == "" or mailTo == "":
		stopRender = True
		outPutWindow('error','you must fill all fields of mail window!')
	elif gmailAccount == "yourmail@gmail.com":
		stopRender = True
		outPutWindow('error','you must write your mail ..!! \nthis is not your Gmail account\nyourmail@gmail.com!')
	else:
		gmailAccount = str(cmds.textField("GmailFrom", q=True, text = True))
		gmailPass = str(cmds.textField("GmailPass", q=True, text = True))
		mailTo = str(cmds.textField("mailTo", q=True, text = True))
		MailSubjectField = str(cmds.textField("mailSub", q=True, text = True))
		
		if (cmds.window("mailGUIwin", q=1, exists=1)): 
			cmds.deleteUI("mailGUIwin")
		
		cmds.button( "configMail", e=True, label = "Mail configured", bgc = markerColor)
		cmds.checkBox("sendMailCheck", e=True, enable = True)
		cmds.text("sendEvery", e=True, enable = True)
		
		mailFile = open(str(mailSettingsFile), 'wb')
		savedMailData = [gmailAccount, gmailPass, mailTo, MailSubjectField]
		pickle.dump(savedMailData, mailFile, -1)
		mailFile.close()
			
			
def mailMe(message):
	global connectJob
	global gmailAccount
	global gmailPass
	global mailTo
	global MailSubjectField
	
	global stopRender	
	global mailError

	if gmailAccount == "" or gmailPass == "" or mailTo == "":
		outPutWindow('error','you must fill all fields of mail window!')
		stopRender= True
	elif gmailAccount == "yourmail@gmail.com":
		outPutWindow('error','you must write your mail ..!! \nthis is not your Gmail account\nyourmail@gmail.com!')
		stopRender = True
	else:
		mailError = False
		try:
			smtpserver = smtplib.SMTP('smtp.gmail.com',587)
			smtpserver.ehlo()
			smtpserver.starttls()
			smtpserver.ehlo
			print("%s >>>" % (timeStamp()))
			print("%s >>> Connection to Gmail Successfully" % (timeStamp()))
			print("%s >>> Connected to Gmail" % (timeStamp()))
			try:
				gmail_user = gmailAccount
				gmail_pwd = gmailPass
				smtpserver.login(gmail_user, gmail_pwd)
			except smtplib.SMTPException:
				outPutWindow('error','Authentication failed!')
				mailError = True
				smtpserver.close()
			else:
				mailError = False

		except (socket.gaierror, socket.error, socket.herror, smtplib.SMTPException) as e:
			mailError = True
			outPutWindow('error', e)		
		else:
			mailError = False

		if MailSubjectField == "":
			sub = "%s render progress" % (gethostname())
		else:
			sub = "%s (%s) render progress" % (gethostname() , MailSubjectField)
		bodymsg = message + mailEnding
		header = 'To: ' + mailTo + '\n' + 'From:  ' + gmail_user + '\n' + 'Subject: ' + sub + '\n'
		msg = header + '\n' + bodymsg + '\n\n'
		try:
			smtpserver.sendmail(gmail_user, mailTo, msg)
		except smtplib.SMTPException:
			mailError = True
			outPutWindow('error','Email could not be sent')
			smtpserver.close()
		else:
			mailError = False
		
		if mailError == False:
			print("%s >>> Email Sent Successfully" % (timeStamp()))
			cmds.button( "configMail", e=True, label = "Mail configured", bgc = markerColor)
			cmds.checkBox("sendMailCheck", e=True, enable = True)
			cmds.text("sendEvery", e=True, enable = True)

		else:
			stopRender = True
			cmds.button( "configMail", e=True, label='Configure mail', bgc = normalColor)
			cmds.checkBox("sendMailCheck", e=True, enable = False)
			cmds.text("sendEvery", e=True, enable = False)
		smtpserver.close()

	
def mailGUI(*args):
	if (cmds.window("mailGUIwin", q=1, exists=1)): 
		cmds.deleteUI("mailGUIwin")
		
	if os.path.exists(mailSettingsFile) == True:
		mailFile = open(mailSettingsFile, 'rb')
		savedMailData = pickle.load(mailFile)
		mailFile.close()
		gmailAccount, gmailPass, mailTo, MailSubjectField = savedMailData
	
	else:
		gmailAccount = ""
		gmailPass = ""
		mailTo = ""
		MailSubjectField = ""
	
	mailWin = cmds.window( "mailGUIwin",title="Configure mail", resizeToFitChildren = False, sizeable = False)
	cmds.columnLayout( adjustableColumn=True)
	cmds.text(label="You must create a Gmail account to be able to send mails from this script.", align="left", font = "boldLabelFont", ww=True, h=40)
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 110), (2, 200)])
	cmds.text(label="Gmail account", align="left", font = "boldLabelFont", bgc=markerColor, h= 20)
	cmds.textField("GmailFrom", text = gmailAccount)
	cmds.text(label="Gmail password", align="left", font = "boldLabelFont", bgc=markerColor, h= 20)
	cmds.textField("GmailPass", text = gmailPass)
	cmds.separator(h=10, style='out')
	cmds.separator(h=10, style='out')
	cmds.text(label="Your mail", align="left", font = "boldLabelFont", h= 20)
	cmds.textField("mailTo", text = mailTo)
	cmds.separator(h=10, style='out')
	cmds.separator(h=10, style='out')
	cmds.text(label="Mail subject", align="left", font = "boldLabelFont", h= 20)
	cmds.textField("mailSub", text = MailSubjectField)
	cmds.setParent( '..' )
	cmds.separator(h=10, style='out')
	cmds.button( "mailButton", label='Save mail settings', height = 30, bgc = infoColor, c='firstMailgetter()')
	cmds.showWindow(mailWin)
	

def layersQuery(mode=0):
	if mode ==0:
		selectedLayer = cmds.textScrollList("layers", query = True, selectItem = True)
	else:
		selectedLayer = cmds.ls( type='renderLayer')
	layers = []
	
	
	loop = 0
	while (loop < len(selectedLayer)):
		l = selectedLayer[loop-1]
		
		cmds.editRenderLayerGlobals( currentRenderLayer=l)
		renderEngine = maya.mel.eval('currentRenderer();')
		n = cmds.getAttr('defaultRenderGlobals.imageFilePrefix')
		if n == None or n == '':
			n = "0"
		
		layers.append((l, n, renderEngine))
		loop = loop + 1
	return (layers)


def cameraQuery():
	perspCameras = cmds.listCameras( p=True )
	
	selectedcamera = cmds.textScrollList("cameraList", query = True, selectItem = True)
	cameras = []
	
	for each in(selectedcamera):
		cameras.append(each)
	return cameras

	
def removeRanges():
	global frameRangeList
	global connectJob
	
	connectJob = False
	frameRangeList = []
	
	cmds.textScrollList("cameraList", e= True, enable=True)
	cmds.textScrollList("layers", e= True, enable=True)
	cmds.button("refreshLayers", e= True, enable=True, bgc = markerColor2)
	
	if cmds.checkBox("useRecursive", query = True, value= True) is True:
		cmds.disable("recursiveStartField", v=False)
		cmds.disable("recursiveEndField", v=False)
		cmds.button("recursiveCustomFrame", e=True, label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()', bgc = normalColor)
			
	elif cmds.checkBox("oneWay",  query = True, value= True) is True:
		cmds.disable("oneWayStartField", v=False)
		cmds.disable("oneWayEndField", v=False)
		cmds.button("oneWayCustomFrame",e=True, label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()',bgc= normalColor)
	
	if cmds.window("ramesRange", q=True, exists=True):
		cmds.deleteUI("ramesRange")


def GetFrameRange2():
	global frameRangeList
	global RenderingRangeList
	global minStart
	global maxEnd
	minStart = None
	maxEnd = None
	
	wrongValue = False
	
	selectedRange = []
	cameraCount = 0
	perspCameras = cmds.listCameras( p=True )
	layers = cmds.ls( type='renderLayer')
	for each in frameRangeList:
		layersSelected = []
		if cmds.checkBox(each[0][1], q= True, value = True) == True:
			curLayers = each[1]
			for layer in curLayers:

				if cmds.checkBox(layer[1], q= True, value = True) == True:
					start = cmds.intField(layer[2], q=True, v=True)
					end = cmds.intField(layer[3], q=True, v=True)
					if start > end:
						wrongValue = True
						break
					else:
						if minStart == None:
							minStart = start
						elif start < minStart:
							minStart = start
						
						if maxEnd == None:
							maxEnd = end
						elif end > maxEnd:
							maxEnd = end
					layersSelected.append([layer[0], start, end])	
				
			selectedRange.append( [each[0][0], layersSelected] )
	if wrongValue == True:
		outPutWindow('error', "Your camera (%s) its render layer (%s) has\nstart frame greater than end frame..!!" %(each[1][0], each[2][0]) )
	else:
		print("\nminStart = %s\t\tmaxEnd = %s\n" %(minStart, maxEnd) )
		RenderingRangeList = selectedRange
		cmds.textScrollList("cameraList", e= True, enable=False)
		cmds.textScrollList("layers", e= True, enable=False)
		cmds.button("refreshLayers", e= True, enable=False, bgc = normalColor)
	
		if cmds.checkBox("useRecursive", query = True, value= True) is True:
			cmds.disable("recursiveStartField")
			cmds.disable("recursiveEndField")
			cmds.button("recursiveCustomFrame", e=True, bgc= markerColor2, label="Remove custom ranges", c='removeRanges()')
			cmds.button("oneWayCustomFrame",e=True, label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()',bgc= normalColor)
			cmds.disable("oneWayStartField", v=False)
			cmds.disable("oneWayEndField", v=False)
			
				
		elif cmds.checkBox("oneWay",  query = True, value= True) is True:
			cmds.disable("oneWayStartField")
			cmds.disable("oneWayEndField")
			cmds.button("oneWayCustomFrame", e=True, bgc= markerColor2, label="Remove custom ranges", c='removeRanges()')
			cmds.button("recursiveCustomFrame", e=True, label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()', bgc = normalColor)
			cmds.disable("recursiveStartField", v=False)
			cmds.disable("recursiveEndField", v=False)
				
	
def FrameRangeWin2(*args):
	global frameRangeList

	if (cmds.window("ramesRange", q=1, exists=1)): 
		cmds.deleteUI("ramesRange")
	framesRangeWin = cmds.window( "ramesRange",title="Frames range", resizeToFitChildren = True, sizeable = False)
		
	if cmds.checkBox("newJob", q = True, v=True):
		if cmds.checkBox("useRecursive", query = True, value= True) is True:
			s = cmds.intField("recursiveStartField", query = True, value= True)
			e = cmds.intField("recursiveEndField", query = True, value= True)
			
		elif cmds.checkBox("oneWay",  query = True, value= True) is True:
			s = cmds.intField("oneWayStartField", query = True, value= True)
			e = cmds.intField("oneWayEndField", query = True, value= True)

		
	cmds.columnLayout( adjustableColumn=True)

	frameRangeList = []
	
	perspCameras = cmds.listCameras( p=True )
	cmds.separator(h=10, style='none')
	cmds.scrollLayout(scrollAreaHeight=10,scrollAreaWidth=5,childResizable = True, w = 310, h=562)
	camCount = 1
	layerCount = 1
	for cam in range(len(perspCameras)):
		layersList = []
		cmds.separator(h=10, style='none')
		cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 25), (2, 255)])
		cmds.checkBox("%sCheck%s"% (perspCameras[cam], camCount), label = "", bgc=markerColor , h=20)
		cmds.text(label="%s"%perspCameras[cam], align="left",bgc=markerColor )
		
		cmds.setParent( '..' )
		layers = cmds.ls( type='renderLayer')
		scrollLayout = cmds.scrollLayout(h= 100, w = 283, scrollAreaHeight=10,scrollAreaWidth=5)
		cmds.rowColumnLayout( numberOfColumns = 4,columnWidth=[(1, 25), (2, 110), (3, 60),(4, 60)])
		for layer in range(len(layers)):
			cmds.checkBox("%sCheck%s"% (layers[layer],layerCount), label = "")
			cmds.text("%s"%layers[layer], label="%s"%layers[layer], align="left")
			cmds.intField("%slayerStart%s"% (layers[layer],layerCount), v = s)
			cmds.intField("%slayerEnd%s"% (layers[layer],layerCount), v=e)   
			layersList.append( ["%s"%layers[layer],"%sCheck%s"% (layers[layer],layerCount), "%slayerStart%s"% (layers[layer],layerCount), "%slayerEnd%s"% (layers[layer],layerCount)] )
			layerCount += 1
		cmds.separator(h=10, style='out')
		cmds.separator(h=10, style='out')
		cmds.separator(h=10, style='out')
		cmds.separator(h=10, style='out')
		cmds.setParent( '..' )
		cmds.setParent( '..' )
		frameRangeList.append( [["%s"%perspCameras[cam], "%sCheck%s"% (perspCameras[cam], camCount)] , layersList] )
		camCount += 1
	cmds.setParent( '..' )
	cmds.separator(h=10, style='none')
	cmds.button("refreshlayerscameras", label="Refresh layers / cameras", bgc = markerColor2, h = 25, c='FrameRangeWin2()')
	cmds.button("frameRangeButton", label="Set ranges", bgc = infoColor, h = 40, c='GetFrameRange2()')
	cmds.showWindow(framesRangeWin)

	
def resetNaming(layers):
	try:
		for key, value, renderEngine in layers:
			cmds.editRenderLayerGlobals( currentRenderLayer=key)
			cmds.setAttr('defaultRenderGlobals.imageFilePrefix', value, type="string")
			maya.mel.eval('setCurrentRenderer %s;' % renderEngine)
			progressWin(0.1)

	except Exception as e:
		for key, value, renderEngine, customCameras in layers:
			cmds.editRenderLayerGlobals( currentRenderLayer=key)
			cmds.setAttr('defaultRenderGlobals.imageFilePrefix', value, type="string")
			maya.mel.eval('setCurrentRenderer %s;' % renderEngine)
			progressWin(0.1)

	else:
		pass

		
def cashFrames(state, frames=None):
	global DBpath
	
	while(True):
		if os.path.exists(tmpCach) == False:
			while(True):
				try:
					tmpFile = open(str(tmpCach), 'w')
					tmpFile.write(gethostname())
					tmpFile.close()
				except Exception as e:
					progressWin(0.1)
				else:
					break
			break
		else:
			progressWin(0.1)

	
	if state == 'r':
		mode = 'rb'
	elif state == 'w':
		mode = 'wb'
	
	cashTimer = time.time()
	outPutValue = None
	while(True):
		try:
			file = open(str(DBpath), mode)
			
			if state == 'r':
				frames = pickle.load(file)
				
			elif state == 'w':
				pickle.dump(frames, file, -1)
				
			file.close
			
		except Exception as e:
			if (time.time() - cashTimer) < 30:
				progressWin()
				
			else:
				break
				
		else:
			outPutValue = frames
			break
	while(True):
		try:
			os.remove(tmpCach)
		except Exception as e:
			progressWin()
		else:
			break
	if outPutValue != None:
		return outPutValue


def averageTime():
	frames = cashFrames('r')
	emptyFrames = 0
	count = 0.0
	allTime = 0.0
	for frame in frames:
		if frame[4] != None and frame[4] != 'skip':
			count += 1.0
			allTime += frame[4]
		else:
			emptyFrames += 1
	averTime = (allTime / count) * emptyFrames
	return (minutes(averTime))
		

def timeStamp():
	stamp = time.strftime("%I-%M-%S_%p", time.localtime(time.time()))
	return(stamp)
		
		
def DoRender(frames, frame):
	global stopRender
	global frameRangeList
	global connectJob
	global renderMaxTimes
	
	global gmailAccount
	global gmailPass
	global mailTo
	global MailSubjectField
	
	global safeDuration
	
	frames[frame] = (True,frames[frame][1],True,time.time(),frames[frame][4],gethostname(),frames[frame][6],frames[frame][7],frames[frame][8],frames[frame][9],frames[frame][10],frames[frame][11],frames[frame][12],frames[frame][13])
	cashFrames('w', frames)
	connectJob = frames[frame][10]
	
	if frames[frame][9] == 'recursive':
		cmds.currentTime(frames[frame][1], edit=True)
	cameras = frames[frame][7]
	
	amount = 0
	cmds.progressWindow(title='Rendering progress', progress=amount, status='Rendering: 0%', isInterruptable=True )
	
	renderingTimer = time.time()
	
	cmds.setAttr('defaultRenderGlobals.outFormatControl', 0)
	cmds.setAttr('defaultRenderGlobals.putFrameBeforeExt', True)
	cmds.setAttr('defaultRenderGlobals.periodInExt', 1)
	cmds.setAttr('defaultRenderGlobals.animation', 1)
	cmds.setAttr('defaultRenderGlobals.animationRange', 1)
	cmds.setAttr('defaultRenderGlobals.extensionPadding', 3)
	
	maya.mel.eval('setNamedPanelLayout("Single Perspective View")')
	perspPanel = cmds.getPanel( withLabel='Persp View')
	
	customCamera = None
	for cam in cameras:
		if stopRender == True:
			break
		
		endError = False
		
		if connectJob == True or frameRangeList != []:
			for key, value, renderEngine, customCamera in frames[frame][8]:#loop over layers
				print("%s >>>" % (timeStamp()))
				print("%s >>> Camera:(%s)    Layer:(%s)    Renderer:(%s)" % (timeStamp(), customCamera, key, renderEngine))
				print("%s >>> ===================" % (timeStamp()))
				print("%s >>> ==  Frame: (%s) ==" % (timeStamp(),frames[frame][1]))
				print("%s >>> ===================" % (timeStamp()))
				print("%s >>>" % (timeStamp()))
				if endError == False:
					print("%s >>> ---------------------------  SCENE ERRORS  ---------------------------\n" % (timeStamp()))
					endError = True
					
				if connectJob == True or frameRangeList != []:
					cam = customCamera
					cmds.setAttr("%s.renderable"%customCamera, 1)
					cmds.modelPanel( perspPanel, edit=True, camera = customCamera )
				cmds.editRenderLayerGlobals( currentRenderLayer=key)
				maya.mel.eval('setCurrentRenderer %s;' % renderEngine)
				cmds.setAttr('defaultRenderGlobals.imageFilePrefix', cam + "_" + value + "_" + frames[frame][6], type="string")
				
				maya.mel.eval("renderIntoNewWindow -True")
				cmds.setAttr('defaultRenderGlobals.imageFilePrefix', value, type="string")
				
				if endError == True:
					print("\n%s >>> ----------------------------------------------------------------------" % (timeStamp()))
					print("%s >>>" % (timeStamp()))
					endError = False
					
			if customCamera != None:
				break
			amount = amount + 1
			cmds.progressWindow( edit=True, progress=amount, status=('Rendering: ' + `amount` + '%' ) )
			if cmds.progressWindow( query=True, isCancelled=True ):
				stopRender = True
				break
			time.sleep(random.uniform(0.2, 0.5))
		else:
			cmds.setAttr("%s.renderable"%cam, 1)
			cmds.modelPanel( perspPanel, edit=True, camera = cam )
		
			for key, value, renderEngine in frames[frame][8]:#loop over layers
				cmds.setAttr("%s.renderable"%cam, 1)
				cmds.modelPanel( perspPanel, edit=True, camera = cam )
				print("%s >>>" % (timeStamp()))
				print("%s >>> Camera:(%s)    Layer:(%s)    Renderer:(%s)" % (timeStamp(), cam, key, renderEngine))
				print("%s >>> ===================" % (timeStamp()))
				print("%s >>> ==  Frame: (%s) ==" % (timeStamp(),frames[frame][1]))
				print("%s >>> ===================" % (timeStamp()))
				print("%s >>>" % (timeStamp()))
				if endError == False:
					print("%s >>> ---------------------------  SCENE ERRORS  ---------------------------\n" % (timeStamp()))
					endError = True
					
				cmds.editRenderLayerGlobals( currentRenderLayer=key)
				maya.mel.eval('setCurrentRenderer %s;' % renderEngine)
				cmds.setAttr('defaultRenderGlobals.imageFilePrefix', cam + "_" + value + "_" + frames[frame][6], type="string")
				
				maya.mel.eval("renderIntoNewWindow -True")
				cmds.setAttr('defaultRenderGlobals.imageFilePrefix', value, type="string")

				if endError == True:
					print("\n%s >>> ----------------------------------------------------------------------" % (timeStamp()))
					print("%s >>>" % (timeStamp()))
					endError = False
				
				amount = amount + 1
				cmds.progressWindow( edit=True, progress=amount, status=('Rendering: ' + `amount` + '%' ) )
				if cmds.progressWindow( query=True, isCancelled=True ):
					stopRender = True
					break
				time.sleep(random.uniform(0.2, 0.5))
	cmds.progressWindow(endProgress=1)
	time.sleep(random.uniform(0.2,2))
	renderTime = time.time() - renderingTimer

	resetNaming(frames[frame][8])
	
	if stopRender == True:
		return(False)
	else:
		frames = cashFrames('r')
		frames[frame] = (True,frames[frame][1],False,frames[frame][3],renderTime,frames[frame][5],frames[frame][6],frames[frame][7],frames[frame][8],frames[frame][9], frames[frame][10],frames[frame][11],frames[frame][12],frames[frame][13])
		cashFrames('w', frames)
		
		print("%s >>>" % (timeStamp()))
		print("%s >>> Rendering time: %s" % (timeStamp(),minutes(renderTime)))
		if averageTime() != "":
			print("%s >>> Average estimated time to finish render: %s" % (timeStamp(), averageTime()))
		print("%s >>> " % (timeStamp()))
	
	mailling = frames[frame][11]
	mailEvery = frames[frame][12]
	if mailling == True:
		gmailAccount = str(frames[frame][13][0])
		gmailPass = str(frames[frame][13][1])
		mailTo = str(frames[frame][13][2])
		MailSubjectField = str(frames[frame][13][3])
		
		mailLastTimer = maillingTimer('r')
		print("%s >>> mail every %s" % (timeStamp(),minutes(mailEvery*60)))
		print("%s >>> Last mail was sent from: %s" % (timeStamp(),minutes(time.time() - mailLastTimer)))
		print("%s >>> " % (timeStamp()))
		if ((time.time() - mailLastTimer)/60) >= mailEvery:
			output = "==================================\n"
			output+= "                   BatchRenderView %s\n" % scriptVersion
			output+= "                         render progress\n"
			output+= "==================================\n\n"
			output+= " Last rendered frame:\n(%s).\n\n" % frames[frame][1]
			output+= " Rendering time:\n%s\n\n" % minutes(renderTime)
			output+= " Average estimated time to finish render:\n%s\n\n" % averageTime()
			output+= " This repot has been sent from:\n(%s) Machine.\n\n" % gethostname()
			output+= "==================================\n"
			x = cashFrames('r')
			status = ""
			f = ""
			new = 0
			rendered = "D"
			crashed = "X"
			rendering = ">"
			empty = "#"
			for i in x:
				new +=1
				if i[0] == True:
					if i[4] != None:
						status = rendered
					elif i[2] == True:
						timeNow = time.time()
						if (timeNow - i[3]) > renderTime * renderMaxTimes:
							status = crashed
						else:
							status = rendering
				else:
					status = empty
				f += "  %03d%s  "% (i[1], status)
				if new == 10:
					new = 0
					f += "\n"
			output+= f + "\n==================================\n"
			output+= "Rendered: (%s),\tCrashed: (%s),\tRendering: (%s),\tEmpty: (%s)" % (rendered,crashed,rendering,empty)
			maillingTimer('w')
			mailMe(output)
	
	if renderTime <= 20:
		safeDuration = (1,5)
	else:
		safeDuration = (0.3,1)
	if stopRender == False:
		return (renderTime)
	


def dataBaseCreator(renderMethod):
	global DBpath
	global selectedCameras
	global selectedLayers
	global imageName
	global renderJobType
	
	global RenderingRangeList
	global minStart
	global maxEnd
	
	global mailEvery
	
	global gmailAccount
	global gmailPass
	global mailTo
	global MailSubjectField
	global mailling

	mailling = cmds.checkBox("sendMailCheck", q=True, v=True)
	if mailling == False:
		mailEvery = None
		mailSettings = None
	else:
		cleanup()
		if os.path.exists(mailSettingsFile) == True:
			mailFile = open(mailSettingsFile, 'rb')
			savedMailData = pickle.load(mailFile)
			mailFile.close()
			gmailAccount, gmailPass, mailTo, MailSubjectField = savedMailData
		mailMe("Your mail settings are correct")
		mailSettings = [gmailAccount, gmailPass, mailTo, MailSubjectField]
		mailEvery = cmds.intField("sendEvery",q=True,v=True)
	
	frames = []
	renderJobType = renderMethod
	file = open(str(DBpath), 'wb')
	if cmds.button("recursiveCustomFrame",q=True, c=True) == 'FrameRangeWin2()' and cmds.button("oneWayCustomFrame",q=True, c=True) == 'FrameRangeWin2()':
		cameras = cameraQuery()
		selectedLayers = layersQuery()
		
		start = 0
		end = 0
		if renderMethod == "recursive":
			start = cmds.intField("recursiveStartField", query=True, value =True) #0
			end = cmds.intField("recursiveEndField", query=True, value =True) #20
			imageName = cmds.textField("recursiveImageName",query = True, text=True)
			if imageName == "":
				imageName = "tmp"

		elif renderMethod == "oneWay":
			start = cmds.intField("oneWayStartField", query=True, value =True) #0
			end = cmds.intField("oneWayEndField", query=True, value =True) #20
			imageName = cmds.textField("oneWayImageName",query = True, text=True)
			if imageName == "":
				imageName = "tmp"
			
			if cmds.checkBox("skipFrameCheck", q=True, v=True) == True:
				skip = cmds.intField("skepFrameValue",q=True, v=True)
				for num in range(skip,start):
					taken = True 
					rendering = False
					takenTime = None
					renderDuration = 'skip'
					connectToAJOB = False
					
					#				0	1		2			3			4		5		6		7			8				9			10			11			12			13
					dataOutput = (taken,num,rendering,takenTime,renderDuration,None,imageName,cameras,selectedLayers,renderMethod, connectToAJOB, mailling, mailEvery, mailSettings)
					frames.append(dataOutput)
		
		for num in range(start,end + 1):
			
			taken = False
			rendering = False
			takenTime = None
			renderDuration = None
			connectToAJOB = False
			
			#				0	1		2			3			4		5		6		7			8				9			10			11			12			13
			dataOutput = (taken,num,rendering,takenTime,renderDuration,None,imageName,cameras,selectedLayers,renderMethod, connectToAJOB, mailling, mailEvery, mailSettings)
			frames.append(dataOutput)
		
	else:
		
		curTimeSlider = minStart
		layers = layersQuery(1)
		i = 0
		layerName = []
		
		skipDone = False
		while(curTimeSlider < maxEnd + 1):
			
			cameraName = []
			for each in RenderingRangeList:
				acceptCamera=False
				for layer in each[1]:
					if curTimeSlider >= layer[1] and curTimeSlider <= layer[2]:
						acceptCamera=True
						for l, n, renderEngine in layers:
							if l == layer[0]:
								if layerName == []:
									layerName.append((l, n, renderEngine,each[0]))
								else:
									try:
										layerName.index((l, n, renderEngine,each[0]))
									except Exception as e:
										layerName.append((l, n, renderEngine,each[0]))
										print(l, n, renderEngine,each[0])
									else:
										pass
								
				if acceptCamera==True:
					cameraName.append(each[0])
					
			if renderMethod == "recursive":
				imageName = cmds.textField("recursiveImageName",query = True, text=True)
				if imageName == "":
					imageName = "tmp"

			elif renderMethod == "oneWay":
				imageName = cmds.textField("oneWayImageName",query = True, text=True)
				if imageName == "":
					imageName = "tmp"
			
			if skipDone == False:
				skipDone = True
				if cmds.checkBox("skipFrameCheck", q=True, v=True) == True:
					skip = cmds.intField("skepFrameValue",q=True, v=True)
					for num in range(skip,minStart):
						taken = True 
						rendering = False
						takenTime = None
						renderDuration = 'skip'
						connectToAJOB = False
						
						#				0	1		2			3			4		5		6		7			8				9			10			11			12			13
						dataOutput = (taken,num,rendering,takenTime,renderDuration,None,imageName,cameraName,layerName,renderMethod, connectToAJOB, mailling, mailEvery, mailSettings)
						frames.append(dataOutput)
			
			taken = False
			rendering = False
			takenTime = None
			renderDuration = None
			connectToAJOB = True
			
			#				0		1			2			3			4		5		6		7			8			9				10			11			12			13
			dataOutput = (taken,curTimeSlider,rendering,takenTime,renderDuration,None,imageName,cameraName,layerName,renderMethod, connectToAJOB, mailling, mailEvery, mailSettings)
			frames.append(dataOutput)
			layerName = []
			
			curTimeSlider += 1
			i += 1
	
	for i in frames:
		print(i)
	
	pickle.dump(frames, file, -1)
	file.close()
	print(str(DBpath))


def runner(*args):
	global stopRender
	global DBpath
	global renderJobType
	global stopRender
	
	stopRender = False
	
	if cmds.checkBox( "newJob", query = True, v=True) is True:
		renderMethod = None
		if cmds.checkBox("useRecursive", query = True, value= True) is True:
			renderMethod = 'recursive'
		elif cmds.checkBox("oneWay",  query = True, value= True) is True:
			renderMethod = 'oneWay'
		else:
			outPutWindow('error', "You must choose a render method \n(Recursive / Oneway)")
		
		try:
			os.remove(tmpCach)
		except Exception as e:
			progressWin()
		
		if renderMethod != None:
			dataBaseCreator(renderMethod)
			coreRenderEngine()
		
	elif cmds.checkBox("connectToJob", query = True, v=True) is True:
		if DBpath != None:
			DBpath = cmds.textField("oneWayDBPath", q = True, text = True)
			frames = cashFrames('r')
			
			renderJobType = frames[0][9]
			
			coreRenderEngine()
		else:
			outPutWindow('error', "Please browes filed and get database file!")
	
	
def frameProgressPrint(frame):
	global renderJobType
	print("\n=================================================================")
	print("%s >>> rendering frame:(%s)	-	Rendering method(%s)" % (timeStamp(), frame, renderJobType))
	print("=================================================================")
	
	
#>>>>>>>>>>>>>>>>>>>>>>>>>
def coreRenderEngine(*arg):
	global stopRender
	global DBpath
	global renderJobType
	global renderMaxTimes
	
	global mailEvery
	global mailling

	firstFrame = True
	frames = cashFrames('r')
	count = len(frames)
	renderTime = 0
	allRendered = False

	autoSave = False
	if cmds.autoSave(q=True, enable=True) == True:
		autoSave = True
		maya.mel.eval("optionVar -iv autoSaveEnable false;autoSave -en false;")
	
	maya.mel.eval("unifiedRenderGlobalsWindow;")
	
	if renderJobType == "recursive":
		while(True): 
			overAllTimer = time.time()
			if stopRender == True:
				break
			if renderTime is False:
				break
			
			if firstFrame == True: 
				firstFrame = False
				frame = 0
				while(frame < count): 
					frames = cashFrames('r')
					mailling = frames[0][11]
					mailEvery = frames[0][12]
					if frames[frame][0] == False: 
						frameProgressPrint(frames[frame][1])
						renderTime = DoRender(frames, frame)
						break
					frame += 1
					
			else: 
				frame = 0
				while(frame < count):
					if stopRender == True:
						break
					if renderTime is False:
						break
					
					frames = cashFrames('r')
					if frames[frame][0] == False:
						frameProgressPrint(frames[frame][1])
						renderTime = DoRender(frames, frame)
						frame = -1

					else:
						if frames[frame][4] == None:
							timeNow = time.time()
							if (timeNow - frames[frame][3]) > renderTime * renderMaxTimes:
								if stopRender == True:
									break
								if renderTime is False:
									break
								print("\n\n>>>> frame (%s) has been crashed <<<<\n\n" %frames[frame][1])
								frameProgressPrint(frames[frame][1])
								renderTime = DoRender(frames, frame)
								frame = -1
							else:
								pass
						
					frame += 1

			__frames = cashFrames('r')
			waitingFrames = 0
			for i in range(len(__frames)):
				if stopRender == True:
					break
				if renderTime is False:
					break
					
				if __frames[i][4] is None:
					if __frames[i][2] is False:
						pass
					elif __frames[i][2] is True:
						pass
					waitingFrames += 1
					break
					
			if waitingFrames == 0:
				break
				
			if time.time() - overAllTimer < 10:
				if stopRender == True:
					break
				x = progressWin()
				if x == True:
					stopRender = True
					break
	
	elif renderJobType == "oneWay":
		renderedCount = 0
		__framesCheck = cashFrames('r')
		for __fcheck in __framesCheck:
			x = progressWin(0.001)
			if x == True:
				stopRender = True
				break
		
			if __fcheck[0] == True and __fcheck[2] == False:
				renderedCount += 1
		if renderedCount == len(__framesCheck):
			stopRender = True
			allRendered = True
		
		frame = 0
		frames = cashFrames('r')
		cmds.currentTime(frames[frame][1]-1, edit = True)
		
		endwarning = False
		
		while(frame < count):
			overAllTimer = time.time()
			if stopRender == True:
				break
			if renderTime is False:
				break
			
			print("%s >>> Changing currentTime = %s" % (timeStamp(), frames[frame][1]))
			print("%s >>>" % (timeStamp()))

			if endwarning == False:
				print("%s >>> ---------------------------  OTHER ERRORS  ---------------------------\n" % (timeStamp()))
				endwarning = True
			maya.mel.eval("playButtonStepForward;")
			if endwarning == True:
				print("\n%s >>> ----------------------------------------------------------------------" % (timeStamp()))
				print("%s >>>" % (timeStamp()))
				endwarning = False
			
			frames = cashFrames('r')
			
			if firstFrame == True:
				if frames[frame][0] == False:
					mailling = frames[0][11]
					mailEvery = frames[0][12]
					firstFrame = False
					frameProgressPrint(frames[frame][1])
					renderTime = DoRender(frames, frame)
			
			elif firstFrame == False:
				if frames[frame][0] == False:
					frameProgressPrint(frames[frame][1])
					renderTime = DoRender(frames, frame)

					
				else:
					if frames[frame][4] == None:
						timeNow = time.time()
						if (timeNow - frames[frame][3]) > renderTime * renderMaxTimes:
							print("\n>>>> frame (%s) has been crashed <<<<" %frames[frame][1])
							frameProgressPrint(frames[frame][1])
							renderTime = DoRender(frames, frame)
						else:
							pass
			
			x = progressWin()
			if x == True:
				stopRender = True
				break
			
			if frame == count - 1 and renderTime != False:
				__frames = cashFrames('r')
				crashedFrames = 0
				stillRendering = 0
				nullCounter1 = 0
				renderedCount = 0
				while(nullCounter1 < len(__frames)):
					x = progressWin(0.001)
					if x == True:
						stopRender = True
						break
					if stopRender == True:
						break
					if renderTime is False:
						break
						
					if __frames[nullCounter1][4] is None:
						if __frames[nullCounter1][0] is True:
							timeNow = time.time()
							if (timeNow - __frames[nullCounter1][3]) > renderTime * renderMaxTimes:
								crashedFrames += 1
								print("\n\n=======================\n//BatchRenderView notification//\n=======================")
								print(">>>> Frame(%s) is crashed..!!\ni will re-simulate until this frame then render it again!\n\n" % __frames[nullCounter1][1])
							else:
								stillRendering += 1
								print("\n\n=======================\n//BatchRenderView notification//\n=======================")
								print(">>>> Frame(%s) is still rendering..!!\ni will check again later and if it crashed i will render it again!\n\n" % __frames[nullCounter1][1])
					else:
						renderedCount+=1
						if renderedCount  == count:
							break
					
					if crashedFrames > 0:
						frame = -1
						cmds.currentTime(frames[0][1]-1, edit = True)
						break
						
					
					elif nullCounter1 == len(__frames):
						if stillRendering > 0 and stillRendering != 1:
							nullCounter1 = - 1
							x = progressWin()
							if x == True:
								stopRender = True
								break
								
					__frames = cashFrames('r')
					
					nullCounter1 = nullCounter1 + 1
							
			frame += 1

	if autoSave == True:
		maya.mel.eval("optionVar -iv autoSaveEnable true;autoSave -en true;")
	
	if allRendered == True:
		print("\n\nRender has been completed already!\n\n\n")
		
	elif stopRender == True:
		print("\n\nRender has been cancelled!\n\n\n")
		if mailling == True:
			mailMe("Render has been cancelled on (%s) machine at %s" % (gethostname(), timeStamp()))

	else:
		print("\n\nRender Complete\n\n\n")
		if mailling == True:
			if os.path.exists(renderComplete) == True:
				pass
			else:
				renderCompleteFile = open(str(renderComplete), 'wb')
				pickle.dump(gethostname(), renderCompleteFile, -1)
				renderCompleteFile.close()
				mailMe("Render has been completed at %s" % timeStamp())
				cleanup((mailTimer, mailTimerTMP, tmpCach))

#<<<<<<<<<<<<<<<<<<<<<<<<<


def renderTab(tab, state=None):
	
	if tab == 1:
		if state == True:
			cmds.checkBox("connectToJob", edit = True, v=False)
			cmds.columnLayout("newRenderJobColumn", edit = True, visible = True)
		cmds.rowColumnLayout( "connectRow", edit = True, visible = False)
	
	if tab == 2:
		if state == True:
			cmds.checkBox("newJob", edit = True, v=False)
			cmds.rowColumnLayout( "connectRow", edit = True, visible = True)
		cmds.columnLayout("newRenderJobColumn", edit = True, visible = False)
		
	if tab == 3:
		cmds.rowColumnLayout( "connectRow", edit = True, visible = False)
		cmds.columnLayout("newRenderJobColumn", edit = True, visible = False)
		cmds.columnLayout("recursiveCol", edit = True, visible = False)
		cmds.columnLayout("onewayColumn", edit = True, visible = False)
		
	if tab == 4:
		if state == True:
			cmds.checkBox("oneWay", edit = True, value = False)
			cmds.checkBox("skipFrameCheck", e=True, v=False)
			cmds.text("skipFrameTxt",e=True, enable = False)
			cmds.intField("skepFrameValue",e=True, enable = False)
			cmds.columnLayout("recursiveCol", edit = True, visible = True)
		cmds.columnLayout("onewayColumn", edit = True, visible = False)
		
	if tab == 5:
		if state == True:
			cmds.checkBox("useRecursive", edit = True, value = False)
			cmds.columnLayout("onewayColumn", edit = True, visible = True)
			cmds.checkBox("skipFrameCheck", e=True, v=False)
			cmds.text("skipFrameTxt",e=True, enable = False)
			cmds.intField("skepFrameValue",e=True, enable = False)
		cmds.columnLayout("recursiveCol", edit = True, visible = False)
		
	if tab == 6:
		if state == True:
			cmds.text("skipFrameTxt",e=True, enable = True)
			cmds.intField("skepFrameValue",e=True, enable = True)
		else:
			cmds.text("skipFrameTxt",e=True, enable = False)
			cmds.intField("skepFrameValue",e=True, enable = False)


def browesDialog(state):
	global DBpath
	basicFilter = "Database (*.txt)"
	
	try:
		if state == "r":
			mode = 1
			okCap = "Load database"
			selectFileFilter = "database"
		elif state == "w":
			mode = 3
			okCap = "Save database"
			selectFileFilter = ""
			
		dBPath_dialog = cmds.fileDialog2(fileFilter = basicFilter, dialogStyle=2, caption="DatabaseFile", okCaption = okCap, fileMode = mode, selectFileFilter = selectFileFilter)
		
		if mode ==3:
			DBpath = "%s/%s_database_%s.txt" % (dBPath_dialog[0],gethostname(), cmds.file(q=True, sn=True, shn=True)[:-3])
		elif mode == 1:
			DBpath = dBPath_dialog[0]
			
		if dBPath_dialog:
			if state == "w":
				cmds.textField("DBpathField", edit = True, text = str(DBpath))
			elif state == "r":
				cmds.textField("oneWayDBPath", edit = True, text = str(DBpath))
	except Exception as e:
		pass

		
def autoRefresh(*args):
	perspCameras = cmds.listCameras( p=True )
	cmds.textScrollList("cameraList", edit = True, removeAll = True)
	h =  (len(perspCameras) * 12) + 10
	if h >= 70:
		h = 70
	cmds.textScrollList("cameraList", edit = True, selectIndexedItem = 1, append = perspCameras, height = h)

	layers = cmds.ls( type='renderLayer')
	cmds.textScrollList("layers", edit = True, removeAll = True)
	h =  (len(layers) * 12) + 10
	if h >= 70:
		h = 70
	cmds.textScrollList("layers", edit = True, selectIndexedItem = 1, append = layers,height = h)

	
def showGUI():
	global DBpath
	
	if (cmds.window("renderMe", q=1, exists=1)): 
		cmds.deleteUI("renderMe")
	
	renderMe = cmds.window( "renderMe",title="Batch render view %s" % scriptVersion, resizeToFitChildren = False, sizeable = False, wh=(300,300))
	cmds.columnLayout( adjustableColumn=True)
	cmds.rowLayout( numberOfColumns=2, columnWidth2=(50, 70), adjustableColumn=2, columnAlign=(1, 'right'), columnAttach=[(1, 'both', 0), (2, 'both', 0)] )
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	
	renderForm = cmds.formLayout()
	renderTabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=200)
	cmds.formLayout( renderForm, edit=True, attachForm=((renderTabs, 'top', 0), (renderTabs, 'left', 0), (renderTabs, 'bottom', 0), (renderTabs, 'right', 0)) )

	NewRenderTab = cmds.columnLayout( adjustableColumn=True)
	cmds.separator(h=10, style='none')
	cmds.checkBox( "newJob", label="New render job" ,v= False, onCommand = "renderTab(1, True)", offCommand = "renderTab(2, False)")
	cmds.separator(h=10, style='none')
	
	cmds.columnLayout("newRenderJobColumn", adjustableColumn=True)

	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 290), (2, 290)])
	cmds.text(label="select cameras", align="center", font = "boldLabelFont", bgc=markerColor, h= 20)
	cmds.text(label="select layers", align="center", font = "boldLabelFont", bgc=markerColor, h = 20)
	cmds.separator(h=5, style='out')
	cmds.separator(h=5, style='out')
	perspCameras = cmds.listCameras( p=True )
	h =  (len(perspCameras) * 12) + 10
	if h >= 70:
		h = 70
	cmds.textScrollList("cameraList", allowMultiSelection=True, selectIndexedItem = 1, append = perspCameras, height = h)
	layers = cmds.ls( type='renderLayer')
	h =  (len(layers) * 12) + 10
	if h >= 70:
		h = 70
	cmds.textScrollList("layers", allowMultiSelection=True, selectIndexedItem = 1, append = layers, height = h)
	cmds.setParent( '..' )
	cmds.button("refreshLayers", label = "Referesh all layers / cameras", h=30, bgc = markerColor2, c='autoRefresh()')
	cmds.separator(h=10, style='none')

	form = cmds.formLayout()
	tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=200)
	cmds.formLayout( form, edit=True, attachForm=((tabs, 'top', 0), (tabs, 'left', 0), (tabs, 'bottom', 0), (tabs, 'right', 0)) )
	
	recursiveRender = cmds.columnLayout( adjustableColumn=True)

	cmds.separator(h=10, style='none')
	cmds.checkBox("useRecursive", label="Use recursive render method" ,v= False, onCommand = 'renderTab(4, True)', offCommand = 'renderTab(5, False)')
	cmds.separator(h=10, style='none')
		
	cmds.text(label='''(Not recommended with uncached simulations) Using this method means that the script will render according to (Filling 
gaps - pariority).  it will check backwords before rendering a new frame.   So by this technique it will always jumps 
between frames to make sure that all frames has been rendered.''', align="left", h=50 ,bgc=normalColor)

	cmds.separator( height=20, style='out' )
	cmds.columnLayout("recursiveCol",  adjustableColumn=True)
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 150), (2, 400)])
	cmds.text("image",label="Image name:", align="left", font = "boldLabelFont")
	cmds.textField("recursiveImageName",text="tmp")
	cmds.setParent( '..' )

	cmds.separator( height=20, style='out' )
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 285), (2, 285)])
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 150), (2, 100)])
	cmds.text("recursiveStart",label="Start render from:", align="left", font = "boldLabelFont")
	cmds.intField("recursiveStartField", value = 0, enterCommand='cmds.setFocus("endField")')
	cmds.text("end",label="End render at:", align="left", font = "boldLabelFont")
	cmds.intField("recursiveEndField", value = 10)
	cmds.setParent( '..' )
	
	cmds.button("recursiveCustomFrame", label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()', bgc = normalColor)
	
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	cmds.setParent( '..' )
		
	oneWayRender = cmds.columnLayout( adjustableColumn=True)
	
	cmds.separator(h=10, style='none')
	cmds.checkBox("oneWay",  label="Use one-way render method" ,v= False, onCommand = 'renderTab(5, True)', offCommand = 'renderTab(4, False)')
	cmds.separator(h=10, style='none')
	
	cmds.text(label='''(Must use it with uncached simulations)Using this method means that the script will render according to (Playing every
frame - pariority).     it will simulate first frame then render it then go to the next frame and so on.''', align="left", bgc=normalColor)

	cmds.columnLayout("onewayColumn",  adjustableColumn=True)
	cmds.separator( height=20, style='out' )
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 150), (2, 400)])
	cmds.text("image",label="Image name:", align="left", font = "boldLabelFont")
	cmds.textField("oneWayImageName",text="tmp")
	cmds.setParent( '..' )

	cmds.separator( height=20, style='out' )
	
	cmds.checkBox("skipFrameCheck", label="Skip frames" ,v= False, onc = 'renderTab(6,True)', ofc = 'renderTab(6,False)')
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 150), (2, 100)])
	cmds.text("skipFrameTxt",label="Start skipping from:", align="left", font = "boldLabelFont", enable = False)
	cmds.intField("skepFrameValue",value = 0, enable = False)
	cmds.separator( height=10, style='out' )
	cmds.separator( height=10, style='out' )
	cmds.setParent( '..' )
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 285), (2, 285)])
	
	cmds.rowColumnLayout( numberOfColumns = 2,columnWidth=[(1, 150), (2, 100)])
	cmds.text("oneWayStart",label="Start render from:", align="left", font = "boldLabelFont")
	cmds.intField("oneWayStartField", value = 0, enterCommand='cmds.setFocus("endField")')
	cmds.text("oneWayEnd",label="End render at:", align="left", font = "boldLabelFont")
	cmds.intField("oneWayEndField", value = 10)
	cmds.setParent( '..' )
	
	cmds.button("oneWayCustomFrame", label = "Customize frame range for each (Camera\Layer)", c='FrameRangeWin2()', bgc=normalColor)
	
	cmds.setParent( '..' )	
	
	cmds.separator(h=10, style='none')
	
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	cmds.tabLayout( tabs, edit=True, tabLabel=((recursiveRender, 'Recursive render'), (oneWayRender, 'One way render')) )
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	cmds.separator(h=5, style='none')
	cmds.rowColumnLayout( numberOfColumns = 3,columnWidth=[(1, 90), (2, 400), (3,70)])
	cmds.text("DBPath",label="Database path:", align="left", font = "boldLabelFont")
	cmds.textField("DBpathField", text = str(DBpath), enterCommand='cmds.setFocus("endField")', enable = False)
	cmds.button("onewayBrowes", label="Browes", command = 'browesDialog("w")')
	cmds.setParent( '..' )
	cmds.text("DatabaseWarning",label=''' This file must be on the server PC or on a shared folder in case you will use network render so all PCs can read and
 write render data.''', h= 40, align="left", bgc = normalColor)
	
	cmds.separator(h=20, style='out')
	cmds.rowColumnLayout(numberOfColumns = 2,columnWidth=[(1, 120), (2, 320)],columnAttach=[(1,"both", 10), (2,"left", 25)])
	
	if os.path.exists(mailSettingsFile) == True:
		mailButton = markerColor
		mailCheckBox = True
	else:
		mailButton = normalColor
		mailCheckBox = False
	cmds.button( "configMail", label='Configure mail', height = 20, bgc = mailButton, c = 'mailGUI()')
	cmds.rowColumnLayout( "mailRow", numberOfColumns = 3,columnWidth=[(1, 75), (2,70), (3,150)],columnAttach=[(1,"right", 10), (2,"left", 30),(3,"left", 10)])
	cmds.checkBox("sendMailCheck", label = "Send mail", v=False, enable = mailCheckBox, onc = 'cmds.intField("sendEvery", e=True, enable = True)', ofc='cmds.intField("sendEvery", e=True, enable = False)')
	cmds.intField("sendEvery", v=15, minValue = 15, enable = False)
	cmds.text("sendEvery", label="Send every (@minutes)", align="left", enable = True)
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	cmds.setParent( '..' )
	cmds.setParent( '..' )

	ConnectToRender = cmds.columnLayout( adjustableColumn=True)
	cmds.separator(h=10, style='none')
	cmds.checkBox("connectToJob", label="Connect to a network job" ,v= False,  onCommand = "renderTab(2, True)", offCommand = "renderTab(1, False)")
	cmds.rowColumnLayout( "connectRow", numberOfColumns = 3,columnWidth=[(1, 90), (2, 400), (3,70)])
	cmds.text("DBPath",label="Database path:", align="left", font = "boldLabelFont")
	cmds.textField("oneWayDBPath", text = '', enterCommand='cmds.setFocus("endField")')
	cmds.button(label="Browes", command = 'browesDialog("r")')
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	cmds.tabLayout( renderTabs, edit=True, tabLabel=((NewRenderTab, 'New render job'), (ConnectToRender, 'Connect to a network render job')) )
	cmds.setParent( '..' )
	cmds.setParent( '..' )
	
	cmds.separator(h=10, style='none')
	cmds.button( label='Batch render', height = 60, bgc = infoColor, command = 'runner()')
	cmds.showWindow(renderMe)
	renderTab(3)

showGUI()