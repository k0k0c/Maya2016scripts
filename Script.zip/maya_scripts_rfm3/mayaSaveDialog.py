import site
import codecs
import glob
import re
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

def pathConvert(path):
    if OSTYPE == "//Server-3d/Project":
        if path.capitalize()[:18] == "/Server-3d/Project":
            path = "//Server-3d/Project" + path[18:]
    else:
        if path.capitalize()[:19] == "//server-3d/project":
            path = "/Server-3d/Project" + path[19:]
    return path

def pathBackConvert(path):
    if str(path).capitalize()[:18] == "/Server-3d/Project":
        path = "//Server-3d/Project" + path[18:]
    return path

def pathToNetwork(path):
    expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
    path = expression.sub("//Server-3d/Project",path)
    return path

   
class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class listDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,60)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2
            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Multiply)
        gradient2 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height())
        gradient2.setColorAt(0,QtGui.QColor(255,255,255))
        gradient2.setColorAt(1,QtGui.QColor(200,200,200))
        brush2 = QtGui.QBrush(gradient2)
        painter.fillRect(option.rect,brush2)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
        gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
        gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
        brush3 = QtGui.QBrush(gradient3)
        painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
    
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
    
        gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
        gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
        brush4 = QtGui.QBrush(gradient4)
        painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        #painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
    
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
    
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
    
        text = index.data(QtCore.Qt.DisplayRole).toString()
        newText = painter.fontMetrics().elidedText(text, QtCore.Qt.ElideRight, option.rect.width())
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), newText)
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
#app = QtGui.qApp
class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.conn = mb.connect(host="192.168.0.7",user="root",passwd="12345",port=3306,db = "mel", use_unicode=True)
        self.conn.set_character_set("utf8")
        self.cursor = self.conn.cursor()
        self.parentAssetId="-1"
        self.bigAssetName=""
        self.bigAssetPath=""
        self.indType=""        
        
        self.mainLayout = QtGui.QVBoxLayout()
        self.groupBoxFind = QtGui.QGroupBox(" Find asset ")
        self.LayoutFindMain = QtGui.QVBoxLayout()
        self.LayoutFind = QtGui.QGridLayout()
        self.groupBoxFind.setLayout(self.LayoutFindMain)
        self.lastSelectedAssetPath=-1
        
        self.oneLabel = QtGui.QLabel("Project: ")
        self.oneLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.cursor.execute("select id, name from projects")
        row = self.cursor.fetchall()
        self.conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()
        self.LayoutFind.addWidget(self.oneLabel, 0, 0)
        self.LayoutFind.addWidget(self.oneCombobox, 0, 1)

        self.selectedAssetPath = ""
        self.selectedAssetName = ""
        self.selectedAssetType = ""
        self.rezChild=""
        self.rezParent=""

        self.fourLabel = QtGui.QLabel("Type: ")
        self.fourLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fourCombobox = QtGui.QComboBox()
        self.fourQlistNames = QtCore.QStringList()
        self.fourQlistNames.append("All")
        self.fourQlistNames.append("chars")        
        self.fourQlistNames.append("props")        
        self.fourQlistNames.append("sets")
        self.fourQlistNames.append("scenes")
        
        self.fiveLabel = QtGui.QLabel("Root: ")
        self.fiveLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fiveCombobox = QtGui.QComboBox()
        self.fiveQlistNames = QtCore.QStringList()
        self.fiveQlistNames.append("Network")
        self.fiveQlistNames.append("Local")        
        
        self.fourCombobox.addItems(self.fourQlistNames)
        self.fiveCombobox.addItems(self.fiveQlistNames)
        self.LayoutFind.addWidget(self.fourLabel, 0, 2)
        self.LayoutFind.addWidget(self.fourCombobox, 0, 3)
        self.LayoutFind.addWidget(self.fiveLabel, 0, 4)
        self.LayoutFind.addWidget(self.fiveCombobox, 0, 5)
                
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.LayoutFindMain.addLayout(self.LayoutFind)
        self.LayoutFindMain.addLayout(self.twoLayout)        
        
        self.groupBox = QtGui.QGroupBox(" Save ")
        self.HBLayout = QtGui.QVBoxLayout()
        self.groupBox.setLayout(self.HBLayout)
    
        self.groupBoxNV = QtGui.QGroupBox(" Name of asset")
        self.gridLayoutNV = QtGui.QGridLayout()
        self.groupBoxNV.setLayout(self.gridLayoutNV)
        self.HBLayout.addWidget(self.groupBoxNV,0)
        
        self.LabelNV = QtGui.QLabel("Asset: ")
        self.ComboboxNV = QtGui.QComboBox()        
        self.ComboboxNV.setSizePolicy(QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Preferred)
        self.LabelNV2 = QtGui.QLabel("Dop name: ")
        self.LineEditNV = QtGui.QLineEdit()     
        
        self.LabelNV3 = QtGui.QLabel("Extension: ")
        self.fourComboboxExtension = QtGui.QComboBox()
        self.fourQlistNamesExtension = QtCore.QStringList()
        self.fourQlistNamesExtension.append("Original")
        self.fourQlistNamesExtension.append(".ma")        
        self.fourQlistNamesExtension.append(".mb")        
        self.fourComboboxExtension.addItems(self.fourQlistNamesExtension)
        
        self.LabelNV4 = QtGui.QLabel("Simlpe save -> ")
        self.checkSimpleSave = QtGui.QCheckBox(" <- with podversion ")
        self.checkSimpleSave.setCheckState(QtCore.Qt.Unchecked)
        self.checkSimpleSave.connect(self.checkSimpleSave, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetSimleSave)                
        
        
        #self.ComboboxNV.setEditable(True)
        #self.ComboboxNV.lineEdit().connect(self.ComboboxNV.lineEdit(), QtCore.SIGNAL("editingFinished()"), self.editTextChangedName)
        self.gridLayoutNV.addWidget(self.LabelNV, 0, 0)
        self.gridLayoutNV.addWidget(self.ComboboxNV, 0, 1)
        self.gridLayoutNV.addWidget(self.LabelNV2, 0, 2)
        self.gridLayoutNV.addWidget(self.LineEditNV, 0, 3)        
        self.gridLayoutNV.addWidget(self.LabelNV3, 1, 0)
        self.gridLayoutNV.addWidget(self.fourComboboxExtension, 1, 1)
        self.gridLayoutNV.addWidget(self.LabelNV4, 1, 2)
        self.gridLayoutNV.addWidget(self.checkSimpleSave, 1, 3)
        
        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("clicked(const QModelIndex &)"), self.activeTreeCellCliked)        
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        #self.delegate = SpinBoxDelegate()
        #self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        self.qwsa = QtGui.QWidget()
        self.qwsaLayout = QtGui.QVBoxLayout(self.qwsa)
        
        self.checkBoxLayout = QtGui.QHBoxLayout()
        self.checkOverride = QtGui.QCheckBox(" Override current version of file")
        self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        self.checkOverride.connect(self.checkOverride, QtCore.SIGNAL("stateChanged(int)"), self.changeOvveride)                
        self.checkBoxLayout.addWidget(self.checkOverride)
        self.saveReff = QtGui.QCheckBox(" Replace root file")
        self.saveReff.setCheckState(QtCore.Qt.Checked)

        self.checkBoxLayout.addWidget(self.saveReff)
        self.qwsaLayout.addLayout(self.checkBoxLayout)              
        
        self.labelNote = QtGui.QLabel("Note:")
        self.textEditNote = QtGui.QTextEdit("")
        self.qwsaLayout.addWidget(self.labelNote)              
        self.qwsaLayout.addWidget(self.textEditNote)   
        
        self.splitter = QtGui.QSplitter(self)
        self.splitter.setFrameStyle(QtGui.QFrame.NoFrame or QtGui.QFrame.Sunken)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.addWidget(self.treeView)        
        self.splitter.addWidget(self.qwsa)
        self.HBLayout.addWidget(self.splitter,1)
       
        #print "USERR:"+str(melnik_setup.userId)
       
        self.okButt = QtGui.QPushButton("Save")
        self.okButt.setEnabled(False)
        self.okButt.released.connect(self.saveFile)
        self.okButt.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        
        self.exportCheckBox = QtGui.QCheckBox(" save enable")
        self.exportCheckBox.stateChanged.connect(self.saveEnable)

        self.treeMLabelCopy = QtGui.QLabel("Copy:")
        self.treeMLabelCopy.setVisible(False)
        self.ExportButt = QtGui.QPushButton("Export root")
        self.ExportButt.released.connect(self.saveFile)
        self.ExportButt.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)

        self.CacheButt = QtGui.QPushButton("Cache Local")
        self.CacheButt.released.connect(self.cacheSceneData)
        self.CacheButt.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        
        self.HBLayoutButton = QtGui.QHBoxLayout()
        self.HBLayout.addLayout(self.HBLayoutButton)
        self.HBLayoutButton.addWidget(self.treeMLabelCopy)
        self.HBLayoutButton.addWidget(self.ExportButt)
        self.HBLayoutButton.addWidget(self.CacheButt)
        self.HBLayoutButton.addWidget(self.okButt)
        self.HBLayoutButton.addWidget(self.exportCheckBox,0,QtCore.Qt.AlignRight)
        
        self.connect(self, QtCore.SIGNAL("accepted()"), self.acceptedSig)
        
        self.mainLayout.addWidget(self.groupBoxFind,0)
        self.mainLayout.addWidget(self.groupBox,1)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')
        #self.readSettings()                    
        #self.findText()
        self.readSettings()
        if self.initVariables() != 1:
            self.findText()
        item = self.treeModel.invisibleRootItem().child(0,0)            
        if item:
            if item.data(QtCore.Qt.UserRole+3).toString() != "5":
                if item.data(QtCore.Qt.UserRole+1).toString().split("/")[-1] != "chars":
                    item.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)
                #print("path: " + item.data(QtCore.Qt.UserRole+1).toString())
        #if self.initVariables() != 1:
        #    self.readSettings()                    
        #    self.findText()


    def cacheSceneData(self):
        print("Cache...")
        slovarik=[]
        slovarikLocalPath=[]
        lRef=cmds.ls(type="reference")
        for lr in lRef:
            pathRef=""
            try:
                if cmds.referenceQuery(lr,il=True):
                    pathRef=cmds.referenceQuery(lr,f=True,wcn=True)
            except:
                pass
            if pathRef != "":
                expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
                path = expression.sub(OSTYPE,pathRef)
                if path not in slovarik:
                    slovarik.append(path)
                    #print path

        for sl in slovarik:         
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            slovarikLocalPath.append(expression.sub(os.environ['HOME']+"/Project",sl))


       
        self.treeMLabelCopy.setVisible(True)
        self.ExportButt.setVisible(False)
        self.CacheButt.setVisible(False)
        self.okButt.setVisible(False)
        self.exportCheckBox.setEnabled(False) 
            
        for slp in range(0,len(slovarikLocalPath)):    
            QtGui.QApplication.processEvents()        
            if not os.path.exists(os.path.dirname(slovarikLocalPath[slp])):
                os.makedirs(os.path.dirname(slovarikLocalPath[slp]))
            copyDa=0
            if not os.path.exists(slovarikLocalPath[slp]):
                copyDa=1
            elif os.path.getmtime(slovarik[slp]) > os.path.getmtime(slovarikLocalPath[slp]):
                copyDa=1
            if copyDa == 1:   
                print("copy: " + slovarik[slp] + " to " + slovarikLocalPath[slp])
                QtGui.QApplication.processEvents()                
                self.treeMLabelCopy.setText("("+str(slp+1)+"/"+str(len(slovarikLocalPath))+") copy: "+str(os.path.basename(slovarikLocalPath[slp])))                
                QtGui.QApplication.processEvents()
                shutil.copyfile(slovarik[slp], slovarikLocalPath[slp])

        self.treeMLabelCopy.setVisible(False)
        self.ExportButt.setVisible(True)
        self.CacheButt.setVisible(True)
        self.okButt.setVisible(True)
        self.exportCheckBox.setEnabled(True) 

    def pathToReal(self, path):
        if OSTYPE == "//Server-3d/Project":
            if path.capitalize()[:18] == "/Server-3d/Project":
                path = "//Server-3d/Project" + path[18:]
        else:
            if path.capitalize()[:19] == "//server-3d/project":
                path = "/Server-3d/Project" + path[19:]
        if self.fiveCombobox.currentText() != "Network":                
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            path = expression.sub(os.environ['HOME']+"/Project",path)
        return path
    

    def pathToHomeNetwork(self, path):
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        path = expression.sub("//Server-3d/Project",path)
        if self.fiveCombobox.currentText() != "Network":                
            path = expression.sub(os.environ['HOME']+"/Project",path)
        return path

    def pathLocalOrNetwork(self, path):
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        path = expression.sub("//Server-3d/Project",path)
        #estVal = cmds.optionVar(q="localSave")
        #if estVal:
        if self.fiveCombobox.currentText() != "Network":
            path = expression.sub(os.environ['HOME']+"/Project",path)
        return path


    def saveEnable(self):
        if self.exportCheckBox.checkState()==QtCore.Qt.Unchecked:
            self.okButt.setEnabled(False)
        else:
            self.okButt.setEnabled(True)

    def acceptedSig(self):
            self.writeSettings()

    def closeEvent(self, event):
            self.writeSettings()
            event.accept()

    def changeOvveride(self, nuzh):
        if nuzh == 2:
            self.treeView.setEnabled(False)           
            print "selectedAssetName: "+self.findNameFile()
            #self.twoLineEdit.setText(self.selectedAssetName)
            self.twoLineEdit.setText(self.findNameFile())
            self.findText()
            item = self.treeModel.invisibleRootItem().child(0,0)
            self.treeView.expand(self.treeModel.indexFromItem(item)) 
        else:
            self.treeView.setEnabled(True)
            
    def stateChangetSimleSave(self, nuzh):       
        if nuzh == 2:
            self.treeView.setEnabled(False)           
            self.fourComboboxExtension.setEnabled(False)           
            self.LineEditNV.setEnabled(False)           
            self.ComboboxNV.setEnabled(False)           
            self.twoLineEdit.setEnabled(False)           
            self.twoPushButton.setEnabled(False)           
            self.fourCombobox.setEnabled(False)           
            self.oneCombobox.setEnabled(False)           
            self.checkOverride.setEnabled(False)           
            self.saveReff.setEnabled(False)           
            self.textEditNote.setEnabled(False)           
        else:
            self.treeView.setEnabled(True)
            self.fourComboboxExtension.setEnabled(True)           
            self.LineEditNV.setEnabled(True)           
            self.ComboboxNV.setEnabled(True)           
            self.twoLineEdit.setEnabled(True)           
            self.twoPushButton.setEnabled(True)           
            self.fourCombobox.setEnabled(True)           
            self.oneCombobox.setEnabled(True)           
            self.checkOverride.setEnabled(True)           
            self.saveReff.setEnabled(True)           
            self.textEditNote.setEnabled(True)           

    def buildFileNameForSimpleSave(self):
        sceneNameFile3=cmds.file(query=True, sn=True)        
        add=""
        exetsion=sceneNameFile3.split(".")[1]
        m=re.search("_v(?P<first_name>[0-9]{1,4}).*.m[ab]$", sceneNameFile3,re.I)
        str4=sceneNameFile3.split("/")
        str3=re.split('_v[0-9]{1,4}', str4[-1],re.I)
        if m:
            if str4[-2]=="work":
                #print("my v podversii")
                f = []
                for (dirpath, dirnames, filenames) in os.walk("/".join(str4[0:-1])):
                    f.extend(filenames)
                    break
                maxNumberFile=0
                for sl in f:
                    m=re.search(str3[0]+"_v(?P<first_name>[0-9]{1,4}).*.m[ab]$", sl,re.I)
                    if m:
                        if int(m.group('first_name')) > maxNumberFile:
                            maxNumberFile=int(m.group('first_name'))
                            exetsion=sl.split(".")[-1]
                            add=re.split('_v[0-9]{1,4}(?=_|$)',sl,re.I)
                            if len(add)>1:
                                add=add[-1].split(".")[0]
                            else:  
                                add=""
                strNext=str(maxNumberFile+1)
                #print("Sledushiy nomer: "+strNext)
                for i in range(2):
                    if len(strNext)<3:
                        strNext="0"+strNext
                    else:
                        break
                #print str3[0]
                str4[-1]=str3[0]+"_v"+strNext+add+"."+exetsion
                self.rezChild="/".join(str4)
                addSpl=add.split("_")
                str4[-1]=str3[0]+"."+exetsion
                self.rezParent="/".join(str4[0:-2])+"/"+str4[-1]
                #print("CHILD PATH: "+self.rezChild)
                #print("PARENT PATH: "+self.rezParent)
            else:
                print("ERROR: PODVERSIA NE V PAPKE WORK")
        else:
            add=""
            #print("my v korne")
            #str3=str4[-1].split("_")
            str3=str4[-1].split(".")
            #print str3
            workPath="/".join(str4[0:-1])+"/work"
            if not os.path.exists(workPath):
                #print "delaem papku"
                os.path.mkdir(workPath)
            f = []
            for (dirpath, dirnames, filenames) in os.walk(workPath):
                f.extend(filenames)
                break
            maxNumberFile=0
            for sl in f:
                m=re.search(str3[0]+"_v(?P<first_name>[0-9]{1,4}).*.m[ab]$",sl,re.I)
                if m:
                    if int(m.group('first_name')) > maxNumberFile:
                        maxNumberFile=int(m.group('first_name'))
                        exetsion=sl.split(".")[-1]
                        add=re.split('_v[0-9]{1,4}(?=_|$)',sl,re.I)
                        if len(add)>1:
                            add=add[-1].split(".")[0]
                        else:  
                            add=""
                        
            strNext=str(maxNumberFile+1)
            #print("Sledushiy nomer: "+strNext)
            for i in range(2):
                if len(strNext)<3:
                    strNext="0"+strNext
                else:
                    break
            
            self.rezChild=workPath+"/"+str3[0]+"_v"+strNext+add+"."+exetsion
            self.rezParent=sceneNameFile3
            #print("CHILD PATH: "+self.rezChild)
            #print("PARENT PATH: "+self.rezParent)
            
            
    def saveFile(self):
        sender = self.sender()
        #print sender.text()
        if self.checkSimpleSave.checkState():
            self.buildFileNameForSimpleSave()
            msgBox=QtGui.QMessageBox()
            msgBox.setText("Do you want to save your changes?")
            #print (self.rezParent+"\n"+self.rezChild)
            msgBox.setInformativeText(self.rezParent+"\n"+self.rezChild)
            msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(QtGui.QMessageBox.Save)
            ret = msgBox.exec_()
            if ret != QtGui.QMessageBox.Cancel:
                #print "save"
                extenshen="mayaBinary"
                if self.rezChild.split(".")[1]=="ma": extenshen="mayaAscii"                
                mel.eval("file -rename \""+self.rezChild+"\"")
                mel.eval("file -f -save  -options \"v=0\" -type \""+extenshen+"\"")
                shutil.copyfile(self.rezChild, self.rezParent)    
                self.accept()                        
        else:
            parentItem = self.treeModel.invisibleRootItem()
            self.listPath = []
            self.buildTree(parentItem)
            self.buildSaveFiles()
            if len(self.fileAssetPath)==0:
                QtGui.QMessageBox.warning(self, "Warning", "Vydelite faily", QtGui.QMessageBox.Ok)
                return 0
            #if self.textEditNote.toPlainText() == "" and self.checkOverride.checkState() != QtCore.Qt.Checked:
            #    QtGui.QMessageBox.warning(self, "Warning", "Zapolnite NOTE", QtGui.QMessageBox.Ok)
            #    return 0

            if self.fourComboboxExtension.currentIndex()==0:
                extension = cmds.file(q=True,sn=True,shn=True).split(".")[-1]
                if len(extension) >1:
                    for i in range(len(self.fileAssetPath)):
                        testSplit=self.fileAssetPath[i].split(".")
                        testSplit[-1]=extension
                        self.fileAssetPath[i]=testSplit.join(".")
                    for i in range(len(self.filePath)):
                        testSplit=self.filePath[i].split(".")
                        testSplit[-1]=extension
                        self.filePath[i]=testSplit.join(".")               
                
            elif self.fourComboboxExtension.currentIndex()==1:
                for i in range(len(self.fileAssetPath)):
                    testSplit=self.fileAssetPath[i].split(".")
                    testSplit[-1]="ma"
                    self.fileAssetPath[i]=testSplit.join(".")
                for i in range(len(self.filePath)):
                    testSplit=self.filePath[i].split(".")
                    testSplit[-1]="ma"
                    self.filePath[i]=testSplit.join(".")               
            else:
                for i in range(len(self.fileAssetPath)):
                    testSplit=self.fileAssetPath[i].split(".")
                    testSplit[-1]="mb"
                    self.fileAssetPath[i]=testSplit.join(".")
                for i in range(len(self.filePath)):
                    testSplit=self.filePath[i].split(".")
                    testSplit[-1]="mb"
                    self.filePath[i]=testSplit.join(".")
                        
            
            for i in range(len(self.fileAssetPath)):
                print "filePath: "+self.filePath[i]
                print "fileAssetPath: "+self.fileAssetPath[i]
                print "fileAssetTag: "+self.fileAssetTag[i]
                print "findName: "+self.findName
                print "fileAssetId: "+str(self.fileAssetId)
                
            myString = QtCore.QString()
            if self.fileAssetId == "-1":
                tmp=str(self.filePath[0]).split("/")
                for t in range(0,len(tmp)):
                    if tmp[t] == "props" or tmp[t] == "chars" or tmp[t] == "sets" or tmp[t] == "scenes":
                        self.bigAssetName=tmp[t+1]
                        self.bigAssetPath="/".join(tmp[:t+1])
                                            
                        self.indType="1"
                        if tmp[t] == "props":
                            self.indType="3"
                        elif tmp[t] == "chars":
                            self.indType="1" 
                        elif tmp[t] == "sets":
                            self.indTpe="4"
                        elif tmp[t] == "scenes":
                            self.indType="5" 
                            self.bigAssetName=tmp[t+2]
                            self.bigAssetPath="/".join(tmp[:t+2])

                        break

                self.cursor.execute("select id from mel.assets as ar, assets_has_projects as ahp where ar.name = %s and ahp.projects_id = %s and ar.id=ahp.assets_id",(self.findName,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))
                row = self.cursor.fetchall()
                self.conn.commit()                                    
                if len(row)!=0:
                    QtGui.QMessageBox.warning(self, "Warning", "Takoy asset uzhe est!", QtGui.QMessageBox.Ok)
                    return 0

                self.cursor.execute("select id from mel.assets as ar, assets_has_projects as ahp where ar.name = %s and ahp.projects_id = %s and ar.id=ahp.assets_id",(self.bigAssetName,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))
                row = self.cursor.fetchall()                                                            
                self.conn.commit()
                if len(row) != 0:
                    self.parentAssetId = row[0][0]                
                    
                print("REZ: " + str(self.parentAssetId) + " :: " + self.bigAssetName + " :: " + self.findName + " :: " + self.bigAssetPath + " :: " + self.indType)    
                    
                    
            for i in range(len(self.fileAssetPath)):        
                    myString+=self.filePath[i]+"\n"
                    if self.saveReff.checkState() == QtCore.Qt.Checked:
                        myString+=self.fileAssetPath[i]+"\n"
            
            msgBox=QtGui.QMessageBox()
            msgBox.setText("Do you want to save your changes?")
            msgBox.setInformativeText(myString)
            msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(QtGui.QMessageBox.Save)
            ret = msgBox.exec_()
            #print(self.fileAssetId)
            
            if ret != QtGui.QMessageBox.Cancel:
                if self.fileAssetId == "-1":
                    if self.parentAssetId == "-1":
                        self.cursor.execute("INSERT INTO mel.assets VALUES(null,%s,'',%s,%s,1,null,'')",(self.bigAssetName,pathToNetwork(self.bigAssetPath),int(self.indType),))                
                        self.parentAssetId=self.conn.insert_id()
                        self.cursor.execute("UPDATE assets SET parent = %s WHERE id = %s",(self.parentAssetId,self.parentAssetId,))
                        self.cursor.execute("INSERT INTO assets_has_atags VALUES(%s,1)",(self.parentAssetId,))
                        self.cursor.execute("INSERT INTO assets_has_projects VALUES(%s,%s)",(self.parentAssetId,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))                    
                        self.conn.commit()                    
                        
                    if self.findName != self.bigAssetName:
                        self.cursor.execute("INSERT INTO mel.assets VALUES(null,%s,'',%s,%s,1,null,'')",(self.findName,pathToNetwork(self.bigAssetPath),int(self.indType),))                
                        self.fileAssetId=self.conn.insert_id()
                        self.cursor.execute("UPDATE assets SET parent = %s WHERE id = %s",(self.parentAssetId,self.fileAssetId,))
                        self.cursor.execute("INSERT INTO assets_has_atags VALUES(%s,1)",(self.fileAssetId,))
                        self.cursor.execute("INSERT INTO assets_has_projects VALUES(%s,%s)",(self.fileAssetId,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))                    
                        self.conn.commit()                                            
                    else:
                        self.fileAssetId=self.parentAssetId

                for i in range(len(self.fileAssetPath)):
                   
                    self.userId = melnik_setup.userId
                    #print "USERR:"+str(self.userId)
                    if self.userId==-1 and sys.platform == "win32":
                        QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Net takogo polzovatelya")
                        return 0            
                    if self.filePath[i]==self.fileAssetPath[i]:
                        QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Nelzya perezapisat asset")
                        return 0                            
                    
                    if self.textEditNote.toPlainText() == "" and self.checkOverride.checkState() == QtCore.Qt.Checked:    
                        #print "ZAHLI0"
                        self.cursor.execute("select id from edits where path like %s order by date desc",(self.pathToHomeNetwork(str(self.filePath[i])),))
                        row = self.cursor.fetchall()
                        self.conn.commit()
                        if len(row) != 0:
                            editsId = row[0][0]
                            #print "ZAHLI: UPDATE edits SET date = now() where id="+str(editsId)
                            self.cursor.execute("UPDATE edits SET date = now() where id=%s",(editsId,))
                            self.conn.commit()
                    elif self.textEditNote.toPlainText() == "" or sys.platform != "win32":
                        pass
                    else:
                        self.cursor.execute("select id from data where path like %s",(self.pathToHomeNetwork(str(self.fileAssetPath[i])),))
                        row = self.cursor.fetchall()
                        self.conn.commit()
                        dataId=-1
                        if len(row) != 0:
                            dataId = row[0][0]
                        elif len(row) == 0:
                            #print("Netu daty, sozdaem...")
                            sss1=self.fileAssetPath[i].split("/")
                            categoryesss=""
                            nayden=0
                            for s in range(len(sss1)):
                                if sss1[s]=="maya":
                                    nayden=1
                                if nayden and s==(len(sss1)-2):
                                    categoryesss=categoryesss+sss1[s]
                                elif nayden and s<(len(sss1)-1):
                                    categoryesss=categoryesss+sss1[s]+"/"
                            self.cursor.execute("select id from dcategories where name like %s",(categoryesss,))
                            row = self.cursor.fetchall()
                            if len(row)==0:
                                self.cursor.execute("INSERT INTO dcategories VALUES(null,%s,null)",(categoryesss,))                
                                categoryesss=self.conn.insert_id()
                                self.conn.commit()
                            else:
                                categoryesss = row[0][0]
                            self.cursor.execute("INSERT INTO data VALUES(NULL,%s,%s,1,4,now())",(self.findName+self.fileAssetTag[i],self.pathToHomeNetwork(str(self.fileAssetPath[i])),))
                            dataId=self.conn.insert_id()
                            #print("dataId: "+str(dataId))
                            if self.fileAssetId != 0:
                                self.cursor.execute("INSERT INTO assets_has_data VALUES(%s,%s,%s,1)",(self.fileAssetId,dataId,categoryesss))
                            else:
                                print "PUT K PAPE NE NAIDEN!!!"
                            self.cursor.execute("INSERT INTO data_has_projects VALUES(%s,%s)",(dataId,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))
                            self.cursor.execute("INSERT INTO data_has_people VALUES(%s,%s)",(dataId,self.userId,))
                            self.conn.commit()


                        self.cursor.execute("INSERT INTO edits VALUES(NULL,now(),%s,%s)",(self.textEditNote.toPlainText().toUtf8(),self.pathToHomeNetwork(str(self.filePath[i])),))
                        editsId=self.conn.insert_id()   
                        self.cursor.execute("INSERT INTO edits_has_people VALUES(%s,%s)",(editsId,self.userId,))
                        self.cursor.execute("INSERT INTO data_has_edits VALUES(%s,%s)",(dataId,editsId,))
                        self.conn.commit()                
                    
                    
                    extenshen="mayaBinary"
                    
                    chekProject.setMayaProject(self.pathLocalOrNetwork(str(self.selectedAssetPath)))
                    
                    myqstri=QtCore.QString(self.filePath[i])
                    myqstriList= myqstri.split("/")
                    myqstriList.takeLast()
                    myqstri=myqstriList.join("/")
                    dir = QtCore.QDir()
                    if not dir.exists(myqstri):
                        dir.mkpath(myqstri)
                    
                    if self.filePath[i].split(".")[1]=="ma": extenshen="mayaAscii"                
                    if sender.text()=="Save":
                        mel.eval("file -rename \""+self.filePath[i]+"\"")
                        mel.eval("file -f -save  -options \"v=0\" -type \""+extenshen+"\"")
                    else:
                        mel.eval("file -f -options \"v=0\" -type \""+extenshen+"\" -pr -es \""+self.filePath[i]+"\"")
                    if self.filePath[i] != self.fileAssetPath[i]:
                        if self.saveReff.checkState() == QtCore.Qt.Checked:
                            fileRaznyi = self.fileAssetPath[i].split(".")
                            fileRaznyi[-1]="ma"
                            fileRaznyi = fileRaznyi.join(".")
                            fileRoot2 = QtCore.QFile(fileRaznyi)
                            if fileRoot2.exists():
                                #print "remove file..."
                                fileRoot2.remove()
                            fileRaznyi = self.fileAssetPath[i].split(".")
                            fileRaznyi[-1]="mb"
                            fileRaznyi = fileRaznyi.join(".")
                            fileRoot2 = QtCore.QFile(fileRaznyi)                                
                            if fileRoot2.exists():
                                #print "remove file..."
                                fileRoot2.remove()    
                            fileRoot = QtCore.QFile(self.filePath[i])                
                            fileRoot.copy(self.fileAssetPath[i]) 
                melnik_setup.updateScene()            
                self.accept()                    
        
    def buildTree(self, root):
        i=0
        while i != -1:
            eeewPast = root.child(i,0)
            if eeewPast is None:
                break
            root1 = eeewPast.data(QtCore.Qt.UserRole+1).toString()
            root2 = eeewPast.data(QtCore.Qt.UserRole+2).toString()
            root5 = eeewPast.data(QtCore.Qt.CheckStateRole).toString()
            #print "root1: " + root1 
            #print "root2: " + root2
            #print "root5: " + root5
            if root5 == "2":
                if root2 == "":
                    #print("buildTree2: "+root1)
                    self.listPath.append(root1)
                else:
                    if self.selectedAssetType != "5":
                        #print("buildTree1: "+root1+"/"+root2+"/maya/")
                        self.listPath.append(root1+"/"+root2+"/maya/")
                    else:
                        #print("buildTree1: "+root1+"/"+root2+"/")
                        self.listPath.append(root1+"/"+root2+"/")                        
            self.buildTree(eeewPast)
            i = i + 1

    def findNameFile(self):
            sceneNameFile3=cmds.file(query=True, sn=True)        
            str2=sceneNameFile3.split(".")
            str4=str2[0].split("/")
            str3=re.split('_v[0-9]{1,4}(?=_|$)', str4[-1],re.I)
            str5=str3[0].split("_")
            rez=str5[0]
            if len(str5)>1:
            	for i in range(1,len(str5)-1):
            		rez = rez + "_" + str5[i]
            	if str4[-2] != str5[-1] and str4[-3] != str5[-1]:
            		rez = rez + "_" + str5[-1]
            return rez            		        
            		
    def buildSaveFiles(self):
        self.filePath = QtCore.QStringList()
        self.fileAssetPath = QtCore.QStringList()
        self.fileAssetTag = QtCore.QStringList()
        self.fileAssetId = self.ComboboxNV.itemData(self.ComboboxNV.currentIndex()).toString()
        self.findName = self.ComboboxNV.currentText()
        #print(str(self.findName))
        self.findName = str(self.findName[0].toLower()+self.findName.mid(1,-1))
        sceneNameFile2=""
        izPodWork=0
        if self.checkOverride.checkState() == QtCore.Qt.Checked:         
            self.listPath=[]
            sceneNameFile2=cmds.file(query=True, sn=True)
            if sceneNameFile2=="":
                QtGui.QMessageBox.warning(self, "Warning", "Pustoy file pod temzhe imenem sohranit nelzya!", QtGui.QMessageBox.Ok)
                return
            rrezz = sceneNameFile2.split("/")
            if rrezz[-2]=="work":
                izPodWork=1
            rrezz2 = ""
            for i in range(len(rrezz)):
                if i == len(rrezz)-1 and (len(rrezz[i].split(".")) == 2 or rrezz[i]=="work"):
                    continue
                if i == len(rrezz)-2 and rrezz[i]=="work":
                    continue        
                rrezz2=rrezz2+rrezz[i]+"/"
            if rrezz2[-1]!="/":
                rrezz2 = rrezz2 + "/"
            #print("rrezz2: "+rrezz2)
            self.listPath.append(rrezz2)
            self.findName = self.findNameFile()
            #print("self.findName: "+self.findName)

        for strIn in range(0,len(self.listPath)):
            print("self.listPath: "+str(self.listPath[strIn]))
            self.listPath[strIn]=self.pathToReal(str(self.listPath[strIn]))
            print("self.listPath to REAL: "+str(self.listPath[strIn]))
            
        for strIn in self.listPath:
			#print("buildSaveFiles: " + strIn)
			maxNumberFile=0
			dir = QtCore.QDir(strIn+"work")
			dir.setNameFilters("*.ma,*.mb".split(","))
			strList = dir.entryList()
			exetsion="mb"
			for sl in strList:
				#print("sl: " + sl)
				m=re.search(self.findName+"_v(?P<first_name>[0-9]{1,4}).*.m[ab]$", sl,re.I)
				if m:
					if int(m.group('first_name')) > maxNumberFile:
						maxNumberFile=int(m.group('first_name'))
						exetsion=sl.split(".")[-1]
			strNext=str(maxNumberFile+1)
			#print("Sledushiy nomer: "+strNext)
			for i in range(2):
				if len(strNext)<3:
					strNext="0"+strNext
				else:
					break
			addStr=""    
			pathi=strIn.split("/")
			if pathi[-1]!="" and len(pathi[-1].split("."))!=1 and pathi[-1]!="work" and pathi[-1]!="maya":
				addStr="_"+pathi[-1]
			elif pathi[-2]!="work":
				addStr="_"+pathi[-2]        
			elif pathi[-3]!="work":
				addStr="_"+pathi[-3]        
			if pathi[-3] == "chars" or pathi[-3] == "props" or pathi[-3] == "sets" or pathi[-2] == "chars" or pathi[-2] == "props" or pathi[-2] == "sets" or pathi[-1] == "maya" or pathi[-2] == "maya":
				addStr=""   				
			#print("tag: "+addStr)
			newName=self.findName+"_v"+strNext+addStr+"."+exetsion
			newNameAs=self.findName+addStr+"."+exetsion
			if self.checkOverride.checkState() != QtCore.Qt.Checked:
				self.fileAssetPath.append((strIn+newNameAs).replace('\n', ''))
				if self.LineEditNV.text() != "":
					sceneNameFile2 = strIn+"work/"+self.findName+"_v"+strNext+addStr+"_"+self.LineEditNV.text()+"."+exetsion
				else:
					sceneNameFile2 = strIn+"work/"+self.findName+"_v"+strNext+addStr+"."+exetsion
				self.filePath.append(sceneNameFile2.replace('\n', ''))
			else:
				rezPath="-1"
				rezPathParentName="-1"
				shaneParasha = str(strIn+newNameAs)
				#print "shaneParasha: " + shaneParasha
				shaneParashaRez1=shaneParasha.split("/")
				for s in range(len(shaneParashaRez1)):
					if shaneParashaRez1[s]=="chars" or shaneParashaRez1[s]=="props" or shaneParashaRez1[s]=="sets":
						rezPath = "/".join(shaneParashaRez1[0:s+1])
						rezPathParentName=shaneParashaRez1[s+1]
						break
					elif shaneParashaRez1[s]=="scenes":
					    rezPath = "/".join(shaneParashaRez1[0:s+2])
					    rezPathParentName=shaneParashaRez1[s+2]
					    break
										        
				self.cursor.execute("select as1.id from assets as as1, assets as as2 where as1.path = %s and as1.name = %s and as1.parent=as2.id and as2.name = %s",(pathToNetwork(rezPath),self.findName,rezPathParentName,))
				row = self.cursor.fetchall()
				self.conn.commit()        
				if len(row) == 1:
					self.fileAssetId=row[0][0]                    
					#print "PAPKA NASHELSYA!!!"+str(self.fileAssetId)
				else:
					self.fileAssetId=0
				if not izPodWork:
					self.fileAssetPath.append(sceneNameFile2.replace('\n', ''))
					self.filePath.append(sceneNameFile2.replace('\n', ''))
				else:
					self.fileAssetPath.append((strIn+newNameAs).replace('\n', ''))
					self.filePath.append(sceneNameFile2.replace('\n', ''))
			self.fileAssetTag.append(addStr)

    def initVariables(self):
        strrr=""
        self.mayaSceneName = cmds.file(query=True, sceneName=True)
        #print self.mayaSceneName
        #print self.GlobalRootPath
        m = re.search(str(self.GlobalRootPath)+"(?P<first_name>.*)",self.mayaSceneName,re.I)
        if m is None:
            print "None1"
        else:
            strrr = m.group("first_name")
            strProject=strrr.split("/")[0]
            projectIndex = self.qlistNames.indexOf(strProject)
            self.oneCombobox.setCurrentIndex(projectIndex)
            #print strrr
            m = re.search(strProject+"/assets/(?P<first_name>.*)",strrr,re.I)
            if m is None:
                m = re.search(strProject+"/scenes/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None3"
                else:    
                    strrr=m.group("first_name")
                    strTypes=strrr.split("/")[0]
                    m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                    if m is None:
                        print "None4"
                    else:
                        strrr=m.group("first_name")
                        strrr=strrr.split("/")[0]
                        self.twoLineEdit.setText(strrr)
                        #print strrr
                        self.findText()
                        item = self.treeModel.invisibleRootItem().child(0,0)
                        self.treeView.expand(self.treeModel.indexFromItem(item))
                        return 1
            else:    
                strrr=m.group("first_name")
                strTypes=strrr.split("/")[0]
                m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None2"
                else:
                    strrr=m.group("first_name")
                    strrr=strrr.split("/")[0]
                    self.twoLineEdit.setText(strrr)
                    #print strrr
                    self.findText()
                    item = self.treeModel.invisibleRootItem().child(0,0)
                    self.treeView.expand(self.treeModel.indexFromItem(item))
                    return 1

    def clearTree(self, root):
        i=0
        while i != -1:
            eeewPast = root.child(i,0)
            if eeewPast is None:
                break
            if eeewPast.data(QtCore.Qt.UserRole+3).toString() != "5":    
                eeewPast.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)
            self.clearTree(eeewPast)
            i = i + 1
            
    def activeTreeCellCliked(self, index):
        print("activeTreeCellCliked: " + str(index.data(QtCore.Qt.UserRole+1).toString()) + " :: " + str(index.data(QtCore.Qt.DisplayRole).toString().simplified().replace('\n', '')) + " :: " + str(index.data(QtCore.Qt.UserRole+3).toString()) + " :: " + str(index.data(QtCore.Qt.CheckStateRole).toInt()[0]))
        eeePastItem = self.treeModel.itemFromIndex(index)

        eeeNew = index
        eeePast = index
        while eeeNew.row() != -1:
            eeePast = eeeNew
            eeeNew = eeeNew.parent()
              
        if len(str(eeePast.data(QtCore.Qt.DisplayRole).toString()).split("_")) > 1:
            QtGui.QMessageBox.warning(self, "Warning", "Name ne pravilnoe: \n"+eeePast.data(QtCore.Qt.DisplayRole).toString(), QtGui.QMessageBox.Ok)                        
            self.clearTree(self.treeModel.invisibleRootItem())
            self.treeView.clearSelection()
            return
        #print self.treeView.isExpanded(index)
        #print eeePastItem.hasChildren()
        self.updateNameComboBox(index)
        if index.data(QtCore.Qt.UserRole+3).toString() != "5":
            if index.data(QtCore.Qt.CheckStateRole).toInt()[0] == 2:
                eeePastItem.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)
            else:
                eeePastItem.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)

    def updateNameComboBox(self, index):
        eeeNew = index
        eeePast = index
        while eeeNew.row() != -1:
            eeePast = eeeNew
            eeeNew = eeeNew.parent()
        self.selectedAssetId = eeePast.data(QtCore.Qt.UserRole).toString()
        self.selectedAssetType = eeePast.data(QtCore.Qt.UserRole+3).toString()
        self.selectedAssetPath = eeePast.data(QtCore.Qt.UserRole+1).toString() + "/" + eeePast.data(QtCore.Qt.DisplayRole).toString().simplified().replace('\n', '')
        self.selectedAssetName = eeePast.data(QtCore.Qt.DisplayRole).toString().simplified().replace('\n', '')
        melnik_setup.globalAssetName=self.selectedAssetName
        #print "activeTreeCellCliked selectedAssetPath:" + self.selectedAssetPath
        if self.lastSelectedAssetPath != self.selectedAssetPath:
            vrodeImya = self.findNameFile()
            #print "vrodeImya:  "+ vrodeImya
            saveCheckState = index.data(QtCore.Qt.CheckStateRole).toInt()[0]
            self.clearTree(self.treeModel.invisibleRootItem())
            '''if saveCheckState == 2:
                eeePastItem = self.treeModel.itemFromIndex(index)
                eeePastItem.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)'''
            #eeePastItem = self.treeModel.itemFromIndex(index)
            #eeePastItem.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)
            #projectName = str(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString())
            slovarik={}
            if self.selectedAssetType!="5":
                charsPath = glob.glob(str(self.selectedAssetPath)+'/maya/*.m[ab]')
            else:
                charsPath = glob.glob(str(self.selectedAssetPath)+'/*.m[ab]')    
                
            for cP in charsPath:
                name=os.path.basename(cP)
                if len(name.split("_")) == 2 and not re.match(".*_v[0-9]{1,5}[_|\.].*",name):
                    slovarik[name.split(".")[0].lower()]=["-1",name.split(".")[0]]

    
                
            #print("self.selectedAssetId: " + self.selectedAssetId + " x: " + self.selectedAssetName + " x: " + self.selectedAssetPath)
            
            if self.selectedAssetId != "-1":
                self.cursor.execute("select id, name from assets as ar where ar.parent=%s",(self.selectedAssetId,))
                row = self.cursor.fetchall()
                self.conn.commit()        

                for x in row:
                    slovarik[x[1].lower()]=[x[0],x[1]]
                    
            liist=slovarik.values()
            liist=sorted(liist, key=lambda t: t[1].lower())            
            #print(str(liist))
            if len(liist)==0:
                liist=[["-1",self.selectedAssetName]]    
                
            self.ComboboxNV.clear()
            n=0        
            fo = QtGui.QFontMetrics(QtGui.QApplication.font());            
            maxWidth=0
            for x in liist:
                #print "imena iz basy" + x[1]
                self.ComboboxNV.addItem(x[1].replace('\n', ''))
                self.ComboboxNV.setItemData(n,x[0])
                if fo.width(x[1])>maxWidth:
                    maxWidth=fo.width(x[1])+20
                n=n+1

            self.ComboboxNV.view().setMinimumWidth(maxWidth);                
            vrodeImyaInt = self.ComboboxNV.findText(vrodeImya,QtCore.Qt.MatchFixedString)
            #print("vrodeImya: "+vrodeImya+" vrodeImyaInt: "+str(vrodeImyaInt))
            if vrodeImyaInt!=-1:
                self.ComboboxNV.setCurrentIndex(vrodeImyaInt)
            self.lastSelectedAssetPath = self.selectedAssetPath

    def requestNewFortune(self):
            self.itemOne.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)                    
       
    def activeTreeCellExpanded(self, index):
        #print "activeTreeCellExpanded"
        #print("expanded: "+index.child(0,0).data().toString())
        if index.parent().row() == -1:
            pal = QtGui.QApplication.palette()
            gradient = QtGui.QLinearGradient(0, 0, 0, 20)
            gradient.setColorAt(0.05, pal.base().color())
            gradient.setColorAt(0.051, pal.window().color())
            gradient.setColorAt(0.95, pal.window().color())
            gradient.setColorAt(0.951, pal.base().color())
            brush = QtGui.QBrush(gradient)
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            childItemToOpen="0"
            sceneNameFileToOpen=QtCore.QString(cmds.file(query=True, sn=True))
            item = self.treeModel.itemFromIndex(index)
            self.itemOne=item
            #QtCore.QTimer.singleShot(500, self.requestNewFortune)
            typeId = index.data(QtCore.Qt.UserRole+3).toString()
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data(QtCore.Qt.UserRole+2).toString()
	    #print("\n\nXXXXXXXXXXXXrootPath: " + rootPath+"\n\n")
            while item.takeRow(0) != []:
                pass
            
            if typeId!="5":
                rootPath+="/maya"
                childItem = QtGui.QStandardItem("  anm")
                childItem.setData(rootPath+"/work/anm/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(0,childItem)
                if sceneNameFileToOpen.contains("/work/anm/"): childItemToOpen=childItem
                
                childItem = QtGui.QStandardItem("  dyn")
                childItem.setData(rootPath+"/work/dyn/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/dyn/"): childItemToOpen=childItem
                            
                childItem = QtGui.QStandardItem("  map")
                childItem.setData(rootPath+"/work/map/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/map/"): childItemToOpen=childItem
                            
                childItem = QtGui.QStandardItem("  fur")
                childItem.setData(rootPath+"/work/fur/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/fur/"): childItemToOpen=childItem

                childItem = QtGui.QStandardItem("  shd")
                childItem.setData(rootPath+"/work/shd/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/shd/"): childItemToOpen=childItem
                            
                childItem = QtGui.QStandardItem("  light")
                childItem.setData(rootPath+"/work/light/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/light/"): childItemToOpen=childItem

                childItem = QtGui.QStandardItem("  tex")
                childItem.setData(rootPath+"/work/tex/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/tex/"): childItemToOpen=childItem
                
                childItem = QtGui.QStandardItem("  mod")
                childItem.setData(rootPath+"/work/mod/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/mod/"): 
                    childItemToOpen=childItem                        
                    self.treeView.expand(self.treeModel.indexFromItem(childItem))
                
                childchildItem = QtGui.QStandardItem("  geo")
                childchildItem.setData(rootPath+"/work/mod/geo/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/mod/geo/"): 
                    childItemToOpen=childchildItem
                            
                childchildItem = QtGui.QStandardItem("  shape")
                childchildItem.setData(rootPath+"/work/mod/shape/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/mod/shape/"): childItemToOpen=childchildItem
                            
                childchildItem = QtGui.QStandardItem("  tpl")
                childchildItem.setData(rootPath+"/work/mod/tpl/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/mod/tpl/"): childItemToOpen=childchildItem
                
                childItem = QtGui.QStandardItem("  rig")
                childItem.setData(rootPath+"/work/rig/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/work/rig/"): 
                    childItemToOpen=childItem
                    self.treeView.expand(self.treeModel.indexFromItem(childItem))                                    
                    
                childchildItem = QtGui.QStandardItem("  face")
                childchildItem.setData(rootPath+"/work/rig/face/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/rig/face/"): childItemToOpen=childchildItem
                            
                childchildItem = QtGui.QStandardItem("  sceleton")
                childchildItem.setData(rootPath+"/work/rig/sceleton/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/rig/sceleton/"): childItemToOpen=childchildItem
                            
                childchildItem = QtGui.QStandardItem("  dev")
                childchildItem.setData(rootPath+"/work/rig/dev/",QtCore.Qt.UserRole+1)
                childchildItem.setCheckable(True)
                childchildItem.setBackground(brush)
                childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childchildItem.setFont(serifFont)
                childItem.setChild(childItem.rowCount(),childchildItem)
                if sceneNameFileToOpen.contains("/work/rig/dev/"): childItemToOpen=childchildItem
            
            elif typeId == "5":            
                childItem = QtGui.QStandardItem("  tmplate")
                childItem.setData(rootPath+"/tmplate/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(0,childItem)
                if sceneNameFileToOpen.contains("/tmplate/"): childItemToOpen=childItem
                
                childItem = QtGui.QStandardItem("  anm")
                childItem.setData(rootPath+"/anm/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/anm/"): childItemToOpen=childItem
                            
                childItem = QtGui.QStandardItem("  dyn")
                childItem.setData(rootPath+"/dyn/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/dyn/"): childItemToOpen=childItem
                            
                childItem = QtGui.QStandardItem("  light")
                childItem.setData(rootPath+"/light/",QtCore.Qt.UserRole+1)
                childItem.setCheckable(True)
                childItem.setBackground(brush)
                childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                childItem.setFont(serifFont)
                item.setChild(item.rowCount(),childItem)
                if sceneNameFileToOpen.contains("/light/"): childItemToOpen=childItem
            
            
            if childItemToOpen != "0": 
                childItemToOpen.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)                    
                #print "childItemToOpen: " +childItemToOpen.data(QtCore.Qt.DisplayRole).toString()
                self.activeTreeCellCliked(self.treeModel.indexFromItem(childItemToOpen))
                childItemToOpen.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)
                
        self.updateNameComboBox(index)
    
            
    def findText(self):   
        fingTextLine = self.twoLineEdit.text()
        #print "fingTextLine: "+fingTextLine        
        '''test = fingTextLine.split("<::>")
        if len(test)==1:
            #fingTextLine+="%"
            #fingTextLine="%"+fingTextLine+"%"
            pass
        else:
            fingTextLine=test[0]


        if len(fingTextLine.split("%"))==3:
            self.twoLineEdit.setText(fingTextLine.split("%")[1])
        else:
            self.twoLineEdit.setText(fingTextLine.split("%")[0])
        '''
            
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()


        REALROOTOFFILES=OSTYPE
        #if self.fiveCombobox.currentText() != "Network":
        #    REALROOTOFFILES=os.environ['HOME']+"/Project"
        #    if not os.path.exists(REALROOTOFFILES):
        #        os.makedirs(REALROOTOFFILES)

        
        pal = QtGui.QApplication.palette()
        gradient = QtGui.QLinearGradient(0, 0, 0, 20)
        gradient.setColorAt(0.05, pal.base().color())
        gradient.setColorAt(0.051, pal.window().color())
        gradient.setColorAt(0.95, pal.window().color())
        gradient.setColorAt(0.951, pal.base().color())
        brush = QtGui.QBrush(gradient)

        slovarik={}

        mun=1        
        if self.fourCombobox.currentText()=="props": mun=3
        elif self.fourCombobox.currentText()=="sets": mun=4
        elif self.fourCombobox.currentText()=="scenes": mun=5

        fingTextLineForSeach=re.sub("%|\*","",str(fingTextLine))
        rezTESET=""
        for t in fingTextLineForSeach:
            rezTESET=rezTESET+"["+t.upper()+t.lower()+"]"
    
        if self.fourCombobox.currentText()!="All":
            if self.fourCombobox.currentText()=="props":    
                propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*' + rezTESET + '*')
                for epSc in propsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]               
            elif self.fourCombobox.currentText()=="sets":    
                setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*' + rezTESET + '*')
                for epSc in setsPath:
                    epSc=epSc.replace("\\","/")                
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]            
            elif self.fourCombobox.currentText()=="scenes":    
                scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*' + rezTESET + '*')
                for epSc in scenesPath:
                    epSc=epSc.replace("\\","/")                
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]             
            else:
                charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*' + rezTESET + '*')
                for epSc in charsPath:
                    epSc=epSc.replace("\\","/")                
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
                        
            self.cursor.execute("select ar.id, ar.name, ar.path, ar.atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),mun,"%"+fingTextLine+"%",))
        else:
            propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*' + rezTESET + '*')
            for epSc in propsPath:
                epSc=epSc.replace("\\","/")            
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]
            setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*' + rezTESET + '*')
            for epSc in setsPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]
            scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*' + rezTESET + '*')
            for epSc in scenesPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]
            charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*' + rezTESET + '*')
            for epSc in charsPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
            #print("CHTO ETO!!! " + str(fingTextLine))                    
            self.cursor.execute("select ar.id, ar.name, ar.path, ar.atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),"%"+fingTextLine+"%",))
            
        row = self.cursor.fetchall()
        '''if len(row)==0 and len(fingTextLine.split("%"))==1:
            print("CHTO ETO!!! " + str(fingTextLine))
            self.cursor.execute("select ar.id, ar.name, ar.path, ar.atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),mun,"%"+fingTextLine+"%",))            
            row = self.cursor.fetchall()
        '''
        
        self.conn.commit()            

        #print("row len: "+ str(len(row)))

        #if self.fiveCombobox.currentText() == "Network":
        for x in row:
            if os.path.isdir(pathConvert(str(x[2]+"/"+x[1]))) and pathConvert(str(x[2]+"/"+x[1])) in slovarik.keys():
                slovarik[pathConvert(str(x[2]+"/"+x[1]))]=[x[0],x[1],x[2],x[3]]
                    
        liist=slovarik.values()
        liist=sorted(liist, key=lambda t: t[1].lower())            
        
        for x in liist:
            item = QtGui.QStandardItem(x[1])
            item.setBackground(brush)
            serifFont=QtGui.QFont()
            #print x[3]
            if str(x[3]) != "5": item.setCheckable(True)
            serifFont.setBold(True)
            item.setFont(serifFont)
            child = QtGui.QStandardItem(pathConvert(x[2]))
            item.setData("  "+x[1],QtCore.Qt.DisplayRole)
            item.setData(x[0],QtCore.Qt.UserRole)
            item.setData(pathConvert(x[2]),QtCore.Qt.UserRole+1)
            item.setData(x[1],QtCore.Qt.UserRole+2)
            item.setData(x[3],QtCore.Qt.UserRole+3)
            item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            item.setChild(0,child)
            parentItem.appendRow(item)

                
    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        self.curProject = settings.value("project", "1").toInt()
        self.oneCombobox.setCurrentIndex(self.curProject[0])    
        self.curType = settings.value("type", "1").toInt()
        self.fourCombobox.setCurrentIndex(self.curType[0])        
        self.curRoot = settings.value("root", "0").toInt()
        self.fiveCombobox.setCurrentIndex(self.curRoot[0])        
        self.splitter.restoreState(settings.value("OpenSplitter").toByteArray())
           
        #self.twoLineEdit.setText(settings.value("findString", "%").toString())
        self.twoLineEdit.setText(codecs.encode(settings.value("findString", "%").toString(), 'utf-8'))
        chekStat = settings.value("checkOverride", "0").toInt()
        if chekStat[0] == 0: self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        else: self.checkOverride.setCheckState(QtCore.Qt.Checked)
        settings.endGroup()            
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", OSTYPE+"/").toString()
        settings.endGroup()

    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.setValue("project", self.oneCombobox.currentIndex())
        settings.setValue("findString", self.twoLineEdit.text())
        settings.setValue("type", self.fourCombobox.currentIndex())        
        settings.setValue("root", self.fiveCombobox.currentIndex())                
        chekStat = 0
        if self.checkOverride.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("checkOverride", chekStat)        
        settings.setValue("OpenSplitter", self.splitter.saveState())
        settings.endGroup()        
        

#if ex.exec_() == QtGui.QDialog.Accepted:
#    print "Accept"
#else:
#    print "Reject"
#cursor.close()    
#conn.close()
#ex = Window()
#ex.exec_()
#melnik_setup.mSd = Window()
#melnik_setup.mSd.exec_()

