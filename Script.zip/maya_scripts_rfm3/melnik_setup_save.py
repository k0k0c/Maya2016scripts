import sys, os
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI

userId="empty"

def run():
	conn = mb.connect(host="192.168.0.206",user="yago",passwd="yagogo",db = "mel")
	conn.set_character_set("utf8")
	cursor = conn.cursor()

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.settimeout(0.13)
	data="empty"            
	try:
		s.connect(("localhost", 55222))
	except socket.timeout:
		QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error: Timeout")
	except socket.error, msg:
		QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error: Obrabotali oshibochku: "+msg)                
	try:                                
		rez = s.send("polySphere")
	except socket.error, msg:
		QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error: Obrabotali oshibochku: "+msg)                
	if rez: 
		data=s.recv(999999)
		s = QtCore.QString(data)
		list = s.split("<xbeg:>")
		for l1 in list:
			l2 = l1.split("<xend:>")
			for l3 in l2:
				l4 = l3.split("<xtext:>")
				if l4.count()==2:
					if len(l4[1]) == l4[0].toInt()[0]:
						s=l4[1]
		data=s.split("::")[1]

	else: 
		QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Data pustaya")				
	#s.close()

	if data=="empty":
		QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Net takogo polzovatelya")
		return 0

	cursor.execute("select id from people where nickname=%s",(data,))
	row = cursor.fetchall()
	userIdTmp=-1
	if len(row)==1:
		print("Takoy polsovatel uzhe est")
		userIdTmp=row[0][0]
	elif len(row)==0:
		print("Sozdaem novogo polzovatelya")        
		cursor.execute("INSERT INTO people VALUES(NULL,NULL,NULL,NULL,%s,NULL,'1','1','1')",(data,))    
		userIdTmp=conn.insert_id()   
		conn.commit()
		print("User id: "+str(userIdTmp))
	else:
		QtGui.QMessageBox().warning(QtGui.QWidget(), "Error", "Neskolko polzovateley s odnim i temzhe imenem");
			
	global userId
	userId=userIdTmp
	print("userIdTmp = "+str(userIdTmp))
	cursor.close()    
	conn.close()

def setting():
    if not cmds.optionVar( ex='Save edits'):
        cmds.optionVar( iv=('Save edits',0))
    do = cmds.optionVar( q='Save edits' )    
    app = QtGui.qApp
    widget = QtGui.QDialog()
    checBox = QtGui.QCheckBox(": save edits")
    checBox.setChecked(do) 
    layout = QtGui.QVBoxLayout()
    layoutButt = QtGui.QHBoxLayout()
    okButt = QtGui.QPushButton("Ok")
    okButt.clicked.connect(widget.accept)
    cancelButt = QtGui.QPushButton("Cancel")
    cancelButt.clicked.connect(widget.reject)
    layoutButt.addWidget(okButt)
    layoutButt.addWidget(cancelButt)
    layout.addWidget(checBox);
    layout.addLayout(layoutButt);
    widget.setLayout(layout);
    widget.resize(150, 50)
    widget.setWindowTitle('Settings')
    if widget.exec_() == QtGui.QDialog.Accepted:
        cmds.optionVar( iv=('Save edits',checBox.isChecked()))
    else:
        print "Reject"
		
def fileNewSaveAs():
    import os, fnmatch
    import maya.cmds as cmds
    import maya.mel as mel
    import re
    strIn=cmds.file(query=True, sn=True)
    if strIn != "":
        str2=strIn.split(".")
        str3=re.split('[0-9]{1,4}$', str2[0])
        maxNumberFile=0
        templateName=str3[0]+"[0-9]*."+str2[1]
        files = os.listdir(os.path.abspath(os.path.dirname(strIn)))
        for filename in fnmatch.filter(files, os.path.basename(templateName)):
            m=re.search(r'[0]*(?P<first_name>[0-9]{1,4}).m[ab]$', filename)
            print filename        
            if m:
                print m.group('first_name') 
                if int(m.group('first_name')) > maxNumberFile:
                    maxNumberFile=int(m.group('first_name'))
        
        strNext=str(maxNumberFile+1)
        for i in range(2):
            if len(strNext)<3:
                strNext="0"+strNext
            else:
                break
        newName=str3[0]+strNext+"."+str2[1]
        extenshen="mayaBinary"
        if str2[1]=="ma": extenshen="mayaAscii"
        #mel.eval("performFileAction( \""+newName+"\", 0, \""+extenshen+"\")")
        mel.eval("file -rename \""+newName+"\"")
        mel.eval("file -f -save  -options \"v=0\" -type \""+extenshen+"\"")
    else:
        print("File Name UNKNOVN!")

def sendToUser(sttr):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    try:
        s.connect(("localhost", 55222))
    except socket.timeout:
        #QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error: Timeout")        
        cmds.warning("USER dont started")
        return 1
    except socket.error, msg:
        #QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error - conection "+msg)                
        cmds.warning("error - conection to USER")
        return 1
    try: 
        rez=s.send("<xbeg:>"+str(len(sttr))+"<xtext:>"+sttr+"<xend:>")
        print("sendToUser: "+"<xbeg:>"+str(len(sttr))+"<xtext:>"+sttr+"<xend:>");
    except socket.error, msg:
        #QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "error - send "+msg)                
        cmds.warning("error - send to USER")    
        return 1
    if rez: 
		data=s.recv(999999)
		s = QtCore.QString(data)
		list = s.split("<xbeg:>")
		for l1 in list:
			l2 = l1.split("<xend:>")
			for l3 in l2:
				l4 = l3.split("<xtext:>")
				if l4.count()==2:
					if len(l4[1]) == l4[0].toInt()[0]:
						s=l4[1]
		data=s.split("::")[1]

    else: 
        #QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Data pustaya")				
        cmds.warning("Data from USER is empty")    
        return 1
        
        #s.close()
        print data		

def updateScene():
    strVar=cmds.file(q=True, sn=True, shortName=True)
    if strVar == "":
        strVar="untitled"
    out = "MAYA::INIT::"+str(cmds.optionVar( q=('Port open')))+"::"+strVar
    sendToUser(out)