import os
import sys
import glob
import string
import re
#import dircache
testCm = sys.argv
#if len(testCm)==4:
tmp = sys.argv[1]
dir = tmp.split('\\')
fileCm=dir[-1]
dir[-1]=""
dir='/'.join(dir)
#list = dircache.listdir(dir)
names = os.listdir(dir)
file = open(dir+"render.bat", "w+")
fileBacth = open(dir+"batch.log", "w+")
d={}
for x in names:
		tmp1 = x.split('.')
		if tmp1[-1]=='mb' or tmp1[-1]=='ma':
			print 'Priem:', x
			fileBacth.write("\nPriem: "+x+"\n")
			#fff=re.findall("[SsRr]+[0-9]+[EePp]+[0-9]+[SsCc]+[0-9]+", x)
			fff=re.findall("[SsRr]+[0-9]+[EePp]+[0-9]+[SsCc]+[0-9]+(?:dop(?:_[abcde])?)*", x)
			ddd=fff[0]
			stringName=str.lower(ddd)
			if stringName in d:
				#print "uzhe est"
				dataPrev=os.stat(dir+d[stringName])[8]
				dataCurr=os.stat(dir+x)[8]
				print "Stariy: ", d[stringName] , "data", dataPrev
				fileBacth.write("Stariy: "+d[stringName]+" data "+str(dataPrev)+"\n")
				print "Noviy: ", x , "data", dataCurr
				fileBacth.write("Noviy: "+x+" data "+str(dataCurr)+"\n")
				fileBacth.write("Pobedil stariy\n")
				dKey=stringName
				dName=x
				d[dKey]=dName
				#st = os.stat(dir+x)
				#print 'Otvet:', st[8]
			else:
				#print "eshe net"
				dKey=stringName
				dName=x
				d[dKey]=dName
print ''
print ''
print ''
for key in d:
	print d[key]
	fileBacth.write(d[key]+"\n")
	tmp1 = d[key].split('.')
	tmp1[-2]=tmp1[-2]+"_bacth"
	tmp1[-1]='log'
	tmp1='.'.join(tmp1)
	file.write("start /B /W C:\\PROGRA~1\\Autodesk\\Maya2010\\bin\\maya.exe -batch -command \"FolderBatchSaveMbToMa()\" -log \""+dir+tmp1+"\" -proj \"//server-3d/Project/SOBAKI\" -file "+dir+d[key]+"\"\n")
	 
file.close()
fileBacth.close()	
os.system (file.name)
	 

