import site
import os
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as OpenMaya
import sys
import re

global OSTYPE
OSTYPE = "//Server-3d/Project"
if sys.platform != "win32":
		OSTYPE="/Server-3d/Project"
batchMode = cmds.about(b=True)
if not batchMode:
    if OSTYPE == "//Server-3d/Project":
        site.addsitedir(OSTYPE+'/lib/soft/Python2013/Lib/site-packages')

        import sys, os        
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
        #from PyQt4 import QtCore, QtGui
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI

        import melnik_setup
        import ClientServer
        import chekProject
    else:
        site.addsitedir(OSTYPE+'/lib/soft/Python2013_lin')

        import sys, os        
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
        #from PyQt4 import QtCore, QtGui
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI

        import melnik_setup
        import ClientServer
        import chekProject
else:
    if OSTYPE == "//Server-3d/Project":
        site.addsitedir(OSTYPE+'/lib/soft/Python2013/Lib/site-packages')
        import sys, os        
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI
    else:
        site.addsitedir(OSTYPE+'/lib/soft/Python2013_lin')
        import sys, os        
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI


def resolfReferencePath(retCode, fileObject, clientData):
    rel = fileObject.expandedFullName()                         
    '''if sys.platform == "win32":
        if rel.lower()[:14] == "/mnt/server-3d":
            rel = "//Server-3d/Project" + rel[14:]
            #print "Callback was changed %s" % rel
        if rel.lower()[:2] == "p:":
            rel = "//Server-3d/Project" + rel[2:]
            #print "Callback was changed %s" % rel
    else:
        if rel.lower()[:19] == "//server-3d/project":
            rel = "/mnt/server-3d" + rel[19:]
            #print "Callback was changed %s" % rel
        if rel.lower()[:2] == "p:":
            rel = "/mnt/server-3d" + rel[2:]
            #print "Callback was changed %s" % rel
    '''
    expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
    rel = expression.sub(OSTYPE,rel)
    batchMode = cmds.about(b=True)
    if not batchMode:
        estVal = cmds.optionVar(q="localSave")
        if estVal:
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            temp = expression.sub(os.environ['HOME']+"/Project",rel)
            if os.path.exists(temp):
                rel=temp
                #print "Callback was changed %s" % rel            
    
    fileObject.setRawFullName(rel)
    OpenMaya.MScriptUtil.setBool(retCode, True)
     
id = OpenMaya.MSceneMessage.addCheckFileCallback(OpenMaya.MSceneMessage.kBeforeReferenceCheck, resolfReferencePath)


def resolfImageFilePath(clientData):
    OSTYPE = sys.platform
    if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
    else:
        OSTYPE="/Server-3d/Project"
    #print("\n\nresolf path OSTYPE: "+OSTYPE+"\n\n")

    filePaths = cmds.ls(type="file",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".fileTextureName")
        if OSTYPE == "//Server-3d/Project":
            if path.lower()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".fileTextureName","//Server-3d/Project" + path[18:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[14:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".fileTextureName","//Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.lower()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".fileTextureName","/Server-3d/Project" + path[19:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".fileTextureName","/Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[2:])

    filePaths = cmds.ls(type="RMSEnvLight",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".rman__EnvMap")
        if OSTYPE == "//Server-3d/Project":
            if path.lower()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".rman__EnvMap","//server-3d/Project" + path[18:],type="string")
                #print "File was changed %s" % ("//server-3d/Project" + path[14:])
        elif OSTYPE == "/Server-3d/Project":
            if path.lower()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[19:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[19:])

    filePaths = cmds.ls(type="RenderManLight",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".shadername")
        if OSTYPE == "//Server-3d/Project":
            if path.lower()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".shadername","//Server-3d/Project" + path[18:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[14:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".shadername","//Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.lower()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".shadername","/Server-3d/Project" + path[19:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".shadername","/Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[2:])
    
    filePaths = cmds.ls(type="RenderManEnvLightShape",l=True)
    for fp in filePaths:
        path = cmds.getAttr(fp+".rman__EnvMap")
        if OSTYPE == "//Server-3d/Project":
            if path.lower()[:18] == "/Server-3d/Project":
                cmds.setAttr(fp+".rman__EnvMap","//Server-3d/Project" + path[18:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[14:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".rman__EnvMap","//Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("//Server-3d/Project" + path[2:])
        elif OSTYPE == "/Server-3d/Project":
            if path.lower()[:19] == "//server-3d/project":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[19:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[19:])
            if path.lower()[:2] == "p:":
                cmds.setAttr(fp+".rman__EnvMap","/Server-3d/Project" + path[2:],type="string")
                #print "File was changed %s" % ("/Server-3d/Project" + path[2:])   
				
#id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterOpen, resolfImageFilePath)
#id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterImport, resolfImageFilePath)
#id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kAfterReference, resolfImageFilePath)
'''
def SobakiSwitcher(clientData):
    OSTYPE = sys.platform
    if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
    else:
        OSTYPE="/mnt/server-3d"
    sceneName = cmds.optionVar(query="RecentFilesList")[-1]
    print("\n\nSobakiSwitcher: "+sceneName+"\n\n")
    rezMatch = re.match(".*SOBAKI.*",sceneName)
    if rezMatch:
        chekProject.setMayaProject(OSTYPE+"/SOBAKI")
				
id = OpenMaya.MSceneMessage.addCallback(OpenMaya.MSceneMessage.kBeforeOpen, SobakiSwitcher)				
'''
