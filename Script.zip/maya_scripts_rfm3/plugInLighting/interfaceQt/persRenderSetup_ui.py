#QT Interface makeCube script for Maya
#Written by Tim Callaway
from PyQt4 import QtGui, QtCore, uic
from pymel.core import *
import pymel.core as pm
import maya.mel as mel

## from cleanup  file
import maya.cmds as cmds
import maya.mel as mel
import re
import linecache
import sys
import advslim
import init_slim
import main
import ml_reference
import maya.OpenMaya as om
import os
import glob
#
import cleanup
reload( cleanup )

# Path to the designer UI file
ui_filename = '//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/interfaceQt/persRenderSetup_ui.ui'
form_class, base_class = uic.loadUiType(ui_filename)

# Interface Class
class mainWindowSetupPers(base_class, form_class):
        def __init__(self):
                super(base_class, self).__init__()
                self.setupUi(self)
                self.setObjectName('mainWindowSetupPers')
                self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)
                self.setDockNestingEnabled(True)
                self.connectInterface()

        def connectInterface(self):
                QtCore.QObject.connect(self.createRenderVertionButton, QtCore.SIGNAL("clicked()"),self.createRenderVertionButtonWin)
                QtCore.QObject.connect(self.cleanupPalleteButton, QtCore.SIGNAL("clicked()"),self.cleanupPalleteButtonWin)
                QtCore.QObject.connect(self.cleanupMaterialButton, QtCore.SIGNAL("clicked()"),self.cleanupMaterialButtonWin)
                QtCore.QObject.connect(self.deletePalleteButton, QtCore.SIGNAL("clicked()"),self.deletePalleteButtonWin)
                QtCore.QObject.connect(self.deleteMaterialButton, QtCore.SIGNAL("clicked()"),self.deleteMaterialButtonWin)
                QtCore.QObject.connect(self.openSlimButton, QtCore.SIGNAL("clicked()"),self.openSlimButtonWin)
                
                QtCore.QObject.connect(self.strClearningButton, QtCore.SIGNAL("clicked()"),self.strClearningButtonWin)
                QtCore.QObject.connect(self.MakeUniqButton, QtCore.SIGNAL("clicked()"),self.MakeUniqButtonWin)
                                
                QtCore.QObject.connect(self.cancelButton, QtCore.SIGNAL("clicked()"),self.cancelButtonWin)
                
                
        def createRenderVertionButtonWin(self):
            mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdSoldatHideUnUse.mel";sdSoldatHideUnUse();');
            
        def MakeUniqButtonWin(self):
            import rfm.slim
            slim=rfm.slim.GetSlim()
            palettes = slim.Cmd('slim GetPalettes').split(' ')
            for palette in palettes:
                mappings = str(slim.Cmd('{plth} UniqueifyAll -returnmappings'.format(plth=palette)))
                slim.RemapBindings(mappings)
            
             
        def cleanupPalleteButtonWin(self):
            #remove material
            ## query - True - print result
            ## query - False -  delete find unUseMaterials
            debug = True
            print cleanup.checkUnusedSlimShaders( query=True, debug=debug );
            
        def cleanupMaterialButtonWin(self):
            #remove pallete 
            ## query - True - print result
            ## query - False - delete find unUsePallete 
            debug = True
            print cleanup.checkUnusedSlimMaterials( query=True, debug=debug );
            
            
        def deletePalleteButtonWin(self):
            debug = True
            cleanup.checkUnusedSlimShaders( query=False, debug=debug );
            print "END shader cleanup";
                   
        def deleteMaterialButtonWin(self):
            debug = True
            cleanup.checkUnusedSlimMaterials( query=False, debug=debug );
            print "END palette cleanup";
        
        def openSlimButtonWin(self):
            if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
	            import rfm.slim
            if cmds.about(b=True): 
		        mel.eval("rman slim start -gui 0 -edit 0")
            if not rfm.slim.GetSlim().Running():
                rfm.slim.GetSlim().Start()
            rfm.slim.GetSlim()

        def strClearningButtonWin(self):
            cmd = "python(\"import sys;print sys.path;sys.path.append('//Server-3d/Project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/preset');print sys.path;import batchCleanupSoldat;\");";
            print cmd;
            
        def cancelButtonWin(self):
		    print 'close!'
		    self.close()
   
                
                
def main():
        global ui
        ui=mainWindowSetupPers()
        ui.show()

if __name__ == "__main__":
        main()
