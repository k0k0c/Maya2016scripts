#QT Interface makeCube script for Maya
#Written by Tim Callaway
from PyQt4 import QtGui, QtCore, uic
from pymel.core import *
import pymel.core as pm
import maya.mel as mel

# Path to the designer UI file
ui_filename = '//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/interfaceQt/soldiersExport.ui'
form_class, base_class = uic.loadUiType(ui_filename)

# Interface Class
class exportCache(base_class, form_class):
        def __init__(self):
                super(base_class, self).__init__()
                self.setupUi(self)
                self.setObjectName('exportCache')
                self.setDockNestingEnabled(True)
                self.connectInterface()

        def connectInterface(self):
                QtCore.QObject.connect(self.hideUnUseSoldatButton, QtCore.SIGNAL("clicked()"),self.hideUnUseSoldatWin)
'''             QtCore.QObject.connect(self.createLocalCatchDirButton, QtCore.SIGNAL("clicked()"),self.createLocalCatchDirButtonWin)
                QtCore.QObject.connect(self.saveAnimSoldatButton, QtCore.SIGNAL("clicked()"),self.saveAnimSoldatButtonWin)
                QtCore.QObject.connect(self.getSodierTypeButton, QtCore.SIGNAL("clicked()"),self.getSodierTypeButtonWin)
                QtCore.QObject.connect(self.setFarClipCameraOneButton, QtCore.SIGNAL("clicked()"),self.setFarClipCameraOneButtonWin)
                QtCore.QObject.connect(self.setFarClipCamera1000Button, QtCore.SIGNAL("clicked()"),self.setFarClipCameraOneButtonWin)
'''
        def hideUnUseSoldatWin(self):
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdSoldatHideUnUse.mel";')
                mel.eval('sdSoldatHideUnUse();')
'''        
        def saveAnimSoldatButtonWin(self):
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdSaveSelectionAllAnimSoldat.mel";')
                mel.eval('sdSaveSeltioecnAllAnimSoldat();')

        def saveAnimSoldatButtonWin(self):
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdTypeSelectedSoldat.mel";')
                mel.eval('sdTypeSelectedSoldat();')
                
        def setFarClipOneCameraOneButtonWin(self):
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdTypeSelectedSoldat.mel";')
                mel.eval('sdSetFarClipToOne()')
                
        def setFarClipOneCameraOneButtonWin(self):
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdTypeSelectedSoldat.mel";')
                mel.eval('sdSetFarClipToThousand()')
        
         def createLocalCatchDirButtonWin(self):    
                mel.eval('source "//server-3d/project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/sdCreateLocalCacheDir.mel";')
'''                
        
                
                
def main():
        global ui
        ui=exportCache()
        ui.show()

if __name__ == "__main__":
        main()
