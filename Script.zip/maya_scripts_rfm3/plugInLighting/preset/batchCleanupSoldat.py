import sys;
import maya.mel as mel;
#QT Interface makeCube script for Maya
#Written by Tim Callaway
#from PyQt4 import QtGui, QtCore, uic
#from pymel.core import *
#import pymel.core as pm
import maya.mel as mel

## from cleanup  file
import maya.cmds as cmds
import maya.mel as mel
#import re
#import linecache
import sys
#import advslim
#import init_slim
#import main
#import ml_reference
import maya.OpenMaya as om
import os
#import glob

import cleanup
reload( cleanup )

debug = True
sys.path.append('//Server-3d/Project/lib/setup/maya/maya_scripts_rfm3/plugInLighting/preset/');
#if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
#	import rfm.slim
#if cmds.about(b=True): 
#    mel.eval("rman slim start -gui 0 -edit 0")
#if not rfm.slim.GetSlim().Running():
#    rfm.slim.GetSlim().Start()
import rfm.slim
rfm.slim.GetSlim()
print "GetSlim "
cleanup.checkUnusedSlimShaders( query=False, debug=debug );
print "checkUnusedSlimShaders "
cleanup.checkUnusedSlimMaterials( query=False, debug=debug );
print "checkUnusedSlimMaterials "
cleanup.checkUnusedSlimShaders( query=False, debug=debug );
print "checkUnusedSlimShaders "
import rfm.slim
slim=rfm.slim.GetSlim()
print slim
palettes = slim.Cmd('slim GetPalettes').split(' ')
print palettes
if palettes  != "" :
    for palette in palettes:
        mappings = str(slim.Cmd('{plth} UniqueifyAll -returnmappings'.format(plth=palette)))
        slim.RemapBindings(mappings)
print "uniqueifyAll"
cmds.file( save=True, type='mayaAscii' )