import pymel.core as pm
import maya.cmds as cmds
import maya.mel as mel

# Controls to exlude from auto parent constraints
CTRLS_EXLUDED = (u"general_CT", u"pivotOffset_CT", u"switch_CT",)
CTRLS_POSTFIX = "CT"

# Directories to load poses and characters
PROJECT_DIR = "//server-3d/Project/UrfinJuse"
STARTING_POSE_DIR = PROJECT_DIR + "/lib/pose"
CHARS_DIR = PROJECT_DIR + "/assets/chars"
OBJECTS_TO_HIDE = [u"faceRig_grp", u"pivotOffset_CT"] # objects to hide after load

# Animation curves filter settings
TIMECHANGE_TOLERANCE = 3
ANGLE_TOLERANCE = 80


class WindowColumnLayout(object):
    btn = {}

    def __init__(self, window_title):
        self.win = pm.window(title=window_title)
        self.layout = pm.columnLayout(cat=('left', 5), rs=5)
        pm.separator(hr=True, h=4, p=self.layout)

    def create_button(self, label, cmd):
        self.btn[cmd] = pm.button(label=label, parent=self.layout)
        self.btn[cmd].setCommand(cmd)
        pm.separator(hr=True, h=4, p=self.layout)

    def create_window(self):
        self.win.show()


class SingleTon(object):
    instance = None

    def __new__(cls):
        if cls.instance is None:
            cls.instance = super(SingleTon, cls).__new__(cls)
        return cls.instance


class SmartBakeUtils(SingleTon):
    translates = (u"translateX", u"translateY", u"translateZ")
    rotates = (u'rotateX', u'rotateY', u'rotateZ')
    axes = (u"x", u"y", u"z")

    blend_channel = None
    blend_curve = None
    namespaces = []
    ctrl_names = []

    def append_attrs(self, iterable, a, attrs):
        for i, t in enumerate(iterable):
            a == t and attrs.append(self.axes[i])

    def get_locked_attrs(self, object_name):
        attrs = pm.listAttr(object_name, l=True)
        st = []
        sr = []
        for a in attrs:
            self.append_attrs(self.translates, a, st)
            self.append_attrs(self.rotates, a, sr)
        return st, sr

    def connect_blend_curve(self):
        ns = self.namespaces
        currentf = pm.currentTime(q=True)

        for i, n in enumerate(self.ctrl_names):
            o = pm.ls(ns[1]+n)
            if o and u'blendParent1' in pm.attributeInfo(ns[1]+n, w=True):
                index = i
                pm.setKeyframe( ns[1]+n, attribute='blendParent1', t=currentf, v=0 )
                pm.setKeyframe( ns[1]+n, attribute='blendParent1', t=currentf+1, v=1 )
                self.blend_channel = ns[1] + n + '.blendParent1'
                break

        if index is not None:
            self.blend_curve = pm.connectionInfo(ns[1] + self.ctrl_names[index]+'.blendParent1', 
                                                 sfd=True)
            for n in self.ctrl_names:
                o = pm.ls(ns[1]+n)
                if (o and n != self.ctrl_names[index] and 
                    u'blendParent1' in pm.attributeInfo(ns[1]+n, all=True)):
                    pm.connectAttr(self.blend_curve, ns[1]+n+'.blendParent1')

            #for n in self.constr_parents:
             #   pm.connectAttr(self.blend_curve, ns[1] + n + '_tempCtr.' + n + 'W0')

    def set_constraints(self):
        ns = self.namespaces
        index = None
        if ns[0]: # check if object is in a namespace (not global)
            controllers_fs = pm.ls(ns[0] + "*" + CTRLS_POSTFIX)

        ctrl_names = []
        for c in controllers_fs:
            n = c.__unicode__().split(':')[-1]
            n in CTRLS_EXLUDED or ctrl_names.append(n)

        self.ctrl_names = ctrl_names
        for n in ctrl_names:
            o = pm.ls(ns[1]+n)
            if o:
                u_attrs = pm.listAttr(o, u=True)
                u_t_attrs = list(set(u_attrs) & set(self.translates + self.rotates))
                for a in u_t_attrs:
                    pm.keyframe(ns[1]+n, q=True, at=a) or pm.setKeyframe(o, at=a, t=1)
                st, sr = self.get_locked_attrs(ns[1]+n)
                if len(st) != 3 and len(sr) != 3:
                    pm.parentConstraint(ns[0]+n, ns[1]+n, n=ns[1]+n+"_tempCtr", st=st, sr=sr)

        self.connect_blend_curve()

        return True

    def bake_animation(self):
        ns = self.namespaces
        startf = pm.playbackOptions(q=True, ast=True)
        finishf = pm.playbackOptions(q=True, aet=True)
        currentf = pm.currentTime(q=True)

        ctrls_str = ''
        for i, c in enumerate(self.ctrl_names):
            ctrls_str += '"'
            ctrls_str += ns[1] + c
            ctrls_str += '"'
            if i < len(self.ctrl_names)-1:
                ctrls_str += ', '

        mel_str = 'bakeResults -simulation false -t "%i:%i" -smart 1' % (startf, finishf)
        mel_str += ' -disableImplicitControl true -preserveOutsideKeys true' 
        mel_str += ' -sparseAnimCurveBake false -removeBakedAttributeFromLayer' 
        mel_str += ' false -bakeOnOverrideLayer false -minimizeRotation false' 
        mel_str += ' -controlPoints false -shape false {' 

        mel_final_str = mel_str + ctrls_str + '};'

        pm.currentTime(startf)
        mel.eval(mel_final_str)
        self.cmd_remove_constraints()
        pm.currentTime(currentf)
        pm.hide(ns[0] + 'root')
        return True

    def cmd_remove_constraints(self, *args):
        try:
            pm.delete(self.namespaces[1]+"*tempCtr")
        except pm.MayaNodeError:
            pass
   
        try:
            pm.delete(self.blend_curve.rsplit(".", 1)[0])
        except pm.MayaNodeError:
            pass
        if self.blend_curve is not None: self.blend_curve = None
        if self.blend_channel is not None: self.blend_channel = None
    
    def cmd_apply_constraints(self, *args):
        selected_objects = pm.ls(os=True);
        map(lambda o: self.namespaces.append(o.namespace()), selected_objects)
        if len(self.namespaces) >= 2:
            self.set_constraints()
        else:
            pm.displayError("Not enough namespaces selected")

    def cmd_select_blend_curve(self, *args):
        if self.blend_channel is not None:
            pm.select(self.blend_channel)
        else:
            pm.displayError("There's no a blend curve in a scene")

    def cmd_smart_bake(self, *args):
        if self.ctrl_names != []:
            self.bake_animation()
        else:
            pm.displayError("There're no constrained controls to bake")

    def cmd_filter_curves(self, *args):
        ns = self.namespaces
        ctrl_names = self.ctrl_names

        for n in ctrl_names:
            attrs = pm.listAttr(ns[1]+n, u=True)
            u_attrs = []
            for a in attrs:
                if a in self.translates or a in self.rotates:
                    u_attrs.append(a)
            for a in u_attrs:
                kc = pm.keyframe(ns[1]+n, attribute=a, query=True, keyframeCount=True)
                for i in xrange(kc):
                    tc = pm.keyframe(ns[1]+n, query=True, index=[i], attribute=a, tc=True)
                    if len(tc) >= 2 and i < kc-1:
                        tc = tc[1] - tc[0]
                        outAngle = pm.keyTangent(ns[1]+n, query=True, index=[i], attribute=a, outAngle=True )
                        inAngle = pm.keyTangent(ns[1]+n, query=True, index=[i+1], attribute=a, inAngle=True )
                        if (outAngle > TIMECHANGE_TOLERANCE or
                            outAngle < -TIMECHANGE_TOLERANCE and
                            tc < TIMECHANGE_TOLERANCE):
                            pm.keyTangent(ns[1]+n, edit=True, index=[i], ott="plateau")
                        if (inAngle > TIMECHANGE_TOLERANCE or
                            inAngle < -TIMECHANGE_TOLERANCE and
                            tc < TIMECHANGE_TOLERANCE):
                            pm.keyTangent(ns[1]+n, edit=True, index=[i+1], itt="plateau")


class OpenPose(SingleTon):
    char_category = ""
    char_pose = ""

    def open_character(self, char_ns):
        char_name = char_ns.split("_", 1)[0]
        cmds.file(CHARS_DIR + "/" + char_name.capitalize() + "/maya/" + char_ns + ".mb",
                  type="mayaBinary", 
                  namespace=char_ns, 
                  r=True, 
                  gl=True, 
                  mergeNamespacesOnClash=False, 
                  options="v=0;")

        map(lambda o: pm.hide(char_ns + ":" + o), OBJECTS_TO_HIDE)

        mel.eval('poseLib;')
        mel.eval('$poseLibBasePath = "' + STARTING_POSE_DIR + '";')
        mel.eval('poseLibSavePrefs;')
        mel.eval('poseLib;')
        mel.eval('optionMenu -e -v "' + char_name + '" "characterChoiceOM";')
        mel.eval('poseLibRefreshPoseList "' + self.char_category + '";')
        mel.eval('poseLibDoApplyPose "' + self.char_pose + '" 0;')
        

    def cmd_open_character(self, *args):
        file_path_maya_dial = cmds.fileDialog2(fm=1, ff="Preview Files (*.bmp)", dir=STARTING_POSE_DIR)
        file_path_pose_f = file_path_maya_dial[0].rsplit(".", 1)[0] or None
        self.char_pose = file_path_pose_f.rsplit("/", 1)[1] or None 
        self.char_category = file_path_maya_dial[0].rsplit("/", 2)[1] or None

        try:
            with open(file_path_pose_f, 'r') as f:
                char_ns = None
                for line in f:
                    if ":" in line:
                        char_ns = line.split(":", 1)[0]
                        break
                char_ns != None and self.open_character(char_ns)     
        except EnvironmentError:
            pm.displayError("Corresponding poseLib file can't be opened")


def create_GUI():
    w_layout = WindowColumnLayout("Anim Util")
    w_layout.create_button("Open Character Pose", OpenPose().cmd_open_character)
    w_layout.create_button("Apply Constraints", SmartBakeUtils().cmd_apply_constraints)
    w_layout.create_button("Select Blend Curve", SmartBakeUtils().cmd_select_blend_curve)
    w_layout.create_button("Remove Constraints", SmartBakeUtils().cmd_remove_constraints)
    w_layout.create_button("Bake Animation", SmartBakeUtils().cmd_smart_bake)
    w_layout.create_button("Filter Curves", SmartBakeUtils().cmd_filter_curves)
    w_layout.create_window()


# create_GUI()