import site
import sys
OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
        site.addsitedir(OSTYPE+'/lib/soft/Python26/Lib/site-packages')

        import sys, os
        sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')

        import re
        #from PyQt4 import QtCore, QtGui
        from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
        import socket
        import MySQLdb as mb
        import sip
        import maya.cmds as cmds
        import maya.OpenMayaUI as apiUI

        import melnik_setup
        import ClientServer

else:
        OSTYPE="/Server-3d/Project"

