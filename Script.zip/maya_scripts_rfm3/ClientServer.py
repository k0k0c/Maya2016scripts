import site
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')
import sys, os
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm3')
import melnik_setup
from PyQt4 import QtCore, QtGui, QtNetwork
import maya.mel as mel

#sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm4')
#import chekProject

class ClientServer(QtGui.QDialog):
    def __init__(self, parent=None):
        super(ClientServer, self).__init__(parent)
        self.message=QtCore.QString()
        #self.tcpServer = QtNetwork.QTcpServer(self)
        #self.tcpServer.listen()
        self.ServerConnectedCount = 0
        self.blockSize = 0
		
        self.tcpSocket = QtNetwork.QTcpSocket(self)
        self.tcpSocket.connected.connect(self.slotConnected)
        self.tcpSocket.disconnected.connect(self.slotDisconnected)
        self.tcpSocket.readyRead.connect(self.readMessage)
        self.startClient()

    def slotConnected(self):
        saveVerion = mel.eval("getApplicationVersionAsFloat")
        aboutVar = mel.eval("about -b")
        #if saveVerion==2013 and not aboutVar:
        #    mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm4/for2013/FileMenu.mel\"");
        #    mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm4/for2013/performNewScene.mel\"");
        #    mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm4/for2013/performFileAction.mel\"");
        
        #chekProject.chekProject()
        #mel.eval("setRmanVars()")
        print("Slot connected!!!")
        
    def slotDisconnected(self):        
        print("Slot disconnected!!!")
        melnik_setup.userId = -1
        self.startClient()
    	
    def startClient(self):
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.updateTimer)
        self.timer.start(2500)
        #self.tcpSocket.connectToHost("localhost", 55222)
		
    def updateTimer(self):
        self.ServerConnectedCount+=1
        gf = self.tcpSocket.state()
        if gf == 3:
            self.timer.stop()
            self.ServerConnectedCount = 0
        elif gf < 2:
            #print("Start Connecting...")
            self.tcpSocket.connectToHost("localhost", 55222)
        #if self.ServerConnectedCount == 1000:
        #    self.timer.stop()
        #    self.ServerConnectedCount=0
        #    print("Error connection number!!!")
		
    def readMessage(self):
        print("Read message...")
        instr = QtCore.QDataStream(self.tcpSocket)
        instr.setVersion(QtCore.QDataStream.Qt_4_7)
        while(True):
            if self.blockSize == 0:
            	if self.tcpSocket.bytesAvailable() < 2:
            		break
            	self.blockSize = instr.readUInt16()
            if self.tcpSocket.bytesAvailable() < self.blockSize:
            	break
            self.message = instr.readQString()
            self.blockSize = 0
            self.process()

    def process(self):
        print("process: "+self.message)        
        rezString=self.message.split("::")
        if rezString[0] == "USER":
            if rezString[1] == "LOGOUT":
                melnik_setup.userId = -1
            else:
                tak=-1
                if rezString[3] != "" or rezString[3] != "-1":
                    tak = rezString[3]
                melnik_setup.userId = tak
                melnik_setup.updateScene()
        if rezString[0] == "EXEC":
            sssssss = str(rezString[1])
            exec(sssssss)
        if rezString[0] == "CHEKLIST":
			pass
            #melnik_setup.mOd.setResourceLabel(self.message)
        if rezString[0] == "UPDATESCENE":
            melnik_setup.updateSceneBL()
            
    def sendMessage(self, message):
        print("Send message: "+message)
        block = QtCore.QByteArray()
        out = QtCore.QDataStream(block, QtCore.QIODevice.WriteOnly)
        out.setVersion(QtCore.QDataStream.Qt_4_7)
        out.writeUInt16(0)
        out.writeQString(message)
        out.device().seek(0)
        out.writeUInt16(block.size() - 2)
        if self.tcpSocket.state() ==3:
            self.tcpSocket.write(block)

clSr = ClientServer()
