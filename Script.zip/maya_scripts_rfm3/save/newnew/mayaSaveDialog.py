import site
site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm3')
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class listDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,60)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2
            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Multiply)
        gradient2 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height())
        gradient2.setColorAt(0,QtGui.QColor(255,255,255))
        gradient2.setColorAt(1,QtGui.QColor(200,200,200))
        brush2 = QtGui.QBrush(gradient2)
        painter.fillRect(option.rect,brush2)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
        gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
        gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
        brush3 = QtGui.QBrush(gradient3)
        painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
    
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
    
        gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
        gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
        brush4 = QtGui.QBrush(gradient4)
        painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        #painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
    
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
    
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
    
        text = index.data(QtCore.Qt.DisplayRole).toString()
        newText = painter.fontMetrics().elidedText(text, QtCore.Qt.ElideRight, option.rect.width())
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), newText)
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
#app = QtGui.qApp
class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.conn = mb.connect(host="192.168.0.7",user="root",passwd="12345",port=3306,db = "mel", use_unicode=True)
        self.conn.set_character_set("utf8")
        self.cursor = self.conn.cursor()

        self.mainLayout = QtGui.QVBoxLayout()
        self.groupBoxFind = QtGui.QGroupBox(" Find asset ")
        self.LayoutFindMain = QtGui.QVBoxLayout()
        self.LayoutFind = QtGui.QGridLayout()
        self.groupBoxFind.setLayout(self.LayoutFindMain)
        self.lastSelectedAssetId=-1
        
        self.oneLabel = QtGui.QLabel("Project: ")
        self.oneLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.cursor.execute("select id, name from projects")
        row = self.cursor.fetchall()
        self.conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()
        self.LayoutFind.addWidget(self.oneLabel, 0, 0)
        self.LayoutFind.addWidget(self.oneCombobox, 0, 1)

        self.selectedAssetPath = ""
        self.fourLabel = QtGui.QLabel("Type: ")
        self.fourLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fourCombobox = QtGui.QComboBox()
        self.fourQlistNames = QtCore.QStringList()
        self.fourQlistNames.append("All")
        self.fourQlistNames.append("chars")        
        self.fourQlistNames.append("proxy")        
        self.fourQlistNames.append("props")        
        self.fourQlistNames.append("sets")
        self.fourQlistNames.append("scene")
        self.fourQlistNames.append("dynamic")
        
        self.fourCombobox.addItems(self.fourQlistNames)
        self.LayoutFind.addWidget(self.fourLabel, 0, 2)
        self.LayoutFind.addWidget(self.fourCombobox, 0, 3)
        
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.LayoutFindMain.addLayout(self.LayoutFind)
        self.LayoutFindMain.addLayout(self.twoLayout)        
        
        self.groupBox = QtGui.QGroupBox(" Save ")
        self.HBLayout = QtGui.QVBoxLayout()
        self.groupBox.setLayout(self.HBLayout)
    
        self.groupBoxNV = QtGui.QGroupBox(" Name of asset")
        self.gridLayoutNV = QtGui.QGridLayout()
        self.groupBoxNV.setLayout(self.gridLayoutNV)
        self.HBLayout.addWidget(self.groupBoxNV,0)
        
        self.LabelNV = QtGui.QLabel("Asset: ")
        self.ComboboxNV = QtGui.QComboBox()        
        self.ComboboxNV.setSizePolicy(QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Preferred)
        self.LabelNV2 = QtGui.QLabel("Dop name: ")
        self.LineEditNV = QtGui.QLineEdit()     
        
        #self.ComboboxNV.setEditable(True)
        #self.ComboboxNV.lineEdit().connect(self.ComboboxNV.lineEdit(), QtCore.SIGNAL("editingFinished()"), self.editTextChangedName)
        self.gridLayoutNV.addWidget(self.LabelNV, 0, 0)
        self.gridLayoutNV.addWidget(self.ComboboxNV, 0, 1)
        self.gridLayoutNV.addWidget(self.LabelNV2, 0, 2)
        self.gridLayoutNV.addWidget(self.LineEditNV, 0, 3)        
        
        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("clicked(const QModelIndex &)"), self.activeTreeCellCliked)        
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        #self.delegate = SpinBoxDelegate()
        #self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        self.qwsa = QtGui.QWidget()
        self.qwsaLayout = QtGui.QVBoxLayout(self.qwsa)
        
        self.checkBoxLayout = QtGui.QHBoxLayout()
        self.checkOverride = QtGui.QCheckBox(" Override current version of file")
        self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        self.checkOverride.connect(self.checkOverride, QtCore.SIGNAL("stateChanged(int)"), self.changeOvveride)                
        self.checkBoxLayout.addWidget(self.checkOverride)
        self.saveReff = QtGui.QCheckBox(" Replace root file")
        self.saveReff.setCheckState(QtCore.Qt.Checked)
        self.checkBoxLayout.addWidget(self.saveReff)
        self.qwsaLayout.addLayout(self.checkBoxLayout)              
        
        self.labelNote = QtGui.QLabel("Note:")
        self.textEditNote = QtGui.QTextEdit("")
        self.qwsaLayout.addWidget(self.labelNote)              
        self.qwsaLayout.addWidget(self.textEditNote)   
        
        self.splitter = QtGui.QSplitter(self)
        self.splitter.setFrameStyle(QtGui.QFrame.NoFrame or QtGui.QFrame.Sunken)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.addWidget(self.treeView)        
        self.splitter.addWidget(self.qwsa)
        self.HBLayout.addWidget(self.splitter,1)
       
        print "USERR:"+str(melnik_setup.userId)
       
        self.okButt = QtGui.QPushButton("Save")
        self.okButt.released.connect(self.saveFile)
        self.okButt.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.HBLayout.addWidget(self.okButt,0,QtCore.Qt.AlignRight)
        
        self.connect(self, QtCore.SIGNAL("accepted()"), self.acceptedSig)
        
        self.mainLayout.addWidget(self.groupBoxFind,0)
        self.mainLayout.addWidget(self.groupBox,1)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')
        self.readSettings()                    
        self.findText()
        self.readSettings()
        if self.initVariables() != 1:
            self.findText()
        item = self.treeModel.invisibleRootItem().child(0,0)            
        if item is not None:
            print "ITEM: " + item.data(QtCore.Qt.DisplayRole).toString()
            #item.setCheckState(QtCore.Qt.Checked)            
            self.activeTreeCellCliked(self.treeModel.indexFromItem(item))    #MOZHNO ILI TAK ILI TAK
        #if self.initVariables() != 1:
        #    self.readSettings()                    
        #    self.findText()
        
    def acceptedSig(self):
            self.writeSettings()

    def closeEvent(self, event):
            self.writeSettings()
            event.accept()

    def changeOvveride(self, nuzh):
        if nuzh == 2:
            self.treeView.setEnabled(False)
        else:
            self.treeView.setEnabled(True)
            
    def saveFile(self):
        parentItem = self.treeModel.invisibleRootItem()
        self.listPath = []
        self.buildTree(parentItem)
        self.buildSaveFiles()
        if len(self.fileAssetPath)==0:
            QtGui.QMessageBox.warning(self, "Warning", "Vydelite faily", QtGui.QMessageBox.Ok)
            return 0            
        #if self.textEditNote.toPlainText() == "" and self.checkOverride.checkState() != QtCore.Qt.Checked:
        #    QtGui.QMessageBox.warning(self, "Warning", "Zapolnite NOTE", QtGui.QMessageBox.Ok)
        #    return 0
            
        myString = QtCore.QString()
        for i in range(len(self.fileAssetPath)):        
                myString+=self.filePath[i]+"\n"
                if self.saveReff.checkState() == QtCore.Qt.Checked:
                    myString+=self.fileAssetPath[i]+"\n"
        
        msgBox=QtGui.QMessageBox()
        msgBox.setText("Do you want to save your changes?")
        msgBox.setInformativeText(myString)
        msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Cancel)
        msgBox.setDefaultButton(QtGui.QMessageBox.Save)
        ret = msgBox.exec_()

        if ret != QtGui.QMessageBox.Cancel:            
            for i in range(len(self.fileAssetPath)):
                print "filePath: "+self.filePath[i]
                print "fileAssetPath: "+self.fileAssetPath[i]
                print "fileAssetTag: "+self.fileAssetTag[i]
                print "findName: "+self.findName
                print "fileAssetId: "+str(self.fileAssetId)
                
                self.userId = melnik_setup.userId
                print "USERR:"+str(self.userId)
                if self.userId==-1:
                    QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Net takogo polzovatelya")
                    return 0            
                if self.filePath[i]==self.fileAssetPath[i]:
                    QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Nelzya perezapisat asset")
                    return 0                            
                
                if self.textEditNote.toPlainText() == "" and self.checkOverride.checkState() == QtCore.Qt.Checked:    
                    print "ZAHLI0"
                    self.cursor.execute("select id from edits where path like %s order by date desc",(self.filePath[i],))
                    row = self.cursor.fetchall()
                    self.conn.commit()
                    if len(row) != 0:
                        editsId = row[0][0]
                        print "ZAHLI: UPDATE edits SET date = now() where id="+str(editsId)
                        self.cursor.execute("UPDATE edits SET date = now() where id=%s",(editsId,))
                        self.conn.commit()
                elif self.textEditNote.toPlainText() == "":
                    pass
                else:
                    self.cursor.execute("select id from data where path like %s",(self.fileAssetPath[i],))
                    row = self.cursor.fetchall()
                    self.conn.commit()
                    dataId=-1
                    if len(row) != 0:
                        dataId = row[0][0]
                    elif len(row) == 0:
                        print("Netu daty, sozdaem...")
                        sss1=self.fileAssetPath[i].split("/")
                        categoryesss=""
                        nayden=0
                        for s in range(len(sss1)):
                            if sss1[s]=="maya":
                                nayden=1
                            if nayden and s==(len(sss1)-2):
                                categoryesss=categoryesss+sss1[s]
                            elif nayden and s<(len(sss1)-1):
                                categoryesss=categoryesss+sss1[s]+"/"
                        self.cursor.execute("select id from dcategories where name like %s",(categoryesss,))
                        row = self.cursor.fetchall()
                        if len(row)==0:
                            self.cursor.execute("INSERT INTO dcategories VALUES(null,%s,null)",(categoryesss,))                
                            categoryesss=self.conn.insert_id()
                            self.conn.commit()
                        else:
                            categoryesss = row[0][0]
                        self.cursor.execute("INSERT INTO data VALUES(NULL,%s,%s,1,4,now())",(self.findName+self.fileAssetTag[i],self.fileAssetPath[i],))
                        dataId=self.conn.insert_id()
                        print("dataId: "+str(dataId))
                        if self.fileAssetId != 0:
                            self.cursor.execute("INSERT INTO assets_has_data VALUES(%s,%s,%s,1)",(self.fileAssetId,dataId,categoryesss))
                        else:
                            print "PUT K PAPE NE NAIDEN!!!"
                        self.cursor.execute("INSERT INTO data_has_projects VALUES(%s,%s)",(dataId,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))
                        self.cursor.execute("INSERT INTO data_has_people VALUES(%s,%s)",(dataId,self.userId,))
                        self.conn.commit()


                    self.cursor.execute("INSERT INTO edits VALUES(NULL,now(),%s,%s)",(self.textEditNote.toPlainText().toUtf8(),self.filePath[i],))
                    editsId=self.conn.insert_id()   
                    self.cursor.execute("INSERT INTO edits_has_people VALUES(%s,%s)",(editsId,self.userId,))
                    self.cursor.execute("INSERT INTO data_has_edits VALUES(%s,%s)",(dataId,editsId,))
                    self.conn.commit()                
                
                
                extenshen="mayaBinary"
                
                chekProject.setMayaProject(self.selectedAssetPath)
                
                myqstri=QtCore.QString(self.filePath[i])
                myqstriList= myqstri.split("/")
                myqstriList.takeLast()
                myqstri=myqstriList.join("/")
                dir = QtCore.QDir()
                if not dir.exists(myqstri):
                    dir.mkpath(myqstri)
                
                if self.filePath[i].split(".")[1]=="ma": extenshen="mayaAscii"                
                mel.eval("file -rename \""+self.filePath[i]+"\"")
                mel.eval("file -f -save  -options \"v=0\" -type \""+extenshen+"\"")
                if self.filePath[i] != self.fileAssetPath[i]:
                    if self.saveReff.checkState() == QtCore.Qt.Checked:
                        fileRoot2 = QtCore.QFile(self.fileAssetPath[i])
                        if fileRoot2.exists():
                            print "remove file..."
                            fileRoot2.remove()
                        fileRoot = QtCore.QFile(self.filePath[i])                
                        fileRoot.copy(self.fileAssetPath[i]) 
            melnik_setup.updateScene()            
            #chekProject.chekProject()
            self.accept()                    
        
    def buildTree(self, root):
        i=0
        while i != -1:
            eeewPast = root.child(i,0)
            if eeewPast is None:
                break
            root1 = eeewPast.data(QtCore.Qt.UserRole+1).toString()
            root2 = eeewPast.data(QtCore.Qt.UserRole+2).toString()
            root5 = eeewPast.data(QtCore.Qt.CheckStateRole).toString()
            if root5 == "2":
                if root2 == "":
                    #print("buildTree2: "+root1)
                    self.listPath.append(root1)
                else:
                    #print("buildTree1: "+root1+"/"+root2+"/maya/")
                    self.listPath.append(root1+"/"+root2+"/maya/")
            self.buildTree(eeewPast)
            i = i + 1

    def findNameFile(self):
            sceneNameFile3=cmds.file(query=True, sn=True)        
            str2=sceneNameFile3.split(".")
            str4=str2[0].split("/")
            str3=re.split('_v[0-9]{1,4}(?=_|$)', str4[-1],re.I)
            str5=str3[0].split("_")
            rez=str5[0]
            if len(str5)>1:
            	for i in range(1,len(str5)-1):
            		rez = rez + "_" + str5[i]
            	if str4[-2] != str5[-1] and str4[-3] != str5[-1]:
            		rez = rez + "_" + str5[-1]
            return rez            		        
            		
    def buildSaveFiles(self):
        self.filePath = QtCore.QStringList()
        self.fileAssetPath = QtCore.QStringList()
        self.fileAssetTag = QtCore.QStringList()
        self.fileAssetId = self.ComboboxNV.itemData(self.ComboboxNV.currentIndex()).toString()
        self.findName = self.ComboboxNV.currentText()
        self.findName = str(self.findName[0].toLower()+self.findName.mid(1,-1))
        sceneNameFile2=""
        if self.checkOverride.checkState() == QtCore.Qt.Checked:         
            #self.activeTreeCellCliked(self.treeModel.invisibleRootItem().child(0,0).index())
            self.listPath=[]
            sceneNameFile2=cmds.file(query=True, sn=True)
            if sceneNameFile2=="":
                QtGui.QMessageBox.warning(self, "Warning", "Pustoy file pod temzhe imenem sohranit nelzya!", QtGui.QMessageBox.Ok)
                return
            rrezz = sceneNameFile2.split("/")
            rrezz2 = ""
            for i in range(len(rrezz)):
                if i == len(rrezz)-1 and (len(rrezz[i].split(".")) == 2 or rrezz[i]=="work"):
                    continue
                if i == len(rrezz)-2 and rrezz[i]=="work":
                    continue        
                rrezz2=rrezz2+rrezz[i]+"/"
            if rrezz2[-1]!="/":
                rrezz2 = rrezz2 + "/"
            print("rrezz2: "+rrezz2)
            self.listPath.append(rrezz2)
            self.findName = self.findNameFile()

        for strIn in self.listPath:
			print("buildSaveFiles: " + strIn)
			maxNumberFile=0
			dir = QtCore.QDir(strIn+"work")
			dir.setNameFilters("*.ma,*.mb".split(","))
			strList = dir.entryList()
			exetsion="mb"
			for sl in strList:
				m=re.search(self.findName+"_v(?P<first_name>[0-9]{1,4}).*.m[ab]$", sl,re.I)
				if m:
					if int(m.group('first_name')) > maxNumberFile:
						maxNumberFile=int(m.group('first_name'))
						exetsion=sl.split(".")[-1]
			strNext=str(maxNumberFile+1)
			print("Sledushiy nomer: "+strNext)
			for i in range(2):
				if len(strNext)<3:
					strNext="0"+strNext
				else:
					break
			addStr=""    
			pathi=strIn.split("/")
			print pathi
			if pathi[-1]!="" and len(pathi[-1].split("."))!=1 and pathi[-1]!="work" and pathi[-1]!="maya":
				addStr="_"+pathi[-1]
			elif pathi[-2]!="work":
				addStr="_"+pathi[-2]        
			elif pathi[-3]!="work":
				addStr="_"+pathi[-3]        
			if pathi[-3] == "chars" or pathi[-3] == "props" or pathi[-3] == "sets" or pathi[-2] == "chars" or pathi[-2] == "props" or pathi[-2] == "sets" or pathi[-1] == "maya" or pathi[-2] == "maya":
				addStr=""   				
			print("tag: "+addStr)
			newName=self.findName+"_v"+strNext+addStr+"."+exetsion
			newNameAs=self.findName+addStr+"."+exetsion
			self.fileAssetPath.append(strIn+newNameAs)
			if self.checkOverride.checkState() != QtCore.Qt.Checked:
				if self.LineEditNV.text() != "":
					sceneNameFile2 = strIn+"work/"+self.findName+"_v"+strNext+addStr+"_"+self.LineEditNV.text()+"."+exetsion
				else:
					sceneNameFile2 = strIn+"work/"+self.findName+"_v"+strNext+addStr+"."+exetsion
			else:
				rezPath="-1"
				rezPathParentName="-1"
				shaneParasha = str(strIn+newNameAs)
				shaneParashaRez1=shaneParasha.split("/")
				for s in range(len(shaneParashaRez1)):
					if shaneParashaRez1[s]=="chars" or shaneParashaRez1[s]=="props" or shaneParashaRez1[s]=="sets":
						rezPath = "/".join(shaneParashaRez1[0:s+1])
						rezPathParentName=shaneParashaRez1[s+1]
						break
						
				self.cursor.execute("select as1.id from assets as as1, assets as as2 where as1.path = %s and as1.name = %s and as1.parent=as2.id and as2.name = %s",(rezPath,self.findName,rezPathParentName,))
				row = self.cursor.fetchall()
				self.conn.commit()        
				if len(row) == 1:
					self.fileAssetId=row[0][0]                    
					print "PAPKA NASHELSYA!!!"+str(self.fileAssetId)
				else:
				    self.fileAssetId=0
			self.filePath.append(sceneNameFile2)
			self.fileAssetTag.append(addStr)

    def initVariables(self):
        strrr=""
        self.mayaSceneName = cmds.file(query=True, sceneName=True)
        #print self.mayaSceneName
        m = re.search(str(self.GlobalRootPath)+"(?P<first_name>.*)",self.mayaSceneName,re.I)
        if m is None:
            print "None"
        else:
            strrr = m.group("first_name")
            strProject=strrr.split("/")[0]
            projectIndex = self.qlistNames.indexOf(strProject)
            self.oneCombobox.setCurrentIndex(projectIndex)
            #print projectIndex
            m = re.search(strProject+"/assets/(?P<first_name>.*)",strrr,re.I)
            if m is None:
                print "None"
            else:    
                strrr=m.group("first_name")
                strTypes=strrr.split("/")[0]
                m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None"
                else:
                    strrr=m.group("first_name")
                    strrr=strrr.split("/")[0]
                    self.twoLineEdit.setText(strrr)
                    #print strrr
                    self.findText()
                    item = self.treeModel.invisibleRootItem().child(0,0)
                    self.treeView.expand(self.treeModel.indexFromItem(item))
                    return 1

    def clearTree(self, root):
        i=0
        while i != -1:
            eeewPast = root.child(i,0)
            if eeewPast is None:
                break
            eeewPast.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)
            self.clearTree(eeewPast)
            i = i + 1
            
    def activeTreeCellCliked(self, index):
        print "activeTreeCellCliked"        
        eeePastItem = self.treeModel.itemFromIndex(index)
        #print self.treeView.isExpanded(index)
        #print eeePastItem.hasChildren()
        if index.data(QtCore.Qt.CheckStateRole).toInt()[0] == 2:
            eeePastItem.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)
        else:
            eeePastItem.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)
        eeeNew = index
        eeePast = index
        while eeeNew.row() != -1:
            eeePast = eeeNew
            eeeNew = eeeNew.parent()
        self.selectedAssetId = eeePast.data(QtCore.Qt.UserRole).toString()
        self.selectedAssetPath = eeePast.data(QtCore.Qt.UserRole+1).toString() + "/" + eeePast.data(QtCore.Qt.DisplayRole).toString().simplified()
        print "activeTreeCellCliked selectedAssetPath:" + self.selectedAssetPath
        if self.lastSelectedAssetId != self.selectedAssetId:
            vrodeImya = self.findNameFile()
            print "vrodeImya:  "+ vrodeImya
            self.clearTree(self.treeModel.invisibleRootItem())
            eeePastItem = self.treeModel.itemFromIndex(index)
            eeePastItem.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)
            self.cursor.execute("select id, name from assets as ar where ar.parent=%s",(self.selectedAssetId,))
            row = self.cursor.fetchall()
            self.conn.commit()        
            self.ComboboxNV.clear()
            n=0        
            fo = QtGui.QFontMetrics(QtGui.QApplication.font());            
            maxWidth=0
            for x in row:
                #print "imena iz basy" + x[1]
                self.ComboboxNV.addItem(x[1])
                self.ComboboxNV.setItemData(n,x[0])
                if fo.width(x[1])>maxWidth:
                    maxWidth=fo.width(x[1])+20
                n=n+1
            
            self.ComboboxNV.view().setMinimumWidth(maxWidth);                
            vrodeImyaInt = self.ComboboxNV.findText(vrodeImya,QtCore.Qt.MatchFixedString)
            #print("vrodeImya: "+vrodeImya+" vrodeImyaInt: "+str(vrodeImyaInt))
            if vrodeImyaInt!=-1:
                self.ComboboxNV.setCurrentIndex(vrodeImyaInt)
            self.lastSelectedAssetId = self.selectedAssetId

    def requestNewFortune(self):
            self.itemOne.setData(QtCore.Qt.Unchecked, QtCore.Qt.CheckStateRole)                    
       
    def activeTreeCellExpanded(self, index):
        print "activeTreeCellExpanded"
        #print("expanded: "+index.child(0,0).data().toString())
        if index.parent().row() == -1:
            pal = QtGui.QApplication.palette()
            gradient = QtGui.QLinearGradient(0, 0, 0, 20)
            gradient.setColorAt(0.05, pal.base().color())
            gradient.setColorAt(0.051, pal.window().color())
            gradient.setColorAt(0.95, pal.window().color())
            gradient.setColorAt(0.951, pal.base().color())
            brush = QtGui.QBrush(gradient)
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            childItemToOpen="0"
            sceneNameFileToOpen=QtCore.QString(cmds.file(query=True, sn=True))
            item = self.treeModel.itemFromIndex(index)
            self.itemOne=item
            #QtCore.QTimer.singleShot(500, self.requestNewFortune)
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data(QtCore.Qt.UserRole+2).toString()+"/maya"
            while item.takeRow(0) != []:
                pass
                
            childItem = QtGui.QStandardItem("  anm")
            childItem.setData(rootPath+"/work/anm/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(0,childItem)
            if sceneNameFileToOpen.contains("/work/anm/"): childItemToOpen=childItem
            
            childItem = QtGui.QStandardItem("  dyn")
            childItem.setData(rootPath+"/work/dyn/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/dyn/"): childItemToOpen=childItem
                        
            childItem = QtGui.QStandardItem("  map")
            childItem.setData(rootPath+"/work/map/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/map/"): childItemToOpen=childItem
                        
            childItem = QtGui.QStandardItem("  shd")
            childItem.setData(rootPath+"/work/shd/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/shd/"): childItemToOpen=childItem
                        
            childItem = QtGui.QStandardItem("  tex")
            childItem.setData(rootPath+"/work/tex/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/tex/"): childItemToOpen=childItem
            
            childItem = QtGui.QStandardItem("  mod")
            childItem.setData(rootPath+"/work/mod/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/mod/"): 
                childItemToOpen=childItem                        
                self.treeView.expand(self.treeModel.indexFromItem(childItem))
            
            childchildItem = QtGui.QStandardItem("  geo")
            childchildItem.setData(rootPath+"/work/mod/geo/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/mod/geo/"): 
                print "est"
                childItemToOpen=childchildItem
                        
            childchildItem = QtGui.QStandardItem("  shape")
            childchildItem.setData(rootPath+"/work/mod/shape/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/mod/shape/"): childItemToOpen=childchildItem
                        
            childchildItem = QtGui.QStandardItem("  tpl")
            childchildItem.setData(rootPath+"/work/mod/tpl/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/mod/tpl/"): childItemToOpen=childchildItem
            
            childItem = QtGui.QStandardItem("  rig")
            childItem.setData(rootPath+"/work/rig/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            if sceneNameFileToOpen.contains("/work/rig/"): 
                childItemToOpen=childItem
                self.treeView.expand(self.treeModel.indexFromItem(childItem))                                    
                
            childchildItem = QtGui.QStandardItem("  face")
            childchildItem.setData(rootPath+"/work/rig/face/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/rig/face/"): childItemToOpen=childchildItem
                        
            childchildItem = QtGui.QStandardItem("  sceleton")
            childchildItem.setData(rootPath+"/work/rig/sceleton/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/rig/sceleton/"): childItemToOpen=childchildItem
                        
            childchildItem = QtGui.QStandardItem("  dev")
            childchildItem.setData(rootPath+"/work/rig/dev/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            if sceneNameFileToOpen.contains("/work/rig/dev/"): childItemToOpen=childchildItem
            
            if childItemToOpen != "0": 
                childItemToOpen.setData(QtCore.Qt.Checked, QtCore.Qt.CheckStateRole)                    
                self.activeTreeCellCliked(self.treeModel.indexFromItem(childItemToOpen))
            
    def findText(self):   
        fingTextLine = self.twoLineEdit.text()
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        
        pal = QtGui.QApplication.palette()
        gradient = QtGui.QLinearGradient(0, 0, 0, 20)
        gradient.setColorAt(0.05, pal.base().color())
        gradient.setColorAt(0.051, pal.window().color())
        gradient.setColorAt(0.95, pal.window().color())
        gradient.setColorAt(0.951, pal.base().color())
        brush = QtGui.QBrush(gradient)

        if self.fourCombobox.currentText()!="All":
            self.cursor.execute("select ar.id, ar.name, ar.path from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),self.fourCombobox.currentIndex(),fingTextLine+"%",))
        else:
            self.cursor.execute("select ar.id, ar.name, ar.path from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),fingTextLine+"%",))
        row = self.cursor.fetchall()
        self.conn.commit()
        for x in row:
            item = QtGui.QStandardItem(x[1])
            item.setCheckable(True)
            item.setBackground(brush)
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            item.setFont(serifFont)
            child = QtGui.QStandardItem(x[2])
            item.setData("  "+x[1],QtCore.Qt.DisplayRole)
            item.setData(x[0],QtCore.Qt.UserRole)
            item.setData(x[2],QtCore.Qt.UserRole+1)
            item.setData(x[1],QtCore.Qt.UserRole+2)
            item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            item.setChild(0,child)
            parentItem.appendRow(item)

                
    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        self.curProject = settings.value("project", "1").toInt()
        self.oneCombobox.setCurrentIndex(self.curProject[0])    
        self.curType = settings.value("type", "1").toInt()
        self.fourCombobox.setCurrentIndex(self.curType[0])
        self.splitter.restoreState(settings.value("OpenSplitter").toByteArray())
           
        self.twoLineEdit.setText(settings.value("findString", "%").toString())
        chekStat = settings.value("checkOverride", "0").toInt()
        if chekStat[0] == 0: self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        else: self.checkOverride.setCheckState(QtCore.Qt.Checked)
        settings.endGroup()            
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", "//Server-3d/Project/").toString()
        settings.endGroup()

    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.setValue("project", self.oneCombobox.currentIndex())
        settings.setValue("findString", self.twoLineEdit.text())
        settings.setValue("type", self.fourCombobox.currentIndex())        
        chekStat = 0
        if self.checkOverride.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("checkOverride", chekStat)        
        settings.setValue("OpenSplitter", self.splitter.saveState())
        settings.endGroup()        
        

#if ex.exec_() == QtGui.QDialog.Accepted:
#    print "Accept"
#else:
#    print "Reject"
   
#cursor.close()    
#conn.close()

#ex = Window()
#ex.exec_()
