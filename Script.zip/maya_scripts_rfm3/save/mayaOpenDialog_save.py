import sys, os
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup

conn = mb.connect(host="192.168.0.206",user="yago",passwd="yagogo",db = "mel", use_unicode=True)
conn.set_character_set("utf8")
cursor = conn.cursor()

class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();


class listDelegate(QtGui.QItemDelegate):
    def __init__(self, parent=None):
        super(listDelegate, self).__init__(parent)
        self.mult = 1
                            
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        #print "resize"
        #print(str(option.rect.width())+"  "+str(option.rect.height()))
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize(11)
        myFontMetrics = QtGui.QFontMetrics(myFont)
        mySize = myFontMetrics.boundingRect(0,0, 260, 0,(QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), index.data(QtCore.Qt.DisplayRole).toString())
        #print(index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize))        
        return QtCore.QSize(mySize.width(),mySize.height()+40)
        
        #mySize = myFontMetrics.boundingRect(option.rect,QtCore.Qt.TextExpandTabs|QtCore.Qt.TextWordWrap,index.data(QtCore.Qt.DisplayRole).toString(),10)
        #mySize = myFontMetrics.size(QtCore.Qt.TextExpandTabs, index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize.width())+"  "+str(mySize.height()+50))        
        #return QtCore.QSize(mySize.width(),mySize.height()+50)
        #return index.data(QtCore.Qt.UserRole+5).toSize()*self.mult

    def paint(self, painter, option, index):
        #print painter.font().pixelSize() 
        #print "paint"
        #self.sizeHint(option, index)
        #self.emmit.sizeHintChanged(index)
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2
            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Multiply)
        gradient2 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height())
        gradient2.setColorAt(0,QtGui.QColor(255,255,255))
        gradient2.setColorAt(1,QtGui.QColor(200,200,200))
        brush2 = QtGui.QBrush(gradient2)
        painter.fillRect(option.rect,brush2)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
        gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
        gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
        brush3 = QtGui.QBrush(gradient3)
        painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
    
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
    
        gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
        gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
        brush4 = QtGui.QBrush(gradient4)
        painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        #painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
    
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
    
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
    
        text = index.data(QtCore.Qt.DisplayRole).toString()
        #newText = painter.fontMetrics().elidedText(text, QtCore.Qt.ElideRight, option.rect.width())
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
#app = QtGui.qApp
class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()
        #print melnik_setup.userId
        self.mainLayout = QtGui.QVBoxLayout()
        self.radioLayout = QtGui.QHBoxLayout()
        self.oneRadio = QtGui.QRadioButton("Assets")
        self.oneRadio.setChecked(True)
        self.twoRadio = QtGui.QRadioButton("Scenes")
        self.radioLayout.addWidget(self.oneRadio)
        self.radioLayout.addWidget(self.twoRadio)
        
        self.oneLayout = QtGui.QHBoxLayout()
        self.oneLabel = QtGui.QLabel("Project: ")
        cursor.execute("select id, name from projects")
        row = cursor.fetchall()
        conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()
        self.oneLayout.addWidget(self.oneLabel)
        self.oneLayout.addWidget(self.oneCombobox)
        self.oneLayout.setStretch(1,1)
        
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")        
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)
        self.twoLineEdit.returnPressed.connect(self.findText)

        
        self.treeLayout = QtGui.QHBoxLayout()
        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.connect(self.treeView, QtCore.SIGNAL("doubleClicked(const QModelIndex &)"), self.activeTreeCellDoubleClicked)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("clicked(const QModelIndex &)"), self.activeTreeCellCliked)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        
        self.treeLayout.addWidget(self.treeView)
        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        self.listLayout = QtGui.QHBoxLayout()
        self.listView = QtGui.QTreeView()
        self.listView.connect(self.listView, QtCore.SIGNAL("doubleClicked(const QModelIndex &)"), self.activeListCellCliked)
        self.listView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = listDelegate()
        self.listView.setItemDelegate(self.delegate)
        self.listView.setIndentation(0)
        self.listView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.listView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.listLayout.addWidget(self.listView)
        self.listModel = QtGui.QStandardItemModel()
        self.listView.setModel(self.listModel)
        self.listView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.listView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.listView.setHeaderHidden(True)
        self.listView.setMinimumWidth(300)
        
        self.layoutButt = QtGui.QHBoxLayout()
        #self.okButt = QtGui.QPushButton("Ok")
        #self.okButt.clicked.connect(self.accept)
        self.cancelButt = QtGui.QPushButton("Close")
        self.cancelButt.clicked.connect(self.reject)
        self.layoutButt.addStretch()
        #self.layoutButt.addWidget(self.okButt)
        self.layoutButt.addWidget(self.cancelButt)
        
        self.mainLayout.addLayout(self.radioLayout)
        self.mainLayout.addLayout(self.oneLayout)
        self.mainLayout.addLayout(self.twoLayout)
        self.mainLayout.addLayout(self.treeLayout)
        self.mainLayout.addLayout(self.listLayout)
        self.mainLayout.addLayout(self.layoutButt)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Load asset/scene...')
        self.readSettings()
        self.findText()
    def closeEvent(self, event):
            self.writeSettings()
            event.accept()

    def activeListCellCliked(self, index):
        #print "cliked!"
        filePathToProcess = index.data(QtCore.Qt.UserRole+1).toString()
        filePathToProcessStr=str(filePathToProcess)
        fileNameToProcess = index.data(QtCore.Qt.UserRole+4).toString().split(".")[0]
        fileNameToProcessStr=str(fileNameToProcess)
        msgBox = QtGui.QMessageBox()
        msgBox.setWindowTitle("How open file?")
        msgBox.setText("Choose what you want...")
        #msgBox.setInformativeText("Do you want to save your changes?")
        but=msgBox.addButton("Open",QtGui.QMessageBox.AcceptRole)
        msgBox.addButton("Reference",QtGui.QMessageBox.AcceptRole)
        msgBox.addButton("Import",QtGui.QMessageBox.AcceptRole)
        cancel = msgBox.addButton(QtGui.QMessageBox.Cancel)
        msgBox.setDefaultButton(but)
        msgBox.setEscapeButton(cancel)
        ret = msgBox.exec_()
        if ret != QtGui.QMessageBox.Cancel:
            if ret == 0:
                #self.accept()
                cmds.file( filePathToProcessStr, type="mayaBinary", options="v=0", ignoreVersion=True, force=True, open=True)
                mel.eval("addRecentFile(\""+filePathToProcessStr+"\", \"mayaBinary\")")
            elif ret == 1:
                #self.accept()
                cmds.file( filePathToProcessStr, type="mayaBinary", options="v=0", reference=True, loadReferenceDepth="all", namespace=fileNameToProcessStr)
            elif ret == 2:
                #self.accept()
                cmds.file( filePathToProcessStr, type="mayaBinary", options="v=0", ignoreVersion=True, force=True, renameAll=True, i=True, namespace=fileNameToProcessStr, preserveReferences=True, loadReferenceDepth="all")
            
        
    def activeTreeCellDoubleClicked(self, index):
        print "double cliked!"
        
    def activeTreeCellCliked(self, index):
        self.listModel.clear()
        rootPath = index.data(QtCore.Qt.UserRole).toString()
        print rootPath
        cursor.execute(u'select e.date, e.info, e.path, p.nickname from data as d, data_has_edits as dhe, edits as e, edits_has_people as ehp, people as p where d.path like %s and d.id = dhe.data_id and e.id = dhe.edits_id and dhe.edits_id=ehp.edits_id and p.id=ehp.people_id',(rootPath,))
        row = cursor.fetchall()
        conn.commit()
        #print len(row)        
        #print row
        myFileInfo=QtCore.QFileInfo(rootPath)
        myFileName = myFileInfo.fileName()
        twoPart = myFileName.split(".")
        treeFor = twoPart[0].split("_")
        parts=1
        
        if treeFor.count() == 2: 
            #for sl in treeFor:
                #print sl
            treeForOne=twoPart[0].split("_")
            treeForOne.insert(1,"v??[0-9]")
            treeForFullOne = treeForOne.join("_")
            treeForTwo=twoPart[0].split("_")
            treeForTwo.insert(2,"v??[0-9]")
            #for sl in treeFor:
                #print sl
            treeForFullTwo = treeForTwo.join("_")
            myStr=treeForFullOne+".ma,"+treeForFullOne+".mb, "+treeForFullTwo+".ma,"+treeForFullTwo+".mb"
            #print myStr
        else:
            if treeFor.count() > 0: 
                parts=2
            treeFor.insert(parts,"v??[0-9]")
            treeForFull = treeFor.join("_")
            myStr=treeForFull+".ma,"+treeForFull+".mb"
        
        filters= myStr.split(",")
        dir = QtCore.QDir()
        dir.setNameFilters(filters)
        
        myPath = myFileInfo.path()
        dir.setPath(myPath+"/work")
        strList = dir.entryInfoList()
        item = self.listModel.invisibleRootItem()
        filePathList = QtCore.QStringList()
        dateTimeList = QtCore.QStringList()        
        userList = QtCore.QStringList()
        fileNameList = QtCore.QStringList()        
        fileInfoList = QtCore.QStringList()                
        
        for i in range(0,len(strList)):
            est=0
            for j in range(0,len(row)):
                if row[j][2] == strList[i].filePath():
                    est=1
                    filePathList.append(row[j][2])
                    ttimeNow=row[j][0]
                    dateTimeList.append(ttimeNow.isoformat(' '))             
                    userList.append(row[j][3])
                    fileNameList.append(strList[i].fileName())
                    fileInfoList.append(row[j][1]) #.decode('UTF-8')
                    break
            if est == 0:                    
                filePathList.append(strList[i].filePath())
                ttime=strList[i].lastModified()
                dateTimeList.append(str(ttime.date().year())+"-"+str(ttime.date().month())+"-"+str(ttime.date().day())+" "+str(ttime.time().hour())+":"+str(ttime.time().minute())+":"+str(ttime.time().second()))             
                userList.append("unknovn")
                fileNameList.append(strList[i].fileName())
                fileInfoList.append("empty")
            
        for i in range(0,len(filePathList)):                        
            child = QtGui.QStandardItem("empty")
            child.setData(filePathList[i],QtCore.Qt.UserRole+1)
            child.setData(dateTimeList[i],QtCore.Qt.UserRole+2)
            child.setData(userList[i],QtCore.Qt.UserRole+3)
            child.setData(fileNameList[i],QtCore.Qt.UserRole+4)
            child.setData(fileInfoList[i],QtCore.Qt.DisplayRole)

            #myFont = QtGui.QFont("Tahoma")
            #myFont.setPixelSize(11)
            #myFontMetrics = QtGui.QFontMetrics(myFont)
            #mySize = myFontMetrics.boundingRect(0,0,40,60,QtCore.Qt.TextExpandTabs,fileInfoList[i],10)
            #print("razmer: "+str(mySize.width())+" na "+str(mySize.height()))

            #child.setData(QtCore.QSize(mySize.width(),mySize.height()+50),QtCore.Qt.UserRole+5)
            item.setChild(i,child)

    def activeTreeCellExpanded(self, index):
        #print("expanded: "+index.child(0,0).data().toString())
        if index.parent().row() == -1:
            item = self.treeModel.itemFromIndex(index)
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data().toString()+"/maya"
            dir = QtCore.QDir(rootPath)
            myStr="*.ma,*.mb"
            filters= myStr.split(",")
            dir.setNameFilters(filters)
            strList = dir.entryList()
            for i in range(0,len(strList)):
                child = QtGui.QStandardItem(strList[i])
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole)
                item.setChild(i,child)
            dir.setPath(rootPath+"/work/anm")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("anm")
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/anm/"+strList[i],QtCore.Qt.UserRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/work/dyn")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("dyn")
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/dyn/"+strList[i],QtCore.Qt.UserRole)                    
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/work/map")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("map")
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/map/"+strList[i],QtCore.Qt.UserRole)                                        
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/shd")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("shd")
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/shd/"+strList[i],QtCore.Qt.UserRole)                                                            
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/tex")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("tex")
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/tex/"+strList[i],QtCore.Qt.UserRole)                                                            
                    childItem.setChild(i,child)               
            dir.setPath(rootPath+"/work/mod/geo")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("mod")
                item.setChild(item.rowCount(),childItem)
                childChildItem = QtGui.QStandardItem("geo")
                childItem.setChild(childItem.rowCount(),childChildItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/mod/geo/"+strList[i],QtCore.Qt.UserRole)                                                                                
                    childChildItem.setChild(i,child)
                dir.setPath(rootPath+"/work/mod/shape")
                strList = dir.entryList()               
                if len(strList) is not 0:
                    childChildItem = QtGui.QStandardItem("shape")
                    childItem.setChild(childItem.rowCount(),childChildItem)
                    for i in range(0,len(strList)):                
                        child = QtGui.QStandardItem(strList[i])
                        child.setData(rootPath+"/work/mod/shape/"+strList[i],QtCore.Qt.UserRole)                                                                                                        
                        childChildItem.setChild(i,child)                                   
                dir.setPath(rootPath+"/work/mod/tpl")
                strList = dir.entryList()                                       
                if len(strList) is not 0:
                    childChildItem = QtGui.QStandardItem("tpl")
                    childItem.setChild(childItem.rowCount(),childChildItem)
                    for i in range(0,len(strList)):                
                        child = QtGui.QStandardItem(strList[i])
                        child.setData(rootPath+"/work/mod/tpl/"+strList[i],QtCore.Qt.UserRole)                                                                                                                                
                        childChildItem.setChild(i,child)                                                           
            dir.setPath(rootPath+"/work/rig")
            strListRig = dir.entryList()
            dir.setPath(rootPath+"/work/rig/face")
            strListHed = dir.entryList()
            dir.setPath(rootPath+"/work/rig/sceleton")
            strListScl = dir.entryList()
            if len(strListRig) is not 0 or len(strListHed) is not 0 or len(strListScl) is not 0:                        
                childItemRig = QtGui.QStandardItem("rig")
                item.setChild(item.rowCount(),childItemRig)
                if len(strListRig) is not 0:
                    for i in range(0,len(strListRig)):                
                        child = QtGui.QStandardItem(strListRig[i])
                        child.setData(rootPath+"/work/rig/"+strListRig[i],QtCore.Qt.UserRole)                                                                                                                                                        
                        childItemRig.setChild(i,child)             
                if len(strListHed) is not 0:
                    childItem = QtGui.QStandardItem("face")
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListHed)):                
                        child = QtGui.QStandardItem(strListHed[i])
                        child.setData(rootPath+"/work/rig/face/"+strListHed[i],QtCore.Qt.UserRole)                                                                                                                                                                                
                        childItem.setChild(i,child)                               
                if len(strListScl) is not 0:
                    childItem = QtGui.QStandardItem("sceleton")
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListScl)):                
                        child = QtGui.QStandardItem(strListScl[i])
                        child.setData(rootPath+"/work/rig/sceleton/"+strListScl[i],QtCore.Qt.UserRole)                                                                                                                                                                                                        
                        childItem.setChild(i,child)                               
                    
            
        
    def findText(self):   
        #twoLineEdit = self.sender()
        fingTextLine = self.twoLineEdit.text()
        #print(fingTextLine+" : combo Index "+self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString())
        cursor.execute("select ar.id, ar.name, ar.path from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),fingTextLine+"%",))
        row = cursor.fetchall()
        conn.commit()
        #print row
        sizeSearche = len(row)
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        for x in row:
            item = QtGui.QStandardItem(x[1])
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            item.setFont(serifFont)
            child = QtGui.QStandardItem(x[2])
            item.setData(x[1],QtCore.Qt.DisplayRole)
            item.setData(x[0],QtCore.Qt.UserRole)
            item.setData(x[2],QtCore.Qt.UserRole+1)            
            item.setChild(0,child)
            parentItem.appendRow(item)

    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.curProject = settings.value("project", "1").toInt();
        self.twoLineEdit.setText(settings.value("findString", "%").toString())
        self.resize(size)
        self.move(pos)
        self.oneCombobox.setCurrentIndex(self.curProject[0])
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", "//Server-3d/Project/").toString()
        settings.endGroup()

    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.setValue("project", self.oneCombobox.currentIndex())
        settings.setValue("findString", self.twoLineEdit.text())
        


ex = Window()
ex.exec_()
#if ex.exec_() == QtGui.QDialog.Accepted:
#    print "Accept"
#else:
#    print "Reject"
   
cursor.close()    
conn.close()