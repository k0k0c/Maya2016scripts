import sys, os
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

conn = mb.connect(host="192.168.0.206",user="root",passwd="12345",db = "mel", use_unicode=True)
conn.set_character_set("utf8")
cursor = conn.cursor()

class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class listDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,60)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2
            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Multiply)
        gradient2 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height())
        gradient2.setColorAt(0,QtGui.QColor(255,255,255))
        gradient2.setColorAt(1,QtGui.QColor(200,200,200))
        brush2 = QtGui.QBrush(gradient2)
        painter.fillRect(option.rect,brush2)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
        gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
        gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
        brush3 = QtGui.QBrush(gradient3)
        painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
    
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
    
        gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
        gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
        brush4 = QtGui.QBrush(gradient4)
        painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        #painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
    
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
    
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
    
        text = index.data(QtCore.Qt.DisplayRole).toString()
        newText = painter.fontMetrics().elidedText(text, QtCore.Qt.ElideRight, option.rect.width())
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), newText)
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
#app = QtGui.qApp
class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.mainLayout = QtGui.QVBoxLayout()
        self.groupBoxFind = QtGui.QGroupBox(" Find asset ")
        self.LayoutFindMain = QtGui.QVBoxLayout()
        self.LayoutFind = QtGui.QGridLayout()
        self.groupBoxFind.setLayout(self.LayoutFindMain)
        
        self.oneLabel = QtGui.QLabel("Project: ")
        self.oneLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        cursor.execute("select id, name from projects")
        row = cursor.fetchall()
        conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()
        self.LayoutFind.addWidget(self.oneLabel, 0, 0)
        self.LayoutFind.addWidget(self.oneCombobox, 0, 1)

        self.fourLabel = QtGui.QLabel("Type: ")
        self.fourLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fourCombobox = QtGui.QComboBox()
        self.fourQlistNames = QtCore.QStringList()
        self.fourQlistNames.append("All")
        self.fourQlistNames.append("chars")        
        self.fourQlistNames.append("proxy")        
        self.fourQlistNames.append("props")        
        self.fourQlistNames.append("sets")
        self.fourQlistNames.append("scene")
        self.fourQlistNames.append("dynamic")
        
        self.fourCombobox.addItems(self.fourQlistNames)
        self.LayoutFind.addWidget(self.fourLabel, 0, 2)
        self.LayoutFind.addWidget(self.fourCombobox, 0, 3)
        
        self.radioLayout = QtGui.QHBoxLayout()
        self.oneRadio = QtGui.QRadioButton("Database")
        self.oneRadio.setChecked(True)
        self.twoRadio = QtGui.QRadioButton("File system")
        self.radioLayout.addWidget(self.oneRadio)
        self.radioLayout.addWidget(self.twoRadio)

        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.LayoutFindMain.addLayout(self.LayoutFind)
        self.LayoutFindMain.addLayout(self.radioLayout)
        self.LayoutFindMain.addLayout(self.twoLayout)        
        
        self.groupBox = QtGui.QGroupBox(" Save ")
        self.HBLayout = QtGui.QVBoxLayout()
        self.groupBox.setLayout(self.HBLayout)
    
        self.groupBoxNV = QtGui.QGroupBox(" Name of asset")
        self.gridLayoutNV = QtGui.QGridLayout()
        self.groupBoxNV.setLayout(self.gridLayoutNV)
        self.HBLayout.addWidget(self.groupBoxNV)
        
        self.LabelNV = QtGui.QLabel("Name: ")
        self.ComboboxNV = QtGui.QComboBox()        
        self.ComboboxNV.setEditable(True)
        #self.ComboboxNV.lineEdit().connect(self.ComboboxNV.lineEdit(), QtCore.SIGNAL("editingFinished()"), self.editTextChangedName)
        self.gridLayoutNV.addWidget(self.LabelNV, 0, 0)
        self.gridLayoutNV.addWidget(self.ComboboxNV, 0, 1)
        
        self.treeLayout = QtGui.QHBoxLayout()
        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("clicked(const QModelIndex &)"), self.activeTreeCellCliked)        
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        #self.delegate = SpinBoxDelegate()
        #self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeLayout.addWidget(self.treeView)
        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        self.HBLayout.addLayout(self.treeLayout)
        
        self.checkOverride = QtGui.QCheckBox(" Override current version of file")
        self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        self.checkOverride.connect(self.checkOverride, QtCore.SIGNAL("stateChanged(int)"), self.changeOvveride)                
        self.HBLayout.addWidget(self.checkOverride)
        
        self.labelNote = QtGui.QLabel("Note:")
        self.HBLayout.addWidget(self.labelNote)        
        self.textEditNote = QtGui.QTextEdit("")
        self.HBLayout.addWidget(self.textEditNote)   
               
        self.okButt = QtGui.QPushButton("Save")
        self.okButt.released.connect(self.saveFile)
        self.okButt.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.HBLayout.addWidget(self.okButt,0,QtCore.Qt.AlignRight)

        self.mainLayout.addWidget(self.groupBoxFind)
        self.mainLayout.addWidget(self.groupBox)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')
        self.readSettings()                    
        #if self.initVariables() != 1:
        #    self.readSettings()                    
        #    self.findText()
        self.findText()

    def closeEvent(self, event):
            self.writeSettings()
            event.accept()

    def changeOvveride(self, nuzh):
        if nuzh == 2:
            self.treeView.setEnabled(False)
        else:
            self.treeView.setEnabled(True)
            
    def saveFile(self):
        parentItem = self.treeModel.invisibleRootItem()
        self.listPath = []
        self.buildTree(parentItem)
        self.buildSaveFiles()
        if len(self.fileAssetPath)==0:
            QtGui.QMessageBox.critical(self, "Error", "Vydelite faily!", QtGui.QMessageBox.Ok)
            return 0            
        if self.textEditNote.toPlainText()=="":
            QtGui.QMessageBox.critical(self, "Error", "Zapolnite NOTE!", QtGui.QMessageBox.Ok)
            return 0
        for i in range(len(self.fileAssetPath)):
            print "aaa1 "+self.filePath[i]
            print "aaa2 "+self.fileAssetPath[i]
            print "aaa3 "+self.fileAssetTag[i]
            self.userId = melnik_setup.userId
            cursor.execute("select dt.id from data as dt, assets_has_data as dhp where dt.path like %s and dhp.data_id=dt.id and dhp.assets_id = %s",(self.fileAssetPath[i],self.selectedAssetId,))
            row = cursor.fetchall()
            conn.commit()
            dataId=-1
            if len(row) != 0:
                dataId = row[0][0]
            elif len(row) == 0:
                print("Netu daty, sozdaem...")
                sss1=self.fileAssetPath[i].split("/")
                categoryesss=""
                nayden=0
                for s in range(len(sss1)):
                    if sss1[s]=="maya":
                        nayden=1
                    if nayden and s==(len(sss1)-2):
                        categoryesss=categoryesss+sss1[s]
                    elif nayden and s<(len(sss1)-1):
                        categoryesss=categoryesss+sss1[s]+"/"
                cursor.execute("select dt.id from dcategories as dt where dt.name like %s",(categoryesss,))
                row = cursor.fetchall()
                if len(row)==0:
                    cursor.execute("INSERT INTO dcategories VALUES(null,%s,null)",(categoryesss,))                
                    categoryesss=conn.insert_id()
                    conn.commit()
                else:
                    categoryesss = row[0][0]
                cursor.execute("INSERT INTO data VALUES(NULL,%s,%s,1,4,now())",(self.findName+self.fileAssetTag[i],self.fileAssetPath[i],))
                dataId=conn.insert_id()
                print dataId
                cursor.execute("INSERT INTO assets_has_data VALUES(%s,%s,%s)",(self.selectedAssetId,dataId,categoryesss))
                cursor.execute("INSERT INTO data_has_projects VALUES(%s,%s)",(dataId,self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),))
                cursor.execute("INSERT INTO data_has_people VALUES(%s,%s)",(dataId,self.userId,))
                conn.commit()


            cursor.execute("select ed.id, ed.info, ehp.people_id from edits as ed, edits_has_people as ehp where ed.path like %s and ehp.edits_id=ed.id",(self.filePath[i],))
            row = cursor.fetchall()
            conn.commit()                        
            curId=-1
            findUserText=""
            for r in row:
                print r
                if r[2]==self.userId:
                    curId=r[0]
                    findUserText=findUserText+r[1]
            if curId == -1:
                cursor.execute("INSERT INTO edits VALUES(NULL,now(),%s,%s)",(self.textEditNote.toPlainText().toUtf8(),self.filePath[i],))
                editsId=conn.insert_id()   
                cursor.execute("INSERT INTO edits_has_people VALUES(%s,%s)",(editsId,self.userId,))
                cursor.execute("INSERT INTO data_has_edits VALUES(%s,%s)",(dataId,editsId,))
                conn.commit()                
            else:
                cursor.execute("UPDATE edits SET info = %s WHERE id = %s",(findUserText+"\\n    "+self.textEditNote.toPlainText().toUtf8(),curId,))
                conn.commit()

            extenshen="mayaBinary"
            
            myqstri=QtCore.QString(self.filePath[i])
            myqstriList= myqstri.split("/")
            myqstriList.takeLast()
            myqstri=myqstriList.join("/")
            dir = QtCore.QDir()
            if not dir.exists(myqstri):
                #print myqstri
                dir.mkpath(myqstri)
            
            if self.filePath[i].split(".")[1]=="ma": extenshen="mayaAscii"                
            mel.eval("file -rename \""+self.filePath[i]+"\"")
            mel.eval("file -f -save  -options \"v=0\" -type \""+extenshen+"\"")
            fileRoot2 = QtCore.QFile(self.fileAssetPath[i])
            if fileRoot2.exists():
                print "remove file..."
                fileRoot2.remove()
            fileRoot = QtCore.QFile(self.filePath[i])                
            fileRoot.copy(self.fileAssetPath[i]) 
        melnik_setup.updateScene()            
        self.accept()

    def buildTree(self, root):
        i=0
        while i != -1:
            eeewPast = root.child(i,0)
            if eeewPast is None:
                break
            root1 = eeewPast.data(QtCore.Qt.UserRole+1).toString()
            root2 = eeewPast.data(QtCore.Qt.UserRole+2).toString()
            root5 = eeewPast.data(QtCore.Qt.CheckStateRole).toString()
            if root5 == "2":
                if root2 == "":
                    print("Specialnaya proverka root2: "+root1)
                    self.listPath.append(root1)
                else:
                    print("Specialnaya proverka: "+root1+"/"+root2+"/maya/")
                    self.listPath.append(root1+"/"+root2+"/maya/")
            self.buildTree(eeewPast)
            i = i + 1

    def buildFileName(self):
        sceneNameFile=cmds.file(query=True, sn=True)
        print("imya faila: "+sceneNameFile)
        if sceneNameFile=="":
            self.findName = ""
            return ""
        str2=sceneNameFile.split(".")
        str4=str2[0].split("/")
        str3=re.split('_v[0-9]{1,4}(?=_|$)', str4[-1])
        str5=str3[0].split("_")
        rez=str5[0]
        if len(str5)>1:
        	for i in range(1,len(str5)-1):
        		rez = rez + "_" + str5[i]
        	if str4[-2] != str5[-1] and str4[-3] != str5[-1]:
        		rez = rez + "_" + str5[-1]        
        print("naydennoe imya: " + rez)
        self.findName = rez

    def buildSaveFiles(self):
        #self.buildFileName()
        self.filePath = QtCore.QStringList()
        self.fileAssetPath = QtCore.QStringList()
        self.fileAssetTag = QtCore.QStringList()
        self.findName = str(self.ComboboxNV.currentText())
        sceneNameFile2=""
        if self.checkOverride.checkState() == QtCore.Qt.Checked:         
            self.activeTreeCellCliked(self.treeModel.invisibleRootItem().child(0,0).index())
            self.findName = str(self.ComboboxNV.currentText())
            self.listPath=[]
            sceneNameFile2=cmds.file(query=True, sn=True)
            rrezz = sceneNameFile2.split("/")
            rrezz2 = ""
            for i in range(len(rrezz)):
                if i == len(rrezz)-1 and (len(rrezz[i].split(".")) == 2 or rrezz[i]=="work"):
                    continue
                if i == len(rrezz)-2 and rrezz[i]=="work":
                    continue        
                rrezz2=rrezz2+rrezz[i]+"/"
            if rrezz2[-1]!="/":
                rrezz2 = rrezz2 + "/"
            self.listPath.append(rrezz2)

        for strIn in self.listPath:
			print("Put: " + strIn)
			maxNumberFile=0
			dir = QtCore.QDir(strIn+"work")
			dir.setNameFilters("*.ma,*.mb".split(","))
			strList = dir.entryList()
			for sl in strList:
				m=re.search(self.findName+"_v(?P<first_name>[0-9]{1,4}).*.m[ab]$", sl)
				if m:
					print sl
					if int(m.group('first_name')) > maxNumberFile:
						maxNumberFile=int(m.group('first_name'))
			strNext=str(maxNumberFile+1)
			print("Sledushiy nomer: "+strNext)
			for i in range(2):
				if len(strNext)<3:
					strNext="0"+strNext
				else:
					break
			addStr=""    
			pathi=strIn.split("/")
			print pathi
			if pathi[-1]!="" and len(pathi[-1].split("."))!=1 and pathi[-1]!="work" and pathi[-1]!="maya":
				addStr="_"+pathi[-1]
			elif pathi[-2]!="work":
				addStr="_"+pathi[-2]        
			elif pathi[-3]!="work":
				addStr="_"+pathi[-3]        
			if pathi[-3] == "chars" or pathi[-3] == "props" or pathi[-3] == "sets" or pathi[-2] == "chars" or pathi[-2] == "props" or pathi[-2] == "sets" or pathi[-1] == "maya" or pathi[-2] == "maya":
				addStr=""   				
			print("tag: "+addStr)
			newName=self.findName+"_v"+strNext+addStr+".mb"#+str2[1]
			if self.checkOverride.checkState() != QtCore.Qt.Checked:sceneNameFile2 = strIn+"work/"+newName
			print("final name: "+sceneNameFile2)
			self.filePath.append(sceneNameFile2)
			newNameAs=self.findName+addStr+".mb"#+str2[1]
			print("final name assets: "+strIn+newNameAs)
			self.fileAssetPath.append(strIn+newNameAs)
			self.fileAssetTag.append(addStr)

    def initVariables(self):
        strrr=""
        self.mayaSceneName = cmds.file(query=True, sceneName=True)
        #print self.mayaSceneName
        m = re.search(str(self.GlobalRootPath)+"(?P<first_name>.*)",self.mayaSceneName,re.I)
        if m is None:
            print "None"
        else:
            strrr = m.group("first_name")
            strProject=strrr.split("/")[0]
            projectIndex = self.qlistNames.indexOf(strProject)
            self.oneCombobox.setCurrentIndex(projectIndex)
            #print projectIndex
            m = re.search(strProject+"/assets/(?P<first_name>.*)",strrr,re.I)
            if m is None:
                print "None"
            else:    
                strrr=m.group("first_name")
                strTypes=strrr.split("/")[0]
                m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None"
                else:
                    strrr=m.group("first_name")
                    strrr=strrr.split("/")[0]
                    self.twoLineEdit.setText(strrr)
                    #print strrr
                    self.findText()
                    item = self.treeModel.invisibleRootItem().child(0,0)
                    self.treeView.expand(self.treeModel.indexFromItem(item))
                    return 1

    def activeTreeCellCliked(self, index):
        self.buildFileName()        
        eeeNew = index
        eeePast = index
        while eeeNew.row() != -1:
            eeePast = eeeNew
            eeeNew = eeeNew.parent()
        self.selectedAssetId = eeePast.data(QtCore.Qt.UserRole).toString()
        rootPath = eeePast.data(QtCore.Qt.UserRole+1).toString()
        rootPathName = eeePast.data(QtCore.Qt.UserRole+2).toString()
        dir = QtCore.QDir(rootPath+"/"+rootPathName+"/maya")
        myStr="*.ma,*.mb"
        filters= myStr.split(",")
        dir.setNameFilters(filters)
        strList = dir.entryList()
        self.ComboboxNV.clear()
        for i in range(0,len(strList)):
            #print strList[i]
            self.ComboboxNV.addItem(strList[i].split(".")[0])
        if self.findName != "":
            findIndex = self.ComboboxNV.findText(self.findName)
            if findIndex != -1:
                self.ComboboxNV.setCurrentIndex(findIndex)
            else: 
                self.ComboboxNV.addItem(self.findName)
                self.ComboboxNV.setCurrentIndex(self.ComboboxNV.count()-1)                

    def activeTreeCellExpanded(self, index):
        #print("expanded: "+index.child(0,0).data().toString())
        if index.parent().row() == -1:
            pal = QtGui.QApplication.palette()
            gradient = QtGui.QLinearGradient(0, 0, 0, 20)
            gradient.setColorAt(0.05, pal.base().color())
            gradient.setColorAt(0.051, pal.window().color())
            gradient.setColorAt(0.95, pal.window().color())
            gradient.setColorAt(0.951, pal.base().color())
            brush = QtGui.QBrush(gradient)
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
                        
            item = self.treeModel.itemFromIndex(index)
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data(QtCore.Qt.UserRole+2).toString()+"/maya"
            #item.takeChild(0,0)
            
            childItem = QtGui.QStandardItem("  anm")
            childItem.setData(rootPath+"/work/anm/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(0,childItem)
            
            childItem = QtGui.QStandardItem("  dyn")
            childItem.setData(rootPath+"/work/dyn/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            
            childItem = QtGui.QStandardItem("  map")
            childItem.setData(rootPath+"/work/map/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            
            childItem = QtGui.QStandardItem("  shd")
            childItem.setData(rootPath+"/work/shd/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
            
            childItem = QtGui.QStandardItem("  tex")
            childItem.setData(rootPath+"/work/tex/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)

            childItem = QtGui.QStandardItem("  mod")
            childItem.setData(rootPath+"/work/mod/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
                        
            childchildItem = QtGui.QStandardItem("  geo")
            childchildItem.setData(rootPath+"/work/mod/geo/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            
            childchildItem = QtGui.QStandardItem("  shape")
            childchildItem.setData(rootPath+"/work/mod/shape/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            
            childchildItem = QtGui.QStandardItem("  tpl")
            childchildItem.setData(rootPath+"/work/mod/tpl/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)

            childItem = QtGui.QStandardItem("  rig")
            childItem.setData(rootPath+"/work/rig/",QtCore.Qt.UserRole+1)
            childItem.setCheckable(True)
            childItem.setBackground(brush)
            childItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childItem.setFont(serifFont)
            item.setChild(item.rowCount(),childItem)
                        
            childchildItem = QtGui.QStandardItem("  face")
            childchildItem.setData(rootPath+"/work/rig/face/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
            
            childchildItem = QtGui.QStandardItem("  sceleton")
            childchildItem.setData(rootPath+"/work/rig/sceleton/",QtCore.Qt.UserRole+1)
            childchildItem.setCheckable(True)
            childchildItem.setBackground(brush)
            childchildItem.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
            childchildItem.setFont(serifFont)
            childItem.setChild(childItem.rowCount(),childchildItem)
        
    def findText(self):   
        fingTextLine = self.twoLineEdit.text()
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        
        pal = QtGui.QApplication.palette()
        gradient = QtGui.QLinearGradient(0, 0, 0, 20)
        gradient.setColorAt(0.05, pal.base().color())
        gradient.setColorAt(0.051, pal.window().color())
        gradient.setColorAt(0.95, pal.window().color())
        gradient.setColorAt(0.951, pal.base().color())
        brush = QtGui.QBrush(gradient)

        if self.oneRadio.isChecked():
            if self.fourCombobox.currentText()!="All":
                cursor.execute("select ar.id, ar.name, ar.path from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),self.fourCombobox.currentIndex(),fingTextLine+"%",))
            else:
                cursor.execute("select ar.id, ar.name, ar.path from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),fingTextLine+"%",))
            row = cursor.fetchall()
            conn.commit()
            for x in row:
                item = QtGui.QStandardItem(x[1])
                item.setCheckable(True)
                item.setBackground(brush)
                serifFont=QtGui.QFont()
                serifFont.setBold(True)
                item.setFont(serifFont)
                child = QtGui.QStandardItem(x[2])
                item.setData("  "+x[1],QtCore.Qt.DisplayRole)
                item.setData(x[0],QtCore.Qt.UserRole)
                item.setData(x[2],QtCore.Qt.UserRole+1)
                item.setData(x[1],QtCore.Qt.UserRole+2)
                item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                item.setChild(0,child)
                parentItem.appendRow(item)
        else:
            if self.fourCombobox.currentText()!="All":
                dir = QtCore.QDir(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/"+self.fourCombobox.currentText())
                dir.setFilter(QtCore.QDir.Dirs|QtCore.QDir.NoDotAndDotDot)
                strList = dir.entryList()
                for x in range(0,len(strList)):
                    item = QtGui.QStandardItem(strList[x])
                    item.setCheckable(True)
                    item.setBackground(brush)                    
                    serifFont=QtGui.QFont()
                    serifFont.setBold(True)
                    item.setFont(serifFont)
                    child = QtGui.QStandardItem(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/"+self.fourCombobox.currentText())
                    item.setData("  "+strList[x],QtCore.Qt.DisplayRole)
                    item.setData(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/"+self.fourCombobox.currentText(),QtCore.Qt.UserRole+1)            
                    item.setData(strList[x],QtCore.Qt.UserRole+2)                    
                    item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)                    
                    item.setChild(0,child)
                    parentItem.appendRow(item)
            else:
                dir = QtCore.QDir(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/chars")
                dir.setFilter(QtCore.QDir.Dirs|QtCore.QDir.NoDotAndDotDot)
                strList = dir.entryList()
                for x in range(0,len(strList)):
                    item = QtGui.QStandardItem(strList[x])
                    item.setCheckable(True)
                    item.setBackground(brush)                    
                    serifFont=QtGui.QFont()
                    serifFont.setBold(True)
                    item.setFont(serifFont)
                    child = QtGui.QStandardItem(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/chars")
                    item.setData("  "+strList[x],QtCore.Qt.DisplayRole)
                    item.setData(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/chars")
                    item.setData(strList[x],QtCore.Qt.UserRole+2)                    
                    item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)                    
                    item.setChild(0,child)
                    parentItem.appendRow(item)
                dir = QtCore.QDir(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/props")
                dir.setFilter(QtCore.QDir.Dirs|QtCore.QDir.NoDotAndDotDot)
                strList = dir.entryList()
                for x in range(0,len(strList)):
                    item = QtGui.QStandardItem(strList[x])
                    item.setCheckable(True)
                    item.setBackground(brush)                    
                    serifFont=QtGui.QFont()
                    serifFont.setBold(True)
                    item.setFont(serifFont)
                    child = QtGui.QStandardItem(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/props")
                    item.setData("  "+strList[x],QtCore.Qt.DisplayRole)
                    item.setData(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/props")
                    item.setData(strList[x],QtCore.Qt.UserRole+2)                    
                    item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)                    
                    item.setChild(0,child)
                    parentItem.appendRow(item)
                dir = QtCore.QDir(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/sets")
                dir.setFilter(QtCore.QDir.Dirs|QtCore.QDir.NoDotAndDotDot)
                strList = dir.entryList()
                for x in range(0,len(strList)):
                    item = QtGui.QStandardItem(strList[x])
                    item.setCheckable(True)
                    item.setBackground(brush)                    
                    serifFont=QtGui.QFont()
                    serifFont.setBold(True)
                    item.setFont(serifFont)
                    child = QtGui.QStandardItem(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/sets")
                    item.setData("  "+strList[x],QtCore.Qt.DisplayRole)
                    item.setData(self.GlobalRootPath+self.oneCombobox.currentText()+"/assets/sets")
                    item.setData(strList[x],QtCore.Qt.UserRole+2)                    
                    item.setData(QtCore.QSize(100,20),QtCore.Qt.SizeHintRole)
                    item.setChild(0,child)
                    parentItem.appendRow(item)                    
                
    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        self.curProject = settings.value("project", "1").toInt()
        self.oneCombobox.setCurrentIndex(self.curProject[0])    
        self.curType = settings.value("type", "1").toInt()
        self.fourCombobox.setCurrentIndex(self.curType[0])
        self.isOneChaked = settings.value("radio", "true").toBool()
        if self.isOneChaked:
            self.oneRadio.setChecked(True)            
        else:
            self.twoRadio.setChecked(True)       
            
        self.twoLineEdit.setText(settings.value("findString", "%").toString())
        chekStat = settings.value("checkOverride", "0").toInt()
        if chekStat[0] == 0: self.checkOverride.setCheckState(QtCore.Qt.Unchecked)
        else: self.checkOverride.setCheckState(QtCore.Qt.Checked)
        settings.endGroup()            
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", "//Server-3d/Project/").toString()
        settings.endGroup()

    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.setValue("project", self.oneCombobox.currentIndex())
        settings.setValue("findString", self.twoLineEdit.text())
        settings.setValue("type", self.fourCombobox.currentIndex())        
        settings.setValue("radio", self.oneRadio.isChecked())                
        chekStat = 0
        if self.checkOverride.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("checkOverride", chekStat)        
        settings.endGroup()        
        
ex = Window()
ex.exec_()
#if ex.exec_() == QtGui.QDialog.Accepted:
#    print "Accept"
#else:
#    print "Reject"
   
cursor.close()    
conn.close()