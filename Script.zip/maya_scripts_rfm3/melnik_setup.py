import site
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm3')
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm4')
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as mui
import ClientServer
import maya.mel as mel
import chekProject

globalAssetName=""
userId=-1
mOd=None
mSd=None

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )

def setting():
    if not cmds.optionVar( ex='Save edits'):
        cmds.optionVar( iv=('Save edits',0))
    do = cmds.optionVar( q='Save edits' )    
    app = QtGui.qApp
    widget = QtGui.QDialog()
    checBox = QtGui.QCheckBox(": save edits")
    checBox.setChecked(do) 
    layout = QtGui.QVBoxLayout()
    layoutButt = QtGui.QHBoxLayout()
    okButt = QtGui.QPushButton("Ok")
    okButt.clicked.connect(widget.accept)
    cancelButt = QtGui.QPushButton("Cancel")
    cancelButt.clicked.connect(widget.reject)
    layoutButt.addWidget(okButt)
    layoutButt.addWidget(cancelButt)
    layout.addWidget(checBox);
    layout.addLayout(layoutButt);
    widget.setLayout(layout);
    widget.resize(150, 50)
    widget.setWindowTitle('Settings')
    if widget.exec_() == QtGui.QDialog.Accepted:
        cmds.optionVar( iv=('Save edits',checBox.isChecked()))
    else:
        print "Reject"

def updateScene():
    if cmds.about(v=True)=="2014":
        OSTYPE = sys.platform
        if OSTYPE == "win32":
            OSTYPE="//Server-3d/Project"
        else:
            OSTYPE="/Server-3d/Project"
        sceneName = cmds.file(q=True, sn=True)
        print("\n\nSobakiSwitcher - updateScene: "+sceneName+"\n\n")
        rezMatch = re.match(".*SOBAKI.*",sceneName)
        if rezMatch:
            mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm4/forSOBAKI/shaveRenderman.mel\"")
            if not cmds.about(b=True):
                chekProject.setMayaProject(OSTYPE+"/SOBAKI")
                estRenderman = mel.eval("exists rman")
                curWorkSpace = mel.eval("file -q -loc -sn")
                if estRenderman:
                    mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+OSTYPE+"/SOBAKI/ -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
                    mel.eval("rman slim message \"workspace SetProject "+OSTYPE+"/SOBAKI\"")			
                    mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/renderSetup.mel\"")
                    if mel.eval("attributeExists(\"renderManGlobals\",\"rman__torattr___linearizeColors\")"):
                        cmds.setAttr("renderManGlobals.rman__torattr___linearizeColors",0)
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/FolderBatchFrameRender.mel\"")
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/FolderBatchRender.mel\"")
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/renderManBatchGenRibForLayer.mel\"")
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/renderManLaunchBatchRender.mel\"")
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/rmanWriteAlfredScript.mel\"")
                    #mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_rfm3/rmanMayaGlue.mel\"")
        else:
            mel.eval("source \""+OSTYPE+"/lib/setup/maya/maya_scripts_2014/shaveRenderman.mel\"")
            
    strVar=cmds.file(q=True, sn=True, shortName=False)
    strVar2=cmds.file(q=True, sn=True, shortName=True)
    if strVar2 == "":
        strVar2="untitled"
        strVar=""
    assetName=""
    rezSplit = re.split('(?:/assets/sets)|(?:/assets/props)|(?:/assets/chars)|(?:/scenes/[eE][pP][0-9]{2})', strVar, re.I)
    if len(rezSplit)==2:
        assetName = rezSplit[1].split("/")[1]        
    out = "MAYA::INIT::"+str(cmds.optionVar( q=('Port open')))+"::"+strVar2+"::"+strVar+"::"+assetName
    #mel.eval("setRmanVars()")
    chekProject.setLinuxDataServer()
    ClientServer.clSr.sendMessage(out)
    '''
    SSM = getMayaWindow().findChildren((QtGui.QDockWidget),"Yashka Return(CIT)")
    if SSM:
        if hasattr(SSM[0],"sceneChanged"):
            SSM[0].sceneChanged+=1
        pointer=SSM[0]
        while pointer:
            if hasattr(pointer, 'tabWidget'):
                pointer=pointer.tabWidget.currentWidget()
            else:
                break
        if hasattr(pointer,"ml_update"):
            if hasattr(SSM[0],"sceneChanged"):
                pointer.ml_update(SSM[0].sceneChanged)
    '''
    
def updateSceneBL():
    strVar=cmds.file(q=True, sn=True, shortName=False)
    strVar2=cmds.file(q=True, sn=True, shortName=True)
    if strVar2 == "":
        strVar2="untitled"
        strVar=""
    assetName=""
    rezSplit = re.split('(?:/assets/sets)|(?:/assets/props)|(?:/assets/chars)|(?:/scenes/[eE][pP][0-9]{2})', strVar, re.I)
    if len(rezSplit)==2:
        assetName = rezSplit[1].split("/")[1]        
    out = "MAYA::BL::"+str(cmds.optionVar( q=('Port open')))+"::"+strVar2+"::"+strVar+"::"+assetName
    ClientServer.clSr.sendMessage(out)
    
def sendMessage(strSend):
    ClientServer.clSr.sendMessage(strSend)
