
import maya.cmds as cmds
import maya.mel as mm
import cPickle

def an_defPosManager ():
    win = "an_setDefPos_win"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Default position manager.v01", s=True, rtf=True   )
    cmds.columnLayout (adj=True, co=("both", 3))
    cmds.frameLayout  (cll=1, label="Select controllers by suffix:", borderStyle="etchedIn")
    cmds.textField("MaskTF", tx="_CT")
    cmds.button (l="Select all controllers " , c= "an_selAllCt()")
    cmds.setParent( '..' )
    cmds.separator( style='none', h=10)
    cmds.frameLayout  (cll=1, label="Default lib path:", borderStyle="etchedIn")
    vEnv = mm.eval("getenv (\"HOME\")")
    cmds.textField("PathTF", tx=vEnv)
    cmds.button (l="Add path", c="an_addPath()"  )
    cmds.setParent( '..' )
    cmds.separator( style='none', h=10)
    cmds.frameLayout  (cll=0, label="Record attribut values", borderStyle="etchedIn")
    cmds.rowColumnLayout (nc=2, cw=[(1, 100), (2, 100)] )
    cmds.button (l="Record to file" , c= "an_actions (\"-recToFile\")")
    cmds.button (l="Record to control", c= "an_actions (\"-recToCT\")")
    cmds.button (l="Set from file" , c= "an_actions (\"-setFromFile\")")
    cmds.button (l="Set from control" , c= "an_actions (\"-setFromCT\")")
    cmds.showWindow (win);

an_defPosManager ()
#########################################################################dobovlyaem put v menyu biblioteki
def an_addPath ():
    vPathName = cmds.fileDialog2(fileMode=2, caption="Add path")
    cmds.textField("PathTF", e=True, tx=vPathName[0])

#########################################################################glavnaya procedura
def an_actions (vActions):
    vObjts =  cmds.ls (sl = True)
    for vObj in vObjts:
        if vActions == "-recToCT": an_recordToControl(vObj)
        if vActions == "-setFromCT": an_setFromControl(vObj)
    if vActions == "-recToFile" : an_recordToFile()
    if vActions == "-setFromFile": an_setFromFile()

##########################################################################ustanovka kt iz fajla

def an_setFromFile():
    vDir = cmds.textField("PathTF", q=True, tx=True)
    vFileName = cmds.fileDialog2( fileMode=1, caption="Load position", dir=vDir )
    r = open(vFileName[0], 'r')
    rData = cPickle.load(r)
    r.close()

    vObjts =  cmds.ls (sl = True)
    vPrefix = ""
    if vObjts:                                #videlenie est
        if  ":" in vObjts[0] :      #ref
            vPrefix = vObjts[0].split(":")[0]+":"
        else:vPrefix = ""
    for vEachCt  in rData:
            for vAttr, val in zip(vEachCt[1], vEachCt[2]):
                #print vPrefix+vEachCt[0]
                if an_chekAttr(vPrefix+vEachCt[0], vAttr):
                    if cmds.nodeType (vPrefix+vEachCt[0])== "transform":
                        cmds.setAttr (vPrefix+vEachCt[0]+"."+vAttr, val)

 ##########################################################################proverka kontrollera i obekta na sootvetvstvie vxodyashhim dannym
def an_chekAttr(vInObj, vInAttr):
    if not cmds.objExists(vInObj): return 0
    v_out = 0
    if vInAttr in cmds.listAttr(vInObj, k=True, u=True, s=True, v=True):
        v_out = v_out+1
        if cmds.connectionInfo(vInObj+"."+vInAttr,isDestination=True): v_out = 0
    return  v_out
 #########################################################################zapisyvaet kt v fajl

def an_recordToFile():
    result = []
    vObjts =  cmds.ls (sl = True)
    for vObj in vObjts:
        vAttr = cmds.listAttr(vObj, k=True, u=True, s=True, v=True)         #poluchaem spisok atributov
        try:
            vData = []
            for v_each in vAttr :     #poluchaem spisok znachenij etix atributov
                    vVal = cmds.getAttr  (vObj +"."+v_each)
                    vData.append(vVal)
            result.append([an_killNC(vObj), vAttr, vData])
        except TypeError: pass
    vDir = cmds.textField("PathTF", q=True, tx=True)
    vFileName = cmds.fileDialog2(sff = "*.dat" , fileMode=0, caption="Save position", dir=vDir )   #zapisyvaem v fajl
    f = open(vFileName[0], 'w')
    cPickle.dump(result , f )
    f.close()

def an_killNC(v_seursNane): #ubivaet vse nejmspejsy v vxodyazhix imenax
    if  ":" in v_seursNane :  return v_seursNane.split(":")[-1]
    else: return v_seursNane
 ############################################################################  ustanavlivaet kt iz atributa

def an_setFromControl(vObj):   #vObj="head_CT"
    if mm.eval("attributeExists \"defValues\""+vObj):
        vString = cmds.getAttr  (vObj+".defValues")
        vData = cPickle.loads(str(vString))
        try:
            for vAttr, val in zip(vData[1], vData[2]):
                if an_chekAttr(vData[0], vAttr):
                    cmds.setAttr (vData[0]+"."+vAttr, val)
        except TypeError: pass

 ##########################################################################################################  zapisyvaet kt v atribut

def an_recordToControl(vObj):
    if not  mm.eval("attributeExists \"defValues\""+vObj):            #zaprashivaem est li atribut defvalues?
        cmds.addAttr   (vObj, ln="defValues", dt="string", keyable = False)   #esli net sozdaem
    vAttr = cmds.listAttr(vObj, k=True, u=True, s=True, v=True)         #poluchaem spisok atributov
    vData = []
    try:
        for each in  vAttr :                                #poluchaem spisok znachenij etix atributov
                vVal = cmds.getAttr  (vObj+"."+each)
                vData.append(vVal)
    except TypeError: pass
    vString = cPickle.dumps([vObj, vAttr, vData])                   #upakovyvaem vse dannye v stroku
    cmds.setAttr ( vObj+".defValues", vString, type="string" )           #zapisyvaem v atribut

 ############################################################################


def an_selAllCt():             # select all controllers in scen
    v_Sfx = cmds.textField("MaskTF", q=True, tx=True)
    vObjts =  cmds.ls (sl = True)
    if vObjts:                                #videlenie est`
        if  ":" in vObjts[0] :      #ref
            vPrefix = vObjts[0].split(":")[0]
            cmds.select (vPrefix+":*"+v_Sfx)
        else: cmds.select ("*"+v_Sfx) #not ref
    else :                                     #videleniya net
        try: cmds.select ("*"+v_Sfx)
        except ValueError: cmds.select ("*:*"+v_Sfx)



























