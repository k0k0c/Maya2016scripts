"""
Main Procedure: 
    an_scriptManager()

Creation Date:  
    March 20, 2014

Authors: 
    Belyaev Andrey 
    andreikin@mail.ru
    www.3drigging.com  

Description:
    The script creates a menu "Scripts", in accordance with the structure of folders with scripts, and the files themselves. 
    The root path specified in your script.

Installation:

    1. Copy the [an_scriptManager] to your local user/scripts folder
		 		example: ..\my documents\maya\scripts\ 
	2. Edit variable in the text of the script, that defines the path to the root folder with scripts
	2. Start Maya 
	4. Type:    import an_scriptManager
                from an_scriptManager import *
	   into the Maya Script Editor (Pithon mod), and hit enter.
				  
Comments or suggestions? E-mail me!!!
Good luck!!!

*************************************************************************************************************************	
 version History  
*************************************************************************************************************************
	v2.0
	- Add script description.
	- Add ability to work with Python scripts
	- Add comments in the code.
 
*************************************************************************************************************************
 Modify at your own risk 
"""

import maya.mel as mm
import maya.cmds as cmds
import os
import sys

def an_scriptManager():
    vPythonMenu = 'PyMenu'
    if cmds.menu (vPythonMenu, exists=True):  cmds.deleteUI (vPythonMenu)
    cmds.menu (vPythonMenu, l='Scripts', p='MayaWindow', tearOff=True)
    vDirPath = "//SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm3/for_rigging/"   	    
    
    an_checkContent (vDirPath, vPythonMenu) 
    
    print "////////////////////////////////////////////////////////////////////////////////" 
    print "   "
    print "              Script Manager successfully started  "
    print "   "
    
    an_sourceProcedures (vDirPath)  
    cmds.menuItem (divider=True,  p=vPythonMenu, bld=True)
    cmds.menuItem (l="--refresh--", p=vPythonMenu, c= "an_scriptManager()")
    print "   "
     
    print "////////////////////////////////////////////////////////////////////////////////" 
    

    path = list(sys.path)
    sys.path.insert(0, vDirPath+"procedures/")    
    

def an_checkContent (vDirPath, vMenuName):
    vContent = cmds.getFileList(folder=vDirPath )   
    for vEach in [obj for obj in vContent if not '.' in obj]: #prohodim po vsem papkam
        if not 'procedures' in vEach:
            cmds.menuItem ( vEach+"Mn2", l=vEach, tearOff=True, sm=True, p=vMenuName)
            vEachContent = cmds.getFileList(folder=vDirPath+vEach+'/')
            if vEachContent: an_checkContent (vDirPath+vEach+'/', vEach+"Mn2")
    cmds.menuItem (divider=True,  p=vMenuName) 
           
    for vEach in [obj for obj in vContent if '.py' in obj]: #prohodim po vsem pyhon failam
        if not '.pyc' in vEach: cmds.menuItem ( vEach, l=vEach, p=vMenuName, c="an_pyComand('"+vEach+"', '"+vDirPath+"')") 
    
    for vEach in [obj for obj in vContent if '.mel' in obj]: #prohodim po vsem mel failam
        cmds.menuItem ( vEach, l=vEach, p=vMenuName , c= "an_melComand('"+vEach+"', '"+vDirPath+"')") 
        
def an_pyComand(vScriptName, vDirPath):
    v_sPath = list(sys.path)  
    sys.path.append(vDirPath) 
    vScriptName = vScriptName.split('.')[0]
    v_namespace = {}
    execfile (vDirPath+vScriptName+'.py', v_namespace)
    globals().update(v_namespace)


def an_melComand(vScriptName, vDirPath):
    vScriptName = vScriptName.split('.mel')[0]
    mm.eval( "source \""+vDirPath+vScriptName+".mel\"") 
    mm.eval(vScriptName) 
 
def an_sourceProcedures (vDirPath):
    vDirPath = vDirPath+"procedures/"
    vContent = cmds.getFileList(folder=vDirPath ) 
    for  vItem in vContent:
        if '.mel' in vItem:
            try:
                mm.eval( "source \""+vDirPath+vItem+"\"")   
            except :
                print "Maybe a mistake in the " + vItem

        if '.py' in vItem and not '.pyc' in vItem :  
            module_name = vItem.split('.')[0]
            path = list(sys.path)
            sys.path.insert(0, vDirPath)
            try:
                module = __import__(module_name)
            except :
                print "Maybe a mistake in the " + vItem 
            finally:
                sys.path[:] = path # restore
                globals().update(vars(module))
 
an_scriptManager()