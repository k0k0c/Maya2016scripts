import maya.mel as mm
import maya.cmds as cmds 
 	
def an_faceRig():	 
    win = "an_faceRig_win" 
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Face rigging system.v01", rtf=True ,menuBar=True )
    cmds.menu (label="Edit" )
    cmds.menu (label="Help" )   		 
    vCLayout =cmds.columnLayout()
    vRCLayout = cmds.rowColumnLayout( numberOfColumns=2, columnWidth=[(1, 123), (2, 500)] ) 
    ############
    an_buttons()                                                                     ################# knopki
    cmds.setParent(vRCLayout)
 
    ############
    form = cmds.formLayout()                                                          ################# vkladki
    tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=5)
    cmds.formLayout( form, edit=True, attachForm=((tabs, 'top', 0), (tabs, 'left', 0), (tabs, 'bottom', 0), (tabs, 'right', 0)) )
    
    child1 = cmds.rowColumnLayout(numberOfColumns=3)  #######  vkladka an_tabThreeCT
    an_tabThreeCT()
    cmds.setParent( '..' )
    
    child2 = cmds.rowColumnLayout(numberOfColumns=3)   #######  vkladka an_tabThreeCT
    an_tabOneCT()
    cmds.setParent( '..' )
    
    cmds.tabLayout( tabs, edit=True, tabLabel=((child1, 'Three-CT system'), (child2, 'One-CT system')) )
    ###########
    cmds.setParent(vCLayout )
    frame = cmds.frameLayout( labelVisible=False, w=623 )
    cmds.helpLine()
    cmds.showWindow (win)
    
    for vEach in ["10", "0"]:   cmds.textField("TF"+vEach, e=True, text="emotCorr_bs")	
 
##############################################################################################################
 
def an_tabOneCT(): 
    vBodyPartForm = cmds.formLayout ()
    t0 = cmds.text (l="Input blend node:") 
    t1 = cmds.text (l="Input corrective blends geometry:") 
    
    b0 = an_butFildGrp2("TF10", 30, 170)
    b1 = an_butFildGrp2("TF11", 80, 5)
    b2 = an_butFildGrp2("TF12", 80, 170)
    b3 = an_butFildGrp2("TF13", 80, 340)
    
    b4 = an_butFildGrp2("TF14", 130, 5)
    b5 = an_butFildGrp2("TF15", 130, 340)
    b6 = an_butFildGrp2("TF16", 180, 5)
    b7 = an_butFildGrp2("TF17", 180, 170)
    b8 = an_butFildGrp2("TF18", 180, 340)
    b9 = an_butFildGrp2("TF19", 240, 170)
 
    t2 = cmds.text (l="Input controller:")
    bf1 = cmds.button(w=150, l="Break connection", ann = "Break connection", c="an_delExpressiuon ( cmds.textField(\"TF19\", q=True, text=True)  )")
    bf2 = cmds.button(w=150, l="Create connection", ann ="Create connection", c="an_tabOneExpression()")
    
    cmds.formLayout( vBodyPartForm, edit=True, attachForm=b0+b1+b2+b3+b4+b5+b6+b7+b8+b9 )
    cmds.formLayout( vBodyPartForm, e=True, attachForm=[(t0, 'top', 10),    (t0, 'left', 20),
                                                        (t1, 'top', 60),    (t1, 'left', 20),
                                                        (t2, 'top', 220),   (t2, 'left', 20),     
                                                        (bf1, 'top', 290),  (bf1, 'left', 186),         
                                                        (bf2, 'top', 290),  (bf2, 'left', 340)         ]  )
    cmds.setParent( '..')
 
 
def an_tabThreeCT(): 

    vBodyPartForm = cmds.formLayout ()
    t0 = cmds.text (l="Input blend node:") 
    t1 = cmds.text (l="Input corrective blends geometry:") 
    
    b0 = an_butFildGrp2("TF0", 30, 170)
    b1 = an_butFildGrp2("TF1", 80, 170)
    b2 = an_butFildGrp2("TF2", 120, 70)
    b3 = an_butFildGrp2("TF3", 120, 250)
    b4 = an_butFildGrp2("TF4", 160, 5)
    b5 = an_butFildGrp2("TF5", 160, 170)
    b6 = an_butFildGrp2("TF6", 160, 340)
    b7 = an_butFildGrp2("TF7", 230, 5)
    b8 = an_butFildGrp2("TF8", 230, 170)
    b9 = an_butFildGrp2("TF9", 230, 340)
 
    t2 = cmds.text (l="Input controllers:")
    bf1 = cmds.button(w=150, l="Break connection", ann = "Break connection", c="an_delExpressiuon ( cmds.textField(\"TF9\", q=True, text=True)  )")
    bf2 = cmds.button(w=150, l="Create connection", ann ="Create connection", c="an_tabThreeExpression()")
    
    cmds.formLayout( vBodyPartForm, edit=True, attachForm=b0+b1+b2+b3+b4+b5+b6+b7+b8+b9 )
    cmds.formLayout( vBodyPartForm, e=True, attachForm=[(t0, 'top', 10),    (t0, 'left', 20),
                                                        (t1, 'top', 60),    (t1, 'left', 20),
                                                        (t2, 'top', 200),   (t2, 'left', 20),     
                                                        (bf1, 'top', 290),  (bf1, 'left', 186),         
                                                        (bf2, 'top', 290),  (bf2, 'left', 340)         ]  )
    cmds.setParent( '..')
 

 
def an_buttons():
    cmds.columnLayout()
    cmds.frameLayout( label='Additional tools:', borderStyle='etchedOut',height=350,)
    cmds.columnLayout( )
    cmds.button(w=120, l="Mirror bsh", c="an_mirrowBshUi()")
    cmds.button(w=120, l="Insert offset", c="an_insertOffset()")
    cmds.button(w=120, l="Corective bsh", c="an_correctivBshUi()")
    cmds.button(w=120, l="Attribute Mix", c="an_attrMixTools()")
    cmds.button(w=120, l="Connect similar attr", c="an_connectSimilarAttr()", ann="select the source object and then target")  
    cmds.button(w=120, l="BSh manager", c="an_bshManager()")   
 
def an_butFildGrp2(vFildName, vTop, vLeft):  ### Procedura cozdaet pole dlya kontrollera..
    vRCLayout = cmds.rowColumnLayout ( numberOfColumns=2, columnWidth=[(1, 120), (2, 30)]) 
    vTextField = cmds.textField(vFildName).split("|")[-1]
    cmds.button (label='<<', c= "cmds.textField (\""+vTextField+"\", e=True, text= cmds.ls (sl=True)[0])", ann = "add selection")
    cmds.setParent( '..')
    return [(str(vRCLayout.split("|")[-1]), 'top', vTop), (str(vRCLayout.split("|")[-1]), 'left', vLeft)] 
   
 
  
def an_tabThreeExpression():
    vInput = []
    for vIdFild in xrange (0,10): vInput.append(cmds.textField("TF"+str(vIdFild), q=True, text=True) )
    vCtrl = vInput [-3:len(vInput)]
    if not all(vEachCt for vEachCt in vCtrl):  cmds.error (" Please input controllers names!")                                                          
    vBsh =  vInput [1:-3]                                                     
    vBshName = vInput[0]  
        # expression Text: 
    vS1= '$ctA='+vCtrl[0]+".ty"+';\n'
    vS2= '$ctB='+vCtrl[1]+".ty"+';\n'  
    vS3= '$ctC='+vCtrl[2]+".ty"+';\n' 
    vS4= '$bothIn=clamp(0,1,($ctA+$ctB)-1);\n'  
    vS5= '$bothOut = clamp(0,1,($ctC+$ctB)-1);\n'
    vS6= '$all = clamp(0,1,($bothIn+$bothOut)-1);\n'
    vS7= '$ctA=$ctA-$bothIn;\n'  
    vS8=  '$ctB=$ctB-(clamp(0,1,($bothIn+$bothOut)));\n'
    vS9=  '$ctC=$ctC-$bothOut;\n'
    vS10= '$bothIn=$bothIn-$all;\n'
    vS11= '$bothOut=$bothOut-$all;\n' 
    
    vS12= vBshName+"."+vBsh[3]+'=$ctA;\n' if vBsh[3] else ""
    vS13= vBshName+"."+vBsh[4]+'=$ctB;\n' if vBsh[4] else ""
    vS14= vBshName+"."+vBsh[5]+'=$ctC;\n' if vBsh[5] else ""
    vS15= vBshName+"."+vBsh[1]+'=$bothIn;\n' if vBsh[1] else ""
    vS16= vBshName+"."+vBsh[2]+'=$bothOut;\n' if vBsh[2] else ""
    vS17= vBshName+"."+vBsh[0]+'=$all;\n'  if vBsh[0] else ""

    an_delExpressiuon (vCtrl[2])    
    cmds.expression( s= vS1+vS2+vS3+vS4+vS5+vS6+vS7+vS8+vS9+vS10+vS11+vS12+vS13+vS14+vS15+vS16+vS17 )

##############################################################################################################

#def an_bshCheker():
    
 

 
##############################################################################################################

def an_tabOneExpression():
   
    vInput = []
    for vIdFild in xrange (10,20): vInput.append(cmds.textField("TF"+str(vIdFild), q=True, text=True) )
             
    vCtrl = vInput [-1]
    if not vCtrl :  cmds.error (" Please input controllers names!")                                                                       
    vBsh =  vInput [1:-1]                                                     
    vBshName = vInput[0] 
     
      # expression Text:  
    vS1= '$CtTx='+vCtrl+".tx"+';\n'       
    vS2= '$CtTy='+vCtrl+".ty"+';\n'          
    vS3= '$CtTu = ($CtTy+$CtTx)/2 ;\n'
    vS4= '$CtTv = ($CtTy-$CtTx)/2 ;\n' 
     
    vS5= 'float $bsh_y;\n'        ##             
    vS6= 'if (($CtTy-abs($CtTx)) > 0) $bsh_y = $CtTy-abs($CtTx);\n' 
    vS7= 'else  $bsh_y = 0;\n' 
    vS8= 'float $bsh_u; \n'       ##       
    vS9= 'if (($CtTu-abs($CtTv)) > 0) $bsh_u = $CtTu-abs($CtTv);\n' 
    vS10= 'else  $bsh_u = 0;\n' 
    vS11= 'float $bsh_x;\n'       ##         
    vS12= 'if (($CtTx-abs($CtTy)) > 0) $bsh_x = $CtTx-abs($CtTy);\n' 
    vS13= 'else  $bsh_x = 0;\n' 
    vS14= 'float $bsh_vMin; \n'    ##             
    vS15= 'if ((-1*$CtTv -abs($CtTu)) > 0) $bsh_vMin = (-1*$CtTv -abs($CtTu));\n' 
    vS16= 'else  $bsh_vMin = 0;\n' 
    vS17= 'float $bsh_yMin; \n'     ##            
    vS18= 'if ((-1*$CtTy -abs($CtTx)) > 0) $bsh_yMin = (-1*$CtTy -abs($CtTx));\n' 
    vS19=  'else  $bsh_yMin = 0;\n' 
    vS20= 'float $bsh_uMin; \n'    ##              
    vS21= 'if ((-1*$CtTu -abs($CtTv)) > 0) $bsh_uMin = (-1*$CtTu -abs($CtTv));\n'    
    vS22= 'else  $bsh_uMin = 0;\n' 
    vS23= 'float $bsh_xMin;\n'     ##             
    vS24= 'if ((-1*$CtTx -abs($CtTy)) > 0) $bsh_xMin = (-1*$CtTx -abs($CtTy));\n' 
    vS25= 'else  $bsh_xMin = 0;\n' 
    vS26= 'float $bsh_v;\n'   ##              
    vS27= 'if (($CtTv-abs($CtTu)) > 0) $bsh_v = $CtTv-abs($CtTu);\n' 
    vS28= 'else  $bsh_v = 0;\n'         
    
    vS29= (vBshName+"."+vBsh[1]+'=$bsh_y;\n')  if vBsh[1] else ""
    vS30= vBshName+"."+vBsh[2]+'=$bsh_u;\n'    if vBsh[2] else ""  
    vS31= vBshName+"."+vBsh[4]+'=$bsh_x;\n'    if vBsh[4] else ""
    vS32= vBshName+"."+vBsh[7]+'=$bsh_vMin;\n' if vBsh[7] else ""  
    vS33= vBshName+"."+vBsh[6]+'=$bsh_yMin;\n' if vBsh[6] else ""
    vS34= vBshName+"."+vBsh[5]+'=$bsh_uMin;\n' if vBsh[5] else ""
    vS35= vBshName+"."+vBsh[3]+'=$bsh_xMin;\n' if vBsh[3] else ""
    vS36= vBshName+"."+vBsh[0]+'=$bsh_v;\n'    if vBsh[0] else ""
     
    an_delExpressiuon (vCtrl)       
    cmds.expression( s= vS1+vS2+vS3+vS4+vS5+vS6+vS7+vS8+vS9+vS10+vS11+vS12+vS13+vS14+vS15+vS16+vS17+vS18+vS19+vS20+vS21+vS22+vS23+vS24+vS25+vS26+vS27+vS28+vS29+vS30+vS31+vS32+vS33+vS34+vS35+vS36 )
an_faceRig()

 
def an_delExpressiuon (vCtrl):
    if cmds.connectionInfo (vCtrl+'.ty' , isSource = True ): #esli expression est to snosim ego 
        vCon = cmds.connectionInfo (vCtrl+'.ty' , destinationFromSource = True )[0] 
        cmds.delete  (vCon.split('.')[0])
 

def an_attrMixTools():
    win = "an_mixTwoAttr" 
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Attribut mix system.v02", rtf=True ,menuBar=True )
    cmds.menu (label="Edit" )
    cmds.menu (label="Help" )   		 
    vCLayout =cmds.columnLayout()     
    for vFild, vI in zip (["Input A:  ", "Input B:  ", "output Attr:  ", "mix Attr:  "], range(0,4)):
         vRCLayout = cmds.rowColumnLayout ( numberOfColumns=4, columnWidth=[(1, 80), (2, 180), (3, 90), (4, 90)]) 
         cmds.text (l=vFild, align="right")
         cmds.textField ("mixTF"+str(vI))
         cmds.button (label='<- add to field', c="an_adAttrAndChangField(\"mixTF"+str(vI)+"\", \"-addAttr\" )" ) 
         cmds.button (label='add to object ->', c= "an_adAttrAndChangField(\"mixTF"+str(vI)+"\", \"-field\" )")
         cmds.setParent( '..')
    cmds.separator(h=3) 
    cmds.rowColumnLayout ( numberOfColumns=3, columnWidth=[(1, 80), (2, 180  ), (3, 180)])
    cmds.text (l="", align="right") 
    cmds.button (label="Connect A to B", c= "cmds.connectAttr(  cmds.textField (\"mixTF0\", q=1, text=1),  cmds.textField (\"mixTF1\", q=1, text=1))" )
    cmds.button (label="Blend A and B", c= "an_DoMixTwoAttr ()")
    cmds.showWindow (win)


def an_DoMixTwoAttr ():
    vNodName =  cmds.createNode  ("blendTwoAttr")
    vInputA = (cmds.textField ("mixTF0", q=1, text=1))
    vInputB = (cmds.textField ("mixTF1", q=1, text=1))
    
    if an_type(vInputA) == "namber": cmds.setAttr (vNodName+".input[0]", float(vInputA)) 
    if an_type(vInputA) == "string": cmds.connectAttr (vInputA, vNodName+".input[0]" )
    
    if an_type(vInputB) == "namber": cmds.setAttr (vNodName+".input[1]", float(vInputB)) 
    if an_type(vInputB) == "string": cmds.connectAttr (vInputB, vNodName+".input[1]" )
    
    cmds.connectAttr (cmds.textField ("mixTF3", q=1, text=1), vNodName+".attributesBlender"   )
    cmds.connectAttr ( vNodName+".output", cmds.textField ("mixTF2", q=1, text=1)   )

def an_type(s):
    try:
        if s==float(s): return"namber"
        else: return "namber"
    except  ValueError:
        return "string"
 
def an_adAttrAndChangField( vField, vAct ):   #vAct =  "-addAttr" , "-field"
    if (vAct == "-addAttr"): 
        vAttr = cmds.channelBox ("mainChannelBox", q=True,  sma=True)
        if   len(str(vAttr))==4  : cmds.error ( "Please select attribute in channel box !")
        vText= cmds.ls (sl=True)[0]+"."+vAttr[0]
        cmds.textField (vField, e=True, text= vText)
    if (vAct == "-field"): 
        vAttr = cmds.textField (vField, q=1, text=1)
        if   len(vAttr)== 0  : cmds.error ( "Please input attribute!")
        obj = cmds.ls (sl=True)
        if   len(obj)== 0  : cmds.error ( "Please select objekt!")
        cmds.addAttr( ln = vAttr, k=1 )
        cmds.textField (vField, e=True, text= obj[0]+"."+vAttr)
######################################################################################################################################################################################################


def an_correctivBshUi():
    win = "an_corrBsh" 
    vWidth = 180
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Corrective bsh tool.v01", rtf=True  ) 
    vCLayout =cmds.columnLayout()     
     
    cmds.frameLayout( label='Step 1:', borderStyle='etchedOut', bgc= [0, 0, 0])
    cmds.text("  Enter the skinned object for which\n you want to make a correction form")
    cmds.columnLayout( )
    cmds.textField("an_baseGeoTF", w=vWidth) 
    cmds.button(w=vWidth, l="Add geometry", c= "cmds.textField (\"an_baseGeoTF\", e=True, text= cmds.ls (sl=True)[0])")
    cmds.setParent( vCLayout)
    cmds.separator(height=20, style='none')
     
    cmds.frameLayout( label='Step 2:', borderStyle='etchedOut', bgc= [0, 0, 0] )
    cmds.columnLayout( )
    cmds.text("  Deform skinned object to the  \n    desired form and generate the\n blank for bsh")
    cmds.button(w=vWidth, l="Generate blank", c="an_makeBlank()" )
    cmds.setParent( vCLayout)
    cmds.separator(height=20, style='none')
     
    cmds.frameLayout( label='Step 3:', borderStyle='etchedOut' , bgc= [0, 0, 0])
    cmds.columnLayout( )
    cmds.text("  Deform blank to the desired form\n and generate corrective bsh")
    cmds.textField("an_blankGeoTF", w=vWidth) 
    cmds.button(w=vWidth, l="Add geometry blank",  c= "cmds.textField (\"an_blankGeoTF\", e=True, text= cmds.ls (sl=True)[0])")
    cmds.separator(height=5, style='none')
    cmds.checkBoxGrp("delBlCBG", columnWidth2=[30, 165], numberOfCheckBoxes=1, label='    ', label1='Delete blank', v1=True)
    cmds.separator(height=5, style='none')
    cmds.button(w=vWidth, l="Generate corrective bsh", c="an_makeCorrectiveBsh()"  )
    cmds.setParent( '..')
     
    cmds.frameLayout( label='Step 4:', borderStyle='etchedOut', bgc= [0, 0, 0])
    cmds.text("  Enter the bsh node and connect\n  selected geometry  ")
    cmds.columnLayout( )
    cmds.textField("an_bshTF", w=vWidth)
    cmds.button(w=vWidth, l="Add bsh", c= "cmds.textField (\"an_bshTF\", e=True, text= cmds.ls (sl=True)[0])") 
    cmds.button(w=vWidth, l="Connect selected to bsh",  c="an_addCorrectiveToBsh()")
    cmds.setParent( vCLayout)
    cmds.showWindow ()
 
def an_addCorrectiveToBsh():
    vBlendShape = cmds.textField ('an_bshTF', q=True, text =True )
    vObj = cmds.textField ('an_baseGeoTF', q=True, text =True )
    vIndexCount = cmds.blendShape( vBlendShape, q=True, weightCount=True )
    cmds.blendShape( vBlendShape, edit=True, t=(vObj, vIndexCount, cmds.ls (sl=True)[0], 1.0) )

def an_makeCorrectiveBsh():
    vObjBlank = cmds.textField ('an_blankGeoTF', q=True, text =True )
    vObjNegativ = vObjBlank.replace('_blank','_negativ')
    vObj = cmds.textField ('an_baseGeoTF', q=True, text =True )
    vList =  cmds.listHistory (vObj, pdo=True)
    skinClaster =  cmds.ls (vList, type="skinCluster") [0] 
    vBlend = cmds.blendShape(vObjNegativ, vObjBlank, vObj, foc=True, tc=True, w=[(0, -1.0), (1, 1.0)])[0]  
    cmds.setAttr (skinClaster+".envelope", 0)
    
    vDup = cmds.duplicate(vObj, name= vObj+'_corrective'  , rr=True )[0] 
    for vEach in ['tx', "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"]:  cmds.setAttr (vDup+"."+vEach, lock=False )
    cmds.setAttr (skinClaster+".envelope", 1)
    cmds.delete (vBlend)
    
    vDupShape = cmds.listRelatives(vDup,s=1)
    vXSize = ((cmds.getAttr (vDupShape[0]+".boundingBoxMaxX"))- (cmds.getAttr (vDupShape[0]+".boundingBoxMinX")))*2
    cmds.setAttr (vDup+".tx", vXSize)
    if cmds.checkBoxGrp("delBlCBG",q=True, v1=True):
        cmds.delete (vObjNegativ, vObjBlank)

 
def an_makeBlank():
    vObj = cmds.textField ('an_baseGeoTF', q=True, text =True )
    vDup = cmds.duplicate(vObj, name= vObj+'_blank'  , rr=True )[0] 
    for vEach in ['tx', "ty", "tz", "rx", "ry", "rz", "sx", "sy", "sz"]:  cmds.setAttr (vDup+"."+vEach, lock=False ) 

    vCopy = cmds.duplicate(vDup, name= vObj+'_negativ'  , rr=True ) [0] 
    cmds.setAttr (vCopy+".v", 0)
    
    vDupShape = cmds.listRelatives(vDup,s=1)
    vXSize = (cmds.getAttr (vDupShape[0]+".boundingBoxMaxX"))- (cmds.getAttr (vDupShape[0]+".boundingBoxMinX"))
    cmds.setAttr (vDup+".tx", vXSize)
    cmds.select (vDup) 
    cmds.textField ("an_blankGeoTF", e=True, text= cmds.ls (sl=True)[0])
 
######################################################################################################################################################################################################

 
def an_insertOffset():
    vWin = "an_insertOffsetWin"
    if cmds.window (vWin, exists=True): cmds.deleteUI ( vWin, window=True )
    cmds.window  (vWin, t="Insert Offset  v13")
    cmds.columnLayout()
    cmds.separator   (h=6 )
    cmds.radioButtonGrp("PosRBG", label='Insert position:    ', labelArray2=['before', 'after' ], numberOfRadioButtons=2 )
    cmds.radioButtonGrp("OperRBG", label='Operation:    ', labelArray2=['add to', 'multiply' ], numberOfRadioButtons=2 )
    cmds.rowColumnLayout( numberOfColumns=2, columnWidth=[(1, 180), (2, 180)] )
    cmds.button( label='delete connection' )
    cmds.button( label='make connection', command= "an_makeInsertOffset()" )
    cmds.showWindow( vWin )

 
def an_makeInsertOffset():
    if (cmds.radioButtonGrp ("PosRBG",q=True, sl=True)==1):  an_insertOffsetBefore()     #esli vibrano before  
    if (cmds.radioButtonGrp ("PosRBG",q=True, sl=True)==2):  an_insertOffsetAfter()     # esli vibrano after 

 
def an_insertOffsetBefore():
    vObj =  cmds.ls (sl = True)
    vAttr = cmds.channelBox  ('mainChannelBox', q = True, sma = True )
    cmds.addAttr   ( ln=vAttr[0]+'Offset', keyable= True )
    vCon = cmds.connectionInfo (vObj[0]+'.'+vAttr[0], sourceFromDestination = True )

    if (cmds.radioButtonGrp ("OperRBG",q=True, sl=True)==1):  #esli vibrano clozhenie
        vPMA =cmds.createNode ('plusMinusAverage', n = vObj[0]+vAttr[0]+'_OfsMDV')
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0]+'Offset', vPMA+'.input1D[0]', force=True)
        cmds.connectAttr ( vCon, vPMA+'.input1D[1]', force=True )
        cmds.connectAttr ( vPMA+'.output1D', vObj[0]+'.'+vAttr[0], force=True )

    if (cmds.radioButtonGrp ("OperRBG",q=True, sl=True)==2):  #esli vibrano umnozhenie
        vPMA =cmds.createNode ('multiplyDivide', n = vObj[0]+vAttr[0]+'_OfsMDV')
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0]+'Offset', vPMA+'.input2X', force=True)
        cmds.connectAttr ( vCon, vPMA+'.input1X', force=True )
        cmds.connectAttr ( vPMA+'.outputX', vObj[0]+'.'+vAttr[0], force=True )
    cmds.select(vObj[0])

 
def an_insertOffsetAfter():
    vObj =  cmds.ls (sl = True)
    vAttr = cmds.channelBox  ('mainChannelBox', q = True, sma = True )
    cmds.addAttr   ( ln=vAttr[0]+'Offset', keyable= True )
    vCon = cmds.connectionInfo (vObj[0]+'.'+vAttr[0], destinationFromSource = True )

    if (cmds.radioButtonGrp ("OperRBG",q=True, sl=True)==1):  #esli vibrano clozhenie
        vPMA =cmds.createNode ('plusMinusAverage', n = vObj[0]+vAttr[0]+'_OfsMDV')
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0], vPMA+'.input1D[0]', force=True)
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0]+'Offset', vPMA+'.input1D[1]', force=True)
        for vEach in vCon:  cmds.connectAttr ( vPMA+'.output1D', vEach, force=True )

    if (cmds.radioButtonGrp ("OperRBG",q=True, sl=True)==2):   #esli vibrano umnozhenie
        vPMA =cmds.createNode ('multiplyDivide', n = vObj[0]+vAttr[0]+'_OfsMDV')
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0], vPMA+'.input1X', force=True)
        cmds.connectAttr ( vObj[0]+'.'+vAttr[0]+'Offset', vPMA+'.input2X', force=True)
        for vEach in vCon:  cmds.connectAttr ( vPMA+'.outputX', vEach, force=True )
    cmds.select(vObj[0])

######################################################################################################################################################################################################


def an_mirrowBshUi():
    win = "an_mirBsh"
    vWidth = 180
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Mirrow BlandShape tool.v01", rtf=True  )
    vCLayout =cmds.columnLayout()
    cmds.separator(height=5, style='none')
    cmds.text("    Select left (right) target, then \n select base object ")
    cmds.separator(height=5, style='none')
    cmds.text("MaxDistance: ")
    cmds.separator(height=5, style='none')
    cmds.textField("an_mDistTF", w=vWidth, text = "0.001")
    cmds.separator(height=13, style='none')
    cmds.checkBoxGrp("delHiCBG", columnWidth2=[30, 165], numberOfCheckBoxes=1, label='  ', label1='Delete history', v1=True)
    cmds.separator(height=10, style='none')
    cmds.button(w=vWidth, l="Mirrow BlandShape", c="an_doMirrowBsh()"  )
    cmds.showWindow ()
 

 

def an_doMirrowBsh():

    vHistory = cmds.checkBoxGrp("delHiCBG", q=True, v1=True)
    vMaxDistance = cmds.textField("an_mDistTF", q=True, text=True)
    do_an_MirrowBlandShape(cmds.ls (sl=True)[1], cmds.ls (sl=True)[0], vHistory, vMaxDistance)
 

def do_an_MirrowBlandShape(vBaseObj, vBlend, vHistory, vMaxDistance):

    vOppositeBlend = cmds.duplicate   (vBaseObj, n='opozit_'+vBlend)# cozdaet kopiu bazovogo ob`ekta
    cmds.setAttr (vOppositeBlend[0]+".scaleX", -1)
    cmds.delete  (cmds.pointConstraint (vBlend, vOppositeBlend))#      raspolagaet na ee meste blendi
    vBsh = cmds.blendShape (vBaseObj, vBlend, w=[(0, 1)])  #     naznachaet blenshape c bazavogo na blendu - deformiruet blendu v bazoviy
    cmds.select ( vOppositeBlend, r=True )
    cmds.select ( vBlend, add=True )
    wrapTemp = mm.eval("doWrapArgList \"6\" { \"1\",\"0\",\""+str(vMaxDistance)+"\", \"2\", \"0\", \"0\", \"0\" };") #  cozdaet vrap ya vivernutuyu kopiu bazovogo
    mm.eval ("setAttr (\""+wrapTemp[0]+".maxDistance\") "+str(vMaxDistance)+";")
    cmds.setAttr (vBsh[0]+"."+vBaseObj, 0)
    cmds.delete (vBsh)

    if (vHistory):
        cmds.delete   (vOppositeBlend,  ch=True)                  #     udalyaet istoriu, ostatki vrapa , vistavlyaet opozit blendu zerkalno ot ishodnoi
        cmds.delete   (vBlend+'Base')
        cmds.setAttr (vOppositeBlend[0]+".scaleX", 1)
        vTXval = cmds.getAttr  (vBlend+'.tx')
        cmds.setAttr (vOppositeBlend[0]+".tx", vTXval*-1)
    else:
        vBsh = cmds.blendShape (vOppositeBlend, vBlend, vBaseObj, w=[(0, 1), (1, 1)])  # esli istoriya ne udalyaetsya , naznachaet obe blendy na bazoviy i skrivaet opozit blendu
        cmds.setAttr (vOppositeBlend[0] +".v", 0)

############################################################################################################################################################################################
def  an_connectSimilarAttr():

    vObjt =  cmds.ls (sl = True) 
    vAttrsA = cmds.listAttr(vObjt[0], k=True, u=True, s=True, v=True)         
    vAttrsB = cmds.listAttr(vObjt[1], k=True, u=True, s=True, v=True)  
     
    for vEachA in vAttrsA:
        for vEachB in vAttrsB:
            if  vEachA==vEachB and not cmds.connectionInfo( vObjt[1]+"."+vEachB, isDestination=True): 
                cmds.connectAttr(vObjt[0]+"."+vEachA, vObjt[1]+"."+vEachB)
                
############################################################################################################################################################################################              
   
def  an_bshManager():

    win = "an_bshManager" 
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Blend shape manager.v02", rtf=True  )
      		
      			 
    vCLayout =cmds.columnLayout() 
     
    
    cmds.frameLayout( label='Rename, add preffix or sufix to target (selected in channel box):', borderStyle='etchedOut', bgc= [0, 0, 0], cll= True)
    cmds.separator (style="none", h=1  )
    vRCLayout = cmds.rowColumnLayout ( numberOfColumns=5, columnWidth=[(1, 90), (2, 90), (3, 90), (4, 90), (5, 90)]) 
    cmds.text (l="Input text:  ", align="right")
    cmds.textField ("textTF" )
    cmds.button (label='Add preffix', c="blendNameChange( \"prefix\")"  ) 
    cmds.button (label='Rename target', c="blendNameChange( \"rename\")"  )
    cmds.button (label='Add suffix', c="blendNameChange( \"sufix\")"  )
    cmds.setParent( vCLayout)
    ###########
    cmds.frameLayout( label='Add In-between. Select target then base object:', borderStyle='etchedOut', bgc= [0, 0, 0], cll= True)
    cmds.separator (style="none", h=1  )
    cmds.rowColumnLayout ( numberOfColumns=5, columnWidth=[(1, 90), (2, 90), (3, 90), (4, 90), (5, 90)]) 
    cmds.text (l="Target index:  ", align="right")
    cmds.intField ("indexTF" )
    cmds.text (l="Weight:  ", align="right")  
    cmds.floatField ("weightTF" ) 
    cmds.button (label='Add in-between', c="an_addInBetween( )" )
    cmds.setParent( vCLayout)
    ###########
    cmds.frameLayout( label='Replacement of the target. Select new target:', borderStyle='etchedOut', bgc= [0, 0, 0], cll= True)
     
    cmds.separator (style="none", h=1  )
    cmds.rowColumnLayout ( numberOfColumns=5, columnWidth=[(1, 90), (2, 90), (3, 90), (4, 90), (5, 90)]) 
    cmds.text (l="Target index:  ", align="right")
    cmds.intField ("indexTF2" )
     
    
    cmds.button (label='Add bsh node>>', c= "cmds.textField (\"BshTF\", e=True, text= cmds.ls (sl=True)[0])" ) 
    cmds.textField ("BshTF" )
    cmds.button (label='Connect target', c= "do_blndConnect ()" )
    cmds.setParent( vCLayout)
     
    cmds.showWindow (win)
 
 
 
 
def do_blndConnect ():
 
    if not  cmds.ls (sl=True) : cmds.warning (" Please Select objects")
    vTarget =  cmds.listRelatives(cmds.ls (sl=True)[0], s=True)[0]
    vBshQuery = cmds.textField ("BshTF", q=True, tx=True )
    vIndexQuery = cmds.intField ("indexTF2", q=True, v=True )
    cmds.connectAttr   ( vTarget +".worldMesh[0]",   vBshQuery+".inputTarget[0].inputTargetGroup["+str(vIndexQuery)+"].inputTargetItem[6000].inputGeomTarget", f=True  )  

 
 
def an_addInBetween():
    if not len(cmds.ls (sl=True)): cmds.warning (" Please Select objects")
    vTarget =  cmds.ls (sl=True)[0]
    vBase =  cmds.ls (sl=True)[1]
    vIndexQuery = cmds.intField ("indexTF", q=True, v=True )
    vWeightQuery = cmds.floatField ("weightTF", q=True, v=True )
    vList =  cmds.listHistory (vBase, pdo=True)
    vBlendShape =  cmds.ls (vList, type="blendShape") [0] 
    cmds.blendShape (vBlendShape, e=True,  ib=True, t= (vBase, vIndexQuery,  vTarget, vWeightQuery)) 
    
     
 
def blendNameChange( vModQuery):# "rename", "prefix", "sufix"  
    try: vNameQuery =  cmds.ls (sl=True) [0]
    except IndexError: cmds.warning (" Please Select object and bsh node")
    
    vChannelQuery =  cmds.channelBox ("mainChannelBox", q=True,  sha=True ) 
    vInputQuery = cmds.textField ("textTF", q=True, tx=True )
    try:
        if (vModQuery == "rename"):
            if (len(vChannelQuery) <= 1): cmds.aliasAttr (vInputQuery, vNameQuery+"."+vChannelQuery[0])
        
        if vModQuery == "prefix":
            for  objChannel in  vChannelQuery: cmds.aliasAttr (vInputQuery+objChannel, vNameQuery+"."+objChannel) 

        if vModQuery == "sufix": 
            for  objChannel in  vChannelQuery: cmds.aliasAttr (objChannel+vInputQuery, vNameQuery+"."+objChannel)
    except TypeError: cmds.warning (" Please Select one Atribute to Rename") 
             
                