
import maya.mel as mm
import maya.cmds as cmds
from  anProcedures import  distans,  an_childCapture
def an_changeCMDS ():
    val= cmds.checkBoxGrp( 'CHBGcurv', q=True, v1=True)
    cmds.intSliderGrp('ISG_attr', e=True,  enable= val  )


def an_bridgeSys_v05():
    """
    ________________________
    
    squash and stretch added
    ________________________
    """
    win = "bridgeSysUI"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Bridge system v5.01", width=420,  height=50, s=True, rtf=True, menuBar=True )
    cmds.scrollLayout
    cmds.columnLayout ('columnLayoutName', adjustableColumn=True)
    #step 1
    cmds.frameLayout (label="Step 1", borderStyle="etchedIn", cll=1, w=424, bgc= [0, 0, 0])
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Creating a basic form for bridge system ", al="left", font= "boldLabelFont")
    cmds.text (l="     - input name of bridge system ", al="left")
    cmds.text (l="     - select start object, then end object, and press \"Make cylinder\"", al="left")
    cmds.textFieldGrp ('TFG_attr', l="System name:",  cw = [(1, 124), (2, 191)])
    cmds.floatSliderGrp('FSG_ofs', label='Length offset:', field=True, minValue=0.5, maxValue=2.0,  value=1.1 , cw = [(1, 124), (2, 50) ] )
    cmds.checkBoxGrp( 'CHBGcurv', numberOfCheckBoxes=1, label='Bilde curve:     ', changeCommand ='an_changeCMDS()', v1=True )
    cmds.intSliderGrp('ISG_attr', label='Number of curve spans:', field=True, min=0, max=10,  v=3 , cw = [(1, 124), (2, 50) ], enable= True )
    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.text (l="")
    cmds.button   (l="Make cylinder",   c="an_makeCylinder()" )
    cmds.setParent ('columnLayoutName')
    cmds.separator  (  style="none")
    #step 2
    cmds.frameLayout (label="Step 2", borderStyle="etchedIn", cll=1, w=424, bgc= [0, 0, 0])
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Setup bridge geometry and making bridge", al="left", font= "boldLabelFont")
    cmds.text (l="     - Skin the curve to the necessary joints", al="left")
    cmds.text (l="     - Set necessary geometry resolution and size", al="left")
    cmds.text (l="     - To making bridge, press \"Make bridge\"", al="left")
    bc = "cmds.textFieldButtonGrp ('TFBG_start', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_start', l="Start joint:",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )
    bc = "cmds.textFieldButtonGrp ('TFBG_end', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_end', l="End joint:",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )
    bc = "cmds.textFieldButtonGrp ('TFBG_curve', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_curve', l="Curve:",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )
    bc = "cmds.textFieldButtonGrp ('TFBG_geo', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_geo', l="Bridge geometry:",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )
    cmds.separator  (  style="none")
    cmds.text (l="         Optional:", al="left", font= "boldLabelFont")
    cmds.text (l="     - Select unscaled group, and global scale object (controller)", al="left")
    bc = "cmds.textFieldButtonGrp ('TFBG_parGeo', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_parGeo', l="Global scale :",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )
    bc = "cmds.textFieldButtonGrp ('TFBG_scaleGeo', e=True, tx=  cmds.ls (sl=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_scaleGeo', l="Unscaled group:",  bl="<<Add selected",  cw = [(1, 124), (2, 191)],  bc = bc )

    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.text (l="")
    cmds.button   (l= "Make bridge", c='an_makeBridgeFromUi()' )
    cmds.setParent ('columnLayoutName')

    cmds.showWindow (win)
an_bridgeSys_v05()

def an_makeBridgeFromUi():
    pfx = cmds.textFieldGrp ('TFG_attr', q=True, text=True)
    startJnt, endJnt =  [cmds.textFieldButtonGrp ('TFBG_start', q=True, tx= True), cmds.textFieldButtonGrp ('TFBG_end', q=True, tx= True)]
    vCurve, geo = cmds.textFieldButtonGrp ('TFBG_curve', q=True, tx= True),  cmds.textFieldButtonGrp ('TFBG_geo', q=True, tx= True)



    rigGrp, globScale = cmds.textFieldButtonGrp ('TFBG_parGeo', q=True, tx= True),  cmds.textFieldButtonGrp ('TFBG_scaleGeo', q=True, tx= True)


    inputData = cmds.connectionInfo( cmds.listRelatives (geo, s=True )[0]+'.inMesh ', sourceFromDestination=True).split('.')[0]
    subdH = cmds.getAttr (inputData+".subdivisionsHeight")
    subdA = cmds.getAttr (inputData+".subdivisionsAxis")
    rad = cmds.getAttr (inputData+".radius")
    an_makeBridge(pfx, startJnt, endJnt, vCurve, [rad, subdA, subdH], globScale, rigGrp )
    cmds.delete (geo)

def an_makeCylinder( ):
    start, end = cmds.ls (sl=True)
    length = distans (start, end)
    lengthOfs = cmds.floatSliderGrp('FSG_ofs', q=True, v=True)
    name = cmds.textFieldGrp ('TFG_attr', q=True, text=True)
    obj = cmds.polyCylinder (r=length/5, h=length*lengthOfs, sx=12, sy=10, sz=1, ax=[0,1,0], rcp=0, cuv=3, ch=1, n= name+'BridgeSys_geo' )
    locA= cmds.spaceLocator( )
    cmds.move( 0, length*lengthOfs/2, 0 )
    locB= cmds.spaceLocator( )
    cmds.move( 0, length*lengthOfs/-2, 0 )

    for each in [locA, locB]: cmds.parent (each, obj[0])
    cmds.delete (cmds.pointConstraint( start, end, obj))
    cmds.delete (cmds.aimConstraint(end, obj, aim=[0, 1, 0]))

    if cmds.checkBoxGrp( 'CHBGcurv', q=True, v1=True):
        pos=[]
        for each in [locA, locB]:
            pos.append( cmds.xform  (each, q=True, t=True, ws=True))
        vCurve = cmds.curve (p =pos, d=1, n=name+'BridgeSys_crv')
        sp= cmds.intSliderGrp('ISG_attr', q=True, v=True )
        cmds.rebuildCurve (vCurve, ch=0, rpo=1, rt=0, end=1,  kr=0, kcp=0, kep=1, kt=0, s=sp, d=3, tol=0.01)
        cmds.textFieldButtonGrp ('TFBG_curve', e=True, tx= vCurve)

    cmds.textFieldButtonGrp ('TFBG_start', e=True, tx= start)
    cmds.textFieldButtonGrp ('TFBG_end', e=True, tx= end)
    cmds.textFieldButtonGrp ('TFBG_geo', e=True, tx= obj[0])
    cmds.select (obj[1])
    cmds.delete (locA, locB)



def an_makeBridge(pfx, startJnt, endJnt, vCurve, geoPar=[2, 12, 10], globScale = None, rigGrp = None ):# geoPar = [radius, subdivisionsAxis, subdivisionsHight]

    skinClusterName =  cmds.ls (cmds.listHistory (vCurve, pdo=1), type='skinCluster')[0]    # get curve skin Cluster Name
    skinJntList = cmds.ls ( cmds.listHistory (skinClusterName, levels=1), type='transform') # get curve skin Jnt List

    shape = cmds.listRelatives(vCurve, s=True)[0]     # get curve shape
    vPointsNum = cmds.getAttr (shape+'.spans')+cmds.getAttr (shape+'.degree')   # get curve shape

    weight = []      #curve points weights storage
    for i in range (vPointsNum):   weight.append( cmds.skinPercent( skinClusterName, vCurve+'.cv['+str(i)+']', query=True, value=True )) #get weights

    drivGrp = cmds.group (em=True, n=pfx+'Driver_grp')     #group wich parent to scale controller
    staticGrp = cmds.group (em=True, n=pfx+'Static_grp')   #group wich stay at zero coordinates

    DriverJnt, StaticJnt, geoDriverJnt, geoStaticJnt = [],[], [], []
    for index, eachJnt in enumerate(skinJntList):
        cmds.select (cl =True)
        drJnt = cmds.joint(n=pfx+'Driver0'+str(index)+'_jnt')   # creation of two groups with joints wich echo position of the bones of the curve
        cmds.delete (cmds.pointConstraint (eachJnt, drJnt ) )
        cmds.parent (drJnt, drivGrp)
        cmds.parentConstraint (eachJnt, drJnt, mo=True )
        DriverJnt.append(drJnt)

        stJnt = cmds.joint(n=pfx+'Static0'+str(index)+'_jnt')
        cmds.parent (stJnt, staticGrp)
        cmds.connectAttr (drJnt+'.t', stJnt+'.t')
        cmds.connectAttr (drJnt+'.r', stJnt+'.r')
        StaticJnt.append(stJnt)

    cmds.skinCluster (shape, e=True, ub=True )
    cmds.skinCluster(StaticJnt, vCurve, tsb=True)

    for i in range (vPointsNum):  #  set skin weight
        cmds.skinPercent( skinClusterName, vCurve+'.cv['+str(i)+']', transformValue=zip(StaticJnt,weight[i]))

    for index, eachJnt in enumerate([startJnt, endJnt]):  # duplicating joints that echo the position of the bones of the body to connect to the bridge
        cmds.select (cl =True)
        drJnt = cmds.joint(n=pfx+'geoDriver0'+str(index)+'_jnt')
        cmds.delete (cmds.pointConstraint (eachJnt, drJnt ) )

        cmds.parent (drJnt, drivGrp)
        cmds.parentConstraint (eachJnt, drJnt, mo=True )
        geoDriverJnt.append(drJnt)

        stJnt = cmds.joint(n=pfx+'geoStatic0'+str(index)+'_jnt')
        cmds.parent (stJnt, staticGrp)
        cmds.connectAttr (drJnt+'.t', stJnt+'.t')
        cmds.connectAttr (drJnt+'.r', stJnt+'.r')
        geoStaticJnt.append(stJnt)

    geo = cmds.polyCylinder (r=geoPar[0], h=cmds.arclen( vCurve ), sx=geoPar[1], sh=geoPar[2] , sz=1, ch=1, n=pfx+'BridgeSys_geo' )[0]# creat Cylinder  for brige
    geoShape = cmds.listRelatives (geo, s=True )[0]

    twistGrp = cmds.group (em=True, n=pfx+'Twist_grp' ) #get start of curve and made twist sys
    jnts = []
    for name, xVal in ([pfx+'Twist_jnt', 0],[pfx+'TwistEnd_jnt', distans (startJnt, endJnt)/5]):
        jnts.append(cmds.joint ( n=name,  p=[xVal, 0, 0]))
    pos = cmds.xform(vCurve+'.cv[0]', q=True,  t=True, ws=True )
    cmds.move ( pos[0], pos[1], pos[2], twistGrp)

    cmds.delete (geo+'.f[0:'+str(geoPar[1]*geoPar[2]-1)+']')
    cmds.delete (cmds.pointConstraint( startJnt, endJnt, geo))
    cmds.delete (cmds.aimConstraint(twistGrp, geo, aim=[0, -1, 0]))
    cmds.delete (geo, ch=True)
    cmds.skinCluster( geoStaticJnt[0], geoStaticJnt[1], geo, dropoffRate = 10)
    bridge = cmds.polyBridgeEdge (geo, ch=1, divisions=geoPar[2]-1, twist=0, taper=1,  curveType=0, smoothingAngle=30)[0]
    cmds.setAttr (bridge+".curveType", 2)
    cmds.connectAttr (shape+'.worldSpace[0]', bridge+'.inputProfile')

    if distans (startJnt, twistGrp) > distans (endJnt, twistGrp):
        cmds.parent (twistGrp, geoStaticJnt[1])
        cmds.delete (cmds.aimConstraint(geoStaticJnt[0], twistGrp,  aim=[1, 0, 0]))
        ikHandl = cmds.ikHandle( sj=jnts[0], ee=jnts[1], sol='ikSCsolver', n=pfx+'BridgeSys_ik' )
        cmds.parent (ikHandl[0], geoStaticJnt[0])
    else:
        cmds.parent (twistGrp, geoStaticJnt[0])
        cmds.delete (cmds.aimConstraint(geoStaticJnt[1], twistGrp,  aim=[1, 0, 0]))
        ikHandl = cmds.ikHandle( sj=jnts[0], ee=jnts[1], sol='ikSCsolver', n=pfx+'BridgeSys_ik' )
        cmds.parent (ikHandl[0], geoStaticJnt[1])
    for each in [  "tx", "ty", "tz" ]:
         cmds.setAttr (ikHandl[0]+"."+each, 0)
    cmds.connectAttr (jnts[0]+'.rotateX', bridge+'.twist')

    cmds.parent (geo, drivGrp)
    cmds.parent (vCurve, staticGrp)

    ## squash and stretch
    cmds.addAttr (geo, ln = 'squashSwitch', min = 0, max =10, dv=1, keyable= True )
    cmds.addAttr (geo, ln = 'squashOffset', min = -10, max =10, dv=0, keyable= True )
    
    PMAOfset = cmds.createNode ('plusMinusAverage',  n=pfx+'sqOffsetPMA') #squashOffset
    cmds.connectAttr (geo+'.squashOffset', PMAOfset+'.input1D[0]' )
    cmds.connectAttr (PMAOfset+'.output1D', bridge+'.taper')
    
    blandToAttr = cmds.createNode ('blendTwoAttr',  n=pfx+'SQblendTwoAttr')   #squashSwitch
    cmds.connectAttr (geo+'.squashSwitch', blandToAttr+'.attributesBlender' )
    cmds.setAttr (blandToAttr+'.input[0]', 1)
    cmds.connectAttr (blandToAttr+'.output', PMAOfset+'.input1D[1]' )
    
    curveInfoNode = cmds.arclen(vCurve, ch=True)
    
    setRange = cmds.createNode ('setRange',  n=pfx+'setRange') #squashOffset

    cmds.connectAttr (setRange+'.outValueX', blandToAttr+'.input[1]' )
    cmds.connectAttr ( curveInfoNode+'.arcLength', setRange+'.valueX' )
    
    cmds.setAttr (setRange+'.minX', 4)
    cmds.setAttr (setRange+'.maxX', -2)
    cmds.setAttr (setRange+'.oldMaxX', cmds.arclen(vCurve)*2)
     
######################################
    if globScale:
        cmds.parent (staticGrp, globScale)

    if rigGrp:
        cmds.parent (drivGrp, rigGrp)



#pfx='ff'
#vCurve = 'spineBridgeSys_crv'
#geo = 'spineBridgeSys_geo1'

#bridge= 'polyBridgeEdge1'







