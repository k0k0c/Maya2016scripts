
import maya.cmds as cmds
import maya.mel as mm

def an_bendCorrector_v04():
    win = "makeScelUI2"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Bend correction system v4.00", width=420,  height=50, s=True, rtf=True, menuBar=True )
    cmds.scrollLayout
    cmds.columnLayout ('columnLayoutName', adjustableColumn=True)
    #step 1
    cmds.frameLayout (label="Step 1", borderStyle="etchedIn", cll=1, w=424)
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Creating a system for calculating the direction and degree of bend", al="left", font= "boldLabelFont")
    cmds.text (l="     - select joint, then up joint.", al="left")
    cmds.text (l="     - to delete a rig, select the group with the system and press \"Delete\"", al="left")
    cmds.radioButtonGrp ('RBG_orient', l="Orient as  :     ", nrb=2, la2=["Main joint","Up joint"],  sl=1 )
    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.button   (l="Delete bend corrector",c="an_delRig (cmds.ls(sl=True)[0])")
    cmds.button   (l="Add bend corrector",   c="an_3dSolver()" )
    cmds.setParent ('columnLayoutName')

    #step 2
    cmds.frameLayout (label="Step 2", borderStyle="etchedIn", cll=1, w=424)
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Creating corrective joints", al="left", font= "boldLabelFont")
    cmds.text (l="     - select the group with the system !", al="left")
    cmds.text (l="     - to delete a joint, select the end joint and press \"Delete\"", al="left")
    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.button   (l= "Delete joint", c="an_delRig (cmds.ls(sl=True)[0])")
    cmds.button   (l= "Add joint", c="an_corrJnt()" )
    cmds.setParent ('columnLayoutName')

    #step 3
    cmds.frameLayout (label="Step 3", borderStyle="etchedIn", cll=1, w=424)
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Adding attributes", al="left", font= "boldLabelFont")
    cmds.text (l="      - set influence axis, attribut and type of control, then select joint !", al="left")
    cmds.radioButtonGrp ('RBG_axis', l="Influence axis:     ", nrb=2, la2=["Z","Y"],  sl=1 )
    v_bc = "cmds.textFieldButtonGrp ('TFBG_attr', e=True,  tx=cmds.channelBox ('mainChannelBox', q=True, sma=True)[0])"
    cmds.textFieldButtonGrp ('TFBG_attr', l="Dependent attribute:",  bl="Add attr",  cw = [(1, 124), (2, 191)], bc=v_bc )
    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.button   (l= "Breake connections",  c="breakeConnections()")
    cmds.button   (l= "Create dependent" ,   c="an_corrAttr()")
    cmds.setParent ('columnLayoutName')

    #mirror
    cmds.frameLayout (label="Auxiliary tools", borderStyle="etchedIn", cll=1, w=424)
    cmds.columnLayout
    cmds.separator  (  style="none")
    cmds.text (l="         Mirroring selected joint", al="left", font= "boldLabelFont")
    cmds.text (l="     - Creating opposite system for calculating the direction and degree!", al="left")
    cmds.text (l="     - select necessary joint and press \"Mirror joint\"", al="left")

    cmds.separator  (  style="none")
    cmds.text (l="         Convert attributes to sdk", al="left", font= "boldLabelFont")
    cmds.text (l="     - select necessary attributes and press \"Convert to sdk\"", al="left")

    cmds.rowColumnLayout (nc=2, cw=[(1, 210), (2, 210)])
    cmds.button   (l= "Convert to sdk", c="an_convertToSdk()" )
    cmds.button   (l= "Mirror joint", c="mirrorJnt()")

    cmds.setParent ('columnLayoutName')
    cmds.showWindow (win)
an_bendCorrector_v04()


def an_corrJnt():
    v_Sfx  = mm.eval('an_NamesList_v02 -Sfx')
    v_pfx = cmds.ls (sl=True) [0].split("Rig_grp" )[0]

    v_index = 1
    while mm.eval('objExists '+v_pfx+'AddBase'+str(v_index)+v_Sfx[3]): v_index =  v_index +1

    cmds.select (cl=True)
    for v_each in [(0, 'Base'), (1,'End')]:
        cmds.joint (n=v_pfx+'Add'+v_each[1]+str(v_index)+v_Sfx[3],  p=[0, 0, v_each[0]])

    cmds.setAttr (v_pfx+'AddBase'+str(v_index)+v_Sfx[3]+".rotateOrder", 1)
    cmds.parent (v_pfx+'AddBase'+str(v_index)+v_Sfx[3],  v_pfx+"_jntGrp" )

    for v_attr in ["jointOrientX", "jointOrientY",  "jointOrientZ",  "tx", "ty", "tz" ]:
        cmds.setAttr (v_pfx+'AddBase'+str(v_index)+v_Sfx[3]+"."+v_attr , 0)
    an_delSys ([v_pfx+'AddBase'+str(v_index)+v_Sfx[3]], v_pfx+'AddEnd'+str(v_index)+v_Sfx[3])

def an_axisCtrl(v_ctName):
    v_ctGrp = cmds.group (n=v_ctName, em= True)
    for v_each in [(1, 0, 0, 13), (0, 1, 0, 14), (0, 0, 1, 6)]:
        vCurv = cmds.curve (d=1, p=[(0, 0, 0), (v_each[0], v_each[1], v_each[2])])
        v_shape = cmds.listRelatives(vCurv, s=True)[0]
        cmds.setAttr (v_shape+".overrideEnabled", 1)
        cmds.setAttr (v_shape+".overrideColor", v_each[3])
        cmds.parent  (v_shape, v_ctGrp, shape=True,r=True)
        cmds.delete (vCurv)
    return v_ctName

def an_connectRigVis (v_ct, v_obj):
    if not mm.eval( 'attributeExists "rigVis"'+v_ct): cmds.addAttr (v_ct, ln="rigVis",  dv=0, k=True, at="enum", en="off:on" )
    for v_each in v_obj:
        if  not cmds.connectionInfo (v_each+".v",id=True):
    	    cmds.connectAttr  (v_ct+".rigVis", v_each+".v")

def an_delSys (v_objs, v_ct):
    if not mm.eval( 'attributeExists "delList"'+v_ct):
        cmds.addAttr (v_ct, ln="delList", k=False, dt="string"  )
    for v_each in v_objs:
        v_val = str(cmds.getAttr  (v_ct +".delList"))
        print v_val, v_each
        if  v_val=='None':  cmds.setAttr (v_ct+".delList", v_each+"***", type="string")
        else : cmds.setAttr (v_ct+".delList",  v_val+v_each+"***", type="string")

def an_delRig (v_Obg):
    if mm.eval( 'attributeExists "delList"'+v_Obg) and mm.eval('objExists '+v_Obg) :
        v_delObgList = str(cmds.getAttr  (v_Obg +".delList")).split("***")[:-1]
        print v_delObgList
        for v_iobj in v_delObgList:
            print v_iobj
            an_delRig (v_iobj)
        if mm.eval('objExists '+v_Obg): cmds.delete(v_Obg)
    else :
        if mm.eval('objExists '+v_Obg): cmds.delete(v_Obg)

########################################################
def an_3dSolver ():
    v_jnt, v_parent = cmds.ls (sl=True)
    pfx = v_jnt.split('_')[0]+'_'+v_jnt.split('_')[1] if '_' in v_jnt else v_jnt
    			  #angle solver	  
    cmds.select (cl=True)
    for v_i in [0,1,2]:  cmds.joint (n=pfx+str(v_i)+'_jnt', p = [v_i-1, 0 ,0 ])
    v_ikHandle =cmds.ikHandle (n=pfx+str(v_i)+'_ik',  sol="ikRPsolver", shf=0, sj=pfx+'0_jnt',  ee=pfx+'2_jnt' ) [0]   #ikHandle
    v_aimGrp = cmds.group ([v_ikHandle], n=pfx+'ikAim' )
    cmds.xform (os=True, piv=[0,0,0])
    
    v_ctName = an_axisCtrl(pfx+'locator') #Controller
    cmds.setAttr (v_ctName+".translateX", 1)
    cmds.parentConstraint (v_aimGrp , v_ctName, mo=True )
    for v_each in ["angle_dir", "angle_val",  "dir_Z",  "dir_Y", "out_Z", "out_Y"]:   cmds.addAttr (v_ctName, ln=v_each,  dv=0, k=True )
    cmds.connectAttr  (pfx+'1_jnt .ry',  v_ctName+".angle_val")
    
    v_nurb = cmds.cylinder ( n=pfx+"Nurbs",  p=[0, 0, 0], ax=[1, 0, 0], r=1, hr=0.1, d=3, ut=0, tol=0.01, s=8, nsp=1, ch=False)[0] # cylinder
    v_nurbSape = cmds.listRelatives(v_nurb, s=True)[0]
     				#sozdaem nodu kotoraja vychisljaet blizhajshuju k lokatoru Vkoordinatu i peredaet ee na atribut lokatora "angle"
    vPointOnSurface = cmds.createNode ("closestPointOnSurface", n=pfx+"PointOnSurface")
    cmds.connectAttr  (v_ctName+'.translate',  vPointOnSurface+".inPosition")
    cmds.connectAttr  (v_nurbSape+".worldSpace[0]",  vPointOnSurface+".inputSurface")
    cmds.connectAttr  (vPointOnSurface+".parameterV", v_ctName+".angle_dir")
    for v_attr in [(4, -1), (6, 0), (2, 0), (0, 1), (8, 1)]: cmds.setDrivenKeyframe (v_ctName+".dir_Y", cd=vPointOnSurface+".parameterV", dv=v_attr[0], v=v_attr[1], itt="linear", ott="linear")
    for v_attr in [(6, 1), (8, 0), (4, 0), (2, -1), (0, 0)]: cmds.setDrivenKeyframe (v_ctName+".dir_Z", cd=vPointOnSurface+".parameterV", dv=v_attr[0], v=v_attr[1], itt="linear", ott="linear")
    
    v_multiplyDivide = cmds.createNode ("multiplyDivide", n=pfx+"MD") #noda umnozhajushhaja napravlenie na stepen' sgiba sustava
    for v_attr in [(".dir_Z", ".input1Z"), (".dir_Y", ".input1Y"), (".angle_val", ".input2Z"), (".angle_val",".input2Y")]:
        cmds.connectAttr  (v_ctName+v_attr[0], v_multiplyDivide+v_attr[1])
    for v_attr in [(".outputZ", ".out_Z"), (".outputY", ".out_Y")]: cmds.connectAttr  (v_multiplyDivide+v_attr[0], v_ctName+v_attr[1])
    
    v_jntGroup = cmds.group (em=True, n=pfx+'_jntGrp' )
    v_Grp = cmds.group ( v_nurb,  v_ctName,  v_aimGrp,  pfx+'0_jnt', v_jntGroup, n=pfx+'_const')
    cmds.xform (os=True, piv=[0,0,0])
    
    cmds.delete (cmds.parentConstraint (v_jnt, v_Grp ))
    if cmds.radioButtonGrp ('RBG_orient', q=True, sl=True )==2: cmds.delete (cmds.orientConstraint (v_parent, v_Grp ))
    cmds.pointConstraint (v_jnt, v_Grp, mo=True)
    v_oriA = cmds.orientConstraint (v_parent, v_Grp, mo=True)[0]
    v_oriB = cmds.orientConstraint (v_jnt, v_aimGrp, mo=True)[0]
    v_rigGrp = cmds.group (v_ctName, v_Grp, n=pfx+'Rig_grp')
    
    for v_each in ["offsetX",  "offsetY",  "offsetZ"]:  cmds.addAttr (v_rigGrp, ln=v_each,  dv=0, k=True )    #  offset system
    
    for v_constr in [v_oriA, v_oriB]:
        for v_attr in ["offsetX",  "offsetY",  "offsetZ"]:
            v_val = cmds.getAttr (v_constr+"."+v_attr)
            cmds.setDrivenKeyframe (v_constr+"."+v_attr, cd=v_rigGrp+"."+v_attr, dv=180, v=v_val+180, itt="linear", ott="linear")
            cmds.setDrivenKeyframe (v_constr+"."+v_attr, cd=v_rigGrp+"."+v_attr, dv=-180, v=v_val-180, itt="linear", ott="linear")
    
    an_connectRigVis (v_rigGrp,  [v_aimGrp, v_nurb, pfx+'0_jnt'])
    an_delSys ([v_ctName], v_rigGrp)
    return   "Computing system was created", v_rigGrp

################################################################################

def  an_corrAttr ():
    v_obj = cmds.ls (sl=True)[0]
    v_pfx =  mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[0] + mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[1]
    v_solver = v_pfx.split('Add')[0]+'locator'
    v_infAxic = ".out_Z" if cmds.radioButtonGrp ('RBG_axis', q=True, sl=True)==1 else ".out_Y"
    v_attr = cmds.textFieldButtonGrp ('TFBG_attr', q=True,  tx=True)
    print v_obj, v_solver, v_infAxic, v_attr, v_pfx
    an_setNodes (v_obj, v_solver, v_infAxic, v_attr, v_pfx)
    cmds.select  (v_obj)

#---------------------------------------------------------------------

def an_setNodes (v_obj, v_solver, v_infAxic, v_attr, v_pfx):
    for v_each in ["start_",  "mid_",  "end_"]:  cmds.addAttr (v_obj, ln=v_each+v_attr,  dv=0, k=True )
    v_blendA = cmds.createNode ("blendTwoAttr",  name= v_pfx +"_blendA"+v_attr )
    cmds.connectAttr   (v_obj+".start_"+v_attr, v_blendA+".input[1]")
    cmds.connectAttr   (v_obj+".mid_"+v_attr, v_blendA+".input[0]")

    v_blendB = cmds.createNode ("blendTwoAttr",  name= v_pfx +"_blendB"+v_attr )
    cmds.connectAttr  (v_obj+".mid_"+v_attr, v_blendB+".input[0]")
    cmds.connectAttr  (v_obj+".end_"+v_attr, v_blendB+".input[1]")

    v_setRange = cmds.createNode ("setRange",   name = v_pfx +"setRange"+v_attr)
    cmds.connectAttr  (v_solver+v_infAxic, v_setRange+".valueX")
    cmds.setAttr (v_setRange+".minX", 1)
    cmds.setAttr (v_setRange+".oldMinX", -180)
    cmds.connectAttr (v_setRange+".outValueX", v_blendA+".attributesBlender")
    cmds.connectAttr  (v_solver+v_infAxic, v_setRange+".valueY")
    cmds.setAttr (v_setRange+".maxY", 1)
    cmds.setAttr (v_setRange+".oldMaxY", 180)
    cmds.connectAttr (v_setRange+".outValueY", v_blendB+".attributesBlender")

    v_condition =  cmds.createNode ( "condition", name= v_pfx +"_condition"+v_attr)
    cmds.setAttr (v_condition+".operation", 2)
    cmds.connectAttr (v_solver+v_infAxic, v_condition+".firstTerm")
    cmds.connectAttr   (v_blendA+".output", v_condition + ".colorIfFalseR")
    cmds.connectAttr (v_blendB+".output", v_condition + ".colorIfTrueR")
    cmds.connectAttr (v_condition+".outColorR", v_obj+"."+v_attr)
#---------------------------------------------------------------------

def breakeConnections ():
    v_obj = cmds.ls (sl=True)[0]
    v_pfx =  mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[0] + mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[1]
    v_attr = cmds.textFieldButtonGrp ('TFBG_attr', q=True,  tx=True)
    for v_eatch in  [v_pfx +"_blendA"+v_attr, v_pfx +"_blendB"+v_attr, v_pfx +"_condition"+v_attr ]:  cmds.delete(v_eatch)
    for v_eatch in ["start_", "mid_", "end_" ]: cmds.deleteAttr (v_obj, attribute= v_eatch+v_attr)

def mirrorJnt():
    v_ljnt = [cmds.listRelatives(cmds.ls (sl=True)[0], p=True )[0], cmds.ls (sl=True)[0]]
    v_rjnt =[mm.eval('an_mirorSelect ("'+v_ljnt[0]+'", {"l_", "r_"})'), mm.eval('an_mirorSelect ("'+v_ljnt[1]+'", {"l_", "r_"})')]
    v_pfx =  v_rjnt[0].split("AddBase" )[0]
    v_solver = v_pfx.split('Add')[0]+'locator'

    cmds.select (cl=True)
    for v_each in [(0, 'Base'), (1,'End')]:
        cmds.joint (n=v_rjnt[v_each[0]],  p=[0, 0, v_each[0]*-1])

    cmds.setAttr ( v_rjnt[0]+".rotateOrder" , 1)
    cmds.parent (v_rjnt[0],  v_pfx+"_jntGrp" )

    for v_attr in ["jointOrientX", "jointOrientY",  "jointOrientZ",  "tx", "ty", "tz" ]:
        cmds.setAttr (v_rjnt[0]+"."+v_attr , 0)
    an_delSys ([v_rjnt[0]], v_rjnt[1])

    for index, v_obj in enumerate(v_ljnt):
        for  v_attr in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']: #prohodim po vsem atributam
            if not cmds.connectionInfo (v_obj+'.'+v_attr, id = True ):
                val = cmds.getAttr ( v_obj+'.'+v_attr)
                if v_attr in ['tx', 'ty', 'tz']: val = val*-1
                cmds.setAttr ( v_rjnt[index]+'.'+v_attr, val)
            else:
                v_connect = cmds.connectionInfo (v_obj+'.'+v_attr, sourceFromDestination = True).split('.')[0]

                if not 'animCurve' in cmds.nodeType(v_connect):  #vypolnjaetsja esli k atributu prikonekchena ne animacinaja krivaja
                    v_setRanje = v_obj.split("_jnt")[0]+"setRange" + v_attr
                    v_infAxic='.'+cmds.connectionInfo (v_setRanje+'.valueX', sourceFromDestination = True ).split('.')[1]
                    v_pfx =  mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[0] + mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[1]
                    v_pfx = mm.eval('an_mirorSelect ("'+v_pfx+'", {"l_", "r_"})')
                    an_setNodes (v_rjnt[index], v_solver, v_infAxic, v_attr, v_pfx)

                    for  v_ofattr in ['start_', 'mid_', 'end_']:
                        val = cmds.getAttr ( v_obj+'.'+v_ofattr+v_attr)
                        if v_attr in ['tx', 'ty', 'tz']: val = val*-1
                        cmds.setAttr ( v_rjnt[index]+'.'+v_ofattr+v_attr, val)
                else:  #vypolnjaetsja esli k atributu prikonekchena animacinaja krivaja
                    v_sDriven = v_obj+'.'+v_attr
                    print v_sDriven

                    v_animCurve = cmds.connectionInfo (v_sDriven, sourceFromDestination = True ).split('.')[0]
                    v_sDriver = cmds.connectionInfo (v_animCurve+'.input', sourceFromDestination = True )
                    v_tDriver = mm.eval('an_mirorSelect ("'+v_sDriver+'", {"l_", "r_"})')
                    v_tDriven = mm.eval('an_mirorSelect ("'+v_sDriven+'", {"l_", "r_"})')

                    v_revers = "neg" if v_attr in ['tx', 'ty', 'tz'] else 'poz'
                    an_copySdk (v_sDriven, v_tDriver, v_tDriven, v_revers)


def an_convertToSdk():
    v_obj = cmds.ls (sl=True)[0]
    v_pfx =  mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[0] + mm.eval('an_returnPfxTxtSfx ("'+v_obj+'")')[1]
    v_attr = cmds.channelBox ('mainChannelBox', q=True, sma=True)[0]
    v_adAttr = [cmds.getAttr ( v_obj+'.start_'+v_attr),   cmds.getAttr ( v_obj+'.mid_'+v_attr),    cmds.getAttr ( v_obj+'.end_'+v_attr)]
    v_solver = v_pfx.split('Add')[0]+'locator'

    v_setRanje = v_obj.split("_jnt")[0]+"setRange" + v_attr
    v_infAxic = '.'+cmds.connectionInfo (v_setRanje+'.valueX', sourceFromDestination = True ).split('.')[1]

    for v_eatch in  [v_pfx +"_blendA"+v_attr, v_pfx +"_blendB"+v_attr, v_pfx +"_condition"+v_attr ]:  cmds.delete(v_eatch)
    for v_eatch in ["start_", "mid_", "end_" ]: cmds.deleteAttr (v_obj, attribute= v_eatch+v_attr)

    cmds.setDrivenKeyframe (v_obj+"."+v_attr,   cd=v_solver+v_infAxic,    dv=-180, v=v_adAttr[0],     itt="linear", ott="linear")
    cmds.setDrivenKeyframe (v_obj+"."+v_attr,   cd=v_solver+v_infAxic,    dv=0, v=v_adAttr[1],     itt="linear", ott="linear")
    cmds.setDrivenKeyframe (v_obj+"."+v_attr,   cd=v_solver+v_infAxic,    dv=180, v=v_adAttr[2],     itt="linear", ott="linear")

#v_sDriven = "l_footAddEnd1_jnt.tx"
#v_tDriver = "r_footlocator.out_Z"
#v_tDriven = "r_footAddEnd1_jnt.tx"
#v_revers  = "neg"

def an_copySdk(v_sDriven, v_tDriver, v_tDriven, v_revers):
    v_kurvName = cmds.connectionInfo (v_sDriven, sourceFromDestination = True).split('.')[0]
    v_dupKurv = cmds.duplicate (v_kurvName, n = mm.eval('an_mirorSelect ("'+v_kurvName+'", {"l_", "r_"})'))[0]
    cmds.connectAttr (v_tDriver,   v_dupKurv+".input")
    cmds.connectAttr (v_dupKurv+".output",  v_tDriven)
    if v_revers  == "neg":
        v_val = cmds.keyframe (v_tDriven, vc=True, q=True)
        for v_index, v_eachVal in enumerate(v_val):
            cmds.keyframe( v_tDriven, e=True, index=(v_index,v_index),  valueChange= v_eachVal*-1 )



























