objList = cmds.ls(sl=True)


def an_connectCtToMatch(objList):
    for ctrl in objList:
        space = An_CharNames(ctrl).devideName()[0]+An_CharNames(ctrl).devideName()[1]+'_match'
        if cmds.objExists(space): 
            cmds.addAttr   (ctrl, ln="match", at="message") # if many obj use  'multi = True'
            cmds.connectAttr (space+'.message',  ctrl+'.match')
            print ctrl, ' connected to -> ', space

an_connectCtToMatch(objList) 