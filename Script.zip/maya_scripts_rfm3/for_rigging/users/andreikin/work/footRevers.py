
#result = cmds.promptDialog( title='FK rig system', message='Enter controller name:', button=['OK', 'Cancel'], defaultButton='OK', cancelButton='Cancel', dismissString='Cancel')
#v_side = cmds.promptDialog(query=True, text=True)


 
v_ctrl = 'l_footIk_CT'
v_revJnt = 'l_legRevers1_jnt'
v_Side = 'l_'

def setReversJnt(v_ctrl, v_revJnt, v_Side):

    v_Pfx = v_Side +'Revers'
    v_revJnts = an_childCapture(v_revJnt)
    
    vClamp1 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp01')   # l_legRevers6_jnt
    cmds.connectAttr ( v_ctrl+'.footBreak ',  vClamp1+'.maxR')
    cmds.connectAttr ( v_ctrl+'.footRoll ',  vClamp1+'.inputR')
    vClamp2 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp02')
    cmds.setAttr (  vClamp2+'.maxR', 360)
    cmds.connectAttr ( vClamp1+'.outputR ',  vClamp2+'.inputR')  
    vPMA1 = cmds.createNode ('plusMinusAverage',  n = v_Pfx+'PMA1')
    cmds.connectAttr ( v_ctrl+'.ballRise ',  vPMA1+'.input1D[0]')
    cmds.connectAttr ( vClamp2+'.outputR ',  vPMA1+'.input1D[1]')  
    cmds.connectAttr ( vPMA1+'.output1D ',  v_revJnts[5]+'.rz', f= True)  
    
    vPMA2 = cmds.createNode ('plusMinusAverage',  n = v_Pfx+'PMA2') # l_legRevers5_jnt
    cmds.setAttr (  vPMA2+'.operation', 2)
    cmds.connectAttr ( v_ctrl+'.footRoll ',  vPMA2+'.input1D[0]')
    cmds.connectAttr ( v_ctrl+'.footBreak ',  vPMA2+'.input1D[1]')
    vClamp3 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp03')
    cmds.setAttr (  vClamp3+'.maxR', 90)
    cmds.connectAttr ( vPMA2+'.output1D ',  vClamp3+'.inputR') 
    vPMA3 = cmds.createNode ('plusMinusAverage',  n = v_Pfx+'PMA3') 
    cmds.connectAttr ( vClamp3+'.outputR',  vPMA3+'.input1D[0]')  
    cmds.connectAttr ( v_ctrl+'.toeRise ',  vPMA3+'.input1D[1]') 
    cmds.connectAttr ( vPMA3+'.output1D ',  v_revJnts[4]+'.rz', f= True) 
    cmds.connectAttr ( v_ctrl+'.toeTwist ',  v_revJnts[4]+'.ry', f= True) 
    cmds.connectAttr ( v_ctrl+'.ballTwist ',  v_revJnts[3]+'.ry', f= True) # l_legRevers4_jnt
    
    v_MDV1 =cmds.createNode ('multiplyDivide',  n = v_Pfx+'MDV1')   # l_legRevers3_jnt
    cmds.connectAttr ( v_ctrl+'.footRoll ',  v_MDV1+'.input1X')
    cmds.setAttr (  v_MDV1+'.input2X', -1)
    vClamp4 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp04') 
    cmds.connectAttr ( v_MDV1+'.outputX', vClamp4+'.inputR'    ) 
    cmds.setAttr (  vClamp4+'.maxR', 360)
    vPMA4 = cmds.createNode ('plusMinusAverage',  n = v_Pfx+'PMA4') 
    cmds.connectAttr ( vClamp4+'.outputR',  vPMA4+'.input1D[0]')
    cmds.connectAttr ( v_ctrl+'.heelRise ',  vPMA4+'.input1D[1]')
    cmds.connectAttr ( vPMA4 +'.output1D ',  v_revJnts[2]+'.rz', f= True)
    cmds.connectAttr ( v_ctrl+'.heelTwist ',  v_revJnts[2]+'.ry', f= True)  
    
    vClamp5 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp05') # l_legRevers1_jnt
    cmds.connectAttr ( v_ctrl+'.side ', vClamp5+'.inputR'    ) 
    cmds.setAttr (  vClamp5+'.minR', -360)
    v_MDV2 =cmds.createNode ('multiplyDivide',  n = v_Pfx+'MDV2')   
    cmds.connectAttr ( vClamp5+'.outputR',  v_MDV2+'.input1X')
    cmds.setAttr (  v_MDV2+'.input2X', -1)
    cmds.connectAttr ( v_MDV2+'.outputX', v_revJnts[0]+'.rz', f= True)
    
    vClamp6 = cmds.createNode ('clamp',  n = v_Pfx+'Clamp06') # l_legRevers2_jnt
    cmds.connectAttr ( v_ctrl+'.side ', vClamp6+'.inputR'    ) 
    cmds.setAttr (  vClamp6+'.maxR', 360)
    cmds.connectAttr (  vClamp6+'.outputR', v_revJnts[1]+'.rz', f= True)










