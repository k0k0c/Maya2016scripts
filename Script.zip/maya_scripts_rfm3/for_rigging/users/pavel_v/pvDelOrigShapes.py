import maya.cmds as mc
import pvProcedures as pvp

def pvDelOrigShapes():
    ns = pvp.pvGetNs()
    if mc.ls(sl=True):
        geoList = mc.ls(sl=True)
    else:
        geoList = pvp.pvListChildrensExactType (ns + 'geometry_grp', 'mesh')
    for each in geoList:
        shpList = mc.listRelatives(each, shapes=True, f=True)
        if len(shpList) > 2:
            mc.setAttr ('%s.intermediateObject'%shpList[0], 1)
            print '----------------------------------------'
            print 'Geometry Name:'
            print each
            print 'Number of Shapes:'
            print len(shpList)
            print 'Full Shapes List:'
            for fsl in shpList: 
                print fsl
            delShpList = shpList[1:len(shpList) - 1]
            print 'Deleted Shapes List:'
            for dsl in delShpList: 
                print dsl
            for delShp in delShpList:
                print 'Working with Shape:'
                print delShp
                mc.setAttr ('%s.intermediateObject'%delShp, 0)
                mc.delete (each, ch=True)
            mc.delete (delShpList)
            mc.setAttr ('%s.intermediateObject'%shpList[0], 0)