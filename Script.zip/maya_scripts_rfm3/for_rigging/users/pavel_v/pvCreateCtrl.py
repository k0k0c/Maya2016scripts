# create control from selected curve, make orient and rotation by source joint
# make point and orient constraints from controller to joint if necessary

import maya.cmds as mc

def pvCreateCtrl():
    if (mc.window ('copyXform_ui', exists = True)):
        mc.deleteUI ('copyXform_ui')
    mc.window ('copyXform_ui', rtf=True, t='Copy Xform')
    mc.columnLayout (adj=1)
    mc.text ('<< Select Joint then Ctrl >>', align = 'center')
    mc.separator (height=5, style='out')
    mc.checkBox ('checkMCtr', v=0, l='Move Ctrl to Join', align='left')
    mc.separator (height=5, style='in')
    mc.checkBox ('checkOCtr', v=1, l='Orient Ctrl by Join', align='left')
    mc.separator (height=5, style='in')
    mc.checkBox ('checkRCtr', v=1, l='Rotate Ctrl by Joint', align='left')
    mc.separator (height=5, style='in')
    mc.checkBox ('checkOCns', l='Orient Constraint to Joint', align='left')
    mc.separator (height=5, style='in')
    mc.checkBox ('checkPCns', l='Point Constraint to Joint', align='left')
    mc.button (label='Run', c='pvCreateCtrlMain ()')
    mc.showWindow ('copyXform_ui')
	
def pvCreateCtrlMain ():
    objList = mc.ls(sl=True)
    if len(objList) != 2:
        mc.error ('pvCopyXform :: Select two objects and run')
    else:
        source, ctrl = objList
        if ('_bind' in source):
            conNull = source.replace('_bind', '_con')
            oriNull = source.replace('_bind','_ori')
            mainName = source[:-5]
        elif ('_jnt' in sel[0]):
            conNull = source.replace('_jnt', '_con')
            oriNull = source.replace('_jnt', '_ori')
            mainName = source[:-4]
        else:
            conNull = source + '_con'
            oriNull = source + '_ori'
        parCtrl = mc.listRelatives (ctrl, p=True)
        rotOrd = mc.getAttr (source + '.rotateOrder')
        if parCtrl:
            currGrp = mc.group (p=parCtrl, em=True, n=conNull)
        else:
            currGrp = mc.group (em=True, n=conNull)
        mc.setAttr ((conNull + '.rotateOrder'), rotOrd)
        mc.setAttr ((ctrl + '.rotateOrder'), rotOrd)
        if mc.checkBox ('checkOCtr', q = True, v = True):
            mc.delete (mc.orientConstraint (source, conNull, mo=False))
        if mc.checkBox ('checkRCtr', q = True, v = True):
            mc.delete (mc.orientConstraint (source, ctrl, mo=False))
        mc.delete (mc.pointConstraint (source, conNull, mo=False))
        if mc.checkBox ('checkMCtr', q = True, v = True):
            mc.delete (mc.pointConstraint (source, ctrl, mo=False))
        mc.duplicate (conNull, n=oriNull)
        mc.parent (ctrl, currGrp)
        mc.parent (currGrp, oriNull)
        mc.makeIdentity (ctrl, apply=True)
        if checkBox ('checkPCns', q=True, v=True): mc.pointConstraint (ctrl, source, mo=True)
        if checkBox ('checkOCns', q=True, v=True): mc.orientConstraint (ctrl, source, mo=True)
        mc.rename (ctrl, (mainName + '_CT'))