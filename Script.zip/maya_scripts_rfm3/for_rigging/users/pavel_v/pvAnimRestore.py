import maya.cmds as mc
import re

def pvAnimRestore():
    refList = mc.ls(references=True)
    for ref in refList:
        animCurves = mc.listConnections(ref, type='animCurve', s=True)
        if animCurves:
            rex = re.compile(r'^(([a-zA-Z0-9_]*:)*[a-zA-Z]{1}[a-zA-Z0-9_]*_CT)_([a-zA-Z0-9_]*)$')
            for anim in animCurves:
                lookLike = rex.match(anim)
                if lookLike:
                    ctrl = lookLike.groups()[0]
                    attr = lookLike.groups()[2]
                    if mc.objExists (ctrl):
                        if mc.attributeQuery (attr, node = ctrl, exists=True):
                            if not mc.listConnections('%s.%s' % (ctrl,attr), s=True):
                                plHolder = mc.listConnections('%s.output' % anim, d=True, plug=True)
                                mc.disconnectAttr('%s.output' % anim, plHolder, force=True)
                                mc.connectAttr('%s.output' % anim, '%s.%s' % (ctrl,attr), force=True)

    if mc.objExists('_UNKNOWN_REF_NODE_'):
        animCurves = mc.listConnections('_UNKNOWN_REF_NODE_', type='animCurve', s=True)
        if animCurves:
            rex = re.compile(r'^(([a-zA-Z0-9_]*:)*[a-zA-Z]{1}[a-zA-Z0-9_]*_CT)_([a-zA-Z0-9_]*)$')
            for anim in animCurves:
                lookLike = rex.match(anim)
                if lookLike:
                    ctrl = lookLike.groups()[0]
                    attr = lookLike.groups()[2]
                if mc.objExists (ctrl):
                    if mc.attributeQuery (attr, node = ctrl, exists=True):
                        if not mc.listConnections('%s.%s' % (ctrl,attr), s=True):
                            plHolder = mc.listConnections('%s.output' % anim, d=True, plug=True)
                            mc.disconnectAttr('%s.output' % anim, plHolder, force=True)
                            mc.connectAttr('%s.output' % anim, '%s.%s' % (ctrl,attr), force=True)

pvAnimRestore()