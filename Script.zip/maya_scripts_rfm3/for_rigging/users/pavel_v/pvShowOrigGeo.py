import maya.cmds as mc

def pvShowOrigGeo(objNames, origState):
    for obj in objNames:
        origShapes = []
        shapes = mc.listRelatives(obj, c=True, shapes=True)
        for shp in shapes:
            if 'Orig' in shp: origShapes.append(shp)
        if (len(origShapes)==0): error ("Object hasn't any Orig shape.")
        else:
            mc.setAttr ((shapes[0] + '.intermediateObject'), origState)
            mc.setAttr ((origShapes[-1] + ".intermediateObject"), (1 - origState))
