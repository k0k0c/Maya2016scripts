# move points to points on curve, in 4 step
def MovePoints():
    sel=mc.ls(sl=True,fl=True)
    wes={}
    for i in sel:
        wes[i]=mc.xform(i,ws=True,q=True,t=True)
    for a in sel:
        mc.select (a)
        for x in xrange(0,5):                        #steps 5-1=4
            mc.pickWalk (d='right')
        mc.xform (a,t=wes[mc.ls(sl=True,fl=True)[0]], ws=True)
MovePoints()
