#Identify function to use for Maya commands - mc
import maya.cmds as mc

#This declares variable objMagic
objMagic = "win"

#This prevents the duplication of our window
if mc.window(objMagic, ex=True):
    mc.deleteUI(objMagic, window=True)

#Create a window for the object aligner that is not resizeable
objMagic = mc.window(objMagic, title="Eye Rig", s=False, wh=(100, 90), menuBar=True)
# Create rollout menu
mc.menu (label="Edit" )
# Inserting information in small menu
mc.menuItem (label='Help', command="helpWin()")
#Create an adjustable column layout
mc.columnLayout(adj=True)
#Instructions
mc.text(l="First Create:")
#Add a button to our window
mc.button(l="Eye CT", w =50, h=20, c="EyeCT()")
#Instructions
mc.text(l="Than side: ")
#Create an adjustable column layout
mc.rowColumnLayout ( numberOfColumns=2, columnWidth=[(1, 50), (2, 50)])
#Add a button to our window
mc.button(l="R", w =50, h=20, c="Rside()")
#Add a button to our window
mc.button(l="L", w =50, h=20, c="Lside()")
#Show the window
mc.showWindow(objMagic)

#This creates Help window
def helpWin():
    #This declares variable hellWin
    HlpW = "Hwin"
    #This prevents the duplication of our window
    if mc.window(HlpW, ex=True):
       mc.deleteUI(HlpW, window=True)
    
    mc.window(HlpW, title="Help", s=False, wh=(300, 100))
    mc.columnLayout(adj=True)
    mc.text(l="")
    mc.text(l="  This script create eye rig. ", align="left")
    mc.text(l="")
    mc.text(l="  You should have imported all eye blendshapes  ", align="left")
    mc.text(l="  geometry in scene (eyes_default04_opt.mb).", align="left")
    mc.text(l="")
    mc.text(l="  Instructions: First press create 'Eye CT' button,  ", align="left")
    mc.text(l="  than choose any side.", align="left")
    mc.text(l="")
    mc.text(l="  @ Zharkikh Kirill            v 1.0           12.05.2014", align="left")
    mc.text(l="")
    mc.showWindow(HlpW)

#This creates Eye CT
def EyeCT():
    # Create tempGeometry
    mc.polyCylinder( n='tempCylinder1', sx=18, sy=1, sz=1, h=0)
    LprtCnsTmp = mc.parentConstraint ( 'l_eye_geo', 'tempCylinder1' )
    mc.delete (LprtCnsTmp)
    mc.setAttr('tempCylinder1.rx', 90)
    mc.setAttr('tempCylinder1.tz', + 10 )
    mc.setAttr('tempCylinder1.sx', 0.6)
    mc.setAttr('tempCylinder1.sy', 0.6)
    mc.setAttr('tempCylinder1.sz', 0.6)
    mc.delete( 'tempCylinder1.f[8]', 'tempCylinder1.f[7]' )
    #
    mc.circle (n='l_eyeAim_CT')
    mc.setAttr('l_eyeAim_CT.tx', 1.5)
    mc.setAttr('l_eyeAim_CT.sx', 0.4)
    mc.setAttr('l_eyeAim_CT.sy', 0.4)
    mc.setAttr('l_eyeAim_CT.sz', 0.4)
    #
    mc.polyCylinder( n='tempCylinder2', sx=18, sy=1, sz=1, h=0)
    RprtCnsTmp = mc.parentConstraint ( 'r_eye_geo', 'tempCylinder2' )
    mc.delete (RprtCnsTmp)
    mc.setAttr('tempCylinder2.rx', 90)
    mc.setAttr('tempCylinder2.tz', + 10 )
    mc.setAttr('tempCylinder2.sx', 0.6)
    mc.setAttr('tempCylinder2.sy', 0.6)
    mc.setAttr('tempCylinder2.sz', 0.6)
    mc.delete( 'tempCylinder2.f[16]', 'tempCylinder2.f[17]' )
    #
    mc.circle (n='r_eyeAim_CT')
    mc.setAttr('r_eyeAim_CT.tx', -1.5)
    mc.setAttr('r_eyeAim_CT.sx', 0.4)
    mc.setAttr('r_eyeAim_CT.sy', 0.4)
    mc.setAttr('r_eyeAim_CT.sz', 0.4)
    
    # Deformations
    mc.polyUnite('tempCylinder1', 'tempCylinder2', n='tempPolySurface1')
    mc.polyBridgeEdge('tempPolySurface1.e[123]', 'tempPolySurface1.e[26]', 'tempPolySurface1.e[124]', 'tempPolySurface1.e[25]', sv1=12, sv2=67, divisions=0 )
    mc.select(['tempPolySurface1.e[107:122]', 'tempPolySurface1.e[179]', 'tempPolySurface1.e[178]', 'tempPolySurface1.e[18:24]', 'tempPolySurface1.e[27:35]'])
    mc.polyToCurve( form=2, degree=1, n='eyesAim_CT')
    
    # Delete tempGeometry
    mc.delete('tempPolySurface1')
    mc.delete('tempCylinder1')
    mc.delete('tempCylinder2')
    
    # PConstrain
    LprtCnsCT = mc.parentConstraint ( 'l_eye_geo', 'l_eyeAim_CT' )
    RprtCnsCT = mc.parentConstraint ( 'r_eye_geo', 'r_eyeAim_CT' )
    mc.delete (LprtCnsCT)
    mc.delete (RprtCnsCT)
    mc.setAttr ('l_eyeAim_CT.tz', + 10 )
    mc.setAttr ('r_eyeAim_CT.tz', + 10 )
    
    # Cleaning
    mc.select('eyesAim_CT')
    mc.FreezeTransformations('eyesAim_CT')
    mc.CenterPivot('eyesAim_CT')
    mc.DeleteHistory('eyesAim_CT')
    mc.select('r_eyeAim_CT')
    mc.FreezeTransformations('r_eyeAim_CT')
    mc.DeleteHistory('r_eyeAim_CT')
    mc.select('l_eyeAim_CT')
    mc.FreezeTransformations('l_eyeAim_CT')
    mc.DeleteHistory('l_eyeAim_CT')
    mc.select(d=True)
    
#This creates Left side
def Lside():
    # Side variable
    L = 'l'
    
    ## Set BS
    mc.select (L + '_eyePupilDilateOut', L + '_eyePupilDilateIn', L + '_eyeDilateOut', L + '_eyeDilateIn', L + '_eyePupilDilateInDopOut', L + '_eye_geo')
    mc.blendShape (frontOfChain=True, tc=0, n= L + '_eyePupilDilateOutIn')
    
    mc.select ( L + '_lensDilateOut', L + '_lensDilateIn', L + '_lens_geo')
    mc.blendShape (frontOfChain=True, tc=0, n= L + '_lensDilateOutIn')
    
    ## Create's nodes
    mc.createNode( 'clamp', n= L + '_eyeMinus_clamp' )
    mc.createNode( 'clamp', n= L + '_eyePlus_clamp' )
    mc.createNode( 'multiplyDivide', n= L + '_eyeMinusInv_mdv' )
    mc.createNode( 'multiplyDivide', n= L + '_eyeInOut01_mdv' )
    mc.createNode( 'multiplyDivide', n= L + '_eyeInOut02_mdv' )
    mc.createNode( 'reverse', n= L + '_eyePlusMinus_rev' )
    
    ## Create's new attributes for controllers
    # 1. pupilDilate
    mc.addAttr( L + '_eyeAim_CT', ln='pupilDilate', at='double', min=-1, max=1, dv=0)
    mc.setAttr( L + '_eyeAim_CT.pupilDilate', e=True, keyable=True)
    # 1. lensDilate
    mc.addAttr( L + '_eyeAim_CT', ln='lensDilate', at='double', min=-1, max=1, dv=0)
    mc.setAttr( L + '_eyeAim_CT.lensDilate', e=True, keyable=True)
    
    # Edit attributes
    mc.setAttr( L + '_eyeMinus_clamp' + '.minR', -1 )
    mc.setAttr( L + '_eyeMinus_clamp' + '.minG', -1 )
    mc.setAttr( L + '_eyePlus_clamp' + '.maxR', 1 )
    mc.setAttr( L + '_eyePlus_clamp' + '.maxG', 1 )
    mc.setAttr( L + '_eyeMinusInv_mdv' + '.input2X', -1 )
    mc.setAttr( L + '_eyeMinusInv_mdv' + '.input2Y', -1 )
    
    ## Connections  (LR + ') (' + LR + ')
    
    mc.connectAttr( 'eyes_null.' + L + '_eyePupilDilateOutIn',  L + '_eyeMinus_clamp.inputR' )
    mc.connectAttr( 'eyes_null.' + L + '_eyePupilDilateOutIn',  L + '_eyePlus_clamp.inputR' )
    mc.connectAttr(  L + '_eyeInOut01_mdv.outputY',  L + '_eyeInOut02_mdv.input1X' )
    mc.connectAttr(  L + '_eyeMinusInv_mdv.outputY',  L + '_lensDilateOutIn.' + L + '_lensDilateOut' )
    mc.connectAttr(  L + '_eyeAim_CT.pupilDilate', 'eyes_null.' + L + '_eyePupilDilateOutIn' )
    mc.connectAttr(  L + '_eyeMinusInv_mdv.outputY',  L + '_eyePupilDilateOutIn.' + L + '_eyeDilateOut' )
    mc.connectAttr(  L + '_eyeMinusInv_mdv.outputX',  L + '_eyePupilDilateOutIn.' + L + '_eyePupilDilateOut' )
    mc.connectAttr(  L + '_eyeInOut01_mdv.outputX',  L + '_eyePupilDilateOutIn.' + L + '_eyePupilDilateInDopOut' )
    mc.connectAttr(  L + '_eyeInOut02_mdv.outputX',  L + '_eyePupilDilateOutIn.' + L + '_eyePupilDilateIn' )
    mc.connectAttr(  L + '_eyeMinus_clamp.outputG',  L + '_eyeMinusInv_mdv.input1Y' )
    mc.connectAttr(  L + '_eyeMinus_clamp.outputR',  L + '_eyeMinusInv_mdv.input1X' )
    mc.connectAttr( 'eyes_null.' + L + '_lensDilateOutIn',  L + '_eyePlus_clamp.inputG' )
    mc.connectAttr( 'eyes_null.' + L + '_lensDilateOutIn',  L + '_eyeMinus_clamp.inputG' )
    mc.connectAttr(  L + '_eyeMinusInv_mdv.outputY',  L + '_eyePlusMinus_rev.inputX' )
    mc.connectAttr(  L + '_eyePlus_clamp.outputR',  L + '_eyeInOut01_mdv.input1X' )
    mc.connectAttr(  L + '_eyePlus_clamp.outputR',  L + '_eyeInOut01_mdv.input1Y' )
    mc.connectAttr(  L + '_eyePlus_clamp.outputG',  L + '_eyePlusMinus_rev.inputY' )
    mc.connectAttr(  L + '_eyePlus_clamp.outputG',  L + '_lensDilateOutIn.' + L + '_lensDilateIn' )
    mc.connectAttr(  L + '_eyeMinusInv_mdv.outputY',  L + '_eyeInOut01_mdv.input2X' )
    mc.connectAttr(  L + '_eyePlus_clamp.outputG',  L + '_eyePupilDilateOutIn.' + L + '_eyeDilateIn' )
    mc.connectAttr(  L + '_eyePlusMinus_rev.outputX',  L + '_eyeInOut01_mdv.input2Y' )
    mc.connectAttr(  L + '_eyePlusMinus_rev.outputY',  L + '_eyeInOut02_mdv.input2X' )
    mc.connectAttr(  L + '_eyeAim_CT.lensDilate', 'eyes_null.' + L + '_lensDilateOutIn' )
    
    ### Joints
    # Create a joints l_eye_bind and l_eyeTip_jnt
    mc.joint (p= [0, 0, 0], n= L + '_eye_bind' )
    mc.joint (p= [0, 0, 0 + 0.7], n= L + '_eyeTip_jnt' )
    
    # Parent joints to eye geometry
    prtCns = mc.parentConstraint ( L + '_eye_geo', L + '_eye_bind' )
    mc.delete (prtCns)
    
    # Create Skin Cluster
    mc.skinCluster( L + '_eye_bind', L + '_eye_geo', tsb=True )
    mc.skinCluster( L + '_eye_bind', L + '_lensDop_geo', tsb=True )
    mc.skinCluster( L + '_eye_bind', L + '_lens_geo', tsb=True )
    
    # Deselect
    mc.select (d=True)
    
    # Parent to head_bind
    mc.parent ( L + '_eye_bind', 'head_bind' )
    
    ### Aim constrain
    mc.aimConstraint ( L + '_eyeAim_CT', L + '_eye_bind', mo=True )
    
    # Parent to eyesAim
    mc.parent ( L + '_eyeAim_CT', 'eyesAim_CT' )
    
    # Deselect
    mc.select (d=True)
    
    # Delete BS
    mc.delete ( L + '_eyePupilDilateOut', L + '_eyePupilDilateIn', L + '_lensDilateOut', L + '_lensDilateOut', L + '_lensDilateIn', L + '_eyeDilateIn', L + '_eyePupilDilateInDopOut', L + '_eyeDilateOut' )


#This creates Right side
def Rside():
    # Side variable
    R = 'r'
    
    ## Set BS
    mc.select (R + '_eyePupilDilateOut', R + '_eyePupilDilateIn', R + '_eyeDilateOut', R + '_eyeDilateIn', R + '_eyePupilDilateInDopOut', R + '_eye_geo')
    mc.blendShape (frontOfChain=True, tc=0, n= R + '_eyePupilDilateOutIn')
    
    mc.select ( R + '_lensDilateOut', R + '_lensDilateIn', R + '_lens_geo')
    mc.blendShape (frontOfChain=True, tc=0, n= R + '_lensDilateOutIn')
    
    ## Create's nodes
    mc.createNode( 'clamp', n= R + '_eyeMinus_clamp' )
    mc.createNode( 'clamp', n= R + '_eyePlus_clamp' )
    mc.createNode( 'multiplyDivide', n= R + '_eyeMinusInv_mdv' )
    mc.createNode( 'multiplyDivide', n= R + '_eyeInOut01_mdv' )
    mc.createNode( 'multiplyDivide', n= R + '_eyeInOut02_mdv' )
    mc.createNode( 'reverse', n= R + '_eyePlusMinus_rev' )
    
    ## Create's new attributes for controllers
    # 1. pupilDilate
    mc.addAttr( R + '_eyeAim_CT', ln='pupilDilate', at='double', min=-1, max=1, dv=0)
    mc.setAttr( R + '_eyeAim_CT.pupilDilate', e=True, keyable=True)
    # 1. lensDilate
    mc.addAttr( R + '_eyeAim_CT', ln='lensDilate', at='double', min=-1, max=1, dv=0)
    mc.setAttr( R + '_eyeAim_CT.lensDilate', e=True, keyable=True)
    
    # Edit attributes
    mc.setAttr( R + '_eyeMinus_clamp' + '.minR', -1 )
    mc.setAttr( R + '_eyeMinus_clamp' + '.minG', -1 )
    mc.setAttr( R + '_eyePlus_clamp' + '.maxR', 1 )
    mc.setAttr( R + '_eyePlus_clamp' + '.maxG', 1 )
    mc.setAttr( R + '_eyeMinusInv_mdv' + '.input2X', -1 )
    mc.setAttr( R + '_eyeMinusInv_mdv' + '.input2Y', -1 )
    
    ## Connections  (LR + ') (' + LR + ')
    
    mc.connectAttr( 'eyes_null.' + R + '_eyePupilDilateOutIn',  R + '_eyeMinus_clamp.inputR' )
    mc.connectAttr( 'eyes_null.' + R + '_eyePupilDilateOutIn',  R + '_eyePlus_clamp.inputR' )
    mc.connectAttr(  R + '_eyeInOut01_mdv.outputY',  R + '_eyeInOut02_mdv.input1X' )
    mc.connectAttr(  R + '_eyeMinusInv_mdv.outputY',  R + '_lensDilateOutIn.' + R + '_lensDilateOut' )
    mc.connectAttr(  R + '_eyeAim_CT.pupilDilate', 'eyes_null.' + R + '_eyePupilDilateOutIn' )
    mc.connectAttr(  R + '_eyeMinusInv_mdv.outputY',  R + '_eyePupilDilateOutIn.' + R + '_eyeDilateOut' )
    mc.connectAttr(  R + '_eyeMinusInv_mdv.outputX',  R + '_eyePupilDilateOutIn.' + R + '_eyePupilDilateOut' )
    mc.connectAttr(  R + '_eyeInOut01_mdv.outputX',  R + '_eyePupilDilateOutIn.' + R + '_eyePupilDilateInDopOut' )
    mc.connectAttr(  R + '_eyeInOut02_mdv.outputX',  R + '_eyePupilDilateOutIn.' + R + '_eyePupilDilateIn' )
    mc.connectAttr(  R + '_eyeMinus_clamp.outputG',  R + '_eyeMinusInv_mdv.input1Y' )
    mc.connectAttr(  R + '_eyeMinus_clamp.outputR',  R + '_eyeMinusInv_mdv.input1X' )
    mc.connectAttr( 'eyes_null.' + R + '_lensDilateOutIn',  R + '_eyePlus_clamp.inputG' )
    mc.connectAttr( 'eyes_null.' + R + '_lensDilateOutIn',  R + '_eyeMinus_clamp.inputG' )
    mc.connectAttr(  R + '_eyeMinusInv_mdv.outputY',  R + '_eyePlusMinus_rev.inputX' )
    mc.connectAttr(  R + '_eyePlus_clamp.outputR',  R + '_eyeInOut01_mdv.input1X' )
    mc.connectAttr(  R + '_eyePlus_clamp.outputR',  R + '_eyeInOut01_mdv.input1Y' )
    mc.connectAttr(  R + '_eyePlus_clamp.outputG',  R + '_eyePlusMinus_rev.inputY' )
    mc.connectAttr(  R + '_eyePlus_clamp.outputG',  R + '_lensDilateOutIn.' + R + '_lensDilateIn' )
    mc.connectAttr(  R + '_eyeMinusInv_mdv.outputY',  R + '_eyeInOut01_mdv.input2X' )
    mc.connectAttr(  R + '_eyePlus_clamp.outputG',  R + '_eyePupilDilateOutIn.' + R + '_eyeDilateIn' )
    mc.connectAttr(  R + '_eyePlusMinus_rev.outputX',  R + '_eyeInOut01_mdv.input2Y' )
    mc.connectAttr(  R + '_eyePlusMinus_rev.outputY',  R + '_eyeInOut02_mdv.input2X' )
    mc.connectAttr(  R + '_eyeAim_CT.lensDilate', 'eyes_null.' + R + '_lensDilateOutIn' )
    
    ### Joints
    # Create a joints l_eye_bind and l_eyeTip_jnt
    mc.joint (p= [0, 0, 0], n= R + '_eye_bind' )
    mc.joint (p= [0, 0, 0 + 0.7], n= R + '_eyeTip_jnt' )
    
    # Parent joints to eye geometry
    prtCns = mc.parentConstraint ( R + '_eye_geo', R + '_eye_bind' )
    mc.delete (prtCns)
    
    # Create Skin Cluster
    mc.skinCluster( R + '_eye_bind', R + '_eye_geo', tsb=True )
    mc.skinCluster( R + '_eye_bind', R + '_lensDop_geo', tsb=True )
    mc.skinCluster( R + '_eye_bind', R + '_lens_geo', tsb=True )
    
    # Deselect
    mc.select (d=True)
    
    # Parent to head_bind
    mc.parent ( R + '_eye_bind', 'head_bind' )
    
    ### Aim constrain
    mc.aimConstraint ( R + '_eyeAim_CT', R + '_eye_bind', mo=True )
    
    # Parent to eyesAim
    mc.parent ( R + '_eyeAim_CT', 'eyesAim_CT' )
    
    # Deselect
    mc.select (d=True)
    
    # Delete BS
    mc.delete ( R + '_eyePupilDilateOut', R + '_eyePupilDilateIn', R + '_lensDilateOut', R + '_lensDilateOut', R + '_lensDilateIn', R + '_eyeDilateIn', R + '_eyePupilDilateInDopOut', R + '_eyeDilateOut' )
