# Zharkikh K.
# 08.12.2014
# Spaces Switcher

# cmds as mc
import maya.cmds as mc

def ki_spcSwtch():

    if not mc.ls (sl=True):
        mc.warning("Object is not selected!")
        return # exit from proc

    # using mc.objExists as attribute exist check
    if not mc.objExists (mc.ls (sl=True)[0] + ".space"):
        mc.warning("Attribute 'space' is not exist!")
        return # exit from proc
    
    global enumList
        
    # window set
    spcSwtchWin = 'spcWin'

    # main function
    enumString = mc.attributeQuery ('space', node=mc.ls (sl=True)[0], listEnum=True)[0]
    enumList = enumString.split (":")
    list = mc.ls (sl=True)
    
    if mc.window (spcSwtchWin, exists=True):
        mc.deleteUI (spcSwtchWin)

    mc.window (spcSwtchWin, title='Spaces Switch', w=200, h=50, mnb=False, mxb=False, sizeable=False)
    mc.columnLayout ()
    # optionMenuGrp has it's own name 'kzSpacesOpMenuGrp' and it's used in another function like variable
    mc.optionMenuGrp ('kzSpacesOpMenuGrp', label='space:', cc='spaceSwitchMain(enumList)')

    # this get every element from enum attribute and create rollout menu with each 
    for each in enumList:
        mc.menuItem (label = each)   

    #show window
    mc.showWindow (spcSwtchWin)
 
# command        
def spaceSwitchMain(enumList):
    # variables
    time = mc.currentTime ( query=True )
    state = mc.optionMenuGrp ('kzSpacesOpMenuGrp', q=True, v=True)
    enumSet = enumList.index (state)
    
    # getting information
    spcT = mc.xform (mc.ls(sl=True)[0], ws=True, t=True, q=True)
    spcR = mc.xform (mc.ls(sl=True)[0], ws=True, ro=True, q=True)
    mc.setKeyframe (mc.ls(sl=True)[0] + '.space', t=time-1)

    # sets
    mc.setAttr (mc.ls(sl=True)[0] + '.space', enumSet)
    mc.setKeyframe (mc.ls(sl=True)[0] + '.space')
    mc.xform (mc.ls(sl=True)[0], ws=True, t=(spcT))
    mc.xform (mc.ls(sl=True)[0], ws=True, ro=(spcR))
    
# clear globals
def clrGlob():
    for any in [var for var in globals().copy() if var[0] != "_" and var != 'clrGlob']:
        del globals()[any]