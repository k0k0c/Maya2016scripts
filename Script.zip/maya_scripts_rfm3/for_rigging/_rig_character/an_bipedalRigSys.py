 


import maya.cmds as cmds
from An_Skeleton import  An_Skeleton as An_Skeleton
from an_BodyRig import  an_BodyRig as an_BodyRig


def an_bipedalRigSys():
    win = "brsSysWin"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Bipedal Rig System v1.00", width=420,  height=390, s=False, rtf=True, menuBar=True )
    cmds.columnLayout ('columnLayoutName'  , adjustableColumn=True)
    tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=5)
    cmds.tabLayout( tabs, edit=True, tabLabel=( (an_skeletonTab(), 'Skeleton maker'), 
                                                (an_BRSTab2(), 'Rigging')) )
    cmds.showWindow()

def an_skeletonTab():
    child1 = cmds.columnLayout (adjustableColumn=True)
    cmds.text ('-Create a template and place the joints at the appropriate places',h=30)
    cmds.button(l='Skeleton template', c='an_SkeletonTemplate("template")')
    cmds.frameLayout( label='Template display mode:', bgc =[0,0,0] ) 
    cmds.canvas( height=5 )
    if cmds.objExists('general_CT.axesSize'):
        cmds.checkBoxGrp( 'AxisCHB',   numberOfCheckBoxes=1, label='Axis visibility:  ', cc = "an_chekBoxSwitch('AxisCHB')",  v1=False)
        cmds.attrFieldSliderGrp('AxisSizeFSG', l='Axis size:  ', min=0, max=10, attribute="general_CT.axesSize" )  
        cmds.checkBoxGrp( 'JointCHB' ,  numberOfCheckBoxes=1, label='Joint visibility:  ', cc= "an_chekBoxSwitch('JointCHB')",  v1=False )
        cmds.checkBoxGrp( 'ctCHB' ,  numberOfCheckBoxes=1, label='Controllers visibility:  ', cc= "an_chekBoxSwitch('ctCHB')",  v1=True )
        cmds.attrFieldSliderGrp('ctSizeFSG', l='SpheresSize:  ', min=0, max=10, attribute="general_CT.SpheresSize" ) 
        cmds.radioButtonGrp('HandRBG', label='Hand axis: ', labelArray2=['Fingers', 'Revers'], numberOfRadioButtons=2, sl= 1, onCommand1 = 'an_axisSwitch("handOn")', onCommand2 = 'an_axisSwitch("handRevers")')
        cmds.radioButtonGrp('LegRBG', label='Leg axis: ', labelArray2=['Leg', 'Revers'], numberOfRadioButtons=2, sl= 1, onCommand1 = 'an_axisSwitch("legOn")', onCommand2 = 'an_axisSwitch("legRevers")' )
    cmds.canvas( height=5 )
    cmds.setParent( '..' )
    cmds.canvas( height=5 )
    cmds.frameLayout( label='Final skeleton option:', bgc =[0,0,0]  )
    cmds.canvas( height=5 )     
    cmds.checkBoxGrp( 'mirrorCHB' ,  numberOfCheckBoxes=1, label='Mirror joint:  ', cc= "an_chekBoxSwitch('JointCHB')",  v1=True)
    cmds.button(l='Final skeleton', c='an_SkeletonTemplate("skelet")')
    for each in xrange(2) :cmds.setParent( '..' )
    return child1

def an_BRSTab2():
    child1 = cmds.columnLayout (adjustableColumn=True)
    #cmds.text ('-Section is under construction',h=60, al='center')
    cmds.frameLayout( label='Character parts setup:', bgc =[0,0,0]  )
    cmds.button(l='Body rigging', c='an_BodyRig()' )
    
    for each in xrange(2) :cmds.setParent( '..' )
    return child1

def an_axisSwitch(action):
    actArm, actLeg = [], []
    if action == 'handOn': actArm = [1, 0]
    if action == 'handRevers': actArm = [0, 1]
    if action == 'legOn': actLeg = [1, 0]
    if action == 'legRevers': actLeg = [0, 1] 
    if actArm: 
        cmds.setAttr ("general_CT.handAxisVisibility", actArm[0])
        cmds.setAttr ("general_CT.handReversVisibility", actArm[1])        
    if actLeg: 
        cmds.setAttr ("general_CT.legAxisVisibility", actLeg [0])
        cmds.setAttr ("general_CT.legReversVisibility", actLeg [1])       
     
def an_chekBoxSwitch(chBox):
    attr = '.controllersVisibility'
    if  chBox =='AxisCHB':
        attr = '.axisVisibility'  
    if  chBox =='JointCHB':
        attr = '.jointVisibility'
    if cmds.checkBoxGrp( chBox, q=True,  v1=True):  cmds.setAttr ("general_CT"+attr, 1)
    else:   cmds.setAttr ("general_CT"+attr, 0)       
   
def an_SkeletonTemplate(aktion):
    obj = An_Skeleton()
    if aktion == 'template':  
        obj.templateCtrl()
    if aktion == 'skelet':
        obj.skeletFromTemplate()
        if cmds.checkBoxGrp( 'mirrorCHB', q=True,  v1=True): 
            [cmds.mirrorJoint (x, myz=True,  mb=True, sr= ["l_", "r_"]) for x in [obj.shoulderJnt, obj.upLegJnt, obj.legRevers[0], obj.armRevers[0]] ]
    an_bipedalRigSys()         

an_bipedalRigSys()	   
	   

	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
 