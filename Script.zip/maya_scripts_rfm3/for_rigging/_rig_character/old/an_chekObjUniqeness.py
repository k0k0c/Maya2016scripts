import maya.cmds as cmds
import maya.mel as mm

def an_chekObjUniqeness ():
    win = "an_chekObjUniqeness_win"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Object uniqeness cheker.v01", s=True, rtf=True   )
    cmds.columnLayout ("mColumnLayout",adj=True, co=("both", 3))
    cmds.button (l="Select all controllers " , c= "an_selAllCt()")
    cmds.button (l="Chek objects" , c= "an_chekObj()")
    cmds.button (l="Delete list" , c= "an_chekObjUniqeness()")
    cmds.separator()
    cmds.showWindow (win);

def an_chekObj():
    v_list =  cmds.ls (sl = True)
    v_shortList = [v_obj.split("|")[-1] for  v_obj in v_list ]
    for index, string in enumerate(v_shortList):
        if v_shortList.count(string)>1:
            cmds.button (l=string , p= "mColumnLayout"   , c= "cmds.select (\""+ v_list[index] +"\")")


def an_selAllCt():             # select all controllers in scene
    vObjts =  cmds.ls (sl = True)
    if vObjts:                                #videlenie est`
        if  ":" in vObjts[0] :      #ref
            vPrefix = vObjts[0].split(":")[0]
            cmds.select (vPrefix+":*_CT")
        else: cmds.select ("*_CT") #not ref
    else :                                     #videleniya net
        try: cmds.select ("*_CT")
        except ValueError: cmds.select ("*:*_CT")

an_chekObjUniqeness ()
