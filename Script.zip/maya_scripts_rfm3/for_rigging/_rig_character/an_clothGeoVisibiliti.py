 """
Main Procedure: 
    an_insertOffset()

Creation Date:  
    July 17, 2014

Authors: 
    Belyaev Andrey 
    andreikin@mail.ru
    www.3drigging.com  

Description:
 

Installation:

 
				  
How to Use:
 
	
Notes:
 
Comments or suggestions? E-mail me!!!
Good luck!!!


*************************************************************************************************************************	
 version History  
*************************************************************************************************************************
	v2.0
 
 
*************************************************************************************************************************
 Modify at your own risk 
"""



import maya.cmds as cmds
import maya.mel as mm 

def an_clothGeoVisibiliti():
    win = "an_clothGeoVis_win"
    if  cmds.window (win, exists=True ): cmds.deleteUI (win)
    cmds.window (win, t="Cloth geometry visibiliti.v01", s=True, rtf=True   )
    cmds.columnLayout (adj=True, co=("both", 3))
    
    cmds.frameLayout  (  label="Add attribut to switch controller, or input it name (obj.attr) ", borderStyle="etchedIn", bgc= [0, 0, 0], cll= True)
    cmds.separator( style='none' )
    cmds.rowColumnLayout (nc=4, cw=[(1, 100), (2, 150), (3, 100), (4, 100)] ) 

    cmds.text("Switch_controller :")
    cmds.textField("AttrTF", text="ClothVisibility") 
    cmds.button (l="<<Add sel. attr" , c= "an_getObjAndAttr()") 
    cmds.button (l="Add attr to obj>>", c= "an_addAttr()") 
    cmds.setParent( '..' )  
    cmds.rowColumnLayout (nc=3, cw=[(1, 150), (2, 150), (3, 150) ] )     

    cmds.button (l="Add selected to render geo" , c= "an_connectToAttr('renderObj')") 
    cmds.button (l="Add selected to collision geo", c= "an_connectToAttr('collisionObj')") 
    cmds.button (l="Add selected to cloth geo", c= "an_connectToAttr('clothObj')") 
    
    cmds.showWindow (win);
    
an_clothGeoVisibiliti ()    
    
def an_getObjAndAttr():
    obj= cmds.ls (sl=True)[0]  
    attr= cmds.channelBox("mainChannelBox", q=True, sma=True)[0]
    cmds.textField ("AttrTF", e=True, text=obj+"."+attr  )  
 
def an_connectToAttr(type):    
    objs= cmds.ls (sl=True) 
    for obj in objs: 
        attrName = cmds.textField ("AttrTF", q=True, text=True )
        cmds.connectAttr ( attrName.split('.')[0]+'.'+type, obj +".v", f=True)
        if type == 'clothObj': 
            cmds.setAttr (obj +".overrideEnabled", 1)
            cmds.connectAttr ( attrName.split('.')[0]+'.'+type+'Con' , obj +".overrideDisplayType", f=True)
    
def an_addAttr():
    obj= cmds.ls (sl=True)[0] 
    attrName = cmds.textField ("AttrTF", q=True, text=True )
    if not  mm.eval("attributeExists \""+attrName+"\""+obj):   
        cmds.addAttr (obj, ln=attrName,  at="enum", en="off:template:referens:normal", keyable=1)  
        for attr in ['renderObj', 'collisionObj', 'clothObj', 'renderObjCon' , 'collisionObjCon', 'clothObjCon']:
             cmds.addAttr  (obj, ln=attr,  keyable = True) 
        cmds.textField ("AttrTF", e=True, text=obj+"."+attrName  ) 
     
    for index, val in enumerate (([0,1,0,0,0,0], [0,1,1,0,0,1], [1,0,1,0,0,2], [1,0,1,0,0,0])):
        print index, val
        cmds.setDrivenKeyframe ( obj+".renderObj", currentDriver=obj+"."+attrName, dv=index, v=val[0] )
        cmds.setDrivenKeyframe ( obj+".collisionObj", currentDriver=obj+"."+attrName, dv=index, v=val[1] )    
        cmds.setDrivenKeyframe ( obj+".clothObj", currentDriver=obj+"."+attrName, dv=index, v=val[2] ) 
 
        cmds.setDrivenKeyframe ( obj+".renderObjCon", currentDriver=obj+"."+attrName, dv=index, v=val[3] )    
        cmds.setDrivenKeyframe ( obj+".collisionObjCon", currentDriver=obj+"."+attrName, dv=index, v=val[4]) 
        cmds.setDrivenKeyframe ( obj+".clothObjCon", currentDriver=obj+"."+attrName, dv=index, v=val[5] )  
 
 
