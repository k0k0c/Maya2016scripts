
import maya.cmds as cmds


def an_ropeRig_v2():
    v_win = "SplineIKRigUi"
    if cmds.window (v_win, exists=True ): cmds.deleteUI (v_win)
    
    cmds.window (v_win, t="Rope Rig Tools v.2", w=450, h=100)
    
    cmds.columnLayout (adj=1)   
    cmds.separator (st="none", h=10)
    cmds.text ("    Creates a chain of bones that stretches along the curve. Please select curve!", align="left")
    cmds.separator (st="none", h=10)
    cmds.textFieldButtonGrp ('TFBG_Prefix', label="Prefix: ", bl="Assign", bc="cmds.textFieldButtonGrp ('TFBG_Prefix', e=True, tx= cmds.ls(sl=True)[0])")
    
    
    cmds.intSliderGrp ('ISG_1', field=1, minValue=1, maxValue=200, value=20, label=" Joints number: " )
    cmds.separator (st="none", h=3)
    cmds.checkBoxGrp ('CBG',columnWidth2=[141, 165], numberOfCheckBoxes=1, label='Stretchable: ', v1=True)
    cmds.showWindow (v_win)
    cmds.separator (st="none", h=10)
    cmds.button (l="Make rope rig", c="an_doRopeRig()")

an_ropeRig_v2() 


def an_doRopeRig():
    v_jntNum = cmds.intSliderGrp ('ISG_1', q=True, v=True)
    v_prefix = cmds.textFieldButtonGrp ('TFBG_Prefix', q=True, tx=True )
    v_curveName = cmds.rebuildCurve (cmds.ls (sl=True)[0], ch=1, rpo=1,  rt=0, end=1, kr=0, kcp=0, kep=1, kt=0, s=4, d=3, tol=0.01)[0]
    cmds.setAttr (v_curveName+".inheritsTransform", 0)
    cmds.select (v_curveName)
      
    v_arcLength  = cmds.arclen (ch=1) 
    v_curvlength = cmds.getAttr (v_arcLength+".arcLength") 
    
    v_MDVnod=cmds.shadingNode ('multiplyDivide', n=v_prefix+"_MDVnod", asUtility=True)      
    cmds.setAttr (v_MDVnod+".operation", 2)
    cmds.connectAttr ( v_arcLength+".arcLength",  v_MDVnod +".input1X") 
    cmds.setAttr (v_MDVnod +".input2X", v_jntNum)
     
    v_ScaleMDVnod=cmds.shadingNode ('multiplyDivide', n=v_prefix+"_ScaleMDVnod", asUtility=True)
    cmds.setAttr (v_ScaleMDVnod+".operation", 2)
    cmds.connectAttr  (v_MDVnod+".outputX", v_ScaleMDVnod +".input1X") 
    
    v_jointName=[] 
    for v_i in xrange(0,v_jntNum+1):  
        v_jointName.append(cmds.joint (r=True, n=v_prefix+"_twistJnt_"+str(v_i), p=[1, 0, 0]))
        cmds.connectAttr  (v_ScaleMDVnod+".outputX", v_prefix+"_twistJnt_"+str(v_i)+".translateX")
    
    v_ikHandle  = cmds.ikHandle ( n=v_prefix+"_ikHandle",  sol='ikSplineSolver', ccv=False,  pcv=False, sj=v_jointName[0], c=v_curveName)[0]
       
    v_SkaleGrp = cmds.group ( v_curveName, v_ikHandle, v_jointName[0], n=v_prefix+"_SkaleGrp" )
    cmds.xform (os=True, piv=[0, 0, 0])
    cmds.connectAttr  (v_SkaleGrp+".sx", v_ScaleMDVnod +".input2X")
    
    v_CT_jntsName = []
    for  index, v_curvPoint in zip(['1','2','3'], [v_curveName+".cv[0]", v_curveName+".cv[3]", v_curveName+".cv[6]" ] ):
        v_pos = cmds.xform (v_curvPoint, q=True, t=True, ws=True)
        cmds.select (cl=True)
        v_ctJnt= cmds.joint (r=True, n=v_prefix+"_ctrlJnt_"+index, p=v_pos)
        v_CT_jntsName.append(v_ctJnt)
        cmds.parent (v_ctJnt, v_SkaleGrp)
     
    cmds.setAttr (v_ikHandle+".dTwistControlEnable", 1)
    cmds.setAttr (v_ikHandle+".dWorldUpType", 4)
    cmds.setAttr (v_ikHandle+".dWorldUpAxis", 3)
    cmds.connectAttr (v_CT_jntsName[0]+".worldMatrix[0]", v_ikHandle+".dWorldUpMatrix")
    cmds.connectAttr  (v_CT_jntsName[2]+".worldMatrix[0]", v_ikHandle+".dWorldUpMatrixEnd")
    cmds.setAttr (v_ikHandle+".dWorldUpVectorY", 1)
    cmds.setAttr (v_ikHandle+".dWorldUpVectorZ", 0)
    cmds.setAttr (v_ikHandle+".dWorldUpVectorEndY", 1)
    cmds.setAttr (v_ikHandle+".dWorldUpVectorEndZ", 0)
    
    cmds.skinCluster (  v_curveName, v_CT_jntsName[0], v_CT_jntsName[1], v_CT_jntsName[2], dr=4.5)
    
    
    if not cmds.checkBoxGrp ('CBG', q=True, v1=True):
    
        for v_jnt in v_jointName: 
             
            cmds.disconnectAttr  (v_ScaleMDVnod+".outputX", v_jnt+".translateX")
        cmds.delete (v_ScaleMDVnod, v_MDVnod)
        
        
        
        
        
        
        
        
 