import maya.cmds as cmds
def an_fkRig ():
    result = cmds.promptDialog( title='FK rig system', message='Enter controller name:', button=['OK', 'Cancel'], defaultButton='OK', cancelButton='Cancel', dismissString='Cancel')
    if result == 'OK':
    	v_ct = cmds.promptDialog(query=True, text=True)
        v_obj   = cmds.ls(sl=True)[0]
        v_parent =  cmds.listRelatives (v_obj, p=True)
        cmds.circle  (n= v_ct+'_CT', nr= [1, 0, 0], d=1, s=6, ch=False )
        cmds.group(n=v_ct+'_con' )
        v_grp = cmds.group(n=v_ct+'_ori' )
        v_tmp =  cmds.parentConstraint ( v_obj ,  v_grp  )[0]
        cmds.delete (v_tmp)
        cmds.parentConstraint ( v_parent ,  v_grp  , mo=True )
        cmds.connectAttr(v_ct+'_CT'+".rotateOrder", v_obj+".rotateOrder")
        cmds.connectAttr(v_ct+'_CT'+".rotate", v_obj+".rotate")
        cmds.addAttr   (v_ct+'_CT', ln= "length" ,   keyable = True, dv = 1)
        cmds.connectAttr(v_ct+'_CT'+".length", v_obj+".sx")
        for v_attr in ['tx', 'ty', 'tz', 'sx', 'sy', 'sz', 'v']:
            cmds.setAttr (v_ct+"_CT."+v_attr, lock=True, keyable=False  )
    else: pass
an_fkRig ()