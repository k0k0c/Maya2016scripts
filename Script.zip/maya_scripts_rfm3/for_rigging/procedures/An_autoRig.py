import maya.cmds as cmds


class An_autoRig():
    def __init__ (self, name="pers"):
        self.name = name
        self.type = 'bipedal', 'quadruped', 'bird'
        
        self.pfx = ['l_', 'r_', 'up_', 'dw_', 'cntr_'] 
        self.sfx = ['_CT', '_jnt', '_bind', '_grp',  '_ori', '_con', '_geo', '_nurbs', '_proxy', '_aux', '_match', 
                       '_crv', '_ik', '_mdv', '_pma', '_set', '_loc', '_clstr', '_lttc', '_bend', '_bs ', '_space' ]
        self.gen = ['switch', 'general', 'pivotOffset']  
        self.body = ['body', 'pelvis', 'waistIk', 'waist', 'torso', 'hip', 'hips', 'neck', 'head']  
        self.arm = ['elbowIk',  'handIk',  'upArm', 'foreArm', 'hand', 'shoulder']  
        self.leg = ['kneeIk',   'footIk',   'upLeg', 'knee', 'foot']
        
        
        
    def an_ui(): pass



    def devideCT (self): # return  pfx , name, sfx
        pfx, sfx  = '', ''
        for each in self.pfx:  
            if each in self.name: pfx = each
        for each in self.sfx:
            if each in self.name: sfx = each
        partA = self.name.split(pfx)[1] if pfx else self.name
        name = partA.split(sfx)[0] if sfx else partA
        return pfx, name, sfx

    def an_seveData(data, key, vFileName = None):
        if not vFileName: vFileName = cmds.fileDialog2(sff = "*.dat" , fileMode=0, caption="Add data"  )
        path =''                                              #poluchaem put`
        for each in vFileName[0].split('/')[0:-1]: path = path + each+'/'
        foldContent = cmds.getFileList(folder='D:/tmp/')     #poluchaem content papki

        if not vFileName[0].split('/')[-1] in  foldContent:  # esli net faila s info to cozdaem ego
            f = open(vFileName[0], 'w')              #sohranyaem info
            cPickle.dump({key:data} , f )
            f.close()
        else:
            f = open(vFileName[0], 'r')     #ili chitaem info i zamenyaem nuzhniy kluch
            fData = cPickle.load(f)
            fData[key]= data
            f.close()

            f = open(vFileName[0], 'w')              #sohranyaem info
            cPickle.dump(fData, f )
            f.close()
        return vFileName #vozvrashaet put` i imya faila

    def an_loadData(key, vFileName = None):
        if not vFileName: vFileName = cmds.fileDialog2(sff = "*.dat" , fileMode=1, caption="Add data"  )
        f = open(vFileName[0], 'r')     #chitaem info
        fData = cPickle.load(f)
        f.close()
        return [fData[key], vFileName]