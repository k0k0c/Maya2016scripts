import maya.cmds as mc
import re
import maya.api.OpenMaya as om

#### set 
def pvSetDrawingOverride(state):
    if state not in (0, 1):
        mo.MGlobal.displayWarning('The argument must be 0 or 1.')
        return
    else:
        for each in mc.ls(sl=True):
            eachSh = mc.listRelatives(each, shapes=True)
            if eachSh:
                for e in eachSh:
                    mc.setAttr('%s.overrideEnabled'%e, state)
            mc.setAttr('%s.overrideEnabled'%each, state)

#### return namespace if exists 'root' group
def pvGetNameSpaces():
    roots = mc.ls('*root')
    nsRoots = mc.ls('*:root')
    if not roots and not nsRoots:
        om.MGlobal.displayInfo('"root" group(s) doesn\'t exists.')
        return
    
    nsList = []
    rootsList = []

    if roots and nsRoots:
        rootsList = roots + nsRoots
    elif roots and not nsRoots:
        rootsList = roots
    elif not roots and nsRoots:
        rootsList = nsRoots

    for each in rootsList:
        if ':' in each:
            nsParts = each.split(':')
            ns = ''
            for i in range(len(nsParts) - 1):
                ns = ns + nsParts[i] + ':'
        elif '_' in each:
            nsParts = each.split('_')
            ns = ''
            for i in range(len(nsParts) - 1):
                ns = ns + nsParts[i] + '_'
        else:
            ns = 'unknown:'

        nsList.append(ns)

    return nsList

#### list childrens exact type for any object
def pvListChildrenExactType(parent, chType):
    listTransform = mc.listRelatives(parent, allDescendents=True, f=True)
    if chType=='transform':
        listChType = [trans for trans in listTransform if mc.nodeType(trans)=='transform']
        return listChType
    elif chType=='joint':
        listChType = [trans for trans in listTransform if mc.nodeType(trans)=='joint']
        return listChType
    elif chType=='cluster':
        listChType = [trans for trans in listTransform if mc.listRelatives(trans, c=True, shapes=True, type='clusterHandle')]
        return listChType
    elif chType=='group':
        listChType = [trans for trans in listTransform if not mc.listRelatives(trans, c=True, shapes=True)]
        return listChType
    elif chType=='bind':
        listChType = [trans for trans in listTransform if '_bind' in trans]
        return listChType
    elif chType=='jnt':
        listChType = [trans for trans in listTransform if '_jnt' in trans]
        return listChType
    elif chType=='geo':
        listChType = [trans for trans in listTransform if mc.listRelatives(trans, c=True, shapes=True, type='mesh')]
        return listChType
    else:
        listChType = [trans for trans in listTransform if mc.listRelatives(trans, c=True, shapes=True, type=chType)]
        return listChType

#### set display override on list of objects by the state argument
def pvDrawOverrideState(objList, state):
    for obj in objList:
        chnl = '%s.overrideEnabled'%obj
        chnlDraw = '%s.drawOverride'%obj
        if pvCheckLockConn(chnl) and pvCheckLockConn(chnlDraw):
            mc.setAttr(chnl, state)
        shapes = mc.listRelatives(obj, c=True, shapes=True)
        if shapes:
            for shp in shapes:
                chnl = '%s.overrideEnabled'%shp
                chnlDraw = '%s.drawOverride'%shp
                if pvCheckLockConn(chnl) and pvCheckLockConn(chnlDraw):
                    mc.setAttr(chnl, state)

#### check channel for lock and conected
def pvCheckLockConn(chnl):
    lock = mc.getAttr(chnl, l=True)
    conn = mc.listConnections(chnl, s=True, d=False)
    if not lock and not conn:
        return True
    else:
        return False

#### select all objects exact type in scene
def pvListAllObjType(type):
    listTransform = mc.ls(type='transform')
    if type=='transform':
        return listTransform
    else:
        listAllType = [trans for trans in listTransform if listRelatives(trans, c=True, shapes=True, type=type)]
        return listAllType

#### set display Handle attribute is off on the list of objects
def pvHandleOff(objList):
    for obj in objList:
        chnl = '%s.displayHandle'%obj
        if pvCheckLockConn(chnl):
            mc.setAttr(chnl, 0)

#### return list of deformers on object
def pvListDeformers(obj):
    hist = listHistory(obj, pdo=1)
    if hist:
        skinSrc = ls(hist, type='skinCluster')
        bsSrc = ls(hist, type='blendShape')
        clstrSrc = ls(hist, type='cluster')
        skinList = [deform for deform in skinSrc if skinSrc]
        bsList = [deform for deform in bsSrc if bsSrc]
        clstrList = [deform for deform in clstrSrc if clstrSrc]
        return skinList, bsList, clstrList

#### return two lists of joints and nurbs influences binded to the skin on selected object
def pvListBindedJoints(object):
    skin = mc.ls(mc.listHistory(object, pdo=1), type='skinCluster')[0]
    if skin:
        infls = mc.skinCluster(skin, q=True, wi=True)
        jnts = mc.ls(infls, type='joint')
        nurbs = list(set(infls).difference(jnts))
        return jnts, nurbs

#### switch state of visibility Original shape and current shape
def pvShowOrigShape(objNames, origState):
    for obj in objNames:
        shapes = mc.listRelatives(obj, c=True, shapes=True)
        origShapes = [shp for shp in shapes if 'Orig' in shp]
        if (len(origShapes)==0):
            om.MGlobal.displayWarning("Object hasn't any Orig shape.")
            return
        else:
            mc.setAttr('%s.intermediateObject'%shapes[0], origState)
            mc.setAttr("%s.intermediateObject"%origShapes[-1], (1 - origState))
            om.MGlobal.displayInfo('Original shape visibility state - %s'%origState)

#### clear reference nodes and namespaces in scene
def pvClearRefNs():
    for each in mc.ls(type='reference'):
        om.MGlobal.displayInfo('Deleted reference node - %s'%each)
        mc.lockNode(each, l=0)
        mc.delete(each)
    for each in mc.namespaceInfo(lon=True):
        if ('UI' not in each) and ('shared' not in each):
            mc.namespace(each, mnr=True, rm=True)
            om.MGlobal.displayInfo('Deleted namespace - %s'%each)

#### move curve's pivot point to start CV
def pvMovePivotToStartCV(curveName):
    cvStart = mc.pointPosition('%s.cp[0]'%curveName, l=True)
    mc.move(cvStart[0], cvStart[1], cvStart[2], '%s.scalePivot'%curveName, '%s.rotatePivot'%curveName)

#### getting skinCluster name on selected object
def pvGetSkinCluster(*args):
    if not args:
        args = mc.ls(selection=True)
    if not args:
        om.MGlobal.displayWarning('Must be specified any object.')
        return
    if len(args) > 1: # check the count of selected objects
        om.MGlobal.displayWarning('Must be specified only one object.')
        return
    hist = mc.listHistory(args[0], pruneDagObjects=True) # try to find history on the destination object
    if not hist: 
        om.MGlobal.displayWarning('Object "%s" has no history.'%args)
        return
    skinCl = mc.ls(hist, type='skinCluster') # try to find skinCluster on the destination object
    if not skinCl:
        om.MGlobal.displayWarning('Object "%s" has no "skinCluster".'%args)
        return
    om.MGlobal.displayInfo('Object: "%s" has skinCluster: %s'%(args[0], skinCl[0]))
    return skinCl[0]

#### remove unused influences in skinCluster
def pvRemoveUnusedInfl(*args):
    if not args:
        sel = mc.ls(selection=True)
        args = pvGetSkinCluster(sel)
    if not args:
        om.MGlobal.displayWarning('Must be specified any "skinCluster".')
        return
    if len(args) != 1: # check the count of selected objects
        om.MGlobal.displayWarning('Must be specified only one "skinCluster".')
        return

    destSkin = args[0]
    influences = mc.skinCluster(destSkin, query=True, influence=True) # getting full list of influences
    weightedInfl = mc.skinCluster(destSkin, query=True, weightedInfluence=True) # getting only weighted influences list
    removeInfl = list(set(influences) - set(weightedInfl)) # getting list with zero weights
    if removeInfl:
        mc.skinCluster(destSkin, edit=True, removeInfluence=removeInfl) # remove influences with zero weights from destination skinCluster
        om.MGlobal.displayInfo('Removed unused influences: %s'%removeInfl)
    else:
        om.MGlobal.displayInfo('SkinCluster has no unused influences.')

def pvMatchInfluences(*args):
    if not args:
        args = mc.ls(selection=True)
    if not args:
        om.MGlobal.displayWarning('Must be specified two objects.')
        return
    if len(args) != 2: # check the count of selected objects
        om.MGlobal.displayWarning('Must be specified only two objects.')
        return

    source, dest = args
    sourceSkin = pvGetSkinCluster(source)
    destSkin = pvGetSkinCluster(dest)
    sourceInfl = mc.skinCluster(sourceSkin, query=True, influence=True)
    destInfl = mc.skinCluster(destSkin, query=True, influence=True)
    sourceDif = list(set(destInfl) - set(sourceInfl))
    destDif = list(set(sourceInfl) - set(destInfl))
    matchInfl = sourceInfl + sourceDif

    if sourceDif:
        mc.skinCluster(sourceSkin, \
                       edit=True, \
                       useGeometry=True, \
                       dropoffRate=4, \
                       polySmoothness=False, \
                       nurbsSamples=25, \
                       lockWeights=True, \
                       weight=0, \
                       addInfluence=sourceDif)

    if destDif:
        mc.skinCluster(destSkin, \
                       edit=True, \
                       useGeometry=True, \
                       dropoffRate=4, \
                       polySmoothness=False, \
                       nurbsSamples=25, \
                       lockWeights=True, \
                       weight=0, \
                       addInfluence=destDif)

    om.MGlobal.displayInfo('Matched influences list: \n%s'%matchInfl)
    return matchInfl

def pvGetSkinInfluences(*args):
    if not args:
        args = mc.ls(selection=True)
    if not args:
        om.MGlobal.displayWarning('Must be specified any object.')
        return
    if len(args) != 1: # check the count of selected objects
        om.MGlobal.displayWarning('Must be specified only one object.')
        return

    skin = pvGetSkinCluster(args)
    skinInfl = mc.skinCluster(skin, query=True, influence=True)
    om.MGlobal.displayInfo('Matched influences list: \n%s'%skinInfl)
    return skinInfl

def pvUnlockAllInfluences(*args):
    if not args:
        args = mc.ls(selection=True)
    if not args:
        om.MGlobal.displayWarning('Must be specified any object(s).')
        return

    for each in args:
            infls = pvGetSkinInfluences(each)
            for inf in infls:
                mc.setAttr('%s.liw'%inf, 0)

def pvRotateToJointOrient(*args):
    if not args:
        args = mc.ls(selection=True)
    if not args:
        om.MGlobal.displayWarning('Must be specified any object(s).')
        return

    for each in args:
        mc.setAttr('%s.jointOrient'%each, *list(mc.getAttr('%s.rotate'%each)[0]), type='double3')
        mc.setAttr('%s.rotate'%each, 0, 0, 0, type='double3')