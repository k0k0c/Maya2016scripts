def an_jntOnCurv(curveName, jntNum = 5 ):
    cmds.select (curveName, r=True )
    curvLength  = cmds.arclen() 
    xVal = curvLength/jntNum
    jointName = range(jntNum+1)  
    for index, string in enumerate(range(jntNum+1)):
    		 jointName[index]= cmds.joint (r=True, p= [xVal, 0, 0])  
    cmds.ikHandle  (sol='ikSplineSolver',   ccv=False,  pcv=False,  sj=jointName[0], ee= jointName[-1], c=curveName)
    
#for eachCurve in cmds.ls (sl=True):
    #an_jntOnCurv(eachCurve, jntNum = 10 )