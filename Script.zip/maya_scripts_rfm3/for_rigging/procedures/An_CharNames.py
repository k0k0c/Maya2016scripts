
import maya.cmds as cmds
class An_CharNames():
    def __init__ (self, name=None, pfx = None):
        self.name = name
        self.pfx = ['l_', 'r_', 'up_', 'dw_', 'cntr_'] 
        self.sfx = ['_CT', '_jnt', '_bind', '_grp',  '_ori', '_con', '_geo', '_nurbs', '_proxy', '_aux', '_match', '_crv', '_ik', '_mdv', '_pma', '_set', '_loc', '_clstr', '_lttc', '_bend', '_bs ', '_space' ]
        self.gen = ['switch', 'general', 'pivotOffset']  
        self.body = ['body', 'pelvis', 'waistIk', 'waist', 'torso', 'hip', 'hips', 'neck', 'head']  
        self.arm = ['elbowIk',  'handIk',  'upArm', 'foreArm', 'hand', 'shoulder']  
        self.leg = ['kneeIk',   'footIk',   'upLeg', 'knee', 'foot']
        self.fingers = ['thumb', 'index', 'middle', 'ring', 'pinky']
              
    def devideName (self): # return  pfx , name, sfx
        pfx, sfx  = '', ''
        for each in self.pfx:  
            if each in self.name[:len(each)]: pfx = each
        for each in self.sfx:
            if each in self.name [-len(each):]: sfx = each
        partA = self.name.split(pfx)[1] if pfx else self.name
        name = partA.split(sfx)[0] if sfx else partA
        return pfx, name, sfx
        
    def an_uniqName(self):
        """
        Adds before suffix two digits if the incoming name is not unique. 
        @param[in] node Name which should be checked
        @return[out] If the incoming name is not unique, return changed name
        """
        import re
        name = self.name	 
        dName =  self.devideName() #devide name  
        dig = re.findall('(\d+)', dName[1][-2:])[0] if  re.findall('(\d+)', dName[1][-2:]) else [] #get the numbers if they have
        i=0
        while cmds.objExists(name): #If the incoming name is not unique:
        	 if len(dig)==2:  endOfName='0'+str(int(dig)+i) if int(dig)<10 else str(int(dig)+i) #change of the last two numbers
        	 if len(dig)==1:  endOfName = dName[1][-2:-1]+str(int(dig)+i) #change  one  last number
        	 if len(dig)==0: endOfName = dName[1][-2:]+'0'+str(i) #add numbers
        	 name = dName[0]+dName[1][0:-2]+endOfName+dName[2] #set new name
        	 if i == 99: break
        	 i=i+1
        return name        

    def generalCtNames(self):
        return     [self.gen[0]+self.sfx[0],		         #general_CT
            		self.gen[1]+self.sfx[0], 		         #pivotOffset_CT
            		self.gen[2]+self.sfx[0]]		         #switch_CT


    def bodyCtNames(self):
        return [self.body[0]+self.sfx[0],		             #body_CT                  body_CT, hips_CT, dw_waist_CT, up_waist_CT, torso_CT
            		self.body[6]+self.sfx[0],       	     #hips_CT        
            		self.pfx[3]+self.body[3]+self.sfx[0],    #dw_waist_CT
            		self.pfx[2]+self.body[3]+self.sfx[0],    #up_waist_CT        
            		self.body[4]+self.sfx[0], ]      	     #torso_CT

            		#self.body[1]+self.sfx[0], 		         #pelvis_CT
            		#self.body[2]+self.sfx[0], 		         #waistIk_CT
            		#self.pfx[2]+self.body[4]+self.sfx[0],    #up_torso_CT
            		#self.body[3]+self.sfx[0]]		         #waist_CT
 
    def armCtNames(self, side): 
        return [side+self.arm[0]+self.sfx[0],                # l_elbowIk_CT
              		side+self.arm[1]+self.sfx[0],            # l_handIk_CT
            		side+self.arm[2]+self.sfx[0],            # l_upArm_CT
            		side+self.arm[3]+self.sfx[0],            # l_foreArm_CT
            		side+self.arm[4]+self.sfx[0],            # l_hand_CT
            		side+self.arm[5]+self.sfx[0]]            # l_shoulder_CT
 
    def legCtNames(self, side): 
        return [side+self.leg[0]+self.sfx[0],                # l_kneeIk_CT
              		side+self.leg[1]+self.sfx[0],            # l_footIk_CT
            		side+self.leg[2]+self.sfx[0],            # l_upLeg_CT
            		side+self.leg[3]+self.sfx[0],            # l_knee_CT
            		side+self.leg[4]+self.sfx[0]]            # l_foot_CT
            		 
    def fingersCtNames(self, side): 
        return [side+self.fingers[0]+self.sfx[0],            # l_thumb_CT
              		side+self.fingers[1]+self.sfx[0],        # l_index_CT
            		side+self.fingers[2]+self.sfx[0],        # l_middle_CT
            		side+self.fingers[3]+self.sfx[0],        # l_ring_CT
            		side+self.fingers[4]+self.sfx[0]]        # l_pinky_CT    
        