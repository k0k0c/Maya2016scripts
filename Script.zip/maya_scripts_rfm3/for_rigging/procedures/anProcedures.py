import maya.cmds as cmds
from An_CharNames import An_CharNames as Names


def an_childCapture(v_objects):
    """
    returns a list  between two specified objects (list),
    or a list of child objects if  one object (string) specified in the input.
        @param[in] two objects (list) or one object (string)
        @return List of children between two objects[] in chain
    """
    v_jntList = [v_objects] if  type(v_objects) == str else [v_objects[0]]
    v_obj= v_jntList [0]
    while cmds.listRelatives (v_obj, children=True ):
        v_obj = cmds.listRelatives (v_obj, children=True )[0]
        v_jntList.append(str(v_obj))
        if  type(v_objects) == list and v_objects[1] == v_obj: return v_jntList
    return v_jntList

def distans (start, end): #return distans  between objects
    from math import  sqrt
    a = cmds.xform  (start, q=True, t=True, ws=True)
    b = cmds.xform  (end, q=True, t=True, ws=True)
    xy = sqrt ((a[0]-b[0])*(a[0]-b[0])+(a[1]-b[1])*(a[1]-b[1]))
    return  sqrt (xy*xy+(a[2]-b[2])*(a[2]-b[2]))


def an_helpLine(chainObj, name="line01_crv"):
    name=Names(Names(name).an_uniqName()).devideName() #get name and suffix
    v_curve = cmds.curve(n =name[0]+name[1]+"_crv",  p=[(0,0,x+1) for x in xrange(0, len(chainObj))], d=1 )
    
    cmds.setAttr (v_curve+".inheritsTransform", 0)
    
    v_grp = cmds.group( v_curve,  n=name[0]+name[1]+"_grp" )
    cmds.setAttr (v_curve +".overrideEnabled", 1)
    cmds.setAttr (v_curve +".overrideDisplayType", 2 )
    for index, obj in enumerate(chainObj):
        v_cluster =cmds.cluster(v_curve+'.cv['+str(index)+']')[1]
        cmds.pointConstraint(obj, v_cluster)
        cmds.setAttr (v_cluster+".visibility", 0)
        cmds.parent (v_cluster, v_grp)
    return v_grp
    
    
    