 
import maya.cmds as cmds      
from An_Controllers import An_Controllers  as ctrl 
from An_Skeleton import An_Skeleton  as An_Skeleton 
from An_CharNames import An_CharNames as An_CharNames


def an_BodyRig():
    name = An_CharNames()
    skel = An_Skeleton()

    swCT = ctrl(name.generalCtNames()[0]) #make switch class object
    swCT.makeController( 'switch',  size = 3, offset = [0,cmds.getAttr(skel.headJnt[1]+'.tx') ,0 ] )
    
    cmds.pointConstraint ( skel.headJnt[1], swCT.name )
    
    swCT.addDevideAttr ('Ik_Fk')
    for attr in ["l_armIkFkSwitch", "r_armIkFkSwitch", "l_legIkFkSwitch", "r_legIkFkSwitch"]:  
        cmds.addAttr (swCT.name, ln=attr, dv=1, min=0, max=1, keyable=True )
    swCT.addDevideAttr ('visCtrls')    
    for attr in ["l_armCtrls", "r_armCtrls", "l_legCtrls", "r_legCtrls", "bodyCtrls", "addCtrls" ]: 
        cmds.addAttr (swCT.name, ln=attr, dv=1, min=0, max=1, keyable=True )
        cmds.setAttr ( swCT.name+'.'+attr, keyable=False,  channelBox=True ) 
    #swCT.addColor ( swCT.name, 'cntrFk')

    jenCT = ctrl(name.generalCtNames()[1]) #make general class object
    jenCT.makeController( 'general',  size = 16  )
    
    jenOffsCT = ctrl(name.generalCtNames()[2]) #make general class object
    jenOffsCT.makeController( 'general',  size = 12  )
    cmds.parent (jenOffsCT.name, jenCT.name)

    bodyCT = ctrl(name.bodyCtNames()[0])    
    bodyCT.makeController( 'body', 7 ) # make body Controller
    bodyCT.gropeCT()                                                
    bodyCT.placeCT (skel.rootJnt , 'point')  # place CT 
    cmds.parent (bodyCT.oriGrp, jenCT.name)
    cmds.parentConstraint (bodyCT.name, skel.rootJnt, mo=True)
    
    for each in [jenCT, jenOffsCT, bodyCT, swCT ]: each.addColor ( swCT.name, 'cntrFk')
    
    ctData =  { 
               name.bodyCtNames()[1]:   { 'type':'fkBody', 'depend':skel.hipsJnt,  'sz':5, 'parent': name.bodyCtNames()[0],  'ofsShape': [0,-.7,0,0,0,0] ,  'ofsPos': [0,0,0,-180, -90, 90]  }, #'hips_CT'
               name.bodyCtNames()[2]:   { 'type':'fkBody', 'depend':skel.spinJnt[0],  'sz':5, 'parent': name.bodyCtNames()[0],  'ofsShape': [0,0,0,0,0,0] ,  'ofsPos': [0,0,0,-180, -90, 90]  }, #'dw_waist_CT'
               name.bodyCtNames()[3]:   { 'type':'fkBody', 'depend':skel.spinJnt[1],  'sz':5, 'parent': name.bodyCtNames()[2],  'ofsShape': [0,0,0,0,0,0] ,  'ofsPos': [0,0,0,-180, -90, 90]  }, #'up_waist_CT'
               name.bodyCtNames()[4]:   { 'type':'torso', 'depend':skel.torsoJnt,  'sz':5, 'parent': name.bodyCtNames()[3],  'ofsShape': [0,2,0,0,0,0] ,  'ofsPos': [0,0,0,-180, -90, 90]  }, #'torso_CT'
               }
              
    for ct in ctData.keys():                        
        ctObj = ctrl(ct)    
        ctObj.makeController( ctData[ct]["type"], ctData[ct]["sz"] ) # make Controller
        ctObj.gropeCT()                                                # grope CT
        ctObj.moveCt  (ctData[ct]["ofsShape"][:3])     # ofset Shape
        ctObj.ratateCt(ctData[ct]["ofsShape"][3:])
        ctObj.placeCT (ctData[ct]["depend"]  , 'point')               # place CT 
        cmds.delete (cmds.orientConstraint(ctData[ct]["depend"],  ctObj.oriGrp, o=ctData[ct]["ofsPos"][3:]))
        cmds.parentConstraint (ctObj.name, ctData[ct]["depend"], mo=True)  
        ctObj.addColor ( swCT.name, 'cntrFk')
        ctObj.hideAttr(['sx', 'sy', 'sz', 'v']) 
        
    for ct in ctData.keys(): 
        cmds.parent ( ct.replace('_CT','_ori'), ctData[ct]["parent"])

    cmds.connectAttr ( swCT.name+'.'+"bodyCtrls", bodyCT.name+'.v' ) 
    
    swCT.hideAttr(['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz', 'v'])
    jenCT.hideAttr(['v'])
    jenOffsCT.hideAttr(['sx', 'sy', 'sz', 'v']) 
    
       
    
    