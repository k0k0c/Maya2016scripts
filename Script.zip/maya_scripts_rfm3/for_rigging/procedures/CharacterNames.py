import maya.cmds as mc
import re


class CharacterNames(object):

    __prefix = ['l_', 'r_', 'up_', 'dw_', 'cntr_'] 
    __suffix = ['_CT', '_jnt', '_bind', '_grp',  '_ori', '_con', '_geo', '_nurbs', '_proxy', '_aux', '_match', '_crv', '_ik', '_mdv', '_pma', '_set', '_loc', '_clstr', '_lttc', '_bend', '_bs ', '_space' ]
    __general = ['switch', 'general', 'pivotOffset']  
    __body = ['body', 'pelvis', 'waistIk', 'waist', 'torso', 'hip', 'hips', 'neck', 'head']  
    __arm = ['elbowIk',  'handIk',  'upArm', 'foreArm', 'hand', 'shoulder']  
    __leg = ['kneeIk',   'footIk',   'upLeg', 'knee', 'foot']
    __fingers = ['thumb', 'index', 'middle', 'ring', 'pinky']

    def __init__ (self, name=None, pfx = None):
        self.name = name

    def divideName (self):
        pref = ''
        suff = ''
        for each in self.__preffix:
            size = len(each)
            if each in self.name[:size]:
                pref = each
        for each in self.__suffix:
            size = len(each)
            if each in self.name [-size:]:
                suff = each
        namePart = self.name.split(pref)[1] if pref else self.name
        name = namePart.split(suff)[0] if suff else namePart
        return pref, name, suff

    def fixNonUniqueName(self, hashes='##'):
        name = self.name
        hashNumber = hashes.count('#')
        currentNumber = re.findall('(\d+)', name)[0]
        newDigits = hashes.replace(hashes, '%0' + str(hashNumber) + 'd')
        numberIncrement = int(currentNumber)
        newNumber = (newDigits % numberIncrement)
        newName = name.replace(currentNumber, newNumber)
        if mc.objExists():
            numberIncrement = int(currentNumber) + 1
            newName = name.replace(currentNumber, newNumber)
        return newName

    @property
    def general(self):
        return [self.__general[0] + self.__suffix[0],		                 # general_CT
            		self.__general[1] + self.__suffix[0], 		             # pivotOffset_CT
            		self.__general[2] + self.__suffix[0]]		             # switch_CT

    @property
    def body(self):
        return [self.__body[0] + self.__suffix[0],		                     # body_CT
            		self.__body[6] + self.__suffix[0],       	             # hips_CT
            		self.__prefix[3] + self.__body[3] + self.__suffix[0],    # dw_waist_CT
            		self.__prefix[2] + self.__body[3] + self.__suffix[0],    # up_waist_CT        
            		self.__body[4] + self.__suffix[0]]      	             # torso_CT

    def getArm(self, side=''):
        return [side + self.__arm[0] + self.__suffix[0],                     # l_elbowIk_CT
              		side + self.__arm[1] + self.__suffix[0],                 # l_handIk_CT
            		side + self.__arm[2] + self.__suffix[0],                 # l_upArm_CT
            		side + self.__arm[3] + self.__suffix[0],                 # l_foreArm_CT
            		side + self.__arm[4] + self.__suffix[0],                 # l_hand_CT
            		side + self.__arm[5] + self.__suffix[0]]                 # l_shoulder_CT

    def getLeg(self, side=''):
        return [side + self.__leg[0] + self.__suffix[0],                     # l_kneeIk_CT
              		side + self.__leg[1] + self.__suffix[0],                 # l_footIk_CT
            		side + self.__leg[2] + self.__suffix[0],                 # l_upLeg_CT
            		side + self.__leg[3] + self.__suffix[0],                 # l_knee_CT
            		side + self.__leg[4] + self.__suffix[0]]                 # l_foot_CT

    def getFingers(self, side=''):
        return [side + self.__fingers[0] + self.__suffix[0],                 # l_thumb_CT
              		side + self.__fingers[1] + self.__suffix[0],             # l_index_CT
            		side + self.__fingers[2] + self.__suffix[0],             # l_middle_CT
            		side + self.__fingers[3] + self.__suffix[0],             # l_ring_CT
            		side + self.__fingers[4] + self.__suffix[0]]             # l_pinky_CT

    def getWholeBody(self, isGeneral=False):
        if isGeneral:
            return self.general + \
                        self.body + \
                        self.getArm('l_') + self.getArm('r_') + \
                        self.getLeg('l_') + self.getLeg('r_') + \
                        self.getFingers('l_') + self.getFingers('r_')
        else:
            return self.body + \
                        self.getArm('l_') + self.getArm('r_') + \
                        self.getLeg('l_') + self.getLeg('r_') + \
                        self.getFingers('l_') + self.getFingers('r_')