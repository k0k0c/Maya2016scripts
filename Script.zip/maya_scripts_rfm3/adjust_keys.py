import pymel.core as pm

# Adjust Keyframes

def set_descreet_key(selected_obj, at, k):
    rk = round(k[0])
    pm.setKeyframe(selected_obj, at=at, t=rk, i=True)

def remove_dangling_key(selected_obj, at, k):
    pm.cutKey(selected_obj, at=at, cl=True, t=[k[0]])

def adjust_keyframes(selected_obj):
    keyable_attrs = pm.listAttr(selected_obj, k=True)
    for at in keyable_attrs:
        keyframes = pm.keyframe(selected_obj, at=at, q=True, sl=True, tc=True, vc=True)
        process_dangling_keyframe(keyframes, selected_obj, at, set_descreet_key)
        process_dangling_keyframe(keyframes, selected_obj, at, remove_dangling_key)

def process_dangling_keyframe(keyframes, selected_obj, at, callback):
    for k in keyframes:
        if k and k[0] % 1 != 0.0:
            callback(selected_obj, at, k)

def get_objects_of_sel_curves():
    selected_curves = pm.keyframe(q=True, sl=True, n=True)
    objs = []
    for crv in selected_curves:
        connections = pm.listConnections(crv, s=False)
        for cn in connections:
            if cn not in objs:
                objs.append(cn)
    return(objs)

# Interface

def gui():
    win = pm.window(title="Anim Utils")
    layout = pm.columnLayout(cat=('left', 5), rs=5)

    pm.separator(hr=True, h=4, p=layout)
    btn_adjust_keys = pm.button(label="Adjust Keyframes", parent=layout)
    pm.separator(hr=True, h=4, p=layout)

    def cmd_blend_curve(*args):
        print "pressed Select Blend Curve"

    def cmd_adjust_keys(*args):
        print "Adjust Keyframes"
        selected_objects = get_objects_of_sel_curves()
        for o in selected_objects:
            adjust_keyframes(o)

    btn_adjust_keys.setCommand(cmd_adjust_keys)

    win.show()