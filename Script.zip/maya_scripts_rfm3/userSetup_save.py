import site
site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os
import re
#from PyQt4 import QtCore, QtGui
from PyQt4 import QtGui, QtCore, QtNetwork, QtSql
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm3')
import melnik_setup

port=0
for i in range(7):
    svobodno=1
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.13)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
        s.bind(("localhost", int("5522"+str(i+3))))
    except socket.error, e:
        svobodno=0
    s.close()
    if svobodno:
        print "Svobodno: "+"5522"+str(i+3)
        port="5522"+str(i+3)
        break
if port == 0:
    QtGui.QMessageBox.warning(QtGui.QWidget(), "Error", "Vse porty zanyaty")
else:    
    cmds.commandPort(n=':'+port)
    cmds.optionVar( iv=('Port open',int(port)))
melnik_setup.updateScene()
melnik_setup.run()