import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]
def densitySetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True), type='transform', allDescendents=True) is None:
			target_obj=cmds.ls(sl=True)
		else:	
			target_obj=cmds.listRelatives(cmds.ls(sl=True), type='transform', allDescendents=True) 
    if mode=='selected':
	    target_obj=cmds.ls(sl=True)    
    for i in range(0,len(target_obj)):
		Attr_check=mel.eval('attributeExists rman__torattr___transformBeginScript '+target_obj[i]+';')
		Attr_rate=0
		if Attr_check==1:
			target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
			target_Rate=re.findall('RiShadingRate [0-9.]+', target_Attr)[0]
			Attr_rate=float(re.findall('[0-9.]+', target_Rate)[0])
			if var=='plus':
			    Attr_rate=Attr_rate+1
			if var=='minus':
			    Attr_rate=Attr_rate/2 
			if var=='fromSetup':
			    Attr_rate=cmds.intFieldGrp("CUTool_Light_setup_RiShadingRate_field", query=True, value1=True) 
			if var=='remove':
			    cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
			if Attr_rate<0.1:
				Attr_rate=1
			if Attr_rate>10:
			    Attr_rate=1
			if target_Rate=='':
				cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'; if(`rman getvar CLASS` == \"RenderRadiosity\") {RiShadingRate 5;}'), type='string')
			elif (target_Rate!='' and Attr_rate!=0):
				cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'), (re.sub('RiShadingRate [0-9.]+', ('RiShadingRate '+str(Attr_rate)), target_Attr)), type='string')
			else:
			    cmds.error('Please check '+target_obj[i]+'!!!\n')
		else:
			mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__torattr___transformBeginScript ("if(`rman getvar CLASS` == \\\"RenderRadiosity\\\") {RiShadingRate 5;}");')
				
#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]			
def shadingRateSetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True), type='mesh', allDescendents=True) is None:
			target_obj=cmds.ls(sl=True, leaf=True, dagObjects=True, shapes=True)
		else:	
			target_obj=cmds.listRelatives(cmds.ls(sl=True), type='mesh', allDescendents=True)
    if mode=='selected':
        target_obj=cmds.ls(sl=True, leaf=True, dagObjects=True, shapes=True)      
    for i in range(0,len(target_obj)):
		Attr_check=mel.eval('attributeExists rman__riattr___ShadingRate '+target_obj[i]+';')
		Attr_rate=0
		if Attr_check==1:
			target_Rate=cmds.getAttr(target_obj[i]+'.rman__riattr___ShadingRate')
			Attr_rate=target_Rate
			if var=='plus':
			    Attr_rate=Attr_rate+((target_Rate<=1.5) and 0.5 or 1.0)
			if var=='minus':
			    Attr_rate=Attr_rate-((target_Rate>=1.5 and target_Rate<=10.0) and 1.0 or ((target_Rate<=1.5) and 0.2 or 0.5))
			if var=='fromSetup':
			    Attr_rate=cmds.intFieldGrp("CUTool_Light_setup_RiShadingRate_field", query=True, value1=True) 
			if var=='remove':
			    cmds.deleteAttr((target_obj[i]+'.rman__riattr___ShadingRate'))
			if Attr_rate<0.1:
				Attr_rate=1
			if Attr_rate>10:
			    Attr_rate=1
			if target_Rate=='':
				cmds.setAttr((target_obj[i]+'.rman__riattr___ShadingRate'),Attr_rate)
			elif (target_Rate!='' and Attr_rate!=0):
				cmds.setAttr((target_obj[i]+'.rman__riattr___ShadingRate'),Attr_rate)
			else:
			    cmds.error('Please check '+target_obj[i]+'!!!\n')
		else:
		    if var!='remove':
			    mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__riattr___ShadingRate 1;')
				
#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]
def illuminateSetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True), type='transform', allDescendents=True) is None:
			target_obj=cmds.ls(sl=True)
		else:	
			target_obj=cmds.listRelatives(cmds.ls(sl=True), type='transform', allDescendents=True)+cmds.ls(sl=True)
    if mode=='selected':
	    target_obj=cmds.ls(sl=True) 
    target_light=[]
    light_array=cmds.ls(sl=True)
    for i in range(0, len(light_array)):
        if re.findall('light', light_array[i], flags=re.IGNORECASE):
            target_light.append(light_array[i])	     	
    for i in range(0, len(target_light)):
        if target_light[i] in target_obj:
            target_obj.remove(target_light[i])
    for i in range(0,len(target_obj)):
        Attr_check=mel.eval('attributeExists rman__torattr___transformBeginScript '+target_obj[i]+';')
        if Attr_check==1:
            for light_i in range(0, len(target_light)):
                target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
                if var=='plus':
                    if target_light[light_i] not in target_Attr:
						cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 0; '), type='string')
                if var=='minus':
                    if target_light[light_i] in target_Attr:
                        buffer_attr=target_Attr.split(';')
                        list_attr=''
                        for attr_i in range(0,len(buffer_attr)):
                            if len(buffer_attr[attr_i])>1:
                                if target_light[light_i] not in buffer_attr[attr_i]:
                                    list_attr=list_attr+buffer_attr[attr_i]+';'    
                        cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')
            if var=='remove':
                print 'rem'
                cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
        else:
            mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__torattr___transformBeginScript ("");')
            for light_i in range(0, len(target_light)):
                target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
                cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 0; '), type='string')
				
		
#lightLinkSetup(make or break)			
def lightLinkSetup(mode):
    if cmds.listRelatives((cmds.ls(sl=True)), allDescendents=True, type='transform') is not None:
        target_objects=cmds.listRelatives((cmds.ls(sl=True)), allDescendents=True, type='transform')+(cmds.ls(sl=True))
    else: target_objects=cmds.ls(sl=True)
    target_light=[]
    light_array=cmds.ls(sl=True)
    for i in range(0, len(light_array)):
        if re.findall('light', light_array[i], flags=re.IGNORECASE):
            target_light.append(light_array[i])
    for i in range(0, len(target_light)):
        for obj_i in range(0, len(target_objects)):
            if mode=='make':
                cmds.lightlink(light=target_light[i], object=target_objects[obj_i], make=True)
            if mode=='break':
                cmds.lightlink(light=target_light[i], object=target_objects[obj_i], b=True)    
				
#REMOVE SLIM SURFACE SHADER 
#CUTool_removeSlimEdits('attribute Name','attribute Type')				
def CUTool_removeSlimEdits(target_edit,target_type):
    target_ref=(cmds.referenceQuery((cmds.ls(sl=True, readOnly=True)[0]),referenceNode=True))
    target_obj=cmds.ls(sl=True, long=True)[0]
    target_edits=cmds.referenceQuery(target_ref, editStrings=True)
    edit_name=[]
    for i in range(0,len(target_edits)):
        if target_obj in target_edits[i]:
            if target_edit in target_edits[i]:
                edit_name.append((target_edits[i]).split(' '))
    for i in range(0,len(edit_name)):
        for edit_i in range(0,len(edit_name[i])):
            if '|' in edit_name[i][edit_i]:
                cmds.referenceEdit(edit_name[i][edit_i], successfulEdits=True, failedEdits=True, editCommand=target_type, removeEdits=True)		
#EXAMPLE: CUTool_removeSlimEdits('rman__torattr___slimSurface','setAttr') <- remove slim surface shader edits

	