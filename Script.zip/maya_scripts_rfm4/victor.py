import maya.cmds as cmds
import maya.mel as mel
from getUVShells import *
import pymel.core.runtime

def victorFlat():
    cmds.delete(ch=True)
    meshOrig = cmds.ls(sl=True)[0]
    meshPlanar = cmds.duplicate(meshOrig, n='%sPlanar' % meshOrig)[0]
    cmds.select(meshOrig)
    cmds.select(meshOrig,add=True)
    global apanels
    apanels = cmds.listRelatives(meshPlanar,f=True,c=True)
    for apanel in apanels:
        mdSetToUvSpace(apanel)

def victorQuad(meshRes = 200):    
    print "meshRes:" + str(meshRes)
    global apanels    
    meshOrig = cmds.ls(sl=True)[0]
    opanels = cmds.listRelatives(meshOrig,f=True,c=True)
    for i in range(0,len(opanels)):
        test = makePlanarMesh(apanels[i],meshRes)
        if test!="error":
            pMesh = cmds.rename(cmds.ls(sl=True)[0],'%sQuad' % opanels[i].split('|')[-1])
            cmds.select(clear=True)
            cmds.select(pMesh,r=True)
            cmds.select(apanels[i],add=True)
            #cmds.CreateWrap()
            #mel.eval("doWrapArgList \"7\" { \"1\",\"0\",\"0.1\", \"2\", \"0\", \"0\", \"0\", \"0\" }")
            mel.eval("doWrapArgList \"7\" { \"1\",\"0\",\"1\", \"2\", \"1\", \"1\", \"0\", \"0\" }")
            #cmds.setAttr(apanels[i]+".dropoff", 20)
            #cmds.setAttr(apanels[i]+".smoothness", 0.05)
            #cmds.setAttr(apanels[i]+".inflType", 2)
            blendShapeNode = cmds.blendShape(opanels[i],apanels[i])
            cmds.blendShape(blendShapeNode,edit=True, w=[(0),(1)])

    


def mdSetToUvSpace(mesh):
    nv = cmds.polyEvaluate(mesh,v=True)
    for v in range(0,nv):
        vert = '%s.vtx[%d]' % (mesh,v)
        uvComps = cmds.polyListComponentConversion(vert,tuv=True)
        if uvComps:
            uvs = cmds.polyEditUV(uvComps[0],q=True)
            
            if uvs:
                cmds.xform(vert,ws=True,t=(uvs[0],uvs[1],0))
                
def makePlanarMesh(mesh, subdivs):
    #mesh='pidzhakPlanar|polySurface4'
    #subdivs=200
    cMesh = cmds.duplicate(mesh)[0]
    #cmds.polySmooth(cMesh,mth=0,dv=1,bnr=1,c=0,kb=1,ksb=1,khe=0,kt=1,kmb=1,suv=1,peh=0,sl=1,dpe=1,ps=0.1,ro=1,ch=1)
    nf = cmds.polyEvaluate(cMesh,f=True)
    cmds.polyExtrudeFacet('%s.f[0:%d]' % (cMesh,nf),ltz=0.2,kft=True)
    cmds.delete(cMesh,ch=True)
    pPlane = cmds.polyCube(w=1,h=1,d=0.05,sx=subdivs,sy=subdivs,sz=1,ch=0)[0]
    cmds.move(0.5,0.5,0.1,pPlane)
    
    
    if cmds.about(v=True) == '2013 x64':
        bMesh = cmds.polyBoolOp(cMesh,pPlane, op=3, ch=0, useThresholds=0, preserveColor=0)[0]
    elif cmds.about(v=True) == '2014':
        bMesh = cmds.polyCBoolOp(cMesh,pPlane, op=3, ch=0, preserveColor=0)[0]

    
    cmds.delete(bMesh,ch=True)
    
    nf = cmds.polyEvaluate(bMesh,f=True)
    nv = cmds.polyEvaluate(bMesh,v=True)
    # shift back to z plane
    if nf!=0:
        cmds.polyMoveVertex( '%s.vtx[0:%d]' % (bMesh,nv), tz=-0.075 )
        
        toDel = []
        for f in range(0,nf):
            face = '%s.f[%d]' % (bMesh,f)
            pos = cmds.xform(face,q=True,ws=True,t=True)
            z = 0
            for i in range(0,len(pos),3):
                z += pos[i+2]
            
            if abs(z) > 0.01:
                toDel.append(face)
    
        cmds.delete(toDel)
    
        return cMesh
    else:
        return "error"
        
def makePlanarMeshHistory(mesh, subdivs):
    cMesh = cmds.duplicate(mesh)[0]
    nf = cmds.polyEvaluate(cMesh,f=True)
    cmds.polyExtrudeFacet('%s.f[0:%d]' % (cMesh,nf),ltz=0.2,kft=True)
    pPlane = cmds.polyCube(w=1,h=1,d=0.05,sx=subdivs,sy=subdivs,sz=1,ch=0)[0]
    cmds.move(0.5,0.5,0.1,pPlane)
    bMesh = cmds.polyBoolOp(cMesh,pPlane, op=3, ch=1, useThresholds=0, preserveColor=0)[0]        
    
    
    
def victorQuadHistory(meshRes = 200):    
    print "meshRes:" + str(meshRes)
    global apanels    
    meshOrig = cmds.ls(sl=True)[0]
    opanels = cmds.listRelatives(meshOrig,f=True,c=True)
    for i in range(0,len(opanels)):
        test = makePlanarMesh(apanels[i],meshRes)
        if test!="error":
            pMesh = cmds.rename(cmds.ls(sl=True)[0],'%sQuad' % opanels[i].split('|')[-1])
            cmds.select(clear=True)
            cmds.select(pMesh,r=True)
            cmds.select(apanels[i],add=True)
            #cmds.CreateWrap()
            mel.eval("doWrapArgList \"7\" { \"1\",\"0\",\"1\", \"2\", \"0\", \"0\", \"0\", \"0\" }")
            #mel.eval("doWrapArgList \"7\" { \"1\",\"0\",\"1\", \"2\", \"1\", \"1\", \"0\", \"0\" }")
            cmds.setAttr(apanels[i]+".dropoff", 20)
            cmds.setAttr(apanels[i]+".smoothness", 0.00)
            cmds.setAttr(apanels[i]+".inflType", 2)
            blendShapeNode = cmds.blendShape(opanels[i],apanels[i])
            cmds.blendShape(blendShapeNode,edit=True, w=[(0),(1)])
    
