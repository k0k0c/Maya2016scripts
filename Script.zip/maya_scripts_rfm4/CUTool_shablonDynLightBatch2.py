import maya.cmds as cmds
import os
import sys
import re
import ml_proxyManager

def ml_makeScene( episode="", scene="", folder="", user_path="" ):
    
    #Get information about scene.
    m_type = folder
    if m_type != "":
        m_root = "//SERVER-3D/Project/UrfinJuse/scenes/"
        m_src_dir = "ep{0}/ep{0}sc{1}/".format( episode, scene )
        m_src_file = "ep{0}sc{1}_anm".format( episode, scene )
        
        #Get source file.
        m_src_file = os.path.join( m_root, m_src_dir, "anm", m_src_file )
        if os.path.exists( m_src_file + ".mb" ):
            m_format = ".mb"
            m_src_file = m_src_file + ".mb"
        elif os.path.exists( m_src_file + ".ma" ):
            m_format = ".ma"
            m_src_file = m_src_file + ".ma"
        else:
            print "Please check animation file for current scene."
            return 0
        m_saveType = m_format == ".mb" and "mayaBinary" or m_format == ".ma" and "mayaAscii"
        
        #Load source file.
        cmds.file( m_src_file, loadReferenceDepth="none", open=True )
        m_start = cmds.playbackOptions( query=True, animationStartTime=True )
        m_end = cmds.playbackOptions( query=True, animationEndTime=True )
        
        #Make new file name.
        m_current_file = "ep{0}sc{1}_{2}".format( episode, scene, m_type )
        m_current_path = os.path.join(  m_root, m_src_dir, m_type, m_current_file + m_format )
        
        #Create new scene.
        cmds.file( new=True, force=True )
        m_namespace = m_current_file
        if user_path == "":
            cmds.file( rename=m_current_path )
        else:
            cmds.file( rename=user_path )
        cmds.playbackOptions( minTime=m_start, animationStartTime=m_start, maxTime=m_end, animationEndTime=m_end )
        cmds.file( m_src_file, reference=True, mergeNamespacesOnClash=False, namespace=m_namespace, loadReferenceDepth="none", type=m_saveType, options="v=0;" )
        
        #Load all references with nested references as original.
        ml_loadOriginalContainers( cmds.referenceQuery( m_src_file, rfn=True ))
        
        #Save new scene.
        cmds.file( force=True, save=True, type="mayaBinary" )
        print "Save scene"
        return 1
        
    else:
        print "Please specify scene type."
        return 0
    
def ml_loadOriginalContainers( m_reference ):
    
    m_filename = cmds.referenceQuery( m_reference, filename=True )
    if not re.findall( "assets/(props/|chars/)", m_filename, re.IGNORECASE ):
        cmds.file( loadReference=m_reference, loadReferenceDepth="topOnly" )
        m_proxy = ml_proxyManager.findProxy( m_reference, "proxy|Proxy", ignore=True )
        if m_proxy:
            ml_proxyManager.switch( m_reference, m_proxy[0] )
            m_childs = cmds.referenceQuery( m_proxy[0], child=True, referenceNode=True )
        else:
            m_childs = cmds.referenceQuery( m_reference, child=True, referenceNode=True )
        if m_childs:
            for i in range( 0, len( m_childs )):
                ml_loadOriginalContainers( m_childs[i] )
    
def referenceAndSaveSceneForShablon_Exec():
    
    attributtes = ( str( "{0}".format( sys.argv[4] ))).split( " " )
    m_episode = attributtes[0]
    m_scene = attributtes[1]
    m_type = attributtes[2]
    print "\n//Start."
    ml_makeScene( episode=m_episode, scene=m_scene, folder=m_type )
    print "\n//End."    
    
referenceAndSaveSceneForShablon_Exec()