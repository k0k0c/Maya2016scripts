import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
import subprocess
import sys
import ast
import shutil
import math
import time
import rfm.slim
import ml_makeProxy
import xml.etree.ElementTree
if cmds.about( b=True ) is False:
	import melnik_setup

def slim_init( wait=1, debug=False ):
	'''
	Start renderman slim.
	-wait = Wait time ( minutes ).
	'''
	if debug is True:
		print 'Initialize renderman slim.'
	cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True and cmds.loadPlugin("RenderMan_for_Maya")
	ml_result = mel.eval('rman slim isconnected') and True or False
	ml_break = time.time() + ( 60 * wait )
	ml_batch = cmds.about( b=True ) and ' -gui 0 -edit 0' or ''
	if ml_result is False:
		mel.eval('rman slim start' + ml_batch )
		while True:
			if mel.eval( 'rman slim isconnected' ):
				if mel.eval( 'rman slim command \"slim GetSlimStatus\"' ):
					ml_result = True
					break
			if time.time() > ml_break:
				break
	return ml_result

def ml_plugins_setup( plugins='', debug=False ):
	'''
	Load plugins.
	-plugins = List plugins.
	-query = Return plugins loading state, without executing.
	'''
	ml_result = []
	ml_plugins = plugins == '' and [ 'RenderMan_for_Maya', 'AbcExport' ] or ( 'list' in str( type( plugins )) and plugins or [ plugins ] )
	for i in range( 0, len( ml_plugins )):
		if not cmds.pluginInfo( ml_plugins[i], query=True, loaded=True ):
			ml_result.append( ml_plugins[i] )
			try:
				if debug is True:
					print 'loadPlugin %s' % ml_plugins[i]
				cmds.loadPlugin( ml_plugins[i] )
			except:
				cmds.warning( 'Errors expected while initialize plugin: %s.' % str( ml_plugins[i] ))
		else:
			if debug is True:
					print 'Plugin already loaded %s' % ml_plugins[i]
	return ml_result
	
def slim_cmd( command, debug=False ):
	'''
	Send commands or messages to renderman slim.
	-command = Slim command or message.
	-debug = Print all outputs.
	'''
	ml_result = []
	ml_slim = rfm.slim.GetSlim()
	ml_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
	for i in range( 0, len( ml_command )):
		ml_temp = ml_slim.Cmd( '"' + ml_command[i] + '"' )
		if debug is True:
			print 'rman slim command "%s" Result: %s' % ( ml_command[i], ( ml_temp and ml_temp or [] ))
		ml_temp and ml_result.append( ml_temp )
	return ml_result

def ml_listConnections( ml_nodes, debug=False, source=True, destination=True, type='' ):
	'''
	List all connections for target node.
	'''
	def mlt_depth( ml_temp ):
		ml_temp = cmds.ls( ml_temp )
		ml_connections = cmds.listConnections( ml_temp, source=source, destination=destination )
		if ml_connections:
			for i in range( 0, len( ml_connections )):
				if ml_connections[i] not in ml_result and ml_connections[i] not in ml_cache and ml_connections[i] not in ml_nodes:
					ml_cache.append( ml_connections[i] )
					if cmds.nodeType( ml_connections[i] ) in ml_type or type == '':
						ml_result.append( ml_connections[i] )
					if debug is True:
						print 'next connection( %s ).' % ml_connections[i]
					mlt_depth( ml_connections[i] )
	ml_result = []
	ml_cache = []
	ml_type = type
	ml_nodes = cmds.ls( ml_nodes )
	mlt_depth( ml_nodes )
	return ml_result

def ml_deleteNode( ml_objects, debug=False ):
	'''
	Delete maya objects.
	'''
	ml_result = []
	ml_ignoreList = [ 'time1', 'sequenceManager1', 'defaultLightList1', 'persp', 'perspShape', 'topShape', 'top', 'frontShape', 'front', 'sideShape', 'side', 'defaultRenderUtilityList1', 'lightList1', 'defaultTextureList1', 'defaultObjectSet', 'defaultViewColorManager', 'hardwareRenderGlobals', 'hardwareRenderingGlobals', 'characterPartition', 'defaultHardwareRenderGlobals', 'ikSystem', 'hyperGraphInfo', 'uiConfigurationScriptNode', 'sceneConfigurationScriptNode', 'hyperGraphLayout', 'globalCacheControl', 'dynController1', 'strokeGlobals' ]
	ml_temp = cmds.ls( ml_objects )
	if ml_temp:
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and ml_temp[i] not in ml_ignoreList:
				ml_result.append( ml_temp[i] )
		if ml_result:
			cmds.delete( ml_result )
			if debug is True:
				print 'delete %s;' % ml_result
	return ml_result

def ml_setAttr( ml_object, ml_value, debug=False, force=False, query=False ):
	'''
	Set attribute value.
	'''
	ml_result = False
	ml_temp = cmds.ls( ml_object, long=True )
	for i in range( 0, len( ml_temp )):
		if cmds.attributeQuery( ml_temp[i].split( '.' )[-1], n=ml_temp[i].split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( ml_temp[i] )):
			if cmds.getAttr( ml_temp[i] ) != ml_value:
				if query is False:
					ml_result = True
					cmds.setAttr( ml_temp[i], ml_value )
					if debug is True:
						print 'setAttr %s %s;' % ( ml_temp[i], ml_value )
			else:
				if query is not False:
					ml_result = False
					if debug is True:
						print "%s not equal %s;" % ( ml_temp[i], ml_value )
	return ml_result

def ml_deleteAttr( ml_object, debug=False, force=False, empty=False ):
	'''
	Delete attribute.
	'''
	if cmds.attributeQuery( ml_object.split( '.' )[-1], n=ml_object.split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( ml_object )) and (( empty is True and not cmds.getAttr( ml_object )) or empty is False ):
		cmds.deleteAttr( ml_object )
		if debug is True:
			print 'deleteAttr %s;' % ml_object
	return ml_object.split( '.' )[0]

def ml_addRmanAttr( ml_object, ml_attribute, ml_value, debug=False ):
	'''
	Add rman attribute.
	'''
	if not cmds.attributeQuery( ml_attribute, n=ml_object, exists=True ):
		mel.eval( 'rmanAddAttr( "%s", "%s", "%s" )' % ( ml_object, ml_attribute, ml_value ) )
		if debug is True:
			print 'rmanAddAttr( "%s", "%s", "%s" )' % ( ml_object, ml_attribute, ml_value )
	return ml_object

def ml_freeze( ml_node, debug=False ):
	ml_temp = cmds.ls( ml_node, dag=True )
	if not cmds.listConnections( ml_temp ):
		try:
			if cmds.getAttr( '%s.tx' % ml_node ) != 0 and cmds.getAttr( '%s.ty' % ml_node ) != 0 and cmds.getAttr( '%s.tz' % ml_node ) != 0:
				cmds.makeIdentity( ml_node, translate=True, apply=True )
				if debug is True:
					print 'makeIdentity -translate true -apply true %s;' % ml_node
		except:
			pass
		try:
			if cmds.getAttr( '%s.sx' % ml_node ) != 1 and cmds.getAttr( '%s.sy' % ml_node ) != 1 and cmds.getAttr( '%s.sz' % ml_node ) != 1:
				cmds.makeIdentity( ml_node, scale=True, apply=True )
				if debug is True:
					print 'makeIdentity -scale true -apply true %s;' % ml_node
		except:
			pass
		
	return ml_node

def ml_uniqueify( debug=False ):
	mel.eval( 'rman slim message "tc_uniqueifyAll"' )
	if debug is True:
		print 'rman slim message "tc_uniqueifyAll"'
	i = 0
	while True:
		ml_status = mel.eval( 'rman slim isconnected' )
		if ml_status:
		    break
		else:
		    if i > 100000000:
		        break
	return True
	
def ml_replaceRmanID( src, dst ):
	'''
	Replace slim id for all nodes.
	-objects = Objects list.
	-depth = Include in object list all childrens.
	'''
	ml_result = []
	ml_objects = cmds.ls( dag=True )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	for i in range( 0, len( ml_objects ) ):
		for p in range( 0, len( ml_attributes ) ):
			if cmds.attributeQuery( ml_attributes[p], n=ml_objects[i], exists=True ):
				value = cmds.getAttr( ml_objects[i] + '.' + ml_attributes[p] )
				if src in value:
					ml_result.append( ml_objects[i] )
					value = value.replace( src, dst )
					cmds.setAttr( ml_objects[i] + '.' + ml_attributes[p], value, type='string' )
	return ml_result

def ml_attachRmanQuery( ml_node ):
	'''
	Query attachment id state.
	'''
	ml_result = []
	ml_objects = cmds.ls( ml_node )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
	for i in range( 0, len( ml_objects )):
		for n in range( 0, len( ml_attributes )):
			if cmds.attributeQuery( ml_attributes[n], n=ml_objects[i], exists=True ) is True:
				ml_value = cmds.getAttr( '%s.%s' % ( ml_objects[i], ml_attributes[n] ))
				if ml_value:
					ml_value = ml_value.split( ',' )
					for v in range( 0, len( ml_value )):
						ml_result.append( ml_value[v] )
	return ml_result

def ml_statistic( ml_node, path='', all=False, debug=False ):
	'''
	Generate statistic.
	'''
	if path == '':
		statistic_name = mel.eval( 'rman stringinterpolate "${STAGE}"' ) + '.string'
		statistic_dir = ( mel.eval( 'rman stringinterpolate "${RMSPROJ}"' ) or mel.eval( 'rman stringinterpolate "${RMSPROD}"' ))
		statistic_path = '%s%s' % ( statistic_dir, statistic_name )
	else:
		statistic_path = path
		statistic_dir = '/'.join( path.split( '/' )[:-1] )
		statistic_name = path.split( '/' )[-1]
	if debug is True:
		print 'statistic: %s' % statistic_path
	mel.eval( 'setCurrentRenderer renderMan;' )
	mel.eval( 'rmanChangeRendererUpdate;' )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_endofframe", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_filename", 'stdout', type="string" )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_xmlfilename", statistic_path, type="string" )
	cmds.setAttr( "renderManGlobals.rman__riattr___ShadingRate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr__volume_depthrelativeshadingrate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riopt__limits_vprelativeshadingrate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr___FocusFactor", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr___MotionFactor", 10 )
	cmds.setAttr( "renderManGlobals.rman__riopt__shading_directlightingsamples", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples0", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples1", 1 )
	cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth0", 2 )
	cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth1", 2 )
	cmds.setAttr( "defaultResolution.width", 128 )
	cmds.setAttr( "defaultResolution.height", 128 )
	cmds.setAttr( "defaultRenderGlobals.startFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.endFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.byFrameStep", 1 )
	#Create statistic camera.
	#Batch render.
	ml_camera = cmds.camera()
	ml_transform = ml_camera[0]
	ml_camera = ml_camera[-1]
	m_cameras_list = cmds.ls( type='camera' )
	[ cmds.setAttr( "%s.renderable" % m_cameras_list[i], 0 ) for i in range( 0, len( m_cameras_list )) ]
	cmds.setAttr( "%s.renderable" % ml_camera, 1 )
	cmds.setAttr( '%s.rotate' % ml_transform, -45, 45, 0 )
	cmds.viewFit( ml_camera )
	if all is False:
		cmds.select( cmds.ls( ml_node, long=True ))
		mel.eval( '$gRManPreviewRenderSelected = 1;' )
	else:
		mel.eval( '$gRManPreviewRenderSelected = 0;' )
	mel.eval( 'rman render;' )
	cmds.delete( ml_transform )
	return statistic_path
	
def ml_listAttached( ml_objects, id=False, node=False, debug=True ):
	'''
	List all slim attached id or objects.
	'''
	ml_result = []
	ml_objects = cmds.ls( ml_objects )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimEnsemble', 'rman__torattr___slimSurface' ]
	for i in range( 0, len( ml_objects )):
		ml_attached = False
		for n in range( 0, len( ml_attributes )):
			if cmds.attributeQuery( ml_attributes[n], n=ml_objects[i], exists=True ):
				ml_value = cmds.getAttr( ml_objects[i] + '.' + ml_attributes[n] ).split( "," )
				if ml_value:
					ml_attached = True
					if debug is True:
						print '%s attached to %s.' % ( ml_objects[i], str( ml_value ))
					for f in range( 0, len( ml_value )):
						if id is True or node is True:
							if id is True:
								if ml_value[f] not in ml_result:
									ml_result.append( ml_value[f] )
							if node is True:
								if ml_objects[i] not in ml_result:
									ml_result.append( ml_objects[i] )
						else:
							if ml_objects[i] not in ml_result:
									ml_result.append( ml_objects[i] )
		if ml_attached is False:
			if debug is True:
				print '%s not attached to any slim nodes.' % ml_objects[i]
	return ml_result
	
def ml_flatRmanAttr( ml_object, ml_attribute, debug=False ):
	'''
	Rebind target attribute to shapes.
	'''
	def ml_flatRmanAttr_depth( ml_node, ml_attribute ):
		ml_childrens = cmds.listRelatives( ml_node, children=True, ni=True, path=True )
		if cmds.attributeQuery( ml_attribute, n=ml_node, exists=True ):
			ml_value = cmds.getAttr( '%s.%s' % ( ml_node, ml_attribute ))
			if ml_childrens:
				ml_deleteAttr( '%s.%s;' % ( ml_node, ml_attribute ), debug=debug )
				for i in range( 0, len( ml_childrens )):
					ml_addRmanAttr( ml_childrens[i], ml_attribute, ml_value, debug=debug )
					ml_moveDownAttr( ml_childrens )
			ml_result.append( ml_node )
	ml_result = []
	ml_flatRmanAttr_depth( ml_object, ml_attribute )
	return ml_result

def ml_rename( ml_node, ml_name, ml_prefix, debug=False ):
	'''
	Generate new name for object by pattern.
	'''
	ml_result = ""
	mlt_incr = 1
	while True:
		ml_result = ml_name + ( "0" * ( 3 - len( str( mlt_incr ) ) ) ) + str( mlt_incr ) + ml_prefix
		if cmds.objExists( ml_result ):
			mlt_incr = mlt_incr + 1
			continue
		else:
			break
	ml_result = cmds.rename( ml_node, ml_result )
	if debug is True:
		print "rename %s %s" % ( ml_node, ml_result )
	return ml_result

def ml_getProject( ml_path, mode='' ):
	'''
	Get project directory.
	-mode = Get project directory from server-3d or renderServer.
	'''
	ml_platform = sys.platform
	ml_mode = mode == '' and 'renderServer' or mode
	ml_server = { 'renderServer':( ml_platform == "win32" and "//renderServer/Project" or "/renderServer/Project" ), 'server-3d':( ml_platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) }
	ml_expr = re.compile('^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)', re.IGNORECASE)
	ml_path = ml_path.split( "/" )
	ml_index = 0
	ml_compile = re.compile( "Project", re.IGNORECASE )
	for ml_temp in ml_path:
		if ml_compile.match( ml_temp ):
			break
		ml_index = ml_index + 1
	ml_project = ml_expr.sub( ml_server[ ml_mode ], "/".join( ml_path[:ml_index + 5] ))
	return ml_project	
	
def ml_exportScene( ml_file, ml_objects, version=False ):
	'''
	Save target objects to new file.
	-filename = Path to saved file.
	-version = Create file version.
	'''
	ml_result = ''
	ml_objects = cmds.ls( ml_objects )
	ml_type = { 'mb':'mayaBinary', 'ma':'mayaAscii' }[ ml_file.split('.')[-1] ]
	if ml_objects != '':
		ml_temp = []
		for i in range( 0, len( ml_objects )):
			if cmds.objExists( ml_objects[i] ):
				ml_temp.append( ml_objects[i] )
		cmds.select( ml_temp )
		cmds.file( ml_file, force=True, type=ml_type, exportSelected=True )
	else:
		cmds.file( force=True, type=ml_type, save=True )
	if version is True:
		ml_work = ml_getVersion( ml_file )
		shutil.copy2( ml_file, ml_work )
	return ml_result
	
def ml_getVersion( ml_path ):
	'''
	Generate new file version.
	-file = Path to target file
	'''
	ml_result = ''
	ml_version = '_v001'
	ml_path = ml_path == '' and cmds.error( 'Please specify path to target file.' ) or ml_path
	ml_scene = ( ml_path.split( '/' )[-1] ).split( '.' )[0]
	ml_format = ( ml_path.split( '/' )[-1] ).split( '.' )[-1]
	ml_project = ml_getProject( ml_path, mode='server-3d' )
	ml_work = ml_project + '/maya/work/'
	if not os.path.isdir( ml_work ):
		os.makedirs( ml_work )
	ml_files = str( os.listdir( ml_work ))
	ml_control = re.findall( ml_scene + '_v([0-9]+)\.' + ml_format, ml_files )
	if ml_control:
		ml_temp = ml_getMaxValue( ml_control ) + 1
		ml_version = '_v' + ( '0' * ( 3 - len( str( ml_temp )))) + str( ml_temp )
	ml_result = ml_work + ml_scene + ml_version + '.' + ml_format
	return ml_result
	
def ml_createCurveControl( name='', parent='', size='', target='', constraint=True, debug=False ):
	'''
	Create curve control shape.
	'''
	def getLenght( node ):
		if node != '':
			bb = { 'min':cmds.getAttr( node + '.boundingBoxMin' )[0], 'max':cmds.getAttr( node + '.boundingBoxMax' )[0] }
			zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
			key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
			return zyx[ key[ True ] ]
		else:
			return 1
	ml_curve_mel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
	ml_curve = mel.eval( ml_curve_mel )
	if debug is True:
		print ml_curve_mel
	ml_length = getLenght( size )
	if name != '':
		ml_curve = cmds.rename( ml_curve, name )
		if debug is True:
			print 'rename %s %s' % ( ml_curve, name )
	cmds.scale( 1.2 * ml_length, 1.2 * ml_length, 1.2 * ml_length, ml_curve )
	cmds.makeIdentity( ml_curve, translate=True, rotate=True, scale=True, apply=True )
	if target != '':
		if constraint is True:
			cmds.parentConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			cmds.scaleConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			if debug is True:
				print 'parentConstraint %s -maintainOffset %s' % ( ml_curve, target )
				print 'scaleConstraint %s -maintainOffset %s' % ( ml_curve, target )
		else:
			cmds.parent( target, ml_curve )
			if debug is True:
				print 'parent %s %s' % ( target, ml_curve )
	if parent != '':
		cmds.parent( ml_curve, parent )
		if debug is True:
			print 'parent %s %s' % ( ml_curve, parent )
	return ml_curve

def ml_txmake( input='', output='' ):
	'''
	Convert input file .tif to .tex or .tex to .tif.
	'''
	import subprocess
	import os
	import re
	mg_output = ''
	mg_txmake = '%srmantree/bin/txmake.exe' % mel.eval( 'rman stringinterpolate "${RMSTREE}"' )
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	mg_input = input != '' and input or cmds.error( 'Please specify path to image source file.' )
	mg_output = output != '' and output or cmds.error( 'Please specify path to image output file.' )
	os.path.isfile( mg_output ) and os.remove( mg_output )
	if re.findall( '.tif$', mg_input ) and re.findall( '.tex$', mg_output ):
		mg_command = [ mg_txmake, '-verbose', '-smode', 'clamp', '-tmode', 'clamp', '-resize', 'up-', mg_input, mg_output ]
	if re.findall( '.tex$', mg_input ) and re.findall( '.tif$', mg_output ):
		mg_command = [ mg_txmake, '-format', 'tiff' , mg_input, mg_output ]
	else:
		cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False

def ml_ptrender( input='', output='', resolution='2048', channel='Ct' ):
	'''
	Convert input file .tif to .tex or .tex to .tif.
	'''
	import subprocess
	import os
	import re
	mg_txmake = '%srmantree/bin/ptrender.exe' % mel.eval( 'rman stringinterpolate "${RMSTREE}"' )
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	os.path.isfile( output ) and os.remove( output )
	if re.findall( '.ptc$', input ) and re.findall( '.tif$', output ):
		mg_command = [ mg_txmake, '-dspy', 'tiff', '-size', resolution, resolution, '-project', 'uv', input, channel, output ]
	else:
	    cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False
		
def ml_setup( query=False, debug=True, path='', hierarchySetup=True, shadingSetup=True, deleteHidden=True, deleteEmpty=True, slimRename=True, deleteCameras=True,
	deleteArchives=True, deleteLayers=True, geometrySetup=True, rmanMaterialsSetup=True, normalDirectionSetup=False, normalAngleSetup=False, 
	setupAttributes=True, meshCombine=True, deleteLights=True, materialExists=True, ensemblesSetup=True, namesSetup=True, deleteUnusedSlimNodes=True, 
	slimSetup=True, bounds=True, bakeColors=True, deleteUnusedNodes=True, deleteHistory=True, uniqueifySlimNodes=True, saveScene=False, proxy=False ):
	'''
	Setup scene.
	'''
	m_result = {}
	print '____________________________________________________________________________'
	print 'Initialization.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	ml_file = path == '' and cmds.file( query=True, sceneName=True ) or path
	ml_file = ml_file != '' and ml_file or 'untitled' 
	ml_scene = ( ml_file.split( '/' )[-1] ).split( '.' )[0]
	print 'file: %s' % ml_file
	print 'name: %s' % ml_scene
	re.findall( 'proxy', ml_file, re.IGNORECASE ) and cmds.error( 'File is proxy version, please specify path to original file.' )
	print '____________________________________________________________________________'
	print 'Load all preferences.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	ml_plugins_setup( debug=debug )
	slim_init( debug=debug )
	slim_cmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim.tcl", debug=debug )
	#Modelling setup 1, 3, 7, 12
	print '____________________________________________________________________________'
	print 'Make root hierarchy.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if hierarchySetup is True:
		if not re.findall( 'render|dyn', ml_file, re.IGNORECASE ):
			ml_temp = cmds.ls( assemblies=True, long=True )
			ml_temp = [ ml_temp[i] for i in range( 0, len( ml_temp )) if not cmds.referenceQuery( ml_temp[i], isNodeReferenced=True ) ]
			ml_rootGrp = cmds.objExists( '|root' ) and cmds.ls( '|root' )[0] or cmds.createNode( "transform", n="root" )
			ml_allRoots = cmds.ls( 'root', long=True )
			if ml_allRoots and len( ml_allRoots ) > 1:
				for i in range( 0, len( ml_allRoots )):
					if not re.findall( '^\|root$|^root$', ml_allRoots[i] ):
						ml_rename( ml_allRoots[i], ml_scene, '_grp', debug=debug )
			if debug is True:
				print 'root group: %s' % ml_rootGrp
			ml_rigGrp = ''
			ml_geometryGrp = ''
			ml_childrens = cmds.listRelatives( ml_rootGrp, children=True, ni=True, path=True )
			ml_unknownGrp = []
			#Get rig and geometry groups.
			if ml_childrens:
				for i in range( 0, len( ml_childrens )):
					if cmds.nodeType( ml_childrens[i] ) == 'transform' and re.findall( 'rig', ml_childrens[i], re.IGNORECASE ) and ml_rigGrp == '':
						ml_rigGrp = ml_childrens[i]
					elif cmds.nodeType( ml_childrens[i] ) == 'transform' and re.findall( 'geo', ml_childrens[i], re.IGNORECASE ) and not re.findall( 'rig', ml_childrens[i], re.IGNORECASE ) and ml_geometryGrp == '':
						ml_geometryGrp = ml_childrens[i]
					else:
						ml_unknownGrp.append( ml_childrens[i] )
			ml_rigGrp = ml_rigGrp == '' and (( cmds.objExists( '|root|rig' ) and cmds.ls( '|root|rig' ) or cmds.createNode( "transform", n="rig", parent=ml_rootGrp ))) or ml_rigGrp
			ml_geometryGrp = ml_geometryGrp == '' and  (( cmds.objExists( '|root|geo_normal' ) and cmds.ls( '|root|geo_normal' ) or cmds.createNode( "transform", n="geo_normal", parent=ml_rootGrp ))) or ml_geometryGrp
			if debug is True:
				print 'geometry group: %s' % ml_geometryGrp
				print 'rig group: %s' % ml_rigGrp
			if ml_unknownGrp:
				for i in range( 0, len( ml_unknownGrp )):
					if not re.findall( 'rig', ml_unknownGrp[i], re.IGNORECASE ):
						print 'Founded unknown group: %s' % ml_unknownGrp[i]
						cmds.parent( ml_unknownGrp[i], ml_geometryGrp )
			#Include all can be used transforms to geometry group.
			for i in range( 0, len( ml_temp )):
				if not re.findall( 'root|top|persp|side|front', ml_temp[i] ):
					print ml_temp[i]
					cmds.parent( ml_temp[i], ml_geometryGrp )
					if debug is True:
						print 'parent %s %s' % ( ml_temp[i], ml_geometryGrp )
			print '____________________________________________________________________________'
			print 'Make root controls.'
			print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
			ml_controlsState = True
			ml_generalCT = cmds.ls( 'general_CT' )
			ml_generalCT_offset = ''
			if not ml_generalCT:
				ml_connections = ml_listConnections( ml_geometryGrp )
				if ml_connections:
					for i in range( 0, len( ml_connections )):
						if cmds.ls( ml_connections[i], dag=True, type='nurbsCurve' ):
							ml_generalCT = ml_connections[i]
							ml_controlsState = False
							if debug is True:
								print 'Unknown controls founded, pass.'
							break
			else:
				ml_childrens = cmds.listRelatives( ml_generalCT, allDescendents=True, path=True )
				ml_shapes = cmds.listRelatives( ml_generalCT, children=True, shapes=True, path=True )
				if ml_childrens and not cmds.listConnections( ml_childrens ) or not ml_childrens and cmds.listConnections( ml_generalCT ) or not ml_shapes:
					ml_controlsState = True
				else:
					ml_controlsState = False
					print 'Controls founded, pass.'
			if ml_controlsState is True:
				if ml_generalCT:
					ml_generalCT_offset = cmds.rename( ml_generalCT, 'general_offset_CT' )
					ml_generalCT = ''
				if not ml_generalCT_offset:
					ml_generalCT_offset = ml_createCurveControl( name='general_offset_CT', parent=ml_rigGrp, size=ml_geometryGrp, target=ml_geometryGrp, constraint=True, debug=debug )
				if not ml_generalCT:
					ml_generalCT = ml_createCurveControl( name='general_CT', parent=ml_rigGrp, size=ml_generalCT_offset, target=ml_generalCT_offset, constraint=False, debug=debug )
			else:
				print '____________________________________________________________________________'
				print 'Setup root controls.'
				print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
				ml_setAttr( [ '%s.tx' % ml_generalCT[0], '%s.ty' % ml_generalCT[0], '%s.tz' % ml_generalCT[0] ], 0, debug=debug )
				try:
					cmds.makeIdentity( ml_generalCT, translate=True, rotate=True, scale=True, apply=True )
				except:
					pass
		else:
			print 'pass'
	else:
		print 'passed...'
	#Get objects list.
	ml_objectsList = cmds.ls( long=True )
	ml_objectsList = [ ml_objectsList[i] for i in range( 0, len( ml_objectsList )) if not cmds.referenceQuery( ml_objectsList[i], isNodeReferenced=True ) ]
	#Texture setup 0.
	print '____________________________________________________________________________'
	print 'Assign lambert to all mesh nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if shadingSetup is True:
		ml_temp = cmds.ls( ml_objectsList, type='mesh', long=True )
		ml_cache = cmds.ls( cmds.sets( 'initialShadingGroup', query=True, nodesOnly=True ), long=True )
		for i in range( 0, len( ml_temp )):
			if ml_temp[i] not in ml_cache:
				cmds.sets( ml_temp[i], edit=True, forceElement='initialShadingGroup' )
				ml_cache.append( ml_temp[i] )
				if debug is True:
					print 'sets -edit -forceElement initialShadingGroup %s' % str( ml_temp[i] )
	else:
		print 'passed...'
	#Modelling setup 0.
	print '____________________________________________________________________________'
	print 'Remove hidden and not used objects.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteHidden is True:
		ml_temp = cmds.ls( ml_objectsList, dag=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and cmds.nodeType():
				if not cmds.listConnections( cmds.ls( ml_temp[i], dag=True, long=True )) and (( cmds.attributeQuery( 'intermediateObject', n=ml_temp[i], exists=True ) and cmds.getAttr( '%s.intermediateObject' % ml_temp[i] ) is True or False ) or ( cmds.attributeQuery( 'visibility', n=ml_temp[i], exists=True ) and cmds.getAttr( '%s.visibility' % ml_temp[i] ) == 0 or False ) or not cmds.listRelatives( ml_temp[i], allDescendents=True, ni=True, path=True )):
					ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	#Modelling setup 10.
	#Texture setup 12.
	print '____________________________________________________________________________'
	print 'Remove unused cameras.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteCameras is True:
		ml_temp = cmds.ls( ml_objectsList, type='camera', ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ):
				ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
				if not re.findall( 'persp|side|front|top|ep[0-9]+|sc[0-9]+', str( ml_parent ), re.IGNORECASE ) and not cmds.listConnections( ml_parent, cmds.ls( ml_parent, dag=True, long=True )):
					cmds.camera( ml_temp[i], edit=True, startupCamera=False )
					ml_deleteNode( ml_parent, debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Delete unused rib archives and alembic caches.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteArchives is True:
		ml_temp = cmds.ls( ml_objectsList, type=[ 'RenderManArchive', 'gpuCache' ], ni=True, dag=True, long=True )
		for i in range( 0, len( ml_temp )):
			ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
			if not cmds.ls( ml_parent, dag=True, type=[ 'mesh', 'nurbsSurface', 'nurbsCurve' ], long=True ) and not cmds.listConnections( ml_parent ):
				ml_deleteNode( ml_temp[i], debug=debug )
			else:
				ml_deleteNode( ml_parent, debug=debug )
	else:
		print 'passed...'
	#Texture setup 7.
	print '____________________________________________________________________________'
	print 'Remove all lights nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteLights is True:
		ml_temp = cmds.ls( ml_objectsList, type=[ 'pointLight', 'volumeLight', 'areaLight', 'spotLight', 'directionalLight', 'ambientLight', 'RMSLightBlocker', 'RMSAreaLight', 'RMSEnvLight', 'RMSGILight', 'RMSCausticLight', 'RMSGIPtcLight', 'RMSGeoAreaLight', 'RMSGeoLightBlocker', 'RMSPointLight' ], ni=True, dag=True, long=True )
		for i in range( 0, len( ml_temp )):
			ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
			if not cmds.ls( ml_parent, dag=True, type=[ 'mesh', 'nurbsSurface', 'nurbsCurve' ], long=True ) and not cmds.listConnections( ml_parent ):
				ml_deleteNode( ml_temp[i], debug=debug )
			else:
				ml_deleteNode( ml_parent, debug=debug )
	else:
		print 'passed...'
	#Modelling setup 9.
	#Texture setup 8.
	print '____________________________________________________________________________'
	print 'Remove all layers.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteLayers is True:
		ml_temp = cmds.ls( type=[ 'RenderMan', 'renderLayer', 'displayLayer', 'animLayer' ] )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and not re.findall( 'default', ml_temp[i], re.IGNORECASE ):
				ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	#Modelling setup 0.
	print '____________________________________________________________________________'
	print 'Remove non manifold components.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if geometrySetup is True:
		ml_temp = cmds.ls( '|root', dag=True, type='mesh', ni=True, visible=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.polyEvaluate( ml_temp[i], vertex=True ) >= 2:
				ml_component = cmds.ls( cmds.polyInfo( ml_temp[i], laminaFaces=True ), fl=True )
				if ml_component:
					if debug is True:
						print 'Founded non manifold faces on: %s' % ml_temp[i]
					cmds.delete( ml_component )
				ml_component = cmds.ls( cmds.polyInfo( ml_temp[i], nonManifoldEdges=True ), fl=True )
				if ml_component:
					if debug is True:
						print 'Founded non manifold edges on: %s' % ml_temp[i]
					cmds.delete( ml_component )
				ml_component = cmds.ls( cmds.polyInfo( ml_temp[i], nonManifoldVertices=True ), fl=True )
				if ml_component:
					if debug is True:
						print 'Founded non manifold vertexes on: %s' % ml_temp[i]
					cmds.polySplitVertex( ml_component )
			else:
				ml_deleteNode( ml_temp[i], debug=debug )
		ml_temp = cmds.ls( '|root', dag=True, type='nurbsCurve', ni=True, visible=True )
		for i in range( 0, len( ml_temp )):
			if cmds.attributeQuery( 'spans', n=ml_temp[i], exists=True ) and cmds.getAttr( '%s.spans' % ml_temp[i] ) < 2:
				ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	#Texture setup 0.
	print '____________________________________________________________________________'
	print 'Rebind to shapes all materials attachements.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if rmanMaterialsSetup is True:
		ml_temp = cmds.ls( ml_objectsList, assemblies=True, long=True, ni=True, visible=True )
		ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
		for i in range( 0, len( ml_temp )):
			for n in range( 0, len( ml_attributes )):
				ml_flatRmanAttr( ml_temp[i], ml_attributes[n], debug=debug )
	else:
		print 'passed...'
	#Modelling setup 8.
	print '____________________________________________________________________________'
	print 'Setup normal direction:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if normalDirectionSetup is True:
		ml_temp = cmds.ls( '|root', type='mesh', dag=True, ni=True )
		for i in range( 0, len( ml_temp )):
			ml_parents = cmds.listRelatives( ml_temp[i], allParents=True, path=True )
			ml_scale = [ cmds.getAttr( '%s.scale' % ml_parents[i] ) for i in range( 0, len( ml_parents )) ]
			cmds.polyNormal( ml_temp[i], normalMode=2, userNormalMode=1 )
			if debug is True:
				print 'polyNormal -normalMode 2 -userNormalMode 1 %s' % ml_temp[i]
			if '-' in str( ml_scale ):
				if cmds.getAttr( '%s.opposite'  % ml_temp[i] ) and debug is True:
					print 'Please check normals direction for %s.' % ml_temp[i]
				cmds.polyNormal( ml_temp[i], normalMode=0, userNormalMode=0 )
				if debug is True:
					print 'polyNormal -normalMode 0 -userNormalMode 0 %s' % ml_temp[i]
	else:
		print 'passed...'
	#Modelling setup 0.
	print '____________________________________________________________________________'
	print 'Setup normal angle:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if normalAngleSetup is not False and 'int' in str( type( normalAngleSetup )):
		ml_temp = cmds.ls( ml_objectsList, type='mesh', dag=True, ni=True )
		for i in range( 0, len( ml_temp )):
			cmds.polySoftEdge( ml_temp[i], angle=normalAngleSetup )
			if debug is True:
				print 'polySoftEdge -angle %s %s' % ( str( normalAngleSetup ), ml_temp[i] )
	else:
		print 'passed...'
	#Modelling setup 2
	print '____________________________________________________________________________'
	print 'Setup names:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if namesSetup is True:
		ml_temp = cmds.ls( '|root', type=[ 'mesh', 'nurbsSurface', 'nurbsCurve' ], dag=True )
		for i in range( 0, len( ml_temp )):
			ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
			ml_parent = ml_parent and cmds.objExists( ml_parent[0] ) and cmds.ls( ml_parent )[0] or ''
			if ml_parent != '':
				if re.findall( 'pPipe|pPlane|polySurface|pCylinder|pCone|pCube|pSphere|nurbsPlan|nurbsTorus|nurbsCone|nurbsCylinder|nurbsCube|nurbsSphere', str( ml_parent )):
					ml_rename( ml_parent, ml_scene, '_geo', debug=debug )
	else:
		print 'passed...'
	#Texture setup 1, 1, 6, 9, 10, 11
	#Modelling setup 5, 11
	print '____________________________________________________________________________'
	print 'Setup attributes:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if setupAttributes is True:
		ml_temp = cmds.ls( '|root', type=[ 'mesh', 'transform', 'nurbsCurve' ], dag=True, ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			#Setup mesh node attributes.
			if cmds.nodeType( ml_temp[i] ) == 'mesh':
				ml_addRmanAttr( ml_temp[i], 'rman__torattr___subdivScheme', '', debug=debug )
				ml_setAttr( '%s.castsShadows' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.receiveShadows' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.primaryVisibility' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.motionBlur' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.visibleInReflections' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.visibleInRefractions' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.doubleSided' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.opposite' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.displaySmoothMesh' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.smoothShading' % ml_temp[i], 1, debug=debug )
				ml_deleteAttr( '%s.rman__torattr___invis' % ml_temp[i], debug=debug )
			#Setup transform node attributes.
			elif cmds.nodeType( ml_temp[i] ) == 'transform':
				ml_freeze( ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___invis' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___subdivScheme' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug )
			#Setup curve node attributes.
			elif cmds.nodeType( ml_temp[i] ) == 'nurbsCurve':
				ml_addRmanAttr( ml_temp[i], 'rman__torattr___invis', '', debug=debug )
				ml_deleteAttr( '%s.rman__torattr___subdivScheme' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug )
			#General setup.
			ml_setAttr( '%s.visibility' % ml_temp[i], 1, debug=debug, query=True )
			ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___postShapeScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___postTransformScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___preShapeScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___transformBeginScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___transformEndScript' % ml_temp[i], debug=debug, empty=True )
	else:
		print 'passed...'
	#Modelling setup 9, 10.
	#Slim setup 9.
	print '____________________________________________________________________________'
	print 'Reattach material ensembles as co-shaders.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if ensemblesSetup is True:
		ml_temp = cmds.ls( '|root', type=[ 'mesh' ], dag=True, ni=True, visible=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=ml_temp[i], exists=True ):
				ml_ensemble = cmds.getAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i] )
				ml_materials = slim_cmd( 'tc_ensembleProperty -id ' + str( ml_ensemble ), debug=debug)
				if ml_materials:
					ml_materials = ml_materials[0].split( ' ' )
					ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
					ml_addRmanAttr( ml_temp[i], 'rman__torattr___slimSurface', ml_materials[0], debug=debug )
					if ml_materials[1:]:
						ml_addRmanAttr( ml_temp[i], 'rman__torattr___slimShader', ','.join( ml_materials[1:] ), debug=debug )
	else:
		print 'passed...'
	#Texture setup 3.
	print '____________________________________________________________________________'
	print 'Combine meshes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if meshCombine is True:
		#Get leaf transforms with no connections.
		ml_combine = []
		ml_transforms = cmds.ls( '|root', dag=True, leaf=True, type='mesh', ni=True, visible=True, long=True )
		ml_transforms = [ cmds.listRelatives( ml_transforms[i], parent=True, path=True )[0] for i in range( 0, len( ml_transforms )) ]
		if ml_transforms:
			for i in range( 0, len( ml_transforms )):
				ml_temp = ml_transforms[i]
				ml_candidate = ''
				while True:
					ml_parent = cmds.listRelatives( ml_temp, parent=True, path=True )
					if ml_parent and not cmds.listConnections( ml_parent ) and not cmds.listConnections( ml_temp ):
						ml_candidate = ml_temp
						ml_temp = ml_parent
						continue
					else:
						if ml_temp not in ml_combine:
							ml_combine.append( ml_temp )
						break
		#Group similar mesh nodes.
		if ml_combine:
			for i in range( 0, len( ml_combine )):
				ml_temp = cmds.ls( ml_combine[i], dag=True, type='mesh', ni=True, visible=True, long=True )
				ml_cache = []
				ml_combine_exec = []
				if ml_temp:
					for n in range( 0, len( ml_temp )):
						if ml_temp[n] not in str( ml_combine_exec ) and not cmds.listConnections( ml_temp[n], destination=False, source=True ):
							ml_combine_cache = []
							if ml_temp[n] not in ml_cache:
								ml_attachedID = ml_attachRmanQuery( ml_temp[n] )
								for f in range( 0, len( ml_temp )):
									ml_law = True
									ml_attachedID_temp = ml_attachRmanQuery( ml_temp[f] )
									for s in range( 0, len( ml_attachedID )):
										if ml_attachedID[s] not in ml_attachedID_temp:
											ml_law = False
									for s in range( 0, len( ml_attachedID_temp )):
										if ml_attachedID_temp[s] not in ml_attachedID:
											ml_law = False
									if ml_law is True and ml_temp[f] not in ml_combine_cache:
										ml_combine_cache.append( ml_temp[f] )
										ml_cache.append( ml_temp[f] )
							if ml_combine_cache:
								ml_combine_exec.append( ml_combine_cache )
				if ml_combine_exec:
					for n in range( 0, len( ml_combine_exec )):
						if len( ml_combine_exec[n] ) > 1:
							print 'Founded can be combined nodes: %s' % ml_combine_exec[n]
							#ml_uniteMesh = cmds.polyUnite( ml_combine_exec[n], mergeUVSets=True, name=( ml_combine_exec[n][0] ).split( '|' )[-1], object=True )
							#ml_uniteMesh = cmds.ls( ml_uniteMesh, type='transform', long=True )
							#cmds.parent( ml_uniteMesh, ml_combine[i] )
							#if debug is True:
								#print 'polyUnite -mergeUVSets %s;' % ml_combine_exec[n]
								#print 'parent %s %s;' % ( ml_uniteMesh, ml_combine[i] )
	else:
		print 'passed...'
	#Texture setup 2.
	#Slim setup 5, 6.
	print '____________________________________________________________________________'
	print 'Remove unused materials from slim.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteUnusedSlimNodes is True:
		ml_slimID = slim_cmd( 'tc_list -appearance _Attachable -return id', debug=debug )
		ml_mayaID = ml_listAttached( cmds.ls( '|root', dag=True, type='mesh', ni=True ), id=True, debug=debug )
		if ml_slimID and ml_mayaID:
			ml_slimID = ml_slimID[0].split( ' ' )
			ml_deletable = ''
			for i in range( 0, len( ml_mayaID )):
				if ml_mayaID[i] not in ml_slimID:
					print 'Failed to find %s slim node.' % ml_mayaID[i]
			for i in range( 0, len( ml_slimID )):
				if ml_slimID[i] not in ml_mayaID:
					ml_deletable = ' '.join( [ ml_deletable, ml_slimID[i] ] )
			if ml_deletable != '':
				slim_cmd( 'tc_delete %s' % ml_deletable, debug=debug )
		else:
			print 'No attached slim nodes founded.'
	else:
		print 'passed...'
	#Slim setup 1, 2, 3, 7, 8, 10, 11, 12, 13, 14, 15, 16.
	print '____________________________________________________________________________'
	print 'Setup slim palettes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if slimSetup is True:
		#Setup palettes.
		slim_cmd( "tc_globalSetup " + ( ml_file.split( '/' )[-1] ).split( '.' )[0], debug=debug )
		#Combine all palettes in one palette.
		slim_cmd( "tc_combinePalettes", debug=debug )
		#Delete disconnected nodes in slim.
		slim_cmd( "tc_clear -disconnected", debug=debug )
		#Texture 4.
	else:
		print 'passed...'
	#Slim setup 4.
	print '____________________________________________________________________________'
	print 'Rename slim nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if slimRename is True:
		ml_temp = cmds.ls( '|root', dag=True, type='mesh' )
		ml_list = ml_listAttached( cmds.ls( '|root', dag=True, type='mesh' ), id=True )
		ml_cache = []
		for i in range( 0, len( ml_temp )):
			if ml_temp[i] not in ml_cache:
				ml_cache.append( ml_temp[i] )
				ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
				ml_idList = ml_listAttached( ml_parent, id=True )
				for n in range( 0, len( ml_idList )):
					if ml_idList[n] not in ml_cache:
						ml_cache.append( ml_idList[n] )
						ml_name = ml_parent.split( '_' )[0]
						slim_cmd( "tc_renameHierarchy " + ml_name + " -id " + ml_idList[n], debug=debug )
	else:
		print 'passed...'
	#Texture setup 8.
	print '____________________________________________________________________________'
	print 'Setup displacement bounds.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if bounds is True:
		ml_temp = ml_listAttached( cmds.ls( '|root', dag=True, long=True, type='mesh', visible=True, ni=True ), node=True, debug=False )
		for i in range( 0, len( ml_temp )):
			ml_xml_file = ml_statistic( ml_temp[i], debug=debug )
			#Get displacement bound.
			ml_bound = []
			print ml_xml_file
			m_xml_string = file( ml_xml_file, 'r' ).read()
			m_xml = xml.etree.ElementTree.fromstring( m_xml_string )
			m_top_lvl = m_xml.findall( '*//stats' )
			for f in range( 0, len( m_top_lvl )):
				if m_top_lvl[f].get( 'name' ) == 'dispBound':
					m_bound_info = m_top_lvl[f].findall( '*' )
					for n in range( 0, len( m_bound_info )):
						if m_bound_info[n].get( 'name' ) == 'displacementBound':
							ml_bound.append( float( m_bound_info[n].text ))
			if ml_bound:
				ml_bound = sum( ml_bound ) * 2.0
				if not cmds.attributeQuery( 'rman__riattr__displacementbound_sphere', n=ml_temp[i], exists=True ):
					ml_addRmanAttr( ml_temp[i], 'rman__riattr__displacementbound_sphere', ml_bound, debug=debug )
					ml_setAttr( '%s.visibility' % ml_temp[i], 1, debug=debug, query=True )
				else:
					ml_setAttr( '%s.rman__riattr__displacementbound_sphere' % ml_temp[i], ml_bound, debug=debug )
				if not cmds.attributeQuery( 'rman__riattr__displacementbound_coordinatesystem', n=ml_temp[i], exists=True ):
					ml_addRmanAttr( ml_temp[i], 'rman__riattr__displacementbound_coordinatesystem', 'shader', debug=debug )
				else:
					cmds.setAttr( '%s.rman__riattr__displacementbound_coordinatesystem' % ml_temp[i], 'shader', type='string' )
	else:
		print 'passed...'
	#Texture setup 4.
	print '____________________________________________________________________________'
	print 'Bake texture to color set.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if bakeColors is True:
		pass
	else:
		print 'passed...'
	#Modelling setup 6.
	#Texture setup 5.
	print '____________________________________________________________________________'
	print 'Delete unused nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteUnusedNodes is True:
		ml_filter = cmds.ls( '|root', dag=True )
		ml_temp = cmds.ls()
		ml_temp = [ ml_temp[i] for i in range( 0, len( ml_temp )) if ml_temp[i] not in ml_filter ]
		for i in range( 0, len( ml_temp )):
			ml_delete = False
			ml_connections = cmds.listConnections( ml_temp[i] )
			if not ml_connections:
				ml_delete = True
			if ml_delete is True:
				ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	#Modelling setup 4.
	print '____________________________________________________________________________'
	print 'Delete history.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteHistory is True:
		ml_temp = cmds.ls( '|root', dag=True, type=[ 'mesh' ], long=True, ni=True, visible=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ):
				mlt_rig = False
				ml_connections = ml_listConnections( ml_temp[i], debug=False, source=True, destination=True, type=[ 'nurbsCurve', 'blendShape', 'animCurveUU', 'animCurveUA', 'animCurveUL' ] )
				if ml_connections:
					mlt_rig = True
					break
				if mlt_rig is False:
					cmds.delete( ml_temp[i], constructionHistory=True )
					if cmds.bakePartialHistory( ml_temp[i], query=True, preDeformers=True ) or cmds.bakePartialHistory( ml_temp[i], query=True, preCache=True ):
						cmds.bakePartialHistory( ml_temp[i], preDeformers=True, preCache=True )
						if debug is True:
							print 'bakePartialHistory -preCache -preDeformers -constructionHistory %s;' % ml_temp[i]
	else:
		print 'passed...'
	#Modelling setup 0.
	print '____________________________________________________________________________'
	print 'Remove empty groups.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteEmpty is True:
		ml_temp = cmds.ls( '|root', dag=True, type='transform', long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and not cmds.listRelatives( ml_temp[i], allDescendents=True, ni=True, path=True ) and not cmds.listConnections( cmds.ls( ml_temp[i], dag=True, ni=True, long=True )):
				ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	#Texture setup 0.
	print '____________________________________________________________________________'
	print 'Uniqueify slim id.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if uniqueifySlimNodes is True:
		ml_uniqueify( debug=debug )
	else:
		print 'passed...'
	#Modelling setup 6, 13.
	#Texture setup 5, 13, 7, 8, 12.
	print '____________________________________________________________________________'
	print 'Save scene.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if saveScene is True:
		ml_exportScene( ml_file, cmds.ls([ '|root', 'mtorPartition' ]), version=True )
	else:
		print 'passed...'
	#Modelling setup 0.
	print '____________________________________________________________________________'
	print 'Make proxy.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if proxy is True:
		ml_makeProxy.ml_makeProxy()
	else:
		print 'passed...'
	return m_result