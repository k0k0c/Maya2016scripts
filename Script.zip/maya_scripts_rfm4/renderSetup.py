import maya.cmds as cmds
import maya.mel as mel
import listFromView
import re
import rfm.passes
import rfm
import rfm.slim
import os
import glob
import shutil
import sys



 
def setup(setAllMeshToLamberParam=True, deletaUnknownNodesParam=True, deleteColotSetsParam=True, defaultPRmanNodesCheckParam=True, imageSequenceParam=True, startEndSequenceParam=True, imageSizeParam=True, commonRenderParam=True, motionBlurParam=True, setFinalPassParam=True, setCustomDisplayParam=True, setCustomLightGroupsParam=True, setShadowSSParam=True, setupShaveParam=True, creataLightGroupParam=True, chekTexureDataParam=True, chekArchiveDataParam=True, repareLightListParam=True, slimMasksParam=True, hideImagePlaneParam=True, autoCreateStereoPassesParam=True, motionFactorParam=True, fixReferenceDeformer=True ):
    cmds.undoInfo(state=True)
    print "renderSetup start"
    if setAllMeshToLamberParam:
        for i in cmds.ls(type="mesh"):
            if re.match(".*CT.*",i):
                cmds.sets(i, forceElement="initialShadingGroup")

    if deletaUnknownNodesParam:
        for rm in cmds.ls(type=["unknown"]):
            try:
                print("rSRRIBRR(1/10) autoClean delete: "+rm)
                cmds.delete(rm)
            except:
                pass

    if deleteColotSetsParam:
        mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm4/pluginLighting/setupUrfinMenu.mel\"")
        mel.eval("deleteColorSets()")

    if defaultPRmanNodesCheckParam:
        if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
            cmds.loadPlugin("RenderMan_for_Maya")

        if mel.eval("currentRenderer") != "renderMan":
            mel.eval("setCurrentRenderer renderMan")     

        if not cmds.objExists("rmanFinalGlobals"):
            mel.eval("rmanCreateGlobals()")
           
        if not cmds.window("unifiedRenderGlobalsWindow",ex=True):
            mel.eval("unifiedRenderGlobalsWindow")

        for i in cmds.ls(type="RenderMan"):
            if re.search("oldrman",i):
                print "delete old: "+ i
                try:
                    cmds.delete(i)
                except:
                    pass
    #cmds.setAttr("defaultRenderGlobals.currentRenderer", "renderMan", type="string")
    #mel.eval("updateRendererUI()")
    
    if imageSequenceParam:
        cmds.setAttr("defaultRenderGlobals.animation", 1)
        cmds.setAttr("defaultRenderGlobals.pff", 1)
        cmds.setAttr("defaultRenderGlobals.peie", 1)
        cmds.setAttr("defaultRenderGlobals.animationRange", 0)
        cmds.setAttr("defaultRenderGlobals.extensionPadding", 4)
        cmds.setAttr("defaultRenderGlobals.outFormatControl", 0)
        cmds.setAttr("defaultRenderGlobals.putFrameBeforeExt", 1)
        cmds.setAttr("defaultRenderGlobals.imageFormat", 3)
        cmds.setAttr("defaultRenderGlobals.enableDefaultLight", 0)
    
    if startEndSequenceParam:
        cmds.setAttr("defaultRenderGlobals.startFrame", l=False)
        cmds.setAttr("defaultRenderGlobals.startFrame", cmds.playbackOptions(q=True, ast=True))
        cmds.setAttr("defaultRenderGlobals.endFrame", l=False)
        cmds.setAttr("defaultRenderGlobals.endFrame", cmds.playbackOptions(q=True, aet=True))

    if imageSizeParam:
        cmds.setAttr("defaultResolution.lockDeviceAspectRatio", 0)
        cmds.setAttr("defaultResolution.deviceAspectRatio", 2.448)
        cmds.setAttr("defaultResolution.pixelAspect", 1)
        cmds.setAttr("defaultResolution.width", 2100)
        cmds.setAttr("defaultResolution.height", 858)
        
    settings = rfm.passes.GetDefaultSettings()
    if commonRenderParam:
        settings[0].SetAttr("rman__riopt__statistics_endofframe",0)
        if not cmds.layout("renderManGlobalsrman__riopt__shading_directlightingsamplesLayout",ex=True):
            mel.eval("global string $gMainPane;setParent $gMainPane;rmanAddRGControl(\"settings:job\", \"Job\", \"shading:directlightingsamples\")")
        settings[0].SetAttr("rman__riattr___ShadingRate",1)
        settings[0].SetAttr("rman__riopt__shading_directlightingsamples",200)
        settings[0].SetAttr("rman__riattr__trace_samplemotion",0)
        settings[0].SetAttr("rman__torattr___motionSamples",2)
        settings[0].SetAttr("rman__riopt__Hider_sigma",0)
        settings[0].SetAttr("rman__riopt___PixelSamples0",8)
        settings[0].SetAttr("rman__riopt___PixelSamples1",8)
        settings[0].SetAttr("rman__riattr__trace_bias",0.01)
        settings[0].SetAttr("rman__riopt__rib_format","binary")
        settings[0].SetAttr("rman__riopt__rib_compression","gzip")
        settings[0].SetAttr("rman__riattr___MotionFactor",1.5)
        settings[0].SetAttr("rman__riattr___FocusFactor",3)
        settings[0].SetAttr("rman__riopt__limits_bucketsize0",16)
        settings[0].SetAttr("rman__riopt__limits_bucketsize1",16)
        settings[0].SetAttr("rman__riopt__limits_proceduralmemory",0)
        settings[0].SetAttr("rman__riopt__limits_geocachememory",2048000)
        settings[0].SetAttr("rman__riopt__limits_radiositycachememory",2048000)
        settings[0].SetAttr("rman__riopt__limits_texturememory",2048000)
        settings[0].SetAttr("rman__riopt__limits_brickmemory",2048000)
        settings[0].SetAttr("rman__riopt__limits_deepshadowtiles",10000)
        settings[0].SetAttr("rman__riopt__limits_deepshadowmemory",2048000)
        settings[0].SetAttr("rman__riopt__limits_othreshold","0.9 0.9 0.9")
        settings[0].SetAttr("rman__riopt__limits_zthreshold","0.9 0.9 0.9")

    #response = cmds.confirmDialog(title="Motion Blur", message="Enable scene motion blur", button=["Yes", "No"], defaultButton="Yes", cancelButton="No", dismissString="No")
    #if response == "Yes":
    #    settings[0].SetAttr("rman__torattr___motionBlur",1)
    #else:
    #    settings[0].SetAttr("rman__torattr___motionBlur",0)
    
    if motionBlurParam:
        settings[0].SetAttr("rman__torattr___motionBlur",1)
        settings[0].SetAttr("rman__torattr___cameraBlur",1)
        settings[0].SetAttr("rman__toropt___motionBlurType","subframe")
        settings[0].SetAttr("rman__toropt___shutterAngle",80)
        settings[0].SetAttr("rman__riopt__Camera_shutteropening0",0.35)
        settings[0].SetAttr("rman__riopt__Camera_shutteropening1",0.65)

    if setFinalPassParam:
        finalPassDefaultsDisplay = rfm.passes.GetPassDefaults("Final").GetPrimaryDisplay()
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_type","openexr")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_dither","0")    
        finalPassDefaultsDisplay.AddAttr("rman__riopt__Display_exrcompression")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_exrcompression","zip")
        finalPassDefaultsDisplay.AddAttr("rman__riopt__Display_exrpixeltype")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_exrpixeltype","half")
        finalPassDefaultsDisplay.AddAttr("rman__riopt__Display_autocrop")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_autocrop","true")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filter","gaussian")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filterwidth0",2)
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filterwidth1",2)
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_exposure1",1)


    if setCustomLightGroupsParam:
        rfm.passes.Update()
        Finals = rfm.passes.GetPasses("Final")
        display=0
        for i in Finals[0].GetDisplayList():
            if i.GetLabel() == "LightGroups":
                display=i
        if not i.IsEnabled():
            i.Enable()
        if display != 0:
            display.SetAttr("rman__riopt__Display_type","openexr")  
            display.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
            display.SetAttr("rman__riopt__Display_dither","0")    
            display.AddAttr("rman__riopt__Display_exrcompression")
            display.SetAttr("rman__riopt__Display_exrcompression","zip")
            display.AddAttr("rman__riopt__Display_exrpixeltype")
            display.SetAttr("rman__riopt__Display_exrpixeltype","half")
            display.AddAttr("rman__riopt__Display_autocrop")
            display.SetAttr("rman__riopt__Display_autocrop","true")
            display.AddAttr("rman__riopt__Display_filter")
            display.SetAttr("rman__riopt__Display_filter","gaussian")
            display.AddAttr("rman__riopt__Display_filterwidth")
            display.SetAttr("rman__riopt__Display_filterwidth0",2)
            display.SetAttr("rman__riopt__Display_filterwidth1",2)

    if setCustomDisplayParam:
        finalPassCustomDisplay=""
        for i in rfm.passes.GetPassDefaults("Final").GetDisplayList():
            if i.GetLabel() == "custom":
                rfm.passes.GetPassDefaults("Final").DeleteDisplay(i)

        finalPassCustomDisplay = rfm.passes.GetPassDefaults("Final").AddDisplay(["point wP","normal wN","float Z","color Diffuse","color DiffuseShadow","color Specular","color SpecularShadow","color DiffuseIndirect","color SpecularIndirect","color Incandescence","color Subsurface","color Refraction","float Occlusion","color Kd","float a"])
        finalPassCustomDisplay.SetDspyID("custom")

        finalPassCustomDisplay.SetAttr("rman__riopt__Display_type","openexr")  
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_dither","0")    
        finalPassCustomDisplay.AddAttr("rman__riopt__Display_exrcompression")
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_exrcompression","zip")
        finalPassCustomDisplay.AddAttr("rman__riopt__Display_exrpixeltype")
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_exrpixeltype","half")
        finalPassCustomDisplay.AddAttr("rman__riopt__Display_autocrop")
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_autocrop","true")
        finalPassCustomDisplay.AddAttr("rman__riopt__Display_filter")
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_filter","gaussian")
        finalPassCustomDisplay.AddAttr("rman__riopt__Display_filterwidth")
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_filterwidth0",2)
        finalPassCustomDisplay.SetAttr("rman__riopt__Display_filterwidth1",2)



    if setShadowSSParam:
        deepShadowPassDefaults = rfm.passes.GetPassDefaults("DeepShadow")
        deepShadowPassDefaults.SetAttr("rman__riopt___PixelSamples0",8)
        deepShadowPassDefaults.SetAttr("rman__riopt___PixelSamples1",8)
        deepShadowPassDefaults.SetAttr("rman__riattr___ShadingRate",30)

        areaShadowPassDefaults = rfm.passes.GetPassDefaults("AreaShadow")
        areaShadowPassDefaults.SetAttr("rman__riopt___PixelSamples0",8)
        areaShadowPassDefaults.SetAttr("rman__riopt___PixelSamples1",8)
        areaShadowPassDefaults.SetAttr("rman__riattr___ShadingRate",30)

        SSRenderPassDefaults = rfm.passes.GetPassDefaults("SSRender")
        SSRenderPassDefaults.AddAttr("rman__torattr___passNameFormat")
        SSRenderPassDefaults.SetAttr("rman__torattr___passNameFormat","${BASE}_${LAYER}_${PASSID}.${FRAME}.${EXT}")

        SSDiffusePassDefaults = rfm.passes.GetPassDefaults("SSDiffuse")
        SSDiffusePassDefaults.SetAttr("rman__param__ptfilter_ior", 1.44)
        SSDiffusePassDefaults.SetAttr("rman__param__ptfilter_unitlength", 0.1)
        SSDiffusePassDefaults.AddAttr("rman__torattr___passNameFormat")
        SSDiffusePassDefaults.SetAttr("rman__torattr___passNameFormat","${BASE}_${LAYER}_${PASSID}.${FRAME}.${EXT}")


    if setupShaveParam:    
        #cmds.loadPlugin("shaveNode")
        #mel.eval("shaveGlobalsEditor")
        if cmds.pluginInfo("shaveNode",query=True,l=True):
            if cmds.ls(type="shaveHair") != []:    
                if not cmds.objExists("shaveGlobals"):
                    mel.eval("shaveGlobalsEditor")
                cmds.setAttr("shaveGlobals.tileMemoryLimit", 1000)
                cmds.setAttr("shaveGlobals.ribOpacities", 1)
                cmds.setAttr("shaveGlobals.ribKeepRibFiles", 1)
                cmds.setAttr("shaveGlobals.ribBinary", 1)
                cmds.setAttr("shaveGlobals.ribCompress", 1)
                #setAttr -type "string" renderManGlobals.rman__torattr___renderBeginScript "rmanTimeStampScript;"; // shave_rmanRenderStart 
                #cmds.setAttr("renderManGlobals.rman__torattr___postTransformScript", "fur_insert();", type="string")
                settings[0].SetAttr("rman__torattr___postTransformScript", "fur_insert();")
                cmds.setAttr("defaultRenderGlobals.preRenderMel", "fur_gen(1);", type="string")
            
                cmds.setAttr("shaveGlobals.ribBlurTimeBasis", 1)
                cmds.setAttr("shaveGlobals.ribBlurRestoreFrame", 1)
                cmds.setAttr("shaveGlobals.ribBlurInheritSettings", 0)
                cmds.setAttr("shaveGlobals.ribBlurShutterOpenOffset", 0)
                cmds.setAttr("shaveGlobals.ribBlurShutterCloseOffset", settings[0].GetAttr("rman__toropt___shutterAngle")/360.0)

                if not mel.eval("attributeExists(\"centr\", \"perspShape\")"):
                    cmds.addAttr("perspShape",at="bool",ln="centr")
                globalsSettings=rfm.passes.GetGlobals()
                if globalsSettings.GetAttr("rman__toropt___shutterTiming") == "frameCenter":
                    cmds.setAttr("perspShape.centr",1)            
                else:
                    cmds.setAttr("perspShape.centr",0)                       

                if settings[0].GetAttr("rman__torattr___motionBlur"):
                    cmds.setAttr("shaveGlobals.ribBlurEnable", 1)
                else:
                    cmds.setAttr("shaveGlobals.ribBlurEnable", 0)
            
                for i in cmds.ls(type="shaveHair"):
                    cmds.setAttr(i + ".disableDynamics", 0)
                    #cmds.setAttr(i + ".enableCollision", 0)
        else:
            cmds.setAttr("renderManGlobals.rman__torattr___postTransformScript", "", type="string")
            cmds.setAttr("defaultRenderGlobals.preRenderMel", "", type="string")


    if creataLightGroupParam:
        if not cmds.objExists("LightSetup"):
            cmds.group(name="LightSetup", em=True)
        if not cmds.objExists("key_grp"):
            cmds.group(name="key_grp", em=True, parent="LightSetup")
        if not cmds.objExists("env_grp"):
            cmds.group(name="env_grp", em=True, parent="LightSetup")
        if not cmds.objExists("rim_grp"):
            cmds.group(name="rim_grp", em=True, parent="LightSetup")
        if not cmds.objExists("bounce_grp"):
            cmds.group(name="bounce_grp", em=True, parent="LightSetup")
        if not cmds.objExists("fx_grp"):
            cmds.group(name="fx_grp", em=True, parent="LightSetup")                






    global debugPy

    try:
        debugPy
    except NameError:
        debugPy=0
    else:
        pass


    OSTYPERS = sys.platform
    if OSTYPERS == "win32":
            OSTYPERS="//renderServer/Project/"
    else:
            OSTYPERS="/renderServer/Project/"

    OSTYPE3D = sys.platform
    if OSTYPE3D == "win32":
            OSTYPE3D="//Server-3d/Project/"
    else:
            OSTYPE3D="/Server-3d/Project/"

    expressionUrfin = re.compile("^UrfinJuse", re.IGNORECASE)
    expressionServer3d = re.compile("^/{1,2}Server-3d/Project/", re.IGNORECASE)
    expressionServerRender = re.compile("^/{1,2}renderServer/Project/", re.IGNORECASE)
    expressionDirectoryPath = re.compile("^(/Server-3d/Project/)|(/mnt/server-3d/)|(P:/)|(/home/.*/Project/)|(D:/Work/Project/)|(//Server-3d/Project/)", re.IGNORECASE)


    def checkFilesOnServer(files,namespaces=[]):
        paths = []
        for i in range(0,len(files)):
            fullName=""
            if expressionUrfin.match(files[i]):
                fullName=OSTYPE3D+files[i]
            elif expressionServer3d.match(files[i]):
                fullName = expressionDirectoryPath.sub(OSTYPE3D,files[i])
            elif expressionServerRender.match(files[i]):
                continue
            else:
                if len(namespaces): print("ERROR COPY FILE("+namespaces[i]+"): " + files[i])
                else: print("ERROR COPY FILE: " + files[i])
                continue

            if fullName!="":
                pathd=re.sub("MAPID_","*",fullName)
                pathd=re.sub("<udim>","*",pathd)
                if fullName != pathd:
                    temp2=["/".join(pathd.split("/")[:-1])]
                    filesss = glob.glob(temp2[0]+'/'+pathd.split("/")[-1])        
                    for f in filesss:
                        if f not in paths:
                            paths.append(f)
                        
                elif os.path.exists(fullName):
                    if fullName not in paths:
                        paths.append(fullName)
        
                else:     
                    if len(namespaces): print("ERROR COPY FILE("+namespaces[i]+"): " + files[i])
                    else: print("ERROR COPY FILE: " + files[i])
        
        return paths



    if chekTexureDataParam:
        print "\n\n"
        if not rfm.slim.GetSlim().Running():
            rfm.slim.GetSlim().Start()
            myslim = rfm.slim.GetSlim()
            
            kakzhedolgo=100000000
            vottak=0
            while vottak < kakzhedolgo:
                vottak+=1
                gde=myslim.Cmd("slim GetSlimStatus")
                if gde != "":
                    kakzhedolgo=vottak-1

        myslim = rfm.slim.GetSlim()
        ddd=myslim.Cmd("listAllTexturePath")


        expressionSlim = re.compile("\} \{", re.IGNORECASE)
        ddd=expressionSlim.sub(",",ddd)
        ddd="["+ddd[1:-1]+"]"
        #listTexurePaths = eval(ddd)
        listTexurePathsTemp = eval(ddd)

        listTexurePaths=[]
        listNamspacePaths=[]
        for i in listTexurePathsTemp:
            listTexurePaths.append(i[0])
            listNamspacePaths.append(i[1])

        paths = checkFilesOnServer(listTexurePaths,listNamspacePaths)
        #paths = checkFilesOnServer(listTexurePaths)
        ollLen=len(paths)
        print "\n\n"
        for i in range(0,ollLen):         
            dirName="/".join(paths[i].split("/")[:-1])
            dirNameServer=expressionDirectoryPath.sub(OSTYPERS,dirName)
            fullNameServer=expressionDirectoryPath.sub(OSTYPERS,paths[i])
            
            if not os.path.exists(dirNameServer):
                os.makedirs(dirNameServer)
          
            if debugPy: print "chek texture: "+paths[i]+" to " +fullNameServer
            if os.path.exists(fullNameServer) and int(os.path.getmtime(paths[i])) == int(os.path.getmtime(fullNameServer)):
                continue

            print str(int(100.0/ollLen*(i+1)))+"%    copy texture "+paths[i]
            if os.path.exists(fullNameServer):
                try:
                    os.remove(fullNameServer)    
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + fullNameServer)
            try:
                shutil.copy2(paths[i],fullNameServer)
            except:
                print("ERROR EXEPTION COPY FILES: " + paths[i] + " to " + fullNameServer)     
             

    if chekArchiveDataParam:
        print "\n\n"
        paths = []
        ribs = cmds.ls( type='RenderManArchive' )
        for i in ribs:
            paths.append(cmds.getAttr(i+'.filename'))

        paths=checkFilesOnServer(paths)
        print "\n\n"
        ollLen=len(paths)
        for i in range(0, ollLen):
            shaderDir = paths[i].split('.')[0]
            root = expressionDirectoryPath.sub(OSTYPERS,shaderDir)
            root = '/'.join(( root ).split( '/' )[:-1] ) + '/'
            newRibFile = root + (paths[i].split('/')[-1])
            newShaderDir = root + (shaderDir).split('/')[-1]
            if debugPy: print "chek archive: "+paths[i]+" to " +newRibFile
                
            if not os.path.exists(root):
                os.makedirs(root)
            if os.path.exists(newRibFile) and int(os.path.getmtime(paths[i])) == int(os.path.getmtime(newRibFile)):
                continue
            
            print str(int(100.0/ollLen*(i+1)))+"%    copy archives "+paths[i]+"   "+newRibFile
            if os.path.exists(newRibFile):
                try:
                    os.remove(newRibFile)
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + newRibFile)
            try:
                shutil.copy2(paths[i],newRibFile)
            except:
                print("ERROR EXEPTION COPY FILES: " + paths[i] + " to " + newRibFile)                    

            if os.path.exists(shaderDir):
                if os.path.exists(newShaderDir):
                    srcFiles = os.listdir(shaderDir)
                    dstFiles = os.listdir(newShaderDir)
                    srcDate = 0
                    dstDate = 0
                    for n in range(0,len(srcFiles)):
                        srcDate+=int((os.stat(shaderDir+'/'+srcFiles[n])).st_mtime)
                    for n in range(0,len(dstFiles)):
                        dstDate+=int((os.stat(newShaderDir+'/'+dstFiles[n])).st_mtime)
                    if srcDate>dstDate or len(srcFiles)>len(dstFiles):
                        try:
                            shutil.rmtree(newShaderDir)
                        except:
                            print("ERROR EXEPTION REMOVE TREE: " + newShaderDir)
                    else:
                        continue
                
                if debugPy: print str(int(100.0/ollLen*(i+1)))+"%    copy archives "+shaderDir
                try:
                    shutil.copytree(shaderDir,newShaderDir)
                except:
                    print("ERROR EXEPTION COPY FILES: " + shaderDir + " to " + newShaderDir)        


    if repareLightListParam:
        allLights=cmds.ls(type=["RMSGeoAreaLight","RMSAreaLight","RMSEnvLight","RMSGILight","RMSGIPtcLight","RMSPointLight","directionalLight","pointLight","spotLight","areaLight"])
        for aL in allLights:
            if cmds.listConnections(aL+".ltd",d=True,s=False) is None:
                cmds.connectAttr(aL+".ltd",":lightList1.l",na=True)               

    if slimMasksParam:
        myslim = rfm.slim.GetSlim()
        ddd=myslim.Cmd("getChannelSLbox")
        ddd=eval("["+ddd[1:]+"]")
        ddd=list(set(ddd))

        for i in range(0,len(ddd)):
            ddd[i]="color "+ddd[i]

        if ddd != []:
            finalPassMasksCustomDisplay=""
            for i in rfm.passes.GetPassDefaults("Final").GetDisplayList():
                if i.GetLabel() == "masks":
                    rfm.passes.GetPassDefaults("Final").DeleteDisplay(i)

            ddd.append("float a")
            print(str(ddd))
            finalPassMasksCustomDisplay = rfm.passes.GetPassDefaults("Final").AddDisplay(ddd)
            finalPassMasksCustomDisplay.SetDspyID("masks")
            #finalPassMasksCustomDisplay.AddChannels(ddd)
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_type","openexr")  
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_dither","0")    
            finalPassMasksCustomDisplay.AddAttr("rman__riopt__Display_exrcompression")
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_exrcompression","zip")
            finalPassMasksCustomDisplay.AddAttr("rman__riopt__Display_exrpixeltype")
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_exrpixeltype","half")
            finalPassMasksCustomDisplay.AddAttr("rman__riopt__Display_autocrop")
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_autocrop","true")
            finalPassMasksCustomDisplay.AddAttr("rman__riopt__Display_filter")
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_filter","gaussian")
            finalPassMasksCustomDisplay.AddAttr("rman__riopt__Display_filterwidth")
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_filterwidth0",2)
            finalPassMasksCustomDisplay.SetAttr("rman__riopt__Display_filterwidth1",2)


    rfm.passes.Update()
    PassManager=rfm.passes.GetPassManager()
    if PassManager is not None:
        PassManager.Update()                

    if hideImagePlaneParam:
        imagePlaneAll=cmds.ls(type="imagePlane")
        for iP in imagePlaneAll:
            #cmds.delete(iP)
            cmds.setAttr(iP+".visibility",0)

    
    if autoCreateStereoPassesParam:
        ### add right pass for castom pass (add AOPass, add LeftCamera as result over pass with RightCam)
        passes=rfm.passes.GetPasses("Final")
        for pas in range(0,len(passes)):
            print passes[pas].GetLabel()
            print passes[pas].GetCamera()
            rez=re.search("Left|Right",passes[pas].GetLabel())
            rez2=""
            if not rez:
                passes[pas].Rename(passes[pas].GetLabel()+"Left")


        passToCreate=[]
        passToDublicate=[]
        camToPassCreate=[]
        passes=rfm.passes.GetPasses("Final")
        for pas in range(0,len(passes)):
            rez=re.search("Left|Right",passes[pas].GetLabel())
            if rez:
                rez2=""
                rez=rez.group(0)
                if rez=="Right":
                    rez2="Left"
                else:
                    rez2="Right"
                    
                aEstlyTakoy=re.sub(rez,rez2,passes[pas].GetLabel())
                print aEstlyTakoy+"1 "+rez+"2 "+rez2
                net=1
                for pas2 in range(0,len(passes)):
                    if aEstlyTakoy==passes[pas2].GetLabel():
                        net=0
                        break
                if net:                
                    passToDublicate.append(passes[pas])
                    passToCreate.append(aEstlyTakoy)
                    camToPassCreate.append(re.sub(rez,rez2,passes[pas].GetCamera()))


        rfm.passes.Update()
        for ptc in range(0,len(passToCreate)):
            newPass=rfm.passes.GetPassManager().DuplicatePass(passToDublicate[ptc])
            newPass.Rename(passToCreate[ptc])
            temp=cmds.listConnections(passToCreate[ptc]+".rman__torattr___camera",source=True,plugs=True)
            if temp:
                cmds.disconnectAttr(temp[0],passToCreate[ptc]+".rman__torattr___camera")
            cmds.connectAttr(camToPassCreate[ptc] + ".message", passToCreate[ptc]+".rman__torattr___camera")
        

    if motionFactorParam:
        '''
        def findContainedReferences(fileww):
            filesFoundSoFar=[]
            filesFoundSoFar.append(fileww)
            nestedReferencesFromFile =  cmds.file(fileww,q=True,r=True)
                
            if len(nestedReferencesFromFile):
                for eachFile in  nestedReferencesFromFile:
                    EachFileReferences = findContainedReferences(eachFile)
                    filesFoundSoFar = EachFileReferences + filesFoundSoFar

            return  filesFoundSoFar

        allReferences=[]
        topLevelReferences=cmds.file(q=True,r=True)
        for eachReference in topLevelReferences:
            nestedReferencesForEachFile=findContainedReferences(eachReference)
            allReferences = allReferences + nestedReferencesForEachFile
            
        allReferencescharReferences=[]
        for aR in allReferences:
            if re.search("assets/chars",aR):
                allReferencescharReferences.append(aR)

        listShapes=[]
        for aRR in allReferencescharReferences:
            listShapes = listShapes + cmds.ls(cmds.referenceQuery(aRR,n=True,dp=True),s=True,ni=True)

        for lS in listShapes:
            if not mel.eval("attributeExists(\"rman__riattr___MotionFactor\", \""+lS+"\")"):
                mel.eval("rmanAddAttr "+lS+" rman__riattr___MotionFactor 0")
        '''
    print "end renderSetup.py"

    if fixReferenceDeformer:
        import ml_rmanAttributesToDeformer;ml_rmanAttributesToDeformer.ml_rmanAttributesToDeformer()
