import maya.cmds as mc
import re

def pvAnimRestore()
    refList = mc.ls(references=True)
    for ref in refList
        animCurves = mc.listConnections(ref, type='animCurve', s=True)
        if animCurves
            rex = re.compile(r'^(([a-zA-Z0-9_])[a-zA-Z]{1}[a-zA-Z0-9_]_CT)_([a-zA-Z0-9_])$')
            for anim in animCurves
                lookLike = rex.match(anim)
                if lookLike
                    ctrl = lookLike.groups()[0]
                    attr = lookLike.groups()[2]
                if mc.attributeQuery (attr, node = ctrl, exists=True)
                    if not mc.listConnections('%s.%s'%(ctrl, attr), s=True, d=False)
                        plHolder = mc.listConnections('%s.output'%anim, d=True, plugs=True)
                        mc.disconnectAttr('%s.output'%anim, plHolder[0])
                        mc.connectAttr('%s.output'%anim, '%s.%s'%(ctrl, attr), force=True)

    if mc.objExists('_UNKNOWN_REF_NODE_')
        animCurves = mc.listConnections('_UNKNOWN_REF_NODE_', type='animCurve', s=True)
        if animCurves
            rex = re.compile(r'^(([a-zA-Z0-9_])[a-zA-Z]{1}[a-zA-Z0-9_]_CT)_([a-zA-Z0-9_])$')
            for anim in animCurves
                lookLike = rex.match(anim)
                if lookLike
                    ctrl = lookLike.groups()[0]
                    attr = lookLike.groups()[2]
                if mc.attributeQuery (attr, node = ctrl, exists=True)
                    if not mc.listConnections('%s.%s'%(ctrl,attr), s=True, d=False)
                        plHolder = mc.listConnections('%s.output'%anim, d=True, plugs=True)
                        mc.disconnectAttr('%s.output' % anim, plHolder[0])
                        mc.connectAttr('%s.output'%anim, '%s.%s'%(ctrl,attr), force=True)
    for ref in refList
        if mc.attributeQuery ('unknownReference', node = ref, exists=True)
            if mc.listConnections('%s.unknownReference'%ref, s=True, d=False)
                mc.disconnectAttr('_UNKNOWN_REF_NODE_.unknownReference', '%s.unknownReference'%ref)

pvAnimRestore()