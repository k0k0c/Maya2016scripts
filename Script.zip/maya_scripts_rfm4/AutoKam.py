import sys
executable = sys.executable
OSTYPE = sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project"
if "2013" in executable:
    sys.path.append( OSTYPE + "/lib/soft/Python2013/Lib/site-packages" )
elif "2014" in executable:
    sys.path.append( OSTYPE + "/lib/soft/Python2014/Lib/site-packages" )
sys.path.append( OSTYPE + "/lib/setup/maya/maya_scripts_rfm4" )
sys.path.append( OSTYPE + "/lib/setup/maya/maya_scripts_rfm3" )
import os
import re
import glob
import subprocess
import shutil
import random
import json
import tractorJob
reload( tractorJob )
from PyQt4 import QtCore, QtGui
    

class Window( QtGui.QDialog ):
    
    def __init__( self, parent=None ):
        super( Window, self ).__init__( parent )
        self.pathToEpisodes = ""
        self.pathToOutput = ""
        self.pathToStereoOut = ""
        self.pathToPrecompose = ""
        self.ffmpegSettings1 = " -filter:v drawtext=fontsize=40:fontfile=//server-3d/Project/lib/python/font/arial.ttf:text=\""
        self.ffmpegSettings2 = "\":fontsize=30:boxcolor=black@0.0:box=1:fontcolor=white@0.5:x=25:y=815 "
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainSplitter = QtGui.QSplitter()
        self.mainlayout.addWidget( self.mainSplitter )
        self.mainlayout.setContentsMargins( 0, 0, 0, 0, )
        self.setLayout( self.mainlayout )
        self.OSTYPE = sys.platform == "win32" and "//server-3d" or "/server-3d"
        #Build interface.
        self.optionsWidget = QtGui.QGroupBox( "" )
        self.optionsLayout = QtGui.QVBoxLayout()
        self.optionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.optionsWidget.setLayout( self.optionsLayout )
        self.mainSplitter.addWidget( self.optionsWidget )
        #Project options.
        self.projectOptionsWidget = QtGui.QGroupBox( " Project: " )
        self.projectOptionsWidget.setMaximumHeight( 180 )
        self.projectOptionsLayout = QtGui.QHBoxLayout()
        self.projectOptionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.projectOptionsWidget.setLayout( self.projectOptionsLayout )
        self.optionsLayout.addWidget( self.projectOptionsWidget )
        self.projectPicture = QtGui.QLabel( "" )
        self.projectOptionsLayout.addWidget( self.projectPicture )
        self.projectOptionsActionsWidget = QtGui.QWidget()
        self.projectOptionsActionsLayout = QtGui.QVBoxLayout()
        self.projectOptionsActionsLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.projectOptionsActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.projectOptionsActionsWidget.setLayout( self.projectOptionsActionsLayout )
        self.projectOptionsLayout.addWidget( self.projectOptionsActionsWidget )
        self.projectsCombobox = QtGui.QComboBox()
        self.projectsComboboxList = QtCore.QStringList()
        self.projectsComboboxList.append( "UrfinJuse" )
        self.projectsComboboxList.append( "Krepost" )
        self.projectsComboboxList.append( "Sezar" )
        self.projectsCombobox.addItems( self.projectsComboboxList )
        self.projectsCombobox.currentIndexChanged.connect( self.switchProject )
        self.projectOptionsActionsLayout.addWidget( self.projectsCombobox )
        self.projectOptionsCreateSceneWidget = QtGui.QWidget()
        self.projectOptionsCreateSceneLayout = QtGui.QHBoxLayout()
        self.projectOptionsCreateSceneLayout.setContentsMargins( 0, 0, 0, 0, )
        self.projectOptionsCreateSceneWidget.setLayout( self.projectOptionsCreateSceneLayout )
        self.projectOptionsActionsLayout.addWidget( self.projectOptionsCreateSceneWidget )
        self.createSceneNameTextLine = QtGui.QLineEdit( "" )
        self.projectOptionsCreateSceneLayout.addWidget( self.createSceneNameTextLine )
        self.createSceneNameButton = QtGui.QPushButton( "Create scene directory" )
        self.createSceneNameButton.released.connect( self.createSceneDirectory )
        self.createSceneNameButton.setMinimumWidth( 30 )
        self.projectOptionsCreateSceneLayout.addWidget( self.createSceneNameButton )
        self.projectSettingsWidget = QtGui.QWidget()
        self.projectSettingsLayout = QtGui.QHBoxLayout()
        self.projectSettingsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.projectSettingsWidget.setLayout( self.projectSettingsLayout )
        self.optionsLayout.addWidget( self.projectSettingsWidget )
        #Episode options.
        self.episodeOptionsActionsWidget = QtGui.QGroupBox( " Episode: " )
        self.episodeOptionsActionsWidget.setMinimumWidth( 50 )
        self.episodeOptionsActionsLayout = QtGui.QVBoxLayout()
        self.episodeOptionsActionsLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.episodeOptionsActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.episodeOptionsActionsWidget.setLayout( self.episodeOptionsActionsLayout )
        self.projectSettingsLayout.addWidget( self.episodeOptionsActionsWidget )
        self.episodeCombobox = QtGui.QComboBox()
        self.episodeCombobox.currentIndexChanged.connect( self.updateScenes )
        self.episodeOptionsActionsLayout.addWidget( self.episodeCombobox )
        self.episodeActionsWidget = QtGui.QWidget()
        self.episodeActionsWidget.setMinimumWidth( 50 )
        self.episodeActionsWidget.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )     
        self.sceneViewLastFinalAviButton = QtGui.QPushButton( "View avi" )
        self.sceneViewLastFinalAviButton.released.connect( self.viewJoinedEpisodeAvi )
        #self.sceneViewLastFinalAviButton.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )     
        self.episodeOptionsActionsLayout.addWidget( self.sceneViewLastFinalAviButton )
        self.checkboxUseOutput = QtGui.QCheckBox( "output" )
        self.checkboxUseOutput.setCheckState( 2 )
        self.checkboxUseOutput.setTristate( False )
        self.checkboxUseOutput.stateChanged.connect( self.joinEpisodePresetCheckStateChanged )
        self.episodeOptionsActionsLayout.addWidget( self.checkboxUseOutput )
        self.checkboxUseDailies = QtGui.QCheckBox( "dailies" )
        self.checkboxUseDailies.setCheckState( 0 )
        self.checkboxUseDailies.setTristate( False )
        self.checkboxUseDailies.stateChanged.connect( self.joinEpisodePresetCheckStateChanged )
        self.episodeOptionsActionsLayout.addWidget( self.checkboxUseDailies )
        self.checkboxUsePrecompose = QtGui.QCheckBox( "precompose" )
        self.checkboxUsePrecompose.setTristate( False )
        self.checkboxUsePrecompose.setCheckState( 2 )
        self.checkboxUsePrecompose.stateChanged.connect( self.joinEpisodePresetCheckStateChanged )
        self.episodeOptionsActionsLayout.addWidget( self.checkboxUsePrecompose )
        self.checkboxUsePlayblast = QtGui.QCheckBox( "playblast" )
        self.checkboxUsePlayblast.setTristate( False )
        self.checkboxUsePlayblast.setCheckState( 2 )
        self.checkboxUsePlayblast.stateChanged.connect( self.joinEpisodePresetCheckStateChanged )
        self.episodeOptionsActionsLayout.addWidget( self.checkboxUsePlayblast )
        self.episodeJoinActionsWidget = QtGui.QWidget()
        self.episodeJoinActionsLayout = QtGui.QHBoxLayout()
        self.episodeJoinActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.episodeJoinActionsWidget.setLayout( self.episodeJoinActionsLayout )
        self.episodeOptionsActionsLayout.addWidget( self.episodeJoinActionsWidget )
        self.episodeCreateLastFinalButton = QtGui.QPushButton( "Create avi" )
        self.episodeCreateLastFinalButton.released.connect( self.joinEpisodeExecute )
        self.episodeJoinActionsLayout.addWidget( self.episodeCreateLastFinalButton )
        self.episodeJoinModeComboBox = myComboBox()
        self.episodeJoinModeComboBoxList = QtCore.QStringList()
        self.episodeJoinModeComboBoxList.append( "" )
        self.episodeJoinModeComboBoxList.append( "by latest date" )
        self.episodeJoinModeComboBox.addItems( self.episodeJoinModeComboBoxList ) 
        self.episodeJoinActionsLayout.addWidget( self.episodeJoinModeComboBox )
        #Scene options.
        self.sceneOptionsActionsWidget = QtGui.QGroupBox( " Scene: " )
        self.sceneOptionsActionsWidget.setMinimumWidth( 50 )
        self.sceneOptionsActionsLayout = QtGui.QVBoxLayout()
        self.sceneOptionsActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.sceneOptionsActionsWidget.setLayout( self.sceneOptionsActionsLayout )
        self.projectSettingsLayout.addWidget( self.sceneOptionsActionsWidget )
        self.model = QtGui.QStandardItemModel()
        self.mainSceneTree = QtGui.QTreeView()
        self.mainSceneTree.setModel( self.model )
        self.mainSceneTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.mainSceneTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.mainSceneTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.mainSceneTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.mainSceneTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainSceneTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.mainSceneTree.setHeaderHidden( True )
        self.mainSceneTree.selectionModel().selectionChanged.connect( self.updateScene )   
        self.sceneOptionsActionsLayout.addWidget( self.mainSceneTree )
        
        self.sceneDpxCreationWidget = QtGui.QWidget()
        self.sceneDpxCreationLayout = QtGui.QVBoxLayout()
        self.sceneDpxCreationLayout.setContentsMargins( 0, 0, 0, 0, )
        self.sceneDpxCreationWidget.setLayout( self.sceneDpxCreationLayout )
        self.sceneOptionsActionsLayout.addWidget( self.sceneDpxCreationWidget )
        self.buttonGroup = QtGui.QButtonGroup()
        self.buttonGroup.setExclusive( True )
        self.fromOutputButton = QtGui.QRadioButton( "from output" )
        self.fromStereoButton = QtGui.QRadioButton( "from stereo" )
        self.buttonGroup.addButton( self.fromOutputButton )
        self.buttonGroup.addButton( self.fromStereoButton )
        self.sceneDpxCreationLayout.addWidget( self.fromOutputButton )
        self.sceneDpxCreationLayout.addWidget( self.fromStereoButton )
        self.fromOutputButton.setChecked( True )
        self.createFinalWidget = QtGui.QWidget()
        self.createFinalWidgetLayout = QtGui.QHBoxLayout()
        self.createFinalWidgetLayout.setContentsMargins( 0, 0, 0, 0, )
        self.createFinalWidget.setLayout( self.createFinalWidgetLayout )
        self.sceneOptionsActionsLayout.addWidget( self.createFinalWidget )
        self.episodeCreateFinalButton = QtGui.QPushButton( "Create final" )
        self.episodeCreateFinalButton.released.connect( self.createFinalAvi )
        #self.episodeCreateFinalButton.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )   
        self.createFinalWidgetLayout.addWidget( self.episodeCreateFinalButton )
        self.viewAfterCreateAviCheckbox = QtGui.QCheckBox( "View" )
        self.viewAfterCreateAviCheckbox.setMaximumWidth( 55 )
        self.createFinalWidgetLayout.addWidget( self.viewAfterCreateAviCheckbox )
        self.viewAfterCreateAviCheckbox.setCheckState( QtCore.Qt.Checked )
        self.createAviOnTractorCheckbox = QtGui.QCheckBox( "tractor" )
        self.createAviOnTractorCheckbox.stateChanged.connect( self.setTractorSettings )
        self.createAviOnTractorCheckbox.setMaximumWidth( 65 )
        self.createFinalWidgetLayout.addWidget( self.createAviOnTractorCheckbox )
        self.createAviOnTractorCheckbox.setCheckState( QtCore.Qt.Unchecked )
        
        self.tractorSettingsGroupBox = QtGui.QGroupBox( "" )
        self.tractorSettingsLayout = QtGui.QGridLayout()
        self.tractorSettingsGroupBox.setLayout( self.tractorSettingsLayout )
        self.sceneOptionsActionsLayout.addWidget( self.tractorSettingsGroupBox )
        
        #self.evnKeyLabel = QtGui.QLabel( "Environment key" )
        #self.tractorSettingsLayout.addWidget( self.evnKeyLabel, 0, 0 )
        #self.evnKeyLine = QtGui.QLineEdit( "Maya2013" )
        #self.tractorSettingsLayout.addWidget( self.evnKeyLine, 0, 1 )
        
        self.evnServerAttributesLabel = QtGui.QLabel( "Job server attributes" )
        self.tractorSettingsLayout.addWidget( self.evnServerAttributesLabel, 0, 0 )
        self.evnServerAttributesLine = QtGui.QLineEdit( "WinFarm" )
        self.tractorSettingsLayout.addWidget( self.evnServerAttributesLine, 0, 1 )
        
        self.jobPriorityLabel = QtGui.QLabel( "job priority" )
        self.tractorSettingsLayout.addWidget( self.jobPriorityLabel, 1, 0 )
        self.jobPrioritySpinBox = QtGui.QSpinBox()
        self.jobPrioritySpinBox.setMaximum( 1000000 )
        self.jobPrioritySpinBox.setMinimum( 1 )
        self.jobPrioritySpinBox.setSingleStep( 1 )
        self.jobPrioritySpinBox.setValue( 1500 )
        self.tractorSettingsLayout.addWidget( self.jobPrioritySpinBox, 1, 1 )
        
        self.sceneViewFinalAviButton = QtGui.QPushButton( "View final" )
        self.sceneViewFinalAviButton.released.connect( self.viewFinalAvi )
        #self.sceneViewFinalAviButton.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )     
        self.sceneOptionsActionsLayout.addWidget( self.sceneViewFinalAviButton )
        self.infoMainWidget = QtGui.QGroupBox( "" )
        self.infoMainWidget.setMaximumHeight( 50 )
        self.infoMainLayout = QtGui.QVBoxLayout()
        self.infoMainLayout.setContentsMargins( 0, 0, 0, 0, )
        self.infoMainWidget.setLayout( self.infoMainLayout )
        self.mainlayout.addWidget( self.infoMainWidget )
        self.infoWidget2 = QtGui.QWidget()
        self.infoLayout2 = QtGui.QHBoxLayout()
        self.infoLayout2.setContentsMargins( 0, 0, 0, 0, )
        self.infoWidget2.setLayout( self.infoLayout2 )
        self.infoMainLayout.addWidget( self.infoWidget2 )
        self.dpxLabel = QtGui.QLabel( "Dpx path:" )
        self.infoLayout2.addWidget( self.dpxLabel )
        self.dpxTextLine = QtGui.QLineEdit( "" )
        self.infoLayout2.addWidget( self.dpxTextLine )
        self.sceneViewRenderDpxButton = QtGui.QPushButton( "View dpx" )
        self.sceneViewRenderDpxButton.setMaximumWidth( 55 )
        self.sceneViewRenderDpxButton.released.connect( self.runDpxSequence )     
        self.infoLayout2.addWidget( self.sceneViewRenderDpxButton )
        self.infoWidget = QtGui.QWidget()
        self.infoLayout = QtGui.QHBoxLayout()
        self.infoLayout.setContentsMargins( 0, 0, 0, 0, )
        self.infoWidget.setLayout( self.infoLayout )
        self.infoMainLayout.addWidget( self.infoWidget )
        self.imageLabel = QtGui.QLabel( "Info:" )
        self.infoLayout.addWidget( self.imageLabel )
        self.imageTextLine = QtGui.QLineEdit( "" )
        self.infoLayout.addWidget( self.imageTextLine )
        #Dailies options.
        self.dailiesMainSplitter = QtGui.QSplitter()
        self.dailiesMainSplitter.setOrientation( QtCore.Qt.Vertical )
        self.mainSplitter.addWidget( self.dailiesMainSplitter )
        self.dailiesMainUpSplitter = QtGui.QSplitter()
        self.dailiesMainSplitter.addWidget( self.dailiesMainUpSplitter )
        self.dailiesMainDownSplitter = QtGui.QSplitter()
        self.dailiesMainSplitter.addWidget( self.dailiesMainDownSplitter )
        #Dailies sequences list.
        self.dailiesOtherSplitter = QtGui.QSplitter()
        self.dailiesOtherSplitter.setOrientation( QtCore.Qt.Vertical )
        self.dailiesMainDownSplitter.addWidget( self.dailiesOtherSplitter )
        self.dailiesSequencesWidget = QtGui.QGroupBox( " Sequences: " )
        self.dailiesSequencesWidget.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )
        self.dailiesSequencesLayout = QtGui.QGridLayout()
        self.dailiesSequencesLayout.setContentsMargins( 0, 0, 0, 0, )
        self.dailiesSequencesWidget.setLayout( self.dailiesSequencesLayout )
        self.dailiesOtherSplitter.addWidget( self.dailiesSequencesWidget )
        self.dailiesSequencesActionsWidget = QtGui.QWidget()
        self.dailiesSequencesActionsLayout = QtGui.QHBoxLayout()
        self.dailiesSequencesActionsLayout.setAlignment( QtCore.Qt.AlignTop )
        self.dailiesSequencesActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.dailiesSequencesActionsWidget.setLayout( self.dailiesSequencesActionsLayout )
        self.dailiesSequencesLayout.addWidget( self.dailiesSequencesActionsWidget, 0, 0 )
        self.dailiesSequencesListCombobox = QtGui.QComboBox()
        self.dailiesSequencesListCombobox.currentIndexChanged.connect( self.updateSequencePreview )
        self.dailiesSequencesActionsLayout.addWidget( self.dailiesSequencesListCombobox )
        self.dailiesSequencesReloadButton = QtGui.QPushButton( "Reload" )
        self.dailiesSequencesReloadButton.setMaximumWidth( 50 )
        self.dailiesSequencesReloadButton.released.connect( self.updateScene )
        self.dailiesSequencesActionsLayout.addWidget( self.dailiesSequencesReloadButton )
        self.episodeViewRenderImagesButton = QtGui.QPushButton( "View jpg" )
        self.episodeViewRenderImagesButton.setMaximumWidth( 55 )
        self.episodeViewRenderImagesButton.released.connect( self.runJpgSequence )   
        self.dailiesSequencesActionsLayout.addWidget( self.episodeViewRenderImagesButton )
        self.sequencePreviewImageLabel = QtGui.QLabel( "" )
        self.sequencePreviewImageLabel.setMinimumHeight( 0 )
        self.sequencePreviewImageLabel.setMinimumWidth( 0 )
        self.sequencePreviewImageLabel.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding )
        self.sequencePreviewImageLabel.setStyleSheet( "QLabel { background-color: rgb( 20, 20, 20 ) }" )
        self.sequencePreviewImageLabel.setAlignment( QtCore.Qt.AlignCenter )
        self.dailiesSequencesLayout.addWidget( self.sequencePreviewImageLabel, 1, 0 )
        #Nuke script list.
        self.nukeScriptsWidget = QtGui.QGroupBox( " Nuke scripts: " )
        self.nukeScriptsWidget.setSizePolicy( QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding ) 
        self.nukeScriptsWidget.setMaximumHeight( 120 )
        self.nukeScriptsLayout = QtGui.QHBoxLayout()
        self.nukeScriptsLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.nukeScriptsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.nukeScriptsWidget.setLayout( self.nukeScriptsLayout )
        self.dailiesOtherSplitter.addWidget( self.nukeScriptsWidget )
        self.dailiesNukeScriptsList = QtGui.QListWidget()
        self.dailiesNukeScriptsList.itemDoubleClicked.connect( self.startNuke )
        self.nukeScriptsLayout.addWidget( self.dailiesNukeScriptsList )
        self.nukeScriptsActionsWidget = QtGui.QWidget()
        self.nukeScriptsActionsLayout = QtGui.QVBoxLayout()
        self.nukeScriptsActionsLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.nukeScriptsActionsLayout.setContentsMargins( 0, 0, 0, 0, )
        self.nukeScriptsActionsWidget.setLayout( self.nukeScriptsActionsLayout )
        self.nukeScriptsLayout.addWidget( self.nukeScriptsActionsWidget )
        self.createNukeScript = QtGui.QPushButton( "Create nuke script" )
        self.createNukeScript.released.connect( self.createScript )
        self.nukeScriptsActionsLayout.addWidget( self.createNukeScript )
        self.lastNukeScriptButton = QtGui.QPushButton( "Last nuke script" )
        self.lastNukeScriptButton.released.connect( self.selectLastNukeScript )
        self.nukeScriptsActionsLayout.addWidget( self.lastNukeScriptButton )
        #Setup dialog window.
        self.mainIcon = QtGui.QIcon( os.path.join( self.OSTYPE, "/project/lib/python/icons/Dailies.png"))
        self.setWindowIcon( self.mainIcon )
        self.font = QtGui.QFont( "", 10 )
        self.setFont( self.font )
        self.setWindowFlags( QtCore.Qt.WindowMinimizeButtonHint )
        self.setWindowTitle('Dailies Manager')
        self.switchProject()
        self.joinEpisodePresetCheckStateChanged()
        self.setTractorSettings()
    
    def setTractorSettings( self ):
        state = self.createAviOnTractorCheckbox.checkState() > 0
        if state is True:
            self.viewAfterCreateAviCheckbox.setCheckState( QtCore.Qt.Unchecked )
            self.viewAfterCreateAviCheckbox.setEnabled( False )
            self.tractorSettingsGroupBox.setEnabled( True )
        else:
            self.viewAfterCreateAviCheckbox.setEnabled( True )
            self.tractorSettingsGroupBox.setEnabled( False )
    
    def joinEpisodePresetCheckStateChanged( self ):
        word = ""
        if self.checkboxUseDailies.checkState() > 0:
            word = "from dailies"
        elif self.checkboxUseOutput.checkState() > 0:
            word = "from output" 
        elif self.checkboxUsePrecompose.checkState() > 0:
            word = "from precompose"
        elif self.checkboxUsePlayblast.checkState() > 0:
            word = "from playblast"
        else:
            word = "from None"
        self.episodeJoinModeComboBox.setItemText( 0, word )
    
    def viewFinalAvi( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        output = 0
        if self.fromOutputButton.isChecked():
            output = True
        elif self.fromStereoButton.isChecked():
            output = False
        else:
            print "error, please choose output."
        if scenes:
            for scene in scenes:
                if output is True:
                    rightPath = self.pathToOutput + episode + "/" + scene + "_right.avi"
                    leftPath = self.pathToOutput + episode + "/" + scene + "_left.avi"
                else:
                    rightPath = self.pathToStereoOut + episode + "/" + scene + "_right.avi"
                    leftPath = self.pathToStereoOut + episode + "/" + scene + "_left.avi"
                paths = [ leftPath, rightPath ]
                for path in paths:
                    if os.path.isfile( path ):
                        path = os.path.normcase( path )
                        os.startfile( path )
                        self.imageTextLine.clear()
                        self.imageTextLine.insert( path )
                        break
                    else:
                        print "Warning: File is not exists %s" % path
            
    def viewJoinedEpisodeAvi( self ):
        episode = str( self.episodeCombobox.currentText())
        path = self.pathToEpisodes + episode + "/"
        pathCut = path + "montage/cut_episode_"
        pathCutSrc = pathCut + episode + ".avi"
        pathCutDst = os.path.expanduser("~") + "/cut_episode_" + episode + ".avi"
        if os.path.isfile( pathCutSrc ):
            boolean = False
            if os.path.isfile( pathCutDst ):
                if os.path.getmtime( pathCutSrc ) > os.path.getmtime( pathCutDst ):
                    boolean = True
            else:
                boolean = True
            if boolean is True:
                shutil.copy( pathCutSrc, pathCutDst )
            pathCutDst = os.path.normcase( pathCutDst )
            os.startfile( pathCutDst )
            self.imageTextLine.clear()
            self.imageTextLine.insert( pathCutDst )
        else:
            print "Warning: File is not exists %s" % pathCutSrc
    
    def joinEpisodeExecute( self ):
        mode = str( self.episodeJoinModeComboBox.currentText())
        mode = mode != "by latest date" and 1 or 0
        precomposeEnable = self.checkboxUsePrecompose.checkState() > 0 and True or False
        playblastEnable = self.checkboxUsePlayblast.checkState() > 0 and True or False
        outputEnable = self.checkboxUseOutput.checkState() > 0 and True or False
        dailiesEnable = self.checkboxUseDailies.checkState() > 0 and True or False
        self.joinEpisode( precomposeEnable=precomposeEnable, playblastEnable=playblastEnable, outputEnable=outputEnable, dailiesEnable=dailiesEnable, mode=mode )
    
    def ffmpegMediaInfo( self, src ):
        command = [ self.OSTYPE + "/project/lib/soft/ffmpeg/bin/ffmpeg", "-i", src ] 
        process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
        output = "\n".join( process.communicate() )
        return output
    
    def ffmpegDefaultSettings( self, src, dst, sc ):
        convert = False
        if os.path.isfile( dst ):
            if os.path.getmtime( src ) > os.path.getmtime( dst ):
                os.remove( dst )
                print "replace old file"
                convert = True
            else:
                checkFormat = self.ffmpegMediaInfo( dst )
                if not re.findall( "mjpeg", checkFormat, re.IGNORECASE ):
                    os.remove( dst )
                    print "replace not valid %s" % dst
                    convert = True
        else:
            print "new file"
            convert = True
        if convert is True:
            print "convert file %s to %s" % ( src, dst )
            if re.findall( "output", src, re.IGNORECASE ):
                aviType = " - output"
            elif re.findall( "dailies", src, re.IGNORECASE ):
                aviType = " - dailies"
            elif re.findall( "precompose", src, re.IGNORECASE ):
                aviType = " - precompose"
            elif re.findall( "playblast", src, re.IGNORECASE ):
                aviType = " - playblast"
            else:
                aviType = ""
            imageFilter = ""
            info = self.ffmpegMediaInfo( src )
            if re.findall( "xvid", info ):
                imageFilter = imageFilter + "scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709,lutyuv=y=clip(val+11),"
            if re.findall( "microsoft", info ):
                imageFilter = imageFilter + "scale=in_range=pc:out_range=tv:in_color_matrix=bt709:out_color_matrix=bt601,lutyuv=y=clip(val+11),"
            label = sc + aviType + "  -  Melnitsa Animation Studio"
            labelFilter = imageFilter + "drawtext=fontsize=40:fontfile=//server-3d/Project/lib/python/font/arial.ttf:text=" + label + ":fontsize=30:boxcolor=black@0.0:box=1:fontcolor=white@0.5:x=25:y=815"
            command = [ self.OSTYPE + "/project/lib/soft/ffmpeg/bin/ffmpeg", "-r", "24", "-color_range", "2", "-i", src, "-c:v", "libxvid", "-s", "2100x858", "-q:v", "1", "-r", "24", "-vcodec", "mjpeg", "-pix_fmt", "yuvj422p", "-filter_complex", labelFilter, dst ] 
            process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
            output = "\n".join( process.communicate() )
            print output
    
    def joinEpisode( self, precomposeEnable=True, playblastEnable=True, outputEnable=True, dailiesEnable=False, mode=1 ):
        print "precompose:", precomposeEnable
        print "playblasts:", playblastEnable
        print "outputs:", outputEnable
        episode = str( self.episodeCombobox.currentText())
        nameDst = "cut_episode"
        pathScenes = self.pathToEpisodes + episode + "/"
        pathDst = self.pathToEpisodes + episode + "/montage/"
        if not os.path.isdir( pathDst ):
            os.makedirs( pathDst )
        dailies = []
        pathToJs = pathDst + episode + ".js"
        scenes = os.listdir( pathScenes )
        scenes = [ scene for scene in scenes if scene.startswith( "ep" ) and os.path.isdir( os.path.join( pathScenes, scene )) ]
        selector = sceneSelector()
        selector.defaultStyle()
        selector.buildList( scenes, pathToJs )
        doneValue = selector.exec_()
        if doneValue == 2:
            if os.path.isfile( pathToJs ):
                container = open( pathToJs ).read()
                data = json.loads( container )
                for cdata in data:
                    scene = cdata.keys()
                    scene = scene[0]
                    value = cdata[scene]
                    if scene.startswith( "ep" ):
                        print "scene:", scene, "-", value
                        if scene in scenes and value != 0:
                            files = []
                            #Find last output.
                            if outputEnable is True:
                                if not files or mode == 0:
                                    outputPath = self.pathToOutput + episode + "/"
                                    if os.path.isdir( outputPath ):
                                        outputs = glob.glob( outputPath + scene + ".avi" )
                                        outputsLeft = glob.glob( outputPath + scene + "_left.avi" )
                                        if outputsLeft:
                                            outputs = outputs + outputsLeft
                                        if outputs:
                                            output = max( outputs, key=os.path.getmtime )
                                            files.append( output )
                            #Find last dailies.
                            if dailiesEnable is True:
                                if not files or mode == 0:
                                    dailiesPath = pathScenes + scene + self.pathToCompose + "dailies/"
                                    if os.path.isdir( dailiesPath ):
                                        outputs = glob.glob( dailiesPath + scene + ".avi" )
                                        outputsLeft = glob.glob( dailiesPath + scene + "_left.avi" )
                                        if outputsLeft:
                                            outputs = outputs + outputsLeft
                                        if outputs:
                                            output = max( outputs, key=os.path.getmtime )
                                            files.append( output )
                            #Find last light sequence.
                            if precomposeEnable is True:
                                if not files or mode == 0:
                                    sequencePath = self.pathToPrecompose + episode + "/render/"
                                    if os.path.isdir( sequencePath ):
                                        outputs = glob.glob( sequencePath + scene + ".avi" )
                                        if outputs:
                                            output = max( outputs, key=os.path.getmtime )
                                            files.append( output )
                                    sequencePathWork = self.pathToPrecompose + episode + "/render/work/"
                                    if os.path.isdir( sequencePathWork ):
                                        outputs = glob.glob( sequencePathWork + scene + "_v*.avi" )
                                        outputs2 = glob.glob( sequencePathWork + scene + ".avi" )
                                        if outputs2:
                                            outputs = outputs + outputs2
                                        if outputs:
                                            output = max( outputs, key=os.path.getmtime )
                                            files.append( output )
                            #Find last playblast.
                            if playblastEnable is True:
                                if not files or mode == 0:
                                    playblastPath = self.OSTYPE + "/project/UrfinJuse/Playblast/" + episode + "/"
                                    if os.path.isdir( playblastPath ):
                                        playblasts = glob.glob( playblastPath + scene + ".avi" )
                                        if playblasts: 
                                            playblast = max( playblasts, key=os.path.getmtime )
                                            files.append( playblast )
                            if files:
                                last = max( files, key=os.path.getmtime )
                                if re.findall( "playblast", last, re.IGNORECASE ):
                                    atype = "playblast"
                                elif re.findall( "precompose", last, re.IGNORECASE ):
                                    atype = "precompose"
                                else:
                                    atype = ""
                                convertedPath = pathDst + "cut_scene_" + atype + "_" + scene + ".avi"
                                self.ffmpegDefaultSettings( last, convertedPath, scene )
                                dailies.append( convertedPath )
                                print "%s -ok" % scene
                output = pathDst + nameDst + "_" + episode + ".avi"
                if os.path.isfile( output ):
                    os.remove( output )
                self.ffmpegConcat( dailies, output )
                self.imageTextLine.clear()
                self.imageTextLine.insert( "Episode has been created successfully!" )
                self.viewJoinedEpisodeAvi()

    def colorRange( self, src, dst ):
        command = [ "//server-3d/project/lib/soft/ffmpeg/bin/ffmpeg", "-r", "24", "-i", src, "-c:v", "libxvid", "-s", "2100x858", "-q:v", "1", "-r", "24", "-c:v", "mpeg4", "-vtag", "xvid", "-pix_fmt", "yuv420p", "-filter_complex", "scale=in_range=pc:out_range=tv:in_color_matrix=bt601:out_color_matrix=bt709", dst ]
        process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
        output = "\n".join( process.communicate() )
        print output
        return dst
    
    def updateDpxPath( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            path = self.OSTYPE + "/project/UrfinJuse/output/" + episode + "/render_dpx/" + scenes[-1] + "/" + scenes[-1] + "_left/" + scenes[-1] +  "_l_0001.dpx"
            dpx = self.OSTYPE + "/project/UrfinJuse/output/" + episode + "/render_dpx/" + scenes[-1] + "/" + scenes[-1] + "_left/" + scenes[-1] + "_l_%04d.dpx"
            boolean = os.path.isfile( path )
            if boolean is False:
                path = self.OSTYPE + "/project/lib/python/icons/noFile.png"
                dpx = "No file yet!"
            self.dpxTextLine.clear()
            self.dpxTextLine.insert( dpx )

    def createFinalAvi( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        output = 0
        viewAfterCreate = self.viewAfterCreateAviCheckbox.checkState() > 0
        onTractor = self.createAviOnTractorCheckbox.checkState() > 0
        tractorjobs = []
        if self.fromOutputButton.isChecked():
            output = True
        elif self.fromStereoButton.isChecked():
            output = False
        else:
            print "error, please choose output."
        if scenes:
            for scene in scenes:
                finalPath = ""
                if output is True:
                    sequenceDirectory = self.pathToOutput + episode + "/render_dpx/" + scene + "/" + scene + "_right/"
                else:
                    sequenceDirectory = self.pathToStereoOut + episode + "/" + scene + "/" + scene + "_right/"
                print sequenceDirectory
                if os.path.isdir( sequenceDirectory ):
                    finalSequence = sequenceDirectory + scene + "_r_0001.dpx"
                    if os.path.isfile( finalSequence ):
                        if output is True:
                            finalPath = self.pathToOutput + episode + "/" + scene + "_right.avi"
                        else:
                            finalPath = self.pathToStereoOut + episode + "/" + scene + "_right.avi"
                        if onTractor is False:
                            self.createAviFromDpx( scene, sequenceDirectory, "r", finalPath, view=viewAfterCreate )
                        else:
                            script = "python( \"import joinDpxSequence; reload( joinDpxSequence ); joinDpxSequence.createAviFromDpx(\\\\\\\"" + scene + "\\\\\\\", \\\\\\\"" + sequenceDirectory + "\\\\\\\", \\\\\\\"r\\\\\\\",\\\\\\\"" + finalPath + "\\\\\\\", view=False )\")"
                            print "send to tractor:", script
                            tractorjobs.append( script )    
                    else:
                        print "File is not exists:", finalSequence
                if output is True:
                    sequenceDirectory = self.pathToOutput + episode + "/render_dpx/" + scene + "/" + scene + "_left/"
                else:
                    sequenceDirectory = self.pathToStereoOut + episode + "/" + scene + "/" + scene + "_left/"
                print sequenceDirectory
                if os.path.isdir( sequenceDirectory ):
                    finalSequence = sequenceDirectory + scene + "_l_0001.dpx"
                    if os.path.isfile( finalSequence ):
                        if output is True:
                            finalPath = self.pathToOutput + episode + "/" + scene + "_left.avi"
                        else:
                            finalPath = self.pathToStereoOut + episode + "/" + scene + "_left.avi"
                        if onTractor is False:
                            self.createAviFromDpx( scene, sequenceDirectory, "l", finalPath, view=False )
                        else:
                            script = "python( \"import joinDpxSequence; reload( joinDpxSequence ); joinDpxSequence.createAviFromDpx(\\\\\\\"" + scene + "\\\\\\\", \\\\\\\"" + sequenceDirectory + "\\\\\\\", \\\\\\\"l\\\\\\\",\\\\\\\"" + finalPath + "\\\\\\\", view=False )\")"
                            print "send to tractor:", script
                            tractorjobs.append( script )
                    else:
                        print "File is not exists:", finalSequence
                self.imageTextLine.clear()
                self.imageTextLine.insert( finalPath )
        if onTractor is True:
            attributes = str( self.evnServerAttributesLine.text())
            priority = int( self.jobPrioritySpinBox.value())
            tractorJob.sendScriptToTractor( environmentKeyLE="maya2013", jobPriorityLE=priority, jobServerAttrubutesLE=attributes, jobScriptTasks=tractorjobs, startPausedCB=False )
                
    def createAviFromDpx( self, scene, directory, direction, output, view=False ):
        print "scene:", scene, direction
        print "directory:", directory
        print "output:", output
        print "view:", view
        if os.path.isdir( directory ):
            sequence = directory + scene + "_" + direction + "_0001.dpx"
            if os.path.isfile( sequence ):
                print "sequence:", sequence
                count = str( len( os.listdir( directory )))
                if os.path.isfile( output ):
                    try:
                        os.remove( output )
                    except:
                        print "File %s is locked" % output
                self.ffmpegJoinDpxSequence( sequence, output, count )
                path = os.path.normcase( output )
                print "done:", path
                if view is True:
                    if os.path.isfile( path ):
                        os.startfile( path )
                    else:
                        print "File %s is not finded" % path
            else:
                print "Failed to find dpx sequence:", sequence
    
    def runDpxSequence( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                raw = self.pathToOutput + episode + "/render_dpx/" + scene + "/" + scene + "_left/" + scene + "_l_%04d.dpx"
                inPath = raw.split( "%" )[0]
                prefix = raw.split( "." )[-1]
                command = inPath + "0001." + prefix
                if os.path.isfile( command ):
                    command = os.path.normcase( command )
                    os.startfile( command )
                else:
                    print "Warning: file is not exists %s" % command  
            
    def runJpgSequence( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                sequence = str( self.dailiesSequencesListCombobox.currentText())
                raw = self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "render/" + sequence + "_%04d.jpg"
                inPath = raw.split( "%" )[0]
                prefix = raw.split( "." )[-1]
                command = inPath + "0001." + prefix
                if os.path.isfile( command ):
                    command = os.path.normcase( command )
                    os.startfile( command )
                else:
                    print "Warning: file is not exists %s" % command
    
    def ffmpegCut( self, src, dst ):
        command = self.OSTYPE + "/project/lib/soft/ffmpeg/bin/ffmpeg -r 24 -i \"concat:" + src + "\" -s 2048x858 -q:v 1 -r 24 " + dst
        os.popen( command )
        
    def ffmpegConcat( self, files, dst ):
        path = os.path.expanduser("~") + "/dailiesConcatList.txt"
        print "scene list saved to %s" % path
        obj = file( path, "w" )
        for i in range( 0, len( files )):
            if i == 0:
                name = "file '" + "/".join( files[i].split( "\\" )) + "'"
            else:
                name = "\n" + "file '" + "/".join( files[i].split( "\\" )) + "'"
            obj.write( name )
        obj.close()
        command = [ self.OSTYPE + "/project/lib/soft/ffmpeg/bin/ffmpeg", "-f", "concat", "-i", path, "-s", "2100x858", "-c:v", "libxvid", "-vcodec", "mjpeg", "-pix_fmt", "yuvj422p", "-q:v", "1", "-r", "24", dst ]
        process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
        output = "\n".join( process.communicate() )
        print output
    
    def ffmpegJoinDpxSequence( self, src, dst, framesCount ):
        command = [ "c:/mel/cmds/Fusion/eyeonScript.exe", "c:/mel/cmds/Fusion/renderSequence.eyeonScript", src, dst, "0", framesCount, "1.0" ]
        print "start join dpx sequence"
        process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
        output = "\n".join( process.communicate() )
        print output
    
    def createSceneDirectory( self ):
        episode = str( self.episodeCombobox.currentText())
        folders = [ "nuke", "render", "layers", "dailies", "final", "render_tif", "sequences" ]
        base = self.pathToEpisodes + episode + "/"
        shot = self.createSceneNameTextLine.text()
        if shot and shot != "":
            shots = shot.split( " " )
            for i in range( 0, len( shots )):
                path = base + shots[i]
                if not os.path.isdir( path + "/" ):
                    os.makedirs( path )
                for folder in folders:
                    temp = path + "/" + folder + "/"
                    if not os.path.isdir( temp ):
                        os.makedirs( temp )
        self.createSceneNameTextLine.clear()   
    
    def createScript( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                path = self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "nuke/"
                if not os.path.isdir( path ):
                    os.makedirs( path )
                files = os.listdir( path )
                if files:
                    exists = []
                    for item in files:
                        if re.findall( scene + "_v[0-9]+.nk", item ):
                            exists.append( item )
                    version = str( len( exists ) + 1 )
                    script = path + scene + "_v" + ( "0" * ( 3 - len( version ))) + version + ".nk"
                else:
                    script = path + scene + "_v001.nk"
                open( script, "w" ).write( "Root {\n  inputs 0\n  format \"2048 858 0 0 2048 858 1 FormatUrfin\"\n }" )
                self.updateNukeScriptsList()
    
    def selectLastNukeScript( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                path = self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "nuke/"
                if os.path.isdir( path ):
                    scripts = glob.glob( path + '*.nk' )
                    if scripts:
                        path = max( scripts, key=os.path.getmtime )
                        path = os.path.normcase( path )
                        os.environ["PYTHONHOME"]="C:/Program Files/Nuke8.0v5"
                        os.startfile( path )
                        self.imageTextLine.clear()
                        self.imageTextLine.insert( path )
    
    def switchProject( self ):
        project = self.projectsCombobox.currentText()
        if project == "Krepost":
            self.pathToEpisodes = self.OSTYPE + "/project/Krepost/compose/"
            self.pathToOutput = self.OSTYPE + "/project/Krepost/output/"
            self.pathToStereoOut = self.OSTYPE + "/project/Krepost/stereo_out/"
            self.pathToPrecompose = self.OSTYPE + "/project/Krepost/precompose/"
            self.pathToCompose = "/"
            self.createSceneNameTextLine.setEnabled( True )
            self.createSceneNameButton.setEnabled( True )
        elif project == "UrfinJuse":
            self.pathToEpisodes = self.OSTYPE + "/project/UrfinJuse/scenes/"
            self.pathToOutput = self.OSTYPE + "/project/UrfinJuse/output/"
            self.pathToStereoOut = self.OSTYPE + "/project/UrfinJuse/stereo_out/"
            self.pathToPrecompose = self.OSTYPE + "/project/UrfinJuse/precompose/"
            self.pathToCompose = "/compose/"
            self.createSceneNameTextLine.setEnabled( False )
            self.createSceneNameButton.setEnabled( False )
        elif project == "Sezar":
            self.pathToEpisodes = self.OSTYPE + "/project/Sezar/scenes/"
            self.pathToOutput = self.OSTYPE + "/project/Sezar/output/"
            self.pathToStereoOut = self.OSTYPE + "/project/Sezar/stereo_out/"
            self.pathToPrecompose = self.OSTYPE + "/project/Sezar/precompose/"
            self.pathToCompose = "/compose/"
            self.createSceneNameTextLine.setEnabled( True )
            self.createSceneNameButton.setEnabled( True )
        self.updateEpisodes()
        self.updateScenes()
        #Update picture.
        image = QtGui.QPixmap( self.OSTYPE + "/project/lib/python/icons/" + project + '.jpg')
        imageScaled = image.scaled( 300, 150, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation )
        self.projectPicture.setPixmap( imageScaled )
        self.updateScene( updatePreview=False )
        
    def updateEpisodes( self ):
        self.episodeCombobox.clear()
        episodeComboboxList = QtCore.QStringList()
        folders = os.listdir( self.pathToEpisodes )     
        for folder in folders:
            if folder.startswith( "ep" ) is True:         
                episodeComboboxList.append( folder )
        self.episodeCombobox.addItems( episodeComboboxList )
        
    def updateScenes( self ):
        self.mainSceneTree.model().clear()
        root = self.mainSceneTree.model().invisibleRootItem()
        episode = str( self.episodeCombobox.currentText())
        folders = os.listdir( self.pathToEpisodes + episode + "/" )     
        for folder in folders:
            if folder.startswith( "ep" ) is True:
                item = QtGui.QStandardItem( folder )
                root.setChild( root.rowCount(), item )
                
    def getSelectedScenes( self ):
        result = []
        selectionModel = self.mainSceneTree.selectionModel()
        indexes = selectionModel.selectedIndexes()
        if indexes:
            for index in indexes:
                result.append( str(index.data( QtCore.Qt.DisplayRole ).toString()))
        return result
    
    def updateSequencePreview( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            sequence = str( self.dailiesSequencesListCombobox.currentText())
            self.sequencePreviewImageLabel.clear()
            path = self.pathToEpisodes + episode + "/" + scenes[-1] + self.pathToCompose + "render/" + sequence + "_0001.jpg"
            jpg = self.pathToEpisodes + episode + "/" + scenes[-1] + self.pathToCompose + "render/" + sequence + "_%04d.jpg"
            boolean = os.path.isfile( path )
            if boolean is False:
                path = self.OSTYPE + "/project/lib/python/icons/noFile.png"
                jpg = "No file yet!"
            image = QtGui.QPixmap( path )
            #imagesc = image.scaled( self.sequencePreviewImageLabel.size(), QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation )
            imagesc = image.scaled( 310, 130, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation )
            self.sequencePreviewImageLabel.setPixmap( imagesc )
            self.imageTextLine.clear()
            self.imageTextLine.insert( jpg )
            self.updateDpxPath()
    
    def refreshSequenceList( self ):
        episode = str( self.episodeCombobox.currentText())
        self.dailiesSequencesListCombobox.clear()
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                path = self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "render/"
                if os.path.isdir( path ):
                    folders = os.listdir( path )
                    sequence = 0
                    for folder in folders:
                        name = folder.split( "." )[0]
                        letters = name[:25]
                        final = '_'.join( letters.split( "_" )[:-1] )
                        if sequence <> final:
                            sequence = final
                            self.dailiesSequencesListCombobox.addItem( final )
        self.updateSequencePreview()
    
    def updateNukeScriptsList( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        self.dailiesNukeScriptsList.clear()
        if scenes:
            for scene in scenes:
                path = self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "nuke/"
                if os.path.isdir( path ):
                    nukes = os.listdir( path )
                    for nuke in nukes:
                        if nuke.endswith( ".nk" ) is True:
                            self.dailiesNukeScriptsList.addItem( nuke.split('\\')[-1] )
    
    def executeNuke( self, path ):
        if os.path.isfile( path ):
            os.environ["PYTHONHOME"]="C:/Program Files/Nuke8.0v5"
            os.startfile( path )        
    
    def startNuke( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            for scene in scenes:
                base =  self.pathToEpisodes + episode + "/" + scene + self.pathToCompose + "nuke/"
                item = self.dailiesNukeScriptsList.currentIndex()
                name = str( item.data().toString())
                path = base + name
                path = os.path.normcase( path )
                self.executeNuke( path )
                self.imageTextLine.clear()
                self.imageTextLine.insert( path )
    
    def updateImagePath( self ):
        episode = str( self.episodeCombobox.currentText())
        scenes = self.getSelectedScenes()
        if scenes:
            sequence = str( self.dailiesSequencesListCombobox.currentText())
            path = self.pathToEpisodes + episode + "/" + scenes[-1] + self.pathToCompose + "render/" + sequence + "_0001.jpg"
            jpg = self.pathToEpisodes + episode + "/" + scenes[-1] + self.pathToCompose + "render/" + sequence + "_%04d.jpg"
            boolean = os.path.isfile( path )
            if boolean is False:
                path = self.OSTYPE + "/project/lib/python/icons/noFile.png"
                jpg = "No file yet!"
            self.imageTextLine.clear()
            self.imageTextLine.insert( jpg )
    
    def updateScene( self, updatePreview=True ):
        self.refreshSequenceList()
        self.updateNukeScriptsList()
        self.updateImagePath()
        self.updateDpxPath()
        if updatePreview:
            self.updateProjectPicture()
    
    def updateProjectPicture( self ):
        project = self.projectsCombobox.currentText()
        if project == "UrfinJuse":
            pictures = os.listdir( self.OSTYPE + "/project/lib/python/icons/pic_for_emotions/" )
            lenght = len( pictures )
            current = pictures[ random.randint( 0, lenght-1 ) ]
            image = QtGui.QPixmap( self.OSTYPE + "/project/lib/python/icons/pic_for_emotions/" + current )
            imageScaled = image.scaled( 350, 200, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation )
            self.projectPicture.setPixmap( imageScaled )
            
    def fusion( self ):
        process = subprocess.Popen( "tasklist /FI \"IMAGENAME eq eyeonScript.exe\"", stdout=subprocess.PIPE )
        output = process.communicate()
        if not re.search( "eyeonScript.exe", str( output )):
            subprocess.Popen( "c:\mel\cmds\RenderSlave\RenderSlave.exe" )
            
    def defaultStyle( self ):
        palette = self.style().standardPalette()
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Window, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.AlternateBase, QtGui.QColor(74,74,74) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Text, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Button, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ButtonText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.WindowText, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Base, QtGui.QColor(42,42,42) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ToolTipBase, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ToolTipText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.BrightText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Light, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Midlight, QtGui.QColor(70,70,70))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Dark, QtGui.QColor(42,42,42))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Mid, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Shadow,QtGui. QColor(0,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Highlight, QtGui.QColor(255,180,0,51))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.HighlightedText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Link, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.LinkVisited, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.NoRole, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Window, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.AlternateBase, QtGui.QColor(74,74,74))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Text, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Button, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Base, QtGui.QColor(42,42,42) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Light, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Highlight, QtGui.QColor(255,180,0,51))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Button, QtGui.QColor(80,80,80))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, QtGui.QColor(10,10,10,10))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Light, QtGui.QColor(150,150,150))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Window, QtGui.QColor(30,30,30) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.AlternateBase, QtGui.QColor(255,0,0) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Text, QtGui.QColor(105,105,105) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, QtGui.QColor(105,105,105) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Base, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ToolTipBase, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ToolTipText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.BrightText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Light, QtGui.QColor(68,68,68))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Midlight, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Dark, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Mid, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Shadow, QtGui.QColor(0,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Highlight, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.HighlightedText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Link, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.LinkVisited, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.NoRole, QtGui.QColor(255,0,0))
        self.setPalette( palette )

class sceneSelector( QtGui.QDialog ):
    
    def __init__( self, parent=None ):
        super( sceneSelector, self ).__init__( parent )
        self.filename = ""
        self.isChanged = False
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 0, 0, 0, 0, )
        self.setLayout( self.mainLayout )
        self.tree = QtGui.QTreeView()
        self.model = QtGui.QStandardItemModel()
        self.delegate = itemDelegate()
        self.connect( self.delegate, QtCore.SIGNAL("itemCheckChange(const QModelIndex &)"), self.toogleState )
        self.tree.setItemDelegate( self.delegate )
        self.tree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.tree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.tree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.tree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.tree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.tree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.tree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.tree.setModel( self.model )
        self.tree.setHeaderHidden( True )
        self.tree.setDragDropMode( QtGui.QAbstractItemView.InternalMove )
        self.mainLayout.addWidget( self.tree )
        self.mainWidget = QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QHBoxLayout()
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainLayout.addWidget( self.mainWidget )
        self.applyButton = QtGui.QPushButton( "apply" )
        self.applyButton.released.connect( self.apply )
        self.mainWidgetLayout.addWidget( self.applyButton )
        self.cancelButton = QtGui.QPushButton( "Cancel" )
        self.cancelButton.released.connect( self.cancel )
        self.mainWidgetLayout.addWidget( self.cancelButton )
        self.setWindowTitle('Scene list')
       
    def setChanged( self ):
        self.isChanged = True
        
    def toogleState( self, index ):
        selections = self.tree.selectionModel().selectedIndexes()
        if selections:
            state = str( index.model().data( index, QtCore.Qt.CheckStateRole ).toString()) == "0" and "1" or "0"
            for selection in selections:
                item = self.model.itemFromIndex( selection )
                item.setData( state, QtCore.Qt.CheckStateRole )
        
    def buildList( self, scenes, filename ):
        self.filename = filename
        if self.filename == "":
            return 1
        else:
            boolean = False
            if not os.path.isfile( self.filename ):
                boolean = True
            else: 
                container = open( self.filename ).read()
                data = json.loads( container )
                if type( data ) is dict:
                    boolean = True 
            if boolean is True:
                container = file( self.filename, "w" )
                data = []
                for scene in scenes:
                    data.append( { scene:0 } )
                json.dump( data, container, indent=4, ensure_ascii=False )
                container.close()
        container = open( self.filename ).read()
        data = json.loads( container )
        root = self.model.invisibleRootItem()
        for cdata in data:
            name = cdata.keys()
            name = name[0]
            if name in scenes:
                scenes.pop( scenes.index( name ))
                value = cdata[name]
                item = QtGui.QStandardItem( name )
                #item.setDropEnabled( True )
                item.setDropEnabled( False )
                item.setData( name, QtCore.Qt.DisplayRole )
                item.setData( name, QtCore.Qt.DisplayRole + 1 )
                item.setData( value, QtCore.Qt.CheckStateRole )
                root.appendRow( item )
        for scene in scenes:
            item = QtGui.QStandardItem( scene )
            #item.setDropEnabled( True )
            item.setDropEnabled( False )
            item.setData( scene, QtCore.Qt.DisplayRole )
            item.setData( scene, QtCore.Qt.DisplayRole + 1 )
            item.setData( 0, QtCore.Qt.CheckStateRole )
            root.appendRow( item )
        self.model.itemChanged.connect( self.setChanged )
            
    def saveList( self, filename ):
        if filename != "":
            container = file( filename, "w" )
            data = []
            root = self.model.invisibleRootItem()
            count = root.rowCount()
            if count > 0:
                for i in range( 0, count ):
                    child = root.child( i )
                    state = int( child.data( QtCore.Qt.CheckStateRole ).toString())
                    name = str( child.data( QtCore.Qt.DisplayRole ).toString())
                    data.append( { name:state } )
            json.dump( data, container, indent=4, ensure_ascii=False )
            container.close()
            
    def apply( self ):
        if self.isChanged is True:
            confirm = confirmLoop()
            confirm.load( label="list changed", text="Do you want to save scene list?" )
            boolean = confirm.exec_()
            if boolean == 1:
                if self.filename != "":
                    self.saveList( self.filename )
                return self.done( 2 )
            elif boolean == 1:
                return self.done( 2 )
            return self.done( 1 )
        return self.done( 2 )
    
    def cancel( self ):
        if self.isChanged is True:
            confirm = confirmLoop()
            confirm.load( label="list changed", text="Do you want to save scene list?" )
            boolean = confirm.exec_()
            if boolean == 1:
                if self.filename != "":
                    self.saveList( self.filename )
                return self.done( 1 )
        return self.done( 1 )
    
    def defaultStyle( self ):
        palette = self.style().standardPalette()
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Window, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.AlternateBase, QtGui.QColor(74,74,74) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Text, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Button, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ButtonText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.WindowText, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Base, QtGui.QColor(42,42,42) )
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ToolTipBase, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.ToolTipText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.BrightText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Light, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Midlight, QtGui.QColor(70,70,70))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Dark, QtGui.QColor(42,42,42))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Mid, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Shadow,QtGui. QColor(0,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Highlight, QtGui.QColor(255,180,0,51))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.HighlightedText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.Link, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.LinkVisited, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Active, QtGui.QPalette.NoRole, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Window, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.AlternateBase, QtGui.QColor(74,74,74))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Text, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Button, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.ButtonText, QtGui.QColor(200,200,200))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.WindowText, QtGui.QColor(200,200,200) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Base, QtGui.QColor(42,42,42) )
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Light, QtGui.QColor(100,100,100))
        palette.setColor( QtGui.QPalette.Inactive, QtGui.QPalette.Highlight, QtGui.QColor(255,180,0,51))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Button, QtGui.QColor(80,80,80))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ButtonText, QtGui.QColor(10,10,10,10))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Light, QtGui.QColor(150,150,150))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Window, QtGui.QColor(30,30,30) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.AlternateBase, QtGui.QColor(255,0,0) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Text, QtGui.QColor(105,105,105) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.WindowText, QtGui.QColor(105,105,105) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Base, QtGui.QColor(68,68,68) )
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ToolTipBase, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.ToolTipText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.BrightText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Light, QtGui.QColor(68,68,68))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Midlight, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Dark, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Mid, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Shadow, QtGui.QColor(0,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Highlight, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.HighlightedText, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.Link, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.LinkVisited, QtGui.QColor(255,0,0))
        palette.setColor( QtGui.QPalette.Disabled, QtGui.QPalette.NoRole, QtGui.QColor(255,0,0))
        self.setPalette( palette )

class itemDelegate(QtGui.QItemDelegate):
    
    def createEditor( self, parent, option, index ):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)
        return editor

    def setEditorData( self, spinBox, index ):
        value = index.model().data(index, QtCore.Qt.EditRole)
        spinBox.setValue(value)

    def setModelData( self, spinBox, model, index ):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData( index, value, QtCore.Qt.EditRole )

    def updateEditorGeometry( self, editor, option, index ):
        editor.setGeometry(option.rect)

    def sizeHint( self, option, index ):
        return QtCore.QSize(100,20)

    def paint( self, painter, option, index ):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        col = QtGui.QColor(index.model().data(index,QtCore.Qt.BackgroundColorRole))
        if col.name() == "#000000":
            col = option.palette.window().color()
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, col)
        gradient.setColorAt(0.95, col)
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole + 1).toString()
        painter.drawText( option.rect.x()+25,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        rown = str( index.row())
        painter.drawText( option.rect.x()-15,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,rown)
        rect = QtCore.QRect( option.rect.x()+0.14*option.rect.height(), option.rect.y()+0.14*option.rect.height(), 0.65*option.rect.height(), 0.65*option.rect.height())
        checkState = index.model().data( index, QtCore.Qt.CheckStateRole ).toString()
        if checkState == "1":
            self.drawCheck( painter, option, rect, True )
        else:
            self.drawCheck( painter, option, rect, False )
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
    def editorEvent( self, event, model, option, index ):
        result = False
        if event.type() == QtCore.QEvent.MouseButtonRelease:
            mouse = QtGui.QMouseEvent( event )
            rect = QtCore.QRect( option.rect.x()+0.1*option.rect.height(), option.rect.y()-0.05*option.rect.height(), option.rect.height(), option.rect.height() )
            if rect.contains( mouse.x(), mouse.y()):
                result = True
                self.emit(QtCore.SIGNAL("itemCheckChange(const QModelIndex &)"), index )
        return result

class myComboBox(QtGui.QComboBox):
    def __init__(self, parent=None):
        super(myComboBox, self).__init__(parent)

    def wheelEvent(self,event):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QComboBox.wheelEvent(self,event)
            
    def showPopup(self):
        lv = self.view()
        fm = lv.fontMetrics()
        mlen = 0
        mwidth = 0
        for i in range( self.count()):
            it = self.itemText(i)
            tlen = len( it )
            if mlen < tlen:
                mlen = tlen
                mwidth = max( fm.width( it ), mwidth )
        self.view().setMinimumWidth( mwidth + 10 + ( self.count() > self.maxVisibleItems() and self.view().verticalScrollBar().sizeHint().width() or 0 ))
        QtGui.QComboBox.showPopup( self )

class confirmLoop( QtGui.QDialog ):
    def __init__(self, parent=None):
        super(confirmLoop, self).__init__(parent)
        
    def load( self, label="", text="" ):
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 2,2,2,2 )        
        self.setWindowTitle( label )
        self.label=QtGui.QLabel( text )
        self.HLayout = QtGui.QHBoxLayout()
        self.executeButton = QtGui.QPushButton( "Yes" )
        self.executeButton.released.connect( self.executeSlot )
        self.continueButton = QtGui.QPushButton( "No" )
        self.continueButton.released.connect( self.continueSlot )  
        self.breakButton = QtGui.QPushButton( "Cancel" )
        self.breakButton.released.connect( self.breakSlot )
        self.HLayout.addWidget( self.executeButton )
        self.HLayout.addWidget( self.continueButton )
        self.HLayout.addWidget( self.breakButton )
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout)
        
    def executeSlot( self ):
        self.done(1)
        
    def continueSlot( self ):
        self.done(2)

    def breakSlot( self ):
        self.done(3)

def main():
    app = QtGui.QApplication(sys.argv)
    app.setStyle( "plastique" )
    window = Window()
    window.defaultStyle()
    window.fusion()
    window.show()
    sys.exit(app.exec_())
    
#window = Window()
#window.defaultStyle()
#window.fusion()
#window.show()
main()