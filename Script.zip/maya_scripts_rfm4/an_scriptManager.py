import maya.mel as mm
import maya.cmds as cmds
import os
import sys

def an_scriptMamager():
    vPythonMenu = 'PyMenu'
    if cmds.menu (vPythonMenu, exists=True):  cmds.deleteUI (vPythonMenu)
    cmds.menu (vPythonMenu, l='Scripts', p='MayaWindow', tearOff=True)
    vDirPath = "//SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm3/for_rigging/"   	    
    
    an_checkContent (vDirPath, vPythonMenu)   
     
    cmds.menuItem (divider=True,  p=vPythonMenu, bld=True)
    cmds.menuItem (l="--refresh--", p=vPythonMenu )

####************************************

def an_checkContent (vDirPath, vMenuName):
    vContent = cmds.getFileList(folder=vDirPath )   
    for vEach in [obj for obj in vContent if not '.' in obj]: #prohodim po vsem papkam
        if not 'procedurs' in vEach:
            cmds.menuItem ( vEach+"Mn2", l=vEach, tearOff=True, sm=True, p=vMenuName)
            vEachContent = cmds.getFileList(folder=vDirPath+vEach+'/')
            if vEachContent: an_checkContent (vDirPath+vEach+'/', vEach+"Mn2")
    cmds.menuItem (divider=True,  p=vMenuName) 
           
    for vEach in [obj for obj in vContent if '.py' in obj]: #prohodim po vsem pyhon failam
        if not '.pyc' in vEach: cmds.menuItem ( vEach, l=vEach, p=vMenuName, c="an_pyComand('"+vEach+"', '"+vDirPath+"')") 
    
    for vEach in [obj for obj in vContent if '.mel' in obj]: #prohodim po vsem mel failam
        cmds.menuItem ( vEach, l=vEach, p=vMenuName , c= "an_melComand('"+vEach+"', '"+vDirPath+"')") 
        
####************************************

def an_pyComand(vscriptName, vDirPath):
    v_sPath = list(sys.path)  
    sys.path.append(vDirPath) 
    vscriptName = vscriptName.split('.')[0]
    v_namespace = {}
    execfile (vDirPath+vscriptName+'.py', v_namespace)
    globals().update(v_namespace)

####************************************

def an_melComand(vscriptName, vDirPath):
    vscriptName = vscriptName.split('.mel')[0]
    mm.eval( "source \""+vDirPath+vscriptName+".mel\"") 
    mm.eval(vscriptName) 
    
####************************************  
an_scriptMamager() 