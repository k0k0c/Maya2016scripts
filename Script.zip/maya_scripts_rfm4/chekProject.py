def chekProject():
    pass
    #import re
    #import maya.mel
    '''
    estRenderman = maya.mel.eval("exists rman")
    currentWorkSpace = maya.mel.eval("workspace -q -fn")
    curWorkSpace = maya.mel.eval("file -q -loc -sn")
    if estRenderman:
        rezzz="//server-3d/Project/default"
        if curWorkSpace == "":
            curWorkSpace="untitled"
        if curWorkSpace != "unknown":
            m=re.search('(.*)(?=/maya)', curWorkSpace)
            if m == None:
                m=re.search('(.*/assets/.*/)', curWorkSpace)
                if m != None and m.group(0) != "":    
                    rezzz=m.group(0)
            else:
                rezzz=m.group(0)

            #m=re.search('^//server-3d/Project/\w+', curWorkSpace)
            #if m is not None:
        if rezzz is not "":
            if currentWorkSpace != rezzz:
                print("PROJECT IZMENEN: "+rezzz)
                maya.mel.eval("setProject \""+rezzz+"/\";")
                maya.mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+rezzz+"/ -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
                maya.mel.eval("rman slim message \"workspace SetProject "+rezzz+"\"")
            else:
                print("CURRENT PROJECT: "+rezzz)
        else:
            m=re.search('^D:/Work/Project/\w+', curWorkSpace)
            if m is not None:
                if currentWorkSpace != rezzz:
                    print("PROJECT IZMENEN: "+rezzz)
                    maya.mel.eval("setProject \""+rezzz+"/\";")
                    maya.mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+rezzz+"/ -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
                    maya.mel.eval("rman slim message \"workspace SetProject "+rezzz+"\"")
                else:
                    print("CURRENT PROJECT: "+rezzz)
            else:
                print "ERROR PROJECT NE NAIDEN!!!"
    else:
        print("PROJECT NE IZMENEN: " + currentWorkSpace)
    '''
    #maya.mel.eval("setProject \"//server-3d/Project/\";")
'''        
def chekProject3():
    import maya.mel
    import os
    import re
    re.IGNORECASE

    #rezInput = 'rms-4.0-maya-2013,prman-17.0,PR-UrfinJuse-User-YAGO_TEST1-sr-NULL-ep-NULL-sc-NULL'
    #rezInputList=rezInput.split(",")
    #rezInput=""
    #for r in rezInputList:
    #    m=re.search('PR-.*-User-.*-sr-.*-ep-.*-sc-', r,re.I)
    #    if m is not None:
    #        pass
    #    else:
    #        rezInput+=r+","
    #rezInput=rezInput[0:-1]
    #print rezInput

    currentWorkSpace = maya.mel.eval("workspace -q -fn")
    currentFileX = maya.mel.eval("file -q -sn")

    srX = ""
    epX = ""
    scX = ""    
    m=re.search('(?<=/)sr(?P<sr>\d*)ep(?P<ep>\d*)sc(?P<sc>\w*)(?=\.)', currentFileX, re.I)
    if m is not None:
        srX = "sr"+m.group("sr")+"/"
        epX = "ep"+m.group("ep")+"/"
        scX = "sc"+m.group("sc")+"/"
    else:
        m=re.search('(?<=/)ep(?P<ep>\d*)sc(?P<sc>\w*)(?=\.)', currentFileX, re.I)    
        if m is not None:
            epX = "ep"+m.group("ep")+"/"
            scX = "sc"+m.group("sc")+"/"


    projectX = ""
    if currentFileX != "":
        m=re.search('^//server-3d/Project/(\w+)', currentFileX,re.I)
        if m is not None:
                projectX = m.group(1)+"/"
        else:
            m=re.search('^D:/Work/Project/(\w+)', currentFileX,re.I)
            if m is not None:
                projectX = m.group(1)+"/"
    else:
        currentFileX=""
        m=re.search('^//server-3d/Project/(\w+)', currentWorkSpace,re.I)
        if m is not None:
                projectX = m.group(1)+"/"
        else:
            m=re.search('^D:/Work/Project/(\w+)', currentWorkSpace,re.I)
            if m is not None:
                projectX = m.group(1)+"/"
    if projectX=="":
        projectX="default/"
    userNameX = ""
    if scX == "":
        userNameX = "USERS/"+os.getenv("COMPUTERNAME")+"/"
    #rezOutput = rezInput+",PR-"+projectX+"-User-"+userNameX+"-sr-"+srX+"-ep-"+epX+"-sc-"+scX
    #print rezOutput
    #maya.mel.eval("global string $gRManPreviewAlfredEnvKey=\"\";")
    #maya.mel.eval("$gRManPreviewAlfredEnvKey = \""+rezOutput+"\";")
    #maya.mel.eval("optionVar -stringValue \"rmanPreviewAlfredEnvKey\" \""+rezOutput+"\";")
    #setMenu = maya.mel.eval("exists rmanPreviewAlfredEnvKey")
    #if setMenu != 0:
    #    maya.mel.eval("textFieldGrp -e -tx \""+rezOutput+"\" rmanPreviewAlfredEnvKey; $gRManPreviewAlfredEnvKey = (`textFieldGrp -q -tx rmanPreviewAlfredEnvKey`);rmanUpdatePreviewOptionsWidgets(\"rmanProRenderOptionsWnd\");")        
    maya.mel.eval("rman setvar PROJECTX \""+projectX+"\";")
    maya.mel.eval("rman setvar USERX \""+userNameX+"\";")
    maya.mel.eval("rman setvar SERIAX \""+srX+"\";")
    maya.mel.eval("rman setvar EPIZODX \""+epX+"\";")
    maya.mel.eval("rman setvar SCENEX \""+scX+"\";") 
    print("ZNACHENIYA PEREMENNYH: "+projectX+" "+userNameX+" "+srX+" "+epX+" "+scX)
    
    
    
    
def chekProjectOld():
    import re
    import maya.mel
    re.IGNORECASE
    currentWorkSpace = maya.mel.eval("workspace -q -fn")
    curWorkSpace = maya.mel.eval("file -q -sn")
    if curWorkSpace != "":
        m=re.search('^//server-3d/Project/\w+', curWorkSpace)
        if m is not None:
            if currentWorkSpace != m.group(0):
                print("PROJECT IZMENEN: "+m.group(0))
                maya.mel.eval("setProject \""+m.group(0)+"\";")
                maya.mel.eval("rman setvar RMSPROD \"//server-3d/Project\";")
                maya.mel.eval("rman setvar RMSPROJ \""+m.group(0)+"\";")
            else:
                print("CURRENT PROJECT: "+m.group(0))
        else:
            m=re.search('^D:/Work/Project/\w+', curWorkSpace)
            if m is not None:
                if currentWorkSpace != m.group(0):
                    print("PROJECT IZMENEN: "+m.group(0))
                    maya.mel.eval("setProject \""+m.group(0)+"\";")
                    maya.mel.eval("rman setvar RMSPROD \"D:/Work/Project\";")
                    maya.mel.eval("rman setvar RMSPROJ \""+m.group(0)+"\";")
                else:
                    print("CURRENT PROJECT: "+m.group(0))
            else:
                print "ERROR PROJECT NE NAIDEN!!!"
    else:
        print("PROJECT NE IZMENEN: " + currentWorkSpace)
'''

def chekProjectProject():
    pass
    '''
    import re
    import maya.mel
    estRenderman = maya.mel.eval("exists rman")
    currentWorkSpace = maya.mel.eval("workspace -q -fn")
    curWorkSpace = maya.mel.eval("file -q -loc -sn")
    rezzz="//server-3d/Project"
    if currentWorkSpace != rezzz:
        print("PROJECT IZMENEN: "+rezzz)
        maya.mel.eval("setProject \""+rezzz+"/\";")
        if estRenderman:
            maya.mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+rezzz+"/ -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
            maya.mel.eval("rman slim message \"workspace SetProject "+rezzz+"\"")
    '''
    
    
def setMayaProject(rezz):
    import re
    import os
    import maya.mel
    import shutil
    import sys

    #rezzz = rezz
    #'''
    #import renderSetup
    #reload(renderSetup)
     
    RENDERSERVER = sys.platform
    if RENDERSERVER == "win32":
            RENDERSERVER="//renderServer/Project"
    else:
            RENDERSERVER="/renderServer/Project"
    ''' 
    RENDERSERVER = sys.platform
    if RENDERSERVER == "win32":
            RENDERSERVER="//Server-3d/Project"
    else:
            RENDERSERVER="/Server-3d/Project"
    '''	
    fff=re.compile('^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)', re.IGNORECASE)
    rezzz = fff.sub(RENDERSERVER,rezz)
    


    SERVER3D = "//Server-3d/Project"
    if sys.platform != "win32":
            SERVER3D = "/Server-3d/Project"
    #estRenderman = maya.mel.eval("exists rman")
    #if estRenderman:
    if os.path.exists(RENDERSERVER):
        if not os.path.exists(rezzz):
            os.makedirs(rezzz)
        if not os.path.exists(rezzz+"/workspace.mel"):
            shutil.copyfile(SERVER3D+"/lib/setup/maya/maya_scripts_rfm4/workspace_source.mel", rezzz+"/workspace.mel")
        print("SET MAYA PROJECT: "+rezzz+"\n")
        maya.mel.eval("setProject \""+rezzz+"/\";")
    
    
    
    
def setLinuxDataServer():
    import sys
    import re
    import maya.cmds as cmds
    import maya.mel as mel

    KUDATYPE = sys.platform
    if KUDATYPE == "win32":
        KUDATYPE="//renderServer/renderData/Project"
    else:
        KUDATYPE="/renderData/Project"
    '''
    import os
    usr=os.environ['USER']
    if usr == 'Yago':
        if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
            sss=mel.eval("rman getvar RMSPROJ")
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            projectX = expression.sub("",sss)
            dataribsimages = expression.sub(KUDATYPE,sss)
            mel.eval("rman setvar PROJECTX \"" + projectX + "\"")
            #mel.eval("rman setvar rfmImages \"" + dataribsimages + "renderman/$STAGE/images\"")
            #mel.eval("rman setvar rfmData \"" + dataribsimages + "renderman/$STAGE/data\"")
            #mel.eval("rman setvar rfmSwap \"" + dataribsimages + "renderman/$STAGE/swap\"")
            #mel.eval("rman setvar rfmRIBs \"" + dataribsimages + "renderman/$STAGE/rib\"")            
            #mel.eval("rman setvar IMAGEPATH \"" + dataribsimages + "renderman/$STAGE/images\"")
            #mel.eval("rman setvar DATAPATH \"" + dataribsimages + "renderman/$STAGE/data\"")
            #mel.eval("rman setvar RIBPATH \"" + dataribsimages + "renderman/$STAGE/rib\"")            
            mel.eval("rman workspace SetDir rfmImages \"" + dataribsimages + "renderman/$STAGE/images\"")
            mel.eval("rman workspace SetDir rfmData \"" + dataribsimages + "renderman/$STAGE/data\"")
            mel.eval("rman workspace SetDir rfmSwap \"" + dataribsimages + "renderman/$STAGE/swap\"")
            mel.eval("rman workspace SetDir rfmRIBs \"" + dataribsimages + "renderman/$STAGE/rib\"")                
    '''

