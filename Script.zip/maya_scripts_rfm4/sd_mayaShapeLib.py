# -*- coding: utf-8 -*-
import maya.cmds as cmds
'''
    example:    import sd_mayaShapeLib as mLib
            source re import (http://stackoverflow.com/questions/437589/how-do-i-unload-reload-a-python-module)
                if 'mLib' in sys.modules:  
                    del(sys.modules["mLib"]) 
                import sd_mayaShapeLib as mLib
                
                
                mLib.getTransform('pasted__pSphereShape1');
'''

def getTransform ( shape ):
    ''' function return Transfor node from select shape 
        example: print getTransform('pSphereShape1') 
        http://ewertb.soundlinker.com/mel/mel.008.php
    '''
    transform = ''
    shapeList = cmds.ls(typ='mesh')
    if 'transform' != cmds.objectType( shapeList[0] ) :
        #print 'Input shape '+shapeList[0];
        transformList = cmds.listRelatives(shapeList, parent=True, fullPath=True)
        transform =  transformList[0]
    return transform
        
def getShape ( xformX ):
    ''' function return Shape node from select transform  
        example: getShape('pSphere1') 
        result: [u'|group2|group1|pSphere1|pSphereShape1']
        http://ewertb.soundlinker.com/mel/mel.008.php
    '''
    shapes = []
    #shapes[0] = xformX
    if 'transform' == cmds.objectType( xformX ) :
        shapes = cmds.listRelatives(xformX, fullPath=True)
    return shapes 

def deleteUnknownNodes():
    ''' 2 things to take care of:
    #   1) you can't delete nodes from references.
    #   2) "delete" will delete all children nodes (hierarchy) in default.
    http://drakeguan.org/blog/2008/12/Delete-unknown-nodes-in-Maya/
    example: 
    import sd_mayaShapeLib as mLib
    reload(mLib)
    mLib.printUnknownNodes() #output list of unknown nodes 
    mLib.deleteUnknownNodes() #delete all unknown nodes 
    '''
    unknown = cmds.ls(type="unknown")
    #unknown = filter(lambda node: not node.isReferenced(), unknown)
    for node in unknown:
        if not cmds.objExists(node):
            continue
        print node
        cmds.delete(node)
        
def printUnknownNodes():
    '''
    # 2 things to take care of:
    #   1) you can't delete nodes from references.
    http://drakeguan.org/blog/2008/12/Delete-unknown-nodes-in-Maya/
    example: 
    import sd_mayaShapeLib as mLib
    reload(mLib)
    mLib.printUnknownNodes() #output list of unknown nodes 
    mLib.deleteUnknownNodes() #delete all unknown nodes 
    '''
    unknown = cmds.ls(type="unknown")
    #unknown = filter(lambda node: not node.isReferenced(), unknown)
    print unknown
    return unknown

def selectNode( node ):
    '''
    select input node
    example:
    import sd_mayaShapeLib as mLib
    reload(mLib)
    mLib.selectNode('mtorPartition')
    '''
    #if str(node)
    cmds.select( str(node) )
    return

def getFullPathNode():
    '''
    import sd_mayaShapeLib as mLib
    reload(mLib)
    mLib.getFullPathNode()
    '''
    import maya.cmds as cmds
    select = cmds.ls(selection=True, type='dagNode')
    print select
    return
    
def deleteNode( node ):
    '''
    select input node
    example:
        import sd_mayaShapeLib as mLib
        reload(mLib)
        mLib.deleteNode('mtorPartition')
    '''
    cmds.delete(str(node))
    print 'delete node: '+str(node)
    return     
    
def setProject(path):
    '''
    example:
    
    import sd_mayaShapeLib as mLib
    reload(mLib)
    mLib.setProject('setProject \"//server-3d/project/UrfinJuse/\"');
    '''
    print path
    import maya.mel as mel 
    mel.eval(path);
    return

def killSlim():
    '''
     correct string in cmd:
     taskkill -f -im "slim.exe"
    '''
    import os
    os.system("taskkill /f /im slim.exe")