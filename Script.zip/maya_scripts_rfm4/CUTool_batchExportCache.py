import sys
import os
import maya.cmds as cmds
import maya.mel as mel
cmds.loadPlugin('AbcExport')
cmds.loadPlugin('RenderMan_for_Maya')
cmds.loadPlugin('mtoa')
cmds.warning('alembic cache batch export started.\n')

#Run from this procedure
def alembicCacheExportInitialize():
    #Get arguments for export alembic cache
    cmds.warning('\nstart open scene.\n')
    pathToScene, mode, selection = openTargetFile()
    arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
    cmds.warning('\nscene succesful opened.\n')
    cmds.warning('\nscene location:'+ cmds.file(query=True, sceneName=True) +'\n')
    #Get target reference nodes with animation
    refNode = getReferenceNodeList(selection)
    cmds.warning('\nstart creating list of target nodes for export.\n')
    #Get target content from reference nodes
    nodesToExport = []
    for i in range(0, len(refNode)):
        content = getCharsContentForExport(mode, refNode[i])
        if content is not None:
            nodesToExport += content
    cmds.warning('\nlist of target nodes created.\n')        
    #Create path to alembic cache folder 
    path = ''
    if 'customPath' in arguments[-1]:
        path = arguments[-1].split('customPath')[-1]    
    else:
        path = generatePathForAlembicCacheFolder(pathToScene)
    cmds.warning('\npath for export cache: '+path+'\n')    
    #Export alembic cache
    print '\n\n\n', refNode
    print '\n\n\n', nodesToExport  
    cmds.warning('\nstart export alembic cache.\n')  
    exportAlembicCache(nodesToExport, path)
    cmds.warning('\nalembic cache succesful exported.\n')  


#Open scene with arguments and return arguments for export cache
def openTargetFile():
    #Get arguments
    arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
    pathToScene = arguments[0]; print pathToScene
    mode = arguments[1]
    selection = arguments[2]
    #Open scene
    cmds.file(pathToScene, force=True, open=True)
    #Return arguments
    return pathToScene, mode, selection


#Get list of animated referenced objects for export
def getReferenceNodeList(mode):
    '''
    mode = 'chars', 'all'
    -chars' = take only animated referenced chars
    -'all' = take all animated referenced objects
    '''
    #Get list of all animated reference nodes
    animCurves = (cmds.ls(type=("animCurveTU", "animCurveTA", "animCurveTL")))
    animCurves = [animCurves[i] for i in range(0, len(animCurves)) if cmds.referenceQuery(animCurves[i], isNodeReferenced=True) is False]
    animatedRef = []
    for i in range(0, len(animCurves)):
        objectControl = cmds.listConnections(animCurves[i], shapes=True, type='transform')
        if objectControl:
            if cmds.referenceQuery(objectControl, isNodeReferenced=True):
                referenceName = cmds.referenceQuery(objectControl, referenceNode=True)
                if referenceName not in animatedRef:
                    animatedRef.append(referenceName)
    #Create list of target reference nodes            
    if animatedRef != []:
        if mode == 'chars':
            animatedRef = [animatedRef[i] for i in range(0, len(animatedRef)) if 'chars' in cmds.referenceQuery(animatedRef[i], filename=True)]
        elif mode == 'all':
            animatedRef = [animatedRef[i] for i in range(0, len(animatedRef)) if 'chars' in cmds.referenceQuery(animatedRef[i], filename=True) or 'props' in cmds.referenceQuery(animatedRef[i], filename=True)];print animatedRef
        if animatedRef != []:
            return animatedRef


#Get content from target set for each character if set is exists or geometry_grp or None
def getCharsContentForExport(mode, refNode):
    '''
    mode = 'geometry_grp', 'dynCache', 'renderCache'
    -'geometry_grp' = search geometry_grp in reference node
    -'geo_normal' = search geo_normal in reference node
    -'dynCache' = search dynCache set in reference node
    -'renderCache' = search renderCache set in reference node
    refNode = target reference node
    '''
    allSets = cmds.ls(cmds.referenceQuery(refNode, nodes=True, dagPath=True), type='objectSet')
    #Find geometry_grp if set not exists
    geoGrp = cmds.ls(cmds.referenceQuery(refNode, nodes=True, dagPath=True), type='transform')
    geoGrp = [geoGrp[i] for i in range(0, len(geoGrp)) if geoGrp[i].split('geometry_grp')[-1]=='']
    #Find geo_normal if set or geometry_grp not exists
    geoNormal = cmds.ls(cmds.referenceQuery(refNode, nodes=True, dagPath=True), type='transform')
    geoNormal = [geoNormal[i] for i in range(0, len(geoNormal)) if geoNormal[i].split('geo_normal')[-1]=='']; print geoNormal
    #Find target set and set content or return geometry_grp for target reference
    if mode != 'geometry_grp' and mode != 'geo_normal':
        if allSets != []:     
            usedSets = [allSets[i] for i in range(0, len(allSets)) if mode in allSets[i]]
            if usedSets != []:
                objectsForExport = cmds.sets(usedSets, query=True, nodesOnly=True) 
                if objectsForExport != []:
                    return objectsForExport
                else:
                    if geoGrp != []:
                        return geoGrp
                    elif geoNormal != []:
                        return geoNormal                    
                    else:
                        return None
            else:
                if geoGrp != []:
                    return geoGrp
                elif geoNormal != []:
                    return geoNormal                
                else:
                    return None
        else:
            if geoGrp != []:
                return geoGrp
            elif geoNormal != []:
                return geoNormal             
            else:
                return None
    elif mode == 'geometry_grp':
        if geoGrp != []:
            return geoGrp
        elif geoNormal != []:
            return geoNormal     
        else:
            return None
    elif mode == 'geo_normal':
        if geoNormal != []:
            return geoNormal
        else:
            return None        
    else:
        return None
        

#Generate path to alembic cache scene if path is not defined
def generatePathForAlembicCacheFolder(pathToScene): 
    pathToCacheFolder = str('/'.join(pathToScene.split('/')[0:-2])) + '/cache/alembic/'
    if not os.path.isdir(pathToCacheFolder):
        os.makedirs(pathToCacheFolder) 
    return pathToCacheFolder    


#Export alembic cache
def exportAlembicCache(nodesToExport, pathToCacheFolder):
    exportAlembicCacheString = 'AbcExport'
    startTime = []
    endTime = []
    for i in range(0, len(nodesToExport)):
        print '\nexport alembic cache... .'
        startTime.append(cmds.playbackOptions(query=True, animationStartTime=True))
        endTime.append(cmds.playbackOptions(query=True, animationEndTime=True))        
        frameRange = [startTime, endTime]
        strTEMP = (nodesToExport[i].replace(":","_x_"))
        strTEMP = strTEMP.replace("|","_z_")
        exportAlembicCacheString += " -j \"-root " + nodesToExport[i] + " -fr "+str(frameRange[0][i])+" "+str(frameRange[1][i])+" -noNormals -renderableOnly -file "+pathToCacheFolder+"/"+strTEMP[:-4]+".abc\""
    mel.eval(exportAlembicCacheString)
    print 'done.'


#Start
alembicCacheExportInitialize()





