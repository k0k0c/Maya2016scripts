import rfm.rlf2maya as rlf2maya
import rfm.passes
from PyQt4 import QtCore, QtGui
from ml_getMayaWindow import *

class m_window( QtGui.QDialog ):
    
    def __init__( self, parent=ml_getMayaWindow()):
        super( m_window, self ).__init__( parent )
        self.m_layout = QtGui.QVBoxLayout()
        self.m_layout.setSpacing(0)
        self.m_layout.setContentsMargins(3,3,3,3)
        self.m_tabWidget = QtGui.QTabWidget()
        self.m_tabWidget.setStyleSheet("QTabWidget{background: rgb(68,68,68);}")
        self.m_RM = m_referenceManager()
        self.m_tabWidget.addTab( self.m_RM, "References manager" )
        self.m_RO = m_referenceOptions()
        self.m_tabWidget.addTab( self.m_RO, "References sets" )
        self.m_layout.addWidget( self.m_tabWidget )
        self.setLayout( self.m_layout )
        
class m_referenceOptions( QtGui.QWidget ):
    
    def __init__( self, parent=ml_getMayaWindow()):
        super( m_referenceOptions, self ).__init__( parent )
        #Layouts.
        self.m_layout = QtGui.QHBoxLayout()
        self.m_listView_group = QtGui.QGroupBox( "" )
        self.m_refenceManager_group = QtGui.QGroupBox( "" )
        self.m_refenceManagerMode_group = QtGui.QGroupBox( "" )
        self.m_refenceManagerMode_group.setMaximumHeight( 75 )
        self.m_refenceManagerButtons_group = QtGui.QGroupBox( "Set options: " )
        self.m_refenceManagerButtons_group.setMaximumHeight( 225 )
        self.m_listView_layout = QtGui.QHBoxLayout()
        self.m_refenceManagerGroup_layout = QtGui.QVBoxLayout()
        self.m_refenceManagerGroup_layout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.m_refenceManagerMode_layout = QtGui.QHBoxLayout()
        self.m_refenceManagerListButtons_layout = QtGui.QVBoxLayout()
        #List.
        self.m_listView = QtGui.QListView()
        self.m_listView_layout.addWidget( self.m_listView )
        #splitter.
        self.m_splitter = QtGui.QSplitter( self )
        self.m_splitter.addWidget( self.m_listView_group )        
        self.m_splitter.addWidget( self.m_refenceManager_group )
        #Mode.
        self.m_nameBox_label = QtGui.QLabel( "name:" )
        self.m_nameBox_label.setMaximumWidth( 32 )
        self.m_nameBox = QtGui.QLineEdit() 
        self.m_refenceManagerMode_layout.addWidget( self.m_nameBox_label )
        self.m_refenceManagerMode_layout.addWidget( self.m_nameBox )
        #Buttons.
        self.m_addReference_button = QtGui.QPushButton( "Load references set" )
        self.m_addViewportReference_button = QtGui.QPushButton( "Save references set" )
        self.m_removeReference_button = QtGui.QPushButton( "Remove references set" )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addViewportReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_removeReference_button )
        #Make hierarchy.
        self.m_refenceManagerMode_group.setLayout( self.m_refenceManagerMode_layout )
        self.m_refenceManagerButtons_group.setLayout( self.m_refenceManagerListButtons_layout )
        self.m_refenceManagerGroup_layout.addWidget( self.m_refenceManagerMode_group )
        self.m_refenceManagerGroup_layout.addWidget( self.m_refenceManagerButtons_group )
        self.m_refenceManager_group.setLayout( self.m_refenceManagerGroup_layout )
        self.m_listView_group.setLayout( self.m_listView_layout )
        self.m_layout.addWidget( self.m_splitter )
        self.setLayout( self.m_layout )

class m_referenceManager( QtGui.QWidget ):
    
    def __init__( self, parent=ml_getMayaWindow()):
        super( m_referenceManager, self ).__init__( parent )
        #Layouts.
        self.m_layout = QtGui.QHBoxLayout()
        self.m_listView_group = QtGui.QGroupBox( "" )
        self.m_refenceManager_group = QtGui.QGroupBox( "" )
        self.m_refenceManagerMode_group = QtGui.QGroupBox( "" )
        self.m_refenceManagerMode_group.setMaximumHeight( 75 )
        self.m_refenceManagerListButtons_group = QtGui.QGroupBox( "List options: " )
        self.m_refenceManagerListButtons_group.setMaximumHeight( 450 )
        self.m_refenceManagerButtons_group = QtGui.QGroupBox( "Reference options: " )
        self.m_refenceManagerButtons_group.setMaximumHeight( 600 )
        self.m_listView_layout = QtGui.QHBoxLayout()
        self.m_refenceManagerGroup_layout = QtGui.QVBoxLayout()
        self.m_refenceManagerGroup_layout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.m_refenceManagerMode_layout = QtGui.QHBoxLayout()
        self.m_refenceManagerListButtons_layout = QtGui.QVBoxLayout()
        self.m_refenceManagerButtons_layout = QtGui.QVBoxLayout()
        #List.
        self.m_listView = QtGui.QListView()
        self.m_listView_layout.addWidget( self.m_listView )
        #splitter.
        self.m_splitter = QtGui.QSplitter( self )
        self.m_splitter.addWidget( self.m_listView_group )        
        self.m_splitter.addWidget( self.m_refenceManager_group )
        #Mode.
        self.m_comboBox_label = QtGui.QLabel( "Mode:" )
        self.m_comboBox_label.setMaximumWidth( 32 )
        self.m_comboBox = QtGui.QComboBox()
        self.m_comboBoxList = QtCore.QStringList()
        self.m_comboBoxList.append( "reference list" )
        self.m_comboBoxList.append( "selection" ) 
        self.m_comboBox.addItems( self.m_comboBoxList )
        self.m_refenceManagerMode_layout.addWidget( self.m_comboBox_label )
        self.m_refenceManagerMode_layout.addWidget( self.m_comboBox )
        #Buttons.
        self.m_addReference_button = QtGui.QPushButton( "Add selected" )
        self.m_addReferenceProxy_button = QtGui.QPushButton( "Add all loaded proxy" )
        self.m_addViewportReference_button = QtGui.QPushButton( "Add from viewport" )
        self.m_addAnimViewportReference_button = QtGui.QPushButton( "Add from animated viewport" )
        self.m_removeReference_button = QtGui.QPushButton( "Remove" )
        self.m_clearReference_button = QtGui.QPushButton( "Clear" )
        self.m_selectReference_button = QtGui.QPushButton( "Select content" )
        self.m_editsReference_button = QtGui.QPushButton( "list reference Edits" )
        self.m_unloadReference_button = QtGui.QPushButton( "Unload reference" )
        self.m_loadReference_button = QtGui.QPushButton( "Load reference" )
        self.m_reloadReference_button = QtGui.QPushButton( "Reload reference" )
        self.m_switchReference_button = QtGui.QPushButton( "Switch proxy" )
        self.m_openReference_button = QtGui.QPushButton( "Open reference" )
        self.m_importReference_button = QtGui.QPushButton( "Import reference" )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addReferenceProxy_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addViewportReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_addAnimViewportReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_removeReference_button )
        self.m_refenceManagerListButtons_layout.addWidget( self.m_clearReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_selectReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_editsReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_unloadReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_loadReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_reloadReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_switchReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_openReference_button )
        self.m_refenceManagerButtons_layout.addWidget( self.m_importReference_button )
        #Make hierarchy.
        self.m_refenceManagerMode_group.setLayout( self.m_refenceManagerMode_layout )
        self.m_refenceManagerListButtons_group.setLayout( self.m_refenceManagerListButtons_layout )
        self.m_refenceManagerButtons_group.setLayout( self.m_refenceManagerButtons_layout )
        self.m_refenceManagerGroup_layout.addWidget( self.m_refenceManagerMode_group )
        self.m_refenceManagerGroup_layout.addWidget( self.m_refenceManagerListButtons_group )
        self.m_refenceManagerGroup_layout.addWidget( self.m_refenceManagerButtons_group )
        self.m_refenceManager_group.setLayout( self.m_refenceManagerGroup_layout )
        self.m_listView_group.setLayout( self.m_listView_layout )
        self.m_layout.addWidget( self.m_splitter )
        self.setLayout( self.m_layout )

def main():
    return m_window()
        