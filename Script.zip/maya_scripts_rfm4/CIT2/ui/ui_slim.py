import maya.OpenMayaUI
import sip
from PyQt4 import QtCore, QtGui, Qt
from ml_getMayaWindow import *

def main():
    return QtGui.QPushButton( "test" )