import sendToRender
reload( sendToRender )
import YashkaSetupBeta
reload( YashkaSetupBeta )

def main():
    return YashkaSetupBeta.Window()