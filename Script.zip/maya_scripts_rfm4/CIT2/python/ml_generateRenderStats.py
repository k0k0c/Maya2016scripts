import maya.cmds as cmds
import maya.mel as mel

def ml_statistic( m_node, path='', selected=True, debug=False ):
    #Generate renderman statistic file for current scene.
    m_target_for_hide = cmds.ls( type=[ "mesh", "nurbsCurve", "nurbsSurface" ] )
    if path == '':
        statistic_name = mel.eval( 'rman stringinterpolate "${STAGE}"' ) + '.string'
        statistic_dir = ( mel.eval( 'rman stringinterpolate "${RMSPROJ}"' ) or mel.eval( 'rman stringinterpolate "${RMSPROD}"' ))
        statistic_path = '%s%s' % ( statistic_dir, statistic_name )
    else:
        statistic_path = path
        statistic_dir = '/'.join( path.split( '/' )[:-1] )
        statistic_name = path.split( '/' )[-1]
    if debug is True:
        print 'statistic: %s' % statistic_path
    #Render settings.
    mel.eval( 'setCurrentRenderer renderMan;' )
    mel.eval( 'rmanChangeRendererUpdate;' )
    cmds.setAttr( "renderManGlobals.rman__riopt__statistics_endofframe", 1 )
    cmds.setAttr( "renderManGlobals.rman__riopt__statistics_filename", 'stdout', type="string" )
    cmds.setAttr( "renderManGlobals.rman__riopt__statistics_xmlfilename", statistic_path, type="string" )
    cmds.setAttr( "renderManGlobals.rman__riattr___ShadingRate", 1 )
    cmds.setAttr( "renderManGlobals.rman__riattr__volume_depthrelativeshadingrate", 1 )
    cmds.setAttr( "renderManGlobals.rman__riopt__limits_vprelativeshadingrate", 1 )
    cmds.setAttr( "renderManGlobals.rman__riattr___FocusFactor", 1 )
    cmds.setAttr( "renderManGlobals.rman__riattr___MotionFactor", 1 )
    cmds.setAttr( "renderManGlobals.rman__riopt__shading_directlightingsamples", 1 )
    cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples0", 1 )
    cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples1", 1 )
    cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth0", 2 )
    cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth1", 2 )
    cmds.setAttr( "defaultResolution.width", 2048 )
    cmds.setAttr( "defaultResolution.height", 2048 )
    cmds.setAttr( "defaultRenderGlobals.startFrame", 1 )
    cmds.setAttr( "defaultRenderGlobals.endFrame", 1 )
    cmds.setAttr( "defaultRenderGlobals.byFrameStep", 1 )
    m_final = cmds.ls( "rmanFinalGlobals" )
    #Final pass settings.
    if not m_final:
        m_final = mel.eval( "rmanCreatePass \"rmanFinalGlobals\"" )
    else:
        m_final = m_final[0]
    mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_backfacing", "%s" )' % ( m_final, 0 ))
    mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_hidden", "%s" )' % ( m_final, 0 ))
    #Create statistic camera.
    ml_camera = cmds.camera()
    ml_transform = ml_camera[0]
    ml_camera = ml_camera[-1]
    m_cameras_list = cmds.ls( type='camera' )
    [ cmds.setAttr( "%s.renderable" % m_cameras_list[i], 0 ) for i in range( 0, len( m_cameras_list )) ]
    cmds.setAttr( "%s.renderable" % ml_camera, 1 )
    cmds.renderSettings( camera=ml_camera )
    cmds.setAttr( '%s.rotate' % ml_transform, -45, 45, 0 )
    m_hidden = []
    if selected is True:
        cmds.select( cmds.ls( m_node, long=True ))
        cmds.viewFit( ml_camera )
        m_hidden = cmds.hide( m_target_for_hide, returnHidden=True )
        cmds.showHidden( m_node )
    else:
        cmds.select( clear=True )
        cmds.viewFit( ml_camera )
    #Batch render.
    mel.eval( 'rman render;' )
    if m_hidden:
        cmds.showHidden( m_hidden )
    cmds.delete( ml_transform )
    #Render
    return statistic_path