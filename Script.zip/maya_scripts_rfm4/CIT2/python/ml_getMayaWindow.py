import maya.OpenMayaUI
import sip
import PyQt4

def ml_getMayaWindow():
    m_app = maya.OpenMayaUI.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), PyQt4.QtCore.QObject )