import maya.cmds as cmds
import maya.mel as mel

def ml_createCurveControl( name='', parent='', size='', target='', constraint=True, debug=False ):
    '''
    Create curve control for user specified node.
    '''
    def getLenght( node ):
        if node != '':
            bb = { 'min':cmds.getAttr( node + '.boundingBoxMin' )[0], 'max':cmds.getAttr( node + '.boundingBoxMax' )[0] }
            zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
            key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
            return zyx[ key[ True ] ]
        else:
            return 1
    #Make new nurbs curve.
    ml_curve_mel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
    ml_curve = mel.eval( ml_curve_mel )
    if debug is True:
        print ml_curve_mel
    #Resize curve.
    ml_length = getLenght( size )
    #Make hierarchy for curve.
    if name != '':
        m_target_short = target.split( "|" )[-1]
        if name != m_target_short:
            ml_curve = cmds.rename( ml_curve, name )
        else:
            m_temp = m_target_short.split( "_" )
            if len( m_temp ) > 1:
                target = cmds.rename( target, "_offset_".join( m_temp ))
            else:
                target = cmds.rename( target, m_temp[0] + "_offset" )
            ml_curve = cmds.rename( ml_curve, name )
        if debug is True:
            print 'rename %s %s' % ( ml_curve, name )
    cmds.scale( 1.2 * ml_length, 1.2 * ml_length, 1.2 * ml_length, ml_curve )
    cmds.makeIdentity( ml_curve, translate=True, rotate=True, scale=True, apply=True )
    #Connect curves to target nodes.
    if target != '':
        if constraint is True:
            cmds.parentConstraint( ml_curve, target, maintainOffset=True, weight=1 )
            cmds.scaleConstraint( ml_curve, target, maintainOffset=True, weight=1 )
            if debug is True:
                print 'parentConstraint %s -maintainOffset %s' % ( ml_curve, target )
                print 'scaleConstraint %s -maintainOffset %s' % ( ml_curve, target )
        else:
            cmds.parent( target, ml_curve )
            if debug is True:
                print 'parent %s %s' % ( target, ml_curve )
    if parent != '':
        cmds.parent( ml_curve, parent )
        if debug is True:
            print 'parent %s %s' % ( ml_curve, parent )
    return ml_curve