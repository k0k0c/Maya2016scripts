import re
import maya.cmds as cmds
import subprocess
import os

def ml_getCamera():
    '''
    Get camera name for current scene.
    '''
    m_result = ""
    m_cams = cmds.listCameras()
    m_scNum = ml_getScene() 
    m_epNum = ml_getEpisode() 
    m_regexp = re.compile( "{0}{1}".format( m_epNum, m_scNum ) , re.IGNORECASE )
    for i in range( 0, len( m_cams )):
        if m_regexp.findall( m_cams[i] ):
            m_result.append( m_cams[i] )
    return m_result

def ml_getEpisode():
    '''
    Get episode number for current scene.
    '''
    m_result = ""
    m_regexp = re.compile( "ep([0-9.]+)", re.IGNORECASE )
    m_name = cmds.file( query=True, sceneName=True )
    m_name = m_name and ( m_name.split( "/" )[-1]).split( "." )[0] or "untitled"
    m_num = m_regexp.findall( m_name )
    if m_num:
        m_result = int( m_num[0] )
    else:
        m_result = 00
    return m_result

def ml_getScene():
    '''
    Get scene number for current scene.
    '''
    m_result = ""
    m_regexp = re.compile( "sc([0-9.]+)", re.IGNORECASE )
    m_name = cmds.file( query=True, sceneName=True )
    m_name = m_name and ( m_name.split( "/" )[-1]).split( "." )[0] or "untitled"
    m_num = m_regexp.findall( m_name )
    if m_num:
        m_result = int( m_num[0] )
    else:
        m_result = 00
    return m_result

def ml_reloadReference( nodes="" ):
    '''
    Reload reference file by selected node in current scene.
    '''
    if nodes != "":
        m_nodes = cmds.ls( sl=True )
    else:
        m_nodes = cmds.ls( nodes )
    m_result = []
    for i in range( 0, len( m_nodes )):
        if cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ) and cmds.referenceQuery( m_nodes[i], filename=True ) not in m_result:
            m_namespace = cmds.referenceQuery( m_result[i], rfn=True )
            m_reference = cmds.referenceQuery( m_result[i], filename=True ) 
            cmds.file( m_reference, loadReference=m_namespace )
            m_result.append( m_reference )
    return m_result

def ml_getSequenceRange( m_camera ):
    '''
    Get sequence frame range for current camera used in sequence.
    '''
    m_result = []
    m_camera = cmds.ls( m_camera )
    m_sequence = cmds.listConnections( m_camera )
    m_sequence = [ m_sequence[i] for i in range( 0, len( m_sequence )) if cmds.nodeType( m_sequence[i] ) == "shot" ]
    [ m_result.append( cmds.getAttr( m_sequence[i] + ".startFrame" ), cmds.getAttr( m_sequence[i] + ".endFrame" ), cmds.getAttr( m_sequence[i] + ".sequenceStartFrame" )) for i in range( 0, len( m_sequence ))]
    return m_result   

def ml_getSceneType():
    '''
    Get current scene type.
    '''
    m_result = ""
    m_path = cmds.file( query=True, location=True )
    m_regexp = re.compile( "/assets/props|/assets/sets|/assets/chars|/(scenes)/ep[0-9]+", re.IGNORECASE )
    m_temp = m_regexp.findall( m_path )
    if m_temp:
        m_result = m_temp
    return m_result

def ml_exportCameras( m_path ):
    '''
    Export camera sequencer node with all connected cameras.
    '''
    cmds.select( cmds.ls( type="sequencer" ))
    cmds.file( m_path, force=True, options="v=0", type="mayaAscii", preserveReferences=True, exportSelected=True )
    return 0
    
def ml_txmake( m_input, m_output ):
    '''
    Convert tiff texture in tex.
    '''
    mg_txmake = '%srmantree/bin/txmake.exe' % mel.eval( 'rman stringinterpolate "${RMSTREE}"' )
    not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
    mg_input = m_input != '' and m_input or cmds.error( 'Please specify path to image source file.' )
    mg_output = m_output != '' and m_output or cmds.error( 'Please specify path to image output file.' )
    os.path.isfile( mg_output ) and os.remove( mg_output )
    if re.findall( '.tif$', mg_input ) and re.findall( '.tex$', mg_output ):
        mg_command = [ mg_txmake, '-verbose', '-smode', 'clamp', '-tmode', 'clamp', '-resize', 'up-', mg_input, mg_output ]
    if re.findall( '.tex$', mg_input ) and re.findall( '.tif$', mg_output ):
        mg_command = [ mg_txmake, '-format', 'tiff' , mg_input, mg_output ]
    else:
        cmds.error( 'Please specify tif and tex image files for input and output variables.' )
    if mg_command:
        mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
        mg_output = '\n'.join( mg_process.communicate() )
        return mg_output
    else:
        return False

def ml_listConnections( m_nodes, debug=False, source=True, destination=True, type='' ):
    '''
    List all connections for current node.
    '''
    def ml_listConnections_exec( m_temp ):
        m_temp = cmds.ls( m_temp )
        m_connections = cmds.listConnections( m_temp, source=source, destination=destination )
        if m_connections:
            for i in range( 0, len( m_connections )):
                if m_connections[i] not in m_result and m_connections[i] not in m_cache and m_connections[i] not in m_nodes:
                    m_cache.append( m_connections[i] )
                    if cmds.nodeType( m_connections[i] ) in m_type or type == '':
                        m_result.append( m_connections[i] )
                    if debug is True:
                        print 'next connection( %s ).' % m_connections[i]
                    ml_listConnections_exec( m_connections[i] )
    m_result = []
    m_cache = []
    m_type = type
    m_nodes = cmds.ls( m_nodes )
    ml_listConnections_exec( m_nodes )
    return m_result     

def ml_searchNode( m_string, m_type="" ):
    '''
    Find node by string, if mel function not working.
    '''
    m_result = []
    m_nodes = cmds.ls( long=True )
    for i in range( 0, len( m_nodes )):
        if m_string == m_nodes[i].split( "|" )[-1]:
            if m_type == "" or cmds.nodeType( m_nodes[i] ) == m_type:
                m_result.append( m_nodes[i] )
    return m_result

def generateName( m_node, names="", shablon="" ):
    '''
    Generate new unique node name.
    '''
    if shablon == "":
        if not cmds.referenceQuery( m_node, isNodeReferenced=True ):
            m_shablon = ( cmds.file( query=True, sceneName=True ).split( "/" )[-1]).split( "." )[0] or "untitled"
        else:
            m_shablon = ( cmds.referenceQuery( m_node, filename=True ).split( "/" )[-1]).split( "." )[0]
    else:
        m_shablon = shablon
    m_type = cmds.nodeType( m_node )
    m_type = ( m_type == "mesh" and "_geo" ) or ( m_type == "transform" and "_grp" ) or ""
    m_number = 1
    m_result = ""
    while True:
        m_result = "%s%s%s" % ( m_shablon, m_number, m_type )
        if cmds.objExists( m_result ) or m_result in names:
            m_number += 1
            continue
        else:
            break
    return m_result

def makeTransform( m_path ):
    '''
    Make transforms hierarchy.
    '''
    m_groups = m_path.split( "|" )
    for i in range( 0, len( m_groups )):
        if m_groups[i]:
            if not cmds.objExists( "|".join(m_groups[:i+1] )):
                if i == 0:
                    cmds.createNode( "transform", name=m_groups[i] )
                else:
                    cmds.createNode( "transform", name=m_groups[i], parent="|".join( m_groups[:i] ))
    return m_path

def ml_getDescendents( m_transform ):
    '''
    Get node descendents, if mel function not working.
    '''
    m_result = []
    m_filename = cmds.file( query=True, sceneName=True )
    m_reference = cmds.referenceQuery( m_transform, isNodeReferenced=True ) and cmds.referenceQuery( m_transform, filename=True ) or m_filename
    m_descendents = cmds.listRelatives( m_transform, allDescendents=True, type="transform", fullPath=True )
    if m_descendents:
        for i in range( 0, len( m_descendents )):
            m_state = cmds.referenceQuery( m_descendents[i], isNodeReferenced=True )
            if m_state and cmds.referenceQuery( m_descendents[i], filename=True ) == m_reference or m_state is False and m_reference == m_filename:
                if m_descendents[i] not in m_result:
                    m_result.append( m_descendents[i] )
    return m_result

def ml_listReferences( unique=False ):
    '''
    List all loaded references.
    '''
    def listReferences_exec( m_current ):
        m_references_current = cmds.file( m_current, query=True, reference=True )
        if m_references_current:
            for i in range( 0, len( m_references_current )):
                m_temp = m_references_current[i]
                if unique is True:
                    m_temp = m_temp.split( "{" )[0]
                if m_temp not in m_result:
                    m_result.append( m_temp )
                    listReferences_exec( m_references_current[i] )
    m_result = []
    m_references = cmds.file( query=True, reference=True )
    for i in range( 0, len( m_references )):
        listReferences_exec( m_references[i] )
        m_temp = m_references[i]
        if unique is True:
            m_temp = m_temp.split( "{" )[0]
        if m_temp not in m_result:
            m_result.append( m_temp )
    return m_result     