import maya.cmds as cmds
import maya.mel as mel
import rfm.slim

def ml_loadSlim( wait=1 ):
    #Run renderman slim.
    cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ) is not True and cmds.loadPlugin( "RenderMan_for_Maya" )
    m_result = mel.eval( "rman slim isconnected" ) and True or False
    m_break = time.time() + ( 60 * wait )
    m_batch = cmds.about( b=True ) and " -gui 0 -edit 0" or ""
    if m_result is False:
        mel.eval( "rman slim start" + m_batch )
        while True:
            if mel.eval( "rman slim isconnected" ) and mel.eval( "rman slim command \"slim GetSlimStatus\"" ):
                m_result = True
                break
            if time.time() > m_break:
                break
    return m_result

def ml_slimCmd( command, debug=False, message=False ):
    #Send to renderman slim command or message.
    m_result = []
    m_slim = rfm.slim.GetSlim()
    if not m_slim:
        ml_loadSlim( wait=1, debug=debug )
    m_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
    for i in range( 0, len( m_command )):
        m_temp = ""
        if message is False:
            m_temp = m_slim.Cmd( '"' + m_command[i] + '"' )
        else:
            m_temp = m_slim.Msg( '"' + m_command[i] + '"' )
            m_wait = 0
            while True:
                m_wait = m_wait + 1
                if mel.eval( 'rman slim isconnected' ):
                    break
                elif m_wait > 1000000000:
                    break
        if debug is True:
            print 'rman slim command "%s" Result: %s' % ( m_command[i], ( m_temp and m_temp or [] ))
        m_temp and m_result.append( m_temp )
    return m_result