import maya.cmds as cmds

def ml_nearClipPlane( m_delete=True ):
    '''
    Create expression for current camera near clip plane.
    '''
    m_cams = cmds.ls( sl=True, dag=True, type=["camera", "stereoRigCamera"], long=True )
    for i in range( 0, len( m_cams )):
        m_options = cmds.renderManip( m_cams[i], query=True, cam=True )
        m_connections = cmds.listConnections( "%s.nearClipPlane" % m_cams[i] )
        if m_connections:
            for n in range( 0, len( m_connections )):
                cmds.delete( m_connections[n] )
        cmds.renderManip( m_cams[i], edit=True, cam=[ m_options[0], m_options[1], m_options[2], False, m_options[4] ] )
        cmds.setAttr( "%s.nearClipPlane" % m_cams[i], 0.1 )
        if m_delete is False:
            cmds.expression( s="{0}.nearClipPlane=30*({0}.focalLength/50)*.34".format( m_cams[i] ), o=m_cams[i], ae=1, uc="all")
            cmds.renderManip( m_cams[i], edit=True, cam=[ m_options[0], m_options[1], m_options[2], True, m_options[4] ] )
    return 0