import maya.cmds as cmds
import maya.mel as mel

def ml_getAnimationCurves():
    '''
    List animation curves used in current scene.
    '''
    m_result = []
    m_curves_list = cmds.ls( type=[ "animCurveTU", "animCurveTL", "animCurveUU", "animCurveTA", "animCurveTT" ])
    m_curves_ref = cmds.ls( type=[ "animCurveTU", "animCurveTL", "animCurveUU", "animCurveTA", "animCurveTT" ], readOnly=True )
    m_curves_list = [ m_curves_list[i] for i in range(0, len(m_curves_list)) if m_curves_list[i] not in m_curves_ref ]
    [ m_result.append( m_curves_list[i] ) for i in range( 0, len( m_curves_list )) if m_curves_list[i] not in m_result ]
    return m_result

def ml_moveSequenceShot( m_shot, m_step ):
    '''
    Offset shot time.
    '''
    m_attrs = [".sequenceStartFrame", ".sequenceEndFrame", ".endFrame", ".startFrame"]
    for i in range(0, len( m_attrs )):
        cmds.setAttr( m_shot + m_attrs[i] , cmds.getAttr( m_shot + m_attrs[i] ) + m_step )
    return 0

def ml_moveKeyFrames( m_time, m_step, m_curves ):
    '''
    Offset keyframes time.
    '''
    for i in range(0, len( m_curves )):
        m_command = "keyframe -e -iub true -an objects -t \"{0}:{1}\" -r -o over -tc {2} {3};".format( m_time, cmds.playbackOptions( query=True, animationEndTime=True ), m_step, m_curves[i] )
        if m_step > 0:
            m_command = m_command.format( m_time, cmds.playbackOptions( query=True, animationEndTime=True ), m_step, m_curves[i] )
            print m_command
            mel.eval( m_command )
        else:
            m_command = m_command.format( cmds.playbackOptions( query=True, animationStartTime=True ), m_time, m_step, m_curves[i] )
            print m_command
            mel.eval( m_command )
    return 0

def ml_animationOffset( m_time, m_step ):
    '''
    Offset animation and sequence shot time.
    '''
    m_shots = cmds.ls( type="shot" )
    m_curves = ml_getAnimationCurves()
    for i in range(0, len( m_curves )):
        m_keys = cmds.keyframe( m_curves[i], query=True, timeChange=True )
        if m_keys is not None:
            for s in xrange(( len( m_keys ) -1 ), -1, -1 ):
                if m_step > 0 and m_keys[s] >= m_time or m_step < 0 and m_keys[s] <= m_time:
                    cmds.keyframe( m_curves[i], absolute=True, option= "move", edit=True, index=( s, s ), timeChange=( m_keys[s] + m_step ))
    if m_step < 0:
        m_range = xrange((len( m_shots )-1), -1, -1)
    else:
        m_range = range(0, len( m_shots ))
    for i in m_range:
        m_starttime = cmds.getAttr( m_shots[i] + ".sequenceStartFrame" )
        if m_step > 0 and m_starttime >= m_time or m_step < 0 and m_starttime <= m_time:
            ml_moveSequenceShot( m_shots[i], m_step )
            
def ml_animationOffsetSecond( m_time, m_step ):
    '''
    Offset animation and sequence shot time.
    '''
    m_shots = cmds.ls( type="shot" )
    m_curves = ml_getAnimationCurves()
    ml_moveKeyFrames( m_time, m_step, m_curves )
    for i in range(0, len( m_shots )):
        start = cmds.getAttr( m_shots[i] + ".sequenceStartFrame" )
        if m_step >= 0:
            if start > m_time:
                ml_moveSequenceShot( m_shots[i], m_step )
        else:
            if start <= m_time:
                ml_moveSequenceShot( m_shots[i], m_step )                      