import maya.cmds as cmds

def ml_loadPlugins( plugins='' ):
    #Load maya plugins.
    m_result = []
    m_plugins = plugins == '' and [ 'RenderMan_for_Maya', 'AbcExport' ] or ( 'list' in str( type( plugins )) and plugins or [ plugins ] )
    for i in range( 0, len( m_plugins )):
        if not cmds.pluginInfo( m_plugins[i], query=True, loaded=True ):
            m_result.append( m_plugins[i] )
            try:
                cmds.loadPlugin( m_plugins[i] )
            except:
                cmds.warning( 'Errors expected while initialize plugin: %s.' % str( m_plugins[i] ))
    return m_result