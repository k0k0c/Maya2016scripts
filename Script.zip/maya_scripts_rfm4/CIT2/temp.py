import maya.cmds as cmds
import re
import sip
from PyQt4 import QtCore, QtGui, Qt

import maya.OpenMayaUI
import sip

def ml_getMayaWindow():
    m_app = maya.OpenMayaUI.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )
    
class m_window( QtGui.QDialog ):
    
    def __init__( self, parent=ml_getMayaWindow()):
        super( m_window, self ).__init__( parent )
        self.m_layout = QtGui.QVBoxLayout()
        self.m_layout.setSpacing( 0 )
        self.m_layout.setContentsMargins( 3,3,3,3 )
        self.m_splitter = QtGui.QSplitter()
        self.m_createOptionsLayout = QtGui.QGridLayout()
        self.m_createOptionsGroupBox = QtGui.QGroupBox( "Deformation options: " )
        self.m_createOptionsGroupBox.setLayout( self.m_createOptionsLayout )
        self.m_createAdvOptionsLayout = QtGui.QGridLayout()
        self.m_createAdvOptionsGroupBox = QtGui.QGroupBox( "Advanced options: " )
        self.m_createAdvOptionsGroupBox.setMaximumWidth( 300 )
        self.m_createAdvOptionsGroupBox.setLayout( self.m_createAdvOptionsLayout )
        self.m_createActionsLayout = QtGui.QHBoxLayout()
        self.m_createActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_createActionsGroupBox.setLayout( self.m_createActionsLayout )
        self.m_createActionsGroupBox.setMaximumHeight( 50 )
        #Creation settings.
        #Noise slider.
        self.m_scaleLabel = QtGui.QLabel( "Scale " )
        self.m_scaleLabel.setMaximumWidth( 75 )
        self.m_scaleSpin = QtGui.QDoubleSpinBox()
        self.m_scaleSpin.setRange( -100000.0, 100000.0 )
        self.m_createOptionsLayout.addWidget( self.m_scaleLabel, 0, 0 )
        self.m_createOptionsLayout.addWidget( self.m_scaleSpin, 0, 1 )
        #Noise slider.
        self.m_noiseLabel = QtGui.QLabel( "Noise " )
        self.m_noiseLabel.setMaximumWidth( 75 )
        self.m_noiseSpin = QtGui.QDoubleSpinBox()
        self.m_noiseSpin.setRange( -100000.0, 100000.0 )
        self.m_createOptionsLayout.addWidget( self.m_noiseLabel, 1, 0 )
        self.m_createOptionsLayout.addWidget( self.m_noiseSpin, 1, 1 )
        #Bend curvature slider.
        self.m_curvatureLabel = QtGui.QLabel( "Bend " )
        self.m_curvatureLabel.setMaximumWidth( 75 )
        self.m_curvatureSpin = QtGui.QDoubleSpinBox()
        self.m_curvatureSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_curvatureLabel, 2, 0 )
        self.m_createOptionsLayout.addWidget( self.m_curvatureSpin, 2, 1 )
        #Twist start end slider.
        self.m_twistLabel = QtGui.QLabel( "Twist " )
        self.m_twistLabel.setMaximumWidth( 75 )
        self.m_twistSpin = QtGui.QDoubleSpinBox()
        self.m_twistSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_twistLabel, 3, 0 )
        self.m_createOptionsLayout.addWidget( self.m_twistSpin, 3, 1 )
        #Twis slider.
        self.m_flareLabel = QtGui.QLabel( "Flare " )
        self.m_flareLabel.setMaximumWidth( 75 )
        self.m_flareSpin = QtGui.QDoubleSpinBox()
        self.m_flareSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_flareLabel, 4, 0 )
        self.m_createOptionsLayout.addWidget( self.m_flareSpin, 4, 1 )
        #Sine slider.
        self.m_sineLabel = QtGui.QLabel( "Sine " )
        self.m_sineLabel.setMaximumWidth( 75 )
        self.m_sineSpin = QtGui.QDoubleSpinBox()
        self.m_sineSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_sineLabel, 5, 0 )
        self.m_createOptionsLayout.addWidget( self.m_sineSpin, 5, 1 )
        #Wave slider.
        self.m_waveLabel = QtGui.QLabel( "Wave: " )
        self.m_waveLabel.setMaximumWidth( 75 )
        self.m_waveSpin = QtGui.QDoubleSpinBox()
        self.m_waveSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_waveLabel, 6, 0 )
        self.m_createOptionsLayout.addWidget( self.m_waveSpin, 6, 1 )
        #Randomization slider.
        self.m_randomLabel = QtGui.QLabel( "Randomization " )
        self.m_randomLabel.setMaximumWidth( 75 )
        self.m_randomSpin = QtGui.QDoubleSpinBox()
        self.m_randomSpin.setRange( -100.000, 100.000 )
        self.m_createOptionsLayout.addWidget( self.m_randomLabel, 7, 0 )
        self.m_createOptionsLayout.addWidget( self.m_randomSpin, 7, 1 )
        #Advanced settings.
        #Hide deformers options.
        self.m_hideOption = QtGui.QCheckBox( "Hide deformers" )
        self.m_createAdvOptionsLayout.addWidget( self.m_hideOption, 0, 0 )
        #Center deformers options.
        self.m_centerOption = QtGui.QCheckBox( "Center position" )
        self.m_createAdvOptionsLayout.addWidget( self.m_centerOption, 1, 0 )
        #Deform geometry options.
        self.m_deformGeometryOption = QtGui.QCheckBox( "Deform geometry" )
        self.m_createAdvOptionsLayout.addWidget( self.m_deformGeometryOption, 2, 0 )
        #Replace deformers options.
        self.m_replaceDeformersOption = QtGui.QCheckBox( "Replace deformers" )
        self.m_createAdvOptionsLayout.addWidget( self.m_replaceDeformersOption, 3, 0 )
        #Wrap deformers options.
        self.m_wrapDeformersOption = QtGui.QCheckBox( "Enable wrap" )
        self.m_createAdvOptionsLayout.addWidget( self.m_wrapDeformersOption, 4, 0 )
        #Division slider.
        self.m_divisionOptionsLayout = QtGui.QGridLayout()
        self.m_divisionOptionsGroupBox = QtGui.QGroupBox( "" )
        self.m_divisionOptionsGroupBox.setMaximumHeight( 100 )
        self.m_divisionOptionsGroupBox.setLayout( self.m_divisionOptionsLayout )
        self.m_divisionLabel = QtGui.QLabel( "Division: " )
        self.m_divisionLabel.setMaximumWidth( 60 )
        self.m_divisionSpin = QtGui.QSpinBox()
        self.m_divisionSpin.setRange( 2, 100.000 )
        self.m_divisionOptionsLayout.addWidget( self.m_divisionLabel, 0, 0 )
        self.m_divisionOptionsLayout.addWidget( self.m_divisionSpin, 0, 1 )
        self.m_createAdvOptionsLayout.addWidget( self.m_divisionOptionsGroupBox, 5, 0 )
        #Envelope slider.
        self.m_envelopeLabel = QtGui.QLabel( "Envelope " )
        self.m_envelopeLabel.setMaximumWidth( 75 )
        self.m_envelopeSpin = QtGui.QDoubleSpinBox()
        self.m_envelopeSpin.setRange( 0, 100 )
        self.m_envelopeSpin.setValue( 100 )
        self.m_divisionOptionsLayout.addWidget( self.m_envelopeLabel, 1, 0 )
        self.m_divisionOptionsLayout.addWidget( self.m_envelopeSpin, 1, 1 )
        #Action buttons.
        self.m_createDeformationButton = QtGui.QPushButton( "Apply deformation" )
        self.m_createActionsLayout.addWidget( self.m_createDeformationButton )
        self.m_removeDeformationButton = QtGui.QPushButton( "Remove deformation" )
        self.m_createActionsLayout.addWidget( self.m_removeDeformationButton )
        #Settings
        self.m_splitter.addWidget( self.m_createOptionsGroupBox )
        self.m_splitter.addWidget( self.m_createAdvOptionsGroupBox )
        self.m_layout.addWidget( self.m_splitter )
        self.m_layout.addWidget( self.m_createActionsGroupBox )
        self.setLayout( self.m_layout )
        self.setMinimumWidth( 480 )
        self.setMinimumHeight( 320 )
        self.setWindowTitle( "Deformation settings" )
        
    def ml_applyDeformation( self ):
        pass
    
    def ml_removeDeformation( self ):
        pass
    
    def ml_getCurrentDeformation( self ):
        pass

def main():
    return m_window()

main().show()