import sys
import os
import re
import maya.OpenMayaUI
import sip
import rfm.rlf2maya as rlf2maya
import rfm.passes
from PyQt4 import QtCore, QtGui, Qt
import ssm_config
sys.path.append( ssm_config.SSM_ROOT + ssm_config.SSM_PYTHON )
sys.path.append( ssm_config.SSM_ROOT + ssm_config.SSM_UI )
import ml_getMayaWindow
reload( ml_getMayaWindow )
from ml_getMayaWindow import *

class dockWindow( QtGui.QDockWidget ):
    
    def __init__( self, m_parent=ml_getMayaWindow()):
        super( dockWindow, self ).__init__( m_parent )
        #Make main layout.
        m_parent.addDockWidget( QtCore.Qt.LeftDockWidgetArea, self )
        self.m_widget = QtGui.QWidget()
        self.m_layout = QtGui.QVBoxLayout()
        self.m_layout.setContentsMargins(3,3,3,3)
        self.m_widget.setLayout( self.m_layout )
        self.setWidget( self.m_widget )

def main():
    '''
    Load ui.
    '''
    #Create main window.
    SSM = dockWindow()
    SSM.setAllowedAreas( QtCore.Qt.LeftDockWidgetArea | QtCore.Qt.RightDockWidgetArea )
    SSM.setWindowTitle( "Scene setup manager ( SSM )" )
    #Load ui.
    m_content = QtGui.QTabWidget()
    m_content.setStyleSheet( "QTabWidget{background: rgb(68,68,68);}" )
    m_modules = os.listdir( ssm_config.SSM_ROOT + ssm_config.SSM_UI )
    for i in range( 0, len( m_modules )):
        if re.findall( ".py$", m_modules[i] ):
            m_module = m_modules[i].split( "." )[0]
            m_name = ( m_module ).split( "ui_" )[-1].capitalize()
            exec( "import %s as m_module" % m_module )
            m_module = reload( m_module )
            print "\tLoad module: %s" % m_module
            m_temp = m_module.main()
            m_content.addTab( m_temp, m_name )
    #Show window.
    SSM.m_layout.addWidget( m_content )
    SSM.show()

'''   
import sys
sys.path.append( "C:/Users/guzha_k/workspace/SSM" )
import ssm
reload( ssm )
ssm.main()
'''