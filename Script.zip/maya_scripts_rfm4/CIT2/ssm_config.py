SSM_ROOT = "//SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm4/CIT2"
SSM_UI = "/ui"
SSM_PYTHON = "/python"
SSM_TCL = "/tcl"