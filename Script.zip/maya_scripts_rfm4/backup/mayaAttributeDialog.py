import site
import codecs
import glob
import re
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

   
class SpinBoxDelegate(QtGui.QItemDelegate):
    sT=QtCore.QVariant(0)
    sN=QtCore.QVariant(-1)

    #def __init__(self):
    #        super(QtGui.QItemDelegate, self).__init__()

    #def __init__(self,var):
    #        QtGui.QItemDelegate.__init__(self)
    #        sT=var

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        imageOffset=0
        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)
        elif index.data(QtCore.Qt.UserRole+1).toInt()[0] == 2:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.Dense6Pattern)
            painter.fillRect(option.rect,brush)
            #painter.drawImage( QtCore.QRect(option.rect.x()+2,option.rect.y()+2,option.rect.height()-4,option.rect.height()-4),QtGui.QImage("/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/arrows-right-circular-icon.png"))
            #imageOffset=option.rect.height()

        one_width = 2
        if self.sT == 2:
            if index.data(QtCore.Qt.UserRole).toString()!="":
                textType = " ["+index.data(QtCore.Qt.UserRole).toString()[0:3]+"] "
                one_width = painter.fontMetrics().width(textType)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textType)
            elif index.data(QtCore.Qt.UserRole+2).toString()!="":
                textLoadedDraw=" ["+index.data(QtCore.Qt.UserRole+2).toString()+"] "
                one_width = painter.fontMetrics().width(textLoadedDraw)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textLoadedDraw)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        text_width = painter.fontMetrics().width(text)
        painter.drawText( option.rect.x()+one_width+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)

        overWidth=0
        '''if index.data(QtCore.Qt.UserRole+6).toString()!="":
            overText="    over    "
            overWidth = painter.fontMetrics().width(overText)
            painter.drawText( option.rect.x()+option.rect.width()-overWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,overText)
        '''
        proxyWidth=0
        if index.data(QtCore.Qt.UserRole+5).toString()!="":
            proxyText="     ["+index.data(QtCore.Qt.UserRole+5).toString()+"]"
            proxyWidth = painter.fontMetrics().width(proxyText)
            if option.rect.width()-overWidth-proxyWidth>one_width+imageOffset+text_width:
                painter.drawText( option.rect.x()+option.rect.width()-overWidth-proxyWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,proxyText)



        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins(8,8,8,8)


        self.twoWidget = QtGui.QWidget()
        self.AEgroupBoxFind = QtGui.QGridLayout(self.twoWidget)
        self.AEgroupBoxFind.setContentsMargins(10,0,0,0)
        self.AEgroupBowCheckBox = QtGui.QCheckBox(" Alembic export ")
        self.AEgroupBowCheckBox.setStyleSheet("QCheckBox::indicator:unchecked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-closed-scaled.png); width: 11px; height: 11px;} QCheckBox::indicator:checked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-open-scaled.png); width: 11px; height: 11px;} QCheckBox{font-weight: bold;}")
        self.AEgroupBowCheckBox.setCheckState(QtCore.Qt.Checked)
        self.AEgroupBowCheckBox.setContentsMargins(0,0,0,0)
        self.AEgroupBowCheckBox.stateChanged.connect(self.AEstateChangetgroupBowCB)

        self.startFrameSB = QtGui.QSpinBox()
        self.startFrameSB.setMaximum(100000)
        self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
        self.AEgroupBoxFind.addWidget(self.startFrameSB,0,0)        
        self.endFrameSB = QtGui.QSpinBox()
        self.endFrameSB.setMaximum(100000)
        self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
        self.AEgroupBoxFind.addWidget(self.endFrameSB,0,1)        

        self.AEExportButton = QtGui.QPushButton("Export settings to file")
        self.AEExportButton.released.connect(self.exportSettingsToFile)
        self.AEgroupBoxFind.addWidget(self.AEExportButton,1,0)        

        self.AESetupGeoButton = QtGui.QPushButton("Setup scene geometry")
        self.AESetupGeoButton.released.connect(self.setupGeoSlot)
        self.AEgroupBoxFind.addWidget(self.AESetupGeoButton,1,1)        

        self.AEloadunloaded = QtGui.QCheckBox("load unloaded")
        self.AEgroupBoxFind.addWidget(self.AEloadunloaded,2,0)        

        self.AEswithreferenceToOriginal = QtGui.QCheckBox("Switch references to original")
        self.AEswithreferenceToOriginal.setCheckState(QtCore.Qt.Checked)
        self.AEgroupBoxFind.addWidget(self.AEswithreferenceToOriginal,2,1)        

        self.AEExportChekbox = QtGui.QCheckBox("selected")
        self.AEgroupBoxFind.addWidget(self.AEExportChekbox,3,0)        

        self.AECreateGpuCasheChekbox = QtGui.QCheckBox("create GPU cashe")
        self.AEgroupBoxFind.addWidget(self.AECreateGpuCasheChekbox,3,1)        


        self.AEExportButton = QtGui.QPushButton("Export")
        self.AEExportButton.released.connect(self.AEExportButtonSlot)
        self.AEgroupBoxFind.addWidget(self.AEExportButton,5,0,1,2)        

        self.oneWidget = QtGui.QWidget()
        self.groupBoxFind = QtGui.QGridLayout(self.oneWidget)
        self.groupBoxFind.setContentsMargins(10,0,0,0)
        self.groupBowCheckBox = QtGui.QCheckBox(" Find objects ")
        self.groupBowCheckBox.setStyleSheet("QCheckBox::indicator:unchecked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-closed-scaled.png); width: 11px; height: 11px;} QCheckBox::indicator:checked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-open-scaled.png); width: 11px; height: 11px;} QCheckBox{font-weight: bold;}")
        self.groupBowCheckBox.setCheckState(QtCore.Qt.Checked)
        self.groupBowCheckBox.setContentsMargins(0,0,0,0)
        self.groupBowCheckBox.stateChanged.connect(self.stateChangetgroupBowCB)

                
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLayout.setContentsMargins(3,3,3,3)
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.groupBoxFind.addLayout(self.twoLayout,0,0)        


        self.filesWidget = QtGui.QWidget()
        self.twoLayoutGridOne = QtGui.QGridLayout(self.filesWidget)
        self.twoLayoutGridOne.setContentsMargins(0,0,0,0)

        self.filesRB = QtGui.QRadioButton("objects")
        self.refsRB = QtGui.QRadioButton("references")
        self.hRadio = QtGui.QHBoxLayout() 
        self.hRadio.setContentsMargins(3,3,3,3)
        self.hRadio.addWidget(self.filesRB)                        
        self.hRadio.addWidget(self.refsRB)                        
        self.groupBoxFind.addLayout(self.hRadio,1,0)                        
        self.refsRB.setChecked(True)        

        self.showLabel = QtGui.QLabel(" show type")
        self.checkShowType = QtGui.QCheckBox()
        self.namespaceLabel = QtGui.QLabel(" show namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                

        self.showFindedLabel = QtGui.QLabel(" only found")
        self.checkShowFinded = QtGui.QCheckBox()
        self.checkShowFinded.setCheckState(QtCore.Qt.Checked)
        self.checkShowFinded.connect(self.checkShowFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded)                

        self.expandFindedLabel = QtGui.QLabel(" expand found")
        self.checkexpandFinded = QtGui.QCheckBox()
        self.checkexpandFinded.setCheckState(QtCore.Qt.Checked)
        self.checkexpandFinded.connect(self.checkexpandFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetExpandFinded)                

        self.collapsePushButton = QtGui.QPushButton("collapse all")
        self.collapsePushButton.released.connect(self.collapseAllSlot)

        self.twoLayoutGridOne.addWidget(self.showLabel,0,1)
        self.twoLayoutGridOne.addWidget(self.checkShowType,0,2)                        
        self.twoLayoutGridOne.addWidget(self.namespaceLabel,0,3)
        self.twoLayoutGridOne.addWidget(self.checkShowNamespace,0,4)                        
        self.twoLayoutGridOne.addWidget(self.showFindedLabel,1,1)
        self.twoLayoutGridOne.addWidget(self.checkShowFinded,1,2)                        
        self.twoLayoutGridOne.addWidget(self.expandFindedLabel,1,3)
        self.twoLayoutGridOne.addWidget(self.checkexpandFinded,1,4)                        
        self.twoLayoutGridOne.addWidget(self.collapsePushButton,1,5)                        
        self.groupBoxFind.addWidget(self.filesWidget,2,0)        

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        
        self.mainLayout.addWidget(self.AEgroupBowCheckBox,0)
        self.mainLayout.addWidget(self.twoWidget,0)
        self.mainLayout.addWidget(self.groupBowCheckBox,0)
        self.mainLayout.addWidget(self.oneWidget,0)
        self.mainLayout.addWidget(self.treeView,1)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')
        self.filesRB.toggled.connect(self.setFilesRefs)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.checkShowType.setCheckState(QtCore.Qt.Checked)

    def FindAlembicSceneFolder(self):
        sss=mel.eval("rman getvar RMSPROJ")+"cache/alembic/"+mel.eval("rman getvar STAGE")+"_new"
        if not os.path.exists(sss):
            os.makedirs(sss)
        return sss

    def exportSettingsToFile(self):
        currNameSpaces=cmds.namespaceInfo(lon=True,r=True,an=True)
        data = {
        "namespaces" : currNameSpaces,
        }

        nodeNameExport={}
        for mP in cmds.ls("*mtorPartition*",r=True):
            nodeNameExport[mP]={}
            nodeNameExport[mP]["type"]=cmds.objectType(mP)
            nodeNameExport[mP]["attributes"]={}
            '''if cmds.attributeQuery("rlfData",n=mP,ex=True):
                temp=cmds.getAttr(mP+".rlfData")
                if temp:
                    nodeNameExport[mP]["rlfData"]=str(temp.encode("utf-8"))
            '''
            if cmds.attributeQuery("slimData",n=mP,ex=True):
                temp=cmds.getAttr(mP+".slimData")
                nodeNameExport[mP]["attributes"]["slimData"]={}
                nodeNameExport[mP]["attributes"]["slimData"]["type"]=cmds.getAttr(mP+".slimData",typ=True)
                if temp:
                    nodeNameExport[mP]["attributes"]["slimData"]["value"]=str(temp.encode("utf-8"))
            '''if cmds.attributeQuery("slimRIB",n=mP,ex=True):
                temp=cmds.getAttr(mP+".slimRIB")
                if temp:
                    nodeNameExport[mP]["slimRIB"]=str(temp.encode("utf-8"))
            '''
                    

                   
        tmpData={}
        if "nodes" in data.keys():
            tmpData=data["nodes"]
        else:
            data["nodes"]={}
            tmpData=data["nodes"]

        data["nodes"]=dict(tmpData.items() + nodeNameExport.items())



        filePath=self.FindAlembicSceneFolder()+"/settings.js"
        m_file = file( filePath, "w" )
        json.dump( data, m_file, indent=4, ensure_ascii=False )
        m_file.close()


    def setupGeoSlot(self):
        for im in cmds.ls(type="mesh",ni=True):
            if not cmds.attributeQuery("SubDivisionMesh",node=im,ex=True):
                cmds.addAttr(im,ln="SubDivisionMesh",at="bool",defaultValue=1)



    def AEExportButtonSlot(self):

        self.selectedFiles=[]
        self.selectedRootNodes=[]
        refsForPasses=[]
        if self.AEExportChekbox.checkState()==QtCore.Qt.Checked:
            for i in self.treeView.selectionModel().selectedRows():
                self.selectedFiles.append(str(i.data(QtCore.Qt.UserRole+3).toString()))
        else:
            self.onlyGetData=1
            temp = str(self.twoLineEdit.text())
            self.twoLineEdit.setText("")
            self.findText()   
            self.onlyGetData=0
            self.twoLineEdit.setText(temp)
            self.selectedFiles=self.listReferences

        for i in self.selectedFiles:
            print i


    def proxyActivate(self,rnNode):
        proxyManager=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True)
        if proxyManager:
            proxyManager=proxyManager.split(".")[0]
        else:    
            return
        artiveProxy=cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0].split(".")[-1]
        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
        currnetProxy=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True).split(".")[-1]
        if artiveProxy != currnetProxy:
            cmds.disconnectAttr(proxyManager+".activeProxy",proxyManager+"."+artiveProxy)
            cmds.connectAttr(proxyManager+".activeProxy", proxyManager+"."+currnetProxy)
            filenameToUnload=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
            if filenameToUnload != "":
                if not cmds.file(filenameToUnload,q=True,dr=True):
                    cmds.file(filenameToUnload,unloadReference=artiveRnNode)
        filenameToLoad=cmds.reference(rfn=rnNode,q=True,filename=True)
        if filenameToLoad != "":
            cmds.file(filenameToLoad,loadReference=rnNode)
                
        srcLstPlugs=cmds.listConnections(artiveRnNode+".associatedNode",source=True,connections=True,plugs=True)
        if srcLstPlugs:
            for i in range(0,len(srcLstPlugs),2):
                    cmds.disconnectAttr(srcLstPlugs[i+1],srcLstPlugs[i])
                    cmds.connectAttr(srcLstPlugs[i+1],rnNode+"."+srcLstPlugs[i].split(".")[-1])


    def stateChangetgroupBowCB(self,a):
        self.oneWidget.setVisible(a)
        

    def AEstateChangetgroupBowCB(self,a):
        self.twoWidget.setVisible(a)

    def setFilesRefs(self,a):
        if a:
            self.showLabel.setText(" show type")
        else:
            self.showLabel.setText(" show load")
        #self.showLabel.setVisible(a)
        #self.checkShowType.setVisible(a)                       
        #self.namespaceLabel.setVisible(a)
        #self.checkShowNamespace.setVisible(a)                      

    def stateChangetShowType(self,typeIs):
        self.delegate.sT=QtCore.QVariant(typeIs)
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))


    def stateChangetShowNamespace(self,typeIs):
        self.delegate.sN=typeIs
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))

    def stateChangetShowFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.showFindedRecurse(parentItem,typeIs)

    def showFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            if val:
                temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
                if temp > 0:
                    self.treeView.setRowHidden(chi,item.index(),False) 
                    self.showFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setRowHidden(chi,item.index(),True) 
            else:
                self.treeView.setRowHidden(chi,item.index(),False) 
                self.showFindedRecurse(item.child(chi,0),val)

    def stateChangetExpandFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.expandFindedRecurse(parentItem,typeIs)

    def expandFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
            if temp > 0:
                if val:
                        self.treeView.setExpanded(item.child(chi,0).index(),True) 
                        self.expandFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setExpanded(item.child(chi,0).index(),False) 


    def collapseAllSlot(self):
        self.checkexpandFinded.setCheckState(QtCore.Qt.Unchecked)
        parentItem = self.treeModel.invisibleRootItem()
        self.collapseAllSlotRecurse(parentItem)

    def collapseAllSlotRecurse(self,item):
        for chi in range(item.rowCount()):
            self.treeView.setExpanded(item.child(chi,0).index(),False) 
            self.collapseAllSlotRecurse(item.child(chi,0))


    def acceptedSig(self):
            pass

    def closeEvent(self, event):
            event.accept()

    
            
    def findText(self):   
        findTextLine = str(self.twoLineEdit.text())
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()

        '''
        listObjects = cmds.ls(dag=True,l=True)
        tree = []
        for item in listObjects:
            currentObject=item[1:].split('|')
            t=tree
            for i in range(len(currentObject)):
                da=-1
                for ii in range(len(t)):
                    if currentObject[i] in t[ii][0]:
                        da=ii
                        t=t[ii]
                        break
                if da == -1:
                    t.append([currentObject[i]])
                    t=t[-1]
        '''
        '''
        listFindedObjects=list(set(cmds.ls(findTextLine,l=True,o=True,r=True)))
        listObjects = cmds.ls(sl=True,dag=True,l=True,st=True) 
        tree = []
        for item in range(0,len(listObjects),2):
            typeObject=listObjects[item+1]
            currentObject=listObjects[item][1:].split('|')
            est="0"
            if listObjects[item] in listFindedObjects:
                est="1"
            t=tree
            for i in range(len(currentObject)):
                da=-1
                if i < (len(currentObject)-1) and ( est == "1" or est == "2" ):
                    est="2"
                elif i == (len(currentObject)-1) and ( est == "1" or est == "2" ):
                    est="1"
                for ii in range(len(t)):
                    if currentObject[i] in t[ii][0]:
                        da=ii
                        t[ii][2]=est
                        t=t[ii]
                        break
                if da == -1:
                    t.append([currentObject[i],typeObject,est])
                    t=t[-1]
        '''

        #cmds.timer(s=True) 
        tree = []
        if self.filesRB.isChecked():
            listFindedObjects=list(set(cmds.ls(findTextLine,l=True,o=True,r=True)))
            listObjects = cmds.ls(dag=True,l=True,st=True)
            for item in range(0,len(listObjects),2):
                typeObject=listObjects[item+1]
                currentObject=listObjects[item][1:].split('|')
                est="0"
                if listObjects[item] in listFindedObjects:
                    est="1"
                t=tree
                startwhis=""
                for i in range(len(currentObject)):
                    startwhis+="|"+currentObject[i]
                    da=-1
                    for ii in range(len(t)):
                        if currentObject[i] in t[ii][0]:
                            da=ii
                            t=t[ii]
                            break
                    if da == -1:
                        if est=="0":
                            for x in listFindedObjects:
                                if x.startswith(startwhis):
                                    est="2"
                        t.append([currentObject[i],typeObject,est])
                        t=t[-1]

            self.printItem(parentItem,tree)
        else:
            '''
            listFindedObjects=list(set(cmds.ls("*",rf=True,r=True)))
            listObjects = cmds.ls(rf=True) 
            tree = []
            for item in range(0,len(listObjects)):
                edem=1
                skolkoConnectov=cmds.listConnections(listObjects[item]+".proxyMsg",d=True,s=True,type="proxyManager")
                if not skolkoConnectov:
                    edem=1
                else:
                    if len(skolkoConnectov)==1:
                        edem=0        
                try:
                    fileName=cmds.referenceQuery(listObjects[item],f=True)
                    isLoaded=cmds.referenceQuery(listObjects[item],il=True)
                    namespace=cmds.file(fileName,query=True,ns=True)        
                except:
                    edem=0
                if edem:
                    currentObject=listObjects[item].split(':')
                    est="0"
                    if listObjects[item] in listFindedObjects:
                        est="1"
                    t=tree
                    startwhis=""
                    for i in range(len(currentObject)):
                        if i == 0:
                            startwhis+=currentObject[i]
                        else:
                            startwhis+=":"+currentObject[i]
                        da=-1
                        for ii in range(len(t)):
                            if currentObject[i] in t[ii][0]:
                                da=ii
                                t=t[ii]
                                break
                        if da == -1:
                            if est=="0":
                                for x in listFindedObjects:
                                    if x.startswith(startwhis):
                                        est="2"
                                        
                            print currentObject[i] 
                            t.append([currentObject[i],est])
                            t=t[-1]

            '''
            self.tree = []
            self.listReferences=[]
            self.loadAllrefs("",self.tree,self.tree,".*".join(findTextLine.split("*")))
            if not self.onlyGetData:
                self.printItemRefs(parentItem,self.tree)
        #print cmds.timer(e=True)

    def loadAllrefs(self,f,self.tree,root,sear):
        rn = cmds.file(f, query=True, reference=True )
        for r in rn:
            skolkoConnectov=cmds.listConnections(cmds.file(r,q=True,rfn=True)+".proxyMsg",d=True,s=True,type="proxyManager")
            proxyTag=cmds.getAttr(cmds.file(r,q=True,rfn=True)+".proxyTag")
            ifOverExists=""
            edem=1
            if skolkoConnectov:
                ifOverExists="1"
                if len(skolkoConnectov)==1:
                    edem=0  
            if edem:
                parentNamespace=cmds.file(r,query=True,pns=True)[0]
                namespaceThis=cmds.file(r,query=True,ns=True)
                if parentNamespace != "":
                    namespaceAll=parentNamespace+":"+namespaceThis
                else:
                    namespaceAll=namespaceThis
                isLoaded=1-int(cmds.file(r,q=True,dr=True))
                est="0"
                if sear!="":
                    expression = re.compile(sear, re.IGNORECASE)
                    m = expression.search(namespaceThis)
                    if m:
                        est="1"
                        tempRoot=self.tree
                        for sp in parentNamespace.split(":"):
                            for tr in tempRoot:
                                if tr[0]==sp:
                                    tr[1]="2"
                                    tempRoot=tr[4]
                        
                root.append([namespaceThis,est,isLoaded,r,[],namespaceAll,proxyTag,ifOverExists])
                self.listReferences.append(r)
                temp=root[-1][4]
                self.loadAllrefs(r,self.tree,temp,sear)

            
    def printItem(self, item, part):
        for i in range(len(part)):
            if type(part[i]) == type([]):
                itemChild = QtGui.QStandardItem(part[i][0])
                itemChild.setData(part[i][1],QtCore.Qt.UserRole)
                itemChild.setData(part[i][2],QtCore.Qt.UserRole+1)
                itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                item.appendRow(itemChild)
                if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                    if part[i][2] == "0":
                        self.treeView.setRowHidden(itemChild.row(),item.index(),True) 

                if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                    if part[i][2] != "0":
                        self.treeView.setExpanded(itemChild.index(),True) 

                self.printItem(itemChild,part[i])    
        
                        
    def printItemRefs(self, item, part):
        for i in range(len(part)):
            itemChild = QtGui.QStandardItem(part[i][5])
            itemChild.setData(part[i][2],QtCore.Qt.UserRole+2)
            itemChild.setData(part[i][3],QtCore.Qt.UserRole+3)
            itemChild.setData(part[i][5],QtCore.Qt.UserRole+4)
            itemChild.setData(part[i][6],QtCore.Qt.UserRole+5)
            itemChild.setData(part[i][7],QtCore.Qt.UserRole+6)
            itemChild.setData(part[i][1],QtCore.Qt.UserRole+1)
            itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            item.appendRow(itemChild)
            if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] == "0":
                    self.treeView.setRowHidden(itemChild.row(),item.index(),True) 
            if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] != "0":
                    self.treeView.setExpanded(itemChild.index(),True) 
            self.printItemRefs(itemChild,part[i][4])    

#ex = Window()
#ex.findText()
#ex.exec_()

