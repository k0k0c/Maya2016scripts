def unloadNotVisibleReferences():
    import main
    import maya.cmds as cmds
    camera = cmds.ls(sl=True, dag=True, type="camera")[-1]
    connections = cmds.listConnections( camera )
    isAnimated = False
    if connections:
        for connection in connections:
            if cmds.nodeType( connection ) in ["animCurveTU", "animCurveTA", "animCurveTL"]:
                isAnimated = True
                break
    if isAnimated is True:
        start = cmds.playbackOptions( query=True, animationStartTime=True )
        end = cmds.playbackOptions( query=True, animationEndTime=True )
    else:
        start = 0
        end = 0
    references = main.notVisbibleReferences( camera, filename=False, start=0, end=0, frameSpacing=2, frustum=0, aspect=1 )
    for i in range( len( references )-1, -1, -1 ):
        print "Unload:", references[i]
        try:
            cmds.file( unloadReference=references[i] )
        except:
            print "Failed to unload:", references[i]