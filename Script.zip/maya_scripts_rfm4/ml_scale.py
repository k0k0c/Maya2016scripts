import maya.cmds as cmds
def ml_scale( m_object, value="" ):
    def getParents( m_node ):
        m_parent = cmds.listRelatives( m_node, parent=True, fullPath=True )
        if m_parent:
            m_parent = m_parent[0]
            m_nodes.append( m_parent )
            getParents( m_parent )
    m_result = 1.0
    m_nodes = []
    getParents( m_object )
    if value == "":
        value = 1.0
    for i in range( 0, len( m_nodes )):
        m_scale = ( cmds.getAttr( "%s.sx" % m_nodes[i] ) + cmds.getAttr( "%s.sy" % m_nodes[i] ) + cmds.getAttr( "%s.sz" % m_nodes[i] )) / 3
        m_result = m_scale * m_result
    return m_result * float( value )
	
#[mel "python( \"import ml_scale; ml_scale( \'$OBJPATH\', value=4.0 )\")" ]