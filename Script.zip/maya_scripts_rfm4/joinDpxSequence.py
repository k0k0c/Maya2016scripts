import os
import subprocess

def ffmpegJoinDpxSequence( src, dst, framesCount ):
    command = [ "c:/mel/cmds/Fusion/eyeonScript.exe", "c:/mel/cmds/Fusion/renderSequence.eyeonScript", src, dst, "0", framesCount, "1.0" ]
    print "start join dpx sequence"
    process = subprocess.Popen( command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
    output = "\n".join( process.communicate() )
    print output

def createAviFromDpx( scene, directory, direction, output, view=False ):
    print "scene:", scene, direction
    print "directory:", directory
    print "output:", output
    if os.path.isdir( directory ):
        sequence = directory + scene + "_" + direction + "_0001.dpx"
        if os.path.isfile( sequence ):
            print "sequence:", sequence
            count = str( len( os.listdir( directory )))
            if os.path.isfile( output ):
                try:
                    os.remove( output )
                except:
                    print "File %s is locked" % output
                    os._exit(1)
            ffmpegJoinDpxSequence( sequence, output, count )
            path = os.path.normcase( output )
            print "done:", path
            if view is True:
                os.startfile( path )
            if os.path.isfile( path ):
                print "File %s" % path
            else:
                print "File %s is not finded" % path
                os._exit(1)
        else:
            print "Failed to find dpx sequence:", sequence
            os._exit(1)