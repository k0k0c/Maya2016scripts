import site
import codecs
import glob
import re
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

   
class SpinBoxDelegate(QtGui.QItemDelegate):
    #sT=QtCore.QVariant(0)
    sN=QtCore.QVariant(-1)

    #def __init__(self):
    #        super(QtGui.QItemDelegate, self).__init__()

    def __init__(self,var):
            QtGui.QItemDelegate.__init__(self)
            self.sT=var

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        print "Paint", self.sT
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        textType = " ["+index.data(QtCore.Qt.UserRole).toString()[0:3]+"] "
        one_width = 2
        if self.sT > 0:
            one_width = painter.fontMetrics().width(textType)
            painter.drawText( option.rect.x(),option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textType)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.model().data(index,QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        painter.drawText( option.rect.x()+one_width,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.mainLayout = QtGui.QVBoxLayout()
        self.groupBoxFind = QtGui.QGroupBox(" Find objects ")
        self.LayoutFindMain = QtGui.QVBoxLayout()
        self.LayoutFind = QtGui.QGridLayout()
        self.groupBoxFind.setLayout(self.LayoutFindMain)
        self.lastSelectedAssetPath=-1
        self.showType=0
        
                
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("s*")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.LayoutFindMain.addLayout(self.LayoutFind)
        self.LayoutFindMain.addLayout(self.twoLayout)        
        
        self.showLabel = QtGui.QLabel(" Show type")
        self.checkShowType = QtGui.QCheckBox()
        self.checkShowType.setCheckState(QtCore.Qt.Unchecked)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.namespaceLabel = QtGui.QLabel(" Show namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                
        self.twoLayoutGridOne = QtGui.QGridLayout()
        self.twoLayoutGridOne.addWidget(self.showLabel,0,1)
        self.twoLayoutGridOne.addWidget(self.checkShowType,0,2)                        
        self.twoLayoutGridOne.addWidget(self.namespaceLabel,0,3)
        self.twoLayoutGridOne.addWidget(self.checkShowNamespace,0,4)                        
        self.LayoutFindMain.addLayout(self.twoLayoutGridOne)        

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        
        self.delegate = SpinBoxDelegate(self.showType)
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        
        self.mainLayout.addWidget(self.groupBoxFind,0)
        self.mainLayout.addWidget(self.treeView,1)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')

    def stateChangetShowType(self,typeIs):
        self.delegate.sT=typeIs
        print self.delegate.sT


    def stateChangetShowNamespace(self,typeIs):
        print typeIs
        self.delegate.sN=typeIs
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))

    def acceptedSig(self):
            pass

    def closeEvent(self, event):
            event.accept()

    
            
    def findText(self):   
        findTextLine = str(self.twoLineEdit.text())
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()

        '''
        listObjects = cmds.ls(dag=True,l=True)
        tree = []
        for item in listObjects:
            currentObject=item[1:].split('|')
            t=tree
            for i in range(len(currentObject)):
                da=-1
                for ii in range(len(t)):
                    if currentObject[i] in t[ii][0]:
                        da=ii
                        t=t[ii]
                        break
                if da == -1:
                    t.append([currentObject[i]])
                    t=t[-1]
        '''
        listObjects = cmds.ls(findTextLine,dag=True,l=True,st=True)
        print findTextLine
        print listObjects
        tree = []
        for item in range(0,len(listObjects),2):
            typeObject=listObjects[item+1]
            currentObject=listObjects[item][1:].split('|')
            t=tree
            for i in range(len(currentObject)):
                da=-1
                for ii in range(len(t)):
                    if currentObject[i] in t[ii][0]:
                        da=ii
                        t=t[ii]
                        break
                if da == -1:
                    t.append([currentObject[i],typeObject])
                    t=t[-1]


        self.printItem(parentItem,tree)

            
    def printItem(self, item, part):
        for i in range(len(part)):
            if type(part[i]) == type([]):
                itemChild = QtGui.QStandardItem(part[i][0])
                itemChild.setData(part[i][1],QtCore.Qt.UserRole)
                itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                item.appendRow(itemChild)
                self.printItem(itemChild,part[i])    
        
                        

#ex = Window()
#ex.findText()
#ex.exec_()

