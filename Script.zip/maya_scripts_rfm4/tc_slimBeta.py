import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
import subprocess
import sys
import ast
import shutil
import math
import time
import rfm.slim
import ml_makeProxy
if cmds.about( b=True ) is False:
	import melnik_setup

def slim_init( wait=1, debug=False ):
	'''
	Start renderman slim.
	-wait = Wait time ( minutes ).
	'''
	if debug is True:
		print '\nInitialize renderman slim.'
	cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True and cmds.loadPlugin("RenderMan_for_Maya")
	ml_result = mel.eval('rman slim isconnected') and True or False
	ml_break = time.time() + ( 60 * wait )
	ml_batch = cmds.about( b=True ) and ' -gui 0 -edit 0' or ''
	if ml_result is False:
		mel.eval('rman slim start' + ml_batch )
		while True:
			if mel.eval( 'rman slim isconnected' ):
				if mel.eval( 'rman slim command \"slim GetSlimStatus\"' ):
					ml_result = True
					break
			if time.time() > ml_break:
				break
	return ml_result

def ml_plugins_setup( plugins='', debug=False ):
	'''
	Load plugins.
	-plugins = List plugins.
	-query = Return plugins loading state, without executing.
	'''
	ml_result = []
	ml_plugins = plugins == '' and [ 'RenderMan_for_Maya', 'AbcExport' ] or ( 'list' in str( type( plugins )) and plugins or [ plugins ] )
	for i in range( 0, len( ml_plugins )):
		if not cmds.pluginInfo( ml_plugins[i], query=True, loaded=True ):
			ml_result.append( ml_plugins[i] )
			try:
				if debug is True:
					print 'loadPlugin %s' % ml_plugins[i]
				cmds.loadPlugin( ml_plugins[i] )
			except:
				cmds.warning( 'Errors expected while initialize plugin: %s.' % str( ml_plugins[i] ))
		else:
			if debug is True:
					print 'Plugin already loaded %s' % ml_plugins[i]
	return ml_result
	
def slim_cmd( command, debug=False ):
	'''
	Send commands or messages to renderman slim.
	-command = Slim command or message.
	-debug = Print all outputs.
	'''
	ml_result = []
	ml_slim = rfm.slim.GetSlim()
	ml_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
	for i in range( 0, len( ml_command )):
		ml_temp = ml_slim.Cmd( '"' + ml_command[i] + '"' )
		if debug is True:
			print 'rman slim command "%s" Result: %s' % ( ml_command[i], ( ml_temp and ml_temp or [] ))
		ml_temp and ml_result.append( ml_temp )
	return ml_result

def ml_listConnections( ml_objects, debug=False ):
	'''
	List all connections for target node.
	'''
	def mlt_depth( ml_var ):
		mlt_connections = cmds.listConnections( ml_var, source=True, destination=True, shapes=True )
		if mlt_connections:
			for i in range( 0, len( mlt_connections )):
				if mlt_connections[i] not in ml_result and mlt_connections[i] not in ml_objects:
					if debug is True:
						print 'next connection( %s ).' % mlt_connections[i]
					ml_result.append( mlt_connections[i] )
					mlt_depth( mlt_connections[i] )
	ml_result = []    
	ml_objects = ( 'list' in str( type( ml_objects )) and ml_objects or [ ml_objects ] )
	mlt_depth( ml_objects )
	return ml_result

def ml_deleteNode( ml_objects, debug=False ):
	'''
	Delete maya objects.
	'''
	cmds.delete( ml_objects )
	if debug is True:
		print 'delete %s;' % ml_objects
	return ml_objects

def ml_setAttr( ml_object, ml_value, debug=False, force=False ):
	'''
	Set attribute value.
	'''
	if cmds.attributeQuery( ml_object.split( '.' )[-1], n=ml_object.split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( ml_object )) and cmds.getAttr( ml_object ) != ml_value:
		cmds.setAttr( ml_object, ml_value )
		if debug is True:
			print 'setAttr %s %s' % ( ml_object, ml_value )
	return ml_object.split( '.' )[0]

def ml_deleteAttr( ml_object, debug=False, force=False, empty=False ):
	'''
	Delete attribute.
	'''
	if cmds.attributeQuery( ml_object.split( '.' )[-1], n=ml_object.split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( ml_object )) and (( empty is True and not cmds.getAttr( ml_object )) or empty is False ):
		cmds.deleteAttr( ml_object )
		if debug is True:
			print 'deleteAttr %s' % ml_object
	return ml_object.split( '.' )[0]

def ml_addRmanAttr( ml_object, ml_attribute, ml_value, debug=False ):
	'''
	Add rman attribute.
	'''
	if not cmds.attributeQuery( ml_attribute, n=ml_object, exists=True ):
		mel.eval( 'rmanAddAttr( "%s", "%s", "%s" )' % ( ml_object, ml_attribute, ml_value ) )
		if debug is True:
			print 'rmanAddAttr( "%s", "%s", "%s" )' % ( ml_object, ml_attribute, ml_value )
	return ml_object

def ml_freeze( ml_object, debug=False ):
	ml_temp = cmds.ls( ml_object, dag=True, type='transform' )
	ml_childrens = []
	ml_attr = [ 'tx', 'tx', 'tz', 'rx', 'rz', 'rx', 'sz', 'sx', 'sz', 'translate', 'rotate', 'scale' ]
	[[ ml_childrens.append( '%s.%s' % ( ml_temp[i], ml_attr[n] )) for i in range( 0, len( ml_temp )) ] for n in range( 0, len( ml_attr )) ]
	if not cmds.listConnections( ml_childrens ):
		try:
			cmds.makeIdentity( ml_object, translate=True, apply=True )
		except:
			pass
		try:
			cmds.makeIdentity( ml_object, scale=True, apply=True )
		except:
			pass
		if debug is True:
			print 'makeIdentity -scale true -translate true -apply true %s;' % ml_object
	return ml_object

def ml_replaceRmanID( src, dst ):
	'''
	Replace slim id for all nodes.
	-objects = Objects list.
	-depth = Include in object list all childrens.
	'''
	ml_result = []
	ml_objects = cmds.ls( dag=True )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	for i in range( 0, len( ml_objects ) ):
		for p in range( 0, len( ml_attributes ) ):
			if cmds.attributeQuery( ml_attributes[p], n=ml_objects[i], exists=True ):
				value = cmds.getAttr( ml_objects[i] + '.' + ml_attributes[p] )
				if src in value:
					ml_result.append( ml_objects[i] )
					value = value.replace( src, dst )
					cmds.setAttr( ml_objects[i] + '.' + ml_attributes[p], value, type='string' )
	return ml_result

def ml_attachRmanQuery( ml_id ):
	'''
	Query attachment id state.
	'''
	ml_result = False
	ml_objects = cmds.ls( type=[ 'mesh', 'transform' ] )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
	for i in range( 0, len( ml_objects )):
		for n in range( 0, len( ml_attributes )):
			if cmds.attributeQuery( ml_attributes[n], n=ml_objects[i], exists=True ) is True:
				ml_value = cmds.getAttr( '%s.%s' % ( ml_objects[i], ml_attributes[n] ))
				if re.findall( ml_id, ml_value ):
					ml_result = True
					break
	return ml_result
	
def ml_flatRmanAttr( ml_object, ml_attribute, debug=False ):
	'''
	Rebind target attribute to shapes.
	'''
	def ml_flatRmanAttr_depth( ml_node, ml_attribute ):
		ml_childrens = cmds.listRelatives( ml_node, children=True, ni=True, path=True )
		if cmds.attributeQuery( ml_attribute, n=ml_node, exists=True ):
			ml_value = cmds.getAttr( '%s.%s' % ( ml_node, ml_attribute ))
			if ml_childrens:
				ml_deleteAttr( '%s.%s' % ( ml_node, ml_attribute ), debug=debug )
				for i in range( 0, len( ml_childrens )):
					ml_addRmanAttr( ml_childrens[i], ml_attribute, ml_value, debug=debug )
					ml_moveDownAttr( ml_childrens )
			ml_result.append( ml_node )
	ml_result = []
	ml_flatRmanAttr_depth( ml_object, ml_attribute )
	return ml_result

def ml_createCurveControl( name='', parent='', size='', target='', constraint=True, debug=False ):
	'''
	Create curve control shape.
	'''
	def getLenght( node ):
		if node != '':
			bb = { 'min':cmds.getAttr( node + '.boundingBoxMin' )[0], 'max':cmds.getAttr( node + '.boundingBoxMax' )[0] }
			zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
			key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
			return zyx[ key[ True ] ]
		else:
			return 1
	ml_curve_mel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
	ml_curve = mel.eval( ml_curve_mel )
	if debug is True:
		print ml_curve_mel
	ml_length = getLenght( size )
	if name != '':
		ml_curve = cmds.rename( ml_curve, name )
		if debug is True:
			print 'rename %s %s' % ( ml_curve, name )
	cmds.scale( 1.2 * ml_length, 1.2 * ml_length, 1.2 * ml_length, ml_curve )
	cmds.makeIdentity( ml_curve, translate=True, rotate=True, scale=True, apply=True )
	if target != '':
		if constraint is True:
			cmds.parentConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			cmds.scaleConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			if debug is True:
				print 'parentConstraint %s -maintainOffset %s' % ( ml_curve, target )
				print 'scaleConstraint %s -maintainOffset %s' % ( ml_curve, target )
		else:
			cmds.parent( target, ml_curve )
			if debug is True:
				print 'parent %s %s' % ( target, ml_curve )
	if parent != '':
		cmds.parent( ml_curve, parent )
		if debug is True:
			print 'parent %s %s' % ( ml_curve, parent )
	return ml_curve

def ml_txmake( input='', output='' ):
	'''
	Convert input file .tif to .tex or .tex to .tif.
	'''
	import subprocess
	import os
	import re
	mg_output = ''
	mg_txmake = executable == '' and '//SERVER-3D/Project/lib/soft/ffmpeg/bin/ffmpeg.exe' or executable
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	mg_input = input != '' and input or cmds.error( 'Please specify path to image source file.' )
	mg_output = output != '' and output or cmds.error( 'Please specify path to image output file.' )
	os.path.isfile( mg_output ) and os.remove( mg_output )
	if re.findall( '.tif$', mg_input ) and re.findall( '.tex$', mg_output ):
		mg_command = [ mg_txmake, '-verbose -smode clamp -tmode clamp -resize up-', mg_input, mg_output ]
	if re.findall( '.tex$', mg_input ) and re.findall( '.tif$', mg_output ):
		mg_command = [ mg_txmake, '-format tiff', mg_input, mg_output ]
	else:
		cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False

def ml_setup( debug=False, file='', hierarchySetup=True, shadingSetup=True, deleteHidden=True, deleteEmpty=True, deleteCameras=True, deleteArchives=True, rmanMaterialsSetup=True, normalDirectionSetup=True, normalAngleSetup=180, 
	setupAttributes=True, ensemblesSetup=True, deleteUnusedSlimNodes=True, slimSetup=True, bakeColors=True, deleteUnusedNodes=True, deleteHistory=True, uniqueifySlimNodes=True, saveScene=True, proxy=False ):
	'''
	Setup scene.
	'''
	print '____________________________________________________________________________'
	print 'Initialization.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	ml_file = file == '' and cmds.file( query=True, sceneName=True ) or file
	print 'file: %s' % ml_file
	re.findall( 'proxy', ml_file, re.IGNORECASE ) and cmds.error( 'File is proxy version, please specify path to original file.' )
	print '____________________________________________________________________________'
	print 'Load all preferences.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	ml_plugins_setup( debug=debug )
	slim_init( debug=debug )
	slim_cmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim.tcl", debug=debug )
	#Setup props.
	print '____________________________________________________________________________'
	print 'Make root hierarchy.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if hierarchySetup is True:
		if not re.findall( 'render|dyn', ml_file, re.IGNORECASE ):
			ml_temp = cmds.ls( assemblies=True, long=True )
			ml_temp = [ ml_temp[i] for i in range( 0, len( ml_temp )) if not cmds.referenceQuery( ml_temp[i], isNodeReferenced=True ) ]
			ml_rootGrp = cmds.objExists( '|root' ) and cmds.ls( '|root' )[0] or cmds.createNode( "transform", n="root" )
			if debug is True:
				print 'root group: %s' % ml_rootGrp
			ml_rigGrp = ''
			ml_geometryGrp = ''
			ml_childrens = cmds.listRelatives( ml_rootGrp, children=True, ni=True, path=True )
			ml_unknownGrp = []
			#Get rig and geometry groups.
			if ml_childrens:
				for i in range( 0, len( ml_childrens )):
					if cmds.nodeType( ml_childrens[i] ) == 'transform' and re.findall( 'rig', ml_childrens[i], re.IGNORECASE ) and ml_rigGrp == '':
						ml_rigGrp = ml_childrens[i]
					elif cmds.nodeType( ml_childrens[i] ) == 'transform' and re.findall( 'geo', ml_childrens[i], re.IGNORECASE ) and not re.findall( 'rig', ml_childrens[i], re.IGNORECASE ) and ml_geometryGrp == '':
						ml_geometryGrp = ml_childrens[i]
					else:
						ml_unknownGrp.append( ml_childrens[i] )
			ml_rigGrp = ml_rigGrp == '' and (( cmds.objExists( '|root|rig' ) and cmds.ls( '|root|rig' ) or cmds.createNode( "transform", n="rig", parent=ml_rootGrp ))) or ml_rigGrp
			ml_geometryGrp = ml_geometryGrp == '' and  (( cmds.objExists( '|root|geo_normal' ) and cmds.ls( '|root|geo_normal' ) or cmds.createNode( "transform", n="geo_normal", parent=ml_rootGrp ))) or ml_geometryGrp
			if debug is True:
				print 'geometry group: %s' % ml_geometryGrp
				print 'rig group: %s' % ml_rigGrp
			if ml_unknownGrp:
				for i in range( 0, len( ml_unknownGrp )):
					if not re.findall( 'rig', ml_unknownGrp[i], re.IGNORECASE ):
						print 'Founded unknown group: %s' % ml_unknownGrp[i]
						cmds.parent( ml_unknownGrp[i], ml_geometryGrp )
			#Include all can be used transforms to geometry group.
			for i in range( 0, len( ml_temp )):
				if not re.findall( 'root|top|persp|side|front', ml_temp[i] ):
					print ml_temp[i]
					cmds.parent( ml_temp[i], ml_geometryGrp )
					if debug is True:
						print 'parent %s %s' % ( ml_temp[i], ml_geometryGrp )
			print '____________________________________________________________________________'
			print 'Make root controls.'
			print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
			ml_controlsState = True
			ml_generalCT = cmds.ls( 'general_CT' )
			ml_generalCT_offset = ''
			if not ml_generalCT:
				ml_connections = ml_listConnections( ml_geometryGrp )
				if ml_connections:
					for i in range( 0, len( ml_connections )):
						if cmds.ls( ml_connections[i], dag=True, type='nurbsCurve' ):
							ml_generalCT = ml_connections[i]
							ml_controlsState = False
							if debug is True:
								print 'Unknown controls founded, pass.'
							break
			else:
				ml_childrens = cmds.listRelatives( ml_generalCT, allDescendents=True, path=True )
				ml_shapes = cmds.listRelatives( ml_generalCT, children=True, shapes=True, path=True )
				if ml_childrens and not cmds.listConnections( ml_childrens ) or not ml_childrens and cmds.listConnections( ml_generalCT ) or not ml_shapes:
					ml_controlsState = True
				else:
					ml_controlsState = False
					print 'Unknown controls founded, pass.'
			if ml_controlsState is True:
				if ml_generalCT:
					ml_generalCT_offset = cmds.rename( ml_generalCT, 'general_offset_CT' )
					ml_generalCT = ''
				if not ml_generalCT_offset:
					ml_generalCT_offset = ml_createCurveControl( name='general_offset_CT', parent=ml_rigGrp, size=ml_geometryGrp, target=ml_geometryGrp, constraint=True, debug=debug )
				if not ml_generalCT:
					ml_generalCT = ml_createCurveControl( name='general_CT', parent=ml_rigGrp, size=ml_generalCT_offset, target=ml_generalCT_offset, constraint=False, debug=debug )
		else:
			print 'pass'
	else:
		print 'passed...'
	#Get objects list.
	ml_objectsList = cmds.ls( long=True )
	ml_objectsList = [ ml_objectsList[i] for i in range( 0, len( ml_objectsList )) if not cmds.referenceQuery( ml_objectsList[i], isNodeReferenced=True ) ]
	print '____________________________________________________________________________'
	print 'Assign lambert to all mesh nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if shadingSetup is True:
		ml_temp = cmds.ls( ml_objectsList, type='mesh', long=True )
		if ml_temp:
			cmds.sets( ml_temp, edit=True, forceElement='initialShadingGroup' )
			if debug is True:
				print 'sets -edit -forceElement initialShadingGroup %s' % str( ml_temp )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Remove hidden and not used objects.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteHidden is True:
		ml_temp = cmds.ls( ml_objectsList, dag=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and cmds.nodeType():
				if not cmds.listConnections( cmds.ls( ml_temp[i], dag=True, long=True )) and (( cmds.attributeQuery( 'intermediateObject', n=ml_temp[i], exists=True ) and cmds.getAttr( '%s.intermediateObject' % ml_temp[i] ) is True or False ) or ( cmds.attributeQuery( 'visibility', n=ml_temp[i], exists=True ) and cmds.getAttr( '%s.visibility' % ml_temp[i] ) == 0 or False ) or not cmds.listRelatives( ml_temp[i], allDescendents=True, ni=True )):
					ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Remove empty groups.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteEmpty is True:
		ml_temp = cmds.ls( ml_objectsList, type='transform', long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ) and not cmds.listRelatives( ml_temp[i], allDescendents=True, ni=True, path=True ) and not cmds.listConnections( cmds.ls( ml_temp[i], dag=True, ni=True, long=True )):
				ml_deleteNode( ml_temp[i], debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Remove unused cameras.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteCameras is True:
		ml_temp = cmds.ls( ml_objectsList, type='camera', ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.objExists( ml_temp[i] ):
				ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
				if not re.findall( 'persp|side|front|top|ep[0-9]+|sc[0-9]+', str( ml_parent ), re.IGNORECASE ) and not cmds.listConnections( ml_parent, cmds.ls( ml_parent, dag=True, long=True )):
					cmds.camera( ml_temp[i], edit=True, startupCamera=False )
					ml_deleteNode( ml_parent, debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Delete unused rib archives and alembic caches.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteArchives is True:
		ml_temp = cmds.ls( ml_objectsList, type=[ 'RenderManArchive', 'gpuCache' ], ni=True, dag=True, long=True )
		for i in range( 0, len( ml_temp )):
			ml_parent = cmds.listRelatives( ml_temp[i], parent=True, path=True )
			if not cmds.ls( ml_parent, dag=True, type=[ 'mesh', 'nurbsSurface', 'nurbsCurve' ], long=True ) and not cmds.listConnections( ml_parent ):
				ml_deleteNode( ml_temp[i], debug=debug )
			else:
				ml_deleteNode( ml_parent, debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Rebind to shapes all materials attachements.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if rmanMaterialsSetup is True:
		ml_temp = cmds.ls( ml_objectsList, assemblies=True, long=True )
		ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
		for i in range( 0, len( ml_temp )):
			for n in range( 0, len( ml_attributes )):
				ml_flatRmanAttr( ml_temp[i], ml_attributes[n], debug=debug )
	else:
		print 'passed...'
	#Modelling 8.
	print '____________________________________________________________________________'
	print 'Setup normal direction:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if normalDirectionSetup is True:
		ml_temp = cmds.ls( ml_objectsList, type='mesh', dag=True, ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			cmds.polyNormal( ml_temp[i], normalMode=2, userNormalMode=1 )
			if debug is True:
				print 'polyNormal -normalMode 2 -userNormalMode 1 %s' % ml_temp[i]
			if cmds.getAttr( '%s.opposite' % ml_temp[i] ):
				cmds.polyNormal( ml_temp[i], normalMode=0, userNormalMode=0 )
				if debug is True:
					print 'polyNormal -normalMode 0 -userNormalMode 0 %s' % ml_temp[i]
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Setup normal angle:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if normalAngleSetup is not False and 'int' in str( type( normalAngleSetup )):
		ml_temp = cmds.ls( ml_objectsList, type='mesh', dag=True, ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			cmds.polySoftEdge( ml_temp[i], angle=normalAngleSetup )
			if debug is True:
				print 'polySoftEdge -angle %s %s' % ( str( normalAngleSetup ), ml_temp[i] )
	else:
		print 'passed...'
	#Texture setup 1, 1, 11
	print '____________________________________________________________________________'
	print 'Setup attributes:'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if setupAttributes is True:
		ml_temp = cmds.ls( ml_objectsList, type=[ 'mesh', 'transform', 'nurbsCurve' ], dag=True, ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			#Setup mesh node attributes.
			if cmds.nodeType( ml_temp[i] ) == 'mesh':
				ml_addRmanAttr( ml_temp[i], 'rman__torattr___subdivScheme', '', debug=debug )
				ml_setAttr( '%s.castsShadows' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.receiveShadows' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.primaryVisibility' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.motionBlur' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.visibleInReflections' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.visibleInRefractions' % ml_temp[i], 1, debug=debug )
				ml_setAttr( '%s.doubleSided' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.opposite' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.displaySmoothMesh' % ml_temp[i], 0, debug=debug )
				ml_setAttr( '%s.smoothShading' % ml_temp[i], 1, debug=debug )
				ml_deleteAttr( '%s.rman__torattr___invis' % ml_temp[i], debug=debug )
			#Setup transform node attributes.
			elif cmds.nodeType( ml_temp[i] ) == 'transform':
				ml_freeze( ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___invis' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___subdivScheme' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug )
			#Setup curve node attributes.
			elif cmds.nodeType( ml_temp[i] ) == 'nurbsCurve':
				ml_addRmanAttr( ml_temp[i], 'rman__torattr___invis', '', debug=debug )
				ml_deleteAttr( '%s.rman__torattr___subdivScheme' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
				ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug )
			#General setup.
			ml_setAttr( '%s.visibilty' % ml_temp[i], 1, debug=debug )
			ml_deleteAttr( '%s.rman__torattr___slimShader' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___slimSurface' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___postShapeScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___postTransformScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___preShapeScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___transformBeginScript' % ml_temp[i], debug=debug, empty=True )
			ml_deleteAttr( '%s.rman__torattr___transformEndScript' % ml_temp[i], debug=debug, empty=True )
	else:
		print 'passed...'
	#Modelling 9, 10.
	print '____________________________________________________________________________'
	print 'Reattach material ensembles as co-shaders.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if ensemblesSetup is True:
		ml_temp = cmds.ls( ml_objectsList, type=[ 'mesh' ], dag=True, ni=True, long=True )
		for i in range( 0, len( ml_temp )):
			if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=ml_temp[i], exists=True ):
				ml_ensemble = cmds.getAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i] )
				ml_materials = slim_cmd( 'tc_ensembleProperty -id ' + str( ml_ensemble ), debug=debug)
				if ml_materials:
					ml_materials = ml_materials[0].split( ' ' )
					ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % ml_temp[i], debug=debug )
					ml_addRmanAttr( ml_temp[i], 'rman__torattr___slimSurface', ml_materials[0], debug=debug )
					if ml_materials[1:]:
						ml_addRmanAttr( ml_temp[i], 'rman__torattr___slimShader', ','.join( ml_materials[1:] ), debug=debug )
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Remove unused materials from slim.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteUnusedSlimNodes is True:
		ml_listID = slim_cmd( 'tc_list -appearance _Attachable -return id', debug=debug )
		if ml_listID:
			ml_listID = ml_listID[0].split( ' ' )
			ml_deletable = ''
			for i in range( 0, len( ml_listID )):
				if not ml_attachRmanQuery( ml_listID[i] ):
					ml_deletable = ' '.join( [ ml_deletable, ml_listID[i] ] )
			if ml_deletable != '':
				slim_cmd( 'tc_delete %s' % ml_deletable, debug=debug )
		else:
			print 'No attachable materials founded.'
	else:
		print 'passed...'
	#Slim 1-18.
	print '____________________________________________________________________________'
	print 'Setup slim palettes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if slimSetup is True:
		#Setup palettes.
		slim_cmd( "tc_globalSetup " + ( ml_file.split( '/' )[-1] ).split( '.' )[0], debug=debug )
		#Combine all palettes in one palette.
		slim_cmd( "tc_combinePalettes", debug=debug )
		#Delete disconnected nodes in slim.
		slim_cmd( "tc_clear -disconnected", debug=debug )
		#Texture 4.
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Bake texture to color set.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if bakeColors is True:
		pass
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Delete unused nodes.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteUnusedNodes is True:
		pass
	else:
		print 'passed...'
	#Modelling 4.
	print '____________________________________________________________________________'
	print 'Delete history.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if deleteHistory is True:
		pass
	else:
		print 'passed...'
	#Modelling 6, 13, Texture 5, 13, 7, 8, 12
	print '____________________________________________________________________________'
	print 'Uniqueify slim id.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if uniqueifySlimNodes is True:
		pass
	else:
		print 'passed...'
	#Modelling 6, 13, Texture 5, 13, 7, 8, 12
	print '____________________________________________________________________________'
	print 'Save scene.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if saveScene is True:
		pass
	else:
		print 'passed...'
	print '____________________________________________________________________________'
	print 'Make proxy.'
	print '_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _'
	if proxy is True:
		ml_makeProxy.ml_makeProxy()
	else:
		print 'passed...'
	#TEX 1.2, 3, 9, 10 Flat all shaders and subdivide attributes. 
	#MOD 1, 2, 3, 5, 7, 11, 12 TEX 1, 6, 9, 11. Hierarchy ( names, hierarchy, pivots, smooth, renderstats, Setup controls, Setup transforms )
	#TEX 2 Check materials attachments
	#TEX 4 Color setup
