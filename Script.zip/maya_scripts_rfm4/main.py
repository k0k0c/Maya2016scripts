def networkFileSave():
    import re
    import sys
    import os
    import maya.cmds as cmds
    rez = rez = cmds.confirmDialog( title='Save file to local?', message='network files on the project should be saved only through the interface', button=['Yes','No'], defaultButton='Yes', cancelButton='No', dismissString='No' )
    if rez == "Yes":
        sceneName=cmds.file(q=True,sn=True)
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        homeProjectDir=os.environ['HOME']+"/Project"
        pathFileDir = expression.sub(homeProjectDir,sceneName)
        if not os.path.exists(pathFileDir):
            os.makedirs(pathFileDir)
        cmds.file(rename=pathFileDir)
        cmds.file(save=True,force=True)

def ribgen( node, filename="", start=0, end=1, step=1 ):
    """
    Generate rib archive.
    """
    import maya.cmds as cmds
    import maya.mel as mel
    import os
    import init_slim
    import glob
    import shutil
    init_slim.init_slim()
    project = cmds.workspace( query=True, rootDirectory=True )
    paths = glob.glob( project + "renderman/ribarchives/" + node + "RIBArchiveShape*" )
    for path in paths:
        if os.path.isdir( path ):
            try:
                print "Remove tree: " + path 
                shutil.rmtree( path )
            except:
                print "ERROR EXEPTION REMOVE TREE: " + path 
        else:        
            try:
                print "Remove file: " + path            
                os.remove(path)    
            except:
                print "ERROR EXEPTION REMOVE FILE: " + path   
    cmds.setAttr("renderManGlobals.rman__riopt__rib_format", "binary", type="string")   
    cmds.setAttr("renderManGlobals.rman__riopt__rib_compression", "gzip", type="string")   
    command = "$node[0]=\"" + node + "\";rmanCreateRIBArchives $node " + str(start) + " " + str(end) + " " + str(step)
    print command
    mel.eval( command )
     
def lastVersion( name ):
    """
    Return version from filename.
    """
    import re
    version = re.findall( "_v([0-9]+).*", name )
    if version:
        return int( version[-1] )
    else:
        return 0
     
def getEpisodeDirectory( path, folder="" ):
    """
    Get path to episode directory if source path in episode folder.
    """
    import re
    import os
    result = ""
    expression = re.compile( "(.*/ep[0-9]+/)ep[0-9]+sc[0-9]+.*/", re.IGNORECASE )
    ep = expression.search( path )
    if ep:
        ep = ep.group(0)
        if os.path.isdir( ep ):
            result = os.path.join( ep, folder )
    return result
    
def loadReferences( rfn="", rfns=[], unloadUnused=True ):
    """
    Load reference list in current opened scene.
    """
    import maya.cmds as cmds
    import ml_reference
    result = []
    if rfn != "":
        if cmds.objExists( rfn ):
            parent = rfn
            filename = cmds.referenceQuery( rfn, filename=True )
            namespace = cmds.file( filename, query=True, renamingPrefix=True )
        else:
            parent = cmds.file( rfn, query=True, rfn=True )
            filename = rfn
            namespace = cmds.file( rfn, query=True, renamingPrefix=True )
        namespace = ":".join( parent.split( ":" )[:-1]) + ":" + namespace
    else:
        parent = ""
        namespace = ""
    if parent != "":
        references = listReferences( references=filename, onlyLoaded=True )
    else:
        references = listReferences( onlyLoaded=True )
    for reference in references:
        if unloadUnused is True and cmds.objExists( reference ) and reference not in rfns:
            ml_reference.unloadReference( reference )
    for rfn in rfns:
        if cmds.objExists( rfn ) and cmds.nodeType( rfn ) == "reference":
            if cmds.referenceQuery( rfn, isLoaded=True ) is False:
                if rfn not in result:
                    result.append( rfn )
                    ml_reference.loadReference( rfn, loadReferenceDepth="topOnly" )
    return result

def pathToNetwork( path, toServer3d=False ):
    """
    Return valid path to network.
    """
    import re
    import sys
    if toServer3d is False and re.findall( "renderserver", path, re.IGNORECASE ):
        res = [ "//renderserver/Project", "/renderserver/Project" ]
        expression = re.compile("^(/renderserver/Project)|(/mnt/renderserver)|(//renderserver/Project)", re.IGNORECASE)
    else:
        res = [ "//Server-3d/Project", "/Server-3d/Project" ]
        if toServer3d is False:
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        else:
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)|(/renderserver/Project)|(/mnt/renderserver)|(//renderserver/Project)", re.IGNORECASE)
    repath = sys.platform == "win32" and res[0] or res[1]
    path = expression.sub( repath, path )
    path = path.replace( "\\", "/" )
    return path
    
def pathToAlembic( temp=False ):
    """
    Return path to alembic folder for current opened scene.
    """
    import sys
    import maya.cmds as cmds
    import os
    import re
    server = sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project"
    root = cmds.workspace( query=True, rootDirectory=True )
    abcPath = "cache/alembic"
    if temp is True:
        abcPath = "cache/alembic/alembicTemp"
    output = os.path.join( root, abcPath )
    expression = re.compile("^(//renderServer/Project)|^(/home/.*/renderServer)|^(/mnt/renderServer)|^(/renderServer/Project)", re.IGNORECASE)
    output = expression.sub( server, output )
    return output

def readAlembicSettings( filename="" ):
    """
    Return alembic settings dictionary.
    """
    import json
    import os
    import maya.cmds as cmds
    if filename == "":
        sceneName = cmds.file( query=True, sceneName=True ).split( "/" )[-1].split( "." )[0]
        sceneName = sceneName != "" and sceneName or "untitled"
        filename = pathToAlembic()
        filename = filename + "/" + sceneName + ".js"
    if os.path.isfile( filename ):
        container = open( filename ).read()
        data = json.loads( container )
    else:
        data = {}
    return data
    
def findRenderVersion( filename="", value="" ):
    """
    Return filename to current render version by source filename and his value.
    """
    import re
    import os
    shortName = filename.split( "/" )[-1].split( "." )[0]
    rfolder = "/".join( filename.split( "/" )[:-1])
    versions = os.listdir( rfolder )
    finded = re.search( ".*(?<=/chars/|/props/)", filename )
    pfolder = finded.group(0)
    assets = os.listdir( pfolder )
    rexpr = re.compile( shortName + "(_render\.m[ab]|render\.m[ab]|Render\.m[ab])", re.IGNORECASE )
    vexpr = re.compile( "(" + shortName + "_" + value + "|" + value + ")(_render\.m[ab]|render\.m[ab]|Render\.m[ab])", re.IGNORECASE )
    if value == "":
        for version in versions:
            if rexpr.findall( version ):
                return os.path.join( rfolder, version )
        return filename
    else:
        for version in versions:
            if vexpr.findall( version ):
                return os.path.join( rfolder, version )
        for asset in assets:
            if asset == value:
                afolder = os.path.join( pfolder, asset, "maya/" )
                rexpr = re.compile( value + "(_render\.m[ab]|render\.m[ab]|Render\.m[ab])", re.IGNORECASE )
                if os.path.isdir( afolder ):
                    versions = os.listdir( afolder )
                    for version in versions:
                        if rexpr.findall( version ):
                            return os.path.join( afolder, version )
        return filename
    return filename

def cleanName( name ):
    """
    Clean namespaces and deformed names
    """
    import re
    buffer = []
    expression = re.compile( "deformed$|Deformed$|deformed[0-9]$|Deformed[0-9]$" )
    for part in name.split( "|" ):
        part = part.split( ":" )[-1]
        buffer.append( part )
    name = "|".join( buffer ) 
    find = expression.findall( name )
    if find:
        name = name[:-len(find[-1])]
    return name
    
def animatedReferencedNodes( characters=False, onlyFilename=False, ignoreProxy=False ):
    """
    Iterate all references and his nodes if reference has animations or deformations or constraints.
    """
    import maya.cmds as cmds
    import re
    expression = re.compile( "proxy", re.IGNORECASE )
    curves = cmds.ls( type=["animCurveTU", "animCurveTA", "animCurveTL"], long=True )
    curves = [ curve for curve in curves if not cmds.referenceQuery( curve, isNodeReferenced=True ) ]
    if not curves:
        animated = []
    else:
        animated = cmds.ls( cmds.listConnections( curves, type="transform" ), long=True )
    deformed = deformedReferencedNodes()
    constrained = constrainedReferencedNodes()
    filenames = listReferences( characters=characters, onlyLoaded=True )
    for filename in filenames:
        if ignoreProxy is True:
            if expression.findall( filename ):
                continue
        nodes = cmds.ls( cmds.referenceQuery( filename, nodes=True, dagPath=True ), long=True )
        if nodes:
            isAnimated = False
            for node in nodes:
                if node in animated or node in constrained or node in deformed:
                    isAnimated = True
                    break
            if isAnimated is True:
                if onlyFilename is True:
                    yield filename
                else:
                    yield [ filename, nodes ]
    
def deformedReferencedNodes():
    """
    List all deformed nodes if his target is reference.
    """
    import maya.cmds as cmds
    deformed = []
    deformers = cmds.ls( type=[ "blendShape", "cluster", "lattice", "nonLinear", "sculpt", "wire" ], long=True )
    for deformer in deformers:
        if not cmds.referenceQuery( deformer, isNodeReferenced=True ):
            geometry = cmds.deformer( deformer, query=True, geometry=True )
            if geometry:
                parent = cmds.listRelatives( geometry, parent=True, fullPath=True )
                if parent:
                    parent = parent[0]
                    if parent not in deformed:
                        if cmds.referenceQuery( parent, isNodeReferenced=True ):
                            deformed.append( parent )
    return deformed

def constrainedReferencedNodes():
    """
    List all constrained nodes if his target is reference.
    """
    import maya.cmds as cmds
    constrained = []
    constraints = cmds.ls( type=[ "aimConstraint", "geometryConstraint", "normalConstraint", "orientConstraint", "parentConstraint", "pointConstraint", "pointOnPolyConstraint", "scaleConstraint", "tangentConstraint" ], long=True )
    for constraint in constraints:
        if not cmds.referenceQuery( constraint, isNodeReferenced=True ):
            connections = cmds.listConnections( constraint, source=False )
            if connections:
                for connection in connections:
                    if cmds.nodeType( connection ) != "transform":
                        parent = cmds.listRelatives( connection, parent=True, fullPath=True )
                        if parent:
                            parent = parent[0]
                    else:
                        parent = connection
                    if parent:
                        if parent not in constrained:
                            if cmds.referenceQuery( parent, isNodeReferenced=True ):
                                constrained.append( parent )
    return constrained
    
def listReferences( references=[], characters=False, onlyLoaded=False, rfn=False, fullHierarchy=False ):
    """
    Iterate all references from current scene.
    """
    import maya.cmds as cmds
    import re
    if not references:
        rn = cmds.file( query=True, reference=True )
    else:
        rn = type( references ) is list and references or [ references ]
    while rn:
        cache = []
        if rn:
            for reference in rn:
                child = cmds.file( reference, query=True, reference=True )
                if child:
                    cache += child
                    if fullHierarchy is True:
                        if rfn is True:
                            rfNode = cmds.file( reference, query=True, rfn=True )
                            yield rfNode
                        else:
                            yield reference
                else:
                    if onlyLoaded is True and cmds.referenceQuery( reference, isLoaded=True ) or onlyLoaded is False:
                        if characters is True and re.findall( "/chars/", reference ) or characters is False:
                            if rfn is True:
                                rfNode = cmds.file( reference, query=True, rfn=True )
                                yield rfNode
                            else:
                                yield reference
        rn = cache
    
def buildReferencePresetData( data=[], level="" ):
    """
    Build reference list from reference preset data.
    """
    result = []
    if level == "":
        level = data
    for i in range( 0, len( level )):
        proxy = level[i].keys()
        proxyLenght = len( proxy )
        activeFounded = False
        for p in range( 0, proxyLenght ):
            rfn = level[i][proxy[p]]
            isLoaded = rfn["load"]
            if p == proxyLenght-1 and activeFounded is False:
                isActive = 1
            else:
                isActive = rfn["active"]
            content = rfn["ref"]
            if isActive == 1:
                activeFounded = True
                if isLoaded == 1:
                    result.append( proxy[p] )
                    if content:
                        cache = buildReferencePresetData( data=data, level=content )
                        if cache:
                            result += cache
    return result
    
def listPresets( filename="", presetType="referencePreset" ):
    """
    List presets names from js file.
    """
    import json
    result = []
    path = pathToPreset( filename=filename )
    filename = open( path ).read()
    data = json.loads( filename )
    for i in range( 0, len( data )):
        keys = data[i].keys()
        if "type" in keys:
            if data[i]["type"] == presetType:
                name = data[i]["name"]
                result.append( name )
    return result

def getPresetData( filename="", name="", presetType="referencePreset" ):
    """
    Get presets data from js file by preset name.
    """
    import json
    result = []
    path = pathToPreset( filename=filename )
    filename = open( path ).read()
    data = json.loads( filename )
    for i in range( 0, len( data )):
        keys = data[i].keys()
        if "type" in keys:
            if data[i]["type"] == presetType:
                if data[i]["name"] == name:
                    result = data[i]["preset"]
                    break
    return result
    
def changeStringAttr(nodeAttr="",pastedString="",chto="",chtoIskat="",setAttr=False):
    import maya.cmds as cmds
    import re
    currentAttr = str(cmds.getAttr(nodeAttr))
    if len(chto) and chto[-1]!=";":
            chto=chto+";"
    if re.search(re.escape(chtoIskat)+'.*?\;', currentAttr) is not None:
        rez = re.sub('\ *'+re.escape(chtoIskat)+'.*?\;', chto, currentAttr)
    else:
        if len(currentAttr) and currentAttr[-1]!=";":
            currentAttr=currentAttr+";"
        if len(currentAttr) and currentAttr[-1]!=" " and len(chto) and chto[0]!=" ":
            currentAttr = currentAttr+" "
        rez = currentAttr+chto

    if setAttr:
        namee=nodeAttr.split(".")[0]
        attr=nodeAttr.split(".")[1]
        typeAttr=cmds.attributeQuery(attr,n=namee,at=True)
        if typeAttr=="typed":
            cmds.setAttr(namee+"."+attr,rez,type="string")
        elif typeAttr=="compound":
            print "COMPOUND: "+str(cmds.attributeQuery(attr,n=namee,listChildren=True))
            #print "COMPOUND: "+str(cmds.attributeQuery(attr,n=namee,numberOfChildren=True))
        else:
            checkValue=""
            expression = re.compile("^[0-9\,\.]*", re.IGNORECASE)
            m = expression.search(rez)
            if m:
                checkValue=m.group(0)
                if checkValue:
                    cmds.setAttr(namee+"."+attr,float(checkValue))
        #cmds.setAttr(nodeAttr,rez,type="string")
    return rez


def pathToPreset( filename="" ):
    """
    Get path to preset by scene or filename.
    """
    import json
    import os
    import re
    import maya.cmds as cmds
    path = ""
    if filename == "":
        filename = cmds.file( query=True, sceneName=True )
    if filename != "":
        name = filename.split( "/" )[-1]
        cname = "".join(re.split( "_v[0-9]+", name ))
        directory = name.join( filename.split( name )[:-1] )  
        path = os.path.join( directory, cname.split( "." )[0] + ".js" )
        buffer_dir = directory.split( "/" )
        if re.findall( "(/|)[Ww][Oo][Rr][Kk](/|)", buffer_dir[-2] ):
            path = os.path.join( "/".join( buffer_dir[:-2] ) + "/", cname.split( "." )[0] + ".js" )
        else: 
            path = os.path.join( directory, cname.split( "." )[0] + ".js" )
        if not os.path.isfile( path ):
            jsfile = file( path, "w" )
            json.dump( [], jsfile, indent=4, ensure_ascii=False )
            jsfile.close()
    else:
        print "\nScene is not saved!!!"
        return None
    return path
    
def loadReferencePreset( name ):
    """
    Load references for current scene by preset.
    """
    import maya.cmds as cmds
    path = cmds.file( query=True, sceneName=True )
    preset = pathToPreset( filename=path )
    presets = listPresets( filename=preset, presetType="referencePreset" )
    if name in presets:
        data = getPresetData( filename=preset, name=name, presetType="referencePreset" )
        rdata = buildReferencePresetData( data=data, level="" )
        loadReferences( rfn="", rfns=rdata, unloadUnused=True )   

def nodeIterator( references=[], attributes=[], namespaces=[], canBeSaved=False, canNotSaved=False, ni=False, hasNotUniqueName=False, referenced=False, imported=False, default=False, nonDefault=False, locked=False, nonLocked=False, shared=False, notShared=False, dag=False, dg=False, types=[], fullPath=False, returnMFnDependencyNode=False, returnMObject=False ):
    """
    terate maya nodes.
    referenced - only nodes from referenced file. 
    imported - only nodes from current scene. 
    default - only not deletable default nodes.
    nonDefault - only deletable nodes.
    locked - only locked nodes.
    nonLocked - only not locked nodes.
    shared - only shared nodes 
    notShared - only not shared nodes.
    dag - only dag nodes.
    dg - only dg nodes.
    type - only nodes by specified type.
    fullPath - return full path dag names.
    returnMFnDependencyNode - return MFnDependencyNode pointer.
    returnMObject - return MObject pointer.
    hasNotUniqueName - only nodes with not unique names. 
    canNotSaved - only can not be saved to file or exported nodes.
    canBeSaved - only can be saved to file or exported nodes.
    namespaces - only nodes with specified parent namespace.
    attributes - only nodes with specified attributes.
    ni - only not itermediate nodes.
    """
    import maya.OpenMaya as om
    import maya.cmds as cmds
    iterator = om.MItDependencyNodes()
    while not iterator.isDone():
        boolean = False
        isDag = False
        mObject = iterator.thisNode()
        node = om.MFnDependencyNode( mObject )
        if canBeSaved is False and canNotSaved is False or canBeSaved is True and canNotSaved is True or canBeSaved is False and canNotSaved is True and not node.canBeWritten() or canBeSaved is True and canNotSaved is False and node.canBeWritten():
            if referenced is True and imported is False or referenced is False and imported is True or references:
                isReferencedNode = node.isFromReferencedFile()
            if referenced is False and imported is False or referenced is True and imported is True or referenced is False and imported is True and not isReferencedNode or referenced is True and imported is False and isReferencedNode:
                if hasNotUniqueName is True and not node.hasUniqueName() or hasNotUniqueName is False:
                    if attributes:
                        attributes = type( attributes ) is list and attributes or [ attributes ]
                    if attributes and True in [ node.hasAttribute( attribute ) for attribute in attributes ] or not attributes:
                        if namespaces and node.parentNamespace() in namespaces or not namespaces:
                            if default is False and nonDefault is False or default is True and nonDefault is True or default is True and nonDefault is False and node.isDefaultNode() or default is False and nonDefault is True and not node.isDefaultNode():
                                if locked is False and nonLocked is False or locked is True and nonLocked is True or locked is True and nonLocked is False and node.isLocked() or locked is False and nonLocked is True and not node.isLocked():
                                    if shared is False and notShared is False or shared is True and notShared is True or shared is True and notShared is False and node.isShared() or shared is False and notShared is True and not node.isShared():
                                        isDag = mObject.hasFn( om.MFn.kDagNode )
                                        if dag is False and dg is False or dag is True and dg is True or dag is True and dg is False and isDag is True or dag is False and dg is True and isDag is False:
                                            if isDag is True and ni is True:
                                                dagPath = om.MDagPath.getAPathTo( mObject )
                                                dagNode = om.MFnDagNode( dagPath )
                                            if isDag is True and ni is True and not dagNode.isIntermediateObject() or ni is False:
                                                if references and isReferencedNode and cmds.referenceQuery( dagPath.fullPathName(), filename=True ) in references or not references:
                                                    nodeType = node.typeName()
                                                    if nodeType in types or not types:
                                                        boolean = True
        iterator.next()
        if boolean is True:
            if returnMFnDependencyNode is False and returnMObject is False:
                name = ""
                if isDag is False:
                    if dg is True:
                        name = node.name()
                else:
                    if dag is True:
                        dagPath = om.MDagPath.getAPathTo( mObject )
                        if fullPath is True:
                            name = dagPath.fullPathName()
                        else:
                            name = dagPath.partialPathName()
                if name != "":
                    yield name
            elif returnMFnDependencyNode is True:
                yield node
            elif returnMObject is True:
                yield mObject

def iterateNodesFromView( camera, reference=False, filename=False, start=0, end=0, frameSpacing=1, frustum=0, aspect=1 ):
    """
    camera - Camera shape name.
    reference - Iterate reference nodes.
    filename - Iterate reference filename.
    frustum - Camera frustum mode ( 0:Viewing, 1:Rendering, 2:Film )
    aspect - Aspect mode ( 0:Camera, 1:Device )
    start - Animation start time.
    end - Animation end time.
    frameSpacing - Skip every frame.
    """
    import maya.cmds as cmds
    import maya.OpenMaya as om
    if not cmds.nodeType( camera ) in [ "camera", "stereoRigCamera" ]:
        print "%s is not camera" % camera
    else:
        cache = []
        currentTime = int( cmds.currentTime( query=True ))
        if start != 0 and end != 0:
            animationRange = range( start, end )
            if frameSpacing > 1:
                animationRange = [ animationRange[f] for f in range( 0, len( animationRange )) if f % frameSpacing == 0 ]
        else:
            start = int( cmds.currentTime( query=True ))
            end = start + 1
            animationRange = range( start, end )
        selection= om.MSelectionList()
        dagPath= om.MDagPath()
        selection.add( camera )
        selection.getDagPath( 0, dagPath )
        cameraDag = om.MFnCamera( dagPath )
        if aspect == 1:
            renderGlobals = cmds.ls( renderGlobals=True )
            resolution = cmds.listConnections( "%s.resolution" % renderGlobals[0] )
            aspect = cmds.getAttr( "%s.deviceAspectRatio" % resolution[0] )
        else:
            aspect = cameraDag.aspectRatio()
        for f in animationRange:
            cmds.currentTime( f )
            focalLenght = cameraDag.focalLength()
            cameraIMatrix = dagPath.inclusiveMatrixInverse()
            nearClip = cameraDag.nearClippingPlane()
            farClip =  cameraDag.farClippingPlane()
            left = om.MScriptUtil()
            left.createFromDouble( 0.0 )
            leftPtr = left.asDoublePtr()
            right = om.MScriptUtil()
            right.createFromDouble( 0.0 )
            rightPtr = right.asDoublePtr()
            bottom = om.MScriptUtil()
            bottom.createFromDouble( 0.0 )
            bottomPtr = bottom.asDoublePtr()
            top = om.MScriptUtil()
            top.createFromDouble( 0.0 )
            topPtr = top.asDoublePtr()
            if frustum == 1:
                cameraDag.getRenderingFrustum( aspect, leftPtr, rightPtr, bottomPtr, topPtr )
            if frustum == 2:
                cameraDag.getFilmFrustum( focalLenght, leftPtr, rightPtr, bottomPtr, topPtr, True )
            else:
                cameraDag.getViewingFrustum( aspect, leftPtr, rightPtr, bottomPtr, topPtr, True, True, True )
            left = left.getDoubleArrayItem( leftPtr, 0 )
            right = right.getDoubleArrayItem( rightPtr, 0 )
            bottom = bottom.getDoubleArrayItem( bottomPtr, 0 )
            top = top.getDoubleArrayItem( topPtr, 0 )
            planes = []
            a = om.MVector( right, top, -nearClip )
            b = om.MVector( right, bottom, -nearClip )
            c = ( a ^ b ).normal()
            planes.append( [ c, 0.0 ] )
            a = om.MVector( left, bottom, -nearClip )
            b = om.MVector( left, top, -nearClip )
            c = ( a ^ b ).normal()
            planes.append( [ c, 0.0 ] )
            a = om.MVector( right, bottom, -nearClip )
            b = om.MVector( left, bottom, -nearClip )
            c = ( a ^ b ).normal()
            planes.append( [ c, 0.0 ] )
            a = om.MVector( left, top, -nearClip )
            b = om.MVector( right, top, -nearClip )
            c = ( a ^ b ).normal()
            planes.append( [ c, 0.0 ] )
            c = om.MVector(0, 0, 1)
            planes.append( [ c, farClip ] )
            c = om.MVector(0, 0, -1)
            planes.append( [ c, nearClip ] )
            iterator = om.MItDag()
            while not iterator.isDone():
                mObject = iterator.currentItem()
                dNode = om.MFnDependencyNode( mObject )
                dagNode = om.MDagPath()
                iterator.getPath( dagNode ) 
                node = iterator.fullPathName()
                iterator.next()
                if reference is True:
                    isReferenced = dNode.isFromReferencedFile()
                if reference is True and isReferenced is True or reference is False:
                    if cmds.objExists( node ):
                        if reference is True:
                            if filename is True:
                                target = cmds.referenceQuery( node, filename=True ) 
                            else:
                                target = cmds.referenceQuery( node, rfn=True )
                        else:
                            target = node
                        if target not in cache:
                            points = []
                            dagEMatrix = dagNode.exclusiveMatrix()
                            fnDag = om.MFnDagNode( dagNode )
                            bbox = fnDag.boundingBox()
                            bboxMin = bbox.min()
                            bboxMax = bbox.max()
                            points.append( bboxMin * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMax.x, bboxMin.y, bboxMin.z ) * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMax.x, bboxMin.y, bboxMax.z ) * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMin.x, bboxMin.y, bboxMax.z ) * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMin.x, bboxMax.y, bboxMin.z ) * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMax.x, bboxMax.y, bboxMin.z ) * dagEMatrix * cameraIMatrix )
                            points.append( bboxMax * dagEMatrix * cameraIMatrix )
                            points.append( om.MPoint( bboxMin.x, bboxMax.y, bboxMax.z ) * dagEMatrix * cameraIMatrix )
                            inside = 0
                            lenght = len( points )
                            boolean = True
                            for n in range( 0, 6 ):
                                behind = 0
                                if behind == lenght:
                                    boolean = False
                                    break
                                for p in range( 0, lenght ):
                                    vectorPoint = om.MVector( points[p].x, points[p].y, points[p].z )
                                    value = ( planes[n][0] * vectorPoint ) + planes[n][-1]
                                    if value < 0.0:
                                        behind += 1
                                    if behind == lenght:
                                        boolean = False
                                        break
                                    elif behind == 0 :
                                        inside += 1
                            if inside == 6 or boolean is True:
                                cache.append( target )
                                yield target
        cmds.currentTime( currentTime )
        
def notVisbibleReferences( camera, filename=False, start=0, end=0, frameSpacing=1, frustum=0, aspect=1 ):
    """
    List references not visible in camera.
    camera - Target camera.
    filename - List reference filenames, by default return reference nodes.
    frustum - Camera frustum mode ( 0:Viewing, 1:Rendering, 2:Film )
    aspect - Aspect mode ( 0:Camera, 1:Device )
    start - Animation start time.
    end - Animation end time.
    frameSpacing - Skip every frame.
    """
    import maya.cmds as cmds
    result = []
    visibleReferences = []
    visibleReferenceIterator = iterateNodesFromView( camera, reference=True, filename=False, start=start, end=end, frameSpacing=frameSpacing, frustum=frustum, aspect=aspect )
    for visibleReference in visibleReferenceIterator:
        parents = referenceParents( visibleReference, rfn=True )
        for parent in parents:
            visibleReferences.append( parent )
        visibleReferences.append( visibleReference )
    referenceIterator = listReferences( characters=False, onlyLoaded=True, rfn=True, fullHierarchy=True )
    for reference in referenceIterator:
        if reference not in visibleReferences:
            if filename is True:
                reference = cmds.referenceQuery( reference, filename=True )
            result.append( reference )
    return result
    
def referenceParents( reference, rfn=False ):
    """
    Return all reference parent filenames.
    """
    import maya.cmds as cmds
    result = []
    if rfn is False:
        parentRfn = cmds.referenceQuery( reference, parent=True, rfn=True )
        if parentRfn:
            parent = cmds.referenceQuery( parentRfn, filename=True )
        else:
            parent = []
    else:
        parent = cmds.referenceQuery( reference, parent=True, rfn=True )
    if parent:
        result.append( parent )
        parents = referenceParents( parent, rfn=rfn )
        for parent in parents:
            result.append( parent )
    return result

def getAssetFirstVersion(inputFile,type="render",findLastFileIfNotFinal=True,palevo=""):
    import MySQLdb as mb
    import re
    import os.path, time
    import datetime
    import glob

    print "INPUT FILE: "+inputFile

    if palevo!="":
        inputFile = findRenderVersion(inputFile,palevo) 
        print "PALEVNAYA VERSIA: "+inputFile

    def pathToNetwork(path):
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        path = expression.sub("//Server-3d/Project",path)
        return path
    
    fileAnimPathTemp=inputFile.split("/")[-1].split(".")[0].split("_")
    if re.match("v[0-9]{3,4}",fileAnimPathTemp[-1]):
        fileAnimPathTemp=fileAnimPathTemp[:-1]
    
    tempParts=""
    if len(fileAnimPathTemp)>1:
        expression = re.compile("(render)$|(proxy)$", re.IGNORECASE)
        fileAnimPathTemp[1]=expression.sub("",fileAnimPathTemp[1]) 
        if fileAnimPathTemp[1]:
            fileAnimPathTemp=fileAnimPathTemp[0]+"_"+fileAnimPathTemp[1]
        else:
            fileAnimPathTemp=fileAnimPathTemp[0]    
    else:
        fileAnimPathTemp=fileAnimPathTemp[0]


    if "_" in fileAnimPathTemp:
        fileAnimPathTemp=fileAnimPathTemp+type.capitalize()
    else:
        fileAnimPathTemp=fileAnimPathTemp+"_"+type
        
    inputFileTemp=inputFile
    if len(re.split("/assets/.*/maya/work/",inputFile))==1:
        inputFileTemp=re.split("/maya/",inputFile)
        if len(inputFileTemp)==1:
            return ""
        inputFileTemp=inputFileTemp[0]+"/maya/work/"+inputFileTemp[1]

    fileAnimForFindInit="/".join(inputFileTemp.split("/")[:-1])+"/"+fileAnimPathTemp
    fileAnimForFind=pathToNetwork(fileAnimForFindInit+"%")
    conn = mb.connect(host="192.168.0.7",user="root",passwd="12345",port=3306,db = "mel", use_unicode=True)
    conn.set_character_set("utf8")
    cursor = conn.cursor()
    d = datetime.datetime.fromtimestamp(os.path.getmtime(inputFile))
    
    cursor.execute("select path,fversion from edits where path like %s and fversion != \"NULL\" and date >= %s order by date",(fileAnimForFind,d))  #2012-09-05 11:48:32
    row = cursor.fetchall()
    conn.commit()                                    
    #for r in range(len(row)):
    #    print row[r]
    if len(row):
        print "FILE TO FIND: "+fileAnimForFind
        print "FINDED FILE: "+str(row[0][0])+" final version: "+str(row[0][1])
        return row[0][0]
    else:
        if findLastFileIfNotFinal:
            find=re.sub("/maya/work/", "/maya/", fileAnimForFindInit)
            filesss=glob.glob(find+".m[a|b]")
            if len(filesss):
                print "FILE TO FIND: "+fileAnimForFind
                print "FINDED ROOT FILE: "+str(filesss[0])
                return filesss[0]
            else:    
                cursor.execute("select path,fversion from edits where path like %s and date >= %s order by date desc",(fileAnimForFind,d))  #2012-09-05 11:48:32
                row = cursor.fetchall()
                conn.commit()                                    
                if len(row):
                    print "FILE TO FIND: "+fileAnimForFind
                    print "FINDED NEPONYATNYI FILE: "+str(row[0][0])
                    return row[0][0]
                else:
                    return inputFile




def uniqueTransforms( reference, hasMesh=False, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True, fullPath=False ):
    import maya.cmds as cmds
    result = []
    uniqueTransforms = []
    if hasMesh is True:
        parted = referenceIsParted( reference )
    else:
        parted = False
    nodes = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    if ignoreShapes is True:
        transforms = cmds.ls( nodes, dag=True, type="transform", long=True, ni=ni )
    else:
        transforms = cmds.ls( nodes, dag=True, long=True, ni=ni )
    for transform in transforms:
        unique = True
        if ignoreShapes is True:
            childs = cmds.ls( transform, dag=True, type="transform", long=True, ni=ni )
        else:
            childs = cmds.ls( transform, dag=True, ni=ni )
        if childs:
            for child in childs:
                if hasMesh is True and parted is True and cmds.ls( child, dag=True, type="mesh" ) or hasMesh is False:
                    if cmds.referenceQuery( child, isNodeReferenced=True ):
                        filename = cmds.referenceQuery( child, filename=True )
                        if reference != filename:
                            unique = False
                            break
                    else:
                        if ignoreDeformers is True:
                            history = cmds.listHistory( child )    
                            for part in history:
                                if cmds.referenceQuery( part, isNodeReferenced=True ):
                                    filename = cmds.referenceQuery( part, filename=True )
                                    if reference != filename:
                                        unique = False
                                        break
                            if unique is False:
                                break
                        else:
                            unique = False
                        if unique is False:
                            break
                else:
                    unique = False
                    break
        else:
            if empty is False:
                unique = False
        if unique is True:
            uniqueTransforms.append( transform )
    for uniqueTransform in uniqueTransforms:
        parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
        if fullPath is False:
            uniqueTransform = cmds.ls( uniqueTransform )
            if uniqueTransform:
                uniqueTransform = uniqueTransform[-1]
        if parent:
            parent = parent[0]
            if parent not in uniqueTransforms:
                result.append( uniqueTransform )
        else:
            result.append( uniqueTransform )
    return result
    
def listUniqueTransforms( references=[], hasMesh=False, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True, fullPath=False ):
    import maya.cmds as cmds
    import main
    result = {}
    uniqueTransforms = {}
    partedReferences = {}
    keys = []
    rkeys = []
    pkeys = []
    transforms = main.nodeIterator( references=references, attributes=[], namespaces=[], canBeSaved=False, ni=ni, canNotSaved=False, hasNotUniqueName=False, referenced=True, imported=False, default=False, nonDefault=False, locked=False, nonLocked=False, shared=False, notShared=False, dag=True, dg=False, types=[], fullPath=True, returnMFnDependencyNode=False, returnMObject=False )
    for transform in transforms:
        reference = cmds.referenceQuery( transform, filename=True )
        if hasMesh is True:
            if reference not in pkeys:
                pkeys.append( reference )
                partedReferences.update( { reference:referenceIsParted( reference ) } )
        else:
            partedReferences.update( { reference:False } )
        unique = True
        if ignoreShapes is True:
            childs = cmds.ls( transform, dag=True, ni=ni, type="transform" )
        else:
            childs = cmds.ls( transform, dag=True, ni=ni )
        if childs:
            for child in childs:
                if hasMesh is True and partedReferences[reference] is True and cmds.ls( child, dag=True, type="mesh" ) or hasMesh is False or partedReferences[reference] is False:
                    if cmds.referenceQuery( child, isNodeReferenced=True ):
                        filename = cmds.referenceQuery( child, filename=True )
                        if reference != filename:
                            unique = False
                            break
                    else:
                        if ignoreDeformers is True:
                            history = cmds.listHistory( child )    
                            for part in history:
                                if cmds.referenceQuery( part, isNodeReferenced=True ):
                                    filename = cmds.referenceQuery( part, filename=True )
                                    if reference != filename:
                                        unique = False
                                        break
                            if unique is False:
                                break
                        else:
                            unique = False
                        if unique is False:
                            break
                else:
                    unique = False
                    break
        else:
            if empty is False:
                unique = False
        if unique is True:
            if reference not in keys:
                keys.append( reference )
                uniqueTransforms.update( { reference:[ transform ] } )
            else:
                uniqueTransforms[ reference ].append( transform )
    for key in keys:
        for uniqueTransform in uniqueTransforms[key]:
            parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
            if fullPath is False:
                uniqueTransform = cmds.ls( uniqueTransform )
                if uniqueTransform:
                    uniqueTransform = uniqueTransform[-1]
            if parent:
                parent = parent[0]
                if parent not in uniqueTransforms[key]:
                    if key not in rkeys:
                        rkeys.append( key )
                        result.update( { key:[ uniqueTransform ] } )
                    else:
                        result[ key ].append( uniqueTransform )
            else:
                if key not in rkeys:
                    rkeys.append( key )
                    result.update( { key:[ uniqueTransform ] } )
                else:
                    result[ key ].append( uniqueTransform )
    return result     
    
def referenceIsParted( reference ):
    import maya.cmds as cmds
    assemblies = 0
    transforms = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    transforms = cmds.ls( transforms, type="transform", long=True )
    for transform in transforms:
        parent = cmds.listRelatives( transform, parent=True, fullPath=True )
        if parent:
            parent = parent[0]
            if parent not in transforms:
                if cmds.referenceQuery( parent, isNodeReferenced=True ):
                    filename = cmds.referenceQuery( parent, filename=True )
                    if filename != reference:
                        assemblies += 1
                else:
                    assemblies += 1
        else:
            assemblies += 1
    return ( assemblies > 1 )
    
    
    
    

