def mg_exportSound( input='', output='', bitrate=1536, codec='pcm_s16le', format='wav', executable='' ):
    '''
    Export sound from video file.
    -input = Path to video file.
    -output = Path to exported sound.
    -bitrate = Quality of exported sound.
    -codec = Codec name.
	-executable = Path to ffmpeg.exe.
	
	requirements:
	ffmpeg for windows.
	http://ffmpeg.zeranoe.com/builds/
    '''
    import subprocess
    import os
    mg_output = ''
    mg_ffmpeg = executable == '' and '//SERVER-3D/Project/lib/soft/ffmpeg/bin/ffmpeg.exe' or executable
    not os.path.isfile( mg_ffmpeg ) and cmds.error( 'Failed to find ffmpeg.' )
    mg_video = input != '' and input or cmds.error( 'Please specify path to video file.' )
    mg_sound = output != '' and output or cmds.error( 'Please specify path to sound file.' )
    os.path.isfile( mg_sound ) and os.remove( mg_sound )
    mg_command = [ mg_ffmpeg, '-i', mg_video, '-ab', ( str( bitrate ) + 'k' ), '-acodec', str( codec ), '-f', str( format ), mg_sound ]
    mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
    mg_output = '\n'.join( mg_process.communicate() )
    return mg_output