import site
import json
import codecs
import glob
import re
import main
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import maya.mel as mel
import maya.OpenMayaUI as mui
import sendToRender

def refnameTofname(x):
    return x.replace(".","_o_").replace("{","_p_").replace("}","_q_")

def fnameTorefname(x):
    return x.replace("_o_",".").replace("_p_","{").replace("_q_","}")
    
def fileExist(fileInput):
    try:
        cmds.file(fileInput,q=True,rfn=True)
        return True
    except:
        return False

def FindAlembicSceneFolder(root=False,gpu=False):
    sss=mel.eval("rman getvar RMSPROJ")+"cache/alembic/"
    gpuString=""
    if gpu:
        gpuString="_gpu"
    addString=mel.eval("rman getvar STAGE")+"_new"+gpuString
    if not root:
       sss+=addString
    if not os.path.exists(sss):
        os.makedirs(sss)
    return sss


def loadReferenceFunction(referenceFile, rez, expandProxy=True, loadUnloaded=False, expandChildProxy=True, loadUnloadedChild=False):
    isLoaded=1-int(cmds.file(referenceFile,q=True,dr=True))
    if not isLoaded and loadUnloaded:
        cmds.file(referenceFile,loadReference=True)
        rn = cmds.file(referenceFile, query=True, reference=True )
        for r in rn:
            rez.append(loadReferenceFunction(r,rez,expandChildProxy,loadUnloadedChild,False,False))
        isLoaded=1

    if isLoaded:
        refNode=cmds.file(referenceFile,q=True,rfn=True)
        currentProxyTag=cmds.getAttr(refNode+".proxyTag")
        if expandProxy and not not currentProxyTag and currentProxyTag != "" and currentProxyTag != "original":
                proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                if proxyMnger:
                    proxyMnger=proxyMnger[0]
                    listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                    for lP in listProxyes:
                        if cmds.getAttr(lP+".proxyTag") == "" or cmds.getAttr(lP+".proxyTag") == "original":
                            proxyActivateFunction(lP)
                            rn = cmds.file(cmds.referenceQuery(lP,f=True), query=True, reference=True )
                            rez.append(cmds.referenceQuery(lP,f=True))
                            for r in rn:
                                rez.append(loadReferenceFunction(r,rez,expandChildProxy,loadUnloadedChild,False,False))
        else:
            rez.append(referenceFile)


def proxyActivateFunction(rnNode):
    proxyManager=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True)
    if proxyManager:
        proxyManager=proxyManager.split(".")[0]
    else:    
        return
    artiveProxy=cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0].split(".")[-1]
    artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
    currnetProxy=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True).split(".")[-1]
    if artiveProxy != currnetProxy:
        cmds.disconnectAttr(proxyManager+".activeProxy",proxyManager+"."+artiveProxy)
        cmds.connectAttr(proxyManager+".activeProxy", proxyManager+"."+currnetProxy)
        filenameToUnload=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
        if filenameToUnload != "":
            if not cmds.file(filenameToUnload,q=True,dr=True):
                cmds.file(filenameToUnload,unloadReference=artiveRnNode)
    filenameToLoad=cmds.reference(rfn=rnNode,q=True,filename=True)
    if filenameToLoad != "":
        cmds.file(filenameToLoad,loadReference=rnNode)
            
    srcLstPlugs=cmds.listConnections(artiveRnNode+".associatedNode",source=True,connections=True,plugs=True)
    if srcLstPlugs:
        for i in range(0,len(srcLstPlugs),2):
                cmds.disconnectAttr(srcLstPlugs[i+1],srcLstPlugs[i])
                cmds.connectAttr(srcLstPlugs[i+1],rnNode+"."+srcLstPlugs[i].split(".")[-1])



def AEExportButtonFun(selectedFileslocal="allLoaded", gpuCache = False, cleanFolder=True, swithReferenceToOriginal=True, loadUnloaded=False, frameRange="timeSlider"):
    start = cmds.timerX()
    
    print "selectedFileslocal: "+str(selectedFileslocal)
    ### geometry change attributes start
    startFrame="1"
    endFrame="1"
    if len(frameRange.split(",")) > 1:
        startFrame=frameRange.split(",")[0]
        endFrame=frameRange.split(",")[1]
    elif frameRange == "renderSettings":
        startFrame = str(cmds.getAttr("defaultRenderGlobals.startFrame"))
        endFrame = str(cmds.getAttr("defaultRenderGlobals.endFrame"))
    elif frameRange == "timeSlider":
        startFrame = str(cmds.playbackOptions(query=True,animationStartTime=True))
        endFrame = str(cmds.playbackOptions(query=True,animationEndTime=True))

    for im in cmds.ls(type="mesh",ni=True):
        if not cmds.attributeQuery("SubDivisionMesh",node=im,ex=True):
            cmds.addAttr(im,ln="SubDivisionMesh",at="bool",defaultValue=not gpuCache)
        cmds.setAttr(im+".SubDivisionMesh",not gpuCache)
    ### geometry change attributes end
    print "AE(1/5): ITERATE GEO: "+str(cmds.timerX(startTime=start))

    filePath=FindAlembicSceneFolder(False,gpuCache)+"/"
    if len(selectedFileslocal.split(",")) == 1:
        if selectedFileslocal=="animation":
            selectedFileslocal=[]
            for i in main.animatedReferencedNodes(onlyFilename=True):
                selectedFileslocal.append(i)
        elif selectedFileslocal=="allLoaded":
            selectedFileslocal=[]
            for i in main.listReferences(onlyLoaded=True,fullHierarchy=True):
                selectedFileslocal.append(i)
            if cleanFolder:
                filesss = glob.glob(filePath+"*")
                for f in filesss:
                    os.remove(f)    
    else:
        temp=selectedFileslocal.split(",")
        selectedFileslocal=[]
        for t in temp:
            selectedFileslocal.append(t) 


    selectedFiles=[]
    for sF in range(len(selectedFileslocal)):
        loadReferenceFunction(selectedFileslocal[sF],selectedFiles,swithReferenceToOriginal,loadUnloaded,True,False)

    print "AE(2/5): RELOAD PROXYES: "+str(cmds.timerX(startTime=start))
    
    ReferencesFilesAndNodes=main.listUniqueTransforms( selectedFiles, hasMesh=True, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True )

    dataFileABCRefs={}
    sceneName=cmds.file(q=True,sn=True)


    for sF in ReferencesFilesAndNodes:

        preloadTree=[]
        temp=sF
        while cmds.referenceQuery(temp,f=True,p=True):
            temp=cmds.referenceQuery(temp,f=True,p=True)
            if temp == sceneName:
                break
            preloadTree.insert(0,temp)


        dataFileABCRefs[sF]={ "abcFiles":[], "namespace": cmds.referenceQuery(sF,ns=True), "parents": preloadTree }


        def hideParent(ttt):
            ttt = cmds.ls(ttt,l=True)[0]
            temp=ttt.split("|")
            if len(temp)>1:
                for ifg in reversed(range(2,len(temp))):
                    tmp = "|".join(temp[:ifg])
                    if not cmds.getAttr(tmp+".visibility"):    
                        print "HIDED PARENT FOLDER: "+tmp
                        if not cmds.attributeQuery("ml_visibility",node=ttt,ex=True):
                            cmds.addAttr(ttt,ln="ml_visibility",at="bool",defaultValue=True)
                        cmds.setAttr(ttt+".ml_visibility",cmds.getAttr(ttt+".visibility"))
                        cmds.setAttr(ttt+".visibility",False)
                        break


        palenayaVersia=""
        for slovo in ReferencesFilesAndNodes[sF]:
            listFiles=cmds.ls(slovo,dag=True)
            net=1
            for i in listFiles:
                if i.endswith("geometry_grp") and sF == cmds.referenceQuery(i,filename=True):
                    hideParent(i)
                    dataFileABCRefs[sF]["abcFiles"].append(i)
                    net=0
                elif i.endswith("geo_normal") and sF == cmds.referenceQuery(i,filename=True):
                    hideParent(i)
                    dataFileABCRefs[sF]["abcFiles"].append(i)
                    net=0
                elif i.endswith("switch_CT") and sF == cmds.referenceQuery(i,filename=True):
                    if cmds.ls(i+".position_modify"):
                        palenayaVersia = cmds.getAttr(i+".position_modify", asString=True)     
                    elif cmds.ls(i+".clothType"):
                        palenayaVersia = cmds.getAttr(i+".clothType", asString=True)
                    elif cmds.ls(i+".type_"):
                        palenayaVersia = cmds.getAttr(i+".type_", asString=True)

            if net:
                hideParent(i)
                dataFileABCRefs[sF]["abcFiles"].append(slovo)


        replacePers=main.getAssetFirstVersion(re.sub("\{[0-9]*\}","",sF),palevo=palenayaVersia)
        dataFileABCRefs[sF]["replaceReferenceVersion"]=replacePers


    print "AE(3/5) CATCH DATA: "+str(cmds.timerX(startTime=start))
    
    stringToAlembic=""
    alParametrsInput="-attr doubleSided -attr visibility -attrPrefix rman -uvWrite"
    if gpuCache:
        alParametrsInput="-ro"

    for lO in dataFileABCRefs:
        alParametrs=alParametrsInput
        abcFiles=""
        for af in dataFileABCRefs[lO]["abcFiles"]:
            abcFiles+=" -root "+af
        if dataFileABCRefs[lO]["replaceReferenceVersion"]!="" and not gpuCache:
            alParametrs=""
        stringToAlembic+=" -j \"-frameRange "+startFrame+" "+endFrame+" -worldSpace -dataFormat ogawa -writeVisibility -noNormals "+alParametrs+" "+abcFiles+" -file "+FindAlembicSceneFolder(False,gpuCache)+"/"+refnameTofname(lO.split("/")[-1])+".abc"+"\""    
        
    mel.eval("AbcExport -verbose "+stringToAlembic)

    print "AE(4/5): EXEC EXPORT: "+str(cmds.timerX(startTime=start))

    
    for dFAR in dataFileABCRefs:
        data={}
         
        if not gpuCache:
            data["namespaces"]=cmds.namespaceInfo(dataFileABCRefs[dFAR]["namespace"],lon=True,r=True,an=True)
         
            nodeNameExport={}
            listNodes=cmds.referenceQuery(dFAR,n=True,dp=True)
            for mP in cmds.ls(listNodes,type="partition"):
                nodeNameExport[mP]={}
                nodeNameExport[mP]["type"]=cmds.objectType(mP)
                nodeNameExport[mP]["attributes"]={}
                if cmds.attributeQuery("slimData",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".slimData")
                    nodeNameExport[mP]["attributes"]["slimData"]={}
                    nodeNameExport[mP]["attributes"]["slimData"]["type"]=cmds.getAttr(mP+".slimData",typ=True)
                    if not temp:
                        temp=""
                    nodeNameExport[mP]["attributes"]["slimData"]["value"]=str(temp.encode("utf-8"))
                if cmds.attributeQuery("slimRIB",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".slimRIB")
                    nodeNameExport[mP]["attributes"]["slimRIB"]={}
                    nodeNameExport[mP]["attributes"]["slimRIB"]["type"]=cmds.getAttr(mP+".slimRIB",typ=True)
                    if not temp:
                        temp=""
                    nodeNameExport[mP]["attributes"]["slimRIB"]["value"]=str(temp.encode("utf-8"))
                '''if cmds.attributeQuery("rlfData",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".rlfData")
                    nodeNameExport[mP]["attributes"]["rlfData"]={}
                    nodeNameExport[mP]["attributes"]["rlfData"]["type"]=cmds.getAttr(mP+".rlfData",typ=True)
                    if not temp:
                        temp=""
                    nodeNameExport[mP]["attributes"]["rlfData"]["value"]=str(temp.encode("utf-8"))
                '''

            data["nodes"]=nodeNameExport
         
         
        data["file"]=dFAR
        data["refsToFiles"]=dataFileABCRefs[dFAR]["abcFiles"]
        data["namespace"]=dataFileABCRefs[dFAR]["namespace"]
        data["parents"]=dataFileABCRefs[dFAR]["parents"]
        data["replaceReferenceVersion"]=dataFileABCRefs[dFAR]["replaceReferenceVersion"]

        
        m_file = file(filePath+refnameTofname(dFAR.split("/")[-1])+".js", "w" )
        json.dump( data, m_file, indent=4, ensure_ascii=False )
        m_file.close()

    dataMainSettings={}
    dataMainSettings["timeRange"]=[startFrame,endFrame]
    m_file = file(filePath+"/settings.js", "w" )
    json.dump( dataMainSettings, m_file, indent=4, ensure_ascii=False )
    m_file.close()
    print "AE(5/5): SAVE DATA: "+str(cmds.timerX(startTime=start))

