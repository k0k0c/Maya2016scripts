'''
import copyRibs
reload(copyRibs)
copyRibs.copyRibs()

'''

import maya.cmds as cmds
import maya.mel as mel
import os
import shutil
import re
import sys
#import distutils.core

OSTYPERS = sys.platform
if OSTYPERS == "win32":
        OSTYPERS="//renderServer/Project"
else:
        OSTYPERS="/renderServer/Project"

OSTYPE3D = sys.platform
if OSTYPE3D == "win32":
        OSTYPE3D="//Server-3d/Project/"
else:
        OSTYPE3D="/Server-3d/Project/"
           
def listSceneRibs():
    result = []
    ribs = cmds.ls( type='RenderManArchive' )
    for i in range( 0, len( ribs ) ):
        path = cmds.getAttr( ribs[i] + '.filename' )
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        if expression.match( path ) is None:
            path = OSTYPE3D + path
        if os.path.isfile( path ):
            if path not in result:
                result.append( path )
    return result

def copyRibs():

    paths = listSceneRibs()
    for i in range( 0, len( paths ) ):
        shaderDir = paths[i].split('.')[0]
        expression = re.compile( '^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)', re.IGNORECASE )
        root = expression.sub( OSTYPERS, shaderDir )        
        root = '/'.join(( root ).split( '/' )[:-1] ) + '/'
        newRibFile = root + '/' + (paths[i].split('/')[-1])
        newShaderDir = root + (shaderDir).split('/')[-1]
        print '\n\tROOT DIRECTORY: %s' % ( root )
        if os.path.isdir( root ) is False:
            print '\tMAKE ROOT : %s' % ( ( root ) )
            os.makedirs( root )
        if os.path.isfile( paths[i] ):
            if os.path.isfile( newRibFile ):
                if os.path.getmtime( paths[i] ) > os.path.getmtime( newRibFile ):
                    print '\tCOPY : %s to %s' % ( paths[i], root )
                    shutil.copy( paths[i], root )
                else:
                    print '\tPASS : %s to %s' % ( paths[i], root )
            else:
                print '\tCOPY : %s to %s' % ( paths[i], root )
                shutil.copy( paths[i], root )
        if os.path.isdir( shaderDir ):
            if os.path.isdir( newShaderDir ):
                srcFiles = os.listdir( shaderDir )
                dstFiles = os.listdir( newShaderDir )
                srcDate = 0
                dstDate = 0
                for n in range( 0, len( srcFiles )):
                    srcDate += int((os.stat( shaderDir + '/' + srcFiles[n] )).st_mtime)
                for n in range( 0, len( dstFiles )):
                    dstDate += int((os.stat( newShaderDir + '/' + dstFiles[n] )).st_mtime)
                if srcDate > dstDate or len( srcFiles ) > len( dstFiles ):
                    print '\tREMOVE : %s' % ( newShaderDir )
                    shutil.rmtree( newShaderDir )
                    print '\tCOPY : %s to %s' % ( shaderDir, newShaderDir + '/' )
                    shutil.copytree( shaderDir, (newShaderDir + '/') )
                else:
                    print '\tPASS : %s to %s' % ( shaderDir, newShaderDir + '/' )
            else:	
                print '\tCOPY : %s to %s' % ( shaderDir, newShaderDir + '/' )
                shutil.copytree( shaderDir, (newShaderDir + '/') )
            #distutils.dir_util.copy_tree( os.path.join(shaderDir), os.path.join(root + shaderDirTemp) )
            