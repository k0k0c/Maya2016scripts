import maya.cmds as cmds
import maya.mel as mel
import re
import advslim
import maya.OpenMaya as om

def checkUnusedNodes( nodes=[], query=True ):
    result = []
    if not nodes:
        nodes = cmds.ls( type=[ "objectTypeFilter", "objectNameFilter", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter", "RenderMan" ], long=True )
        for i in range( 0, len( nodes )):
            if re.findall( "[0-9]", nodes[i] ):
                if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                    result.append( "%s is not used nodes" % nodes[i] )
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " is not used nodes" )[0]
            if cmds.objExists( node ):
                cmds.delete( node )
    return result

def checkTransformTranslations( nodes=[], query=True ):
    result = []
    if not nodes:
        if cmds.ls( "|root", assemblies=True ):
            nodes = cmds.ls( "|root", dag=True, type="transform", long=True )
            for i in range( 0, len( nodes )):
                if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                    if cmds.ls( nodes[i], dag=True, type="mesh" ) and not cmds.ls( nodes[i], dag=True, type="nurbsCurve" ):
                        translate = cmds.getAttr( "%s.t" % nodes[i] )[0]
                        if ( round( translate[0], 2 ) != 0.0 or round( translate[1], 2 ) != 0.0 or round( translate[-1], 2 ) != 0.0 ):
                            boolean = True
                            dag = cmds.ls( nodes[i], dag=True )
                            if cmds.listConnections( dag, type="blendShape" ):
                                boolean = False
                                continue
                            if cmds.listConnections( dag, type="skinCluster" ):
                                boolean = False
                                continue
                            if cmds.listConnections( dag, type="transform" ):
                                boolean = False
                                continue 
                            childs = cmds.ls( nodes[i], dag=True, type="transform", long=True )
                            for c in range( 0, len( childs )):
                                if boolean is False:
                                    break
                                attributes = [ "%s.t" % childs[c], "%s.tx" % childs[c], "%s.ty" % childs[c], "%s.tz" % childs[c], "%s.t" % childs[c] ]
                                for a in range( 0, len( attributes )):
                                    if cmds.getAttr( attributes[a], lock=True ) or cmds.listConnections( attributes[a] ):
                                        boolean = False
                                        break    
                            if boolean is True:
                                result.append( "%s is not freezed transform" % nodes[i] )
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " is not freezed transform" )[0]
            if cmds.objExists( node ):
                cmds.makeIdentity( node, translate=True, apply=True )
    return result

def checkSlimAttachements():
    avalaible = advslim.listSlimID()
    result = []
    nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ], long=True )
    for n in range( 0, len( nodes )):
        value = advslim.getMayaID( nodes[n], ensemble=True )
        if value:
            for v in range( 0, len( value )):
                if nodes[n] not in result:
                    if cmds.nodeType( nodes[n] ) in [ "transform", "mesh" ]: 
                        if value[v] not in avalaible:
                            result.append( "%s has attached to not existing id" % nodes[n] )
                    else:
                        if value[v] not in avalaible:
                            result.append( "%s is not valid and has attached to not existing id" % nodes[n] )
                        else:
                            result.append( "%s is not valid" % nodes[n] )
    return result

def checkNonManifoldMeshes():
    result = []
    nodes = cmds.ls( type=[ "mesh", "nurbsCurve" ] )
    for i in range( 0, len( nodes )):
        if cmds.nodeType( nodes[i] ) == "mesh":
            if cmds.polyEvaluate( nodes[i], vertex=True ) >= 2:
                m_component = cmds.ls( cmds.polyInfo( nodes[i], laminaFaces=True, nonManifoldEdges=True, nonManifoldVertices=True ), fl=True, long=True )
                if m_component:
                    result = result + m_component
            else:
                result.append( "%s has non-manifold geometry" % nodes[i] )
        else:
            if cmds.attributeQuery( "spans", n=nodes[i], exists=True ) and cmds.getAttr( "%s.spans" % nodes[i] ) < 2 and nodes[i] not in result:
                result.append( "%s has non-manifold spans" % nodes[i] )
    return result

def checkNonManifoldVertex( geometry=[], ignoreSkinned=True, query=False ):
    result = []
    geometry = geometry and ( type( geometry ) is list and geometry or [ geometry ]) or cmds.ls( dag=True, type="mesh", long=True )
    for i in range( 0, len( geometry )):
        selectionList = om.MSelectionList()
        selectionList.add( geometry[i] )
        dagPath = om.MDagPath()
        selectionList.getDagPath(0, dagPath )
        iterator = om.MItMeshVertex( dagPath )
        skinned = ""
        while not iterator.isDone():
            array = om.MIntArray()
            iterator.getConnectedEdges( array )
            vtx = iterator.index()
            if array.length() < 1:
                if ignoreSkinned is True and skinned == "":
                    history = cmds.listHistory( geometry[i] )
                    for h in range( 0, len( history )):
                        if cmds.nodeType( history[h] ) == "skinCluster":
                            skinned = True
                            break
                if skinned is False and ignoreSkinned is True or ignoreSkinned is False: 
                    result.append( "%s.vtx[%s] is not manifold vertex" % ( geometry[i], vtx ))
            iterator.next()
    if query is False:
        if result:
            for i in range( 0, len( result )):
                node = result[i].split( " is not manifold vertex" )[0]
                cmds.polyDelVertex( node, constructionHistory=False )
    return result

def checkNonManifoldNormals( nodes=[], query=False ):
    result = []
    if not nodes:
        nodes = cmds.ls( dag=True, type="mesh", ni=True, long=True )
        for i in range( 0, len( nodes )):
            if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                components = cmds.polyInfo( nodes[i], nonManifoldVertices=True )
                if components:
                    components = cmds.ls( components, fl=True, long=True )
                    for n in range( 0, len( components )):
                        if len( cmds.ls( cmds.polyListComponentConversion( components[n], fromVertex=True, toEdge=True ), fl=True, long=True )) == len( cmds.ls( cmds.polyListComponentConversion( components[n], fromVertex=True, toFace=True ), fl=True, long=True )) and nodes[i] not in result: 
                            result.append( "%s has non-manifold normals" % nodes[i] )
                            break
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " has non-manifold normals" )[0]
            if cmds.objExists( node ) and not cmds.referenceQuery( node, isNodeReferenced=True ):
                cmds.polyNormal( node, normalMode=2, userNormalMode=1 )
    return result

def checkAttributes( nodes=[], query=False ):
    result = []
    renderman = cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True )
    if not nodes:
        nodes = nodes and ( type( nodes ) is list and nodes or [ nodes ] ) or cmds.ls( type=[ "transform", "mesh", "nurbsCurve" ], long=True, ni=True )
        for i in range( 0, len( nodes )):
            info = ""
            if cmds.nodeType( nodes[i] ) == "mesh":
                if renderman:
                    name = "%s.rman__torattr___subdivScheme" % nodes[i] 
                    if not cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ):
                        info = info + " -add rman__torattr___subdivScheme;"
                    name = "%s.rman__torattr___invis" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___invis;"
                name = "%s.castsShadows" % nodes[i]
                if cmds.attributeQuery( "castsShadows", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set castsShadows -int 1;"
                name = "%s.receiveShadows" % nodes[i]
                if cmds.attributeQuery( "receiveShadows", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set receiveShadows -int 1;"
                name = "%s.primaryVisibility" % nodes[i]
                if cmds.attributeQuery( "primaryVisibility", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set primaryVisibility -int 1;"
                name = "%s.motionBlur" % nodes[i]
                if cmds.attributeQuery( "motionBlur", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set motionBlur -int 1;"
                name = "%s.visibleInReflections" % nodes[i]
                if cmds.attributeQuery( "visibleInReflections", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set visibleInReflections -int 1;"
                name = "%s.visibleInRefractions" % nodes[i]
                if cmds.attributeQuery( "visibleInRefractions", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set visibleInRefractions -int 1;"
                name = "%s.doubleSided" % nodes[i]
                if cmds.attributeQuery( "doubleSided", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set doubleSided -int 0;"
                name = "%s.opposite" % nodes[i]
                if cmds.attributeQuery( "opposite", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set opposite -int 0;"
                name = "%s.displaySmoothMesh" % nodes[i]
                if cmds.attributeQuery( "displaySmoothMesh", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set displaySmoothMesh -int 0;"
                name = "%s.smoothShading" % nodes[i]
                if cmds.attributeQuery( "smoothShading", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set smoothShading -int 1;"
            elif cmds.nodeType( nodes[i] ) == "transform":
                if renderman:
                    name = "%s.rman__torattr___invis" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___invis;"
                    name = "%s.rman__torattr___subdivScheme" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___subdivScheme;"
            elif cmds.nodeType( nodes[i] ) == "nurbsCurve":
                if renderman:
                    name = "%s.rman__torattr___invis" % nodes[i]
                    if not cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ):
                        info = info + " -add rman__torattr___invis;"
                    name = "%s.rman__torattr___subdivScheme" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___subdivScheme;"
                    name = "%s.rman__torattr___slimShader" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimShader", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimShader;"
                    name = "%s.rman__torattr___slimSurface" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimSurface", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimSurface;"
                    name = "%s.rman__torattr___slimEnsemble" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimEnsemble;"
            if renderman:
                name = "%s.rman__torattr___slimEnsemble" % nodes[i]
                if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimEnsemble;"
                name = "%s.rman__torattr___slimShader" % nodes[i]
                if cmds.attributeQuery( "rman__torattr___slimShader", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimShader;"
                name = "%s.rman__torattr___slimSurface" % nodes[i]        
                if cmds.attributeQuery( "rman__torattr___slimSurface", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimSurface;"
                name = "%s.rman__torattr___slimEnsemble" % nodes[i]        
                if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimEnsemble;"
                name = "%s.rman__torattr___postShapeScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___postShapeScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___postShapeScript;"
                name = "%s.rman__torattr___postTransformScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___postTransformScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___postTransformScript;"
                name = "%s.rman__torattr___preShapeScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___preShapeScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___preShapeScript;"
                name = "%s.rman__torattr___transformBeginScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___transformBeginScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___transformBeginScript;"
                name = "%s.rman__torattr___transformEndScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___transformEndScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___transformEndScript;"
            if info:
                result.append( "%s%s" % ( nodes[i], info ))
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " " )[0]
            args = result[i].split( "%s " % node )[-1]
            args = args.split( ";" )
            if cmds.objExists( node ) and not cmds.referenceQuery( node, isNodeReferenced=True ):
                for n in range( 0, len( args )):
                    if "-remove" in args[n]:
                        target = args[n].split( "-remove " )[-1]
                        if cmds.attributeQuery( target, n=node, exists=True ):
                            cmds.deleteAttr( "%s.%s" % ( node, target ) )
                    if "-add" in args[n]:
                        target = args[n].split( "-add " )[-1]
                        mel.eval( "rmanAddAttr( \"%s\", \"%s\", \"\" )" % ( node, target ))
                    if "-set" in args[n]:
                        target = ( args[n].split( "-set " )[-1] ).split( " -" )[0]
                        if "-int" in args[n]:
                            value = int( args[n].split( "-int " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value )
                        elif "-float" in args[n]:
                            value = float( args[n].split( "-float " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value )
                        elif "-str" in args[n]:
                            value = str( args[n].split( "-str " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value, type="string" )
    return result