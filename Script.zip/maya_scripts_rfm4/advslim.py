import maya.cmds as cmds
import maya.mel as mel
import rfm.slim
import time
import re
import os

def listMayaID( selected=False, ensemble=False ):
    """
    List all slim binding id attached in current scene.
    """
    result = []
    if selected is False:
        nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    else:
        nodes = cmds.ls( sl=True, dag=True, type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    for n in range( 0, len( nodes )):
        value = getMayaID( nodes[n], ensemble=ensemble )
        if value:
            for v in range( 0, len( value )):
                if value[v] not in result:
                    result.append( value[v] )
    return result

def replaceID( src, dst, selected=False ):
    """
    Replace attachment id for all maya nodes.
    """
    result = []
    if selected is False:
        nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    else:
        nodes = cmds.ls( sl=True, dag=True, type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    for n in range( 0, len( nodes )):
        value = setMayaID( nodes[n], src, dst )
        if value:
            for v in range( 0, len( value )):
                if value[v] not in result:
                    result.append( value[v] )
    return result

def unpackEnsemble( id, selected=False ):
    """
    Unpack slim material ensemble and attach all shaders and co-shaders to attached nodes.  
    """
    result = []
    if selected is False:
        nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    else:
        nodes = cmds.ls( sl=True, dag=True, type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    materials = ensembleAttachaments( id, returnId=True )
    if materials:
        for n in range( 0, len( nodes )):
            if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[n], exists=True ):
                value = cmds.getAttr( "%s.rman__torattr___slimEnsemble" % nodes[n] )
                if value == id:    
                    attribute = "%s.rman__torattr___slimSurface" % ( nodes[n] )
                    if not cmds.attributeQuery( "rman__torattr___slimSurface", n=nodes[n], exists=True ):
                        cmds.addAttr( nodes[n], longName="rman__torattr___slimSurface", dataType="string" )
                    cmds.setAttr( attribute, materials[-1], type="string" )
                    attribute = "%s.rman__torattr___slimShader" % ( nodes[n] )
                    if not cmds.attributeQuery( "rman__torattr___slimShader", n=nodes[n], exists=True ):
                        cmds.addAttr( nodes[n], longName="rman__torattr___slimShader", dataType="string" )
                        string = ""
                    else:
                        string = cmds.getAttr( attribute )
                    string = string.split( "," ) + materials[:-1]
                    cache = []
                    [ cache.append( string[s] ) for s in range( 0, len( string )) if string[s] and string[s] not in cache ]
                    string = ",".join( cache )
                    cmds.setAttr( attribute, string, type="string" )
                    cmds.deleteAttr( "%s.rman__torattr___slimEnsemble" % nodes[n])
                    result.append( result )
    return result

def setMayaID( node, src, dst ):
    """
    Replace slim attachments for current maya node. 
    """
    result = []
    attributes = [ "rman__torattr___slimSurface", "rman__torattr___slimEnsemble", "rman__torattr___slimShader" ]
    for a in range( 0, len( attributes )):
        if cmds.attributeQuery( attributes[a], n=node, exists=True ):
            anode = "%s.%s" % ( node, attributes[a] )
            value = cmds.getAttr( anode )
            nvalue = value.replace( src, dst )
            if value != nvalue:
                cmds.setAttr( anode, nvalue, type="string" )
                result.append( anode )
    return result

def getMayaID( node, ensemble=False ):
    """
    Get slim binding id attached to current node.
    """
    result = []
    attributes = [ "rman__torattr___slimSurface", "rman__torattr___slimEnsemble", "rman__torattr___slimShader" ]
    for a in range( 0, len( attributes )):
        if cmds.attributeQuery( attributes[a], n=node, exists=True ):
            value = cmds.getAttr( "%s.%s" % ( node, attributes[a]  ))
            if value:
                value = value.split( "," )
                for v in range( 0, len( value )):
                    if attributes[a] == "rman__torattr___slimEnsemble" and ensemble is False:
                        value_ens = ensembleAttachaments( value[v], returnId=True )
                        for e in range( 0, len( value_ens )):
                            if value[v] not in result:
                                result.append( value_ens[e] )
                    else:
                        if value[v] not in result:
                            result.append( value[v] )
    return result

def findNode( id, ensemble=False ):
    """
    List all maya nodes attached to current slim binding id in current scene.
    """
    result = []
    nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ] )
    for n in range( 0, len( nodes )):
        value = getMayaID( nodes[n], ensemble=ensemble )
        if value:
            for v in range( 0, len( value )):
                if value[v] == id:
                    result.append( nodes[n] )
                    break
    return result

def ensembleAttachaments( id, returnId=False ):
    """
    List all slim nodes attached to current ensemble shader as surface and co-shaders.
    """
    result = []
    if returnId is False:
        value = sendToSlim( "set result {}; foreach node [[ slim GetAppearances -id %s ] GetConnectedFunctions ] { if { [ regexp CoShader|Surface [[ $node GetConnectionClients ] GetName ]] != 0 } { lappend result $node } }; set result $result" % id )
    else:
        value = sendToSlim( "set result {}; foreach node [[ slim GetAppearances -id %s ] GetConnectedFunctions ] { if { [ regexp CoShader|Surface [[ $node GetConnectionClients ] GetName ]] != 0 } { lappend result [ $node GetID ] } }; set result $result" % id )
    if value:
        result = value[0].split( " " )
    return result
    
def listAttachments( notAttached=False ):
    """
    List all can be attached shaders.
    """
    result = []
    value = sendToSlim( "set result {}; foreach node [ slim GetAppearances -type _Attachable ] { set palette [ $node GetParent ]; if { [ $palette GetAccessMode ] != \\\"ro\\\" } { lappend result [ $node GetID ] }}; set result $result" )
    if value:
        result = value[0].split( " " )
    if notAttached is True:
        id = listMayaID( selected=False, ensemble=True )
        result = [ part for part in result if part not in id ]
    return result

def removeMaterial( id ):
    """
    Remove material by id.
    """
    sendToSlim( "set node [ slim GetAppearances -id %s ]; if { $node != \\\"\\\" } { set palette [ $node GetParent ]; $node Delete 0; $palette DeleteDisconnected } update; slim CommitCmds" % id )
    return True
    
def removePalette( paletteObject ):
    """
    Remove palette.
    """
    sendToSlim( "%s Delete 0; update; slim CommitCmds" % paletteObject )
    return True
    
def unusedPalettes( returnName=False ):
    """
    List all unused in current scene palettes.
    """
    result = []
    materials = listAttachments( notAttached=True )
    palettes = listSlimPalettes( onlyEditable=True )
    if returnName is True:
        nameString = "regsub -all { } [ $node GetLabel ] \\\"\\\" name"
    else:
        nameString = "set name \\\"\\\""
    for palette in palettes:
        boolean = True
        id = sendToSlim( "set result {}; foreach node [ %s GetAppearances -type _Attachable ] { %s; lappend result [ concat [ $node GetID ],$name ] }; set result $result" % ( palette, nameString ) )
        if id:
            id = id[0].split( " " )
            for part in id:
                if part not in materials:
                    boolean = False
        if boolean is True:
            result.append( palette )
    return result
    
def selectSlimNode( id ):
    """
    Select slim material node in current opened slim session.
    """
    sendToSlim( "select_shader %s" % id )

def getSlimInfo( id, name=False ):
    """
    Get type for current slim node.
    """
    result = []
    namecmd = ""
    if name is True:
        namecmd = "|[ $node GetName ]"
    value = sendToSlim( "set node [ slim GetAppearances -id %s ]; set result [ concat [ [ $node GetTemplate ] GetName ]%s ]" % ( id, namecmd ))
    if value:
        result = value[0].split( " " )
    if result:
        result = result[-1]
    return result

def setSlimAttribute( id, attribute, value, byClass="::Slim::Parameter" ):
    """
    Set value for shader attribute from current opened slim session.
    """
    result = []
    value = sendToSlim( "set result {}; foreach parm [[ slim GetAppearances -id %s ] GetProperties -access input -class %s ] { if { [ regexp ^%s$ [ $parm GetName ]] != 0 } { lappend result $parm; $parm SetValue %s } }; set result $result" % ( id, byClass, attribute, value ))
    if value:
        result = value[0].split( " " )
    return result
    
def listSlimPalettes( onlyEditable=False ):
    """
    List all slim palettes.
    """
    result = []
    if onlyEditable is True:
         value = sendToSlim( "set result {};foreach palette [ slim GetPalettes ] { if { [ $palette GetAccessMode ] != \\\"ro\\\" } { lappend result $palette;foreach children [ $palette GetDescendents depthFirst ] { if { [ $children GetType ] == \\\"palette\\\" } { lappend result $children } } } };set result $result" )
    else:
        value = sendToSlim( "set result {};foreach palette [ slim GetPalettes ] { lappend result $palette;foreach children [ $palette GetDescendents depthFirst ] { if { [ $children GetType ] == \\\"palette\\\" } { lappend result $children } } };set result $result" )
    if value:
        result = value[0].split( " " )
    return result
    
def getProjectDir( directory="slimShaders" ):
    """
    Get full path to project directory.
    """
    result = []
    value = sendToSlim( "set workspace [ slim GetWorkspace ];set root [ $workspace GetRootDir ];set shaders [ $workspace GetDir %s ];set path [ concat $root$shaders ];set path [ $workspace GlobalizePath $path ]" % directory )
    if value:
        result = value[0].split( " " )
    return result

def listShaders( palettes=[], name=False, namespace=False, full=False ):
    """
    List all node in user specified palettes.
    """
    result = []
    array = "{%s}" % " ".join( palettes )
    getResultFunc = "lappend result $node"
    long = ""
    if full is True:
        long = "$node|"
    if name is True:
        getResultFunc = "set name [ $node GetName ];lappend result $name"
        if namespace is True:
            getResultFunc = "set name [ $node GetName ];set namespace [ $node GetNamespace ];set name [ concat %s$namespace$name ];lappend result $name" % long
    value = sendToSlim( "set result {}; set buffer %s; foreach palette $buffer { set nodes [ $palette GetAppearances ]; foreach node $nodes { %s } }; set result $result" % ( array, getResultFunc ))
    if value:
        result = value[0].split( " " )
    return result
    
def buildShaders( shaders=[] ):
    """
    Recompile user specified shaders.
    """
    directory = getProjectDir( directory="slimShaders" )
    shaders = "{%s}" % " ".join( shaders )
    sendToSlim( "set shaders %s; foreach shader $shaders { $shader BuildShader }" % shaders )
    return True
    
def getSlimAttribute( id, attribute, byClass="::Slim::Parameter" ):
    """
    Get value for shader attribute from current opened slim session.
    """
    result = []
    value = sendToSlim( "set result {}; foreach parm [[ slim GetAppearances -id %s ] GetProperties -access input -class %s ] { if { [ regexp ^%s$ [ $parm GetName ]] != 0 } { lappend result [ $parm GetValue ] } }; set result $result" % ( id, byClass, attribute ))
    if value:
        result = value[0].split( " " )
    return result

def listSlimID():
    """
    List all shader id from current opened slim session.
    """
    result = []
    value = sendToSlim( "set result {}; foreach node [ slim GetAppearances -type _Attachable ] { lappend result [ $node GetID ] }; set result $result" )
    if value:
        result = value[0].split( " " )
    return result

def isReferenced( id ):
    """
    Query reference statement for slim id.
    """
    result = []
    value = sendToSlim( "set node [[[ slim GetAppearances -id %s ] GetRoot ] GetAccessMode ]" % id )
    if value:
        result = value[-1]
    return result

def listSlimAttributes( id, name=False, value=False, type=False, byClass="::Slim::Parameter" ):
    """
    List shader attributes from current opened slim session.
    """
    result = []
    dop = []
    if name is True:
        dop.append( "|[ $parm GetName ]" )
    if value is True:
        dop.append( "|[ join [ $parm GetValue ] , ]" )
    if type is True:
        dop.append( "|[ $parm GetType ]" )
    if not dop:
        value = sendToSlim( "[ slim GetAppearances -id %s ] GetProperties -access input -class %s" % ( id, byClass ) )
    else:
        dop = "".join( dop )
        value = sendToSlim( "set result {}; foreach parm [[ slim GetAppearances -id %s ] GetProperties -access input -class %s ] { lappend result [ concat $parm%s] }; set result $result" % ( id, byClass, dop ))
    if value:
        result = value[0].split( " " )
    return result

def loadSlim( wait=1 ):
    """
    Load slim for current scene.
    """
    if cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ) is not True:
        cmds.loadPlugin( "RenderMan_for_Maya" )
    m_result = mel.eval( "rman slim isconnected" ) and True or False
    m_break = time.time() + ( 60 * wait )
    m_batch = cmds.about( b=True ) and " -gui 0 -edit 0" or ""
    if m_result is False:
        mel.eval( "rman slim start" + m_batch )
        while True:
            if mel.eval( "rman slim isconnected" ) and mel.eval( "rman slim command \"slim GetSlimStatus\"" ):
                m_result = True
                break
            if time.time() > m_break:
                break
    return m_result
    
def sendToSlim( command, message=False ):
    """
    Send command or message to slim.
    """
    if cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ) is not True:
        cmds.loadPlugin( "RenderMan_for_Maya" )
    result = []
    slim = rfm.slim.GetSlim()
    if not slim or not slim.Running():
        loadSlim()
    m_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
    for i in range( 0, len( m_command )):
        temp = ""
        if message is False:
            temp = slim.Cmd( '"' + m_command[i] + '"' )
        else:
            temp = slim.Msg( '"' + m_command[i] + '"' )
            wait = 0
            while True:
                wait = wait + 1
                if mel.eval( 'rman slim isconnected' ):
                    break
                elif wait > 1000000000:
                    break
        temp and result.append( temp )
    return result

def loadPlugins( plugins=[] ):
    """
    Load maya plugins for current scene. 
    """
    m_result = []
    m_plugins = type( plugins ) is list and plugins or [ plugins ]
    for i in range( 0, len( m_plugins )):
        if not cmds.pluginInfo( m_plugins[i], query=True, loaded=True ):
            m_result.append( m_plugins[i] )
            try:
                cmds.loadPlugin( m_plugins[i] )
            except:
                cmds.warning( 'Errors expected while initialize plugin: %s.' % str( m_plugins[i] ))
        rfm.passes.GetDefaultSettings()
        rfm.passes.GetGlobals()
    return m_result

def makeTransform( path ):
    """
    Make transform hierarchy.
    """
    result = []
    groups = path.split( "|" )
    for i in range( 0, len( groups )):
        if groups[i]:
            if not cmds.objExists( "|".join(groups[:i+1] )):
                if i == 0:
                    transform = cmds.createNode( "transform", name=groups[i] )
                    result.append( transform )
                else:
                    transform = cmds.createNode( "transform", name=groups[i], parent="|".join( groups[:i] ))
                    result.append( "|".join( result ) + "|" + transform )
    return result

def importSlimMaterial( id ):
    pass