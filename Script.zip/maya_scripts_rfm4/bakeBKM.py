def setupBake():
	import maya.cmds as cmds
	import maya.mel as mel
	import rfm.rlf2maya as rlf2maya
	import rfm.passes
	import os

	dude=cmds.ls(sl=True)
	if not cmds.objExists("bakeSet"):
		cmds.sets(name="bakeSet")
	cmds.sets(clear="bakeSet")
	if dude != []:
		cmds.sets(dude,add="bakeSet")

	RenderManVolume = cmds.ls("bakeVolumeShader")
	if RenderManVolume == []:
		RenderManVolume=cmds.shadingNode("RenderManVolume", asShader=True)
		RenderManVolume=cmds.rename(RenderManVolume,"bakeVolumeShader")
		cmds.setAttr(RenderManVolume+".shadername","/server-3d/Project/lib/shaders/testvol.slo", type="string")
		mel.eval("rman loadShader "+RenderManVolume+" \"/server-3d/Project/lib/shaders/testvol.slo\"");
		nodeSG = cmds.sets(renderable=True, noSurfaceShader=True, empty=True)
		nodeSG=cmds.rename(nodeSG,"bakeVolumeSG")
		mel.eval("rmanAddAttr(\""+nodeSG+"\",\"rman__torattr___defaultAtmosphereShader\",\"\")")
		cmds.connectAttr(RenderManVolume + ".message", nodeSG+".rman__torattr___defaultAtmosphereShader",f=True)
		#RenderManVolume=mel.eval("rmanCreateNode -asExtShader \"\" RenderManVolume")
		#attr=cmds.listConnections(RenderManVolume+'.outColor', d=True, s=False, p=True)
		#cmds.disconnectAttr(RenderManVolume+'.outColor', attr[0])
		#cmds.connectAttr(RenderManVolume+'.outColor', attr[0].split(".")[0]+'.volumeShader')
	else:
		RenderManVolume=RenderManVolume[0]


	bakelLght = cmds.ls("bakeLght")
	if bakelLght == []:
		bakelLght=cmds.shadingNode("RMSGIPtcLight",asLight=True)
		bakelLght=cmds.rename(bakelLght,"bakeLght")
	else:
		bakelLght=bakelLght[0]

	PassManager=rfm.passes.GetPassManager()
	RenderRadiosityPass = PassManager.GetPass("BakeRadiosityPass")
	if not RenderRadiosityPass:
		RenderRadiosityPass = PassManager.CreatePass("RenderRadiosity")
		RenderRadiosityPass.Rename("BakeRadiosityPass")
		SECONDARY_OUTPUTS = ["color Diffuse", "color DiffuseIndirect", "color DiffuseShadow", "color DiffuseShadow", "float Occlusion"]
		RenderRadiosityPass.AddChannel("color bakedColor")
		RenderRadiosityPass.AddChannel("color Os")
		display = RenderRadiosityPass.AddDisplay(SECONDARY_OUTPUTS)
		display.SetDspyID("BakeAOVs")
		if not cmds.isConnected("BakeRadiosityPass.message","bakeLght.GDMap"):
			cmds.connectAttr("BakeRadiosityPass.message","bakeLght.GDMap")
		cmds.setAttr("BakeRadiosityPass.rman__riattr___ShadingRate",1)
		cmds.setAttr("BakeRadiosityPass.rman__torattr___rayTracing",2)
		#RenderRadiosityPass = rfm.passes.GetPass("BakeRadiosityPass")
		#pathToBakeFile = RenderRadiosityPass.GetDisplayList()[1].GetOutputFile(fullpath=True)
		#pathToBakeFile = "/".join(pathToBakeFile.split("/")[:-2])
		REALROOTOFFILES=os.environ['HOME']+"/Project/tmp"
		if not os.path.exists(REALROOTOFFILES):
			os.makedirs(REALROOTOFFILES)
		cmds.setAttr(RenderManVolume+".filename",REALROOTOFFILES+"/bakeBKM.ptc", type="string")
		cmdString = "System \\\\\\\"\\\\\\\\\\\\\\\"${RMANTREE}/bin/brickmake\\\\\\\\\\\\\\\" -threads 8 -maxerror 0.001 -progress 2 -addpn 1 \\\\\\\\\\\\\\\"" + REALROOTOFFILES + "/bakeBKM.ptc\\\\\\\\\\\\\\\" \\\\\\\\\\\\\\\"" + REALROOTOFFILES + "/bakeBKM.bkm\\\\\\\\\\\\\\\"\\\\\\\"\\\\n"
		mel.eval("rmanAddAttr(\"BakeRadiosityPass\",\"rman__torattr___postRenderScript\",\"RiArchiveRecord(\\\"verbatim\\\",\\\"" + cmdString + "\\\");\")")

	Finals = rfm.passes.GetPasses("Final")
	for F in Finals:
		F.Disable()

	s = rlf2maya.GetActiveScope()
	dist=s.GetInjectionPayloads()
	delaem=1
	#attr=cmds.listConnections('bakeVolumeShader.message', d=True, s=False)
	for ddd in dist.keys():
		if ddd == "bakeVolumeSG":
			delaem=0
	if delaem:
		plId=s.CreatePayload("bakeVolumeSG", "inject", {u'Content': u'1', u'Source': u'1', 'Payload': u'BakePlayload', u'Label': u'bakeVolumeShader'})
		new_rule = rfm.rlf.NewRlfRule('inject', 'xpath', '/renderpass[@id="BakeRadiosityPass"]//*[contains(@sets,"bakeSet")]', 'continue',plId)
		d = []
		new_rule.SetUserDataDict(d)
		s.AddRule(new_rule)
		rlf2maya.SetActiveScope(s)

def deleteBake():
	import maya.cmds as cmds
	import maya.mel as mel
	import rfm.rlf2maya as rlf2maya
	import rfm.passes
	if cmds.objExists("bakeSet"): cmds.delete("bakeSet")
	if cmds.objExists("bakeLght"): cmds.delete("bakeLght")
	RenderRadiosityPass = rfm.passes.GetPass("BakeRadiosityPass")
	if RenderRadiosityPass != "": rfm.passes.DeletePass(RenderRadiosityPass)
	if cmds.objExists("bakeVolumeShader"): cmds.delete("bakeVolumeShader")
	if cmds.objExists("bakeVolumeSG"): cmds.delete("bakeVolumeSG")
	Finals = rfm.passes.GetPasses("Final")
	for F in Finals:
		F.Enable()
	s = rlf2maya.GetActiveScope()
	dict=s.GetRules()
	for k in dict:
		if k.GetPayloadId() == 'bakeVolumeSG':
			s.RemovePayload(k.GetPayloadId())
			s.DeleteRule(k)
	rlf2maya.SetActiveScope(s)

