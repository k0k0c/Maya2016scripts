import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
import subprocess
import sys
import ast
import shutil
import math
import time
import rfm.slim
import ml_makeProxy
import xml.etree.ElementTree
if cmds.about( b=True ) is False:
	import melnik_setup
'''
Make hierarchy
Combine
Displacement bound by shaders with displacement
Query in slim procedures
'''
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#Assembly procedures.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def ml_loadSlim( wait=1, debug=False ):
	'''
	Load slim renderman.
	'''
	if debug is True:
		print 'Initialize renderman slim.'
	cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ) is not True and cmds.loadPlugin( "RenderMan_for_Maya" )
	m_result = mel.eval( "rman slim isconnected" ) and True or False
	m_break = time.time() + ( 60 * wait )
	m_batch = cmds.about( b=True ) and " -gui 0 -edit 0" or ""
	if m_result is False:
		mel.eval( "rman slim start" + m_batch )
		while True:
			if mel.eval( "rman slim isconnected" ) and mel.eval( "rman slim command \"slim GetSlimStatus\"" ):
				m_result = True
				break
			if time.time() > m_break:
				break
	return m_result

def ml_loadPlugins( plugins='', debug=False ):
	'''
	Load maya plugins.
	'''
	m_result = []
	m_plugins = plugins == '' and [ 'RenderMan_for_Maya', 'AbcExport' ] or ( 'list' in str( type( plugins )) and plugins or [ plugins ] )
	for i in range( 0, len( m_plugins )):
		if not cmds.pluginInfo( m_plugins[i], query=True, loaded=True ):
			m_result.append( m_plugins[i] )
			try:
				if debug is True:
					print 'loadPlugin %s' % m_plugins[i]
				cmds.loadPlugin( m_plugins[i] )
			except:
				cmds.warning( 'Errors expected while initialize plugin: %s.' % str( m_plugins[i] ))
		else:
			if debug is True:
					print 'Plugin already loaded %s' % m_plugins[i]
	return m_result

def ml_slimCmd( command, debug=False, message=False ):
	'''
	Send command or message to slim.
	'''
	m_result = []
	m_slim = rfm.slim.GetSlim()
	if not m_slim:
		ml_loadSlim( wait=1, debug=debug )
	m_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
	for i in range( 0, len( m_command )):
		m_temp = ""
		if message is False:
			m_temp = m_slim.Cmd( '"' + m_command[i] + '"' )
		else:
			m_temp = m_slim.Msg( '"' + m_command[i] + '"' )
			m_wait = 0
			while True:
				m_wait = m_wait + 1
				if mel.eval( 'rman slim isconnected' ):
					break
				elif m_wait > 1000000000:
					break
		if debug is True:
			print 'rman slim command "%s" Result: %s' % ( m_command[i], ( m_temp and m_temp or [] ))
		m_temp and m_result.append( m_temp )
	return m_result

def ml_uniqueify( debug=False ):
	mel.eval( 'rman slim message "tc_uniqueifyAll"' )
	if debug is True:
		print 'rman slim message "tc_uniqueifyAll"'
	i = 0
	while True:
		ml_status = mel.eval( 'rman slim isconnected' )
		if ml_status:
		    break
		else:
		    if i > 100000000:
		        break
	return True	

def ml_freeze( m_node, query=False ):
	m_bool = True
	m_childrens = cmds.ls( m_node, dag=True, type="transform", long=True, ni=True )
	for n in range( 0, len( m_childrens )):
		if cmds.listConnections( m_childrens[n], source=True, destination=False ) or cmds.getAttr( "%s.tx" % m_childrens[n], lock=True ) or cmds.getAttr( "%s.ty" % m_childrens[n], lock=True ) or cmds.getAttr( "%s.tz" % m_childrens[n], lock=True ) or cmds.getAttr( "%s.t" % m_childrens[n], lock=True ):
			m_bool = False
			break
	if query is False and m_bool is True:
		cmds.makeIdentity( m_node, translate=True, apply=True )
		return m_node
	else:
		return m_bool
	
def ml_statistic( ml_node, path='', all=False, debug=False ):
	'''
	Generate statistic.
	'''
	m_target_for_hide = cmds.ls( type=[ "mesh", "nurbsCurve", "nurbsSurface" ] )
	if path == '':
		statistic_name = mel.eval( 'rman stringinterpolate "${STAGE}"' ) + '.string'
		statistic_dir = ( mel.eval( 'rman stringinterpolate "${RMSPROJ}"' ) or mel.eval( 'rman stringinterpolate "${RMSPROD}"' ))
		statistic_path = '%s%s' % ( statistic_dir, statistic_name )
	else:
		statistic_path = path
		statistic_dir = '/'.join( path.split( '/' )[:-1] )
		statistic_name = path.split( '/' )[-1]
	if debug is True:
		print 'statistic: %s' % statistic_path
	mel.eval( 'setCurrentRenderer renderMan;' )
	mel.eval( 'rmanChangeRendererUpdate;' )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_endofframe", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_filename", 'stdout', type="string" )
	cmds.setAttr( "renderManGlobals.rman__riopt__statistics_xmlfilename", statistic_path, type="string" )
	cmds.setAttr( "renderManGlobals.rman__riattr___ShadingRate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr__volume_depthrelativeshadingrate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riopt__limits_vprelativeshadingrate", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr___FocusFactor", 10 )
	cmds.setAttr( "renderManGlobals.rman__riattr___MotionFactor", 10 )
	cmds.setAttr( "renderManGlobals.rman__riopt__shading_directlightingsamples", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples0", 1 )
	cmds.setAttr( "renderManGlobals.rman__riopt___PixelSamples1", 1 )
	cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth0", 2 )
	cmds.setAttr( "rmanFinalOutputGlobals0.rman__riopt__Display_filterwidth1", 2 )
	cmds.setAttr( "defaultResolution.width", 256 )
	cmds.setAttr( "defaultResolution.height", 256 )
	cmds.setAttr( "defaultRenderGlobals.startFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.endFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.byFrameStep", 1 )
	#Create statistic camera.
	#Batch render.
	ml_camera = cmds.camera()
	ml_transform = ml_camera[0]
	ml_camera = ml_camera[-1]
	m_cameras_list = cmds.ls( type='camera' )
	[ cmds.setAttr( "%s.renderable" % m_cameras_list[i], 0 ) for i in range( 0, len( m_cameras_list )) ]
	cmds.setAttr( "%s.renderable" % ml_camera, 1 )
	cmds.renderSettings( camera=ml_camera )
	cmds.setAttr( '%s.rotate' % ml_transform, -45, 45, 0 )
	m_hidden = []
	if all is False:
		cmds.select( cmds.ls( ml_node, long=True ))
		cmds.viewFit( ml_camera )
		m_hidden = cmds.hide( m_target_for_hide, returnHidden=True )
		cmds.showHidden( ml_node )
	else:
		cmds.select( clear=True )
		cmds.viewFit( ml_camera )
	mel.eval( 'rman render;' )
	if m_hidden:
		cmds.showHidden( m_hidden )
	cmds.delete( ml_transform )
	return statistic_path

def ml_txmake( input='', output='' ):
	'''
	Convert input file .tif to .tex or .tex to .tif.
	'''
	import subprocess
	import os
	import re
	mg_output = ''
	mg_txmake = '%srmantree/bin/txmake.exe' % mel.eval( 'rman stringinterpolate "${RMSTREE}"' )
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	mg_input = input != '' and input or cmds.error( 'Please specify path to image source file.' )
	mg_output = output != '' and output or cmds.error( 'Please specify path to image output file.' )
	os.path.isfile( mg_output ) and os.remove( mg_output )
	if re.findall( '.tif$', mg_input ) and re.findall( '.tex$', mg_output ):
		mg_command = [ mg_txmake, '-verbose', '-smode', 'clamp', '-tmode', 'clamp', '-resize', 'up-', mg_input, mg_output ]
	if re.findall( '.tex$', mg_input ) and re.findall( '.tif$', mg_output ):
		mg_command = [ mg_txmake, '-format', 'tiff' , mg_input, mg_output ]
	else:
		cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False

def ml_ptrender( input='', output='', resolution='2048', channel='Ct' ):
	'''
	Convert input file .tif to .tex or .tex to .tif.
	'''
	import subprocess
	import os
	import re
	mg_txmake = '%srmantree/bin/ptrender.exe' % mel.eval( 'rman stringinterpolate "${RMSTREE}"' )
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	os.path.isfile( output ) and os.remove( output )
	if re.findall( '.ptc$', input ) and re.findall( '.tif$', output ):
		mg_command = [ mg_txmake, '-dspy', 'tiff', '-size', resolution, resolution, '-project', 'uv', input, channel, output ]
	else:
	    cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False
	
def ml_listAttached( ml_objects, id=False, node=False, debug=True ):
	'''
	List all slim attached id or objects.
	'''
	ml_result = []
	ml_objects = cmds.ls( ml_objects )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimEnsemble', 'rman__torattr___slimSurface' ]
	for i in range( 0, len( ml_objects )):
		ml_attached = False
		for n in range( 0, len( ml_attributes )):
			if cmds.attributeQuery( ml_attributes[n], n=ml_objects[i], exists=True ):
				ml_value = cmds.getAttr( ml_objects[i] + '.' + ml_attributes[n] ).split( "," )
				if ml_value:
					ml_attached = True
					if debug is True:
						print '%s attached to %s.' % ( ml_objects[i], str( ml_value ))
					for f in range( 0, len( ml_value )):
						if id is True or node is True:
							if id is True:
								if ml_value[f] not in ml_result:
									ml_result.append( ml_value[f] )
							if node is True:
								if ml_objects[i] not in ml_result:
									ml_result.append( ml_objects[i] )
						else:
							if ml_objects[i] not in ml_result:
									ml_result.append( ml_objects[i] )
		if ml_attached is False:
			if debug is True:
				print '%s not attached to any slim nodes.' % ml_objects[i]
	return ml_result

def ml_createCurveControl( name='', parent='', size='', target='', constraint=True, debug=False ):
	'''
	Create curve control shape.
	'''
	def getLenght( node ):
		if node != '':
			bb = { 'min':cmds.getAttr( node + '.boundingBoxMin' )[0], 'max':cmds.getAttr( node + '.boundingBoxMax' )[0] }
			zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
			key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
			return zyx[ key[ True ] ]
		else:
			return 1
	ml_curve_mel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
	ml_curve = mel.eval( ml_curve_mel )
	if debug is True:
		print ml_curve_mel
	ml_length = getLenght( size )
	if name != '':
		ml_curve = cmds.rename( ml_curve, name )
		if debug is True:
			print 'rename %s %s' % ( ml_curve, name )
	cmds.scale( 1.2 * ml_length, 1.2 * ml_length, 1.2 * ml_length, ml_curve )
	cmds.makeIdentity( ml_curve, translate=True, rotate=True, scale=True, apply=True )
	if target != '':
		if constraint is True:
			cmds.parentConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			cmds.scaleConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			if debug is True:
				print 'parentConstraint %s -maintainOffset %s' % ( ml_curve, target )
				print 'scaleConstraint %s -maintainOffset %s' % ( ml_curve, target )
		else:
			cmds.parent( target, ml_curve )
			if debug is True:
				print 'parent %s %s' % ( target, ml_curve )
	if parent != '':
		cmds.parent( ml_curve, parent )
		if debug is True:
			print 'parent %s %s' % ( ml_curve, parent )
	return ml_curve
	
def ml_setAttr( m_node, m_value, debug=False, force=False, query=False ):
	'''
	Set attribute value.
	'''
	m_result = []
	m_temp = cmds.ls( m_node, long=True )
	for i in range( 0, len( m_temp )):
		if cmds.attributeQuery( m_temp[i].split( '.' )[-1], n=m_temp[i].split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( m_temp[i] )):
			if cmds.getAttr( m_temp[i] ) != m_value:
				m_result.append( m_temp[i] )
				if query is False:
					cmds.setAttr( m_temp[i], m_value )
					if debug is True:
						print 'setAttr %s %s;' % ( m_temp[i], m_value )
				else:
					if debug is True:
						print "%s not equal %s;" % ( m_temp[i], m_value )
	return m_result

def ml_deleteNode( ml_objects, debug=False, query=False ):
	'''
	Delete maya node.
	'''
	m_result = []
	m_ignore = [ "time1", "sequenceManager1", "renderPartition", "renderGlobalsList1", "defaultLightList1", "defaultShaderList1", "postProcessList1", "defaultRenderUtilityList1", "defaultRenderingList1", "lightList1", "defaultTextureList1", "lambert1", "particleCloud1", "initialShadingGroup", "initialParticleSE", "initialMaterialInfo", "shaderGlow1", "dof1", "defaultRenderGlobals", "defaultRenderQuality", "defaultResolution", "defaultLightSet", "defaultObjectSet", "defaultViewColorManager", "hardwareRenderGlobals", "hardwareRenderingGlobals", "characterPartition", "defaultHardwareRenderGlobals", "ikSystem", "hyperGraphInfo", "hyperGraphLayout", "globalCacheControl", "dynController1", "strokeGlobals", "lightLinker1", "layerManager", "defaultLayer", "renderLayerManager", "defaultRenderLayer" ]
	m_temp = cmds.ls( ml_objects, long=True )
	if m_temp:
		for i in range( 0, len( m_temp )):
			if cmds.objExists( m_temp[i] ) and m_temp[i] not in m_ignore:
				m_result.append( m_temp[i] )
		if m_result:
			if query is False:
				cmds.delete( m_result )
			if debug is True:
				print 'delete %s;' % m_result
	return m_result

def ml_deleteAttr( m_node, debug=False, force=False, query=False, empty=False ):
	'''
	Delete attribute.
	'''
	if cmds.attributeQuery( m_node.split( '.' )[-1], n=m_node.split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( m_node )) and (( empty is True and not cmds.getAttr( m_node )) or empty is False ):
		if query is False:
			cmds.deleteAttr( m_node )
		if debug is True:
			print 'deleteAttr %s;' % m_node
	return m_node.split( '.' )[0]

def ml_addRmanAttr( m_node, m_attribute, m_value, debug=False, query=False ):
	'''
	Add rman attribute.
	'''
	if not cmds.attributeQuery( m_attribute, n=m_node, exists=True ):
		if query is False:
			mel.eval( 'rmanAddAttr( "%s", "%s", "%s" )' % ( m_node, m_attribute, m_value ) )
		if debug is True:
			print 'rmanAddAttr( "%s", "%s", "%s" )' % ( m_node, m_attribute, m_value )
	return m_node

def ml_renameNode( m_nodes, m_shablon, m_prefix, debug=False ):
	'''
	Generate new name for object by pattern.
	'''
	m_result = []
	m_nodes = cmds.ls( m_nodes, long=True )
	for i in range( 0, len( m_nodes )):
		if cmds.objExists( m_nodes[i] ):
			m_incr = 1
			while True:
				m_name = m_shablon + ( "0" * ( 3 - len( str( m_incr ) ) ) ) + str( m_incr ) + m_prefix
				if cmds.objExists( m_name ):
					m_incr = m_incr + 1
					continue
				else:
					break
			m_name = cmds.rename( m_nodes[i], m_name, ignoreShape=True )
			m_result.append( m_name )
			for n in range( 0, len( m_nodes )):
				if re.findall( "^" + "\|".join( m_nodes[i].split( "|" )), m_nodes[n] ):
					m_nodes[n] = m_nodes[n].replace( m_nodes[i], m_name )
			if debug is True:
				print "rename %s %s" % ( m_nodes, m_name )
	return m_result

def ml_attachRmanQuery( ml_node ):
	'''
	Query attachment id state.
	'''
	ml_result = []
	ml_objects = cmds.ls( ml_node )
	ml_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
	for i in range( 0, len( ml_objects )):
		for n in range( 0, len( ml_attributes )):
			if cmds.attributeQuery( ml_attributes[n], n=ml_objects[i], exists=True ) is True:
				ml_value = cmds.getAttr( '%s.%s' % ( ml_objects[i], ml_attributes[n] ))
				if ml_value:
					ml_value = ml_value.split( ',' )
					for v in range( 0, len( ml_value )):
						ml_result.append( ml_value[v] )
	return ml_result	
	
def ml_listConnections( ml_nodes, debug=False, source=True, destination=True, type='' ):
	'''
	List all connections for target node.
	'''
	def mlt_depth( m_temp ):
		m_temp = cmds.ls( m_temp )
		ml_connections = cmds.listConnections( m_temp, source=source, destination=destination )
		if ml_connections:
			for i in range( 0, len( ml_connections )):
				if ml_connections[i] not in ml_result and ml_connections[i] not in ml_cache and ml_connections[i] not in ml_nodes:
					ml_cache.append( ml_connections[i] )
					if cmds.nodeType( ml_connections[i] ) in ml_type or type == '':
						ml_result.append( ml_connections[i] )
					if debug is True:
						print 'next connection( %s ).' % ml_connections[i]
					mlt_depth( ml_connections[i] )
	ml_result = []
	ml_cache = []
	ml_type = type
	ml_nodes = cmds.ls( ml_nodes )
	mlt_depth( ml_nodes )
	return ml_result	
	
def ml_setupAttributes( m_node, query=False, debug=False ):
	def ml_setupAttributes_exec( m_node, m_attribute, m_value ):
		m_info = ""
		if m_value == "REMOVE":
			if cmds.attributeQuery( m_attribute, n=m_node, exists=True ) and not cmds.listConnections( "%s.%s" % ( m_node, m_attribute )):
				m_info = "delete %s.%s;" % ( m_node, m_attribute )
				if query is False:
					ml_deleteAttr( '%s.%s' % ( m_node, m_attribute ), debug=debug )
					return m_info
				else:
					return m_info
		elif m_value == "REMOVE EMPTY":
			if cmds.attributeQuery( m_attribute, n=m_node, exists=True ) and not cmds.listConnections( "%s.%s" % ( m_node, m_attribute )) and not cmds.getAttr( "%s.%s" % ( m_node, m_attribute )):
				m_info = "delete %s.%s;" % ( m_node, m_attribute )
				if query is False:
					ml_deleteAttr( '%s.%s' % ( m_node, m_attribute ), debug=debug )
					return m_info
				else:
					return m_info
		elif m_value == "ADD":
			if not cmds.attributeQuery( m_attribute, n=m_node, exists=True ):
				m_info = "add %s.%s;" % ( m_node, m_attribute )
				if query is False:
					ml_addRmanAttr( m_node, m_attribute, "", debug=debug )
					return m_info
				else:
					return m_info
		elif m_value == "FLAT":
			if cmds.attributeQuery( m_attribute, n=m_node, exists=True ):
				m_info = "assign %s.%s;" % ( m_node, m_attribute )
				if query is False:
					m_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
					if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=m_node, exists=True ):
						m_ensemble = cmds.getAttr( '%s.rman__torattr___slimEnsemble' % m_node )
						m_materials = ml_slimCmd( 'tc_ensembleProperty -id %s' % m_ensemble, debug=debug)
						if m_materials:
							m_materials = m_materials[0].split( ' ' )
							ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % m_node, debug=debug )
							ml_addRmanAttr( m_node, 'rman__torattr___slimSurface', m_materials[0], debug=debug )
							if m_materials[1:]:
								ml_addRmanAttr( m_node, 'rman__torattr___slimShader', ','.join( m_materials[1:] ), debug=debug )
					for n in range( 0, len( m_attributes )):
						ml_flatRmanAttr( m_node, m_attributes[n], debug=debug )
					return m_info
				else:
					return m_info
		else:
			if cmds.attributeQuery( m_attribute, n=m_node, exists=True ) and not cmds.listConnections( "%s.%s" % ( m_node, m_attribute )) and cmds.getAttr( "%s.%s" % ( m_node, m_attribute ) ) != m_value:
				m_info = "set %s.%s %s;" % ( m_node, m_attribute, m_value )
				if query is False:
					ml_setAttr( "%s.%s" % ( m_node, m_attribute ), m_value, debug=debug )
					return m_info
				else:
					return m_info
	m_result = []
	m_nodes = cmds.ls( m_node, long=True )
	m_base_dict = {
	"mesh" : {
	"rman__torattr___subdivScheme" : "ADD",
	"castsShadows" : 1,
	"receiveShadows" : 1,
	"primaryVisibility" : 1,
	"motionBlur" : 1,
	"visibleInReflections" : 1,
	"visibleInRefractions" : 1,
	"doubleSided" : 0,
	"opposite" : 0,
	"displaySmoothMesh" : 0,
	"smoothShading" : 1,
	"rman__torattr___invis" : "REMOVE",
	},
	"nurbsCurve" : {
	"rman__torattr___invis" : "ADD",
	"rman__torattr___subdivScheme" : "REMOVE",
	"rman__torattr___slimShader" : "REMOVE",
	"rman__torattr___slimEnsemble" : "REMOVE",
	"rman__torattr___slimSurface" : "REMOVE",
	},
	"transform" : {
	"rman__torattr___invis" : "REMOVE",
	"rman__torattr___subdivScheme" : "REMOVE",
	"rman__torattr___slimShader" : "FLAT",
	"rman__torattr___slimEnsemble" : "FLAT",
	"rman__torattr___slimSurface" : "FLAT",
	},
	}
	m_base_keys = m_base_dict.keys()
	m_assembly_dict = {
	"visibility" : 1,
	"rman__torattr___slimShader" : "REMOVE EMPTY",
	"rman__torattr___slimSurface" : "REMOVE EMPTY",
	"rman__torattr___slimEnsemble" : "REMOVE EMPTY",
	"rman__torattr___postShapeScript" : "REMOVE EMPTY",
	"rman__torattr___postTransformScript" : "REMOVE EMPTY",
	"rman__torattr___preShapeScript" : "REMOVE EMPTY",
	"rman__torattr___transformBeginScript" : "REMOVE EMPTY",
	"rman__torattr___transformEndScript" : "REMOVE EMPTY",
	}
	m_assembly_keys = m_assembly_dict.keys()
	m_cameras = cmds.ls( cameras=True, long=True )
	m_cameras = [ cmds.listRelatives( m_cameras[i], parent=True, fullPath=True )[0] for i in range( 0, len( m_cameras )) ]
	for i in range( 0, len( m_nodes )):
		if cmds.nodeType( m_nodes[i] ) in m_base_keys and m_nodes[i] not in m_cameras:
			m_type_dict = m_base_dict[ cmds.nodeType( m_nodes[i] ) ]
			m_type_keys = m_type_dict.keys()
			for n in range( 0, len( m_assembly_keys )):
				m_temp = ml_setupAttributes_exec( m_nodes[i], m_assembly_keys[n], m_assembly_dict[ m_assembly_keys[n] ] )
				if m_temp and m_temp not in m_result:
					m_result.append( m_temp )
			for n in range( 0, len( m_type_keys )):
				m_temp = ml_setupAttributes_exec( m_nodes[i], m_type_keys[n], m_type_dict[ m_type_keys[n] ] )
				if m_temp and m_temp not in m_result:
					m_result.append( m_temp )
	return m_result
	
def ml_replace( m_dst, m_src, m_variable, expression="" ):
	'''
	Replace all values to target value in dictionary and list variables.
	'''
	def ml_replace_exec( m_temp, parent=None, index=None ):
		if type( m_temp ) is dict:
			m_value_keys = m_temp.keys()
			for i in range( 0, len( m_value_keys )):
				ml_replace_exec( m_temp[ m_value_keys[i] ], parent=m_temp, index=m_value_keys[i] )
		elif type( m_temp ) is list:
			for i in range( 0, len( m_temp )):
				ml_replace_exec( m_temp[i], parent=m_temp, index=i )
		elif type( m_temp ) is str or type( m_temp ) is unicode:
			if re_expression.findall( m_temp ):
				re_sub = re.compile( "{0}\||{0}$".format( "\|".join( m_src.split( "|" ))))
				m_temp = re_sub.sub( m_temp, m_dst )
				if type( parent ) is dict:
					parent.update( { index:m_temp } )
				elif type( parent ) is list:
					parent[index] = m_temp
	re_expression =  expression == "" and re.compile( "^\|{0}|^{0}".format( "\|".join( m_src.split( "|" ))), re.IGNORECASE ) or expression
	ml_replace_exec( m_variable )
	return m_variable
	
def ml_exportScene( ml_file, ml_objects, version=False ):
	'''
	Save target objects to new file.
	-filename = Path to saved file.
	-version = Create file version.
	'''
	ml_result = ''
	ml_objects = cmds.ls( ml_objects )
	ml_type = { 'mb':'mayaBinary', 'ma':'mayaAscii' }[ ml_file.split('.')[-1] ]
	if ml_objects != '':
		m_temp = []
		for i in range( 0, len( ml_objects )):
			if cmds.objExists( ml_objects[i] ):
				m_temp.append( ml_objects[i] )
		cmds.select( m_temp )
		cmds.file( ml_file, force=True, type=ml_type, exportSelected=True )
	else:
		cmds.file( force=True, type=ml_type, save=True )
	if version is True:
		ml_work = ml_getVersion( ml_file )
		shutil.copy2( ml_file, ml_work )
	return ml_result

def ml_flatRmanAttr( ml_object, ml_attribute, debug=False ):
	'''
	Rebind target attribute to shapes.
	'''
	def ml_flatRmanAttr_depth( ml_node, ml_attribute ):
		ml_childrens = cmds.listRelatives( ml_node, children=True, ni=True, fullPath=True )
		if cmds.attributeQuery( ml_attribute, n=ml_node, exists=True ):
			ml_value = cmds.getAttr( '%s.%s' % ( ml_node, ml_attribute ))
			if ml_childrens:
				ml_deleteAttr( '%s.%s' % ( ml_node, ml_attribute ), debug=debug )
				for i in range( 0, len( ml_childrens )):
					ml_addRmanAttr( ml_childrens[i], ml_attribute, ml_value, debug=debug )
					ml_flatRmanAttr_depth( ml_childrens[i], ml_attribute )
			ml_result.append( ml_node )
	ml_result = []
	ml_flatRmanAttr_depth( ml_object, ml_attribute )
	return ml_result	
	
def ml_getVersion( ml_path ):
	'''
	Generate new file version.
	-file = Path to target file
	'''
	ml_result = ''
	ml_version = '_v001'
	ml_path = ml_path == '' and cmds.error( 'Please specify path to target file.' ) or ml_path
	ml_scene = ( ml_path.split( '/' )[-1] ).split( '.' )[0]
	ml_format = ( ml_path.split( '/' )[-1] ).split( '.' )[-1]
	ml_project = ml_getProject( ml_path, mode='server-3d' )
	ml_work = ml_project + '/maya/work/'
	if not os.path.isdir( ml_work ):
		os.makedirs( ml_work )
	ml_files = str( os.listdir( ml_work ))
	ml_control = re.findall( ml_scene + '_v([0-9]+)\.' + ml_format, ml_files )
	if ml_control:
		m_temp = ml_getMaxValue( ml_control ) + 1
		ml_version = '_v' + ( '0' * ( 3 - len( str( m_temp )))) + str( m_temp )
	ml_result = ml_work + ml_scene + ml_version + '.' + ml_format
	return ml_result
	
def ml_getProject( ml_path, mode='' ):
	'''
	Get project directory.
	-mode = Get project directory from server-3d or renderServer.
	'''
	ml_platform = sys.platform
	ml_mode = mode == '' and 'renderServer' or mode
	ml_server = { 'renderServer':( ml_platform == "win32" and "//renderServer/Project" or "/renderServer/Project" ), 'server-3d':( ml_platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) }
	ml_expr = re.compile('^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)', re.IGNORECASE)
	ml_path = ml_path.split( "/" )
	ml_index = 0
	ml_compile = re.compile( "Project", re.IGNORECASE )
	for m_temp in ml_path:
		if ml_compile.match( m_temp ):
			break
		ml_index = ml_index + 1
	ml_project = ml_expr.sub( ml_server[ ml_mode ], "/".join( ml_path[:ml_index + 5] ))
	return ml_project	
	
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#Main procedure.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def ml_setup(
	scenePath = "",
	query = False,
	debug = False,
	mayaUnusedNodes = True,
	mayaRenameNodes = True,
	mayaHierarchySetup = True,
	mayaRenderStats = True,
	mayaZeroTranslate = True,
	mayaNonManifoldGeometry = True,
	mayaReAttachSlimNodes = True,
	slimRenameNodes = True,
	slimHierarchySetup = True,
	slimUnusedNodes = True,
	mayaSetDisplacementBoundForSlim = True,
	mayaNormalDirection = True,
	mayaShadingNode = True,
	mayaBakeColorsFromSlim = True,
	mayaCombine = True,
	slimUniqueifyNodes = True,
	mayaDeleteHistoryNodes = True,
	slimMask = False,
	mayaSaveScene = False,
	mayaMakeProxy = False,
	):
	def ml_update_content( m_dst, m_src ):
		ml_replace( m_dst, m_src, mayaUnusedNodes )
		ml_replace( m_dst, m_src, mayaRenameNodes )
		ml_replace( m_dst, m_src, mayaHierarchySetup )
		ml_replace( m_dst, m_src, mayaRenderStats )
		ml_replace( m_dst, m_src, mayaNonManifoldGeometry )
		ml_replace( m_dst, m_src, mayaReAttachSlimNodes )
		ml_replace( m_dst, m_src, mayaSetDisplacementBoundForSlim )
		ml_replace( m_dst, m_src, mayaNormalDirection )
		ml_replace( m_dst, m_src, mayaShadingNode )
		ml_replace( m_dst, m_src, mayaCombine )
		ml_replace( m_dst, m_src, mayaDeleteHistoryNodes )
	def ml_print_currentTask( m_dict, *m_keys ):
		if debug is True:
			for m_string in m_keys:
				print m_dict[ m_string ]
		return True
	m_debug_messages = {
	0:"_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _",
	1 : "Delete unused nodes:",
	2 : "Rename maya nodes:",
	3 : "Hierarchy setup:",
	4 : "Non manifold geometry:",
	5 : "Rename slim nodes:",
	6 : "Slim attachments setup:",
	7 : "Setup slim:",
	8 : "Delete unused slim nodes:",
	9 : "Displacement bound setup:",
	10 : "Normal direction setup:",
	11 : "Normal angle setup:",
	12 : "Shading setup:",
	13 : "Bake colors:",
	14 : "Uniqueify slim nodes:",
	15 : "Delete history:",
	16 : "Save scene:",
	17 : "Make proxy:",
	18 : "Initialization",
	19 : "Load preferences;",
	20 : "__________________________________________________________________",
	21 : "Setup attributes",
	22 : "Combine meshes",
	}
	m_undeletable = [ "time1", "sequenceManager1", "renderPartition", "renderGlobalsList1", "mtorPartition", "defaultLightList1", "defaultShaderList1", "postProcessList1", "defaultRenderUtilityList1", "defaultRenderingList1", "lightList1", "defaultTextureList1", "lambert1", "particleCloud1", "initialShadingGroup", "initialParticleSE", "initialMaterialInfo", "shaderGlow1", "dof1", "defaultRenderGlobals", "defaultRenderQuality", "defaultResolution", "defaultLightSet", "defaultObjectSet", "defaultViewColorManager", "hardwareRenderGlobals", "hardwareRenderingGlobals", "characterPartition", "defaultHardwareRenderGlobals", "ikSystem", "hyperGraphInfo", "hyperGraphLayout", "globalCacheControl", "dynController1", "strokeGlobals", "lightLinker1", "layerManager", "defaultLayer", "renderLayerManager", "defaultRenderLayer" ]
	m_cameras = cmds.ls( cmds.listCameras(), dag=True, long=True )
	m_cameras = [ m_cameras[i] for i in range( 0, len( m_cameras )) if cmds.camera( m_cameras[i], query=True, startupCamera=True ) ]
	[ m_undeletable.append( m_cameras[i] ) for i in range( 0, len( m_cameras )) ]
	m_references = cmds.ls( referencedNodes=True, long=True )
	m_referencedNodes = cmds.ls( references=True, long=True )
	[ m_references.append( m_referencedNodes[i] ) for i in range( 0, len( m_referencedNodes )) ]
	m_result = {}
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	ml_print_currentTask( m_debug_messages, 20, 18, 0 )
	m_mayafile = scenePath == "" and cmds.file( query=True, sceneName=True ) or scenePath
	m_mayafile = m_mayafile != "" and m_mayafile or "untitled"
	m_scenename = ( m_mayafile.split( "/" )[-1] ).split( "." )[0]
	re.findall( "proxy", m_mayafile, re.IGNORECASE ) and cmds.error( "File is proxy version, please specify path to original file." )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	ml_print_currentTask( m_debug_messages, 20, 19, 0 )
	ml_loadPlugins( debug=debug )
	ml_loadSlim( debug=debug )
	ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim.tcl", debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 6, 9, 10.
	#Texture setup 5, 12, 7, 8.
	if mayaUnusedNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 1, 0 )
		m_procedure = "Unused maya nodes"
		m_items = []
		if mayaUnusedNodes is True:
			m_nodes = cmds.ls( long=True )
			m_shaders = cmds.ls( materials=True, long=True )
			for i in range( 0, len( m_nodes )):
				if cmds.objExists( m_nodes[i] ) and m_nodes[i] not in m_references:
					#Rib archives, Layers, Lights, GpuCaches, Filters
					if cmds.nodeType( m_nodes[i] ) in [ "objectTypeFilter", "shadingEngine", "lookAt", "nodeEditorPanel", "animCurveTA", "animCurveTL", "animCurveTU", "objectNameFilter", "groupId", "lambert", "materialInfo", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter", "RenderManArchive", "gpuCache", "RenderMan", "renderLayer", "displayLayer", "animLayer", "pointLight", "volumeLight", "areaLight", "spotLight", "directionalLight", "ambientLight", "RMSLightBlocker", "RMSAreaLight", "RMSEnvLight", "RMSGILight", "RMSCausticLight", "RMSGIPtcLight", "RMSGeoAreaLight", "RMSGeoLightBlocker", "RMSPointLight", "camera" ] or m_nodes[i] in m_shaders:
						if m_nodes[i] not in m_items and m_nodes[i] not in m_undeletable:
							if cmds.nodeType( m_nodes[i] ) == "groupId":
								if not cmds.listConnections( m_nodes[i], type="groupParts" ) and not cmds.listConnections( m_nodes[i], type="mesh" ):
									m_items.append( m_nodes[i] )
									continue
							elif cmds.nodeType( m_nodes[i] ) in [ "animCurveTA", "animCurveTL", "animCurveTU" ]:
								if not cmds.listConnections( m_nodes[i], type="nurbsCurve" ) and not cmds.listConnections( m_nodes[i], type="mesh" ) and not cmds.listConnections( m_nodes[i], type="blendShape" ):
									m_connections = cmds.listConnections( m_nodes[i] )
									m_connections = cmds.ls( m_connections, dag=True, shapes=True )
									m_law = False
									for n in range( 0, len( m_connections )):
										if cmds.nodeType( m_connections[n] ) in [ "camera", "stereoRigCamera" ]:
											m_law = True
											break
									if m_law is True:
										m_items.append( m_nodes[i] )
										continue
							else:
								m_items.append( m_nodes[i] )
								continue
					#Empty groups
					elif cmds.nodeType( m_nodes[i] ) in [ "transform" ]:
						m_law = True
						m_temp = cmds.ls( m_nodes[i], dag=True, noIntermediate=True, long=True )
						for n in range( 0, len( m_temp )):
							m_connections = cmds.listConnections( m_temp[n] )
							if cmds.nodeType( m_temp[n] ) != "transform":
								m_law = False
								break
							else:
								if m_connections:
									m_law = False
									break
						if m_law is True:
							if m_nodes[i] not in m_items and m_nodes[i] not in m_undeletable:
								m_items.append( m_nodes[i] )
								continue
							continue
					#Hidden nodes
					if cmds.ls( m_nodes[i], dag=True, long=True ) and not cmds.listConnections( cmds.ls( m_nodes[i], dag=True, long=True )) and ((( cmds.attributeQuery( 'intermediateObject', n=m_nodes[i], exists=True ) and cmds.getAttr( '%s.intermediateObject' % m_nodes[i] )) or ( cmds.attributeQuery( 'visibility', n=m_nodes[i], exists=True ) and cmds.getAttr( '%s.visibility' % m_nodes[i] ) == 0 ))):
						if m_nodes[i] not in m_items and m_nodes[i] not in m_undeletable:
							m_items.append( m_nodes[i] )
							continue
		else:
			m_items = mayaUnusedNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				ml_deleteNode( m_items, debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 2
	if mayaRenameNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 2, 0 )
		m_procedure = "Incorrect maya names"
		m_items = []
		if mayaRenameNodes is True:
			m_nodes = cmds.ls( dag=True, long=True, ni=True, shapes=True )
			for i in range( 0, len( m_nodes )):
				if cmds.objExists( m_nodes[i] ) and m_nodes[i] not in m_references:
					m_rec = re.compile( "pPipe|pPlane|polySurface|pCylinder|pPyramid|pCone|pCube|pSphere|nurbsPlan|nurbsTorus|nurbsCone|nurbsCylinder|nurbsCube|nurbsSphere", re.IGNORECASE )
					m_parent = cmds.listRelatives( m_nodes[i], parent=True, path=True )
					if m_parent:
						m_parent = m_parent[0]
						if m_rec.findall( m_nodes[i] ) and m_nodes[i] not in m_items:
							m_items.append( m_parent )
						elif m_rec.findall( m_parent ) and m_parent not in m_items:
							m_items.append( m_parent )
		else:
			m_items = mayaRenameNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ):
						m_temp = ml_renameNode( m_items[i], m_scenename, '_geo', debug=debug )
						m_temp = m_items[i].replace( m_items[i].split( "|" )[-1], m_temp[0] )
						ml_update_content( m_temp, m_items[i] )
						m_shape = cmds.listRelatives( m_temp, children=True, shapes=True, fullPath=True )
						for n in range( 0, len( m_shape )):
							m_temp = cmds.rename( m_shape[n], "%sShape" % m_temp )
							m_temp = m_shape[n].replace( m_shape[n].split( "|" )[-1], m_temp )
							ml_update_content( m_temp, m_shape[n] )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 1, 3, 7, 12
	if mayaHierarchySetup is not False:
		ml_print_currentTask( m_debug_messages, 20, 3, 0 )
		m_procedure = "Maya nodes hierarchy"
		m_items = []
		if mayaHierarchySetup is True:
			if not re.findall( 'render|dyn', m_scenename, re.IGNORECASE ):
				m_nodes = cmds.ls( long=True, dag=True, assemblies=True, ni=True )
				m_nodes = [ m_nodes[i] for i in range( 0, len( m_nodes )) if not cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ) ]
				for i in range( 0, len( m_nodes )):
					m_depth_childrens = cmds.ls( m_nodes[i], dag=True, ni=True )
					m_law = False
					for n in range( 0, len( m_depth_childrens )):
						if cmds.nodeType( m_depth_childrens[n] ) != "transform":
							m_law = True
							break
					if not re.findall( 'root|top|persp|side|front', m_nodes[i] ) and cmds.nodeType( m_nodes[i] ) == "transform" and m_nodes[i] not in m_items and m_law is True:
						m_items.append( m_nodes[i] )
		else:
			m_items = mayaHierarchySetup
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				m_rootGrp = cmds.objExists( '|root' ) and cmds.ls( '|root' )[0] or cmds.createNode( "transform", n="root" ) and cmds.ls( "root", long=True, type="transform" )[0]
				m_allRoots = cmds.ls( 'root', long=True )
				if m_allRoots and len( m_allRoots ) > 1:
					for i in range( 0, len( m_allRoots )):
						if not re.findall( '^\|root$|^root$', m_allRoots[i] ):
							m_temp = ml_rename( m_allRoots[i], m_scenename, '_grp', debug=debug )
							m_temp = m_allRoots[i].replace( m_allRoots[i].split( "|" )[-1], m_temp[0] )
							ml_update_content( m_temp, m_allRoots[i] )
				if debug is True:
					print 'root group: %s' % m_rootGrp
				m_rigGrp = ''
				m_geometryGrp = ''
				m_childrens = cmds.listRelatives( m_rootGrp, children=True, ni=True, path=True )
				m_unknownGrp = []
				#Get rig and geometry groups.parent
				if m_childrens:
					for i in range( 0, len( m_childrens )):
						if cmds.nodeType( m_childrens[i] ) == 'transform' and re.findall( 'rig', m_childrens[i], re.IGNORECASE ) and m_rigGrp == '':
							m_rigGrp = m_childrens[i]
						elif cmds.nodeType( m_childrens[i] ) == 'transform' and re.findall( 'geo', m_childrens[i], re.IGNORECASE ) and not re.findall( 'rig', m_childrens[i], re.IGNORECASE ) and m_geometryGrp == '':
							m_geometryGrp = m_childrens[i]
						else:
							m_depth_childrens = cmds.ls( m_childrens[i], dag=True, ni=True )
							m_law = False
							for n in range( 0, len( m_depth_childrens )):
								if cmds.nodeType( m_depth_childrens[n] ) != "transform":
									m_law = True
									break
							if m_law is True:
								m_unknownGrp.append( m_childrens[i] )
				m_rigGrp = m_rigGrp == '' and (( cmds.objExists( '|root|rig' ) and cmds.ls( '|root|rig', long=True ) or cmds.createNode( "transform", n="rig", parent=m_rootGrp )  and cmds.ls( "root|rig", long=True, type="transform" )[0])) or m_rigGrp
				m_geometryGrp = m_geometryGrp == '' and  (( cmds.objExists( '|root|geo_normal' ) and cmds.ls( '|root|geo_normal', long=True ) or cmds.createNode( "transform", n="geo_normal", parent=m_rootGrp ) and cmds.ls( "root|geo_normal", long=True, type="transform" )[0])) or m_geometryGrp
				if debug is True:
					print 'geometry group: %s' % m_geometryGrp
					print 'rig group: %s' % m_rigGrp
				if m_unknownGrp:
					for i in range( 0, len( m_unknownGrp )):
						if cmds.objExists( m_items[i] ) and not re.findall( 'rig', m_unknownGrp[i], re.IGNORECASE ):
							m_temp = cmds.parent( m_unknownGrp[i], m_geometryGrp )
							m_temp = m_geometryGrp + "|" + m_unknownGrp[i].split( "|" )[-1]
							ml_update_content( m_temp, m_unknownGrp[i] )
							if debug is True:
								print 'Founded unknown group: %s' % m_unknownGrp[i]
				#Include all can be used transforms to geometry group.
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not re.findall( 'root|top|persp|side|front', m_items[i] ):
						m_temp = cmds.parent( m_items[i], m_geometryGrp )
						m_temp = m_geometryGrp + "|" + m_items[i].split( "|" )[-1]
						ml_update_content( m_temp, m_items[i] )
						if debug is True:
							print 'parent %s %s' % ( m_items[i], m_geometryGrp )
				m_controlsState = True
				m_generalCT = cmds.ls( 'general_CT' )
				m_generalCT_offset = cmds.ls( "general_offset_CT" )
				if not m_generalCT:
					m_connections = ml_listConnections( m_geometryGrp )
					if m_connections:
						for i in range( 0, len( m_connections )):
							if cmds.ls( m_connections[i], dag=True, type='nurbsCurve' ):
								m_generalCT = m_connections[i]
								m_controlsState = False
								if debug is True:
									print 'Unknown controls founded, pass.'
								break
				else:
					m_childrens = cmds.listRelatives( m_generalCT, allDescendents=True, path=True )
					ml_shapes = cmds.listRelatives( m_generalCT, children=True, shapes=True, path=True )
					if m_childrens and not cmds.listConnections( m_childrens ) or not m_childrens and cmds.listConnections( m_generalCT ) or not ml_shapes:
						m_controlsState = True
					else:
						m_controlsState = False
						print 'Controls founded, pass.'
				if m_controlsState is True:
					if m_generalCT and not m_generalCT_offset:
						m_generalCT_offset = cmds.rename( m_generalCT, 'general_offset_CT' )
						m_generalCT = ''
					if not m_generalCT_offset:
						m_generalCT_offset = ml_createCurveControl( name='general_offset_CT', parent=m_rigGrp, size=m_geometryGrp, target=m_geometryGrp, constraint=True, debug=debug )
					if not m_generalCT:
						m_generalCT = ml_createCurveControl( name='general_CT', parent=m_rigGrp, size=m_generalCT_offset, target=m_generalCT_offset, constraint=False, debug=debug )
				m_generalCT_offset = cmds.ls( "general_offset_CT" )
				m_generalCT = cmds.ls( 'general_CT' )
				if m_generalCT:
					ml_setupAttributes( m_generalCT, query=False, debug=False )
					ml_setAttr( [ '%s.tx' % m_generalCT[0], '%s.ty' % m_generalCT[0], '%s.tz' % m_generalCT[0] ], 0, debug=debug )
					ml_setAttr( [ '%s.rx' % m_generalCT[0], '%s.ry' % m_generalCT[0], '%s.rz' % m_generalCT[0] ], 0, debug=debug )
				if m_generalCT_offset:
					ml_setupAttributes( m_generalCT_offset, query=False, debug=False )
					ml_setAttr( [ '%s.tx' % m_generalCT_offset[0], '%s.ty' % m_generalCT_offset[0], '%s.tz' % m_generalCT_offset[0] ], 0, debug=debug )
					ml_setAttr( [ '%s.rx' % m_generalCT_offset[0], '%s.ry' % m_generalCT_offset[0], '%s.rz' % m_generalCT_offset[0] ], 0, debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 0.
	if mayaNonManifoldGeometry is not False:
		ml_print_currentTask( m_debug_messages, 20, 4, 0 )
		m_procedure = "Non-manifold geometry"
		m_items = {}
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		if mayaNonManifoldGeometry is True:
			m_nodes = cmds.ls( dag=True, type='mesh', ni=True, visible=True, long=True )
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_ignore and m_nodes[i] not in m_references:
					m_temp = []
					if cmds.polyEvaluate( m_nodes[i], vertex=True ) >= 2:
						m_component = cmds.ls( cmds.polyInfo( m_nodes[i], laminaFaces=True ), fl=True, long=True )
						if m_component:
							for n in range( 0, len( m_component )):
								m_temp.append( m_component[n] )
							if debug is True:
								print 'Founded non manifold faces on: %s' % m_nodes[i]
						m_component = cmds.ls( cmds.polyInfo( m_nodes[i], nonManifoldEdges=True ), fl=True, long=True )
						if m_component:
							for n in range( 0, len( m_component )):
								m_temp.append( m_component[n] )
							if debug is True:
								print 'Founded non manifold edges on: %s' % m_nodes[i]
						m_component = cmds.ls( cmds.polyInfo( m_nodes[i], nonManifoldVertices=True ), fl=True, long=True )
						if m_component:
							for n in range( 0, len( m_component )):
								m_temp.append( m_component[n] )
							if debug is True:
								print 'Founded non manifold vertexes on: %s' % m_nodes[i]
					else:
						m_items.update( { m_nodes[i]:[] } )
					if m_temp:
						m_items.update( { m_nodes[i]:m_temp } )
			m_nodes = cmds.ls( dag=True, type='nurbsCurve', ni=True, visible=True, long=True )
			m_null_curves = []
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_ignore and m_nodes[i] not in m_references:
					if cmds.attributeQuery( 'spans', n=m_nodes[i], exists=True ) and cmds.getAttr( '%s.spans' % m_nodes[i] ) < 2 and m_nodes[i] not in m_items:
						m_null_curves.append( m_nodes[i] )
			if m_null_curves:
				m_items.update( { "Zero spans nurbs curves":m_null_curves } )
		else:
			m_items = mayaNonManifoldGeometry
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				m_items_keys = m_items.keys()
				for i in range( 0, len( m_items_keys )):
					for n in range( 0, len( m_items[ m_items_keys[i] ] )):
						ml_deleteNode( m_items[ m_items_keys[i] ][n], debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 9, 10.
	#Slim setup 9.
	if mayaReAttachSlimNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 6, 0 )
		m_procedure = "Need slim assignment"
		m_items = []
		if mayaReAttachSlimNodes is True:
			m_nodes = cmds.ls( type=[ "transform", "mesh" ], long=True, ni=True )
			for i in range( 0, len( m_nodes )):
				if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=m_nodes[i], exists=True ) and m_nodes[i] not in m_items and m_nodes[i] not in m_references:
					m_items.append( m_nodes[i] )
					continue
				if cmds.nodeType( m_nodes[i] ) == "transform" and m_nodes[i] not in m_references:
					if cmds.attributeQuery( 'rman__torattr___slimShader', n=m_nodes[i], exists=True ) and m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
						continue
					if cmds.attributeQuery( 'rman__torattr___slimSurface', n=m_nodes[i], exists=True ) and m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
						continue
		else:
			m_items = mayaReAttachSlimNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				m_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
				for i in range( 0, len( m_items )):
					if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=m_items[i], exists=True ):
						m_ensemble = cmds.getAttr( '%s.rman__torattr___slimEnsemble' % m_items[i] )
						m_materials = ml_slimCmd( 'tc_ensembleProperty -id %s' % m_ensemble, debug=debug)
						if m_materials:
							m_materials = m_materials[0].split( ' ' )
							ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % m_items[i], debug=debug )
							ml_addRmanAttr( m_items[i], 'rman__torattr___slimSurface', m_materials[0], debug=debug )
							if m_materials[1:]:
								ml_addRmanAttr( m_items[i], 'rman__torattr___slimShader', ','.join( m_materials[1:] ), debug=debug )
					for n in range( 0, len( m_attributes )):
						ml_flatRmanAttr( m_items[i], m_attributes[n], debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Slim setup 1, 2, 3, 7, 8, 10, 11, 12, 13, 14, 15, 16.
	if slimHierarchySetup is not False:
		ml_print_currentTask( m_debug_messages, 20, 7, 0 )
		m_procedure = "Slim nodes hierarchy"
		m_items = []
		if slimHierarchySetup is True:
			m_nodes = ml_slimCmd( "tc_list -template GPSurface -return id", debug=debug )
			if m_nodes:
				m_nodes = m_nodes[0].split( " " )
				for i in range( 0, len( m_nodes )):
					if m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
		else:
			m_items = slimHierarchySetup
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				ml_slimCmd( "tc_globalSetup %s" % m_scenename, debug=debug )
				ml_slimCmd( "tc_combinePalettes %s" % m_scenename, debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 0.
	if mayaZeroTranslate is not False:
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		m_procedure = "Need to freeze transforms"
		m_items = []
		if mayaZeroTranslate is True:
			m_transforms = cmds.ls( dag=True, type="transform", long=True, ni=True )
			for i in range( 0, len( m_transforms )):
				if cmds.nodeType( m_transforms[i] ) == "transform" and m_transforms[i] not in m_references:
					m_translate = cmds.getAttr( "%s.t" % m_transforms[i] )[0]
					if m_transforms[i] not in m_undeletable and m_transforms[i] not in m_ignore:
						if ( round( m_translate[0], 2 ) != 0.0 or round( m_translate[1], 2 ) != 0.0 or round( m_translate[-1], 2 ) != 0.0 ):
							if not cmds.listConnections( m_transforms[i], source=True, destination=False ) and not cmds.getAttr( "%s.tx" % m_transforms[i], lock=True ) and not cmds.getAttr( "%s.ty" % m_transforms[i], lock=True ) and not cmds.getAttr( "%s.tz" % m_transforms[i], lock=True ) and not cmds.getAttr( "%s.t" % m_transforms[i], lock=True ):
								if m_transforms[i] not in m_items:
									m_items.append( m_transforms[i] )
									continue
		else:
			m_items = mayaZeroTranslate
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					ml_freeze( m_items[i] )
					if re.findall( "general_CT$", m_items[i] ):
						cmds.move( 0, 0, 0, m_items[i], rotatePivotRelative=True )
						ml_freeze( m_items[i] )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Slim setup 4.
	if slimRenameNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 5, 0 )
		m_procedure = "Slim synchronise names with maya"
		m_items = []
		if slimRenameNodes is True:
			m_nodes = ml_slimCmd( "tc_list -appearance _Attachable -return id", debug=debug )
			if m_nodes:
				m_nodes = m_nodes[0].split( " " )
				for i in range( 0, len( m_nodes )):
					if m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
		else:
			m_items = slimRenameNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				m_nodes = cmds.ls( dag=True, type="mesh", ni=True )
				m_cache = []
				for i in range( 0, len( m_nodes )):
					if m_nodes[i] not in m_cache:
						m_cache.append( m_nodes[i] )
						m_parent = cmds.listRelatives( m_nodes[i], parent=True, path=True )
						m_idList = ml_listAttached( m_nodes[i], id=True, debug=False )
						for n in range( 0, len( m_idList )):
							if m_idList[n] not in m_cache and m_idList[n] in m_items:
								m_cache.append( m_idList[n] )
								if len( m_items ) > 1:
									m_name = m_parent[0].split( '_' )[0]
								else:
									m_name = "root"
								ml_slimCmd( "tc_renameHierarchy " + m_name + " -id " + m_idList[n], debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 2.
	#Slim setup 5, 6.
	if slimUnusedNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 8, 0 )
		m_procedure = "Slim unused nodes"
		m_items = []
		if slimUnusedNodes is True:
			m_cache = []
			m_slim_nodes = ml_slimCmd( "tc_list -appearance _Attachable -return id", debug=debug )
			m_maya_nodes = ml_listAttached( cmds.ls( dag=True, type="mesh", ni=True, long=True ), id=True, debug=debug )
			if m_slim_nodes and m_maya_nodes:
				m_slim_nodes = m_slim_nodes[0].split( ' ' )
				for i in range( 0, len( m_maya_nodes )):
					if m_maya_nodes[i] not in m_slim_nodes:
						if debug is True:
							print "Failed to find %s slim node." % m_maya_nodes[i]
				for i in range( 0, len( m_slim_nodes )):
					if ml_slimCmd( "[ slim GetAppearances -id %s ] GetType" % m_slim_nodes[i], debug=debug )[0] == "ensemble":
						m_temp = ml_slimCmd( "tc_ensembleProperty -id %s" % m_slim_nodes[i], debug=debug )
						if m_temp:
							m_temp = m_temp[0].split( " " )
							for i in range( 0, len( m_temp )):
								m_cache.append( m_temp[i] )
				for i in range( 0, len( m_slim_nodes )):
					if m_slim_nodes[i] not in m_maya_nodes and m_slim_nodes[i] not in m_cache or ml_slimCmd( "[ slim GetAppearances -id %s ] GetType" % m_slim_nodes[i], debug=debug )[0] == "ensemble" and m_slim_nodes[i] not in m_items:
						m_items.append( m_slim_nodes[i] )
		else:
			m_items = slimUnusedNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					ml_slimCmd( "tc_delete %s" % m_items[i], debug=debug )
				ml_slimCmd( "tc_clear -disconnected", debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 3.
	if mayaCombine is not False:
		ml_print_currentTask( m_debug_messages, 20, 22, 0 )
		m_procedure = "Combine similar nodes"
		m_items = {}
		if mayaCombine is True:
			m_combine = []
			m_cache = []
			m_nodes = cmds.ls( dag=True, leaf=True, type="mesh", ni=True, visible=True, long=True )
			#m_nodes = [ cmds.listRelatives( m_nodes[i], parent=True, path=True )[0] for i in range( 0, len( m_nodes )) ]
			if m_nodes:
				for i in range( 0, len( m_nodes )):
					if m_nodes[i] not in m_references:
						m_temp = m_nodes[i]
						m_candidate = ''
						while True:
							m_parent = cmds.listRelatives( m_temp, parent=True, fullPath=True )
							if m_parent and not cmds.listConnections( m_parent ) and not cmds.listConnections( m_temp, source=True, destination=False ):
								m_candidate = m_temp
								m_temp = m_parent
								continue
							else:
								if m_parent and m_parent[0] not in m_combine:
									m_combine.append( m_parent[0] )
								break
			#Group similar mesh nodes.
			if m_combine:
				m_groups = {}
				for i in range( 0, len( m_combine )):
					m_nodes = cmds.ls( m_combine[i], dag=True, type="mesh", ni=True, visible=True, long=True )
					m_nodes_cache = []
					for n in range( 0, len( m_nodes )):
						m_bool = True
						for f in range( 0, len( m_combine )):
							if f != i and re.findall( "^" + "\|".join( m_combine[f].split( "|" )) + "\|", m_nodes[n] ) and not re.findall( "^" + "\|".join( m_combine[f].split( "|" )) + "\|", m_combine[i] ):
								m_bool = False
								break
						if m_bool is True:
							m_nodes_cache.append( m_nodes[n] )
					m_groups.update( { m_combine[i]:m_nodes_cache } )
				for i in range( 0, len( m_combine )):
					m_temp = m_groups[ m_combine[i] ]
					m_combine_exec = []
					m_cache_names = []
					if m_temp and len( m_temp ) > 1:
						for n in range( 0, len( m_temp )):
							if m_temp[n] not in str( m_combine_exec ) and not cmds.listConnections( m_temp[n], destination=False, source=True ):
								m_combine_cache = []
								if m_temp[n] not in m_cache:
									m_attachedID = ml_attachRmanQuery( m_temp[n] )
									for f in range( 0, len( m_temp )):
										m_law = True
										m_attachedID_temp = ml_attachRmanQuery( m_temp[f] )
										for s in range( 0, len( m_attachedID )):
											if m_attachedID[s] not in m_attachedID_temp:
												m_law = False
												break
										for s in range( 0, len( m_attachedID_temp )):
											if m_attachedID_temp[s] not in m_attachedID:
												m_law = False
												break
										if m_law is True and m_temp[f] not in m_combine_cache:
											m_combine_cache.append( m_temp[f] )
											m_cache.append( m_temp[f] )
								if m_combine_cache:
									m_combine_exec.append( m_combine_cache )
					if m_combine_exec:
						for n in range( 0, len( m_combine_exec )):
							if len( m_combine_exec[n] ) > 1:
								m_name = "%s_%s" % ( m_combine[i], len( m_cache_names ))
								m_items.update( { m_name : m_combine_exec[n] } )
								m_cache_names.append( m_name )
								if debug is True:
									print "Founded can be combined nodes: %s" % m_combine_exec[n]
		else:
			m_items = mayaSetDisplacementBoundForSlim
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				pass
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 1, 1, 6, 9, 10, 11
	#Modelling setup 5, 11
	if mayaRenderStats is not False:
		ml_print_currentTask( m_debug_messages, 20, 3, 0 )
		m_procedure = "Maya node attributes"
		m_items = []
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		if mayaRenderStats is True:
			m_nodes = cmds.ls( type=[ "transform", "mesh", "nurbsCurve" ], long=True, ni=True )
			for i in range( 0, len( m_nodes )):
				m_info = ml_setupAttributes( m_nodes[i], query=True, debug=False )
				if m_info and m_nodes[i] not in m_items and m_nodes[i] not in m_ignore:
					m_items.append( m_nodes[i] )
		else:
			m_items = mayaRenderStats
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				ml_setupAttributes( m_items, query=False, debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 8.
	if mayaSetDisplacementBoundForSlim is not False:
		ml_print_currentTask( m_debug_messages, 20, 9, 0 )
		m_procedure = "Displacement bound"
		m_items = []
		if mayaSetDisplacementBoundForSlim is True:
			m_slim_nodes = ml_slimCmd( "tc_findNodeByAttr enableDisplacement 0 id", debug=debug )
			m_maya_nodes = ml_listAttached( cmds.ls( dag=True, long=True, type="mesh", visible=True, ni=True ), node=True, debug=False )
			if m_slim_nodes:
				m_slim_nodes = m_slim_nodes[0].split( " " )
				for i in range( 0, len( m_maya_nodes )):
					m_law = False
					m_maya_id = ml_attachRmanQuery( m_maya_nodes[i] )
					for n in range( 0, len( m_maya_id )):
						if m_maya_id[n] in m_slim_nodes:
							m_law = True
							break
					if m_law is True and m_maya_nodes[i] not in m_items:
						m_items.append( m_maya_nodes[i] )
		else:
			m_items = mayaSetDisplacementBoundForSlim
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				m_slim_nodes = ml_slimCmd( "tc_findNodeByAttr enableDisplacement 0 id", debug=debug )
				if m_slim_nodes:
					m_slim_nodes = m_slim_nodes[0].split( " " )
					for i in range( 0, len( m_slim_nodes )):
						m_func = ml_slimCmd( "tc_list -id %s" % m_slim_nodes[i], debug=debug )
						if m_func:
							m_parm = ml_slimCmd( "tc_listAttr %s ^displacementbound$" % m_func[0], debug=debug )
							if m_parm:
								ml_slimCmd( "%s SetValue 0" % m_parm[0], debug=debug )
				for i in range( 0, len( m_items )):
					if cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=m_items[i], exists=True ):
						ml_setAttr( "%s.rman__riattr__displacementbound_sphere" % m_items[i], 0, debug=debug )
					ml_xml_file = ml_statistic( m_items[i], debug=debug )
					print ml_xml_file
					ml_bound = []
					m_xml_string = file( ml_xml_file, "r" ).read()
					m_xml = xml.etree.ElementTree.fromstring( m_xml_string )
					m_top_lvl = m_xml.findall( "*//stats" )
					for f in range( 0, len( m_top_lvl )):
						if m_top_lvl[f].get( "name" ) == "dispBound":
							m_bound_info = m_top_lvl[f].findall( "*" )
							for n in range( 0, len( m_bound_info )):
								if m_bound_info[n].get( "name" ) == "displacement":
									ml_bound.append( float( m_bound_info[n].text ))
									print m_bound_info[n].text
					if ml_bound:
						ml_bound = sum( ml_bound ) * 2.0
						if not cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=m_items[i], exists=True ):
							ml_addRmanAttr( m_items[i], "rman__riattr__displacementbound_sphere", ml_bound, debug=debug )
						else:
							ml_setAttr( "%s.rman__riattr__displacementbound_sphere" % m_items[i], ml_bound, debug=debug )
						if not cmds.attributeQuery( "rman__riattr__displacementbound_coordinatesystem", n=m_items[i], exists=True ):
							ml_addRmanAttr( m_items[i], "rman__riattr__displacementbound_coordinatesystem", "shader", debug=debug )
						else:
							cmds.setAttr( "%s.rman__riattr__displacementbound_coordinatesystem" % m_items[i], "shader", type="string" )
				m_render_trash = cmds.ls( type="RenderMan" )
				if m_render_trash:
					cmds.delete( m_render_trash )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 8.
	if mayaNormalDirection is not False:
		ml_print_currentTask( m_debug_messages, 20, 10, 0 )
		m_procedure = "Normals direction"
		m_items = []
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		if mayaNormalDirection is True:
			m_nodes = cmds.ls( type='mesh', dag=True, ni=True, long=True )
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_ignore and m_nodes[i] not in m_references:
					m_parents = cmds.listRelatives( m_nodes[i], allParents=True, path=True )
					m_scale = [ cmds.getAttr( '%s.scale' % m_parents[n] ) for n in range( 0, len( m_parents )) ]
					if '-' in str( m_scale ) or cmds.getAttr( '%s.opposite'  % m_nodes[i] ) and m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
						continue
					m_components = cmds.polyInfo( m_nodes[i], nonManifoldVertices=True )
					if m_components:
						m_components = cmds.ls( m_components, fl=True, long=True )
						for n in range( 0, len( m_components )):
							if len( cmds.ls( cmds.polyListComponentConversion( m_components[n], fromVertex=True, toEdge=True ), fl=True, long=True )) == len( cmds.ls( cmds.polyListComponentConversion( m_components[n], fromVertex=True, toFace=True ), fl=True, long=True )) and m_nodes[i] not in m_items:
								m_items.append( m_nodes[i] )
								break
		else:
			m_items = mayaNormalDirection
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					cmds.polyNormal( m_items[i], normalMode=2, userNormalMode=1 )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 0.
	if mayaShadingNode is not False:
		ml_print_currentTask( m_debug_messages, 20, 12, 0 )
		m_procedure = "Default shading"
		m_items = []
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		if mayaShadingNode is True:
			m_nodes = cmds.ls( type="mesh", long=True, ni=True )
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_ignore and m_nodes[i] not in m_references:
					m_connections = cmds.listConnections( m_nodes[i], plugs=True, connections=True, destination=True )
					m_law = True
					for n in range( 0, len( m_connections )):
						if re.findall( "%s.instObjGroups$" % m_nodes[i].split( "|" )[-1], m_connections[n] ) and "initialShadingGroup" in cmds.listConnections( "%s.instObjGroups" % m_nodes[i] ):
							m_law = False
							break
					if m_law is True:
						if m_nodes[i] not in m_items:
							m_items.append( m_nodes[i] )
		else:
			m_items = mayaShadingNode
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					cmds.hyperShade( m_items[i], assign="lambert1" )
					cmds.sets( m_items[i], edit=True, forceElement='initialShadingGroup' )
					if debug is True:
						print 'hyperShade -assign lambert1 %s' % str( m_items[i] )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 0.
	if mayaBakeColorsFromSlim is not False:
		ml_print_currentTask( m_debug_messages, 20, 13, 0 )
		m_procedure = "Bake slim to color"
		m_result.update( { m_procedure:[]  } )
		if query is False:
			pass
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Texture setup 0.
	if slimUniqueifyNodes is not False:
		m_procedure = "Uniqueify scene slim id"
		m_items = ml_slimCmd( "tc_list -appearance _Attachable", debug=debug )
		if m_items:
			m_result.update( { m_procedure:[]  } )
		if query is False:
			ml_uniqueify( debug=debug )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 4.
	if mayaDeleteHistoryNodes is not False:
		ml_print_currentTask( m_debug_messages, 20, 15, 0 )
		m_procedure = "History"
		m_items = []
		m_ignore = []
		if "Unused maya nodes" in m_result.keys():
			m_ignore = m_result[ "Unused maya nodes" ]
		if mayaDeleteHistoryNodes is True:
			m_nodes = cmds.ls( dag=True, type=[ 'mesh' ], long=True, ni=True, visible=True )
			for i in range( 0, len( m_nodes )):
				if cmds.objExists( m_nodes[i] ) and m_nodes[i] not in m_ignore and m_nodes[i] not in m_references:
					mlt_rig = False
					ml_connections = ml_listConnections( m_nodes[i], debug=False, source=True, destination=True, type=[ 'nurbsCurve', 'blendShape', 'animCurveUU', 'animCurveUA', 'animCurveUL' ] )
					if ml_connections:
						mlt_rig = True
						break
					if mlt_rig is False:
						m_shortName = cmds.ls( m_nodes[i] )[0]
						m_cache = cmds.bakePartialHistory( m_nodes[i], preDeformers=True, preCache=True, query=True )
						m_history = cmds.listHistory( m_nodes[i] )
						if m_history:
							m_history = [ m_history[n] for n in range( 0, len( m_history )) if m_history[n] != "initialShadingGroup" and m_history[n] != m_shortName ]
						m_connections = cmds.listConnections( m_nodes[i], source=True, destination=False )
						if m_connections:
							m_connections = [ m_connections[n] for n in range( 0, len( m_connections )) if m_connections[n] != "initialShadingGroup" and m_connections[n] != m_shortName ]
						if m_history and len( m_history ) > 1 or m_cache and m_connections and m_nodes[i] not in m_items:
							m_items.append( m_nodes[i] )
		else:
			m_items = mayaDeleteHistoryNodes
		if m_items:
			m_result.update( { m_procedure:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ):
						cmds.bakePartialHistory( m_items[i], preDeformers=True, preCache=True )
						cmds.delete( m_items[i], constructionHistory=True )
						if debug is True:
							print 'bakePartialHistory -preCache -preDeformers -constructionHistory %s;' % m_items[i]
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 6, 13.
	#Texture setup 5, 13, 7, 8, 12.
	if mayaSaveScene is not False:
		ml_print_currentTask( m_debug_messages, 20, 16, 0 )
		if query is False:
			ml_exportScene( ml_file, cmds.ls([ '|root', 'mtorPartition' ], long=True), version=True )
	#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	#Modelling setup 0.
	if mayaMakeProxy is not False:
		if query is False:
			ml_makeProxy.ml_makeProxy()
	return m_result