def chekEdges():
    import maya.cmds as cmds
    nameF = cmds.ls(sl=True)
    if not len(nameF):
        nameF = cmds.ls(type='mesh')
    cmds.select(clear=True)
    for n in nameF: 
        edgeNumber = cmds.polyEvaluate(n,e=True)
        points = cmds.polyCrease(str(n)+'.e[0:'+str(edgeNumber-1)+']',query=True,value=True)
        for p in range(0,len(points)):
            if points[p]>10 or points[p]<-10:
                cmds.select(str(n)+".e["+str(p)+"]",add=True)
                print(str(p) + " i edge "+ str(points[p]))

def repareEdges():
    import maya.cmds as cmds
    nameF = cmds.ls(sl=True)
    if not len(nameF):
        nameF = cmds.ls(type='mesh')
    for n in nameF: 
        edgeNumber = cmds.polyEvaluate(n,e=True)
        points = cmds.polyCrease(str(n)+'.e[0:'+str(edgeNumber-1)+']',query=True,value=True)
        for p in range(0,len(points)):
            if points[p]>10 or points[p]<-10:
                print(str(p) + " i edge "+ str(points[p]))
                newVar = cmds.polyInfo( str(n)+".e["+str(p)+"]",ev=True )
                listVertex = newVar[0].split(" ")
                naiden=""
                nah=0
                for v in range(len(listVertex)):
                    if nah and len(listVertex[v])>1:
                        naiden=listVertex[v]
                        break
                    if len(listVertex[v].split(":"))>1:
                        nah=1
                print newVar[0]+" naiden: "+naiden
                #cmds.select(str(n)+".vtx["+listVertex[2]+"]",str(n)+".vtx["+listVertex[3]+"]",r=True)
                newVarOneV = cmds.polyInfo( str(n)+".vtx["+str(naiden)+"]",ve=True )
                listVertex = newVarOneV[0].split(" ")
                naiden1=""
                naiden2=""
                vt=0
                nah=0        
                for v in range(len(listVertex)):
                    if nah and len(listVertex[v])>1:
                        naiden1=listVertex[v]
                        vt=v
                        break        
                    if len(listVertex[v].split(":"))>1:
                        nah=1                
                for v in range(len(listVertex)):
                    if v > vt and len(listVertex[v])>1:
                        naiden2=listVertex[v]
                        break  
                print newVarOneV[0]+" naiden1: "+naiden1+" naiden2: "+naiden2
                valueOfThisPoints = cmds.polyCrease(str(n)+".e["+str(naiden1)+"]",query=True,value=True)
                if str(valueOfThisPoints[0]) != "inf":
                    print "one:"+str(valueOfThisPoints[0])
                    print "okey:   "+str(valueOfThisPoints)
                    if valueOfThisPoints[0]==-1:
                        valueOfThisPoints[0]=0
                    cmds.polyCrease(str(n)+".e["+str(p)+"]",value=valueOfThisPoints[0])
                else:
                    valueOfThisPoints = cmds.polyCrease(str(n)+".e["+str(naiden2)+"]",query=True,value=True)
                    if str(valueOfThisPoints[0]) != "inf":
                        print "two: " + str(n)+".e["+str(p)+"]"
                        print "okey:   "+str(valueOfThisPoints)
                        if valueOfThisPoints[0]==-1:
                            valueOfThisPoints[0]=0                
                        cmds.polyCrease(str(n)+".e["+str(p)+"]",value=valueOfThisPoints[0])

    '''import maya.cmds as cmds
    nameF = cmds.ls(sl=True)
    edgeNumber = cmds.polyEvaluate(nameF,e=True)
    points = cmds.polyCrease(str(nameF[0])+'.e[0:'+str(edgeNumber-1)+']',query=True,value=True)
    for p in range(0,len(points)):
        if points[p]>10 or points[p]<-10:
            print(str(p) + " i edge "+ str(points[p]))
            newVar = cmds.polyInfo( str(nameF[0])+".e["+str(p)+"]",ev=True )
            listVertex = newVar[0].split("  ")
            #cmds.select(str(nameF[0])+".vtx["+listVertex[2]+"]",str(nameF[0])+".vtx["+listVertex[3]+"]",r=True)
            newVarOneV = cmds.polyInfo( str(nameF[0])+".vtx["+str(listVertex[1])+"]",ve=True )
            listVertex = newVarOneV[0].split(" ")
            valueOfThisPoints = cmds.polyCrease(str(nameF[0])+".e["+str(listVertex[6])+"]",query=True,value=True)
            if valueOfThisPoints > -1:
                print "okey:   "+str(valueOfThisPoints)
                cmds.polyCrease(str(nameF[0])+".e["+str(p)+"]",value=valueOfThisPoints)
            else:
                valueOfThisPoints = cmds.polyCrease(str(nameF[0])+".e["+str(listVertex[7])+"]",query=True,value=True)
                if valueOfThisPoints > -1:
                    print "okey:   "+valueOfThisPoints
                    cmds.polyCrease(str(nameF[0])+".e["+str(p)+"]",value=valueOfThisPoints)
    '''
'''
def copyCrease():
    import maya.cmds as cmds
    global copyBuffer
    nameF = cmds.ls(sl=True)
    edgeNumber = cmds.polyEvaluate(e=True)
    copyBuffer = cmds.polyCrease(str(nameF[0])+".e[0:"+str(edgeNumber-1)+"]",q=True,v=True);

def pasteCrease():
    import maya.cmds as cmds
    nameF = cmds.ls(sl=True)
    edgeNumber = cmds.polyEvaluate(e=True)
    for ed in range(0,len(copyBuffer)):
        if copyBuffer[ed] != -1:
            cmds.polyCrease(str(nameF[0])+".e["+str(ed)+"]",v=copyBuffer[ed])
'''

def copyCrease_path_x(path):
	import maya.cmds as cmds
	import re
	copyBufferF=[]
	nameF = cmds.ls(sl=True,l=True,dag=True,ni=True,lf=True,type="mesh")
	for F in nameF:
		copyBufferF.append("\n"+F+"\n")
		edgeNumber = cmds.polyEvaluate(F,e=True)
		copyBuffer = cmds.polyCrease(str(F)+".e[0:"+str(edgeNumber-1)+"]",q=True,v=True);
		a={}
		for cB in range(0,len(copyBuffer)):
			if copyBuffer[cB]!= -1:
				#print str(copyBuffer[cB])+ "  :  " + str(cB)
				a[str(cB)]=str(copyBuffer[cB])
		
		listAllEdVertex = cmds.polyInfo(F,ev=True)
		b = {}
		for i in range(0, len(listAllEdVertex)):
			listNum = re.split('\D+', listAllEdVertex[i])
			lst2 = [x for x in listNum if x != '']
			#print lst2
			b[lst2[0]] = [lst2[1],lst2[2]]
		
		for i in range(0, len(a)):
			#print " ".join(b[a.keys()[i]]) + " = " + str(a[a.keys()[i]])
			copyBufferF.append(b[a.keys()[i]][0]+" "+b[a.keys()[i]][1]+" "+a[a.keys()[i]]+"\n")

		
	out_file = open(path, "wt")
	for item in copyBufferF:
		out_file.write(item)
	out_file.close()

def pasteCrease_path_x(path):
	import maya.cmds as cmds
	import re

	copyBuffer=[]
	objectBuffer=[]

	fileF = open(path, "rt")
	nextName=0
	n=0
	while 1:
		line = fileF.readline()
		if not line:
			break
		if line == "\n":
			nextName=1
		elif nextName==1:    
			objectBuffer.append([line.strip(),str(n)])
			nextName=0
		else:
			n=n+1
			lineRez=line.split(" ")
			copyBuffer.append([lineRez[0],lineRez[1],lineRez[2].strip()])
			
	fileF.close()
	#print copyBuffer

	for F in range(0, len(objectBuffer)):    
		objName=""
		#if cmds.objExists(objectBuffer[0][0]):
		#    objName = objectBuffer[0][0]
		nameFindInObject = cmds.ls(sl=True,l=True,dag=True,ni=True,lf=True,type="mesh")
		for nFIO in nameFindInObject:
			oneEr=objectBuffer[F][0]
			oneErRez = []
			for tr in oneEr.split("|"):
				oneErRez.append(tr.split(":")[-1])
			oneErRez = "|".join(oneErRez)

			twoEr=nFIO
			twoErRez = []
			for tr in twoEr.split("|"):
				twoErRez.append(tr.split(":")[-1])
			twoErRez = "|".join(twoErRez)

			if len(oneErRez)>len(twoErRez):
				if oneErRez[len(oneErRez)-len(twoErRez):] == twoErRez:
				   objName=nFIO
				   break
			elif len(oneErRez)<len(twoErRez):
				if twoErRez[len(twoErRez)-len(oneErRez):] == oneErRez:
				   objName=nFIO
				   break
			else:
				if oneErRez == twoErRez:
				   objName=nFIO
				   break
			
		if objName != "":
			listAllEdVertex = cmds.polyInfo(objName,ev=True)

			b = []
			for i in range(0, len(listAllEdVertex)):
				listNum = re.split('\D+', listAllEdVertex[i])
				lst2 = [x for x in listNum if x != '']
				b.append([lst2[0],lst2[1],lst2[2]])
			
			rezList=[]
			startIndex=int(objectBuffer[F][1])
			endIndex=len(copyBuffer)
			if (len(objectBuffer)-1)>F:
				endIndex=int(objectBuffer[F+1][1])

			for i in range(startIndex, endIndex):
				for j in range(0, len(b)):
					if (copyBuffer[i][0] == b[j][1] and copyBuffer[i][1] == b[j][2]) or (copyBuffer[i][0] == b[j][2] and copyBuffer[i][1] == b[j][1]):
						rezList.append([b[j][0],copyBuffer[i][2]])
						break
			
			nameF = cmds.ls(sl=True)
			for ed in range(0,len(rezList)):
					cmds.polyCrease(str(objName)+".e["+rezList[ed][0]+"]",v=float(rezList[ed][1]))
