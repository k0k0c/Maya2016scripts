import maya.cmds as cmds
import re
def ml_rmanAttributesToDeformer():
	m_nodes = cmds.ls( type="mesh", ni=True, visible=True, untemplated=True, long=True )
	m_expression = re.compile( "^rman__" )
	for i in range( 0, len( m_nodes )):
		#Validate deformation nodes.
		m_history = cmds.listHistory( "%s.inMesh" % m_nodes[i] )
		m_filename_n = cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ) and cmds.referenceQuery( m_nodes[i], filename=True ) or ""
		m_bool = False
		if m_history:
			for c in range( 0, len( m_history )):
				if cmds.nodeType( m_history[c] ) == "mesh":
					m_filename_d = cmds.referenceQuery( m_history[c], isNodeReferenced=True ) and cmds.referenceQuery( m_history[c], filename=True ) or ""
					if m_filename_n != m_filename_d or m_filename_d == "":
						m_bool = True
						break
		else:
			continue
		#Transfer rman attributes from original nodes.
		if m_bool is True:
			if m_history:
				m_meshes = cmds.ls( m_history, type="mesh" )
				for m in range( 0, len( m_meshes )):
					m_attributes = cmds.listAttr( m_meshes[m], settable=True )
					m_attributes = [ m_attributes[a] for a in range( 0, len( m_attributes )) if m_expression.findall( m_attributes[a] )]
					for a in range( 0, len( m_attributes )):
						if not cmds.attributeQuery( m_attributes[a], n=m_nodes[i], exists=True ):
							print "ml_rmanAttributesToDeformer:", m_nodes[i]
							m_type = cmds.getAttr( "%s.%s" % ( m_meshes[m], m_attributes[a] ), type=True )
							m_value = cmds.getAttr( "%s.%s" % ( m_meshes[m], m_attributes[a] ))
							if m_type in [ "string" ]:
								cmds.addAttr( m_nodes[i], longName=m_attributes[a], dt=m_type )
								cmds.setAttr( "%s.%s" % ( m_nodes[i], m_attributes[a] ), m_value, type=m_type )
							elif m_type not in [ "enum", "int", "float", "long", "double", "bool", "short", "byte", "char", "doubleAngle", "doubleLinear" ]:
								cmds.addAttr( "%s.%s" % ( m_nodes[i], m_attributes[a] ), m_value, type=m_type )
								cmds.setAttr( "%s.%s" % ( m_nodes[i], m_attributes[a] ), m_value, type=m_type )
							else:
								cmds.addAttr( m_nodes[i], longName=m_attributes[a], at=m_type )
								cmds.setAttr( "%s.%s" % ( m_nodes[i], m_attributes[a] ), m_value )