#/usr/autodesk/maya2013-x64/bin/maya -batch -proj /renderServer/Project/UrfinJuse/assets/props/TykvaZhevunov -command "python(\"import ml_makeProxy; ml_makeProxy.ml_makeProxy()\")" -file /Server-3d/Project/UrfinJuse/assets/props/TykvaZhevunov/maya/tykvaZhevunov.mb
import sys
import os
import re
import glob    
import maya.cmds as cmds
if not cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ):
	cmds.loadPlugin( "RenderMan_for_Maya" )
if not cmds.pluginInfo( "AbcExport", query=True, loaded=True ):
	cmds.loadPlugin( "AbcExport" )
if not cmds.pluginInfo( "AbcImport", query=True, loaded=True ):
	cmds.loadPlugin( "AbcImport" )
if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
	import rfm.passes
import maya.mel as mel
import shutil
import init_slim

def ml_makeProxy():
    OSTYPE3D = sys.platform
    if OSTYPE3D == "win32":
            OSTYPE3D="//Server-3d/Project/"
    else:
            OSTYPE3D="/Server-3d/Project/"


    def clearManifold():
        selectNonmanifold = mel.eval("polyCleanupArgList 3 { \"1\",\"2\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"1e-05\",\"0\",\"1e-05\",\"0\",\"1e-05\",\"0\",\"1\",\"0\" }")
        skolko=50
        seychas=0
        while seychas < skolko:
            for sN in selectNonmanifold:
                allBadPoly = cmds.polyListComponentConversion(sN,tf=True)
                cmds.delete(allBadPoly)
            seychas = seychas + 1
            selectNonmanifold = mel.eval("polyCleanupArgList 3 { \"1\",\"2\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"1e-05\",\"0\",\"1e-05\",\"0\",\"1e-05\",\"0\",\"1\",\"0\" }")
            if selectNonmanifold == []:
                seychas = 60

    if not cmds.pluginInfo("AbcExport",query=True,l=True):
        try:
            cmds.loadPlugin("AbcExport")
        except:        
            print("\nNe gruzitsya AbcExport!!!!\n")
            return        
    if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
        try:
            cmds.loadPlugin("RenderMan_for_Maya")
        except:
            print("\nNe gruzitsya RenderMan_for_Maya!!!!\n")
            return            

    expressionDirectoryPath = re.compile("^(/renderServer/Project/)|(R:/)|(//renderServer/Project/)", re.IGNORECASE)
    projectDir=mel.eval("rman workspace GetProjDir")

    pathToServer3d=expressionDirectoryPath.sub(OSTYPE3D,projectDir)+"maya/"
    stageVar = mel.eval("rman getvar STAGE")
    addString=""
    temp = cmds.file(query=True, sceneName=True).split("/")
    scenepath = "/".join(temp[:-1])+"/"
    scenename = temp[-1]
    scenenameonly=temp[-1].split(".")[:-1]
    proxyMatch = re.compile(".*proxy.*", re.IGNORECASE)
    if proxyMatch.match(scenename) or len(scenename.split("_"))>2:
        print("\nOtkroyte original a ne proxy!!!! "+scenepath+"\n")
        return

    expressionBothServers = re.compile("^/{1,2}Server-3d/Project/|^/{1,2}renderServer/Project/", re.IGNORECASE)
    ralativeRMSProjectFile = expressionBothServers.sub("",scenepath)
    ralativePathToFile = expressionBothServers.sub("",projectDir)+"maya/"
    if ralativeRMSProjectFile != ralativePathToFile:
        print("\nfile nahoditsya ne v korne asseta!!!! "+scenepath+"\n")
        return    


    init_slim.init_slim()

    if mel.eval("currentRenderer") != "renderMan":
        mel.eval("setCurrentRenderer renderMan")     

    if not cmds.objExists("rmanFinalGlobals"):
        mel.eval("rmanCreateGlobals()")
            
    cmds.currentTime(1)
    mel.eval("rman setPref DisableCacheInZip 0")
    settings = rfm.passes.GetDefaultSettings()
    settings[0].SetAttr("rman__riopt__rib_format","binary")
    settings[0].SetAttr("rman__riopt__rib_compression","gzip")


    geo_normal=cmds.ls("|root|geo_normal")
    if len(geo_normal) != 1:
        print("\nCHTO BLIN S geo_normal!!!!\n")
        return    
        
    rig=cmds.ls("|root|rig")
    if len(rig) != 1:
        print("\nGde GLAVNYI KONTROL!!!!\n")
        return    

    '''general_CTShapes=cmds.ls("|root|rig|general_CT|*",dag=True,lf=True)
    if general_CTShapes != []:
        cmds.delete(general_CTShapes)
    else:
        print("\nCHTO BLIN S general_CT!!!!\n")
        #return    
    '''

    conList=[]
    grpList=[]
    rigProxyList=cmds.ls("|root|rig|*",dag=True,tr=True,l=True)
    for rP in rigProxyList:
        temp = cmds.listConnections (rP, s=False,d=True)
        if temp is not None:
            temp=list(set(temp))
            for t in temp:
                temp2 = cmds.listConnections (t, s=False,d=True)
                if temp2 is not None:
                    temp2=list(set(temp2))
                    for t2 in temp2:
                        if cmds.ls(t2,dag=True,type="mesh",ni=True):
                            conList.append(cmds.ls(rP,l=True)[0])
                            grpList.append(cmds.ls(t2,l=True)[0])


    temp = []
    for i in conList:
           if i not in temp:
              temp.append(i)
    print len(temp), "==", len(conList)
    temp2 = []
    for i in grpList:
           if i not in temp2:
              temp2.append(i)
    print len(temp2), "==", len(grpList)
              
    conList=temp
    grpList=temp2
    rezRibArchiveRez=[]
    for gL in range(0,len(grpList)):
        for gL2 in grpList:
            if grpList[gL] in gL2 and grpList[gL] != gL2:
                print(gL2+" in "+grpList[gL])
                print("proxy")
                mel.eval("rmanAddAttr "+gL2+" rman__torattr___invis 2")
            else:
                mel.eval("rmanAddAttr "+gL2+" rman__torattr___invis 0")
        #tempRoot=cmds.parent(grpList[gL], conList[gL])[0]
        tempRootInitional=cmds.parent(grpList[gL], conList[gL])[0]
        tempRoot=cmds.rename(tempRootInitional,scenenameonly[0]+"_"+tempRootInitional)		

        paths=glob.glob(projectDir+"renderman/ribarchives/"+tempRoot+"RIBArchiveShape*")
        for path in paths:
            if os.path.isdir(path):
                try:
                    print("Remove tree: " + path)
                    shutil.rmtree(path)
                except:
                    print("ERROR EXEPTION REMOVE TREE: " + path)
            else:        
                try:
                    print("Remove file: " + path)            
                    os.remove(path)    
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + path)            		
					
        print("rezRibArchiveRez.append(mel.eval(\"$ddd[0]=\\\""+tempRoot+"\\\";rmanCreateRIBArchives $ddd 1 1 1\")[0])")    
        rezRibArchiveRez.append(mel.eval("$ddd[0]=\""+tempRoot+"\";rmanCreateRIBArchives $ddd 1 1 1")[0])
        tempRoot=cmds.rename(tempRoot,tempRootInitional)
        cmds.setAttr(rezRibArchiveRez[-1]+".crew","",type="string")
        cmds.setAttr(rezRibArchiveRez[-1]+".displayStyle",0)
        tempRoot2=cmds.parent(tempRoot, "|".join(grpList[gL].split("|")[:-1]))[0]


    clearManifold()
    rezProxyMeshList=[None]*len(grpList)
    rezRibArchiveRezParent=[None]*len(rezRibArchiveRez)
    for i in range(len(grpList)-1, -1, -1):
        meshList=cmds.ls(grpList[i],dag=True,type="mesh",l=True,ni=True)
        proxyMesh=""
        if len(meshList)>1:
            proxyMesh=cmds.polyUnite(meshList,ch=False,n=conList[i].split("|")[-1]+"Proxy")[0]
        elif len(meshList)==1:
            print(meshList)
            proxyMesh=cmds.rename("|".join(meshList[0].split("|")[:-1]),conList[i].split("|")[-1]+"Proxy")
        
        if proxyMesh != "":
            #proxyMeshShape=cmds.listRelatives(proxyMesh, shapes=True)[0]
            cmds.select(proxyMesh)
            mel.eval("polyCleanupArgList 3 { \"0\",\"1\",\"0\",\"0\",\"0\",\"1\",\"1\",\"0\",\"1\",\"1e-05\",\"1\",\"1e-05\",\"0\",\"1e-05\",\"0\",\"1\",\"1\" }")
            polyCount = cmds.polyEvaluate(proxyMesh, triangle=True)
            reduceValue=50
            var = [polyCount <= 100, polyCount <= 250 and polyCount > 100, polyCount <= 500 and polyCount > 250, polyCount <= 1000 and polyCount > 500, polyCount <= 1500 and polyCount > 1000, polyCount <= 3000 and polyCount > 1500, polyCount <= 5000 and polyCount > 3000, polyCount <= 10000 and polyCount > 5000, polyCount <= 100000 and polyCount > 10000, polyCount <= 1000000 and polyCount > 100000, polyCount > 1000000]
            result = [30, 30, 40, 40, 50, 50, 60, 60, 80, 85, 90][var.index(True)]
            colorSets=cmds.polyColorSet(proxyMesh,q=True,acs=True)
            if colorSets is not None:
                for cS in colorSets:
                    if cS == "RMSet":
                        cmds.polyColorSet(proxyMesh,delete=True,colorSet="RMSet")
            clearManifold()            	    
            cmds.polyReduce(proxyMesh, percentage=result, uvWeights=0, colorWeights=0, keepQuadsWeight=1, keepBorder=1, keepMapBorder=0, keepOriginalVertices=1, keepHardEdge=0, compactness=0, triangulate=1, replaceOriginal=1, cachingReduce=0, constructionHistory=False)

            rezRibArchiveRezParent[i]=cmds.parent(cmds.listRelatives(rezRibArchiveRez[i], parent=True)[0], conList[i])[0]
            temp=cmds.parent(proxyMesh, rezRibArchiveRezParent[i])[0]
            #temp=cmds.parent(proxyMesh, conList[i])[0]
            toDoskonectAttr = cmds.listConnections (temp+".translateX", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".translateY", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".translateZ", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".rotateX", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".rotateY", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".rotateZ", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".scaleX", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".scaleY", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            toDoskonectAttr = cmds.listConnections (temp+".scaleZ", s=True,d=False,c=True,p=True)
            if toDoskonectAttr is not None:
                for tD in range(0,len(toDoskonectAttr),2):
                    cmds.disconnectAttr(toDoskonectAttr[tD+1],toDoskonectAttr[tD]) 
            cmds.makeIdentity(temp,apply=True,t=1,r=1,s=1,n=0)
            #rezRibArchiveRezParent[i]=cmds.parent(rezRibArchiveRez[i], conList[i], add=True, shape=True)[0]
            #temp=cmds.parent(cmds.listRelatives(temp, shapes=True)[0], conList[i], add=True, shape=True)[0]
            
            fullPath = mel.eval("rman workspace GetProdDir")+"/"+"/".join(cmds.getAttr(cmds.ls(rezRibArchiveRez[i])[0]+".filename").split("/")[:-1])
            if not os.path.exists(fullPath+"/"+rezRibArchiveRez[i]+"/cache"):
                os.makedirs(fullPath+"/"+rezRibArchiveRez[i]+"/cache")
            print("AbcExport -j \"-frameRange 1 1 -noNormals -ro -root "+proxyMesh+" -file "+fullPath+"/"+rezRibArchiveRez[i]+"/cache/"+rezRibArchiveRez[i]+".abc\"")    
            mel.eval("AbcExport -j \"-frameRange 1 1 -noNormals -ro -root "+proxyMesh+" -file "+fullPath+"/"+rezRibArchiveRez[i]+"/cache/"+rezRibArchiveRez[i]+".abc\"")
            
            gpuNode = cmds.createNode('gpuCache',n=grpList[i].split("|")[-1]+"RibArchiveGPUCacheShape",parent=rezRibArchiveRezParent[i])
            #gpuNode = cmds.createNode('gpuCache',n=grpList[i].split("|")[-1]+"RibArchiveGPUCacheShape",parent=conList[i])
                #print("cmds.setAttr(\""+gpuNode+".cacheFileName\", \""+fullPath+"/"+rezRibArchiveRez[i]+"/cache/"+rezRibArchiveRez[i]+".abc\", type=\"string\")")
            cmds.setAttr(gpuNode+".cacheFileName", fullPath+"/"+rezRibArchiveRez[i]+"/cache/"+rezRibArchiveRez[i]+".abc", type="string")
            cmds.delete(proxyMesh)





    #zahuta ot riga, tractor ili bath, force ili check, vydeleniya


    for i in cmds.ls("|root|*"):
        if i != "rig":
            cmds.delete(i)



    rezscenename = ""
    temp = scenename.split("_")
    if len(temp)==1:
        rezscenename = scenename.split(".")[0]+"_proxy"
    else:
        rezscenename = temp[0]+"_"+temp[-1].split(".")[0]+"Proxy"

    if os.path.exists(scenepath+rezscenename+".mb"):
        try:
            os.remove(scenepath+rezscenename+".mb")    
        except:
            print("ERROR EXEPTION REMOVE FILE: " + scenepath+rezscenename+".mb\n")
            return

    if os.path.exists(scenepath+rezscenename+".ma"):
        try:
            os.remove(scenepath+rezscenename+".ma")    
        except:
            print("ERROR EXEPTION REMOVE FILE: " + scenepath+rezscenename+".ma\n")
            return

    cmds.select("root")
    print("SAVE PROXY FILE: " + scenepath+rezscenename+".mb")
    cmds.file(scenepath+rezscenename+".mb", force=True, es=True, options="v=0;", typ="mayaBinary")






