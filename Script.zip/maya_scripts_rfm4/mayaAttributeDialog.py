import site
import json
import codecs
import glob
import re
import main
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

   
def uniqueTransforms( reference ):
    import maya.cmds as cmds
    result = []
    uniqueTransforms = []
    nodes = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    transforms = cmds.ls( nodes, dag=True, long=True )
    for transform in transforms:
        unique = True
        childs = cmds.ls( transform, dag=True )
        for child in childs:
            if cmds.referenceQuery( child, isNodeReferenced=True ):
                filename = cmds.referenceQuery( child, filename=True )
                if reference != filename:
                    unique = False
                    break
            else:
                unique = False
                break
        if unique is True:
            uniqueTransforms.append( transform )
    for uniqueTransform in uniqueTransforms:
        parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
        if parent:
            parent = parent[0]
            if parent not in uniqueTransforms:
                result.append( uniqueTransform )
        else:
            result.append( uniqueTransform )
    return result

class SpinBoxDelegate(QtGui.QItemDelegate):
    sT=QtCore.QVariant(0)
    sN=QtCore.QVariant(-1)

    #def __init__(self):
    #        super(QtGui.QItemDelegate, self).__init__()

    #def __init__(self,var):
    #        QtGui.QItemDelegate.__init__(self)
    #        sT=var

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        imageOffset=0
        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)
        elif index.data(QtCore.Qt.UserRole+1).toInt()[0] == 2:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.Dense6Pattern)
            painter.fillRect(option.rect,brush)
            #painter.drawImage( QtCore.QRect(option.rect.x()+2,option.rect.y()+2,option.rect.height()-4,option.rect.height()-4),QtGui.QImage("/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/arrows-right-circular-icon.png"))
            #imageOffset=option.rect.height()

        one_width = 2
        if self.sT == 2:
            if index.data(QtCore.Qt.UserRole).toString()!="":
                textType = " ["+index.data(QtCore.Qt.UserRole).toString()[0:3]+"] "
                one_width = painter.fontMetrics().width(textType)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textType)
            elif index.data(QtCore.Qt.UserRole+2).toString()!="":
                textLoadedDraw=" ["+index.data(QtCore.Qt.UserRole+2).toString()+"] "
                one_width = painter.fontMetrics().width(textLoadedDraw)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textLoadedDraw)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        text_width = painter.fontMetrics().width(text)
        painter.drawText( option.rect.x()+one_width+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)

        overWidth=0
        '''if index.data(QtCore.Qt.UserRole+6).toString()!="":
            overText="    over    "
            overWidth = painter.fontMetrics().width(overText)
            painter.drawText( option.rect.x()+option.rect.width()-overWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,overText)
        '''
        proxyWidth=0
        if index.data(QtCore.Qt.UserRole+5).toString()!="":
            proxyText="     ["+index.data(QtCore.Qt.UserRole+5).toString()+"]"
            proxyWidth = painter.fontMetrics().width(proxyText)
            if option.rect.width()-overWidth-proxyWidth>one_width+imageOffset+text_width:
                painter.drawText( option.rect.x()+option.rect.width()-overWidth-proxyWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,proxyText)



        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class SpinBoxDelegate2(QtGui.QItemDelegate):
    sN=QtCore.QVariant(-1)

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        painter.drawText( option.rect.x()+2,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)


        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class Window(QtGui.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins(8,8,8,8)


        self.selectedFiles=[]
        self.selectedRootNodes=[]
        self.onlyGetData=0
        self.tree=[]
        self.twoWidget = QtGui.QWidget()
        self.AEgroupBoxFind = QtGui.QGridLayout(self.twoWidget)
        self.AEgroupBoxFind.setContentsMargins(10,0,0,0)
        self.AEgroupBowCheckBox = QtGui.QCheckBox(" Alembic export ")
        self.AEgroupBowCheckBox.setStyleSheet("QCheckBox::indicator:unchecked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-closed-scaled.png); width: 11px; height: 11px;} QCheckBox::indicator:checked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-open-scaled.png); width: 11px; height: 11px;} QCheckBox{font-weight: bold;}")
        self.AEgroupBowCheckBox.setCheckState(QtCore.Qt.Checked)
        self.AEgroupBowCheckBox.setContentsMargins(0,0,0,0)
        self.AEgroupBowCheckBox.stateChanged.connect(self.AEstateChangetgroupBowCB)

        self.startFrameSB = QtGui.QSpinBox()
        self.startFrameSB.setMaximum(100000)
        self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
        self.AEgroupBoxFind.addWidget(self.startFrameSB,0,0)        
        self.endFrameSB = QtGui.QSpinBox()
        self.endFrameSB.setMaximum(100000)
        self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
        self.AEgroupBoxFind.addWidget(self.endFrameSB,0,1)        

        self.AEloadunloaded = QtGui.QCheckBox("load unloaded")
        self.AEgroupBoxFind.addWidget(self.AEloadunloaded,1,0)        

        self.AEswithreferenceToOriginal = QtGui.QCheckBox("Switch proxy to original")
        self.AEswithreferenceToOriginal.setCheckState(QtCore.Qt.Checked)
        self.AEgroupBoxFind.addWidget(self.AEswithreferenceToOriginal,1,1)        

        self.AEExportChekbox = QtGui.QCheckBox("selected")
        self.AEExportChekbox.connect(self.AEExportChekbox, QtCore.SIGNAL("stateChanged(int)"), self.exportstateChanged)                
        self.AEgroupBoxFind.addWidget(self.AEExportChekbox,2,0)        

        self.AECreateGpuCasheChekbox = QtGui.QCheckBox("create GPU cashe")
        self.AEgroupBoxFind.addWidget(self.AECreateGpuCasheChekbox,2,1)        

        self.refPasses = QtGui.QSpinBox()
        self.refPasses.setValue(1)
        self.AEgroupBoxFind.addWidget(self.refPasses,3,0)        

        self.AEExportButton = QtGui.QPushButton("Export")
        self.AEExportButton.released.connect(self.AEExportButtonSlot)
        self.AEgroupBoxFind.addWidget(self.AEExportButton,4,0,1,2)        

        self.oneWidget = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind = QtGui.QGridLayout()
        self.groupBoxFind.setSpacing(0)
        self.oneWidget.setLayout(self.groupBoxFind)
        self.groupBoxFind.setContentsMargins(3,3,3,3)
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLayout.setContentsMargins(0,0,0,0)
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.groupBoxFind.addLayout(self.twoLayout,0,0)        


        self.filesWidget = QtGui.QWidget()
        self.twoLayoutGridOne = QtGui.QGridLayout(self.filesWidget)
        self.twoLayoutGridOne.setContentsMargins(0,0,0,0)

        self.filesRB = QtGui.QRadioButton("objects")
        self.refsRB = QtGui.QRadioButton("references")
        self.hRadio = QtGui.QHBoxLayout() 
        self.hRadio.setContentsMargins(0,0,0,0)
        self.hRadio.addWidget(self.filesRB)                        
        self.hRadio.addWidget(self.refsRB)                        
        self.groupBoxFind.addLayout(self.hRadio,1,0)                        
        self.refsRB.setChecked(True)        

        self.showLabel = QtGui.QLabel(" show type")
        self.checkShowType = QtGui.QCheckBox()
        self.namespaceLabel = QtGui.QLabel(" show namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                

        self.showFindedLabel = QtGui.QLabel(" only found")
        self.checkShowFinded = QtGui.QCheckBox()
        self.checkShowFinded.setCheckState(QtCore.Qt.Checked)
        self.checkShowFinded.connect(self.checkShowFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded)                

        self.expandFindedLabel = QtGui.QLabel(" expand found")
        self.checkexpandFinded = QtGui.QCheckBox()
        self.checkexpandFinded.setCheckState(QtCore.Qt.Checked)
        self.checkexpandFinded.connect(self.checkexpandFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetExpandFinded)                

        self.collapsePushButton = QtGui.QPushButton("collapse all")
        self.collapsePushButton.released.connect(self.collapseAllSlot)

        self.twoLayoutGridOne.addWidget(self.showLabel,0,1)
        self.twoLayoutGridOne.addWidget(self.checkShowType,0,2)                        
        self.twoLayoutGridOne.addWidget(self.namespaceLabel,0,3)
        self.twoLayoutGridOne.addWidget(self.checkShowNamespace,0,4)                        
        self.twoLayoutGridOne.addWidget(self.showFindedLabel,1,1)
        self.twoLayoutGridOne.addWidget(self.checkShowFinded,1,2)                        
        self.twoLayoutGridOne.addWidget(self.expandFindedLabel,1,3)
        self.twoLayoutGridOne.addWidget(self.checkexpandFinded,1,4)                        
        self.twoLayoutGridOne.addWidget(self.collapsePushButton,1,5)                        
        self.groupBoxFind.addWidget(self.filesWidget,2,0)        

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        
        self.AEgroupBoxFind.addWidget(self.oneWidget,5,0,1,2)        
        self.AEgroupBoxFind.addWidget(self.treeView,6,0,1,2)        
        self.AEgroupBoxFind.setRowStretch(7,100)





        self.treWidget = QtGui.QWidget()
        self.treWLayout = QtGui.QGridLayout(self.treWidget)
        self.treWLayout.setContentsMargins(10,0,0,0)
        self.treWCheckBox = QtGui.QCheckBox(" Alembic import")
        self.treWCheckBox.setStyleSheet("QCheckBox::indicator:unchecked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-closed-scaled.png); width: 11px; height: 11px;} QCheckBox::indicator:checked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-open-scaled.png); width: 11px; height: 11px;} QCheckBox{font-weight: bold;}")
        self.treWCheckBox.setCheckState(QtCore.Qt.Checked)
        self.treWCheckBox.setContentsMargins(0,0,0,0)
        self.treWCheckBox.stateChanged.connect(self.stateTreChangetgroupBowCB)


        self.labelToFolderCB=QtGui.QLabel("Cashe folder:")
        self.FolderCombobox = QtGui.QComboBox()
        self.m_renderTypeList = QtCore.QStringList()
        filesss = glob.glob(self.FindAlembicSceneFolder(root=True)+"*")
        self.m_renderTypeList.append("choose")
        filesssPath = []
        for f in filesss:
            self.m_renderTypeList.append( f.split("/")[-1] )
            filesssPath.append(f)
        self.FolderCombobox.addItems( self.m_renderTypeList )
        for f in range(len(filesssPath)):
            if f==0:
                self.FolderCombobox.setItemData(0,"",QtCore.Qt.UserRole)
            self.FolderCombobox.setItemData(f+1,filesssPath[f],QtCore.Qt.UserRole)


        self.importChekbox = QtGui.QCheckBox("selected")
        self.importChekbox.connect(self.importChekbox, QtCore.SIGNAL("stateChanged(int)"), self.importstateChanged)                


        self.importUnloadRefsChekbox = QtGui.QCheckBox("gpu:auto unload refs")
        self.importUnloadRefsChekbox.setCheckState(QtCore.Qt.Checked)
        self.importUnloadRefsChekbox.setVisible(False) 
        
        self.autoLoadOtherVersionChekbox = QtGui.QCheckBox("auto load pers")

        self.importButton = QtGui.QPushButton("Import")
        self.importButton.released.connect(self.importButtonSlot)


        self.oneWidget2 = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind2 = QtGui.QVBoxLayout()
        self.groupBoxFind2.setSpacing(0)
        self.oneWidget2.setLayout(self.groupBoxFind2)
        self.groupBoxFind2.setContentsMargins(3,3,3,3)
        self.twoLayout2 = QtGui.QHBoxLayout()
        self.twoLayout2.setContentsMargins(0,0,0,0)
        self.twoLabel2 = QtGui.QLabel("Name: ")
        self.twoLineEdit2 = QtGui.QLineEdit()
        self.twoLineEdit2.setText("")        
        self.twoLineEdit2.returnPressed.connect(self.findText2)
        self.twoPushButton2 = QtGui.QPushButton("Find")
        self.twoPushButton2.released.connect(self.findText2)
        self.twoLayout2.addWidget(self.twoLabel2)
        self.twoLayout2.addWidget(self.twoLineEdit2,1)                        
        self.twoLayout2.addWidget(self.twoPushButton2)                        
        self.groupBoxFind2.addLayout(self.twoLayout2)        


        self.filesWidget2 = QtGui.QWidget()
        self.twoLayoutGridOne2 = QtGui.QGridLayout(self.filesWidget2)
        self.twoLayoutGridOne2.setContentsMargins(3,3,3,3)

        self.namespaceLabel2 = QtGui.QLabel(" show namespace")
        self.checkShowNamespace2 = QtGui.QSpinBox()
        self.checkShowNamespace2.setMinimum(-1)
        self.checkShowNamespace2.setValue(-1)
        self.showNamespace2=QtCore.QVariant(0)
        self.checkShowNamespace2.connect(self.checkShowNamespace2, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace2)                

        self.showFindedLabel2 = QtGui.QLabel(" only found")
        self.checkShowFinded2 = QtGui.QCheckBox()
        self.checkShowFinded2.setCheckState(QtCore.Qt.Checked)
        self.checkShowFinded2.connect(self.checkShowFinded2, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded2)                


        self.twoLayoutGridOne2.addWidget(self.namespaceLabel2,0,0)
        self.twoLayoutGridOne2.addWidget(self.checkShowNamespace2,0,1)                        
        self.twoLayoutGridOne2.addWidget(self.showFindedLabel2,0,2)
        self.twoLayoutGridOne2.addWidget(self.checkShowFinded2,0,3)                        

        self.groupBoxFind2.addWidget(self.filesWidget2)        


        self.treeView2 = QtGui.QTreeView()
        self.treeView2.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate2 = SpinBoxDelegate2()
        self.treeView2.setItemDelegate(self.delegate2)
        self.treeView2.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView2.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel2 = QtGui.QStandardItemModel()
        self.treeView2.setModel(self.treeModel2)
        self.treeView2.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView2.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView2.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView2.setHeaderHidden(True)


        self.treeViewGPU = QtGui.QTreeView()
        self.treeViewGPU.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegateGPU = SpinBoxDelegate2()
        self.treeViewGPU.setItemDelegate(self.delegateGPU)
        self.treeViewGPU.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeViewGPU.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModelGPU = QtGui.QStandardItemModel()
        self.treeViewGPU.setModel(self.treeModelGPU)
        self.treeViewGPU.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeViewGPU.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeViewGPU.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeViewGPU.setHeaderHidden(True)

        self.GPULayout = QtGui.QHBoxLayout()
        self.loadGPUButton = QtGui.QPushButton("Refresh")
        self.loadGPUButton.released.connect(self.GPUButtonSlot)
        self.switchGPUButton = QtGui.QPushButton("Switch")
        self.switchGPUButton.released.connect(self.switchGPUButtonSlot)
        self.GPULayout.addWidget(self.loadGPUButton)
        self.GPULayout.addWidget(self.switchGPUButton)

        self.treWLayout.addWidget(self.labelToFolderCB,0,0)        
        self.treWLayout.addWidget(self.FolderCombobox,0,1)        
        self.treWLayout.addWidget(self.importChekbox,1,0)        
        self.treWLayout.addWidget(self.importUnloadRefsChekbox,1,1)        
        self.treWLayout.addWidget(self.autoLoadOtherVersionChekbox,1,1)        
        self.treWLayout.addWidget(self.importButton,2,0,1,2)        
        self.treWLayout.addWidget(self.oneWidget2,3,0,1,2)
        self.treWLayout.addWidget(self.treeView2,4,0,1,2)        
        self.treWLayout.addWidget(self.treeViewGPU,5,0,1,2)        
        self.treWLayout.addLayout(self.GPULayout,6,0,1,2)        


        self.mainLayout.addWidget(self.AEgroupBowCheckBox,0)
        self.mainLayout.addWidget(self.twoWidget,0)
        self.mainLayout.addWidget(self.treWCheckBox,0)
        self.mainLayout.addWidget(self.treWidget,0)
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.setWindowTitle('Save asset/scene...')
        self.filesRB.toggled.connect(self.setFilesRefs)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.checkShowType.setCheckState(QtCore.Qt.Checked)
        self.FolderCombobox.currentIndexChanged.connect(self.changeFolderFiles)


    def GPUButtonSlot(self):
        self.treeModelGPU.clear()
        parentItem = self.treeModelGPU.invisibleRootItem()
        nodesss = cmds.ls("|system|gpu_cache",dag=True,type="gpuCache")
        for f in nodesss:
            nameForAlembicTemp = f.split("/")[-1].replace("_x_",":")
            nameForAlembicTemp = nameForAlembicTemp.replace("_z_","|")
            nameForAlembicTemp = nameForAlembicTemp.split(".")[0] 
            itemChild = QtGui.QStandardItem(nameForAlembicTemp)
            itemChild.setData(cmds.getAttr(f+".ml_origReferenceFile"),QtCore.Qt.UserRole)
            itemChild.setData(f,QtCore.Qt.UserRole+2)
            itemChild.setData(0,QtCore.Qt.UserRole+1)
            itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            parentItem.appendRow(itemChild)

    def switchGPUButtonSlot(self):
        data={}
        folderPath=""
        for i in self.treeViewGPU.selectionModel().selectedRows():
            selectedFiles=str(i.data(QtCore.Qt.UserRole).toString())
            selectedNodes=str(i.data(QtCore.Qt.UserRole+2).toString())
            parentNode=cmds.listRelatives(selectedNodes,p=True)[0]
            parentPath=cmds.getAttr(parentNode+".cacheFileName").split(".")[0]
            parentPath="/".join(parentPath.split("/")[:-1])
            if data == {} or folderPath!=parentPath:
                folderPath=parentPath
                filePath=folderPath+"/settings.js"
                if os.path.exists(filePath):
                    fileOpen = open( filePath ).read()
                    data = json.loads( fileOpen )
            if cmds.getAttr(parentNode+".visibility"):
                cmds.setAttr(parentNode+".visibility",0)
                findedRefFile=[]
                if selectedFiles in data["refsToFiles"]:
                    findedRefFile=data["refsToFiles"][selectedFiles]["parents"]
                    print str(data["refsToFiles"][selectedFiles])

                for fRF in findedRefFile:
                    if cmds.file(fRF,q=True,ex=True):
                        if cmds.file(fRF,q=True,dr=True):
                            cmds.file(fRF,loadReference=True,lrd="topOnly")
                print selectedFiles
                print str(findedRefFile)
                if cmds.file(selectedFiles,q=True,ex=True):
                    refNode=cmds.file(selectedFiles,q=True,rfn=True)
                    proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                    if proxyMnger:
                        proxyMnger=proxyMnger[0]
                        artiveProxy=cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0].split(".")[-1]
                        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
                        filenameToLoad=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
                        if filenameToLoad != "":
                            if cmds.file(filenameToLoad,q=True,dr=True):
                                cmds.file(filenameToLoad,loadReference=artiveRnNode)
                    else:            
                        if cmds.file(selectedFiles,q=True,dr=True):
                            cmds.file(selectedFiles,loadReference=refNode)
            else:
                cmds.setAttr(parentNode+".visibility",1)
                nautiBilla=""
                try:
                    nautiBilla=cmds.file(selectedFiles,q=True,rfn=True)
                except:
                    pass
                if nautiBilla:
                    if cmds.file(selectedFiles,q=True,ex=True):
                        refNode=cmds.file(selectedFiles,q=True,rfn=True)
                        proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                        if proxyMnger:
                            proxyMnger=proxyMnger[0]
                            listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                            for lP in listProxyes:
                                nextFile = cmds.referenceQuery(lP,f=True)
                                if not cmds.file(nextFile,q=True,dr=True):
                                    cmds.file(nextFile,unloadReference=lP)                
                        else:            
                            if not cmds.file(selectedFiles,q=True,dr=True):
                                cmds.file(selectedFiles,unloadReference=refNode)





    def findText2(self):
        findTextLine = str(self.twoLineEdit2.text())
        findTextLine = ".*".join(findTextLine.split("*"))
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.DisplayRole).toString()
                expression = re.compile(findTextLine, re.IGNORECASE)
                m = expression.search(temp)
                if m:
                    item.setData(1,QtCore.Qt.UserRole+1)
                    if self.checkShowFinded2.checkState()==QtCore.Qt.Unchecked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    item.setData(0,QtCore.Qt.UserRole+1)
                    if self.checkShowFinded2.checkState()==QtCore.Qt.Checked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 


    def importstateChanged(self,a):
        if a:
            self.importButton.setText("Import selected")
        else:
            self.importButton.setText("Import")


    def exportstateChanged(self,a):
        if a:
            self.AEExportButton.setText("Export selected")
        else:
            self.AEExportButton.setText("Export")

    def changeFolderFiles(self):
        if self.FolderCombobox.currentIndex()!=0:
            self.treeModel2.clear()
            parentItem = self.treeModel2.invisibleRootItem()
            print self.FolderCombobox.currentIndex()
            folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
            print folderPath
            filesss = glob.glob(folderPath+"/*.abc")
            for f in filesss:
                nameForAlembicTemp = f.split("/")[-1].replace("_x_",":")
                nameForAlembicTemp = nameForAlembicTemp.replace("_z_","|")
                nameForAlembicTemp = nameForAlembicTemp.split(".")[0] 
                itemChild = QtGui.QStandardItem(nameForAlembicTemp)
                itemChild.setData(f,QtCore.Qt.UserRole)
                itemChild.setData(0,QtCore.Qt.UserRole+1)
                itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                parentItem.appendRow(itemChild)

        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if folderPath.endswith("_gpu"):
            self.importUnloadRefsChekbox.setVisible(True) 
            self.autoLoadOtherVersionChekbox.setVisible(False) 
        else:
            self.importUnloadRefsChekbox.setVisible(False) 
            self.autoLoadOtherVersionChekbox.setVisible(True) 


    def FindAlembicSceneFolder(self,root=False,gpu=False):
        sss=mel.eval("rman getvar RMSPROJ")+"cache/alembic/"
        gpuString=""
        if gpu:
            gpuString="_gpu"
        addString=mel.eval("rman getvar STAGE")+"_new"+gpuString
        if not root:
           sss+=addString
        if not os.path.exists(sss):
            os.makedirs(sss)
        return sss


    def importButtonSlot(self): 
        for ddd in cmds.ls(type="camera",l=True):
            if cmds.camera(ddd,q=True,startupCamera=True):
                if ddd not in ["|front|frontShape","|persp|perspShape","|side|sideShape","|top|topShape"]:
                    cmds.camera(ddd,e=True,startupCamera=False)
                    print "Kamera popravlena: "+ddd

        self.selectedFiles=[]
        self.selectedNodes=[]
        if self.importChekbox.checkState()==QtCore.Qt.Checked:
            for i in self.treeView2.selectionModel().selectedRows():
                self.selectedFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
                self.selectedNodes.append(str(i.data(QtCore.Qt.DisplayRole).toString()))
        else:
            parentItem = self.treeModel2.invisibleRootItem()
            for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                self.selectedFiles.append(str(item.data(QtCore.Qt.UserRole).toString()))
                self.selectedNodes.append(str(item.data(QtCore.Qt.DisplayRole).toString()))

        data={}
        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        filePath=folderPath+"/settings.js"
        if os.path.exists(filePath):
            fileOpen = open( filePath ).read()
            data = json.loads( fileOpen )


        if folderPath.endswith("_gpu"):
            if cmds.ls("|system") == []:
                cmds.createNode("transform",n="system")    
            if cmds.ls("|system|gpu_cache") == []:
                cmds.createNode("transform",n="gpu_cache",p="system")    
            startTime=cmds.timerX()
            for ifn in self.selectedFiles:
                nameee=ifn.split("/")[-1].split(".")[0]
                nameForAlembicTemp = nameee.replace("_x_",":")
                nameForAlembicTemp = nameForAlembicTemp.replace("_z_","|")
                folderName=""
                if cmds.ls("|system|gpu_cache|"+nameee) == []:    
                    folderName = cmds.createNode("transform",n=nameee,p="|system|gpu_cache")
                else:
                    folderName=cmds.ls("|system|gpu_cache|"+nameee)[0] 

                nodeShapeName=""
                if cmds.ls("|system|gpu_cache|"+nameee,dag=True,type="gpuCache") == []:    
                    nodeShapeName=cmds.createNode("gpuCache",n=nameee+"Shape",p="|system|gpu_cache|"+folderName)
                else:
                    nodeShapeName=cmds.ls(nameee,dag=True,type="gpuCache")[0]

                cmds.setAttr(nodeShapeName+".cfn",ifn,type="string")    

                findedRefFile=""
                if "refsToFiles" in data:
                    for d in data["refsToFiles"].keys():
                        for i in data["refsToFiles"][d]["abcFiles"]:
                            if nameForAlembicTemp == i:
                                findedRefFile=d
                                break

                if not cmds.attributeQuery("ml_origReferenceFile",n=nodeShapeName,ex=True):
                    cmds.addAttr(nodeShapeName,longName="ml_origReferenceFile",dt="string")
                cmds.setAttr(nodeShapeName+".ml_origReferenceFile",findedRefFile,type="string")

                if findedRefFile:
                    if self.importUnloadRefsChekbox.checkState()==QtCore.Qt.Checked:
                        if cmds.file(findedRefFile,q=True,ex=True):
                            refNode=cmds.file(findedRefFile,q=True,rfn=True)
                            proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                            if proxyMnger:
                                proxyMnger=proxyMnger[0]
                                listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                                for lP in listProxyes:
                                    nextFile = cmds.referenceQuery(lP,f=True)
                                    if not cmds.file(nextFile,q=True,dr=True):
                                        cmds.file(nextFile,unloadReference=lP)                
                            else:            
                                if not cmds.file(findedRefFile,q=True,dr=True):
                                    cmds.file(findedRefFile,unloadReference=refNode)
            
            print cmds.timerX(startTime=startTime)

        else:
            existsNameSpace=cmds.namespaceInfo(lon=True,r=True,an=True) 
            if "namespaces" in data.keys():
                for t in data["namespaces"]: 
                    if t not in existsNameSpace:
                        cmds.namespace(add=t)


            if "nodes" in data.keys():
                for t in data["nodes"]: 
                    if not cmds.objExists(t):
                        thisNode=cmds.createNode(data["nodes"][t]["type"])
                        thisNode=cmds.rename(thisNode,t)
                        for tt in data["nodes"][t]["attributes"]:
                            if not cmds.attributeQuery(tt,n=thisNode,ex=True):
                                cmds.addAttr(thisNode,longName=tt,dt=data["nodes"][t]["attributes"][tt]["type"])
                            #cmds.addAttr(thisNode,longName="rgcnx",attributeType="message")
                            #cmds.addAttr(thisNode,longName="rlfData",dt="string")
                            #cmds.addAttr(thisNode,longName="slimData",dt="string")
                            #cmds.addAttr(thisNode,longName="slimRIB",dt="string")
                            cmds.setAttr(thisNode+"."+tt,data["nodes"][t]["attributes"][tt]["value"],type=data["nodes"][t]["attributes"][tt]["type"])

            startTime=cmds.timerX()
            print "load files ("+str(len(self.selectedFiles))+")"
            for ifn in range(len(self.selectedFiles)):
                namespaceFinded=""
                findedRefFile=""
                for d in data["refsToFiles"].keys():
                    for i in data["refsToFiles"][d]["abcFiles"]:
                        if self.selectedNodes[ifn] == i:
                            findedRefFile=d
                            namespaceFinded=data["refsToFiles"][d]["namespace"] 
                            break

                if self.autoLoadOtherVersionChekbox.checkState()==QtCore.Qt.Checked:
                    replacePers=main.getAssetFirstVersion(re.sub("\{[0-9]*\}","",findedRefFile))
                    if replacePers:
                        if not cmds.namespace(ex=namespaceFinded):
                            cmds.namespace(add=namespaceFinded)

                        if not cmds.namespaceInfo(namespaceFinded,ls=True):
                            print "LOAD RENDER VERSION:"+replacePers
                            cmds.file(replacePers,r=True,mergeNamespacesOnClash=True,namespace=namespaceFinded)

                mel.eval("AbcImport -mode import -fitTimeRange -connect \"/\" -setToStartFrame -createIfNotFound \""+self.selectedFiles[ifn]+"\"")
            print cmds.timerX(startTime=startTime)


    def loadReference(self, referenceFile, rez, expandProxy=True, loadUnloaded=False, expandChildProxy=True, loadUnloadedChild=False):
        refNode=cmds.file(referenceFile,q=True,rfn=True)
        isLoaded=1-int(cmds.file(referenceFile,q=True,dr=True))
        if not isLoaded and loadUnloaded:
            cmds.file(referenceFile,loadReference=refNode)
            rn = cmds.file(referenceFile, query=True, reference=True )
            for r in rn:
                rez.append(self.loadReference(r,rez,expandChildProxy,loadUnloadedChild,False,False))
            isLoaded=1

        if isLoaded:
            currentProxyTag=cmds.getAttr(refNode+".proxyTag")
            if expandProxy and not not currentProxyTag and currentProxyTag != "" and currentProxyTag != "original":
                    proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                    if proxyMnger:
                        proxyMnger=proxyMnger[0]
                        listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                        for lP in listProxyes:
                            if cmds.getAttr(lP+".proxyTag") == "" or cmds.getAttr(lP+".proxyTag") == "original":
                                self.proxyActivate(lP)
                                rn = cmds.file(cmds.referenceQuery(lP,f=True), query=True, reference=True )
                                rez.append(cmds.referenceQuery(lP,f=True))
                                for r in rn:
                                    rez.append(self.loadReference(r,rez,expandChildProxy,loadUnloadedChild,False,False))
            else:
                rez.append(referenceFile)

    '''
    def referenceRoots(self,referenceFile):
        listNodes=cmds.referenceQuery(referenceFile,n=True,dp=True)
        pathsToShapes=cmds.ls(listNodes,l=True,s=True)
        proveren=pathsToShapes
        podVoprosom=[]


        for pTS in pathsToShapes:
            liiist=pTS.split("|")
            for i in reversed(range(len(liiist)-1)):
                if i != 0:
                    var="|".join(liiist[:i+1])
                    listChild=cmds.ls(var+"|*",l=True,r=True)
                    chist=1
                    for lC in listChild:
                        if lC not in proveren:
                            if lC not in podVoprosom:
                                podVoprosom.append(lC)
                            chist=0
                        else:
                            if lC in podVoprosom:
                                podVoprosom.remove(lC)
                            
                    if chist:
                        proveren.append(var)

        chistyi=[]
        for i in proveren:
            temp=i
            for ii in proveren:    
                if temp.startswith(ii) and len(ii)<len(temp):
                    temp=ii
            if temp not in chistyi:
                chistyi.append(temp                self.listReferences.append(r)
)

        return chistyi
    '''
    def hideParent(self,ttt):
        ttt = cmds.ls(ttt,l=True)[0]
        temp=ttt.split("|")
        if len(temp)>1:
            for ifg in reversed(range(2,len(temp))):
                tmp = "|".join(temp[:ifg])
                if not cmds.getAttr(tmp+".visibility"):    
                    print "HIDED PARENT FOLDER: "+tmp
                    if not cmds.attributeQuery("ml_visibility",node=ttt,ex=True):
                        cmds.addAttr(ttt,ln="ml_visibility",at="bool",defaultValue=True)
                    cmds.setAttr(ttt+".ml_visibility",cmds.getAttr(ttt+".visibility"))
                    cmds.setAttr(ttt+".visibility",False)
                    break

    def AEExportButtonSlot(self):
        setBool=1
        if self.AECreateGpuCasheChekbox.checkState()==QtCore.Qt.Checked:
            setBool=0

        for im in cmds.ls(type="mesh",ni=True):
            if not cmds.attributeQuery("SubDivisionMesh",node=im,ex=True):
                cmds.addAttr(im,ln="SubDivisionMesh",at="bool",defaultValue=setBool)
            cmds.setAttr(im+".SubDivisionMesh",setBool)

        dataFileABCRefs={}
        selectedFiles=[]
        selectedFileslocal=[]
        selectedRootNodes=[]
        refsForPasses=[]
        refsForPassesProxy=[]
        if self.AEExportChekbox.checkState()==QtCore.Qt.Checked:
            for i in self.treeView.selectionModel().selectedRows():
                selectedFileslocal.append(str(i.data(QtCore.Qt.UserRole+3).toString()))
        else:
            self.onlyGetData=1
            temp = str(self.twoLineEdit.text())
            self.twoLineEdit.setText("")
            self.findText()   
            self.onlyGetData=0
            self.twoLineEdit.setText(temp)
            selectedFileslocal=self.listReferences

        for i in selectedFileslocal:
            print i

        print "\n\n\n"

        for sF in range(len(selectedFileslocal)):
            self.loadReference(selectedFileslocal[sF],selectedFiles,self.AEswithreferenceToOriginal.checkState()==QtCore.Qt.Checked,self.AEloadunloaded.checkState()==QtCore.Qt.Checked,True,False)

        #for i in self.selectedFiles:
        #    print str(i)

        import test22
        #slovar=test22.uniqueTransforms3() 
        slovar=test22.listUniqueTransforms( references=[], hasMesh=True, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True )
        '''for a in slovar:
            for aa in slovar[a]:
                if cmds.ls(aa,dag=True,type="mesh") == []:
                    slovar[a].remove(aa)
        '''

        sceneName=cmds.file(q=True,sn=True)
        for sF in range(len(selectedFiles)):
            preloadTree=[]
            temp=selectedFiles[sF]
            while cmds.referenceQuery(temp,f=True,p=True):
                temp=cmds.referenceQuery(temp,f=True,p=True)
                if temp == sceneName:
                    break
                preloadTree.insert(0,temp)


            NameSpace=cmds.referenceQuery(selectedFiles[sF],ns=True)
            dataFileABCRefs[selectedFiles[sF]]={ "abcFiles":[], "namespace": NameSpace, "parents": preloadTree }
            if selectedFiles[sF] in slovar:
                for slovo in slovar[selectedFiles[sF]]:
                    filename = cmds.referenceQuery(slovo, filename=True )
                    listFiles=cmds.ls(slovo,dag=True)
                    net=1
                    for i in listFiles:
                        if i.endswith("geometry_grp") and filename == cmds.referenceQuery(i,filename=True):
                            self.hideParent(i)
                            selectedRootNodes.append(i)    
                            dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(i)
                            net=0
                        elif i.endswith("geo_normal") and filename == cmds.referenceQuery(i,filename=True):
                            self.hideParent(i)
                            selectedRootNodes.append(i)    
                            dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(i)
                            net=0
                    if net:
                        self.hideParent(i)
                        selectedRootNodes.append(slovo)    
                        dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(slovo)



            '''if cmds.file(selectedFiles[sF],r=True,q=True) != []:
                print "PARENTY: "+selectedFiles[sF]
                arrayA=cmds.ls(NameSpace+":*",s=True,l=True)
                arrayB=[]
                for arA in arrayA:
                    ddd=0
                    for rA in arrayA:
                        if rA.startswith(arA) and arA != rA:
                            ddd=1
                            break
                    if not ddd:
                        arrayB.append(arA)
                        selectedRootNodes.append(cmds.listRelatives(arA,parent=True)[0])    
                        dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(cmds.listRelatives(arA,parent=True)[0])
            else:
                nashli=0
                listNodes=cmds.referenceQuery(selectedFiles[sF],n=True,dp=True)
                print "PURE: "+selectedFiles[sF]
                for lN in listNodes:
                    if lN.endswith("geo_normal") or lN.endswith("geometry_grp"):
                        if NameSpace == cmds.referenceQuery(lN,ns=True): 
                            selectedRootNodes.append(lN)    
                            dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(lN)
                            nashli=1
                if not nashli:
                    listAllFiles=cmds.ls(listNodes,tr=True,l=True)
                    referenceRoots=[]
                    for lAF in listAllFiles:
                        est=0
                        for rR in range(len(referenceRoots)):
                            if referenceRoots[rR].startswith(lAF):
                                referenceRoots[rR]=lAF
                                est=1
                            elif lAF.startswith(referenceRoots[rR]):
                                est=1
                        if not est:
                            if NameSpace== cmds.referenceQuery(lAF,ns=True): 
                                referenceRoots.append(lAF)
                    for rR in referenceRoots:
                        test=cmds.ls(rR)[0]
                        if NameSpace== cmds.referenceQuery(test,ns=True): 
                            selectedRootNodes.append(test)    
                            dataFileABCRefs[selectedFiles[sF]]["abcFiles"].append(test)
            '''


        for i in selectedRootNodes:
            print i

        self.executeAlembic(selectedRootNodes)

        data={}
        gpu=False
        if self.AECreateGpuCasheChekbox.checkState()==QtCore.Qt.Checked:
            gpu=True
        filePath=self.FindAlembicSceneFolder(False,gpu)+"/settings.js"
        if os.path.exists(filePath):
            fileOpen = open( filePath ).read()
            data = json.loads( fileOpen )

        if self.AECreateGpuCasheChekbox.checkState()==QtCore.Qt.Unchecked:
            currNameSpaces=cmds.namespaceInfo(lon=True,r=True,an=True)
            data["namespaces"]=currNameSpaces

            nodeNameExport={}
            for mP in cmds.ls("*mtorPartition*",r=True):
                nodeNameExport[mP]={}
                nodeNameExport[mP]["type"]=cmds.objectType(mP)
                nodeNameExport[mP]["attributes"]={}
                '''if cmds.attributeQuery("rlfData",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".rlfData")
                    if temp:
                        nodeNameExport[mP]["rlfData"]=str(temp.encode("utf-8"))
                '''
                if cmds.attributeQuery("slimData",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".slimData")
                    nodeNameExport[mP]["attributes"]["slimData"]={}
                    nodeNameExport[mP]["attributes"]["slimData"]["type"]=cmds.getAttr(mP+".slimData",typ=True)
                    if not temp:
                        temp=""
                    nodeNameExport[mP]["attributes"]["slimData"]["value"]=str(temp.encode("utf-8"))
                '''if cmds.attributeQuery("slimRIB",n=mP,ex=True):
                    temp=cmds.getAttr(mP+".slimRIB")
                    if temp:
                        nodeNameExport[mP]["slimRIB"]=str(temp.encode("utf-8"))
                '''
                        

                       
            tmpData={}
            if "nodes" in data.keys():
                tmpData=data["nodes"]
            else:
                data["nodes"]={}
                tmpData=data["nodes"]

            data["nodes"]=dict(tmpData.items() + nodeNameExport.items())

        
        tmpDataFilesNodes={}
        if "refsToFiles" in data.keys():
            tmpDataFilesNodes=data["refsToFiles"]
        else:
            data["refsToFiles"]={}
            tmpDataFilesNodes=data["refsToFiles"]

        data["refsToFiles"]=dict(tmpDataFilesNodes.items() +dataFileABCRefs.items())

        m_file = file( filePath, "w" )
        json.dump( data, m_file, indent=4, ensure_ascii=False )
        m_file.close()


    def executeAlembic(self,listObjects):
        stringToAlembic=""
        gpu=False
        alParametrs="-attr doubleSided -attr visibility -attrPrefix rman -uvWrite"
        if self.AECreateGpuCasheChekbox.checkState()==QtCore.Qt.Checked:
            gpu=True
            alParametrs="-ro"

        for lO in listObjects:
            nameForAlembicTemp = lO.replace(":","_x_")
            nameForAlembicTemp = nameForAlembicTemp.replace("|","_z_")
            stringToAlembic+=" -j \"-frameRange "+str(self.startFrameSB.value())+" "+str(self.endFrameSB.value())+" -worldSpace -dataFormat ogawa -writeVisibility -noNormals "+alParametrs+" -root "+lO+" -file "+self.FindAlembicSceneFolder(False,gpu)+"/"+nameForAlembicTemp+".abc"+"\""    
            
        startTime=cmds.timerX()
        print(stringToAlembic)
        mel.eval("AbcExport -verbose "+stringToAlembic)
        print cmds.timerX(startTime=startTime)
        

    def proxyActivate(self,rnNode):
        proxyManager=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True)
        if proxyManager:
            proxyManager=proxyManager.split(".")[0]
        else:    
            return
        artiveProxy=cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0].split(".")[-1]
        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
        currnetProxy=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True).split(".")[-1]
        if artiveProxy != currnetProxy:
            cmds.disconnectAttr(proxyManager+".activeProxy",proxyManager+"."+artiveProxy)
            cmds.connectAttr(proxyManager+".activeProxy", proxyManager+"."+currnetProxy)
            filenameToUnload=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
            if filenameToUnload != "":
                if not cmds.file(filenameToUnload,q=True,dr=True):
                    cmds.file(filenameToUnload,unloadReference=artiveRnNode)
        filenameToLoad=cmds.reference(rfn=rnNode,q=True,filename=True)
        if filenameToLoad != "":
            cmds.file(filenameToLoad,loadReference=rnNode)
                
        srcLstPlugs=cmds.listConnections(artiveRnNode+".associatedNode",source=True,connections=True,plugs=True)
        if srcLstPlugs:
            for i in range(0,len(srcLstPlugs),2):
                    cmds.disconnectAttr(srcLstPlugs[i+1],srcLstPlugs[i])
                    cmds.connectAttr(srcLstPlugs[i+1],rnNode+"."+srcLstPlugs[i].split(".")[-1])


    def AEstateChangetgroupBowCB(self,a):
        self.twoWidget.setVisible(a)

    def stateTreChangetgroupBowCB(self,a):
        self.treWidget.setVisible(a)

    def setFilesRefs(self,a):
        if a:
            self.showLabel.setText(" show type")
        else:
            self.showLabel.setText(" show load")

    def stateChangetShowType(self,typeIs):
        self.delegate.sT=QtCore.QVariant(typeIs)
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))

    def stateChangetShowNamespace2(self,typeIs):
        self.delegate2.sN=typeIs
        temp=self.treeModel2.index(0,0)
        taak=self.treeView2.isExpanded(temp)
        if taak:
            self.treeView2.collapse(self.treeModel2.index(0,0))
            self.treeView2.expand(self.treeModel2.index(0,0))
        else:
            self.treeView2.expand(self.treeModel2.index(0,0))
            self.treeView2.collapse(self.treeModel2.index(0,0))

    def stateChangetShowNamespace(self,typeIs):
        self.delegate.sN=typeIs
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))

    def stateChangetShowFinded2(self,typeIs):
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.UserRole+1).toInt()[0]
                if self.checkShowFinded2.checkState()==QtCore.Qt.Unchecked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    if not temp:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 

    def stateChangetShowFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.showFindedRecurse(parentItem,typeIs)

    def showFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            if val:
                temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
                if temp > 0:
                    self.treeView.setRowHidden(chi,item.index(),False) 
                    self.showFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setRowHidden(chi,item.index(),True) 
            else:
                self.treeView.setRowHidden(chi,item.index(),False) 
                self.showFindedRecurse(item.child(chi,0),val)

    def stateChangetExpandFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.expandFindedRecurse(parentItem,typeIs)

    def expandFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
            if temp > 0:
                if val:
                        self.treeView.setExpanded(item.child(chi,0).index(),True) 
                        self.expandFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setExpanded(item.child(chi,0).index(),False) 


    def collapseAllSlot(self):
        self.checkexpandFinded.setCheckState(QtCore.Qt.Unchecked)
        parentItem = self.treeModel.invisibleRootItem()
        self.collapseAllSlotRecurse(parentItem)

    def collapseAllSlotRecurse(self,item):
        for chi in range(item.rowCount()):
            self.treeView.setExpanded(item.child(chi,0).index(),False) 
            self.collapseAllSlotRecurse(item.child(chi,0))


    def acceptedSig(self):
            pass

    def closeEvent(self, event):
            event.accept()

    
            
    def findText(self):   
        findTextLine = str(self.twoLineEdit.text())
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        #cmds.timer(s=True) 
        tree = []
        if self.filesRB.isChecked():
            listFindedObjects=list(set(cmds.ls(findTextLine,l=True,o=True,r=True)))
            listObjects = cmds.ls(dag=True,l=True,st=True)
            for item in range(0,len(listObjects),2):
                typeObject=listObjects[item+1]
                currentObject=listObjects[item][1:].split('|')
                est="0"
                if listObjects[item] in listFindedObjects:
                    est="1"
                t=tree
                startwhis=""
                for i in range(len(currentObject)):
                    startwhis+="|"+currentObject[i]
                    da=-1
                    for ii in range(len(t)):
                        if currentObject[i] in t[ii][0]:
                            da=ii
                            t=t[ii]
                            break
                    if da == -1:
                        if est=="0":
                            for x in listFindedObjects:
                                if x.startswith(startwhis):
                                    est="2"
                        t.append([currentObject[i],typeObject,est])
                        t=t[-1]

            self.printItem(parentItem,tree)
        else:
            self.tree = []
            self.listReferences=[]
            self.loadAllrefs("",self.tree,self.tree,".*".join(findTextLine.split("*")))
            if not self.onlyGetData:
                self.printItemRefs(parentItem,self.tree)
        #print cmds.timer(e=True)

    def loadAllrefs(self,f,tree,root,sear):
        rn = cmds.file(f, query=True, reference=True )
        for r in rn:
            skolkoConnectov=cmds.listConnections(cmds.file(r,q=True,rfn=True)+".proxyMsg",d=True,s=True,type="proxyManager")
            proxyTag=cmds.getAttr(cmds.file(r,q=True,rfn=True)+".proxyTag")
            ifOverExists=""
            edem=1
            if skolkoConnectov:
                ifOverExists="1"
                if len(skolkoConnectov)==1:
                    edem=0  
            if edem:
                parentNamespace=cmds.file(r,query=True,pns=True)[0]
                namespaceThis=cmds.file(r,query=True,ns=True)
                if parentNamespace != "":
                    namespaceAll=parentNamespace+":"+namespaceThis
                else:
                    namespaceAll=namespaceThis
                isLoaded=1-int(cmds.file(r,q=True,dr=True))
                est="0"
                if sear!="":
                    expression = re.compile(sear, re.IGNORECASE)
                    m = expression.search(namespaceThis)
                    if m:
                        est="1"
                        tempRoot=self.tree
                        for sp in parentNamespace.split(":"):
                            for tr in tempRoot:
                                if tr[0]==sp:
                                    tr[1]="2"
                                    tempRoot=tr[4]
                        
                root.append([namespaceThis,est,isLoaded,r,[],namespaceAll,proxyTag,ifOverExists])
                if isLoaded:
                    self.listReferences.append(r)
                temp=root[-1][4]
                self.loadAllrefs(r,self.tree,temp,sear)

            
    def printItem(self, item, part):
        for i in range(len(part)):
            if type(part[i]) == type([]):
                itemChild = QtGui.QStandardItem(part[i][0])
                itemChild.setData(part[i][1],QtCore.Qt.UserRole)
                itemChild.setData(part[i][2],QtCore.Qt.UserRole+1)
                itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                item.appendRow(itemChild)
                if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                    if part[i][2] == "0":
                        self.treeView.setRowHidden(itemChild.row(),item.index(),True) 

                if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                    if part[i][2] != "0":
                        self.treeView.setExpanded(itemChild.index(),True) 

                self.printItem(itemChild,part[i])    
        
                        
    def printItemRefs(self, item, part):
        for i in range(len(part)):
            itemChild = QtGui.QStandardItem(part[i][5])
            itemChild.setData(part[i][2],QtCore.Qt.UserRole+2)
            itemChild.setData(part[i][3],QtCore.Qt.UserRole+3)
            itemChild.setData(part[i][5],QtCore.Qt.UserRole+4)
            itemChild.setData(part[i][6],QtCore.Qt.UserRole+5)
            itemChild.setData(part[i][7],QtCore.Qt.UserRole+6)
            itemChild.setData(part[i][1],QtCore.Qt.UserRole+1)
            itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            item.appendRow(itemChild)
            if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] == "0":
                    self.treeView.setRowHidden(itemChild.row(),item.index(),True) 
            if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] != "0":
                    self.treeView.setExpanded(itemChild.index(),True) 
            self.printItemRefs(itemChild,part[i][4])    

#ex = Window()
#ex.findText()
#ex.exec_()

