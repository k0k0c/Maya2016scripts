import time
import sys
import os
import re
import maya.cmds as cmds
import maya.mel as mel
cmds.loadPlugin('RenderMan_for_Maya')

#Get arguments
arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
pathToScene = arguments[0]
pathToScene = '\\' in pathToScene and '/'.join(pathToScene.split('\\')) or pathToScene
print 'path: ', pathToScene
archiveName = arguments[1]
print 'Archive name: ', archiveName
updateProxy = arguments[2]

def slimStop():
    
    try:
        mel.eval('rman slim command ("slim Shutdown force")')
    except:
        print '\nslim cmd error:  (slim Shutdown force)'  

def openTargetFile(pathToScene, archiveName, updateProxy):
    #startTime = 
    #endTime =
    #stepFrame = 
    cmds.file(pathToScene, force=True, open=True)
    #Return arguments
    if archiveName != 'NoName':
        #time.sleep(1.0)
        archivePathName = createRibArchive(archiveName)
    else:
        #time.sleep(1.0)
        archiveName = ((cmds.file(query=True, sceneName=True).split('/')[-1]).split('.')[0]+'RibArchive')        
        archivePathName = createRibArchive(archiveName)
    mel.eval('rman slim command ("slim Shutdown")')   
    if updateProxy == 'True':
        target = ''
        pathToSceneProxy = '_' not in pathToScene.split('.')[0] and pathToScene.split('.')[0] + '_proxy.' + pathToScene.split('.')[-1] or pathToScene.split('.')[0] + 'Proxy.' + pathToScene.split('.')[-1]
        mel.eval('rman slim command ("slim Shutdown")')
        cmds.file(force=True, new=True)
        cmds.file(pathToSceneProxy, force=True, open=True)
        nodes = cmds.ls('root', dag=True, long=True, type=['mesh', 'gpuCache', 'locator', 'RenderManArchive'])
        if nodes:
            if nodes:
                target = ''
                for i in range(0, len(nodes)):
                    if cmds.attributeQuery('rman__torattr___invis', node=nodes[i], exists=True):
                        cmds.deleteAttr(nodes[i]+'.rman__torattr___invis')                    
                    if cmds.attributeQuery('rman__param___draFile', node=nodes[i], exists=True):
                        cmds.deleteAttr(nodes[i]+'.rman__param___draFile')
                    if cmds.attributeQuery('rman__torattr___preShapeScript', node=nodes[i], exists=True):
                        if cmds.getAttr(nodes[i]+'.rman__torattr___preShapeScript') == "rmanOutputDelayedReadArchives":
                            cmds.setAttr(nodes[i]+'.rman__torattr___preShapeScript', '', type='string')
                    if cmds.attributeQuery('rman__param___draUseSequenceNumber', node=nodes[i], exists=True):
                        cmds.deleteAttr(nodes[i]+'.rman__param___draUseSequenceNumber')
                    if cmds.nodeType(nodes[i]) == 'RenderManArchive':
                        target = nodes[i]
                    else:
                        mel.eval('rmanAddAttr "'+nodes[i]+'" rman__torattr___invis ("");')
                if target != '':
                    cmds.setAttr(target+'.filename', archivePathName, type="string")
                    cmds.file(force=True, save=True)
                elif target == '':
                    ribArchive = cmds.createNode('RenderManArchive', parent=cmds.ls(nodes[i], long=True)[0].split('|')[-2])
                    cmds.setAttr(ribArchive+'.filename', archivePathName, type="string")
                    cmds.file(force=True, save=True)
    return archivePathName
                    

def createRibArchive(archiveName='', startTime=1, endTime=1, frequency=0):
    '''
    This script working only with parented to world 'root' transform node in target object root directory
    
    archiveName = rib archive project name (default "Current project")
    startTime = rib archive sequence start time (default 1)
    endTime = rib archive sequence end time (default 1)
    frequency = frequency rib arcives per frame (default 0)
    
    example = createRibArchive(rib.zip, 1, 1, 0)
    createRibArchive('testArchiveForMe')
    
    path to archive projectDir+'/renderman/ribarchives/'+archiveName.zip
    '''
    #Set project directory
    mel.eval('eval("rman slim start -gui 0")')
    filePath = 'untitled' not in cmds.file(query=True, sceneName=True) and cmds.file(query=True, sceneName=True) or pathToScene
    project = re.split('project|Project', filePath)[-1].split('/')[1]
    OSTYPE = sys.platform
    curWorkSpace = mel.eval("file -q -loc -sn")
    print 'START FROM HERE!\n'
    print 'path to file: ', filePath
    if re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath):
        print 'scene type: ', re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath)
        projectDir = '/'.join(filePath.split('/')[0:filePath.split('/').index(re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath)[0])+2])
        if OSTYPE == "win32":
            OSTYPE="//renderServer/Project"
        else:
            OSTYPE="/renderServer/Project"
        if OSTYPE:
            projectRoot = OSTYPE+'/'+project+projectDir.split(project)[-1]
            if os.path.isdir( projectRoot ) is False:
                os.makedirs( projectRoot )
            mel.eval("setProject \""+projectRoot+"\";")
            mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+" -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
            mel.eval('rman slim message \"workspace SetProject '+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+'"')	
        #set project only for files in 'props', 'sets', 'chars', 'scenes' directory
        projectRoot = '/'.join(filePath.split('/')[0:4])
        #mel.eval('rman setvar RMSPROJ "' + projectDir + '/"')
        #mel.eval('rman setvar RMSPROD "' + projectRoot + '"')
        #mel.eval('rman setvar RMSPROD_GLOBAL "' + projectRoot + '"')
        archiveDir = mel.eval('rman workspace GetDir "rfmRIBArchives"')
        #set shaders diretory to rib archive path
        shaderDirArchive = (archiveDir+'/'+archiveName+'/shaders')
        slimDirArchive = (archiveDir+'/'+archiveName+'/slim/shaders')
        mel.eval('rman workspace SetDir "rfmShaders" ("{'+shaderDirArchive+'}");')
        mel.eval('rman workspace SetDir "slimShaders" ("{'+slimDirArchive+'}");')
        mel.eval('rman slim command ("workspace SetDir slimShaders {'+slimDirArchive+'}")')
        mel.eval('rman slim command ("slim ReloadExtensions cmd")')  
        mel.eval('rman slim command ("slim BuildShaders")')
    else: 
        cmds.warning('File is corrupted, please use project files or files in assets, scenes project directory')
    #Rib node setup
    ribArchiveShapeNode = cmds.ls(type='RenderManArchive', long=True) and ('|'.join(cmds.ls(type='RenderManArchive', long=True)[0].split('|')[-2:])) or ''
    rootTr = cmds.ls('root')
    if rootTr:
        newRoot = rootTr
    else:
        objects = cmds.ls(transforms=True, long=True)
        upperTransforms = []
        for i in range(0, len(objects)):
            if objects[i].split('|')[1]:
                objectTEMP = objects[i].split('|')[1]
                shapes = cmds.ls(objectTEMP, dag=True, leaf=True, long=True)[0]
                if shapes.split('|') and len(shapes.split('|'))>4:
                    if objectTEMP not in upperTransforms:
                        upperTransforms.append(objectTEMP)
        newRoot = cmds.createNode('transform', n='root')
        cmds.parent(upperTransforms, newRoot)
    if ribArchiveShapeNode == '':                   
        newRib = cmds.createNode('transform', n='ribArchive')
        ribArchiveShapeNode = cmds.createNode('RenderManArchive', name=(newRib+'Shape'), parent=newRib)
        try:
            cmds.parent((cmds.listRelatives(ribArchiveShapeNode, parent=True)[0]), newRoot)  
        except:
            cmds.warning('root already get archive')    
    cmds.setAttr(ribArchiveShapeNode+'.crew', '__siblings', type='string')
    cmds.setAttr(ribArchiveShapeNode+'.startframe', startTime)
    cmds.setAttr(ribArchiveShapeNode+'.endframe', endTime)
    archivePathName = mel.eval('rman getvar RMSPROJ')+mel.eval('rman workspace GetDir "rfmRIBArchives"')+'/'+archiveName+'.zip'
    cmds.setAttr(ribArchiveShapeNode+'.filename', archivePathName, type='string')            
    #Export rib
    mel.eval('rman genrib -cacheCrew ("'+ribArchiveShapeNode+'"+",") -updateArchives 1 -s '+str(startTime)+' -e '+str(endTime)+' -updateArchivesPerFrame '+str(frequency)+';')
    return archivePathName

def getWindowsProcessId(inputExe='slim.exe', typeExe='Console', mode='getId'):
    processList = os.popen('tasklist').read()
    processList = processList.split('\n')
    processListSlim = []
    pid = []
    for i in range(0, len(processList)):
        if inputExe in processList[i]:
            processListSlim.append(processList[i])
    if processListSlim:
        for i in range(0, len(processListSlim)):
            if typeExe in processListSlim[i]:
                pid.append(re.findall('[0-9]+', processListSlim[i].split(typeExe)[0]) and re.findall('[0-9]+', processListSlim[i].split(typeExe)[0])[0])
    if mode == 'getId':
        return [inputExe, pid]
    elif mode == 'killProc':       
        if pid:
            for i in range(0, len(pid)):
                os.system("taskkill /f /pid "+str(pid[i]))

archivePathName = openTargetFile(pathToScene, archiveName, updateProxy)
slimStop()#getWindowsProcessId('slim.exe', 'Console', 'killProc')
print archivePathName
