#Requies
import subprocess
import sys
import os
import re
import maya.cmds as cmds
import maya.mel as mel
#plugins
cmds.loadPlugin('AbcExport')
#setup
OSTYPE = sys.platform
if OSTYPE == "win32":
    OSTYPE="//Server-3d/Project"
else:
    OSTYPE="/Server-3d/Project"
BATCH_RUSH_ADD_PROXY = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/rushAddProxy.py'

def main():
    arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
    print '\nPROXY UPDATE START.'
    #Get arguments
    original = arguments[0]
    print '\nOriginal object: '+original
    proxy = arguments[1]
    print '\nProxy object: '+proxy
    #open original object
    print '\nOPEN SCENE - '+original
    openScene(path=original)
    #update referenced files
    print '\nCHECK INCLUDE REFERENCES'
    updateGpuProxyScene()
    cmds.file(force=True, save=True)
    print '\nEXPORT AS PROXY'
    cmds.file(proxy, force=True, exportAll=True, preserveReferences=False, type='mayaBinary')
    print '\nOPEN PROXY SCENE'
    openScene(path=proxy)
    #optimize scene
    print '\nREDUCE SCENE GEOMETRY.'
    reduceSceneGeometry(reduceValue=50)
    #gpu cache
    print '\nSTART GPU CACHE PROCEDURE'
    gpuCachePath = '/'.join(proxy.split('/')[0:-1]) + '/' + (proxy.split('/')[-1]).split('.')[0]
    gpuCacheProc(exportCache=True, treshold=40000, filePath=gpuCachePath)
    print '\nIMPORT GPU CACHE'
    gpuCacheProc(importCache=True, filePath=gpuCachePath)
    #create controls
    print '\nCREATE CONTROLS FOR PROXY'
    createControls()
    print 'SAVE NEW PROXY'
    cmds.file(rename=proxy)
    cmds.file(force=True, save=True)
        
def openScene(path=''):
    '''
    path = path to opening file
    '''
    if path != '':
        try:
            cmds.file(path, force=True, open=True)
        except:
            cmds.error('FAILED TO OPEN FILE'+path)

def gpuCacheProc(importCache='', exportCache='', treshold=40000, filePath=''):
    '''
    import:
        importCache = if True import cpu cache to scene
        filePath = path to gpu cache
    export:
        exportCache = if True export all meshes to cache
        treshold = vertices treshold
        filePath = path to export gpu cache
    '''
    treshold = str(treshold)
    print 'GPU CACHE: ', filePath + '.abc'
    #check flags
    if importCache is True and exportCache is True or importCache is False and exportCache is False:
        return 'Please specify one flag import or export!'    
    #import cache
    if exportCache is True:
        #get objects
        meshes = cmds.ls(type='mesh')
        if meshes:
	    print 'gpuCache -optimize -optimizationThreshold '+treshold+' -directory "'+'/'.join(filePath.split('/')[0:-1]) +'/" -fileName "'+filePath.split('/')[-1]  +'" -allDagObjects;'
            mel.eval('gpuCache -optimize -optimizationThreshold '+treshold+' -directory "'+'/'.join(filePath.split('/')[0:-1]) +'/" -fileName "'+filePath.split('/')[-1]  +'" -allDagObjects;')
	    print 'Exported to: ', filePath
            return filePath
	else:
	    cmds.warning('File not contain geometry.')
    #export cache
    elif importCache is True:
	print '\nNEW PROXY SCENE.'
        cmds.file(force=True, newFile=True)
        gpuNode = cmds.createNode('gpuCache')
	if os.path.isfile(filePath):
	    cmds.setAttr(gpuNode+".cacheFileName", filePath+'.abc', type="string")
        return gpuNode

def reduceSceneGeometry(reduceValue=50, onlyCombine=False):
    '''
    reduceValue = reduce all geometry by this value
    onlyCombine = if True only combine all mesh and clear history
    _____________________________________
    Example:
    reduceSceneGeometry(onlyCombine=True) 
    reduceSceneGeometry(reduceValue=50) 
    '''
    meshes = cmds.ls(type='mesh')
    nonManifold = [meshes[i] for i in range(0, len(meshes)) if cmds.polyInfo(meshes[i], nonManifoldVertices=True)]
    manifold = [meshes[i] for i in range(0, len(meshes)) if not cmds.polyInfo(meshes[i], nonManifoldVertices=True)]
    for i in range(0, len(manifold)):
        cmds.polyReduce(manifold[i], percentage=reduceValue, keepQuadsWeight=0.5, compactness=1, triangulate=0, constructionHistory=False)
        cmds.delete(all=True, constructionHistory=True)
    if len(meshes) > 1:
	cmds.polyUnite(meshes)	
    cmds.delete(all=True, constructionHistory=True)
    return (cmds.ls(type='mesh'))
    
def createControls():
    '''
    create nurbs controls
    '''
    def getBoundingBoxMax(objectName=''):
        '''
        get max bounding box lenght
        objectName = object name
        '''
        bbMin = cmds.getAttr(objectName+'.boundingBoxMin')[0]
        bbMax = cmds.getAttr(objectName+'.boundingBoxMax')[0]
        xLenght = bbMax[0] - bbMin[0]
        yLenght = bbMax[1] - bbMin[1]
        zLenght = bbMax[2] - bbMin[2]
        if xLenght >= yLenght and xLenght >= zLenght:
            return xLenght
        if yLenght >= xLenght and yLenght >= zLenght:
            return yLenght
        if zLenght >= xLenght and zLenght >= yLenght:
            return zLenght       
    #get all transforms
    objects = cmds.ls(dag=True, leaf=True, shapes=True, long=True)
    objects = [objects[i] for i in range(0, len(objects)) if cmds.nodeType(objects[i]) == 'mesh' or cmds.nodeType(objects[i]) == 'gpuCache']
    objects = [cmds.listRelatives(objects[i], parent=True, fullPath=True)[0] for i in range(0, len(objects))]
    objects = cmds.rename(objects[0], 'general_CT')
    #create controls
    curveControl = mel.eval('curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;')
    curveControl = cmds.rename(curveControl, 'general_Curve')
    #create hierachy
    groupName = cmds.group(objects, n='rig')
    groupName = cmds.group(groupName, n='root')
    #setup control
    scaleMulti = getBoundingBoxMax(objectName=objects)
    cmds.setAttr(curveControl+'.scaleX', (scaleMulti*1.2))
    cmds.setAttr(curveControl+'.scaleY', (scaleMulti*1.2))
    cmds.setAttr(curveControl+'.scaleZ', (scaleMulti*1.2))
    cmds.makeIdentity(curveControl, apply=True, t=1, r=1, s=1, n=0)
    curveShape = cmds.ls(curveControl, dag=True, s=True)
    cmds.parent(curveShape, objects, add=True, shape=True)
    cmds.delete(curveControl)
    cmds.xform('general_CT', ws=True, a=True, zeroTransformPivots=True)

def referencedNodes(filename=False, nodes=True, onlyFirstLevel=False):
    '''
    This procedure get all references in scene if reference exists
    filename = if True return only file names
    nodes = if True return only reference nodes
    '''
    def containerReferences(var):
	contained = cmds.file(var, query=True, reference=True)
	if contained:
	    for i in range(0, len(contained)):
		references.append(contained[i])
		containerReferences(contained[i])
    references = cmds.file(query=True, reference=True)
    if onlyFirstLevel is False:
	if references:
	    for i in range(0, len(references)):
		containerReferences(references[i])            
    #return only references filenames
    if nodes is False and filename is True:      
	return references
    #return only references nodes
    elif filename is False and nodes is True:
	nodes = []
	for i in range(0, len(references)):
	    nodes.append(cmds.referenceQuery(references[i], referenceNode=True))
	return nodes
       
def dateCheck(original='', proxy='', magic=0):
    '''
    Return true, if original object created before proxy object
    original = file
    proxy = file
    '''
    return int(os.path.getmtime(original)) < (int(os.path.getmtime(proxy))+magic)

def getConnectedProxy(source='', original=False):
    '''
    Return proxy if reference with proxy
    source = any reference node
    '''
    proxyManager = cmds.listConnections(source, type='proxyManager')
    proxy = []
    if proxyManager:
	connectedProxy = cmds.listConnections(proxyManager, type='reference')
	if original is False:
	    if connectedProxy:
		[proxy.append(connectedProxy[i]) for i in range(0, len(connectedProxy)) if re.findall('proxy', cmds.referenceQuery(connectedProxy[i], filename=True), re.IGNORECASE) and connectedProxy[i] not in proxy]
	elif original is True:
	    [proxy.append(connectedProxy[i]) for i in range(0, len(connectedProxy)) if not re.findall('proxy', cmds.referenceQuery(connectedProxy[i], filename=True), re.IGNORECASE) and connectedProxy[i] not in proxy]
    return proxy

def createNewProxyName(source=''):
    '''
    source = source for create new proxy name
    '''
    fullName = ''
    directory = '/'.join(source.split('/')[0:-1])
    filename = source.split('/')[-1]
    if not re.findall('_[A-z, 0-9]*proxy', filename, re.IGNORECASE):
    	if re.findall('_', filename):
    	    cleanName = filename.split('_')[0]
    	    prefix = (filename.split('_', 1)[1])
    	    if re.findall('_', prefix):
    		prefix = prefix.split('_')[0]
    	    if re.findall('.', prefix):
    		prefix = prefix.split('.')[0]
    	    fullName = directory+ '/' + cleanName + '_' + prefix + 'Proxy.mb'
    	else:
    	    fullName = directory+ '/' + filename.split('.mb')[0] + '_proxy.mb'
        return fullName   
    
def connectProxyToReference(original='', proxy=''):    
    '''
    original = original reference node
    proxy = path to proxy for connect to original reference
    '''
    print '\nConnect: '+original+' to '+proxy
    mel.eval('proxyAdd "'+original+'" "'+proxy+'" "";')

def findProxy(path=''):
    '''
    Find proxy for original object if proxy object exists in root directory exists
    '''
    directory = '/'.join(path.split('/')[0:-1])+'/'
    originalName = (path.split('/')[-1]).split('.')[0]
    files = os.listdir(directory)
    if not re.findall('proxy', originalName, re.IGNORECASE):
	if re.findall('_[A-z, 0-9]+', originalName, re.IGNORECASE):
	    files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and re.findall('proxy', files[i], re.IGNORECASE) and re.findall(originalName, files[i], re.IGNORECASE)]
	else:
	    files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and re.findall('_proxy', files[i], re.IGNORECASE) and re.findall(originalName, files[i], re.IGNORECASE)]
    else:
	proxyPrefix = re.findall('proxy', originalName, re.IGNORECASE)[0]
	originalName = originalName.split(proxyPrefix)[0]
	if re.findall('_$',originalName):
	    originalName = originalName.split('_')
	    if len(originalName) > 2:
		originalName = '_'.join(originalName[0:2])
	    else:
		originalName = originalName[0]                
	files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and not re.findall('_proxy|proxy', files[i], re.IGNORECASE) and re.findall(originalName+'.', files[i], re.IGNORECASE)]
    if files:
	return directory+files[0]
    else:
	return files
    
def updateProxy(original='', proxy=''):
    '''
    This script  create proxy for selected object
    '''
    if re.findall('_[A-z, 0-9]proxy', original, re.IGNORECASE):
	proxy = proxy + '>>' + original
	original = proxy.split('>>')[0]
	proxy = proxy.split('>>')[1]
    #start process
    arguments = original+' '+proxy
    result = initScriptBatch(BATCH_RUSH_ADD_PROXY, arguments, block=True)
  
def updateGpuProxyScene():
    '''
    '''
    #Get upper reference level
    references = referencedNodes(filename=False, nodes=True, onlyFirstLevel=True)
    print 'Include: ', references
    #For eache reference node get proxy and original reference    
    for i in range(0, len(references)):
	proxy = getConnectedProxy(source=references[i], original=False)
	original = getConnectedProxy(source=references[i], original=True)
	#If proxy version exists, check proxy and original last update date
	if proxy and original:
	    filenameProxy = cmds.referenceQuery(proxy, filename=True, withoutCopyNumber=True)
	    originalName = cmds.referenceQuery(original, filename=True, withoutCopyNumber=True)
	    #If proxy last updated before oringinal, make new proxy version
	    if dateCheck(original=originalName, proxy=filenameProxy) is False:
		print 'Update connected proxy for: '+originalName+' to '+filenameProxy
		updateProxy(original=originalName, proxy=filenameProxy)#
	#Else proxy is not connected to reference
	else:
	    #Check proxy file
	    originalName = cmds.referenceQuery(references[i], filename=True, withoutCopyNumber=True)
	    filenameProxy = findProxy(originalName)
	    #If proxy file exists
	    if filenameProxy:
		#Check date last updated proxy, and if proxy updated before original, update proxy and connect to reference
		if dateCheck(original=originalName, proxy=filenameProxy) is False:
		    print 'Update proxy for: '+originalName+' to '+filenameProxy
		    updateProxy(original=originalName, proxy=filenameProxy)#IN WORK
		    connectProxyToReference(original=references[i], proxy=filenameProxy)
		else:
		    #If proxy version actual, connect proxy to reference
		    print 'Connect proxy for: '+originalName+' to '+filenameProxy
		    connectProxyToReference(original=references[i], proxy=filenameProxy)
	    else:
		#If proxy is not exists, create new proxy and connect to reference
		filenameProxy = createNewProxyName(source=originalName)
		print 'Create new proxy for: '+originalName+' in '+filenameProxy
		updateProxy(original=originalName, proxy=filenameProxy)#IN WORK
		connectProxyToReference(original=references[i], proxy=filenameProxy)

def initScriptBatch(pathToScript, stringVar, block=True):
	'''
	This script run maya in mel batch mode and execute python file scripts
	run this without maya.standalone
	
	pathToScript = path to .py file 
	stringVar = parse variables from python string
	
	
	run example:
	initScriptBatch('C:/Users/guzha_k/Desktop/mtoaTest.py', 'Hello')	
	example source:
	import sys
	arguments = (str('{0}'.format(sys.argv[4])))
	'''
	import subprocess
	mayaExe = os.path.join(os.path.split(sys.executable)[0], 'maya')
	#string to run maya batch with user settings
	command = mayaExe + ' -batch -command "python(\\"\"execfile(' + "\\'" + pathToScript + "\\'" + ')\"\\")"' + ' "' + stringVar + '"'
	print command
	#run maya batch
	block = block is True and 'call' or 'Popen'
	exec('subprocess.'+block+'(command, stdin=None, stdout=None, stderr=None, shell=False)')

main()







