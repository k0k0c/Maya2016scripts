import maya.cmds as cmds        
import maya.OpenMaya as om

def getMFnTransform( transform ):
    selectionList = om.MSelectionList()
    selectionList.add( transform )
    dagPath = om.MDagPath()
    selectionList.getDagPath(0, dagPath )
    mfnTransform = om.MFnTransform( dagPath )
    return mfnTransform

def getBoundingBox( shape ):
    selectionList = om.MSelectionList()
    selectionList.add( shape )
    dagPath = om.MDagPath()
    selectionList.getDagPath(0, dagPath )
    fnMesh = om.MFnMesh( dagPath )
    boundingBox = fnMesh.boundingBox()
    return boundingBox

def makeBoundingBox( transforms=[], color=( 0, 0, 0 ), group="", debug=True ):     
    transforms = transforms and ( type( transforms ) is list and transforms or [ transforms ] ) or cmds.ls( sl=True, type="transform" )
    for i in range( 0, len( transforms )):
        parent = cmds.listRelatives( transforms[i], parent=True ) 
        if parent and parent[0] != group or not parent:
            pivot = cmds.xform( transforms[i], query=True, worldSpace=True, scalePivot=True )  
            rotation = cmds.xform( transforms[i], query=True, worldSpace=True, rotation=True )
            scale = cmds.xform( transforms[i], query=True, scale=True )
            parents = cmds.listRelatives( transforms[i], allParents=True, fullPath=True )
            for p in range( 0, len( parents )):
                sscale = cmds.xform( parents[p], query=True, scale=True )
                scale = [ scale[0] * sscale[0], scale[1] * sscale[1], scale[2] * sscale[2] ]              
            selectionList = om.MSelectionList()
            selectionList.add( transforms[i] )
            dagPath = om.MDagPath()
            selectionList.getDagPath(0, dagPath )
            center = cmds.objectCenter( transforms[i] )
            boundingBox = om.MBoundingBox()
            meshes = cmds.ls( transforms[i], dag=True, type="mesh", long=True )
            for m in range( 0, len( meshes )):
                bb = getBoundingBox( meshes[m] )
                boundingBox.expand( bb )
            name = "%s_bb" % "_y_".join( "_x_".join( transforms[i].split( ":" )).split( "|" ))
            if cmds.objExists( name ):
                cmds.delete( name )
            cube = cmds.polyCube( name=name, w=boundingBox.width(), h=boundingBox.height(), d=boundingBox.depth())
            cube = cube[0]
            cmds.setAttr( "%s.t" % cube, center[0], center[1], center[2] )
            cmds.setAttr( "%s.r" % cube, rotation[0], rotation[1], rotation[2] )
            cmds.setAttr( "%s.s" % cube, scale[0], scale[1], scale[2] )
            cmds.xform( cube, worldSpace=True, scalePivot=[ pivot[0], pivot[1], pivot[2] ] )
            cmds.xform( cube, worldSpace=True, rotatePivot=[ pivot[0], pivot[1], pivot[2] ] )
            if group != "":
                if not cmds.objExists( group ):
                    cmds.group( name=group, empty=True )
                cmds.parent( cube, group )
        else:
            cube = transforms[i]
        cmds.polyColorPerVertex( cube, r=color[0], g=color[1], b=color[2], colorDisplayOption=True )