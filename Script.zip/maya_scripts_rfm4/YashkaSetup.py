import site
import codecs
import glob
import re
import shutil
import sys, os

import rfm.rlf2maya as rlf2maya
import rfm.passes

import maya.OpenMayaUI as mui

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

import re
from PyQt4 import QtCore, QtGui
import maya.cmds as cmds
import maya.mel as mel
import sip

import math

def getMayaWindow():
   ptr = mui.MQtUtil.mainWindow()
   return sip.wrapinstance(long(ptr), QtCore.QObject)


def convertSpotToRMS(dist,resolution):
    lights = cmds.ls(sl=True, dag=True, type='transform')
    lights = [lights[i] for i in range(0, len(lights)) if cmds.ls(lights[i], dag=True, leaf=True, type='spotLight')]
    if lights:
        for i in range(0, len(lights)):
            #get old attributes
            light = lights[i]
            intensity = cmds.getAttr(light + '.intensity')
            decayRate = cmds.getAttr(light + '.decayRate')
            #coneAngle = cmds.getAttr(light + '.coneAngle')
            #penumbraAngle = cmds.getAttr(light + '.penumbraAngle')
            #dropoff = cmds.getAttr(light + '.dropoff')
            emitDiffuse = cmds.getAttr(light + '.emitDiffuse')
            emitSpecular = cmds.getAttr(light + '.emitSpecular')
            lightColor = cmds.getAttr(light + '.color')[0];
            shadowColor = cmds.getAttr(light + '.shadowColor')[0]
            shadowUsed = cmds.getAttr(light + '.useDepthMapShadows')
            targetIntensity = getTargetIntensityByDistance(dist, intensity, decayRate)
            #create new lights
            rmsLight=cmds.shadingNode("RMSGeoAreaLight",asLight=True)
            rmsLight=cmds.rename(rmsLight,light+"_GEO")
            rmsLight=cmds.parent(rmsLight,light)[0]

            cmds.setAttr(rmsLight+".tx",0)
            cmds.setAttr(rmsLight+".ty",0)
            cmds.setAttr(rmsLight+".tz",0)
            cmds.setAttr(rmsLight+".rx",0)
            cmds.setAttr(rmsLight+".ry",0)
            cmds.setAttr(rmsLight+".rz",0)
            cmds.setAttr(rmsLight+".sx",1)
            cmds.setAttr(rmsLight+".sy",1)
            cmds.setAttr(rmsLight+".sz",1)
            kudaParent="|".join(cmds.ls(light,l=True)[0].split("|")[:-1])
            if kudaParent!="":
                rmsLight=cmds.parent(rmsLight,kudaParent)[0]
            else:                
                rmsLight=cmds.parent(rmsLight,world=True)[0]
            rmsLightShape = cmds.ls(rmsLight, dag=True, type='RMSGeoAreaLight')[0]
            #cmds.setAttr((rmsLightShape + '.shape'), 'spot', type='string')
            #cmds.setAttr(rmsLightShape + '.coneangle', coneAngle)
            #cmds.setAttr(rmsLightShape + '.distributionAngle', coneAngle)
            #cmds.setAttr(rmsLightShape + '.penumbraangle', penumbraAngle)
            cmds.setAttr(rmsLightShape + '.areaNormalize', 1)
            #cmds.setAttr(rmsLightShape + '.penumbraexponent', dropoff)
            cmds.setAttr(rmsLightShape + '.temperature', -1)
            cmds.setAttr(rmsLightShape + '.lightcolor', lightColor[0], lightColor[1], lightColor[2], type='double3')
            cmds.setAttr(rmsLightShape + '.diffAmount', emitDiffuse, emitDiffuse, emitDiffuse, type='double3')
            cmds.setAttr(rmsLightShape + '.specAmount', emitSpecular, emitSpecular, emitSpecular, type='double3')
            cmds.setAttr(rmsLightShape + '.shadowColor', shadowColor[0], shadowColor[1], shadowColor[2], type='double3')
            cmds.setAttr(rmsLightShape + '.intensity', getBaseIntensityByTargetIntensity(dist, targetIntensity))
            if shadowUsed == 1:
                cmds.setAttr(rmsLightShape + '.traceShadows', 0)
                areaShadowPass=""
                rfm.passes.Update()
                shadowsPasses = rfm.passes.GetPasses("AreaShadow")
                for i in shadowsPasses:
                    if i.GetID() == "AreaShadoW"+light:
                        areaShadowPass=i
                if areaShadowPass == "":
                    areaShadowPass = rfm.passes.CreatePass("AreaShadow")
                    areaShadowPass.Rename(light+"_AreaShadoW")

                areaShadowPass.SetAttr("rman__riopt__Format_resolution", resolution)                    
                shadowPass = areaShadowPass.GetID()

                cameraShadow = cmds.camera(hfa=1.4, vfa=1.4, n=(light+"_SHADOW"))[0]
                cameraShadow=cmds.parent(cameraShadow, rmsLight)[0]
                cmds.setAttr(cameraShadow+'.translate', 0, 0, 0)
                cmds.setAttr(cameraShadow+'.rotate', 0, 0, 0)
                cmds.connectAttr(cmds.ls(cameraShadow, dag=True, type='camera')[0]+'.message', shadowPass+'.rman__torattr___camera', f=True)
                cmds.connectAttr(shadowPass+'.message', rmsLightShape+'.shadowname', f=True)
                cmds.setAttr(cameraShadow+".visibility", 0)
            else:
                cmds.setAttr(rmsLightShape + '.traceShadows', 0)
            cmds.setAttr(light+".visibility", 0)

            cmds.select(rmsLight)

    else:
        cmds.warning("Vydelite StopLight")
    
    
def getTargetIntensityByDistance(distance, intensity, decayRate):
    if decayRate == 0:
        return intensity
    elif decayRate == 1:
        return (intensity/distance)
    elif decayRate == 2:
        return (intensity/(distance**2))  
    elif decayRate == 3:
        return (intensity/(distance**3))
        
def getBaseIntensityByTargetIntensity(saveDistance, intensity):
        #print saveDistance
        #print intensity
        return math.log(intensity*(saveDistance**2), 2)
        
        


       

class Window(QtGui.QDialog):
    def __init__(self, parent=getMayaWindow()):
        super(Window, self).__init__(parent)
  
        self.mainLayout = QtGui.QVBoxLayout()
        
        self.groupBoxSpotConvert = QtGui.QGroupBox(" Spot Convert: ")
        self.spotLayout = QtGui.QHBoxLayout()
        self.convertSpin = QtGui.QSpinBox()
        self.convertSpin.setRange(0,10000)
        self.convertSpin.setValue(50)
        self.convertCombobox = QtGui.QComboBox()
        self.convertComboboxList = QtCore.QStringList()
        self.convertComboboxList.append("128")
        self.convertComboboxList.append("256")        
        self.convertComboboxList.append("512")
        self.convertComboboxList.append("1024")        
        self.convertComboboxList.append("2048")
        self.convertComboboxList.append("4096")        
        self.convertComboboxList.append("8192")
        self.convertComboboxList.append("16384")      
        self.convertCombobox.addItems(self.convertComboboxList)
        self.convertCombobox.setCurrentIndex(2)                
        self.convertButton = QtGui.QPushButton("Convert")
        self.convertButton.released.connect(self.convertSpot)
        self.spotLayout.addWidget(self.convertSpin)
        self.spotLayout.addWidget(self.convertCombobox)
        self.spotLayout.addWidget(self.convertButton)        
        self.groupBoxSpotConvert.setLayout(self.spotLayout)
        
        
        self.groupBoxLightGroups = QtGui.QGroupBox(" Light Groups: ")
        self.oneLayout = QtGui.QHBoxLayout()
        self.numGroupsSpin = QtGui.QSpinBox()
        self.setButton = QtGui.QPushButton("Set")
        self.setButton.released.connect(self.setLightGroups)
        self.deleteButton = QtGui.QPushButton("Delete")
        self.deleteButton.released.connect(self.deleteLightGroups)
        self.oneLayout.addWidget(self.numGroupsSpin)
        self.oneLayout.addWidget(self.setButton)
        self.oneLayout.addWidget(self.deleteButton)
        self.groupBoxLightGroups.setLayout(self.oneLayout)

        self.groupBoxSetLights = QtGui.QGroupBox(" Set Lights: ")
        
        self.lightsButton = QtGui.QPushButton("None")
        self.lightsButton.released.connect(self.setLight)        
        self.selectButton = QtGui.QPushButton("select")
        self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)        
        self.selectButton.setProperty("ssss","None")        
        self.selectButton.released.connect(self.selectLight)                
        self.LayoutButtons = QtGui.QHBoxLayout()
        self.LayoutButtons.addWidget(self.lightsButton)
        self.LayoutButtons.addWidget(self.selectButton)
        
                            
        self.LayoutSetLights = QtGui.QVBoxLayout()
        self.LayoutSetLights.addLayout(self.LayoutButtons)
        
        
        self.groupBoxSetLights.setLayout(self.LayoutSetLights)
        
        #get exsists buttons
        rfm.passes.Update()
        Finals = rfm.passes.GetPasses("Final")    
        arrayButtomNames=[]    
        for i in Finals[0].GetChannelList():    
            m=re.search(".*use_(?P<set>lightset.*)",i.GetName())
            if m is not None:
                arrayButtomNames.append(m.group("set"))

        for i in arrayButtomNames:
                self.lightsButton = QtGui.QPushButton(i)
                self.lightsButton.released.connect(self.setLight)
                self.selectButton = QtGui.QPushButton("select")
                self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                        
                self.selectButton.setProperty("ssss",i)
                self.selectButton.released.connect(self.selectLight)                
                self.LayoutButtons = QtGui.QHBoxLayout()
                self.LayoutButtons.addWidget(self.lightsButton)
                self.LayoutButtons.addWidget(self.selectButton)
                self.LayoutSetLights.addLayout(self.LayoutButtons)
        
        self.mainLayout.addWidget(self.groupBoxSpotConvert)        
        self.mainLayout.addWidget(self.groupBoxLightGroups)
        self.mainLayout.addWidget(self.groupBoxSetLights)        
        self.setLayout(self.mainLayout)
        #self.resize(350, 550)
        self.setWindowTitle('Yashka')
      
      
      
    def convertSpot(self):
        convertSpotToRMS(self.convertSpin.value(),self.convertCombobox.currentText()+" "+self.convertCombobox.currentText())
        
        
    def setLightGroups(self):
            #install                            
            self.deleteLightGroups()
            for i in range(0, self.numGroupsSpin.value()):
                if i == 0:
                    self.lightsButton = QtGui.QPushButton("lightset")
                    self.lightsButton.released.connect(self.setLight)
                    self.selectButton = QtGui.QPushButton("select")
                    self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                            
                    self.selectButton.setProperty("ssss","lightset")
                    self.selectButton.released.connect(self.selectLight)                
                    self.LayoutButtons = QtGui.QHBoxLayout()
                    self.LayoutButtons.addWidget(self.lightsButton)
                    self.LayoutButtons.addWidget(self.selectButton)
                else:                
                    self.lightsButton = QtGui.QPushButton("lightset"+str(i))            
                    self.lightsButton.released.connect(self.setLight)                    
                    self.selectButton = QtGui.QPushButton("select")
                    self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                            
                    self.selectButton.setProperty("ssss","lightset"+str(i))                    
                    self.selectButton.released.connect(self.selectLight)                
                    self.LayoutButtons = QtGui.QHBoxLayout()
                    self.LayoutButtons.addWidget(self.lightsButton)
                    self.LayoutButtons.addWidget(self.selectButton)
                    
                self.LayoutSetLights.addLayout(self.LayoutButtons)
                
            rfm.passes.Update()
            Finals = rfm.passes.GetPasses("Final")
            spinNUM=self.numGroupsSpin.value()

            SECONDARY_OUTPUTS = []
            for i in range(0,spinNUM):
                num = str(i)
                if num == "0":
                    num=""
                SECONDARY_OUTPUTS.append("color GroupedDiffuse_lightset"+num)
                SECONDARY_OUTPUTS.append("color GroupedSpecular_lightset"+num)
                Finals[0].AddChannel("color GroupedDiffuse_lightset"+num)
                Finals[0].AddChannel("color GroupedSpecular_lightset"+num)
            
            if SECONDARY_OUTPUTS != []:
                display = Finals[0].AddDisplay(SECONDARY_OUTPUTS)
                display.SetDspyID("LightGroups")    
                cmds.setAttr("renderManGlobals.rman__torattr___defaultRiOptionsScript", "RiOption \"user\" \"int lightGroupsNum\" "+str(spinNUM)+";",type="string")
                display.SetAttr("rman__riopt__Display_type","openexr")  
                display.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
                display.SetAttr("rman__riopt__Display_dither","0")    
                display.AddAttr("rman__riopt__Display_exrcompression")
                display.SetAttr("rman__riopt__Display_exrcompression","zip")
                display.AddAttr("rman__riopt__Display_exrpixeltype")
                display.SetAttr("rman__riopt__Display_exrpixeltype","half")
                display.AddAttr("rman__riopt__Display_autocrop")
                display.SetAttr("rman__riopt__Display_autocrop","true")
                display.AddAttr("rman__riopt__Display_filter")
                display.SetAttr("rman__riopt__Display_filter","separable-catmull-rom")
                display.AddAttr("rman__riopt__Display_filterwidth")
                display.SetAttr("rman__riopt__Display_filterwidth0",4)
                display.SetAttr("rman__riopt__Display_filterwidth1",4)
                #display.Update()
                #Finals[0].Update()
                #rfm.passes.Update()
                #PassManager=rfm.passes.GetPassManager()
                #PassManager.Update()                


    def deleteLightGroups(self):
            #remove
            '''for i in reversed(range(self.LayoutSetLights.count())): 
                if i > 0:
                    child = self.LayoutSetLights.takeAt(i)
                    child.widget().deleteLater()
            '''
            while self.LayoutSetLights.count() > 1:
                d=self.LayoutSetLights.takeAt(1)
                while d.count():
                    ds=d.takeAt(0)
                    ds.widget().deleteLater()
                d.deleteLater()                    
                    
            rfm.passes.Update()
            Finals = rfm.passes.GetPasses("Final")
            for i in Finals[0].GetDisplayList():
                if i.GetLabel() == "LightGroups":
                    Finals[0].DeleteDisplay(i)
                
            for i in Finals[0].GetChannelList():    
                m=re.match("(GroupedDiffuse.*)|(GroupedSpecular.*)",i.GetName())
                if m is not None:
                    Finals[0].DeleteChannel(i)
     
            cmds.setAttr("renderManGlobals.rman__torattr___defaultRiOptionsScript", "",type="string")       
            #Finals[0].Update()
            #rfm.passes.Update()
            #PassManager=rfm.passes.GetPassManager()
            #PassManager.Update()


    def setLight(self):
        sender = self.sender()
        nameLightGroup=sender.text()
        #print(nameLightGroup)
        
        if nameLightGroup == "None":
            nameLightGroup=""
        for i in cmds.ls(sl=True,dag=True,s=True):
            #print(i)
            if cmds.nodeType(i) == "RMSGeoAreaLight" or cmds.nodeType(i) == "RMSEnvLight":
                cmds.setAttr(i+".__group",nameLightGroup,type="string")


    def selectLight(self):
        sender = self.sender()
        nameLightGroup=sender.property("ssss").toString()
        if nameLightGroup == "None":
            nameLightGroup=""
            
        cmds.select(clear=True)
        for i in cmds.ls(type=["RMSGeoAreaLight","RMSEnvLight"]):
                if cmds.getAttr(i+".__group") == nameLightGroup:
                    cmds.select("|".join(cmds.ls(i,l=True)[0].split("|")[:-1]),add=True)
                    



#mOd = Window()
#mOd.show()



