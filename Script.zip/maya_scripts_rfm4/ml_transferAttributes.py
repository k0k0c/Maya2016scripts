import maya.cmds as cmds
import re

def ml_transferAttributes( src="", dst="" ):
	#_______________________________________________________________________________________________________________________
	def ml_listAttr( m_node, exactType="" ):
		#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
		#List attributes for current node by type.
		m_result = []
		m_node = cmds.ls( m_node, long=True )
		m_type = type( exactType ) is list and exactType or [ exactType ]
		m_list = cmds.listAttr( m_node, settable=True )
		for n in range( 0, len( m_node )):
			for i in range( 0, len( m_list )):
				try:
					m_temp = cmds.getAttr( "%s.%s" % ( m_node[n], m_list[i] ), type=True )
					if m_temp in m_type:
						m_result.append( m_list[i] )
				except:
					pass
		return m_result
		#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
	if src == "":
		m_src = cmds.ls( sl=True, long=True )[0]
	else:
		m_src = cmds.ls( src, long=True )[0]
	if dst == "":
		m_dst = cmds.ls( sl=True, long=True )
	else:
		m_dst = cmds.ls( dst, long=True )
	for s in range( 0, len( m_dst )):
		#Attributes type list.
		m_allowType = [ "bool", "long", "short", "byte", "char", "enum", "float", "double", "doubleAngle", "doubleLinear", "compound", "float2", "float3", "double2", "double3", "long2", "long3", "short2", "short3", "string" ]
		m_attributeType = [ "bool", "long", "short", "byte", "char", "enum", "float", "double", "doubleAngle", "doubleLinear", "compound", "message", "time", "fltMatrix", "reflectance", "float2", "float3", "double2", "double3", "long2", "long3", "short2", "short3" ]
		m_dataType = [ "string", "stringArray", "matrix", "reflectanceRGB", "spectrumRGB", "doubleArray", "Int32Array", "vectorArray", "nurbsCurve", "nurbsSurface", "mesh", "lattice", "pointArray" ]
		#Get attributes list.
		m_src_attrs = ml_listAttr( m_src, exactType=m_allowType )
		m_dst_attrs = ml_listAttr( m_dst[s], exactType=m_allowType )
		#Transfer values.
		for i in range( 0, len( m_src_attrs )):
			try:
				#Get info about attributes.
				m_type = cmds.getAttr( "%s.%s" % ( m_src, m_src_attrs[i] ), type=True )
				m_value = cmds.getAttr( "%s.%s" % ( m_src, m_src_attrs[i] ))
				#Add new attributes.
				if m_src_attrs[i] not in m_dst_attrs:
					if m_type in m_attributeType:
						cmds.addAttr( m_dst[s], longName=m_src_attrs[i], at=m_type )
					else:
						cmds.addAttr( m_dst[s], longName=m_src_attrs[i], dt=m_type )
				#Copy attribute content.
				if m_value != cmds.getAttr( "%s.%s" % ( m_dst[s], m_src_attrs[i] )) or m_connections != cmds.listConnections( "%s.%s" % ( m_dst[s], m_src_attrs[i] )):
					#Copy value.
					if m_type in [ "short", "long", "byte", "char", "enum", "float", "double", "bool" ]:
						cmds.setAttr( "%s.%s" % ( m_dst[s], m_src_attrs[i] ), m_value )
					else:
						if m_type in [ "float2", "double2", "long2", "short2" ]:
							cmds.setAttr( "%s.%s" % ( m_dst[s], m_src_attrs[i] ), m_value[0][0], m_value[0][1], type=m_type )
						elif m_type in [ "float3", "double3", "long3", "short3" ]:
							cmds.setAttr( "%s.%s" % ( m_dst[s], m_src_attrs[i] ), m_value[0][0], m_value[0][1], m_value[0][2], type=m_type )
						else:
							cmds.setAttr( "%s.%s" % ( m_dst[s], m_src_attrs[i] ), m_value, type=m_type )
			except:
				pass
		#Transfer connections.
		m_src_connections = cmds.listConnections( m_src, plugs=True )
		if m_src_connections:
			for i in range( 0, len( m_src_connections )):
				try:
					m_regexp = re.compile( ".inMesh", re.IGNORECASE )
					m_dst_connections = cmds.listConnections( m_src_connections[i], plugs=True )[0]
					m_dst_connections = "%s.%s" % ( m_dst[s], ".".join( m_dst_connections.split( "." )[1:]))
					m_source = cmds.connectionInfo( m_src_connections[i], isSource=True ) and True or False
					m_compound = False
					if not m_regexp.findall( m_dst_connections ) or not m_regexp.findall( m_dst_connections ):
						if re.findall( "\[[0-9]+\]", m_dst_connections ):
							m_dst_connections = "[".join( m_dst_connections.split( "[" )[0:-1] )
							m_compound = True
						if re.findall( "\[[0-9]+\]", m_src_connections[i] ):
							m_src_connections[i] = "[".join( m_src_connections[i].split( "[" )[0:-1] )
							m_compound = True
						if m_source is True:
							cmds.connectAttr( m_src_connections[i], m_dst_connections, force=True, na=m_compound )
						else:
							m_connections = cmds.listConnections( m_dst_connections, plugs=True )
							if m_connections:
								for n in range( 0, len( m_connections )):
									cmds.disconnectAttr( m_dst_connections, m_connections[n] )
							cmds.connectAttr( m_dst_connections, m_src_connections[i], force=True, na=m_compound )
				except:
					pass
	return m_dst
	#_______________________________________________________________________________________________________________________
	
	
	
#if m_type in [ "short", "long", "byte", "char", "enum", "float", "double" ]:	