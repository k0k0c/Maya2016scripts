import os
import re
import maya.cmds as cmds
import maya.mel as mel
import json
import glob
import main

def alembicSetup( renderableOnly=False, writeVisisbility=False, worldSpace=False, stripNamespaces=False, onlyCharacters=False, temp=False, connectVisibility=False, connectTransforms=False, fitTimeRange=False ):
    #exportAlembic( renderableOnly=renderableOnly, writeVisisbility=writeVisisbility, worldSpace=worldSpace, stripNamespaces=stripNamespaces, onlyCharacters=onlyCharacters, output="", temp=temp )
    output = main.pathToAlembic( temp=temp )
    print "alembic:", output
    filename = cmds.file( query=True, sceneName=True )
    print "scene:", filename
    sceneName = filename.split( "/" )[-1].split( "." )[0]
    sceneName = sceneName != "" and sceneName or "untitled"
    sceneName = sceneName.split( "_" )[0]
    settings = output + "/" + sceneName + ".js"
    print "settings:", settings
    data = main.readAlembicSettings( settings )
    print "data:", data
    importAlembicFromSettings( dictionary=data, connectVisibility=connectVisibility, connectTransforms=connectTransforms, fitTimeRange=fitTimeRange )
    #project = cmds.workspace( query=True, rootDirectory=True )
    #project = main.pathToNetwork( project, toServer3d=True )
    #name = project.split( "/" )[-2]
    #work = os.path.join( project, "light/work/" )
    #files = glob.glob( work + name + "_v*_light.m[ab]" )
    #version = max( files, key=main.lastVersion )
    #version = main.lastVersion( version )
    #version = str( version + 1 )
    #version = ( "0" * ( 3 - len( version ))) + version 
    #filename = os.path.join( work, name + "_v" + version + "_light.mb" )
    #print "save:", filename
    #cmds.file( rename=filename )
    #cmds.file( f=True, save=True, options="v=0", type="mayaBinary" )

def exportAlembic( renderableOnly=False, writeVisisbility=False, worldSpace=False, stripNamespaces=False, onlyCharacters=False, output="", temp=False ):
    if not cmds.pluginInfo( "AbcExport", query=True, loaded=True ):
        cmds.loadPlugin("AbcExport")
    #Settings.
    start = cmds.playbackOptions( query=True, animationStartTime=True )
    end = cmds.playbackOptions( query=True, animationEndTime=True )
    renderableOnly = renderableOnly is True and " -renderableOnly" or ""
    writeVisisbility = writeVisisbility is True and " -writeVisibility" or ""
    worldSpace = worldSpace is True and " -worldSpace" or ""
    stripNamespaces = stripNamespaces is True and " -stripNamespaces" or ""
    #Output directory for alembic cache.
    if output == "":
        output = main.pathToAlembic( temp=temp )
    if not os.path.isdir( output ):
        os.makedirs( output )
    print "directory:", output
    #Export to alembic.
    data = {}
    animations = main.animatedReferencedNodes( characters=onlyCharacters, ignoreProxy=True )
    evalAlembic = "AbcExport"
    controls = cmds.ls( ["*:switch_CT", "*:general_CT"], recursive=True, long=True )
    for animation in animations:
        value = ""
        filename = animation[0]
        filenameRes = filename.split( "{" )[0]
        names = animation[-1]
        if cmds.ls( names, type="gpuCache" ):
            continue
        for control in controls:
            if control in names:
                value = ""
                if cmds.ls( "%s.position_modify" % control ):
                    value = cmds.getAttr( "%s.position_modify" % control, asString=True )     
                elif cmds.ls( "%s.clothType" % control ):
                    value = cmds.getAttr( "%s.clothType" % control, asString=True )
                elif cmds.ls( "%s.type_" % control ):
                    value = cmds.getAttr( "%s.type_" % control, asString=True )
                if value != "":
                    break
        print "\nvalue:", value
        #render = main.findRenderVersion( filename=filename, value=value )
        render = main.getAssetFirstVersion(filenameRes, type="render", findLastFileIfNotFinal=True, palevo=value )
        render = render.replace( "\\", "/" )
        print "version:", render
        if names:
            group = ""
            for name in names:
                parts = name.split( "|" )
                orname = [ part.split(":")[-1] for part in parts ]
                orname = "|".join( orname )
                if re.findall( "\|geometry_grp$|\|geo_normal$|^geometry_grp$|^geo_normal$", orname ):
                    group = name
                    break
            if group != "":
                alembic = filename.split( "/" )[-1]
                alembic = alembic.replace( "}", "" ).replace( "{", "_" ).replace( ".ma", "" ).replace( ".mb", "" )
                alembic = output + "/" + alembic + ""
                print "filename:", filename
                print "node:", group
                print "alembic:", alembic
                data.update( { alembic + ".abc":render } )
                evalAlembic += " -j \"-root " + group + " -fr " + str( start ) + " " + str( end ) + " -noNormals -ef" + worldSpace + stripNamespaces + renderableOnly + writeVisisbility + " -file " + alembic + ".abc\""
    if evalAlembic != "AbcExport":
        sceneName = cmds.file( query=True, sceneName=True ).split( "/" )[-1].split( "." )[0]
        sceneName = sceneName != "" and sceneName or "untitled"
        sceneName = sceneName.split( "_" )[0]
        abcSettings = output + "/" + sceneName + ".js"
        container = file( abcSettings, "w" )
        json.dump( data, container, indent=4, ensure_ascii=False )
        container.close()
        print "\nwrite settings:", abcSettings
        print "\n", evalAlembic
        mel.eval( evalAlembic )
        print "done"
        
def importAlembicFromSettings( dictionary={}, connectVisibility=False, connectTransforms=False, fitTimeRange=False ):
    if not cmds.pluginInfo( "AbcExport", query=True, loaded=True ):
        cmds.loadPlugin("AbcExport")
    if not dictionary:
        dictionary = main.readAlembicSettings()
    abcPaths = dictionary.keys()
    references = cmds.file( query=True, reference=True )
    for abcPath in abcPaths:
        isFind = False
        for reference in references:
            filename = reference.split( "{" )[0]
            rfn = cmds.file( reference, query=True, rfn=True )
            if cmds.referenceQuery( rfn, isLoaded=True ):
                sfilename = main.pathToNetwork( filename.split( "{" )[0] )
                srender = main.pathToNetwork( dictionary[abcPath].split( "{" )[0] )
                if sfilename == srender:
                    importAlembic( abcPath, rfn, connectVisibility=connectVisibility, connectTransforms=connectTransforms, fitTimeRange=fitTimeRange )
                    references.pop( references.index( reference ))
                    isFind = True
                    break
        if isFind is False:
            importAlembic( abcPath, dictionary[abcPath], connectVisibility=connectVisibility, connectTransforms=connectTransforms, fitTimeRange=fitTimeRange )

def importAlembic( abcFile, mayaFile, connectVisibility=False, connectTransforms=False, fitTimeRange=False ):
    print "\nImport:", abcFile
    print "Target:", mayaFile
    group = cmds.ls( "cache", assemblies=True )
    if not group:
        group = cmds.createNode( "transform", n="cache" )
    else:
        group = group[-1]
    if not cmds.objExists( mayaFile ):
        isFile = True
        mayaPath = main.pathToNetwork( mayaFile )
    else:
        isFile = False
        mayaPath = cmds.referenceQuery( mayaFile, filename=True )
    abcPath = main.pathToNetwork( abcFile )
    if os.path.isfile( abcPath ):
        if os.path.isfile( mayaPath ):
            abcName = abcPath.split( "/" )[-1].split( "." )[0]
            longAbcFolderName = "|" + group + "|" + abcName
            if cmds.ls( longAbcFolderName ):
                cmds.rename( longAbcFolderName, longAbcFolderName + "_tmp" )
            cacheFolder = cmds.createNode( "transform", n=abcName, parent=group )
            longAbcFolderName = "|" + group + "|" + cacheFolder
            fitTimeRange = fitTimeRange is True and "-fitTimeRange" or ""
            mel.eval( "AbcImport" + fitTimeRange + " -rpr " + longAbcFolderName + " \"" + abcPath + "\"" )
            if len( cmds.ls( longAbcFolderName, dag=True, l=True)) <= 1:
                print "Alembic cache %s has not containing any geometry" % abcName
            else:
                mayaType = mayaPath.split( "/" )[-1].split( "." ) 
                mayaName = mayaType[0]
                mayaType = mayaType[-1] == "mb" and "mayaBinary" or "mayaAscii" 
                if isFile is True:
                    mayaNodes = cmds.file( mayaPath, type=mayaType, options="v=0", reference=True, namespace=mayaName, returnNewNodes=True )
                else:
                    mayaNodes = cmds.referenceQuery( mayaPath, nodes=True, dagPath=True )
                abcNodes = cmds.ls( longAbcFolderName, dag=True, long=True )
                if connectTransforms is True:
                    print "Connect attributes:"
                    transforms = cmds.ls( mayaNodes, type="transform", long=True )
                    abcTransforms = cmds.ls( abcNodes, type="transform", long=True )
                    lenght = len( transforms )
                    it = 0
                    for transform in transforms:
                        it += 1
                        ctransform = main.cleanName( transform )
                        for abcTransform in abcTransforms:
                            cabcTransform = main.cleanName( abcTransform )
                            shortName = cabcTransform.split( longAbcFolderName )[-1]
                            if shortName and shortName != "" and shortName in ctransform:
                                it += 1
                                print lenght, "/", it, "Found:", abcTransform, "to", transform
                                abcTransforms.pop( abcTransforms.index( abcTransform ))
                                try:
                                    cmds.connectAttr( abcTransform + ".t", transform + ".t", force=True )
                                    cmds.connectAttr( abcTransform + ".r", transform + ".r", force=True )
                                    cmds.connectAttr( abcTransform + ".s", transform + ".s", force=True )
                                except:
                                    print "Attributes is locked:", transform
                                if connectVisibility is True:
                                    try:
                                        cmds.connectAttr( "%s.visibility" % abcTransform, "%s.visibility" % transform, force=True)
                                    except:
                                        print "Attributes visibility is locked:", transform
                                break
                print "Connect geometry:"
                meshes = cmds.ls( mayaNodes, type="mesh", long=True )
                abcMeshes = cmds.ls( abcNodes, type="mesh", long=True )
                lenght = len( abcMeshes )
                it = 0
                for mesh in meshes:
                    cmesh = main.cleanName( mesh )
                    for abcMesh in abcMeshes:
                        cabcMesh = main.cleanName( abcMesh )
                        shortName = cabcMesh.split( longAbcFolderName )[-1]
                        if shortName in cmesh:
                            it += 1
                            print lenght, "/", it, "Found:", cabcMesh, "to", mesh
                            abcMeshes.pop( abcMeshes.index( abcMesh ))
                            blendShape = ""
                            history = cmds.listHistory( mesh )
                            for connection in history:
                                if cmds.nodeType( connection ) == "blendShape":
                                    blendShape = connection
                                    break
                            if blendShape != "":
                                blconnection = cmds.listConnections( "%s.inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget" % blendShape )
                                if blconnection:
                                    if type( blconnection ) is list:
                                        blconnection = blconnection[-1]
                                    cmds.disconnectAttr( "%s.worldMesh[0]" % blconnection, "%s.inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget" % blendShape )
                                    cmds.delete( blconnection )
                                try:
                                    cmds.connectAttr( "%s.worldMesh[0]" % abcMesh, "%s.inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget" % blendShape, force=True )
                                except:
                                    print "Failed to replace blendshape", blendShape
                            else:
                                try:
                                    cmds.blendShape( abcMesh, mesh, frontOfChain=True, o="world", w=[0,1] )
                                except:
                                    print "Failed to create blendshape for %s from %s" % ( abcMesh, mesh )
                            break
                print "Hide:", longAbcFolderName
                cmds.setAttr( "%s.visibility" % longAbcFolderName, 0 )
        else:
            print "File not exists:", mayaPath 
    else:
        print "File not exists:", abcPath
        
        
#abcFile = "//SERVER-3D/Project/UrfinJuse/scenes/ep07/ep07sc09/cache/alembic/lanPirot.abc.abc"
#mayaFile = "//SERVER-3D/Project/UrfinJuse/assets/chars/LanPirot/maya/lanPirot_render.mb"
#importAlembic( abcFile, mayaFile, connectVisibility=False, connectTransforms=False, fitTimeRange=False ) 
#import exportAlembic
#reload(exportAlembic)
#exportAlembic.exportAlembic( renderableOnly=False, writeVisisbility=True, worldSpace=True, stripNamespaces=False, onlyCharacters=False, output="", temp=False )
#import exportAlembic
#reload(exportAlembic)
#exportAlembic.alembicSetup( renderableOnly=False, writeVisisbility=False, worldSpace=True, stripNamespaces=False, onlyCharacters=False, temp=False, connectVisibility=False, connectTransforms=False, fitTimeRange=False )