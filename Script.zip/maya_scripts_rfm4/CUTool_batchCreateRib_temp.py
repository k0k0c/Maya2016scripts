import sys
import os
import re
import maya.standalone
maya.standalone.initialize(name='python')
import maya.cmds as cmds
import maya.mel as mel
cmds.loadPlugin('RenderMan_for_Maya')
print 'rib export started'

def openTargetFile():
    #Get arguments
    arguments = (str('{0}'.format(sys.argv[1]))).split(' ')
    pathToScene = arguments[0]
    print 'open scene', pathToScene
    archiveName = arguments[1]
    updateProxy = arguments[2]
    print 'create rib "', archiveName, '"'
    #startTime = 
    #endTime =
    #stepFrame = 
    cmds.file(pathToScene, force=True, open=True)
    #Return arguments
    if archiveName != '':
        archivePathName = createRibArchive(archiveName)
    else:     
        archivePathName = createRibArchive()
    if updateProxy == 'True': 
        target = ''
        pathToSceneProxy = '_' not in pathToScene.split('.')[0] and pathToScene.split('.')[0] + '_proxy' + pathToScene.split('.')[-1] or pathToScene.split('.')[0] + 'Proxy' + pathToScene.split('.')[-1]
        cmds.file(pathToScene, force=True, open=True)
        if cmds.ls('general_CT'):
            nodes = cmds.listRelatives('general_CT', s=True)
            if cmds.attributeQuery('rman__param___draFile', node='general_CTShape', exists=True):
                cmds.setAttr('general_CTShape.rman__param___draFile', archivePathName, type='string')
                cmds.file(save=True)
            elif nodes:
                for i in range(0, len(nodes)):
                    if cmds.nodeType(nodes[i]) == 'RenderManArchive':
                        target = nodes[i]
                if target != '':
                    cmds.setAttr(target+'.filename', archivePathName, type="string")
                    cmds.file(save=True)
                elif target == '':
                    ribArchive = cmds.createNode('RenderManArchive', parent='general_CT')
                    cmds.setAttr(ribArchive+'.filename', archivePathName, type="string")
                    cmds.file(save=True)
                    

def createRibArchive(archiveName='rootRibArchiveShape', startTime=1, endTime=1, frequency=0):
    '''
    This script working only with parented to world 'root' transform node in target object root directory
    
    archiveName = rib archive project name (default "Current project")
    startTime = rib archive sequence start time (default 1)
    endTime = rib archive sequence end time (default 1)
    frequency = frequency rib arcives per frame (default 0)
    
    example = createRibArchive(rib.zip, 1, 1, 0)
    createRibArchive('testArchiveForMe')
    
    path to archive projectDir+'/renderman/ribarchives/'+archiveName.zip
    '''
    #Set project directory
    mel.eval('eval("rman slim start -gui 0")')
    project = re.split('project|Project', cmds.file(query=True, sceneName=True))[-1].split('/')[1]
    filePath = cmds.file(query=True, sceneName=True)
    OSTYPE = sys.platform
    curWorkSpace = mel.eval("file -q -loc -sn")
    if re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath):
        projectDir = '/'.join(filePath.split('/')[0:filePath.split('/').index(re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath)[0])+2])
        if OSTYPE == "win32":
            OSTYPE="//Server-3d/Project"
        else:
            OSTYPE="/Server-3d/Project"
        if OSTYPE:
            mel.eval("setProject \""+OSTYPE+'/'+project+projectDir.split(project)[-1]+"\";")    
            mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+" -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
            mel.eval('rman slim message \"workspace SetProject '+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+'"')	
        #set project only for files in 'props', 'sets', 'chars', 'scenes' directory
        projectRoot = '/'.join(filePath.split('/')[0:4])
        #mel.eval('rman setvar RMSPROJ "' + projectDir + '/"')
        #mel.eval('rman setvar RMSPROD "' + projectRoot + '"')
        #mel.eval('rman setvar RMSPROD_GLOBAL "' + projectRoot + '"')
        archiveDir = mel.eval('rman workspace GetDir "rfmRIBArchives"')
        #set shaders diretory to rib archive path
        shaderDirArchive = (archiveDir+'/'+archiveName+'/shaders')
        slimDirArchive = (archiveDir+'/'+archiveName+'/slim/shaders')
        mel.eval('rman workspace SetDir "rfmShaders" ("{'+shaderDirArchive+'}");')
        mel.eval('rman workspace SetDir "slimShaders" ("{'+slimDirArchive+'}");')
        mel.eval('rman slim command ("workspace SetDir slimShaders {'+slimDirArchive+'}")')
        mel.eval('rman slim command ("slim ReloadExtensions cmd")')     
        mel.eval('rman slim command ("slim BuildShaders")') 
    else: 
        cmds.warning('File is corrupted, please use project files or files in assets, scenes project directory')    
    #Rib node setup
    ribArchiveShapeNode = cmds.ls(type='RenderManArchive', long=True) and ('|'.join(cmds.ls(type='RenderManArchive', long=True)[0].split('|')[-2:])) or ''
    rootTr = cmds.ls('root')
    if rootTr:
        newRoot = rootTr
    else:
        objects = cmds.ls(transforms=True, long=True)
        upperTransforms = []
        for i in range(0, len(objects)):
            if objects[i].split('|')[1]:
                objectTEMP = objects[i].split('|')[1]
                shapes = cmds.ls(objectTEMP, dag=True, leaf=True, long=True)[0]
                if shapes.split('|') and len(shapes.split('|'))>4:
                    if objectTEMP not in upperTransforms:
                        upperTransforms.append(objectTEMP)
        newRoot = cmds.createNode('transform', n='root')
        cmds.parent(upperTransforms, newRoot)
    if ribArchiveShapeNode == '':                   
        newRib = cmds.createNode('transform', n='ribArchive')
        ribArchiveShapeNode = cmds.createNode('RenderManArchive', name=(newRib+'Shape'), parent=newRib)
        try:
            cmds.parent((cmds.listRelatives(ribArchiveShapeNode, parent=True)[0]), newRoot)  
        except:
            cmds.warning('root already get archive')    
    cmds.setAttr(ribArchiveShapeNode+'.crew', '__siblings', type='string')
    cmds.setAttr(ribArchiveShapeNode+'.startframe', startTime)
    cmds.setAttr(ribArchiveShapeNode+'.endframe', endTime)
    archivePathName = mel.eval('rman getvar RMSPROJ')+mel.eval('rman workspace GetDir "rfmRIBArchives"')+'/'+archiveName+'.zip'
    cmds.setAttr(ribArchiveShapeNode+'.filename', archivePathName, type='string')            
    #Export rib
    mel.eval('rman genrib -cacheCrew ("'+ribArchiveShapeNode+'"+",") -updateArchives 1 -s '+str(startTime)+' -e '+str(endTime)+' -updateArchivesPerFrame '+str(frequency)+';')
    print ribArchiveShapeNode, ' rib created to ', archivePathName
    mel.eval('eval("rman slim stop")')
    mel.eval('rman slim command ("slim Shutdown")')  
    return archivePathName

openTargetFile()


