import sip
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import advslim
import maya.cmds as cmds
import sys
reload( advslim )

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )
    
class Window( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( Window, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setProperty("index","ES")
        self.isLoad=False
        
    def load( self ):
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainWidgetLayout.setSpacing( 0 )
        self.mainWidgetLayout.setContentsMargins( 3, 3, 3, 3 )
        self.setLayout( self.mainlayout )
        
        self.settingWidget = QtGui.QWidget()
        self.settingLayout = QtGui.QVBoxLayout()
        self.settingLayout.setContentsMargins( 0, 0, 0, 0 )
        self.settingWidget.setLayout( self.settingLayout )
        self.mainlayout.addWidget( self.settingWidget )
        
        self.m_uniqueCheckbox = QtGui.QCheckBox( "Copy shader for selected objects" )
        self.settingLayout.addWidget( self.m_uniqueCheckbox )
        
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget = QtGui.QWidget()
        
        self.m_attributeWidget = QtGui.QGroupBox( "" )
        self.m_attributeLayout = QtGui.QGridLayout()
        self.m_attributeLayout.setContentsMargins( 0,0,0,0 )
        self.m_attributeLayout.setAlignment( QtCore.Qt.AlignTop )
        self.m_attributeLayout.setVerticalSpacing( 0 )
        self.m_attributeWidget.setLayout( self.m_attributeLayout )
        self.mainWidgetLayout.addWidget( self.m_attributeWidget )
        
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        
        self.m_actionWidget = QtGui.QGroupBox( "" )
        self.m_actionWidget.setMaximumHeight( 30 )
        self.m_actionLayout = QtGui.QGridLayout()
        self.m_actionLayout.setContentsMargins( 0,0,0,0 )
        self.m_actionWidget.setLayout( self.m_actionLayout )
        self.mainlayout.addWidget( self.m_actionWidget )
        
        self.m_updateButton = QtGui.QPushButton( "Refresh" )
        self.m_updateButton.released.connect( self.refresh )
        self.m_actionLayout.addWidget( self.m_updateButton, 0, 0 )
        
        self.setWindowTitle( "Slim shader editor" )
        self.isLoad=True
    
    def refresh( self ):
        self.clearItems()
        advslim.loadSlim()
        advslim.sendToSlim( "source %s/" % "%s/lib/setup/rfm400/copyShader.tcl" % ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ))
        self.array = advslim.listMayaID( selected=True, ensemble=True )
        idlen = len( self.array )
        for i in range( 0, idlen ):
            print "%s/%s" % ( idlen, i+1 )
            item = slimBox()
            self.m_attributeLayout.addWidget( item )
            item.load( self.array[i] )
    
    def clearItems( self ):
        for i in reversed( range( self.m_attributeLayout.count() ) ): 
            self.m_attributeLayout.itemAt(i).widget().deleteLater() 
        

class slimBox( QtGui.QWidget ):
    def __init__( self, parent=None ):
        super( slimBox, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        
    def load( self, id ):
        self.id = id
        self.stype = advslim.getSlimInfo( self.id, name=True ).split( "|" )
        self.name = self.stype[-1]
        self.stype = self.stype[0]
        self.m_infoGroupBox = QtGui.QGroupBox( self.name )
        self.m_infoLayout = QtGui.QVBoxLayout()
        self.m_infoLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_shaderWidget = QtGui.QWidget()
        self.m_shaderLayout = QtGui.QGridLayout()
        self.m_shaderLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_shaderLayout.setSpacing( 2 )
        self.m_shaderWidget.setLayout( self.m_shaderLayout )
        self.m_infoGroupBox.setLayout( self.m_infoLayout )
        self.m_infoLayout.addWidget( self.m_shaderWidget )
        self.mainlayout.addWidget( self.m_infoGroupBox )
        self.m_actionWidget = QtGui.QWidget()
        self.m_actionWidget.setMaximumHeight( 40 )
        self.m_actionLayout = QtGui.QHBoxLayout()
        self.m_actionLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionLayout.setSpacing( 2 )
        self.m_actionWidget.setLayout( self.m_actionLayout )
        self.m_uniqueCheckbox = self.parent().parent().parent().parent().parent().m_uniqueCheckbox
        self.m_applyButton = QtGui.QPushButton( "apply" )
        self.m_applyButton.released.connect( self.apply )
        self.m_actionLayout.addWidget( self.m_applyButton )
        self.m_selectAttachedButton = QtGui.QPushButton( "select in maya" )
        self.m_selectAttachedButton.released.connect( self.selectAttached )
        self.m_actionLayout.addWidget( self.m_selectAttachedButton )
        self.m_selectShaderButton = QtGui.QPushButton( "select in slim" )
        self.m_selectShaderButton.released.connect( self.selectShader )
        self.m_actionLayout.addWidget( self.m_selectShaderButton )
        self.m_typenameLabel = QtGui.QLabel( "type:" )
        self.m_shaderLayout.addWidget( self.m_typenameLabel, 0, 0 )
        self.m_typeLabel = QtGui.QLabel( self.stype )
        self.m_shaderLayout.addWidget( self.m_typeLabel, 0, 1 )
        self.m_idnameLabel = QtGui.QLabel( "id:" )
        self.m_shaderLayout.addWidget( self.m_idnameLabel, 1, 0 )
        self.m_idLabel = QtGui.QLabel( self.id )
        self.m_shaderLayout.addWidget( self.m_idLabel, 1, 1 )
        print "load shader: %s - %s" % ( self.stype, self.id )
        if "GPSurface" in self.stype:
            #Diffuse gain. 
            value = advslim.getSlimAttribute( self.id, "diffuseGain" )
            value = float( value[0] )
            self.m_diffuseLabel = QtGui.QLabel( "Diffuse gain" )
            self.m_shaderLayout.addWidget( self.m_diffuseLabel, 2, 0 )
            self.m_diffuseGainSpinBox = myDoubleSpinBox()
            self.m_diffuseGainSpinBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_diffuseGainSpinBox.setRange( 0, 10 )
            self.m_diffuseGainSpinBox.setValue( value )
            self.m_shaderLayout.addWidget( self.m_diffuseGainSpinBox, 2, 1 )
            #Roughness.
            value = advslim.getSlimAttribute( self.id, "roughness" )           
            value = float( value[0] )
            self.m_roughnessLabel = QtGui.QLabel( "Roughness" )
            self.m_shaderLayout.addWidget( self.m_roughnessLabel, 3, 0 )
            self.m_roughnessGainSpinBox = myDoubleSpinBox()
            self.m_roughnessGainSpinBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_roughnessGainSpinBox.setRange( 0, 100 )
            self.m_roughnessGainSpinBox.setValue( value )
            self.m_shaderLayout.addWidget( self.m_roughnessGainSpinBox, 3, 1 )
            #Roughness.
            value = advslim.getSlimAttribute( self.id, "enableOldRoughnessMapping" )           
            value = int( value[0] )
            self.m_oldRoughnessLabel = QtGui.QLabel( "Old roughness" )
            self.m_shaderLayout.addWidget( self.m_oldRoughnessLabel, 4, 0 )
            self.m_oldRoughnessCheckbox = QtGui.QCheckBox( "" )
            self.m_oldRoughnessCheckbox.setCheckState( value )
            self.m_shaderLayout.addWidget( self.m_oldRoughnessCheckbox, 4, 1 )
            #Specular gain.
            value = advslim.getSlimAttribute( self.id, "specularGain" )           
            value = float( value[0] )
            self.m_specularLabel = QtGui.QLabel( "Specular gain" )
            self.m_shaderLayout.addWidget( self.m_specularLabel, 5, 0 )
            self.m_specularGainSpinBox = myDoubleSpinBox()
            self.m_specularGainSpinBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_specularGainSpinBox.setRange( 0, 10 )
            self.m_specularGainSpinBox.setValue( value )
            self.m_shaderLayout.addWidget( self.m_specularGainSpinBox, 5, 1 )
            #Displacement enable.
            value = advslim.getSlimAttribute( self.id, "enableDisplacement" )
            value = int( value[0] )
            self.m_displacementLabel = QtGui.QLabel( "Displacement" )
            self.m_shaderLayout.addWidget( self.m_displacementLabel, 6, 0 )
            self.m_displacementModeComboBox = myComboBox()
            self.m_displacementModeComboBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_displacementModeComboBoxList = QtCore.QStringList()
            self.m_displacementModeComboBoxList.append( "Disable" )
            self.m_displacementModeComboBoxList.append( "Displace" )
            self.m_displacementModeComboBoxList.append( "Bump" )
            self.m_displacementModeComboBox.addItems( self.m_displacementModeComboBoxList )
            if value == -1:
                self.m_displacementModeComboBox.setCurrentIndex(0)
            elif value == 0:
                self.m_displacementModeComboBox.setCurrentIndex(1)
            else:
                self.m_displacementModeComboBox.setCurrentIndex(2)
            self.m_shaderLayout.addWidget( self.m_displacementModeComboBox, 6, 1 )
            #Displacement amount.
            value = advslim.getSlimAttribute( self.id, "displacementAmount" )
            value = float( value[0] )
            self.m_displacementAmountLabel = QtGui.QLabel( "Displacement scale" )
            self.m_shaderLayout.addWidget( self.m_displacementAmountLabel, 7, 0 )
            self.m_displacementAmountSpinBox = myDoubleSpinBox()
            self.m_displacementAmountSpinBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_displacementAmountSpinBox.setRange( -1000, 1000 )
            self.m_displacementAmountSpinBox.setValue( value )
            self.m_shaderLayout.addWidget( self.m_displacementAmountSpinBox, 7, 1 )
            #Bump amount.
            value = advslim.getSlimAttribute( self.id, "bumpAmount" )
            value = float( value[0] )
            self.m_bumpAmountLabel = QtGui.QLabel( "Bump scale" )
            self.m_shaderLayout.addWidget( self.m_bumpAmountLabel, 8, 0 )
            self.m_bumpAmountSpinBox = myDoubleSpinBox()
            self.m_bumpAmountSpinBox.setFocusPolicy( QtCore.Qt.StrongFocus )
            self.m_bumpAmountSpinBox.setRange( -1000, 1000 )
            self.m_bumpAmountSpinBox.setValue( value )
            self.m_shaderLayout.addWidget( self.m_bumpAmountSpinBox, 8, 1 )
        elif "Ensemble" in self.stype:
            self.m_unpackButton = QtGui.QPushButton( "Unpack" )
            self.m_unpackButton.released.connect( self.unpackEnsemble )
            self.m_actionLayout.addWidget( self.m_unpackButton )
        self.m_infoLayout.addWidget( self.m_actionWidget )

    def unpackEnsemble( self ):
        if self.m_uniqueCheckbox.checkState() > 0:
            index = advslim.sendToSlim( "copyShader %s -force" % self.id )
            selected = True
        else:
            index = advslim.sendToSlim( "copyShader %s" % self.id )
            selected = False
        if index:
            index = index[0].split( " " )[-1]
            print "remap slim attachments: %s to %s" % ( self.id, index )
            advslim.replaceID( self.id, index, selected=selected )
            self.id = index
            self.m_infoGroupBox.setTitle( "%s %s" % ( self.name, self.id ) )
        advslim.unpackEnsemble( self.id, selected=selected )
        advslim.selectSlimNode( self.id )
        
    def selectShader( self ):
        advslim.selectSlimNode( self.id )

    def apply( self ):
        print "apply changes: %s" % self.id
        index = []
        if self.m_uniqueCheckbox.checkState() > 0:
            index = advslim.sendToSlim( "copyShader %s -force" % self.id )
            selected = True
        elif advslim.isReferenced( self.id ) == "ro":
            index = advslim.sendToSlim( "copyShader %s" % self.id )
            selected = False
        if index:
            index = index[0].split( " " )[-1]
            print "remap slim attachments: %s to %s" % ( self.id, index )
            advslim.replaceID( self.id, index, selected=selected )
            self.id = index
            self.m_infoGroupBox.setTitle( "%s %s" % ( self.name, self.id ) )
        if "GPSurface" in self.stype:
            value = self.m_diffuseGainSpinBox.value()
            advslim.setSlimAttribute( self.id, "diffuseGain", value )
            value = self.m_roughnessGainSpinBox.value()
            advslim.setSlimAttribute( self.id, "roughness", value )
            value = self.m_specularGainSpinBox.value()
            advslim.setSlimAttribute( self.id, "specularGain", value )
            value = self.m_oldRoughnessCheckbox.checkState() > 0 and 1 or 0
            advslim.setSlimAttribute( self.id, "enableOldRoughnessMapping", value )
            value = self.m_displacementModeComboBox.currentText()
            if value == "Disable":
                value = -1
            elif value == "Displace":
                value = 0
            else:
                value = 1
            advslim.setSlimAttribute( self.id, "enableDisplacement", value )
            value = self.m_displacementAmountSpinBox.value()
            advslim.setSlimAttribute( self.id, "displacementAmount", value )
            value = self.m_bumpAmountSpinBox.value()
            advslim.setSlimAttribute( self.id, "bumpAmount", value )
        advslim.selectSlimNode( self.id )
    
    def selectAttached( self ):
        nodes = advslim.findNode( self.id, ensemble=True )
        cmds.select( clear=True )
        if nodes:
            cmds.select( nodes )

class myDoubleSpinBox( QtGui.QDoubleSpinBox ):
    def __init__( self, parent=getMayaWindow() ):
        super( myDoubleSpinBox, self ).__init__( parent )
        self.setDecimals( 4 ) 

    def wheelEvent( self,event ):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QDoubleSpinBox.wheelEvent( self,event )
            
class mySpinBox( QtGui.QSpinBox ):
    def __init__( self, parent=getMayaWindow() ):
        super( mySpinBox, self ).__init__( parent )

    def wheelEvent( self,event ):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QSpinBox.wheelEvent( self,event )
            
class myComboBox(QtGui.QComboBox):
    def __init__(self, parent=getMayaWindow()):
        super(myComboBox, self).__init__(parent)

    def wheelEvent(self,event):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QComboBox.wheelEvent(self,event)