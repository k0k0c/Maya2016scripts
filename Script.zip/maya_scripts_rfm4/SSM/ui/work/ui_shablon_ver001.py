import maya.cmds as cmds
import maya.mel as mel
import sip
import re
import os
import sys
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import maya.OpenMaya as om
import ml_reference
import shutil
reload( ml_reference )

globaljobBatchContextLE = ""

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )
    
class Window( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( Window, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.isLoad=False
        self.setProperty( "index", "Shablon" )
        self.loaded=[]
        
    def load( self ):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect( self.currentWidgetSlot )        
        self.tabWidget.setStyleSheet( "QTabWidget{background: rgb(68,68,68);}" )
        self.CMW = cameraManagerWidget()
        self.tabWidget.addTab( self.CMW, "Camera manager" )
        self.mainlayout.addWidget( self.tabWidget )
        self.readSettings()
        self.isLoad = True

    def currentWidgetSlot( self, wi ):
        if wi not in self.loaded:
            self.tabWidget.widget( wi ).load()
            self.loaded.append( wi )

    def readSettings( self ):
        settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
        settings.beginGroup("ShablonTabDialog")
        pos = settings.value("posMayaApp", QtCore.QPoint( 200, 200 )).toPoint()
        self.move( pos )        
        size = settings.value( "sizeMayaApp", QtCore.QSize( 400, 400 )).toSize()
        self.resize( size )
        pos = settings.value( "tabWidget", "0" ).toInt()
        self.tabWidget.setCurrentIndex( pos[0] )
        settings.endGroup()
        
    def writeSettings( self ):
        if self.isLoad:
            settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
            settings.beginGroup( "ShablonTabDialog" )
            settings.setValue( "posMayaApp", self.pos())
            settings.setValue( "sizeMayaApp", self.size())
            settings.setValue( "tabWidget", self.tabWidget.currentIndex())
            settings.setValue( "globaljobBatchContextLE", globaljobBatchContextLE )        
            settings.endGroup()              
            for i in range( 0, self.tabWidget.count()):
                if hasattr( self.tabWidget.widget(i), 'writeSettings' ):
                    self.tabWidget.widget( i ).writeSettings()

    def closeEvent( self, event ):
        self.writeSettings()
        event.accept()

class cameraManagerWidget( QtGui.QWidget ):
    
    def __init__( self, parent=getMayaWindow()):
        super( cameraManagerWidget, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        self.setProperty( "index" , "References" )
        self.isLoad=False
    
    def load( self ):
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainWidgetLayout.setContentsMargins( 2,2,2,2 )
        #Project.
        self.m_projectWidget = QtGui.QWidget()
        self.m_projectWidget.setMaximumHeight( 40 )
        self.m_projectLayout = QtGui.QGridLayout()
        self.m_projectWidget.setLayout( self.m_projectLayout )
        self.m_projectLabel = QtGui.QLabel( "Scene project:" )
        self.m_projectLayout.addWidget( self.m_projectLabel, 0, 0 )
        expression = re.compile("^(/renderserver/Project/)|(/mnt/renderserver/)|(P:/)|(/home/.*/Project/)|(D:/Work/Project/)|(//renderserver/Project/)", re.IGNORECASE)
        OSTYPE = sys.platform
        if OSTYPE == "win32":
                OSTYPE="//Server-3d/Project/"
        else:
                OSTYPE="/Server-3d/Project/"
        project = cmds.workspace( query=True, rootDirectory=True )
        project = expression.sub( OSTYPE, project )
        temp = os.path.join( project, "tmplate" )
        if os.path.isdir( temp ):
            project = temp
        self.m_projectEditLine = QtGui.QLineEdit( project )
        self.m_projectLayout.addWidget( self.m_projectEditLine, 0, 1 )
        self.m_changeProjectButton = QtGui.QPushButton( "" )
        self.m_changeProjectButton.setIcon( self.style().standardIcon(QtGui.QStyle.SP_DialogOpenButton) )
        self.m_changeProjectButton.released.connect( self.ml_changeProject )
        self.m_projectLayout.addWidget( self.m_changeProjectButton, 0, 2 )
        self.m_refreshCameraButton = QtGui.QPushButton( "" )
        self.m_refreshCameraButton.released.connect( self.ml_refreshFileList )
        self.m_refreshCameraButton.setIcon( self.style().standardIcon(QtGui.QStyle.SP_BrowserReload) )
        self.m_projectLayout.addWidget( self.m_refreshCameraButton, 0, 3 )
        self.mainWidgetLayout.addWidget( self.m_projectWidget )
        #Selection list.
        self.m_splitter = QtGui.QSplitter()
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setMinimumWidth( 200 )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListTree.setModel( self.m_selectionListModel )
        self.m_selectionListTree.setHeaderHidden( True )
        #List actions fiels.
        self.m_selectionListActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_selectionListActionLayout = QtGui.QVBoxLayout()
        self.m_selectionListActionLayout.setAlignment( QtCore.Qt.AlignTop )
        self.m_data = []
        self.m_actionListReferenceGroupBox = QtGui.QGroupBox( "" )
        self.m_actionListReferenceLayout = QtGui.QGridLayout()
        self.m_actionListReferenceLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionListReferenceGroupBox.setLayout( self.m_actionListReferenceLayout )
        #Controls.
        self.m_loadCameraButton = QtGui.QPushButton( "Load" )
        self.m_loadCameraButton.released.connect( self.ml_loadCamera )
        self.m_actionListReferenceLayout.addWidget( self.m_loadCameraButton )
        self.m_editCameraButton = QtGui.QPushButton( "Edit" )
        self.m_editCameraButton.released.connect( self.ml_editCamera )
        self.m_editCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_editCameraButton )
        self.m_saveSelectedCameraButton = QtGui.QPushButton( "Save" )
        self.m_saveSelectedCameraButton.released.connect( self.ml_saveCamera )
        self.m_saveSelectedCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_saveSelectedCameraButton )
        self.m_versionSaveCheckbox = QtGui.QCheckBox( "Save version" )
        self.m_versionSaveCheckbox.setCheckState( True )
        self.m_actionListReferenceLayout.addWidget( self.m_versionSaveCheckbox )
        self.m_versionShowCheckbox = QtGui.QCheckBox( "Show versions" )
        self.m_actionListReferenceLayout.addWidget( self.m_versionShowCheckbox )
        self.m_selectionListActionLayout.addWidget( self.m_actionListReferenceGroupBox )
        self.m_selectionListActionsGroupBox.setLayout( self.m_selectionListActionLayout )
        self.m_splitter.addWidget( self.m_selectionListActionsGroupBox )
        self.m_splitter.addWidget( self.m_selectionListTree )
        #Settings
        self.mainWidgetLayout.addWidget( self.m_splitter )
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        self.isLoad = True
        self.ml_refreshFileList()
        
    def ml_changeProject( self ):
        m_directory = cmds.workspace( query=True, rootDirectory=True )
        m_path = cmds.fileDialog2( caption="Project", startingDirectory=m_directory, dialogStyle=1, fm=3 )
        if m_path:
            m_path = type( m_path ) is list and m_path[0] or m_path
            m_path = "/".join( m_path.split( "\\" ))
            self.m_projectEditLine.setText( m_path )
            self.ml_refreshFileList()
        return m_path

    def ml_refreshFileList( self ):
        self.ml_removeAllContent()
        directory = str( self.m_projectEditLine.text())
        expr = re.compile( "(cam|camera|cams|cam_ver[0-9]+|cams_ver[0-9]+|camera_ver[0-9]+)(.ma$|.mb$)", re.IGNORECASE )
        if os.path.isdir( directory ):
            if self.m_versionShowCheckbox.checkState():
                m_work = os.path.join( directory, "/work/" )
                if os.path.isdir( m_work ):
                    files = os.listdir( m_work )
                    for i in range( 0, len( files )):
                        if expr.findall( files[i] ):
                            if directory[-1] == "/":
                                self.ml_addContent( os.path.join( m_work, files[i] ))
            files = os.listdir( directory )
            for i in range( 0, len( files )):
                if expr.findall( files[i] ):
                    if directory[-1] == "/":
                        self.ml_addContent( os.path.join( directory, "/" + files[i] ))
                    else:
                        self.ml_addContent( os.path.join( directory + "/", files[i] ))
        else:
            print "%s is not exists." % directory
            return None

    def ml_saveCamera( self ):
        m_references = cmds.file( query=True, reference=True )
        m_references = m_references and [ m_references[i].split( "{" )[0] for i in range( 0, len( m_references )) ]
        m_files = self.ml_getSelected()
        for i in range( 0, len( m_files )):
            if os.path.isfile( m_files[i] ):
                if m_files[i] in m_references:
                    print "%s is read only and cannot be saved. Please load file in edit mode." % m_files[i]
                    return False
                m_type = m_files[i].split( "." )[-1]
                m_type = "ma" in m_type and "mayaBinary" or "mb" in m_type and "mayaAscii" or ""
                m_cleanName = m_files[i].split( "/" )[-1].split( "." )[0] 
                m_namespaces = cmds.namespaceInfo( listNamespace=True )
                m_namespace = m_files[i].split( "/" )[-1].split( "." )[0]
                if m_namespace in m_namespaces:
                    confirm = confirmLoop()
                    confirm.load( label="Export", text="Do you want to save %s?" % m_namespace )
                    m_bool = confirm.exec_()
                    if m_bool == 1 and m_type != "":
                        m_nodes = cmds.namespaceInfo( m_namespace, listOnlyDependencyNodes=True, dagPath=True )
                        m_toExport = []
                        if m_nodes:
                            for n in range( 0, len( m_nodes )):
                                if m_nodes[n] not in m_toExport:
                                    m_toExport.append( m_nodes[n] )
                                m_connections = cmds.listConnections( m_nodes[n] )
                                if m_connections:
                                    for c in range( 0, len( m_connections )):
                                        if m_connections[c] not in m_toExport:
                                            m_toExport.append( m_connections[c] )
                            cmds.select( cl=True )
                            cmds.select( m_toExport )
                            #Remove namespace.
                            #for n in range( 0, len( m_nodes )):
                                #buffer = m_nodes[n].split( ":" )
                                #buffer = buffer[-1].split( "|" )
                                #name = buffer[-1]
                                #if cmds.objExists( m_nodes[n] ):
                                    #cmds.rename( m_nodes[n], "%s:%s" % ( "", name ))
                            #cmds.namespace( removeNamespace=m_namespace )
                            #Get work directory.
                            m_work = m_files[i].split( "/" )[:-1]
                            m_work = "/".join( m_work ) + "/work/"
                            #Backup old file.
                            m_name = m_files[i].split( "/" )[-1]
                            m_name = m_name.split( "." )
                            m_name = ".".join( [ ".".join( m_name[:-1] ) + "_backup", ".".join( m_name[-1:] ) ] )
                            m_backup = os.path.join( m_work, m_name )
                            if not os.path.isdir( m_work ):
                                os.mkdir( m_work )
                            print "\nsave backup to %s" % m_backup
                            shutil.copy2( m_files[i], m_backup )
                            #Make first file.
                            m_name = m_files[i].split( "/" )[-1]
                            m_name = m_name.split( "." )
                            m_name = ".".join( [ ".".join( m_name[:-1] ) + "_base", ".".join( m_name[-1:] ) ] )
                            m_base = os.path.join( m_work, m_name )
                            if not os.path.isfile( m_base ):
                                print "\nsave base to %s" % m_base
                                shutil.copy2( m_files[i], m_base )
                            #Export selected.
                            print "save to %s" % m_files[i]
                            cmds.file( m_files[i], type=m_type, namespace=m_namespace, options="v=0;", er=True )
                            cmds.select( cl=True )
                            #Make new version.
                            if self.m_versionSaveCheckbox.checkState():
                                m_content = os.listdir( m_work )
                                m_versions = []
                                expr_file = re.compile( m_cleanName )
                                expr_version = re.compile( "_ver([0-9]+).m[ab]" )
                                for f in range( 0, len( m_content )):
                                    if expr_file.findall( m_content[f] ):
                                        m_version = expr_version.findall( m_content[f] )
                                        if m_version:
                                            m_versions.append( int( m_version[-1] ))
                                if m_versions:
                                    m_current = str( max( m_versions ) + 1 )
                                else:
                                    m_current = "1"
                                m_versionName = m_cleanName + "_ver" + ( "0" * ( 3 - len( m_current )) + m_current ) + "." + m_files[i].split( "." )[-1]
                                m_versionName = os.path.join( m_work, m_versionName )
                                print "save next version to %s" % m_versionName
                                shutil.copy2( m_files[i], m_versionName )
                    else:
                        continue
        self.ml_loadCamera()
    
    def ml_editCamera( self ):
        m_references = cmds.file( query=True, reference=True )
        m_references = m_references and [ m_references[i].split( "{" )[0] for i in range( 0, len( m_references )) ]
        m_references = "|".join( m_references )
        m_files = self.ml_getSelected()
        for i in range( 0, len( m_files )):
            if os.path.isfile( m_files[i] ):
                print m_files[i]
                print m_references
                if re.findall( m_files[i], m_references, re.IGNORECASE ):
                    cmds.file( m_files[i], removeReference=True )
                m_namespaces = cmds.namespaceInfo( listNamespace=True )
                m_namespace = m_files[i].split( "/" )[-1].split( "." )[0]
                if m_namespace in m_namespaces:
                    confirm = confirmLoop()
                    confirm.load( label="Import", text="Do you want to replace %s with all namespace content?" % m_namespace )
                    m_bool = confirm.exec_()
                    if m_bool == 1:
                        self.ml_deleteNamespaceContent( m_namespace )
                    elif m_bool == 2:
                        continue
                    else:
                        break
                nodes = cmds.file( m_files[i], namespace=m_namespace, i=True, returnNewNodes=True )
                if nodes:
                    nodes = cmds.ls( nodes, assemblies=True )
                    if nodes:
                        if cmds.objExists( "|cameras_grp" ):
                            cmds.parent( nodes, "|cameras_grp" )
                        else:
                            cmds.group( nodes, n="cameras_grp" )
        
    def ml_loadCamera( self ):
        m_references = cmds.file( query=True, reference=True )
        m_references = m_references and [ m_references[i].split( "{" )[0] for i in range( 0, len( m_references )) ]
        m_references = "|".join( m_references )
        m_files = self.ml_getSelected()
        for i in range( 0, len( m_files )):
            if os.path.isfile( m_files[i] ) and not re.findall( m_files[i], m_references, re.IGNORECASE ):
                print m_files[i]
                m_namespaces = cmds.namespaceInfo( listNamespace=True )
                m_namespace = m_files[i].split( "/" )[-1].split( "." )[0]
                if m_namespace in m_namespaces:
                    confirm = confirmLoop()
                    confirm.load( label="Reference", text="Do you want to replace %s with all namespace content?" % m_namespace )
                    m_bool = confirm.exec_()
                    if m_bool == 1:
                        self.ml_deleteNamespaceContent( m_namespace )
                    elif m_bool == 2:
                        continue
                    else:
                        break
                nodes = cmds.file( m_files[i], reference=True, namespace=m_files[i].split( "/" )[-1].split( "." )[0], returnNewNodes=True )
                if nodes:
                    nodes = cmds.ls( nodes, assemblies=True )
                    if nodes:
                        if cmds.objExists( "|cameras_grp" ):
                            cmds.parent( nodes, "|cameras_grp" )
                        else:
                            cmds.group( nodes, n="cameras_grp" )
            else:
                print "%s is already loaded" % m_files[i]
                
    def ml_deleteNamespaceContent( self, namespace ):
        m_namespaces = type( namespace ) is list and namespace or [ namespace ]
        m_nested = cmds.namespaceInfo( namespace, listOnlyNamespaces=True, recurse=True )
        if m_nested:
            for i in range( 0, len( m_nested )):
                m_namespaces.append( m_nested[i] )
        for i in range( len( m_namespaces )-1, -1, -1 ):
            m_nodes = cmds.namespaceInfo( m_namespaces[i], listOnlyDependencyNodes=True, dagPath=True )
            if m_nodes:
                cmds.delete( m_nodes )
            cmds.namespace( removeNamespace=m_namespaces[i] )
    
    def ml_addContent( self, filename ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_name = ( filename.split( "/" )[-1]).split( "." )[0]
        if filename not in self.m_data:
            m_item = QtGui.QStandardItem( filename )
            m_item.setData( "",QtCore.Qt.UserRole + 1 )
            m_item.setData( "", QtCore.Qt.UserRole + 2 )
            m_item.setData( m_name, QtCore.Qt.UserRole + 3 )
            m_item.setData( "", QtCore.Qt.UserRole + 4 )
            m_item.setData( "", QtCore.Qt.UserRole + 5 )
            m_item.setData( "", QtCore.Qt.UserRole + 6 )
            m_list.appendRow( m_item )
            self.m_data.append( filename )
    
    def ml_getSelected( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            m_temp = m_indexes[i].data().toString()
            m_temp = str( m_temp )
            if m_temp not in m_result:
                m_result.append( m_temp )
        return m_result
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            m_path = m_selected[i].data().toString()
            self.m_selectionListModel.removeRow( m_selected[i].row() )
            if m_path in self.m_data:
                self.m_data.pop( self.m_data.index( m_path ))
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
        self.m_data = []

class confirmLoop( QtGui.QDialog ):
    def __init__(self, parent=None):
        super(confirmLoop, self).__init__(parent)
        
    def load( self, label="", text="" ):
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 2,2,2,2 )        
        self.setWindowTitle( label )
        self.label=QtGui.QLabel( text )
        self.HLayout = QtGui.QHBoxLayout()
        self.executeButton = QtGui.QPushButton( "Yes" )
        self.executeButton.released.connect( self.executeSlot )
        self.continueButton = QtGui.QPushButton( "No" )
        self.continueButton.released.connect( self.continueSlot )  
        self.breakButton = QtGui.QPushButton( "Cancel" )
        self.breakButton.released.connect( self.breakSlot )
        self.HLayout.addWidget( self.executeButton )
        self.HLayout.addWidget( self.continueButton )
        self.HLayout.addWidget( self.breakButton )
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout)
        
    def executeSlot( self ):
        self.done(1)
        
    def continueSlot( self ):
        self.done(2)

    def breakSlot( self ):
        self.done(3)

class listDelegate( QtGui.QItemDelegate ):
    
    def __init__( self, parent=None ):
        super(listDelegate, self).__init__( parent )
        self.mult = 1
                            
    def createEditor( self, parent, option, index ):
        editor = QtGui.QSpinBox( parent )
        editor.setMinimum( 0 )
        editor.setMaximum( 100 )
        return editor
    
    def setEditorData( self, spinBox, index ):
        value = index.model().data( index, QtCore.Qt.EditRole )
        spinBox.setValue(value)
        
    def setModelData( self, spinBox, model, index ):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData( index, value, QtCore.Qt.EditRole )
        
    def updateEditorGeometry( self, editor, option, index ):
        editor.setGeometry( option.rect )
        
    def sizeHint( self, option, index ):
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize( 11 )
        myFontMetrics = QtGui.QFontMetrics( myFont )
        mySize = myFontMetrics.boundingRect( 0,0, 260, 0,( QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft ), index.data( QtCore.Qt.DisplayRole ).toString() )     
        return QtCore.QSize( mySize.width(), mySize.height() + 40 )
    
    def paint( self, painter, option, index ):
        painter.save()
        painter.setRenderHint( QtGui.QPainter.Antialiasing )
        newMetr = QtGui.QFontMetrics( painter.font() )
        heit = newMetr.height() + 2   
        gradient = QtGui.QLinearGradient( option.rect.x() + option.rect.width() / 2, option.rect.y(), option.rect.x() + option.rect.width() / 2, option.rect.y() + option.rect.height() )
        gradient.setColorAt( 0.01, option.palette.base().color() )
        gradient.setColorAt( 0.02, option.palette.window().color() )
        gradient.setColorAt( 0.98,option.palette.window().color() )
        gradient.setColorAt( 0.99, option.palette.base().color() )
        brush = QtGui.QBrush( gradient )
        painter.fillRect( option.rect,brush )
        if sys.platform == "win32":
            painter.setCompositionMode( QtGui.QPainter.CompositionMode_Multiply )
            gradient2 = QtGui.QLinearGradient( option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height() )
            gradient2.setColorAt( 0, QtGui.QColor(255,255,255))
            gradient2.setColorAt( 1, QtGui.QColor(200,200,200))
            brush2 = QtGui.QBrush( gradient2 )
            painter.fillRect( option.rect,brush2 )
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
            gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
            gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
            brush3 = QtGui.QBrush(gradient3)
            painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
            gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
            gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
            brush4 = QtGui.QBrush(gradient4)
            painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
        textSize = index.data(QtCore.Qt.UserRole+5).toString()
        one_widthSize = painter.fontMetrics().width(textSize)
        painter.drawText( option.rect.x()+option.rect.width()-one_widthSize-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textSize)
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-6-one_widthSize,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
        text = index.data(QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)   
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore()