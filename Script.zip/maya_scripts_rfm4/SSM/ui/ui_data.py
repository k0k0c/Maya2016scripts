import json
import glob
import re
import alembic_export_new
import sys, os
from PyQt4 import QtCore, QtGui
import sip
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMayaUI as mui
import sendToRender

   
def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return sip.wrapinstance(long(ptr), QtCore.QObject)


class Window(QtGui.QWidget):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.loaded=[]
        self.setProperty("index","Data")
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setLayout(self.mainLayout)

    def load(self):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect(self.currentWidgetSlot)        
        self.tabWidget.setStyleSheet("QTabWidget{background: rgb(68,68,68);}")
        self.AE=WindowAlembicExport()
        self.tabWidget.addTab(self.AE, "Alembic Export")
        self.AI=WindowAlembicImport()
        self.tabWidget.addTab(self.AI, "Alembic Import")
        self.Attr=WindowAttributes()
        self.tabWidget.addTab(self.Attr, "Attributes")
        self.mainLayout.addWidget(self.tabWidget)        
        self.readSettings()
        self.isLoad=True
        #self.AE.installEventFilter(self)
        #self.AI.installEventFilter(self)
        #self.Attr.installEventFilter(self)

    def currentWidgetSlot(self,wi):
        if wi not in self.loaded:
            self.tabWidget.widget(wi).load()
            self.loaded.append(wi)
    '''
    def eventFilter(self, obj, event):
        if (obj == self.AE or obj == self.AI or obj == self.Attr) and event.type() == QtCore.QEvent.Show: 
            SSM = getMayaWindow().findChildren((QtGui.QDockWidget),"Yashka Return(CIT)")[0]
            if obj == self.AE and event.type() == QtCore.QEvent.Show:
                if SSM.sceneChanged != self.AE.sceneChanged:
                    self.AE.ml_update(SSM.sceneChanged) 
            elif obj == self.AI and event.type() == QtCore.QEvent.Show:
                if SSM.sceneChanged != self.AI.sceneChanged:
                    self.AI.ml_update(SSM.sceneChanged) 
            elif obj == self.Attr and event.type() == QtCore.QEvent.Show:
                if SSM.sceneChanged != self.Attr.sceneChanged:
                    self.Attr.ml_update(SSM.sceneChanged) 
        return False
    ''' 
    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("YashkaDialog")        
        pos = settings.value("tabWidget", "0").toInt()
        self.tabWidget.setCurrentIndex(pos[0])
        settings.endGroup()
    
    def writeSettings(self):
        if self.isLoad:
            settings = QtCore.QSettings("Melnitsa Soft", "Yago")
            settings.beginGroup("YashkaDialog")
            settings.setValue("posMayaApp", self.pos())
            settings.setValue("sizeMayaApp", self.size())
            settings.setValue("tabWidget", self.tabWidget.currentIndex())
            settings.endGroup()              
            for i in range(0,self.tabWidget.count()):
                if hasattr(self.tabWidget.widget(i), 'writeSettings'):
                    self.tabWidget.widget(i).writeSettings()

    def closeEvent(self, event):
        self.writeSettings()
        event.accept()
   



class ExportSpinBoxDelegate(QtGui.QItemDelegate):
    sT=QtCore.QVariant(0)
    sN=QtCore.QVariant(-1)

    #def __init__(self):
    #        super(QtGui.QItemDelegate, self).__init__()

    #def __init__(self,var):
    #        QtGui.QItemDelegate.__init__(self)
    #        sT=var

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        imageOffset=0
        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)
        elif index.data(QtCore.Qt.UserRole+1).toInt()[0] == 2:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.Dense6Pattern)
            painter.fillRect(option.rect,brush)
            #painter.drawImage( QtCore.QRect(option.rect.x()+2,option.rect.y()+2,option.rect.height()-4,option.rect.height()-4),QtGui.QImage("/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/arrows-right-circular-icon.png"))
            #imageOffset=option.rect.height()

        one_width = 2
        if self.sT == 2:
            if index.data(QtCore.Qt.UserRole).toString()!="":
                textType = " ["+index.data(QtCore.Qt.UserRole).toString()[0:3]+"] "
                one_width = painter.fontMetrics().width(textType)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textType)
            elif index.data(QtCore.Qt.UserRole+2).toString()!="":
                textLoadedDraw=" ["+index.data(QtCore.Qt.UserRole+2).toString()+"] "
                one_width = painter.fontMetrics().width(textLoadedDraw)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textLoadedDraw)

        serifFont=QtGui.QFont()
        #serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        text_width = painter.fontMetrics().width(text)
        painter.drawText( option.rect.x()+one_width+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)

        overWidth=0
        '''if index.data(QtCore.Qt.UserRole+6).toString()!="":
            overText="    over    "
            overWidth = painter.fontMetrics().width(overText)
            painter.drawText( option.rect.x()+option.rect.width()-overWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,overText)
        '''
        proxyWidth=0
        if index.data(QtCore.Qt.UserRole+5).toString()!="":
            proxyText="     ["+index.data(QtCore.Qt.UserRole+5).toString()+"]"
            proxyWidth = painter.fontMetrics().width(proxyText)
            if option.rect.width()-overWidth-proxyWidth>one_width+imageOffset+text_width:
                painter.drawText( option.rect.x()+option.rect.width()-overWidth-proxyWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,proxyText)



        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class ImportSpinBoxDelegate(QtGui.QItemDelegate):
    sN=QtCore.QVariant(-1)

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        painter.drawText( option.rect.x()+2,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)


        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();








#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT







class WindowAlembicExport(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowAlembicExport, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.sceneChanged=-2
        self.mainLayout.setSpacing(4)
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setProperty("index","AE")
        self.setLayout(self.mainLayout)


    def load(self):
        self.AEgroupBoxFind = QtGui.QVBoxLayout()
        self.framesLayout=QtGui.QHBoxLayout()
        self.framesLabel = QtGui.QLabel("Time range: ")
        self.TimeRangeBG = QtGui.QButtonGroup()
        self.rendSetR = QtGui.QRadioButton("Render settings")
        self.rendSetR.toggled.connect(self.setFrameRangeSlot)
        self.timeSliderR = QtGui.QRadioButton("Time slider")
        self.timeSliderR.toggled.connect(self.setFrameRangeSlot)
        self.startEndR = QtGui.QRadioButton("Custom")
        self.startEndR.toggled.connect(self.setFrameRangeSlot)
        self.TimeRangeBG.addButton(self.rendSetR)
        self.TimeRangeBG.addButton(self.timeSliderR)
        self.TimeRangeBG.addButton(self.startEndR)
        self.startEndLabel=QtGui.QLabel("start/end")
        self.startFrameSB = QtGui.QSpinBox()
        self.startFrameSB.setMaximum(100000)
        self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
        self.endFrameSB = QtGui.QSpinBox()
        self.endFrameSB.setMaximum(100000)
        self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
        self.framesLayout2=QtGui.QHBoxLayout()
        self.passesLabel=QtGui.QLabel("Passes: ")
        self.refPasses = QtGui.QSpinBox()
        self.refPasses.setValue(1)
        self.framesLayout.addWidget(self.framesLabel)
        self.framesLayout.addWidget(self.rendSetR)
        self.framesLayout.addWidget(self.timeSliderR)
        self.framesLayout.addWidget(self.startEndR)
        self.framesLayout2.addWidget(self.startEndLabel)
        self.framesLayout2.addWidget(self.startFrameSB)
        self.framesLayout2.addWidget(self.endFrameSB)
        self.framesLayout2.addStretch(1)
        self.framesLayout2.addWidget(self.passesLabel)
        self.framesLayout2.addWidget(self.refPasses)

        self.AEgroupBoxFind.addLayout(self.framesLayout)        
        self.AEgroupBoxFind.addLayout(self.framesLayout2)        


        self.AEloadunloaded = QtGui.QCheckBox("load unloaded")

        self.options1Layout=QtGui.QHBoxLayout()
        self.labelSelectedMode=QtGui.QLabel("export: ")
        #self.AEExportAllChekbox = QtGui.QRadioButton("all")
        #self.AEExportAllChekbox.toggled.connect(self.exportAllstateChanged)
        self.AEExportAllLoadedChekbox = QtGui.QRadioButton("all loaded")
        self.AEExportAllLoadedChekbox.toggled.connect(self.exportAllLoadedstateChanged)
        self.AEExportChekbox = QtGui.QRadioButton("selected")
        self.AEExportChekbox.toggled.connect(self.exportstateChanged)
        self.AEExportAnimationChekbox = QtGui.QRadioButton("animation")
        self.AEExportAnimationChekbox.toggled.connect(self.exportanimationstateChanged)
        self.AECleanFolder = QtGui.QCheckBox("clean folder")
        self.AECleanFolder.setCheckState(QtCore.Qt.Checked)
        #self.options1Layout.addWidget(self.AEExportAllChekbox)
        self.options1Layout.addWidget(self.labelSelectedMode)
        self.options1Layout.addWidget(self.AEExportAllLoadedChekbox)
        self.options1Layout.addWidget(self.AEExportChekbox)
        self.options1Layout.addWidget(self.AEExportAnimationChekbox)
        self.options1Layout.addStretch(1)
        self.options1Layout.addWidget(self.AECleanFolder)
        self.AEgroupBoxFind.addLayout(self.options1Layout)        

        self.options2Layout=QtGui.QHBoxLayout()
        self.AEswithreferenceToOriginal = QtGui.QCheckBox("Switch proxy to original")
        self.AEswithreferenceToOriginal.setCheckState(QtCore.Qt.Checked)
        self.GEOGPUBG = QtGui.QButtonGroup()
        self.AECreateGpuCasheChekbox = QtGui.QRadioButton("GPU cashe")
        self.AECreateGeoCasheChekbox = QtGui.QRadioButton("Geo cashe")
        self.GEOGPUBG.addButton(self.AECreateGeoCasheChekbox)
        self.GEOGPUBG.addButton(self.AECreateGpuCasheChekbox)
        self.options2Layout.addWidget(self.AECreateGeoCasheChekbox)
        self.options2Layout.addWidget(self.AECreateGpuCasheChekbox)
        self.AEgroupBoxFind.addLayout(self.options2Layout)        

        self.sendToTractor=QtGui.QCheckBox("tractor")
        self.AEExportButton = QtGui.QPushButton("Export")
        self.AEExportButton.released.connect(self.AEExportButtonSlot)
        self.options2Layout.addWidget(self.sendToTractor)
        self.options2Layout.addWidget(self.AEExportButton,1)

        self.oneWidget = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind = QtGui.QVBoxLayout()
        self.groupBoxFind.setSpacing(4)
        self.oneWidget.setLayout(self.groupBoxFind)
        self.groupBoxFind.setContentsMargins(3,3,3,3)
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLayout.setContentsMargins(0,0,0,0)
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.groupBoxFind.addLayout(self.twoLayout)        



        self.showLabel = QtGui.QLabel("show type")
        self.checkShowType = QtGui.QCheckBox()
        self.namespaceLabel = QtGui.QLabel("namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                
        self.showTypeLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showLabel)
        self.showTypeLayout.addWidget(self.checkShowType)
        self.showTypeLayout.addWidget(self.namespaceLabel)
        self.showTypeLayout.addWidget(self.checkShowNamespace)
        self.showTypeLayout.addStretch(1)

        self.showFindedLabel = QtGui.QLabel(" only found")
        self.checkShowFinded = QtGui.QCheckBox()
        self.checkShowFinded.setCheckState(QtCore.Qt.Unchecked)
        self.checkShowFinded.connect(self.checkShowFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded)                

        self.expandFindedLabel = QtGui.QLabel(" expand found")
        self.checkexpandFinded = QtGui.QCheckBox()
        self.checkexpandFinded.setCheckState(QtCore.Qt.Checked)
        self.checkexpandFinded.connect(self.checkexpandFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetExpandFinded)                


        self.outLayout = QtGui.QHBoxLayout()
        self.outlonerLabel = QtGui.QLabel("Send")
        self.fromOutPushButton = QtGui.QPushButton("To")
        self.fromOutPushButton.setMinimumWidth( 10 )
        self.fromOutPushButton.released.connect(self.fromOutSlot)
        self.fromOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.toOutPushButton = QtGui.QPushButton("From")
        self.toOutPushButton.setMinimumWidth( 10 )
        self.toOutPushButton.released.connect(self.toOutSlot)
        self.toOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.outlonerLabel2 = QtGui.QLabel("Outliner")
        self.outLayout.addWidget(self.outlonerLabel)
        self.outLayout.addWidget(self.fromOutPushButton)
        self.outLayout.addWidget(self.toOutPushButton)
        self.outLayout.addWidget(self.outlonerLabel2)
        self.outLayout.addStretch(1)

        self.RELayout = QtGui.QHBoxLayout()
        self.referenceEditorLabel = QtGui.QLabel("Send")
        #self.fromREPushButton = QtGui.QPushButton("To")
        #self.fromREPushButton.setMinimumWidth( 10 )
        #self.fromREPushButton.released.connect(self.fromRESlot)
        #self.fromREPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.toREPushButton = QtGui.QPushButton("From")
        self.toREPushButton.setMinimumWidth( 10 )
        self.referenceEditorLabel2 = QtGui.QLabel("Reference editor")
        self.toREPushButton.released.connect(self.toRESlot)
        self.toREPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.outLayout.addWidget(self.referenceEditorLabel)
        #self.outLayout.addWidget(self.fromREPushButton)
        self.outLayout.addWidget(self.toREPushButton)
        self.outLayout.addWidget(self.referenceEditorLabel2)
        self.outLayout.addStretch(1)

        self.collapsePushButton = QtGui.QPushButton("collapse all")
        self.collapsePushButton.released.connect(self.collapseAllSlot)
        self.showFindedLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showFindedLabel)
        self.showTypeLayout.addWidget(self.checkShowFinded)
        self.showTypeLayout.addWidget(self.expandFindedLabel)
        self.showTypeLayout.addWidget(self.checkexpandFinded)
        self.showTypeLayout.addStretch(1)
        self.showFindedLayout.addWidget(self.collapsePushButton)
        self.showFindedLayout.addStretch(1)


        self.groupBoxFind.addLayout(self.showTypeLayout)
        self.groupBoxFind.addLayout(self.showFindedLayout)

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = ExportSpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        self.groupBoxFind.addWidget(self.treeView)        
        self.groupBoxFind.addLayout(self.outLayout)
        
        self.AEgroupBoxFind.addWidget(self.oneWidget)        
        self.mainLayout.addLayout(self.AEgroupBoxFind)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.checkShowType.setCheckState(QtCore.Qt.Checked)
        self.AEExportAllLoadedChekbox.setChecked(True)        
        self.AECreateGeoCasheChekbox.setChecked(True)        
        self.timeSliderR.setChecked(True)        
        self.isLoad=True


    def setFrameRangeSlot(self):
        if self.rendSetR.isChecked():
            self.startFrameSB.setValue(cmds.getAttr("defaultRenderGlobals.startFrame"))
            self.endFrameSB.setValue(cmds.getAttr("defaultRenderGlobals.endFrame"))
            self.startFrameSB.setDisabled(True)
            self.endFrameSB.setDisabled(True)
        elif self.timeSliderR.isChecked():
            self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
            self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
            self.startFrameSB.setDisabled(True)
            self.endFrameSB.setDisabled(True)
        elif self.startEndR.isChecked():
            self.startFrameSB.setDisabled(False)
            self.endFrameSB.setDisabled(False)


    def fromOutSlot(self):
        ar=[]
        for i in self.treeView.selectionModel().selectedRows():
            file=str(i.data(QtCore.Qt.UserRole+3).toString())
            isLoaded=1-int(cmds.file(file,q=True,dr=True))
            if isLoaded:
                temp=cmds.referenceQuery(file,n=True,dp=True)
                if temp:
                    ar+=temp
        cmds.select(cl=True)
        if ar:
            cmds.select(ar,ne=True)

    def toOutSlot(self):
        ar=cmds.ls(sl=True)
        fileList=[]
        for a in ar:
            temp=cmds.referenceQuery(a,f=True)
            if temp not in fileList:
                fileList.append(temp)
        if fileList:
            self.findText(massFiles=fileList,files=True)

    def toRESlot(self):
        ar=mel.eval("proc string[] blay(){global string $gReferenceEditorPanel;string $mmm[]=`lsUI -windows`;int $mozhno=0;for($m in $mmm){if(`gmatch $m \"*referenceEditorPanel*\"`){$mozhno=1;break;}}string $references[];if($mozhno){$references = `sceneEditor -q -selectReference $gReferenceEditorPanel`;return $references;}else{return $references;}}blay();")
        fileList=[]
        for a in ar:
            temp=cmds.referenceQuery(a,f=True)
            if temp not in fileList:
                fileList.append(temp)
        if fileList:
            self.findText(massFiles=fileList,files=True)

    def ml_update(self,sc):
        self.sceneChanged=sc
        self.setFrameRangeSlot()

    def stateChangetShowFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.showFindedRecurse(parentItem,typeIs)

    def showFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            if val:
                temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
                if temp > 0:
                    self.treeView.setRowHidden(chi,item.index(),False) 
                    self.showFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setRowHidden(chi,item.index(),True) 
            else:
                self.treeView.setRowHidden(chi,item.index(),False) 
                self.showFindedRecurse(item.child(chi,0),val)

    def stateChangetExpandFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.expandFindedRecurse(parentItem,typeIs)

    def expandFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
            if temp > 0:
                if val:
                        self.treeView.setExpanded(item.child(chi,0).index(),True) 
                        self.expandFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setExpanded(item.child(chi,0).index(),False) 


    def stateChangetShowNamespace(self,typeIs):
        self.delegate.sN=typeIs
        parentItem = self.treeModel.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
            if not self.treeView.isRowHidden(chi,parentItem.index()):
                taak=self.treeView.isExpanded(self.treeModel.index(chi,0))
                if taak:
                    self.treeView.collapse(self.treeModel.index(chi,0))
                    self.treeView.expand(self.treeModel.index(chi,0))
                else:
                    self.treeView.expand(self.treeModel.index(chi,0))
                    self.treeView.collapse(self.treeModel.index(chi,0))
                break


    def stateChangetShowType(self,typeIs):
        self.delegate.sT=QtCore.QVariant(typeIs)
        parentItem = self.treeModel.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
            if not self.treeView.isRowHidden(chi,parentItem.index()):
                taak=self.treeView.isExpanded(self.treeModel.index(chi,0))
                if taak:
                    self.treeView.collapse(self.treeModel.index(chi,0))
                    self.treeView.expand(self.treeModel.index(chi,0))
                else:
                    self.treeView.expand(self.treeModel.index(chi,0))
                    self.treeView.collapse(self.treeModel.index(chi,0))
                break


    def exportstateChanged(self):
        self.AEExportButton.setText("Export selected")

    def exportAllLoadedstateChanged(self):
        self.AEExportButton.setText("Export All loaded")
        if self.AEExportAllLoadedChekbox.isChecked():
            self.AECleanFolder.setVisible(True) 
        else:
            self.AECleanFolder.setVisible(False) 


    def exportAllstateChanged(self):
        self.AEExportButton.setText("Export All")

    def exportanimationstateChanged(self):
        self.AEExportButton.setText("Export animation only")

    def collapseAllSlot(self):
        self.checkexpandFinded.setCheckState(QtCore.Qt.Unchecked)
        parentItem = self.treeModel.invisibleRootItem()
        self.collapseAllSlotRecurse(parentItem)

    def collapseAllSlotRecurse(self,item):
        for chi in range(item.rowCount()):
            self.treeView.setExpanded(item.child(chi,0).index(),False) 
            self.collapseAllSlotRecurse(item.child(chi,0))



    def findText(self,massFiles=[],files=False):   
        findTextLine = str(self.twoLineEdit.text())
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        #cmds.timer(s=True) 
        tree = []
        self.tree = []
        self.listReferences=[]
        self.loadAllrefs("",self.tree,self.tree,".*".join(findTextLine.split("*")),massFiles,files)
        self.printItemRefs(parentItem,self.tree)
        #print cmds.timer(e=True)
       
                        
    def printItemRefs(self, item, part):
        for i in range(len(part)):
            itemChild = QtGui.QStandardItem(part[i][5])
            itemChild.setData(part[i][2],QtCore.Qt.UserRole+2)
            itemChild.setData(part[i][3],QtCore.Qt.UserRole+3)
            itemChild.setData(part[i][5],QtCore.Qt.UserRole+4)
            itemChild.setData(part[i][6],QtCore.Qt.UserRole+5)
            itemChild.setData(part[i][7],QtCore.Qt.UserRole+6)
            itemChild.setData(part[i][1],QtCore.Qt.UserRole+1)
            #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            item.appendRow(itemChild)
            if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] == "0":
                    self.treeView.setRowHidden(itemChild.row(),item.index(),True) 
            if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] != "0":
                    self.treeView.setExpanded(itemChild.index(),True) 
            self.printItemRefs(itemChild,part[i][4])    


    def loadAllrefs(self,f,tree,root,sear,massFiles=[],files=False):
        rn = cmds.file(f, query=True, reference=True )
        for r in rn:
            skolkoConnectov=cmds.listConnections(cmds.file(r,q=True,rfn=True)+".proxyMsg",d=True,s=True,type="proxyManager")
            proxyTag=cmds.getAttr(cmds.file(r,q=True,rfn=True)+".proxyTag")
            ifOverExists=""
            edem=1
            if skolkoConnectov:
                ifOverExists="1"
                if len(skolkoConnectov)==1:
                    edem=0  
            if edem:
                parentNamespace=cmds.file(r,query=True,pns=True)[0]
                namespaceThis=cmds.file(r,query=True,ns=True)
                if parentNamespace != "":
                    namespaceAll=parentNamespace+":"+namespaceThis
                else:
                    namespaceAll=namespaceThis
                isLoaded=1-int(cmds.file(r,q=True,dr=True))
                est="0"
                if sear!="" or files:
                    expression = re.compile(sear, re.IGNORECASE)
                    m=False
                    if files:
                        if r in massFiles:
                            m=True
                    else:
                        m = expression.search(namespaceThis)
                    if m:
                        est="1"
                        tempRoot=self.tree
                        for sp in parentNamespace.split(":"):
                            for tr in tempRoot:
                                if tr[0]==sp:
                                    if tr[1]!="1":
                                        tr[1]="2"
                                    tempRoot=tr[4]
                        
                root.append([namespaceThis,est,isLoaded,r,[],namespaceAll,proxyTag,ifOverExists])
                if isLoaded:
                    self.listReferences.append(r)
                temp=root[-1][4]
                self.loadAllrefs(r,self.tree,temp,sear,massFiles,files)


    def AEExportButtonSlot(self):
        selectedFileslocal=[]
        if self.AEExportChekbox.isChecked():
            for i in self.treeView.selectionModel().selectedRows():
                selectedFileslocal.append(str(i.data(QtCore.Qt.UserRole+3).toString()))
        elif self.AEExportAnimationChekbox.isChecked():
            selectedFileslocal="animation"
        elif self.AEExportAllLoadedChekbox.isChecked():
            selectedFileslocal="allLoaded"

        frameRange=[]
        if self.rendSetR.isChecked():
            frameRange="renderSettings"
        elif self.timeSliderR.isChecked():
            frameRange="timeSlider"
        elif self.startEndR.isChecked():
            frameRange=[str(self.startFrameSB.value()),str(self.endFrameSB.value())]

        if self.sendToTractor.checkState()==QtCore.Qt.Checked:
            sceneName=cmds.file(q=True,sn=True)
            if type(selectedFileslocal)==type([]):
                selectedFileslocal="\\\\\\\""+",".join(selectedFileslocal)+"\\\\\\\""
            else:
                selectedFileslocal="\\\\\\\""+selectedFileslocal+"\\\\\\\""
            if type(frameRange)==type([]):
                frameRange="\\\\\\\""+",".join(frameRange)+"\\\\\\\""
            else:
                frameRange="\\\\\\\""+frameRange+"\\\\\\\""
            scriptString="python \"import alembic_export_new; alembic_export_new.AEExportButtonFun("+str(selectedFileslocal)+", gpuCache = "+str(self.AECreateGpuCasheChekbox.isChecked())+", cleanFolder="+str(self.AECleanFolder.isChecked())+", swithReferenceToOriginal="+str(self.AEswithreferenceToOriginal.checkState()==QtCore.Qt.Checked)+", loadUnloaded="+str(self.AEloadunloaded.checkState()==QtCore.Qt.Checked)+",frameRange="+str(frameRange)+")\""
            sendToRender.runFunctionFromSelectFiles(scriptString=scriptString,environmentKeyLE="maya2013",jobListTask=[sceneName])
        else:
            alembic_export_new.AEExportButtonFun(selectedFileslocal, gpuCache = self.AECreateGpuCasheChekbox.isChecked(), cleanFolder=self.AECleanFolder.isChecked(), swithReferenceToOriginal=self.AEswithreferenceToOriginal.checkState()==QtCore.Qt.Checked, loadUnloaded=self.AEloadunloaded.checkState()==QtCore.Qt.Checked,frameRange=frameRange)





        


##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT






class WindowAlembicImport(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowAlembicImport, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.sceneChanged=-2
        self.mainLayout.setSpacing(4)
        self.setProperty("index","AI")
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setLayout(self.mainLayout)


    def load(self):
        self.treWLayout = QtGui.QVBoxLayout()
        self.treWLayout.setContentsMargins(0,0,0,0)

        self.importCacheLayout = QtGui.QHBoxLayout()
        self.labelToFolderCB=QtGui.QLabel("Cashe folder:")
        self.FolderCombobox = QtGui.QComboBox()
        self.m_renderTypeList = QtCore.QStringList()
        filesss = glob.glob(alembic_export_new.FindAlembicSceneFolder(root=True)+"*")
        self.m_renderTypeList.append("choose")
        filesssPath = []
        for f in filesss:
            self.m_renderTypeList.append( f.split("/")[-1] )
            filesssPath.append(f)
        self.FolderCombobox.addItems( self.m_renderTypeList )
        for f in range(len(filesssPath)):
            if f==0:
                self.FolderCombobox.setItemData(0,"",QtCore.Qt.UserRole)
            self.FolderCombobox.setItemData(f+1,filesssPath[f],QtCore.Qt.UserRole)

        self.importUnloadRefsChekbox = QtGui.QCheckBox("gpu:auto unload refs")
        self.importUnloadRefsChekbox.setCheckState(QtCore.Qt.Checked)
        self.importUnloadRefsChekbox.setVisible(False) 
        self.importTimeRangesChekbox = QtGui.QCheckBox("gpu:set frame range")
        self.importTimeRangesChekbox.setCheckState(QtCore.Qt.Checked)
        self.importTimeRangesChekbox.setVisible(False) 
        self.autoLoadOtherVersionChekbox = QtGui.QCheckBox("auto load render version")
        self.autoLoadOtherVersionChekbox.setCheckState(QtCore.Qt.Checked)

        self.importCacheLayout.addWidget(self.labelToFolderCB)
        self.importCacheLayout.addWidget(self.FolderCombobox)
        self.importCacheLayout.addStretch(1)
        self.importCacheLayout.addWidget(self.importUnloadRefsChekbox)
        self.importCacheLayout.addWidget(self.autoLoadOtherVersionChekbox)
        self.importCacheLayout.addWidget(self.importTimeRangesChekbox)

        self.radioLayout = QtGui.QHBoxLayout()
        self.importLabel = QtGui.QLabel("Import")
        self.importChekboxAll = QtGui.QRadioButton("all")
        self.importChekboxSelected = QtGui.QRadioButton("selected")
        self.importChekboxSelected.toggled.connect(self.importstateChanged)                
        self.importButton = QtGui.QPushButton("Import")
        self.importButton.released.connect(self.importButtonSlot)
        self.radioLayout.addWidget(self.importLabel)
        self.radioLayout.addWidget(self.importChekboxAll)
        self.radioLayout.addWidget(self.importChekboxSelected)
        self.radioLayout.addStretch(1)
        self.radioLayout.addWidget(self.importButton)





        self.oneWidget2 = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind2 = QtGui.QVBoxLayout()
        self.oneWidget2.setLayout(self.groupBoxFind2)
        self.groupBoxFind2.setContentsMargins(3,3,3,3)
        self.twoLayout2 = QtGui.QHBoxLayout()
        self.twoLayout2.setContentsMargins(0,0,0,0)
        self.twoLabel2 = QtGui.QLabel("Name: ")
        self.twoLineEdit2 = QtGui.QLineEdit()
        self.twoLineEdit2.setText("")        
        self.twoLineEdit2.returnPressed.connect(self.findTextImport)
        self.twoPushButton2 = QtGui.QPushButton("Find")
        self.twoPushButton2.released.connect(self.findTextImport)
        self.twoLayout2.addWidget(self.twoLabel2)
        self.twoLayout2.addWidget(self.twoLineEdit2,1)                        
        self.twoLayout2.addWidget(self.twoPushButton2)                        
        self.groupBoxFind2.addLayout(self.twoLayout2)        


        self.findOneLayout = QtGui.QHBoxLayout()
        self.namespaceLabel2 = QtGui.QLabel(" show namespace")
        self.checkShowNamespace2 = QtGui.QSpinBox()
        self.checkShowNamespace2.setMinimum(-1)
        self.checkShowNamespace2.setValue(-1)
        self.showNamespace2=QtCore.QVariant(0)
        self.checkShowNamespace2.connect(self.checkShowNamespace2, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace2)                

        self.showFindedLabel2 = QtGui.QLabel(" only found")
        self.checkShowFinded2 = QtGui.QCheckBox()
        self.checkShowFinded2.setCheckState(QtCore.Qt.Checked)
        self.checkShowFinded2.connect(self.checkShowFinded2, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded2)                


        self.findOneLayout.addWidget(self.namespaceLabel2)
        self.findOneLayout.addWidget(self.checkShowNamespace2)
        self.findOneLayout.addWidget(self.showFindedLabel2)
        self.findOneLayout.addWidget(self.checkShowFinded2)
        self.findOneLayout.addStretch(1)
        self.groupBoxFind2.addLayout(self.findOneLayout)        


        self.treeView2 = QtGui.QTreeView()
        self.treeView2.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate2 = ImportSpinBoxDelegate()
        self.treeView2.setItemDelegate(self.delegate2)
        self.treeView2.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView2.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel2 = QtGui.QStandardItemModel()
        self.treeView2.setModel(self.treeModel2)
        self.treeView2.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView2.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView2.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView2.setHeaderHidden(True)
        self.groupBoxFind2.addWidget(self.treeView2)        


        self.treeViewGPU = QtGui.QTreeView()
        self.treeViewGPU.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegateGPU = ImportSpinBoxDelegate()
        self.treeViewGPU.setItemDelegate(self.delegateGPU)
        self.treeViewGPU.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeViewGPU.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModelGPU = QtGui.QStandardItemModel()
        self.treeViewGPU.setModel(self.treeModelGPU)
        self.treeViewGPU.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeViewGPU.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeViewGPU.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeViewGPU.setHeaderHidden(True)

        self.GPULayout = QtGui.QHBoxLayout()
        self.loadGPUButton = QtGui.QPushButton("Refresh")
        self.loadGPUButton.released.connect(self.GPUButtonSlot)
        self.switchGPUButton = QtGui.QPushButton("Switch")
        self.switchGPUButton.released.connect(self.switchGPUButtonSlot)
        self.GPULayout.addWidget(self.loadGPUButton)
        self.GPULayout.addWidget(self.switchGPUButton)

        self.treWLayout.addLayout(self.importCacheLayout)        
        self.treWLayout.addLayout(self.radioLayout)        
        self.treWLayout.addWidget(self.oneWidget2)
        self.treWLayout.addWidget(self.treeViewGPU)        
        self.treWLayout.addLayout(self.GPULayout)        
        self.importChekboxAll.setChecked(True)


        self.mainLayout.addLayout(self.treWLayout)
        self.FolderCombobox.currentIndexChanged.connect(self.changeFolderFiles)
        self.isLoad=True

    def ml_update(self,sc):
        self.sceneChanged=sc

    def GPUButtonSlot(self):
        self.treeModelGPU.clear()
        parentItem = self.treeModelGPU.invisibleRootItem()
        nodesss = cmds.ls("|system|gpu_cache",dag=True,type="gpuCache")
        for f in nodesss:
            itemChild = QtGui.QStandardItem(cmds.getAttr(f+".ml_namespace"))
            itemChild.setData(cmds.getAttr(f+".ml_origReferenceFile"),QtCore.Qt.UserRole)
            itemChild.setData(f,QtCore.Qt.UserRole+2)
            itemChild.setData(0,QtCore.Qt.UserRole+1)
            #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            parentItem.appendRow(itemChild)

    def switchGPUButtonSlot(self):
        data={}
        folderPath=""
        for i in self.treeViewGPU.selectionModel().selectedRows():
            selectedFiles=str(i.data(QtCore.Qt.UserRole).toString())
            selectedNodes=str(i.data(QtCore.Qt.UserRole+2).toString())
            parentNode=cmds.listRelatives(selectedNodes,p=True)[0]
            fileJSPath=cmds.getAttr(parentNode+".cacheFileName").replace(".abc",".js")
            if os.path.exists(fileJSPath):
                fileOpen = open(fileJSPath).read()
                data = json.loads(fileOpen)
            if cmds.getAttr(parentNode+".visibility"):
                cmds.setAttr(parentNode+".visibility",0)
                for fRF in data["parents"]:
                    if cmds.file(fRF,q=True,dr=True):
                        cmds.file(fRF,loadReference=True,lrd="topOnly")
                if alembic_export_new.fileExist(selectedFiles):
                    refNode=cmds.file(selectedFiles,q=True,rfn=True)
                    proxyMnger=cmds.listConnections(cmds.file(selectedFiles,q=True,rfn=True)+".proxyMsg")
                    if proxyMnger:
                        proxyMnger=proxyMnger[0]
                        artiveProxy=cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0].split(".")[-1]
                        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
                        filenameToLoad=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
                        if filenameToLoad != "":
                            if cmds.file(filenameToLoad,q=True,dr=True):
                                cmds.file(filenameToLoad,loadReference=artiveRnNode)
                    else:            
                        if cmds.file(selectedFiles,q=True,dr=True):
                            cmds.file(selectedFiles,loadReference=refNode)
            else:
                cmds.setAttr(parentNode+".visibility",1)
                nautiBilla=""
                try:
                    nautiBilla=cmds.file(selectedFiles,q=True,rfn=True)
                except:
                    pass
                if nautiBilla:
                    if cmds.file(selectedFiles,q=True,ex=True):
                        refNode=cmds.file(selectedFiles,q=True,rfn=True)
                        proxyMnger=cmds.listConnections(cmds.file(selectedFiles,q=True,rfn=True)+".proxyMsg")
                        if proxyMnger:
                            proxyMnger=proxyMnger[0]
                            listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                            for lP in listProxyes:
                                nextFile = cmds.referenceQuery(lP,f=True)
                                if not cmds.file(nextFile,q=True,dr=True):
                                    cmds.file(nextFile,unloadReference=lP)                
                        else:            
                            if not cmds.file(selectedFiles,q=True,dr=True):
                                cmds.file(selectedFiles,unloadReference=refNode)





    def findTextImport(self):
        findTextLine = str(self.twoLineEdit2.text())
        findTextLine = ".*".join(findTextLine.split("*"))
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.DisplayRole).toString()
                expression = re.compile(findTextLine, re.IGNORECASE)
                m = expression.search(temp)
                if m:
                    item.setData(1,QtCore.Qt.UserRole+1)
                    self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    item.setData(0,QtCore.Qt.UserRole+1)
                    if self.checkShowFinded2.checkState()==QtCore.Qt.Checked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 
                    else:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 

    def importstateChanged(self,a):
        if a:
            self.importButton.setText("Import selected")
        else:
            self.importButton.setText("Import All")


    def changeFolderFiles(self):
        if self.FolderCombobox.currentIndex()!=0:
            self.treeModel2.clear()
            parentItem = self.treeModel2.invisibleRootItem()
            folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
            filesss = glob.glob(folderPath+"/*.js")
            for f in filesss:
                if f.split("/")[-1]!="settings.js":
                    data={}
                    fileOpen=open(f).read()
                    data=json.loads(fileOpen)
                    itemChild = QtGui.QStandardItem(data["namespace"])
                    itemChild.setData(f,QtCore.Qt.UserRole)
                    itemChild.setData(0,QtCore.Qt.UserRole+1)
                    #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                    parentItem.appendRow(itemChild)

        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if folderPath.endswith("_gpu"):
            self.importUnloadRefsChekbox.setVisible(True) 
            self.importTimeRangesChekbox.setVisible(True) 
            self.autoLoadOtherVersionChekbox.setVisible(False) 
        else:
            self.importUnloadRefsChekbox.setVisible(False) 
            self.importTimeRangesChekbox.setVisible(False) 
            self.autoLoadOtherVersionChekbox.setVisible(True) 



    def importButtonSlot(self): 
        for ddd in cmds.ls(type="camera",l=True):
            if cmds.camera(ddd,q=True,startupCamera=True):
                if ddd not in ["|front|frontShape","|persp|perspShape","|side|sideShape","|top|topShape"]:
                    cmds.camera(ddd,e=True,startupCamera=False)
                    print "Kamera popravlena: "+ddd

        selectedFiles=[]
        if self.importChekboxSelected.isChecked():
            for i in self.treeView2.selectionModel().selectedRows():
                selectedFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        else:
            parentItem = self.treeModel2.invisibleRootItem()
            for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                selectedFiles.append(str(item.data(QtCore.Qt.UserRole).toString()))

        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if folderPath.endswith("_gpu"):
            if cmds.ls("|system") == []:
                cmds.createNode("transform",n="system")    
            if cmds.ls("|system|gpu_cache") == []:
                cmds.createNode("transform",n="gpu_cache",p="system")    

        for ifn in selectedFiles:
            data={}
            fileOpen = open(ifn).read()
            data = json.loads( fileOpen )
            if folderPath.endswith("_gpu"):
                findedRefFile=data["file"]
                findedRefNamespace=data["namespace"]
                nameee=alembic_export_new.refnameTofname(findedRefFile.split("/")[-1])
                folderName=""
                if cmds.ls("|system|gpu_cache|"+nameee) == []:    
                    folderName = cmds.createNode("transform",n=nameee,p="|system|gpu_cache")
                else:
                    folderName=cmds.ls("|system|gpu_cache|"+nameee)[0] 
                nodeShapeName=""
                if cmds.ls("|system|gpu_cache|"+nameee,dag=True,type="gpuCache") == []:    
                    nodeShapeName=cmds.createNode("gpuCache",n=nameee+"Shape",p="|system|gpu_cache|"+folderName)
                else:
                    nodeShapeName=cmds.ls(nameee,dag=True,type="gpuCache")[0]
                cmds.setAttr(nodeShapeName+".cfn",ifn.replace(".js",".abc"),type="string")    

                if not cmds.attributeQuery("ml_origReferenceFile",n=nodeShapeName,ex=True):
                    cmds.addAttr(nodeShapeName,longName="ml_origReferenceFile",dt="string")
                cmds.setAttr(nodeShapeName+".ml_origReferenceFile",findedRefFile,type="string")
                if not cmds.attributeQuery("ml_namespace",n=nodeShapeName,ex=True):
                    cmds.addAttr(nodeShapeName,longName="ml_namespace",dt="string")
                cmds.setAttr(nodeShapeName+".ml_namespace",findedRefNamespace,type="string")

                if findedRefFile:
                    if self.importUnloadRefsChekbox.checkState()==QtCore.Qt.Checked:
                        if alembic_export_new.fileExist(findedRefFile):
                            refNode=cmds.file(findedRefFile,q=True,rfn=True)
                            proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                            if proxyMnger:
                                proxyMnger=proxyMnger[0]
                                listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                                for lP in listProxyes:
                                    nextFile = cmds.referenceQuery(lP,f=True)
                                    if not cmds.file(nextFile,q=True,dr=True):
                                        cmds.file(nextFile,unloadReference=lP)                
                            else:            
                                if not cmds.file(findedRefFile,q=True,dr=True):
                                    cmds.file(findedRefFile,unloadReference=refNode)


                if self.importUnloadRefsChekbox.checkState()==QtCore.Qt.Checked:
                    dataMainSettings={}
                    fileOpen = open(folderPath+"/settings.js").read()
                    dataMainSettings = json.loads( fileOpen )
                    cmds.playbackOptions(animationStartTime=dataMainSettings["timeRange"][0])
                    cmds.playbackOptions(min=dataMainSettings["timeRange"][0])
                    cmds.playbackOptions(animationEndTime=dataMainSettings["timeRange"][1])
                    cmds.playbackOptions(max=dataMainSettings["timeRange"][1])
                
            else:
                replacePers=""
                if self.autoLoadOtherVersionChekbox.checkState()==QtCore.Qt.Checked:
                    replacePers=data["replaceReferenceVersion"]
                #if self.autoLoadOtherVersionChekbox.checkState()==QtCore.Qt.Checked:
                #    findedRefFile=data["file"]
                #    replacePers=main.getAssetFirstVersion(re.sub("\{[0-9]*\}","",findedRefFile))

                existsNameSpace=cmds.namespaceInfo(lon=True,r=True,an=True) 
                filenamespace=data["namespace"]
                if filenamespace not in existsNameSpace:
                    cmds.namespace(add=filenamespace)
                if data["namespaces"]:
                    for t in data["namespaces"]: 
                        if t not in existsNameSpace:
                            cmds.namespace(add=t)

                if "nodes" in data.keys():
                    for t in data["nodes"]:
                        if (replacePers and data["nodes"][t]["type"] != "partition") or (not replacePers):
                            if not cmds.objExists(t):
                                thisNode=cmds.createNode(data["nodes"][t]["type"])
                                thisNode=cmds.rename(thisNode,t)
                                for tt in data["nodes"][t]["attributes"]:
                                    if not cmds.attributeQuery(tt,n=thisNode,ex=True):
                                        cmds.addAttr(thisNode,longName=tt,dt=data["nodes"][t]["attributes"][tt]["type"])
                                    cmds.setAttr(thisNode+"."+tt,data["nodes"][t]["attributes"][tt]["value"],type=data["nodes"][t]["attributes"][tt]["type"])

                if replacePers:
                    if not cmds.namespaceInfo(filenamespace,ls=True):
                        print "LOAD RENDER VERSION:"+replacePers
                        cmds.file(replacePers,i=True,mergeNamespacesOnClash=True,namespace=filenamespace)

                mel.eval("AbcImport -mode import -fitTimeRange -connect \"/\" -setToStartFrame -createIfNotFound \""+ifn.replace(".js",".abc")+"\"")



    def stateChangetShowNamespace2(self,typeIs):
        self.delegate2.sN=typeIs
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem2.rowCount()):
            if not self.treeView2.isRowHidden(chi,parentItem.index()):
                taak=self.treeView2.isExpanded(self.treeModel2.index(chi,0))
                if taak:
                    self.treeView2.collapse(self.treeModel2.index(chi,0))
                    self.treeView2.expand(self.treeModel2.index(chi,0))
                else:
                    self.treeView2.expand(self.treeModel2.index(chi,0))
                    self.treeView2.collapse(self.treeModel2.index(chi,0))
                break

    def stateChangetShowFinded2(self,typeIs):
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.UserRole+1).toInt()[0]
                if self.checkShowFinded2.checkState()==QtCore.Qt.Unchecked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    if not temp:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 













#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################
#####################ATTRIBUTTTEEEESSSSS#################################






class WindowAttributes(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowAttributes, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.sceneChanged=-2
        self.mainLayout.setSpacing(4)
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setProperty("index","Attr")
        self.setLayout(self.mainLayout)


    def load(self):
        self.AEgroupBoxFind = QtGui.QVBoxLayout()
        self.AEgroupBoxFind.setSpacing(2)

        self.setWidget = QtGui.QGroupBox( " Set value " )
        self.groupBoxSet = QtGui.QVBoxLayout()
        self.groupBoxSet.setSpacing(4)
        self.setWidget.setLayout(self.groupBoxSet)
        self.groupBoxSet.setContentsMargins(3,3,3,3)

        self.treWidget = QtGui.QGroupBox("Linking")
        self.treWLayout = QtGui.QVBoxLayout()
        self.treWidget.setLayout(self.treWLayout)
        self.treWLayout.setContentsMargins(3,3,3,3)
        self.treWCheckBox = QtGui.QCheckBox(" Lighting ")
        self.treWCheckBox.setStyleSheet("QCheckBox::indicator:unchecked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-closed-scaled.png); width: 11px; height: 11px;} QCheckBox::indicator:checked{ image: url(/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/stylesheet-branch-open-scaled.png); width: 11px; height: 11px;} QCheckBox{font-weight: bold;}")
        self.treWCheckBox.setCheckState(QtCore.Qt.Checked)
        self.treWCheckBox.setContentsMargins(0,0,0,0)
        self.treWCheckBox.stateChanged.connect(self.stateTreChangetgroupBowCB)

        self.findLightLayout = QtGui.QHBoxLayout()
        self.findLightLayout.setContentsMargins(0,0,0,0)
        self.findLightLabel= QtGui.QLabel("Find objects where current lights:")
        #self.findLightLabel.setAlignment(QtCore.Qt.AlignRight and QtCore.Qt.AlignVCenter)
        self.findLightPushButton = QtGui.QPushButton("exist")
        self.findLightPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.findLightPushButton.released.connect(self.findLights)
        self.onLightPushButton = QtGui.QPushButton("on")
        self.onLightPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.onLightPushButton.released.connect(self.findOnLights)
        self.offLightPushButton = QtGui.QPushButton("off")
        self.offLightPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.offLightPushButton.released.connect(self.findOffLights)
        self.findLightLayout.addWidget(self.findLightLabel)
        self.findLightLayout.addStretch(1)
        self.findLightLayout.addWidget(self.findLightPushButton)
        self.findLightLayout.addWidget(self.onLightPushButton)
        self.findLightLayout.addWidget(self.offLightPushButton)

        self.setLightLayout = QtGui.QHBoxLayout()
        self.setLightLayout.setContentsMargins(0,0,0,0)
        self.setLightLabel= QtGui.QLabel("Link current lights with selected objects:")
        self.makeLPushButton = QtGui.QPushButton("Clear")
        self.makeLPushButton.released.connect(self.clearLSlot)
        self.addLPushButton = QtGui.QPushButton("Make")
        self.addLPushButton.released.connect(self.addLSlot)
        self.removeLPushButton = QtGui.QPushButton("Break")
        self.removeLPushButton.released.connect(self.removeLSlot)
        self.setLightLayout.addWidget(self.makeLPushButton)
        self.setLightLayout.addWidget(self.addLPushButton)
        self.setLightLayout.addWidget(self.removeLPushButton)
        self.treWLayout.setSpacing(2)
        self.treWLayout.addLayout(self.findLightLayout)
        self.treWLayout.addWidget(self.setLightLabel)
        self.treWLayout.addLayout(self.setLightLayout)



        self.AttrLabel = QtGui.QLabel("Attribute:")
        self.AttrAddCombobox = QtGui.QComboBox()
        self.AttrAddCombobox.setEditable(True)
        self.AttrAddCombobox.completer().setCompletionMode(QtGui.QCompleter.InlineCompletion)
        self.AttrAddCombobox.setAutoCompletion(True)
        self.AttrAddCombobox.view().setAlternatingRowColors(True)
        self.AttrAddCombobox.lineEdit().returnPressed.connect(self.findText)
        self.m_AttrTypeList = QtCore.QStringList()
        self.rendermanAttrs=mel.eval("rmanGetOptionalAttrs(\"persp\")")
        self.rendermanAttrNames=[""]
        self.m_AttrTypeList.append("")
        for i in self.rendermanAttrs:
            self.m_AttrTypeList.append(i)
            self.rendermanAttrNames.append(mel.eval("rman getRmanAttrName \""+i+"\""))
        self.AttrAddCombobox.addItems( self.rendermanAttrNames )
        for f in range(len(self.m_AttrTypeList)):
            self.AttrAddCombobox.setItemData(f,self.m_AttrTypeList[f],QtCore.Qt.UserRole)
            self.AttrAddCombobox.setItemData(f,"rman",QtCore.Qt.UserRole+1)


        self.ValueLabel = QtGui.QLabel("Value:")
        self.lineEditValueOfAttribute = QtGui.QLineEdit()
        self.lineEditValueOfAttribute.returnPressed.connect(self.findText)
        self.attrAttrLayout = QtGui.QHBoxLayout()
        self.attrAttrLayout.setContentsMargins(0,0,0,0)
        self.attrAttrLayout.addWidget(self.AttrLabel)
        self.attrAttrLayout.addWidget(self.AttrAddCombobox)
        self.attrAttrLayout.addStretch(1)
        self.attrValueLayout = QtGui.QHBoxLayout()
        self.attrValueLayout.setContentsMargins(0,0,0,0)
        self.attrValueLayout.addWidget(self.ValueLabel)
        self.attrValueLayout.addWidget(self.lineEditValueOfAttribute)

        self.partBlockLayout = QtGui.QHBoxLayout()
        self.partBlockLayout.setContentsMargins(0,0,0,0)
        self.currentValueLabel = QtGui.QLabel("Part block: ")
        self.partBlockValueLineEdit = QtGui.QLineEdit()
        self.partBlockLayout.addWidget(self.currentValueLabel)                   
        self.partBlockLayout.addWidget(self.partBlockValueLineEdit)                   

        self.replaceStringLayout = QtGui.QHBoxLayout()
        self.replaceStringLayout.setContentsMargins(0,0,0,0)
        self.replaceStringLabel = QtGui.QLabel("Replase string: ")
        self.replaceStringLineEdit = QtGui.QLineEdit()
        self.replaceStringLayout.addWidget(self.replaceStringLabel)                   
        self.replaceStringLayout.addWidget(self.replaceStringLineEdit)                   

        self.stringIfNotLayout = QtGui.QHBoxLayout()
        self.stringIfNotLayout.setContentsMargins(0,0,0,0)
        self.stringIfNotLabel = QtGui.QLabel("if empty: ")
        self.stringIfNotLineEdit = QtGui.QLineEdit()
        self.stringIfNotLayout.addWidget(self.stringIfNotLabel)                   
        self.stringIfNotLayout.addWidget(self.stringIfNotLineEdit)                   

        self.setChildLayout = QtGui.QHBoxLayout()
        self.setChildLayout.setContentsMargins(0,0,0,0)
        self.valueLabel = QtGui.QLabel("Value:")
        self.valueLineEdit = QtGui.QLineEdit()
        self.valueLineEdit.returnPressed.connect(self.doit)
        self.setChildLayout.addWidget(self.valueLabel)                        
        self.setChildLayout.addWidget(self.valueLineEdit)                        

        self.setChildRadioLayout = QtGui.QHBoxLayout()
        self.deystviyaBG = QtGui.QButtonGroup()
        self.setRB = QtGui.QRadioButton("set")
        self.setRB.toggled.connect(self.stringSetSlot)
        self.removeRB = QtGui.QRadioButton("remove")
        self.removeRB.toggled.connect(self.stringRemoveSlot)
        self.addRB = QtGui.QRadioButton("plus")
        self.addRB.toggled.connect(self.stringAddSlot)
        self.scaleRB = QtGui.QRadioButton("multiply")
        self.scaleRB.toggled.connect(self.stringScaleSlot)
        self.replaceRB = QtGui.QRadioButton("replace")
        self.replaceRB.toggled.connect(self.stringReplaceSlot)
        self.deystviyaBG.addButton(self.setRB)
        self.deystviyaBG.addButton(self.removeRB)
        self.deystviyaBG.addButton(self.addRB)
        self.deystviyaBG.addButton(self.scaleRB)
        self.deystviyaBG.addButton(self.replaceRB)
        self.setChildRadioLayout.addWidget(self.setRB)        
        self.setChildRadioLayout.addWidget(self.removeRB)        
        self.setChildRadioLayout.addWidget(self.addRB)        
        self.setChildRadioLayout.addWidget(self.scaleRB)        
        self.setChildRadioLayout.addWidget(self.replaceRB)        

        self.setValuePushButton = QtGui.QPushButton("Do it")
        self.setValuePushButton.released.connect(self.doit)

        self.groupBoxSet.addLayout(self.partBlockLayout)        
        self.groupBoxSet.addLayout(self.replaceStringLayout)        
        self.groupBoxSet.addLayout(self.stringIfNotLayout)        
        self.groupBoxSet.addLayout(self.setChildLayout)        
        self.groupBoxSet.addLayout(self.setChildRadioLayout)        
        self.groupBoxSet.addWidget(self.setValuePushButton)                        

        self.oneWidget = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind = QtGui.QVBoxLayout()
        self.groupBoxFind.setSpacing(4)
        self.oneWidget.setLayout(self.groupBoxFind)
        self.groupBoxFind.setContentsMargins(3,3,3,3)
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLayout.setContentsMargins(0,0,0,0)
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.AttrCombobox = QtGui.QComboBox()
        self.AttrCombobox.setEditable(True)
        self.AttrCombobox.completer().setCompletionMode(QtGui.QCompleter.InlineCompletion)
        self.AttrCombobox.setAutoCompletion(True)
        self.AttrCombobox.view().setAlternatingRowColors(True)
        self.AttrCombobox.lineEdit().returnPressed.connect(self.findText)
        self.m_AttrTypeList = QtCore.QStringList()
        self.rendermanAttrs=mel.eval("rmanGetOptionalAttrs(\"persp\")")
        self.rendermanAttrNames=[""]
        self.m_AttrTypeList.append("")
        for i in self.rendermanAttrs:
            self.m_AttrTypeList.append(i)
            self.rendermanAttrNames.append(mel.eval("rman getRmanAttrName \""+i+"\""))
        self.AttrCombobox.addItems( self.rendermanAttrNames )
        for f in range(len(self.m_AttrTypeList)):
            self.AttrCombobox.setItemData(f,self.m_AttrTypeList[f],QtCore.Qt.UserRole)

        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)
        self.groupBoxFind.addLayout(self.twoLayout)        
        self.groupBoxFind.addLayout(self.attrAttrLayout)        
        self.groupBoxFind.addLayout(self.attrValueLayout)        



        self.showLabel = QtGui.QLabel("show type")
        self.checkShowType = QtGui.QCheckBox()
        self.namespaceLabel = QtGui.QLabel("namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                
        self.showTypeLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showLabel)
        self.showTypeLayout.addWidget(self.checkShowType)
        self.showTypeLayout.addWidget(self.namespaceLabel)
        self.showTypeLayout.addWidget(self.checkShowNamespace)
        self.showTypeLayout.addStretch(1)

        self.showFindedLabel = QtGui.QLabel(" only found")
        self.checkShowFinded = QtGui.QCheckBox()
        self.checkShowFinded.setCheckState(QtCore.Qt.Unchecked)
        self.checkShowFinded.connect(self.checkShowFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded)                



        self.outLayout = QtGui.QHBoxLayout()
        self.outlonerLabel = QtGui.QLabel("Send")
        self.fromOutPushButton = QtGui.QPushButton("To")
        self.fromOutPushButton.setMinimumWidth( 10 )
        self.fromOutPushButton.released.connect(self.fromOutSlot)
        self.fromOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.toOutPushButton = QtGui.QPushButton("From")
        self.toOutPushButton.setMinimumWidth( 10 )
        self.toOutPushButton.released.connect(self.toOutSlot)
        self.toOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.outlonerLabel2 = QtGui.QLabel("Outliner")
        self.outLayout.addWidget(self.outlonerLabel)
        self.outLayout.addWidget(self.fromOutPushButton)
        self.outLayout.addWidget(self.toOutPushButton)
        self.outLayout.addWidget(self.outlonerLabel2)
        self.outLayout.addStretch(1)


        self.collapsePushButton = QtGui.QPushButton("collapse all")
        self.collapsePushButton.released.connect(self.collapseAllSlot)

        self.checkexpandFinded = QtGui.QPushButton("expand found")
        self.checkexpandFinded.released.connect(self.stateChangetExpandFinded)

        self.showFindedLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showFindedLabel)
        self.showTypeLayout.addWidget(self.checkShowFinded)
        self.showTypeLayout.addStretch(1)
        self.showFindedLayout.addWidget(self.collapsePushButton)
        self.showFindedLayout.addWidget(self.checkexpandFinded)
        self.showFindedLayout.addStretch(1)


        self.groupBoxFind.addLayout(self.showTypeLayout)
        self.groupBoxFind.addLayout(self.showFindedLayout)

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = ExportSpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        self.treeView.setAlternatingRowColors(True)
        self.treeView.selectionModel().connect(self.treeView.selectionModel(), QtCore.SIGNAL("currentChanged (QModelIndex,QModelIndex)"), self.currentselectionChanged)                
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.groupBoxFind.addWidget(self.treeView)        
        self.groupBoxFind.addLayout(self.outLayout)
        
        self.AEgroupBoxFind.addWidget(self.treWCheckBox)        
        self.AEgroupBoxFind.addWidget(self.treWidget)        
        self.AEgroupBoxFind.addWidget(self.setWidget)        
        self.AEgroupBoxFind.addWidget(self.oneWidget)        
        self.mainLayout.addLayout(self.AEgroupBoxFind)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.checkShowType.setCheckState(QtCore.Qt.Checked)
        self.isLoad=True
        self.setRB.setChecked(True)

    def stringSetSlot(self,est):
        if est:
            self.partBlockValueLineEdit.setEnabled(False)
            self.replaceStringLineEdit.setEnabled(False)
            self.stringIfNotLineEdit.setEnabled(False)
            self.valueLineEdit.setEnabled(True)
            self.currentValueLabel.setEnabled(False)
            self.replaceStringLabel.setEnabled(False)
            self.stringIfNotLabel.setEnabled(False)
            self.valueLabel.setEnabled(True)

    def stringRemoveSlot(self,est):
        if est:
            self.partBlockValueLineEdit.setEnabled(False)
            self.replaceStringLineEdit.setEnabled(False)
            self.stringIfNotLineEdit.setEnabled(False)
            self.valueLineEdit.setEnabled(False)
            self.currentValueLabel.setEnabled(False)
            self.replaceStringLabel.setEnabled(False)
            self.stringIfNotLabel.setEnabled(False)
            self.valueLabel.setEnabled(False)

    def stringAddSlot(self,est):
        if est:
            self.partBlockValueLineEdit.setEnabled(False)
            self.replaceStringLineEdit.setEnabled(False)
            self.stringIfNotLineEdit.setEnabled(False)
            self.valueLineEdit.setEnabled(True)
            self.currentValueLabel.setEnabled(False)
            self.replaceStringLabel.setEnabled(False)
            self.stringIfNotLabel.setEnabled(False)
            self.valueLabel.setEnabled(True)

    def stringScaleSlot(self,est):
        if est:
            self.partBlockValueLineEdit.setEnabled(False)
            self.replaceStringLineEdit.setEnabled(False)
            self.stringIfNotLineEdit.setEnabled(False)
            self.valueLineEdit.setEnabled(True)
            self.currentValueLabel.setEnabled(False)
            self.replaceStringLabel.setEnabled(False)
            self.stringIfNotLabel.setEnabled(False)
            self.valueLabel.setEnabled(True)

    def stringReplaceSlot(self,est):
        if est:
            self.partBlockValueLineEdit.setEnabled(True)
            self.replaceStringLineEdit.setEnabled(True)
            self.stringIfNotLineEdit.setEnabled(True)
            self.valueLineEdit.setEnabled(True)
            self.currentValueLabel.setEnabled(True)
            self.replaceStringLabel.setEnabled(True)
            self.stringIfNotLabel.setEnabled(True)
            self.valueLabel.setEnabled(True)

    def warningOChemto(self,text):
        msgBox = QtGui.QMessageBox()
        msgBox.setWindowTitle("WARNING!")
        msgBox.setText(text)
        #msgBox.setInformativeText("Do you want to save your changes?")
        but=msgBox.addButton("Ok",QtGui.QMessageBox.AcceptRole)
        ret = msgBox.exec_()

    def findLights(self):
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights:
            self.warningOChemto("Select Lights!!!!!")
            return
        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)


    def findOnLights(self):
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights:
            self.warningOChemto("Select Lights!!!!!")
            return
        for i in range(len(lights)):
            lights[i]="&"+lights[i]
        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)


    def findOffLights(self):
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights:
            self.warningOChemto("Select Lights!!!!!")
            return
        for i in range(len(lights)):
            lights[i]="&-"+lights[i]
        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)

    def updateCaption(self):
        self.treeView.verticalScrollBar().setSliderPosition(self.tempScroll)


    def clearLSlot(self):
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.replaceRB.setChecked(True)        
        self.partBlockValueLineEdit.setText(",\"string lightcategory\",\"")
        self.valueLineEdit.setText("")
        self.stringIfNotLineEdit.setText("")
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights or not self.treeView.selectionModel().selectedRows():
            self.warningOChemto("Select Lights and objects!!!!!")
            return
        for light in lights:
            self.replaceStringLineEdit.setText("&-?"+light)
            self.doit()

        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)

    def addLSlot(self):
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.replaceRB.setChecked(True)        
        self.partBlockValueLineEdit.setText(",\"string lightcategory\",\"")
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights or not self.treeView.selectionModel().selectedRows():
            self.warningOChemto("Select Lights and objects!!!!!")
            return
        for light in lights:
            self.replaceStringLineEdit.setText("&-?"+light)
            self.valueLineEdit.setText("&"+light)
            self.stringIfNotLineEdit.setText("RiAttribute(\"user\",\"string lightcategory\",\"&"+light+"\")")
            self.doit(forceCreateAttribute=True)

        for i in range(len(lights)):
            lights[i]="&"+lights[i]
        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)

    def removeLSlot(self):
        indexNaiden = self.AttrAddCombobox.findText("transformBeginScript")
        if indexNaiden != -1:
            self.AttrAddCombobox.setCurrentIndex(indexNaiden)
        self.replaceRB.setChecked(True)        
        self.partBlockValueLineEdit.setText(",\"string lightcategory\",\"")
        lights=cmds.ls(sl=True,dag=True, type=["RMSGeoAreaLight","RMSGIPtcLight","RMSGILight","RMSEnvLight","RMSAreaLight"])
        if not lights or not self.treeView.selectionModel().selectedRows():
            self.warningOChemto("Select Lights and objects!!!!!")
            return
        for light in lights:
            self.replaceStringLineEdit.setText("&-?"+light)
            self.valueLineEdit.setText("&-"+light)
            self.stringIfNotLineEdit.setText("RiAttribute(\"user\",\"string lightcategory\",\"&-"+light+"\")")
            self.doit(forceCreateAttribute=True)

        for i in range(len(lights)):
            lights[i]="&-"+lights[i]
        findLightsList="|".join(lights)
        self.lineEditValueOfAttribute.setText(findLightsList)        
        self.tempScroll=self.treeView.verticalScrollBar().sliderPosition()
        self.findText()
        QtCore.QTimer.singleShot(1, self.updateCaption)

    def stateTreChangetgroupBowCB(self,a):
        self.treWidget.setVisible(a)

    def doit(self,forceCreateAttribute=False):
        ar=[]
        for i in self.treeView.selectionModel().selectedRows():
            file=str(i.data(QtCore.Qt.DisplayRole).toString())
            ar.append(file)

        value = str(self.valueLineEdit.text())
        attr=str(self.AttrAddCombobox.itemData(self.AttrAddCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if attr:
            if self.setRB.isChecked() and value:
                rezValue=""
                for r in ar:
                    mel.eval("rmanAddAttr(\""+r+"\",\""+attr+"\",\""+value+"\")") 
                    rezValue=str(cmds.getAttr(r+"."+attr))
                for i in self.treeView.selectionModel().selectedRows():
                    self.treeModel.setData(i,rezValue,QtCore.Qt.UserRole+5)
                    self.treeModel.setData(i,"1",QtCore.Qt.UserRole+1)
            elif self.removeRB.isChecked():
                print "remove"
                for r in ar:
                    if cmds.attributeQuery(attr,n=r,ex=True):
                        cmds.deleteAttr(r+"."+attr)
                for i in self.treeView.selectionModel().selectedRows():
                    self.treeModel.setData(i,"",QtCore.Qt.UserRole+5)
                    self.treeModel.setData(i,"0",QtCore.Qt.UserRole+1)
            elif self.addRB.isChecked() and value:
                checkValue=""
                expression = re.compile("^[0-9\,\.]*", re.IGNORECASE)
                m = expression.search(value)
                if m:
                    checkValue=m.group(0)
                    if checkValue:
                        tempArray=[]
                        for r in ar:
                            checkAttrValue=""
                            if cmds.attributeQuery(attr,n=r,ex=True):
                                getValue=cmds.getAttr(r+"."+attr)
                                m = expression.search(str(getValue))
                                if m:
                                    checkAttrValue=m.group(0)
                                    if checkAttrValue:
                                        checkAttrValue=str(float(checkValue)+float(checkAttrValue))
                                        mel.eval("rmanAddAttr(\""+r+"\",\""+attr+"\",\""+checkAttrValue+"\")") 
                            tempArray.append(checkAttrValue)
                        ii=0
                        for i in self.treeView.selectionModel().selectedRows():
                            self.treeModel.setData(i,tempArray[ii],QtCore.Qt.UserRole+5)
                            ii+=1
            elif self.scaleRB.isChecked() and value:
                checkValue=""
                expression = re.compile("^[0-9\,\.]*", re.IGNORECASE)
                m = expression.search(value)
                if m:
                    checkValue=m.group(0)
                    if checkValue:
                        tempArray=[]
                        for r in ar:
                            checkAttrValue=""
                            if cmds.attributeQuery(attr,n=r,ex=True):
                                getValue=cmds.getAttr(r+"."+attr)
                                m = expression.search(str(getValue))
                                if m:
                                    checkAttrValue=m.group(0)
                                    if checkAttrValue:
                                        checkAttrValue=str(float(checkValue)*float(checkAttrValue))
                                        mel.eval("rmanAddAttr(\""+r+"\",\""+attr+"\",\""+checkAttrValue+"\")") 
                            tempArray.append(checkAttrValue)
                        ii=0
                        for i in self.treeView.selectionModel().selectedRows():
                            self.treeModel.setData(i,tempArray[ii],QtCore.Qt.UserRole+5)
                            ii+=1
            elif self.replaceRB.isChecked():
                nachalo = str(self.partBlockValueLineEdit.text())
                chtomenyaem = str(self.replaceStringLineEdit.text())
                stringIfNot = str(self.stringIfNotLineEdit.text())
                tempRez=[]
                for r in ar:
                    if forceCreateAttribute:
                        if not cmds.attributeQuery(attr,n=r,ex=True):
                            mel.eval("rmanAddAttr(\""+r+"\",\""+attr+"\",\"\")") 
                    rez=""
                    if cmds.attributeQuery(attr,n=r,ex=True):
                        attrValue=cmds.getAttr(r+"."+attr)
                        rez=self.changeStringAttrComplex(nachalo,chtomenyaem,value,attrValue,stringIfNot)
                        cmds.setAttr(r+"."+attr,rez,type="string")
                        rez=cmds.getAttr(r+"."+attr)
                    tempRez.append(rez)
                ii=0
                for i in self.treeView.selectionModel().selectedRows():
                    self.treeModel.setData(i,tempRez[ii],QtCore.Qt.UserRole+5)
                    #self.treeModel.setData(i,"1",QtCore.Qt.UserRole+1)
                    ii+=1

    #def changeStringAttr(self,rezultString,chtoIshem, naChtoMenyaem):
    #    return re.sub(re.escape(chtoIshem), naChtoMenyaem, rezultString)

    def changeStringAttr(self,nachalo,chtomenyaem,nachtomenyaem,stroka):
        rezParts=[]
        findly=[]
        if nachalo:
            findly=re.findall("(?<=;).*"+nachalo+".*?;", stroka)
            rezParts=re.split("(?<=;).*"+nachalo+".*?;", stroka)
            if not findly:
                findly=re.findall(".*"+nachalo+".*?;", stroka)
                rezParts=re.split(".*"+nachalo+".*?;", stroka)    
            if not findly:
                findly=re.findall("(?<=;).*"+nachalo+".*", stroka)
                rezParts=re.split("(?<=;).*"+nachalo+".*", stroka)        
            if not findly:
                findly=re.findall(".*"+nachalo+".*", stroka)
                rezParts=re.split(".*"+nachalo+".*", stroka)        
        else:
            rezParts=["",""]
            findly=[stroka]    
            
        if findly:
            rez = re.sub(chtomenyaem, nachtomenyaem, findly[0])
            return rezParts[0]+rez+rezParts[1]


    def changeStringAttrComplex(self,nachalo,chtomenyaem,nachtomenyaem,stroka,stringIfNot):
        rezParts=[]
        findly=[]
        if nachalo:
            findly=re.findall("(?<=;).*"+nachalo+".*?;", stroka)
            rezParts=re.split("(?<=;).*"+nachalo+".*?;", stroka)
            if not findly:
                findly=re.findall(".*"+nachalo+".*?;", stroka)
                rezParts=re.split(".*"+nachalo+".*?;", stroka)    
            if not findly:
                findly=re.findall("(?<=;).*"+nachalo+".*", stroka)
                rezParts=re.split("(?<=;).*"+nachalo+".*", stroka)        
            if not findly:
                findly=re.findall(".*"+nachalo+".*", stroka)
                rezParts=re.split(".*"+nachalo+".*", stroka)        
            if not findly:        
                findly=[stringIfNot]
                rezParts=["",stroka]
        else:
            rezParts=["",""]
            findly=[stroka]    

        rez=""    
        if findly:
            rez=findly[0]
            if chtomenyaem:
                rez = re.sub(chtomenyaem, nachtomenyaem, findly[0])
                if rez == findly[0] and not re.search(chtomenyaem,findly[0]):
                    if nachalo:
                        rez = re.sub(nachalo, nachalo+nachtomenyaem, findly[0])
                    else:
                        if len(findly[0]) and findly[0][-1]!=";":
                            findly[0]=findly[0]+";"
                        rez = findly[0] + stringIfNot
            else:
                if not re.search(nachtomenyaem,findly[0]):
                    if nachalo:
                        rez = re.sub(nachalo, nachalo+nachtomenyaem, findly[0])
                    else:            
                        if len(findly[0]) and findly[0][-1]!=";":
                            findly[0]=findly[0]+";"
                        rez = findly[0] + stringIfNot
        return rezParts[0]+rez+rezParts[1]

    def currentselectionChanged(self,current,previous):
            self.lineEditValueOfAttribute.setText(current.data(QtCore.Qt.UserRole+5).toString())        

    def fromOutSlot(self):
        ar=[]
        for i in self.treeView.selectionModel().selectedRows():
            file=str(i.data(QtCore.Qt.DisplayRole).toString())
            ar.append(file)
        cmds.select(cl=True)
        if ar:
            cmds.select(ar,ne=True)

    def toOutSlot(self):
        ar=cmds.ls(sl=True)
        self.findText(massFiles=ar)


    def ml_update(self,sc):
        self.sceneChanged=sc

    def stateChangetShowFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.showFindedRecurse(parentItem,typeIs)

    def showFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            if val:
                temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
                if temp != 0:
                    self.treeView.setRowHidden(chi,item.index(),False) 
                    self.showFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setRowHidden(chi,item.index(),True) 
            else:
                self.treeView.setRowHidden(chi,item.index(),False) 
                self.showFindedRecurse(item.child(chi,0),val)

    def stateChangetExpandFinded(self):
        parentItem = self.treeModel.invisibleRootItem()
        self.expandFindedRecurse(parentItem,True)

    def expandFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
            if temp != 0:
                if val:
                        self.treeView.setExpanded(item.child(chi,0).index(),True) 
                        self.expandFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setExpanded(item.child(chi,0).index(),False) 


    def stateChangetShowNamespace(self,typeIs):
        self.delegate.sN=typeIs
        parentItem = self.treeModel.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
            if not self.treeView.isRowHidden(chi,parentItem.index()):
                taak=self.treeView.isExpanded(self.treeModel.index(chi,0))
                if taak:
                    self.treeView.collapse(self.treeModel.index(chi,0))
                    self.treeView.expand(self.treeModel.index(chi,0))
                else:
                    self.treeView.expand(self.treeModel.index(chi,0))
                    self.treeView.collapse(self.treeModel.index(chi,0))
                break


    def stateChangetShowType(self,typeIs):
        self.delegate.sT=QtCore.QVariant(typeIs)
        parentItem = self.treeModel.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
            if not self.treeView.isRowHidden(chi,parentItem.index()):
                taak=self.treeView.isExpanded(self.treeModel.index(chi,0))
                if taak:
                    self.treeView.collapse(self.treeModel.index(chi,0))
                    self.treeView.expand(self.treeModel.index(chi,0))
                else:
                    self.treeView.expand(self.treeModel.index(chi,0))
                    self.treeView.collapse(self.treeModel.index(chi,0))
                break

    def collapseAllSlot(self):
        parentItem = self.treeModel.invisibleRootItem()
        self.collapseAllSlotRecurse(parentItem)

    def collapseAllSlotRecurse(self,item):
        for chi in range(item.rowCount()):
            self.treeView.setExpanded(item.child(chi,0).index(),False) 
            self.collapseAllSlotRecurse(item.child(chi,0))




    def findText(self,massFiles=[]):   
        dsp=str(self.AttrAddCombobox.itemData(self.AttrAddCombobox.currentIndex(),QtCore.Qt.DisplayRole).toString())
        usr=str(self.AttrAddCombobox.itemData(self.AttrAddCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        curText=str(self.AttrAddCombobox.currentText())
        attr=curText
        if dsp.lower()==curText.lower() and usr!="":
            attr=usr
        if massFiles:
            findTextLine = massFiles
            attr=""
        else:
            temp=str(self.twoLineEdit.text())
            if not temp and attr: 
                temp="*"
            findTextLine = str(temp)

        if type(findTextLine)!=type([]):
            if attr!="":
                findTextLine=findTextLine.split(".")[0]+"."+attr

        attrValue=str(self.lineEditValueOfAttribute.text())

        print str(findTextLine)
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        #cmds.timer(s=True) 
        tree = []
        listFindedObjects=list(set(cmds.ls(findTextLine,l=True,o=True,r=True)))
        listObjects = cmds.ls(dag=True,l=True,st=True)
        for item in range(0,len(listObjects),2):
            typeObject=listObjects[item+1]
            currentObject=listObjects[item][1:].split('|')
            est="0"
            valueAttr=""
            if listObjects[item] in listFindedObjects:
                est="1"
                if attr:
                    valueAttr=str(cmds.getAttr(listObjects[item]+"."+attr))
                    if attrValue:
                        if re.search("[\|\*|\.]",attrValue):
                            if not re.search(attrValue,valueAttr):
                                est="-1"
                        else:
                            if valueAttr.find(attrValue) == -1:
                                est="-1"
            t=tree
            startwhis=""
            for i in range(len(currentObject)):
                startwhis+="|"+currentObject[i]
                da=-1
                for ii in range(len(t)):
                    if type(t[ii]) == type([]):
                        if currentObject[i] in t[ii][0]:
                            da=ii
                            t=t[ii]
                            break
                if da == -1:
                    if est=="0":
                        for x in listFindedObjects:
                            if x.startswith(startwhis):
                                est="2"
                    elif est=="-1":
                        for x in listFindedObjects:
                            if x.startswith(startwhis):
                                est="-2"
                    t.append([currentObject[i],typeObject,est,valueAttr])
                    t=t[-1]

        self.printItem(parentItem,tree)

            
    def printItem(self, item, part):
        estZachemRaskryvat=False
        for i in range(len(part)):
            if type(part[i]) == type([]):
                itemChild = QtGui.QStandardItem(part[i][0])
                itemChild.setData(part[i][1],QtCore.Qt.UserRole)
                itemChild.setData(part[i][2],QtCore.Qt.UserRole+1)
                itemChild.setData(part[i][3],QtCore.Qt.UserRole+5)
                itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                item.appendRow(itemChild)
                if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                    if part[i][2] == "0" or part[i][2] == "-1":
                        self.treeView.setRowHidden(itemChild.row(),item.index(),True) 

                if part[i][2] != "0":
                    self.treeView.setExpanded(itemChild.index(),True) 
                    estZachemRaskryvat=True

                self.printItem(itemChild,part[i])    
        if not estZachemRaskryvat:
            self.treeView.setExpanded(item.index(),False) 
