import sip
import linecache
import sys
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import cleanup
import ast
import maya.cmds as cmds
cmds.evalDeferred( "import maya.cmds as cmds" )
reload( cleanup )

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )

class cleanupView( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( cleanupView, self ).__init__( parent )
        self.map = {}
        self.backWidget = None
        self.modal = False
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setContentsMargins( 0, 0, 0, 0, )
        self.setLayout( self.mainlayout )
        self.presetWidget = QtGui.QWidget()
        self.presetLayout = QtGui.QHBoxLayout()
        self.presetLayout.setContentsMargins( 0, 0, 0, 0, )
        self.presetWidget.setLayout( self.presetLayout )
        self.mainlayout.addWidget( self.presetWidget )
        self.presetLabel = QtGui.QLabel( "Type:" )
        self.presetLabel.setMaximumWidth( 30 )
        self.presetLayout.addWidget( self.presetLabel )
        self.presetComboBox = QtGui.QComboBox()
        self.presetComboBoxList = QtCore.QStringList()
        self.presetComboBoxList.append( "none" )
        self.preset = { "none":[] }
        self.presetComboBox.addItems( self.presetComboBoxList )
        self.presetComboBox.activated.connect( self.changePreset )
        self.presetLayout.addWidget( self.presetComboBox )
        self.tree = QtGui.QTreeView()
        self.delegate = itemDelegate()
        self.tree.setItemDelegate( self.delegate )
        self.tree.setExpandsOnDoubleClick( False ) 
        self.tree.setAlternatingRowColors( True )
        self.tree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.tree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.tree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.tree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.tree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.tree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.tree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.connect( self.delegate, QtCore.SIGNAL("itemCheckChange(const QModelIndex &)"), self.setChecked )
        self.connect( self.delegate, QtCore.SIGNAL("itemExpanded(const QModelIndex &)"), self.setExpanded )
        self.model = QtGui.QStandardItemModel()
        self.tree.setModel( self.model )
        self.tree.setHeaderHidden( True )
        self.tree.setContextMenuPolicy( QtCore.Qt.CustomContextMenu )
        self.tree.customContextMenuRequested.connect( self.openContextMenu )
        self.mainlayout.addWidget( self.tree )
        self.selectButton = QtGui.QPushButton( "Select" )
        self.selectButton.released.connect( self.selectAction )
        self.mainlayout.addWidget( self.selectButton )
        self.actionWidget = QtGui.QWidget()
        self.actionLayout = QtGui.QHBoxLayout()
        self.actionLayout.setContentsMargins( 0, 0, 0, 0, )
        self.actionWidget.setLayout( self.actionLayout )
        self.mainlayout.addWidget( self.actionWidget )
        self.cancelButton = QtGui.QPushButton( "Back" )
        self.cancelButton.released.connect( self.back )
        self.actionLayout.addWidget( self.cancelButton )
        self.cancelButton = QtGui.QPushButton( "Cancel" )
        self.cancelButton.released.connect( self.cancelSlot )
        self.actionLayout.addWidget( self.cancelButton )
        self.setupButton = QtGui.QPushButton( "Setup" )
        self.setupButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 92, 96, 99 ); }")
        self.setupButton.released.connect( self.applySlot )
        self.actionLayout.addWidget( self.setupButton )
        self.setWindowTitle( "Cleanup settings" )
    
    def back( self ):
        if self.backWidget:
            window = cleanupPreview()
            window.modal = self.modal
            window.preset = str( self.presetComboBox.currentText())
            if self.modal is True:
                self.cancelSlot()
                window.exec_()
            else:
                self.cancelSlot()
                window.show()            
        else:
            self.cancelSlot()
    
    def setExpanded( self, index ):
        boolean = not self.tree.isExpanded( index ) and True or False
        self.tree.setExpanded( index, boolean )
    
    def itemChildsIterator( self, item, enabled=False ):
        count = item.rowCount()
        if count > 0:
            for i in range( 0, count ):
                child = item.child( i )
                if enabled is True:
                    state = str( child.data( QtCore.Qt.UserRole + 1 ).toString())
                    isEnabled = state == "1" and True or False
                else:
                    isEnabled = True
                if child and isEnabled:
                    yield child
                    iterator = self.itemChildsIterator( child, enabled=enabled )
                    for n in iterator:
                        yield n
    
    def openContextMenu( self, position ):
        menu = QtGui.QMenu()
        select = QtGui.QAction( "Select", self )
        select.triggered.connect( self.selectAction )
        menu.addAction( select )
        menu.exec_( self.tree.viewport().mapToGlobal( position ) )
    
    def descendentsItems( self, item, enabled=False ):
        result = []
        generator = self.itemChildsIterator( item, enabled=enabled )
        for child in generator:
            result.append( child )
        return result
    
    def descendentsItems_old( self, item, enabled=False ):
        result = []
        count = item.rowCount()
        if count > 0:
            for r in range( 0, count ):
                child = item.child( r )
                if enabled is True:
                    state = str( child.data( QtCore.Qt.UserRole + 1 ).toString())
                    isEnabled = state == "1" and True or False
                else:
                    isEnabled = True
                if child and child not in result and isEnabled:
                    result.append( child )
                    descendents = self.descendentsItems_old( child, enabled=enabled )
                    for i in range( 0, len( descendents )):
                        result.append( descendents[i] )
        return result
    
    def parentItem( self, item ):
        result = []
        root = self.model.invisibleRootItem()
        parent = item.parent()
        while parent:
            result.append( parent )
            parent = parent.parent()
            if parent == root:
                break
        return result
    
    def setChecked( self, index ):
        selected = self.tree.selectionModel().selectedIndexes()
        if index not in selected:
            self.tree.selectionModel().clear()
            self.tree.selectionModel().select( index, QtGui.QItemSelectionModel.Select )
            selected.append( index )
        if selected:
            state = str( index.data( QtCore.Qt.UserRole + 1 ).toString())
            state = state == "0" and 1 or 0 
            for i in range( 0, len( selected )):
                item = self.model.itemFromIndex( selected[i] )
                item.setData( state, QtCore.Qt.UserRole + 1 )
                self.updateRelativeItems( item )
    
    def selectAction( self ):
        selectionList = self.tree.selectionModel().selectedIndexes()
        result = []
        if selectionList:
            for selected in selectionList:
                name = str( selected.data( QtCore.Qt.UserRole + 2 ).toString())
                name = self.stringToVar( name )
                if type( name ) is dict:
                    keys = name.keys()
                    for key in keys:
                        clname = key.split( " " )[0]
                        if clname not in result:
                            if cmds.objExists( clname ):
                                result.append( clname )
                else:
                    clname = name.split( " " )[0]
                    if clname not in result:
                        if cmds.objExists( clname ):
                            result.append( clname )
        if result:
            print "select", result
            cmds.evalDeferred( "cmds.select(%s)" % result )
        return result
        
    def updateRelativeItems( self, item ):
        state = str( item.data( QtCore.Qt.UserRole + 1 ).toString())
        parent = self.parentItem( item )
        plen = len( parent )
        generator = self.itemChildsIterator( item )
        for child in generator:
            child.setData( state, QtCore.Qt.UserRole + 1 )
        for i in range( 0, plen ):
            pstate = str( parent[i].data( QtCore.Qt.UserRole + 1 ).toString())
            if pstate == "0":
                parent[i].setData( state, QtCore.Qt.UserRole + 1 )
            
    def itemExecute( self, item ):
        generator = self.itemChildsIterator( item, enabled=False )
        rname = str( item.data( QtCore.Qt.DisplayRole ).toString())
        for child in generator:
            name = str( child.data( QtCore.Qt.UserRole + 2 ).toString())
            name = self.stringToVar( name )
            state = str( child.data( QtCore.Qt.UserRole + 1 ).toString())
            if name != "":
                if state == "1":
                    if name not in self.map[rname]:
                        self.map[rname].append( name )
                else:
                    if name in self.map[rname]: 
                        i = self.map[rname].index( name )
                        self.map[rname].pop( i )
        
    def stringToVar( self, var ):
        if var.startswith( "{" ):
            var = ast.literal_eval( var )
        return var
        
    def applySlot( self ):
        root = self.model.invisibleRootItem()
        for r in range( root.rowCount()-1, -1, -1 ):
            child = root.child( r )
            state = str( child.data( QtCore.Qt.UserRole + 1 ).toString())
            name = str( child.data( QtCore.Qt.DisplayRole ).toString())
            name = self.stringToVar( name )
            if state == "1":
                self.itemExecute( child )
            else:
                for i in range( len( self.map[name] )-1, -1, -1 ):
                    self.map[name].pop(i)
        cmds.evalDeferred( "import ui_cleanup;reload(ui_cleanup);ui_cleanup.setup()" )
        self.done( 1 )
    
    def cancelSlot( self ):
        self.done( 0 )
    
    def setPreset( self, name ):
        validIndex = 0
        if name == "":
            name = "none"
        for i in range( 0, self.presetComboBox.count()):
            if self.presetComboBox.itemText( i ) == name:
                validIndex = i
        self.presetComboBox.setCurrentIndex( validIndex )
        self.changePreset()
        
    def changePreset( self ):
        preset = str( self.presetComboBox.currentText())
        if preset in self.preset.keys():
            items = self.preset[ preset ]
            root = self.model.invisibleRootItem()
            for r in range( root.rowCount()-1, -1, -1 ):
                child = root.child( r )
                name = str( child.data( QtCore.Qt.DisplayRole ).toString())
                if name in items:
                    child.setData( 1, QtCore.Qt.UserRole + 1 )
                else:
                    child.setData( 0, QtCore.Qt.UserRole + 1 )
                self.updateRelativeItems( child )
    
    def cleanName( self, data ):
        result = []
        buffer = data.split( " " )
        for part in buffer:
            if cmds.objExists( part ):
                sname = part.split( "|" )[-1]
                sim = cmds.ls( sname )
                if len( sim ) > 1:
                    result.append( part )
                else:
                    result.append( sname )
            else:
                result.append( part )
        return " ".join( result )
    
    def addFolder( self, name="", data=[], category=[] ):
        categoryExists = []
        namesExists = []
        for i in range( 0, self.presetComboBox.count()):
            itemText = str( self.presetComboBox.itemText( i ))
            categoryExists.append( itemText )
            namesExists = namesExists + self.preset[ itemText ]
        if name not in namesExists:
            if category:
                for i in range( 0, len( category )):
                    if category[i] not in categoryExists:
                        self.presetComboBox.addItem( category[i] )
                        self.preset.update( { category[i] : [ name ] } )
                    else:
                        content = self.preset[ category[i] ]
                        content.append( name )
                        self.preset.update( { category[i] : content } )
            root = self.model.invisibleRootItem()
            item = QtGui.QStandardItem( name )
            item.setData( name, QtCore.Qt.DisplayRole )
            for i in range( 0, len( data )):
                if type( data[i] ) is not dict:
                    try:
                        str( data[i] )
                        string = data[i] 
                    except:
                        string = data[i].encode( "ascii", "ignore" )
                    cleanName = self.cleanName( data[i] )
                    child = QtGui.QStandardItem( cleanName )
                    child.setData( cleanName, QtCore.Qt.DisplayRole )
                    child.setData( 0, QtCore.Qt.UserRole + 1 )
                    child.setData( 1, QtCore.Qt.UserRole + 3 )
                    child.setData( data[i], QtCore.Qt.UserRole + 2 )
                    item.setChild( item.rowCount(), child )
                else:
                    keys = data[i].keys()
                    for key in keys:
                        try:
                            string = str( key )
                        except:
                            string = key.encode( "ascii", "ignore" )
                        cleanName = self.cleanName( string )
                        child = QtGui.QStandardItem( cleanName )
                        child.setData( cleanName, QtCore.Qt.DisplayRole )
                        child.setData( 0, QtCore.Qt.UserRole + 1 )
                        child.setData( 1, QtCore.Qt.UserRole + 3 )
                        child.setData( str( data[i] ), QtCore.Qt.UserRole + 2 )
                        item.setChild( item.rowCount(), child )
                        descedents = data[i][key]
                        if type( descedents ) is str:
                            descedents = [ descedents ]
                        for descedent in descedents:
                            try:
                                str( descedent )
                                string = descedent
                            except:
                                string = descedent.encode( "ascii", "ignore" )
                            cleanName = self.cleanName( string )
                            nchild = QtGui.QStandardItem( cleanName )
                            nchild.setData( cleanName, QtCore.Qt.DisplayRole )
                            nchild.setData( 0, QtCore.Qt.UserRole + 1 )
                            nchild.setData( 0, QtCore.Qt.UserRole + 3 )
                            nchild.setData( string, QtCore.Qt.UserRole + 2 )
                            child.setChild( child.rowCount(), nchild )
            item.setData( 0, QtCore.Qt.UserRole + 1 )
            root.setChild( root.rowCount(), item )
            self.map.update( { name:data } )
        else:
            print "Please specify another name."

class itemDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        #checkbox = QtGui.QCheckBox()
        editor.setMinimum(0)
        editor.setMaximum(100)
        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)
        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        if text != "":
            painter.save()
            painter.setRenderHint(QtGui.QPainter.Antialiasing)
            gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
            col = QtGui.QColor(index.model().data(index,QtCore.Qt.BackgroundColorRole))
            if col.name() == "#000000":
                col = option.palette.window().color()
            gradient.setColorAt(0.05, option.palette.base().color())
            gradient.setColorAt(0.051, col)
            gradient.setColorAt(0.95, col)
            gradient.setColorAt(0.951, option.palette.base().color())
            brush = QtGui.QBrush(gradient)
            painter.fillRect(option.rect,brush)
            painter.drawText( option.rect.x()+20,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
            checkable = index.model().data(index,QtCore.Qt.UserRole+3).toString()
            if checkable != "0":
                brush = QtGui.QBrush(QtGui.QColor(30,30,30))
                painter.setPen(QtCore.Qt.NoPen)
                painter.setBrush(brush)
                painter.drawEllipse( option.rect.x()+0.205*option.rect.height(), option.rect.y()+0.205*option.rect.height(), 0.5*option.rect.height(), 0.5*option.rect.height())
                checkState = index.model().data(index,QtCore.Qt.UserRole+1).toString()
                if checkState == "1":
                    brush = QtGui.QBrush(QtGui.QColor(200,200,200))
                    painter.setPen(QtCore.Qt.NoPen)
                    painter.setBrush(brush)
                    painter.drawEllipse( option.rect.x()+0.305*option.rect.height(), option.rect.y()+0.305*option.rect.height(), 0.3*option.rect.height(), 0.3*option.rect.height())
            if option.state & QtGui.QStyle.State_Selected:
                colr = QtGui.QBrush(option.palette.highlight())
                ccc = QtGui.QColor(colr.color())
                ccc.setAlphaF(.2)
                colr.setColor(ccc)
                painter.fillRect(option.rect, colr )
            painter.restore(); 

    def editorEvent( self, event, model, option, index ):
        result = False
        if event.type() == QtCore.QEvent.MouseButtonPress:
            mouse = QtGui.QMouseEvent( event )
            rect = QtCore.QRect( option.rect.x()+0.205*option.rect.height(), option.rect.y()+0.205*option.rect.height(), 0.5*option.rect.height(), 0.5*option.rect.height() )
            if rect.contains( mouse.x(), mouse.y()):
                result = True
                self.emit(QtCore.SIGNAL("itemCheckChange(const QModelIndex &)"), index )
        elif event.type() == QtCore.QEvent.MouseButtonDblClick:
            mouse = QtGui.QMouseEvent( event )
            rect = QtCore.QRect( option.rect.x()+0.205*option.rect.height(), option.rect.y()+0.205*option.rect.height(), 0.5*option.rect.height(), 0.5*option.rect.height() )
            if not rect.contains( mouse.x(), mouse.y()):
                result = True
                self.emit(QtCore.SIGNAL("itemExpanded(const QModelIndex &)"), index )
        return result
    
    def getRoot( self, item ):
        result = []
        parent = item.parent()
        while parent:
            result.append( parent )
            parent = parent.parent()
        return result 

class cleanupPreview( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( cleanupPreview, self ).__init__( parent )
        global unusedNodes
        global transformTranslations
        global slimAttachements
        global nonManifoldMeshes
        global nonManifoldVertex
        global nonManifoldNormals 
        global setupAttributes
        global unusedHistory
        global nonManifoldNames
        global nonManifoldHierarchy
        global setupSlimShaders
        global setupMayaShaders
        global unusedUv
        global notCompiledShaders
        global lockedCameras
        global unusedSlimPalettes
        global unusedSlimMaterials
        global partedReferences
        global unusedMtorPartition
        global referenceConnections
        global partedProxyManager
        global partedNamespaces
        self.modal = True
        self.preset = ""
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setContentsMargins( 0, 0, 0, 0, )
        self.setLayout( self.mainlayout )
        self.previewGroupBox = QtGui.QGroupBox( "" )
        self.previewLayout = QtGui.QVBoxLayout()
        self.previewGroupBox.setLayout( self.previewLayout )
        self.mainlayout.addWidget( self.previewGroupBox )
        self.info = ""
        lenght = len( unusedNodes )
        if lenght > 0:
            self.info = self.info + ( "\nUnused nodes: %s ( delete )" % lenght )
        lenght = len( unusedHistory )
        if lenght > 0:
            self.info = self.info + ( "\nUnused history: %s ( delete )" % lenght )
        lenght = len( transformTranslations )
        if lenght > 0:
            self.info = self.info + ( "\nFreeze translation: %s ( freeze translates )" % lenght )
        lenght = len( unusedUv )
        if lenght > 0:
            self.info = self.info + ( "\nUnused uv: %s ( delete )" % lenght )
        lenght = len( slimAttachements )
        if lenght > 0:
            self.info = self.info + ( "\nAttached not existing slim shader: %s ( manual )" % lenght )
        lenght = len( nonManifoldMeshes )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold geometry: %s ( manual )" % lenght )
        lenght = len( nonManifoldVertex )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold vertices: %s ( delete )" % lenght )
        lenght = len( nonManifoldNormals )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold normals: %s ( conform )" % lenght )
        lenght = len( setupAttributes )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold attributes: %s ( setup attributes )" % lenght )
        lenght = len( nonManifoldNames )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold names: %s ( manual )" % lenght )
        lenght = len( nonManifoldHierarchy )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold hierarchy: %s ( repair hierarchy )" % lenght )
        lenght = len( setupSlimShaders )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold slim shaders: %s ( setup attributes )" % lenght )
        lenght = len( setupMayaShaders )
        if lenght > 0:
            self.info = self.info + ( "\nNon-manifold maya shaders: %s ( delete )" % lenght )
        lenght = len( notCompiledShaders )
        if lenght > 0:
            self.info = self.info + ( "\nNot compiled slim shaders: %s ( compile )" % lenght )
        lenght = len( lockedCameras )
        if lenght > 0:
            self.info = self.info + ( "\nLocked cameras: %s ( unlock )" % lenght )
        lenght = len( unusedSlimMaterials )
        if lenght > 0:
            self.info = self.info + ( "\nUnused slim nodes: %s ( delete )" % lenght )
        lenght = len( unusedSlimPalettes )
        if lenght > 0:
            self.info = self.info + ( "\nUnused slim palettes: %s ( delete )" % lenght )
        lenght = len( partedReferences )
        if lenght > 0:
            self.info = self.info + ( "\nParted references: %s ( manual )" % lenght )
        lenght = len( unusedMtorPartition )
        if lenght > 0:
            self.info = self.info + ( "\nUnused mtor partition: %s ( delete )" % lenght )
        lenght = len( referenceConnections )
        if lenght > 0:
            self.info = self.info + ( "\nReference connected geometry: %s ( manual )" % lenght )
            
        lenght = len( partedProxyManager )
        if lenght > 0:
            self.info = self.info + ( "\nParted proxy: %s ( manual )" % lenght )
        lenght = len( partedNamespaces )
        if lenght > 0:
            self.info = self.info + ( "\nParted namespaces: %s ( manual )" % lenght )
        self.label = QtGui.QLabel( self.info )
        self.previewLayout.addWidget( self.label )
        self.setupButton = QtGui.QPushButton( "Cleanup" )
        self.previewLayout.addWidget( self.setupButton )
        self.setupButton.released.connect( self.setupSlot )
        self.settingsButton = QtGui.QPushButton( "Settings" )
        self.previewLayout.addWidget( self.settingsButton )
        self.settingsButton.released.connect( self.settingsSlot )
        self.cancelButton = QtGui.QPushButton( "Cancel" )
        self.previewLayout.addWidget( self.cancelButton )
        self.cancelButton.released.connect( self.cancelSlot )
        self.setWindowTitle( "Cleanup" )
        
    def setupSlot( self ):
        self.done(1)
        cmds.evalDeferred( "import ui_cleanup;reload(ui_cleanup);ui_cleanup.setup()" )
        
    def settingsSlot( self ):
        global unusedNodes
        global transformTranslations
        global slimAttachements
        global nonManifoldMeshes
        global nonManifoldVertex
        global nonManifoldNormals
        global setupAttributes
        global unusedHistory
        global nonManifoldNames
        global nonManifoldHierarchy
        global setupSlimShaders
        global setupMayaShaders
        global unusedUv
        global notCompiledShaders
        global lockedCameras
        global unusedSlimPalettes
        global unusedSlimMaterials
        global partedReferences
        global unusedMtorPartition
        global referenceConnections
        global partedProxyManager
        global partedNamespaces  
        cleanup = cleanupView()
        cleanup.backWidget = self
        cleanup.modal = self.modal
        if unusedNodes:
            cleanup.addFolder( name="Unused nodes: " + str( len( unusedNodes )) , data=unusedNodes, category=[ "rigging", "texturing", "modeling", "full" ] )
        if unusedHistory:
            cleanup.addFolder( name="Unused history: " + str( len( unusedHistory )) , data=unusedHistory, category=[ "rigging", "texturing", "modeling", "full" ] )
        if transformTranslations:
            cleanup.addFolder( name="Freeze translation: " + str( len( transformTranslations )), data=transformTranslations, category=[ "modeling", "rigging", "full" ] )
        if unusedUv:
            cleanup.addFolder( name="Unused uv: " + str( len( unusedUv )) , data=unusedUv, category=[ "texturing", "modeling", "full" ] )
        if slimAttachements:
            cleanup.addFolder( name="Attached not existing slim shader: " + str( len( slimAttachements )), data=slimAttachements, category=[ "texturing", "full" ] )
        if nonManifoldMeshes:
            cleanup.addFolder( name="Non-manifold geometry: " + str( len( nonManifoldMeshes )), data=nonManifoldMeshes, category=[ "modeling", "full" ] )
        if nonManifoldVertex:
            cleanup.addFolder( name="Non-manifold vertices (Non-skinned geometry only): " + str( len( nonManifoldVertex )), data=nonManifoldVertex, category=[] )
        if nonManifoldNormals:
            cleanup.addFolder( name="Non-manifold normals: " + str( len( nonManifoldNormals )), data=nonManifoldNormals, category=[ "modeling", "full" ] )
        if setupAttributes:
            cleanup.addFolder( name="Non-manifold attributes: " + str( len( setupAttributes )), data=setupAttributes, category=[ "rigging", "texturing", "modeling", "full" ] )
        if nonManifoldNames:
            cleanup.addFolder( name="Non-manifold names: " + str( len( nonManifoldNames )), data=nonManifoldNames, category=[ "rigging", "texturing", "modeling", "full" ] )
        if nonManifoldHierarchy:
            cleanup.addFolder( name="Non-manifold hierarchy: " + str( len( nonManifoldHierarchy )), data=nonManifoldHierarchy, category=[ "rigging", "texturing", "modeling", "full" ] )
        if setupSlimShaders:
            cleanup.addFolder( name="Non-manifold slim shaders: " + str( len( setupSlimShaders )), data=setupSlimShaders, category=[ "texturing", "full" ] )
        if setupMayaShaders:
            cleanup.addFolder( name="Non-manifold maya shaders: " + str( len( setupMayaShaders )), data=setupMayaShaders, category=[ "texturing", "full" ] )
        if notCompiledShaders:
            cleanup.addFolder( name="Not compiled slim shaders: " + str( len( notCompiledShaders )), data=notCompiledShaders, category=[ "texturing", "full" ] )
        if lockedCameras:
            cleanup.addFolder( name="Locked cameras: " + str( len( lockedCameras )), data=lockedCameras, category=[ "full" ] )
        if unusedSlimMaterials:
            cleanup.addFolder( name="Unused slim nodes: " + str( len( unusedSlimMaterials )), data=unusedSlimMaterials, category=[ "texturing", "full" ] )
        if unusedSlimPalettes:
            cleanup.addFolder( name="Unused slim palettes: " + str( len( unusedSlimPalettes )), data=unusedSlimPalettes, category=[ "texturing", "full" ] )
        if partedReferences:
            cleanup.addFolder( name="Parted references: " + str( len( partedReferences )), data=partedReferences, category=[ "full" ] )
        if unusedMtorPartition:
            cleanup.addFolder( name="Unused mtor partition: " + str( len( unusedMtorPartition )), data=unusedMtorPartition, category=[ "full" ] )
        if referenceConnections:
            cleanup.addFolder( name="Reference connected geometry: " + str( len( referenceConnections )), data=referenceConnections, category=[ "full" ] )
        if partedProxyManager:
            cleanup.addFolder( name="Parted proxy: " + str( len( partedProxyManager )), data=partedProxyManager, category=[ "full" ] )
        if partedNamespaces:
            cleanup.addFolder( name="Parted namespaces: " + str( len( partedNamespaces )), data=partedNamespaces, category=[ "full" ] )
        self.done(2)
        if self.preset != "":
            cleanup.setPreset( self.preset )
        if self.modal is True:
            cleanup.exec_()
        else:
            cleanup.show()

    def cancelSlot( self ):
        self.done(3)

def exception():
    print "\nEXPECTED ERROR {"
    extype, exobj, traceback = sys.exc_info()
    lineno = traceback.tb_lineno
    nfile = traceback.tb_frame
    filename = nfile.f_code.co_filename
    linecache.checkcache( filename )
    line = linecache.getline( filename, lineno, nfile.f_globals )
    linestp = line.strip()
    linestp = linestp and linestp or "<module>"
    result = "# Error: {3}# Traceback (most recent call last):\n# \tFile {0}, line {1}, in {2}\n# {4}: {3}".format( filename, lineno, linestp, exobj, extype.__name__ )
    print result
    print "}"
    return result
     
def main( modal=True, batch=False, query=False, preset="" ):
    global unusedNodes
    global transformTranslations
    global slimAttachements
    global nonManifoldMeshes
    global nonManifoldVertex
    global nonManifoldNormals
    global setupAttributes
    global unusedHistory
    global nonManifoldNames
    global nonManifoldHierarchy
    global setupSlimShaders
    global setupMayaShaders
    global unusedUv
    global notCompiledShaders
    global lockedCameras
    global unusedSlimPalettes
    global unusedSlimMaterials
    global partedReferences
    global unusedMtorPartition
    global referenceConnections
    global partedProxyManager
    global partedNamespaces 
    unusedNodes = []
    transformTranslations = []
    slimAttachements = []
    nonManifoldMeshes = []
    nonManifoldVertex = []
    nonManifoldNormals = []
    setupAttributes = []
    unusedHistory = []
    nonManifoldNames = []
    nonManifoldHierarchy = []
    setupSlimShaders = []
    setupMayaShaders = []
    unusedUv = []
    notCompiledShaders = []
    lockedCameras = []
    unusedSlimPalettes = []
    unusedSlimMaterials = []
    partedReferences = []
    unusedMtorPartition = []
    referenceConnections = []
    partedProxyManager = []
    partedNamespaces = []
    i = 0
    maxi = 23
    debug = query
    print "cleanup settings: \"%s\"" % preset
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check unused nodes" % ( i, maxi )
        if preset != "" and preset in [ "rigging", "texturing", "modeling", "full" ] or preset == "":
            unusedNodes = cleanup.checkUnusedNodes( query=True, debug=debug )
        else:
            unusedNodes = []
            print "pass"
    except:
        exception()
        unusedNodes = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check translates" % ( i, maxi )
        if preset != "" and preset in [ "modeling", "rigging", "full" ] or preset == "":
            transformTranslations = cleanup.checkTransformTranslations( query=True, debug=debug )
        else:
            transformTranslations = []
            print "pass"
    except:
        exception()
        transformTranslations = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check unused uv" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "modeling", "full" ] or preset == "":
            unusedUv = cleanup.checkUnusedUv( query=True, debug=debug )
        else:
            unusedUv = []
            print "pass"
    except:
        exception()
        unusedUv = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check slim attachements" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            slimAttachements = cleanup.checkSlimAttachements( debug=debug )
        else:
            slimAttachements = []
            print "pass"
    except:
        exception()
        slimAttachements = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check non-manifold geometry" % ( i, maxi )
        if preset != "" and preset in [ "modeling", "full" ] or preset == "":
            nonManifoldMeshes = cleanup.checkNonManifoldMeshes( debug=debug )
        else:
            nonManifoldMeshes = []
            print "pass"
    except:
        exception()
        nonManifoldMeshes = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check non-manifold vertices" % ( i, maxi )
        if preset != "" and preset in [] or preset == "":
            nonManifoldVertex = cleanup.checkNonManifoldVertex( query=True, debug=debug, ignoreSkinned=True )
        else:
            nonManifoldVertex = []
            print "pass"
    except:
        exception()
        nonManifoldVertex = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check non-manifold normals" % ( i, maxi )
        if preset != "" and preset in [ "modeling", "full" ] or preset == "":
            nonManifoldNormals = cleanup.checkNonManifoldNormals( query=True, debug=debug )
        else:
            nonManifoldNormals = []
            print "pass"
    except:
        exception()
        nonManifoldNormals = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check non-manifold attributes" % ( i, maxi )
        if preset != "" and preset in [ "rigging", "texturing", "modeling", "full" ] or preset == "":
            setupAttributes = cleanup.checkAttributes( query=True, debug=debug )
        else:
            setupAttributes = []
            print "pass"
    except:
        exception()
        setupAttributes = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check history" % ( i, maxi )
        if preset != "" and preset in [ "rigging", "texturing", "modeling", "full" ] or preset == "":
            unusedHistory = cleanup.checkHistory( query=True, debug=debug )
        else:
            unusedHistory = []
            print "pass"
    except:
        exception()
        unusedHistory = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check names" % ( i, maxi )
        if preset != "" and preset in [ "rigging", "texturing", "modeling", "full" ] or preset == "":
            nonManifoldNames = cleanup.checkUniqueNames( query=True, debug=debug )
        else:
            nonManifoldNames = []
            print "pass"
    except:
        exception()
        nonManifoldNames = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check hierarchy" % ( i, maxi )
        if preset != "" and preset in [ "rigging", "texturing", "modeling", "full" ] or preset == "":
            nonManifoldHierarchy = cleanup.checkHierarchy( query=True, debug=debug )
        else:
            nonManifoldHierarchy = []
            print "pass"
    except:
        exception()
        nonManifoldHierarchy = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check slim shaders" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            setupSlimShaders = cleanup.checkSlimShaders( query=True, debug=debug )
        else:
            setupSlimShaders = []
            print "pass"
    except:
        exception()
        setupSlimShaders = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check maya shaders" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            setupMayaShaders = cleanup.checkMayaShaders( query=True, debug=debug )
        else:
            setupMayaShaders = []
            print "pass"
    except:
        exception()
        setupMayaShaders = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)
    try:
        i = i + 1
        print "\n(%s/%s) - check not compiled slim shaders" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            notCompiledShaders = cleanup.checkCompileSlim( query=True, debug=debug )
        else:
            notCompiledShaders = []
            print "pass"
    except:
        exception()
        notCompiledShaders = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)    
    try:
        i = i + 1
        print "\n(%s/%s) - check locked cameras" % ( i, maxi )
        if preset != "" and preset in [ "full" ] or preset == "":
            lockedCameras = cleanup.checkNonManifoldCameras( query=True, debug=debug )
        else:
            lockedCameras = []
            print "pass"
    except:
        exception()
        lockedCameras = []
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check unused slim nodes" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            unusedSlimMaterials = cleanup.checkUnusedSlimMaterials( query=True, debug=debug )
        else:
            unusedSlimMaterials = []
            print "pass"
    except:
        exception()
        unusedSlimMaterials = []  
    print "read in %s sec" % cmds.timer(endTimer=True) 
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check unused slim palettes" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            unusedSlimPalettes = cleanup.checkUnusedSlimPalettes( query=True, debug=debug )
        else:
            unusedSlimPalettes = []
            print "pass"
    except:
        exception()
        unusedSlimPalettes = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check parted references" % ( i, maxi )
        if preset != "" and preset in [ "texturing", "full" ] or preset == "":
            partedReferences = cleanup.checkReferenceParts( query=True, debug=debug )
        else:
            partedReferences = []
            print "pass"
    except:
        exception()
        partedReferences = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check mtor partition" % ( i, maxi )
        if preset != "" and preset in [ "full" ] or preset == "":
            unusedMtorPartition = cleanup.checkPartitions( query=True, debug=False )
        else:
            unusedMtorPartition = []
            print "pass"
    except:
        exception()
        unusedMtorPartition = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check reference connections" % ( i, maxi )
        if preset != "" and preset in [ "full" ] or preset == "":
            referenceConnections = cleanup.checkReferenceConnections( query=True, debug=False )
        else:
            referenceConnections = []
            print "pass"
    except:
        exception()
        referenceConnections = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check parted proxy" % ( i, maxi )
        if preset != "" and preset in [ "full" ] or preset == "":
            partedProxyManager = cleanup.checkProxies( query=True, debug=False )
        else:
            partedProxyManager = []
            print "pass"
    except:
        exception()
        partedProxyManager = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    cmds.timer(startTimer=True)  
    try:
        i = i + 1
        print "\n(%s/%s) - check parted namespaces" % ( i, maxi )
        if preset != "" and preset in [ "full" ] or preset == "":
            partedNamespaces = cleanup.checkReferenceNamespace( query=True, debug=False )
        else:
            partedNamespaces = []
            print "pass"
    except:
        exception()
        partedNamespaces = []  
    print "read in %s sec" % cmds.timer(endTimer=True)
    i = i + 1    
    print "\n(%s/%s) - initialization" % ( i, maxi )
    if batch is False:
        window = cleanupPreview()
        window.modal = modal
        window.preset = preset
        if modal is True:
            window.exec_()
        else:
            window.show()
    else:
        if query is False:
            cmds.evalDeferred( "import ui_cleanup;reload(ui_cleanup);ui_cleanup.setup()" )
    return True

class cleanupPresetSettings( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( cleanupPresetSettings, self ).__init__( parent )
        self.isLoad=False
        self.modal = True
        self.preset = ""
        self.mainlayout = QtGui.QVBoxLayout()
        #self.mainlayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.mainlayout.setContentsMargins( 0, 0, 0, 0, )
        self.setLayout( self.mainlayout )
        
    def load( self ):
        
        self.presetComboBox = QtGui.QComboBox()
        
        self.presetComboBoxList = QtCore.QStringList()
        self.presetComboBoxList.append( "none" )
        self.presetComboBoxList.append( "modeling" )
        self.presetComboBoxList.append( "texturing" )
        self.presetComboBoxList.append( "rigging" )
        self.presetComboBoxList.append( "tmplate" )
        self.presetComboBoxList.append( "full" )
        self.presetComboBox.addItems( self.presetComboBoxList )
        self.presetComboBox.activated.connect( self.changePreset )
        self.mainlayout.addWidget( self.presetComboBox )
        
        self.nodesLabel = QtGui.QGroupBox( "Nodes:" )
        self.nodesLabel.setFlat( True )
        self.nodesLabel.toggled.connect( lambda: self.updateCheckstate( self.nodesLabel ))
        self.nodesLabel.setCheckable( True )
        self.nodesLabel.setChecked( False )
        self.nodesLayout = QtGui.QVBoxLayout()
        self.nodesLayout.setContentsMargins( 2, 2, 2, 2, )
        self.nodesLabel.setLayout( self.nodesLayout )
        self.mainlayout.addWidget( self.nodesLabel )
        self.unusedNodesCheckbox = QtGui.QCheckBox( "Unused nodes" )
        self.nodesLayout.addWidget( self.unusedNodesCheckbox )
        self.unusedNodesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.unusedHistoryCheckbox = QtGui.QCheckBox( "Unused history" )
        self.nodesLayout.addWidget( self.unusedHistoryCheckbox ) 
        self.unusedHistoryCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        
        self.hierarchyLabel = QtGui.QGroupBox( "Hierarchy:" )
        self.hierarchyLabel.setFlat( True )
        self.hierarchyLabel.toggled.connect( lambda: self.updateCheckstate( self.hierarchyLabel ))
        self.hierarchyLabel.setCheckable( True )
        self.hierarchyLabel.setChecked( False )
        self.hierarchyLayout = QtGui.QVBoxLayout()
        self.hierarchyLayout.setContentsMargins( 2, 2, 2, 2, )
        self.hierarchyLabel.setLayout( self.hierarchyLayout )
        self.mainlayout.addWidget( self.hierarchyLabel )
        self.transformTranslationsCheckbox = QtGui.QCheckBox( "Freeze translation" )
        self.hierarchyLayout.addWidget( self.transformTranslationsCheckbox )
        self.transformTranslationsCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.nonManifoldNamesCheckbox = QtGui.QCheckBox( "Non-manifold names" )
        self.hierarchyLayout.addWidget( self.nonManifoldNamesCheckbox )
        self.nonManifoldNamesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.nonManifoldHierarchyCheckbox = QtGui.QCheckBox( "Non-manifold hierarchy" )
        self.hierarchyLayout.addWidget( self.nonManifoldHierarchyCheckbox )
        self.nonManifoldHierarchyCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.lockedCamerasCheckbox = QtGui.QCheckBox( "Locked cameras" )
        self.hierarchyLayout.addWidget( self.lockedCamerasCheckbox )
        self.lockedCamerasCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        
        self.texturingLabel = QtGui.QGroupBox( "Texturing:" )
        self.texturingLabel.setFlat( True )
        self.texturingLabel.toggled.connect( lambda: self.updateCheckstate( self.texturingLabel ))
        self.texturingLabel.setCheckable( True )
        self.texturingLabel.setChecked( False )
        self.texturingLayout = QtGui.QVBoxLayout()
        self.texturingLayout.setContentsMargins( 2, 2, 2, 2, )
        self.texturingLabel.setLayout( self.texturingLayout )
        self.mainlayout.addWidget( self.texturingLabel )
        self.unusedUvCheckbox = QtGui.QCheckBox( "Unused uv" )
        self.texturingLayout.addWidget( self.unusedUvCheckbox )
        self.unusedUvCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.setupMayaShadersCheckbox = QtGui.QCheckBox( "Non-manifold maya shaders" )
        self.texturingLayout.addWidget( self.setupMayaShadersCheckbox )
        self.setupMayaShadersCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.setupAttributesCheckbox = QtGui.QCheckBox( "Non-manifold attributes" )
        self.texturingLayout.addWidget( self.setupAttributesCheckbox )
        self.setupAttributesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        
        self.modelingLabel = QtGui.QGroupBox( "Modeling:" )
        self.modelingLabel.setFlat( True )
        self.modelingLabel.toggled.connect( lambda: self.updateCheckstate( self.modelingLabel ))
        self.modelingLabel.setCheckable( True )
        self.modelingLabel.setChecked( False )
        self.modelingLayout = QtGui.QVBoxLayout()
        self.modelingLayout.setContentsMargins( 2, 2, 2, 2, )
        self.modelingLabel.setLayout( self.modelingLayout )
        self.mainlayout.addWidget( self.modelingLabel )
        self.nonManifoldMeshesCheckbox = QtGui.QCheckBox( "Non-manifold geometry" )
        self.modelingLayout.addWidget( self.nonManifoldMeshesCheckbox )
        self.nonManifoldMeshesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.nonManifoldVertexCheckbox = QtGui.QCheckBox( "Non-manifold vertices" )
        self.modelingLayout.addWidget( self.nonManifoldVertexCheckbox )
        self.nonManifoldVertexCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.nonManifoldNormalsCheckbox = QtGui.QCheckBox( "Non-manifold normals" )
        self.modelingLayout.addWidget( self.nonManifoldNormalsCheckbox )
        self.nonManifoldNormalsCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        
        self.slimLabel = QtGui.QGroupBox( "Slim:" )
        self.slimLabel.setFlat( True )
        self.slimLabel.toggled.connect( lambda: self.updateCheckstate( self.slimLabel ))
        self.slimLabel.setCheckable( True )
        self.slimLabel.setChecked( False )
        self.slimLayout = QtGui.QVBoxLayout()
        self.slimLayout.setContentsMargins( 2, 2, 2, 2, )
        self.slimLabel.setLayout( self.slimLayout )
        self.mainlayout.addWidget( self.slimLabel )
        self.slimAttachementsCheckbox = QtGui.QCheckBox( "Attached not existing slim shader" )
        self.slimLayout.addWidget( self.slimAttachementsCheckbox )
        self.slimAttachementsCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.setupSlimShadersCheckbox = QtGui.QCheckBox( "Non-manifold slim shaders" )
        self.slimLayout.addWidget( self.setupSlimShadersCheckbox )
        self.setupSlimShadersCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.notCompiledShadersCheckbox = QtGui.QCheckBox( "Not compiled slim shaders" )
        self.slimLayout.addWidget( self.notCompiledShadersCheckbox )
        self.notCompiledShadersCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.unusedSlimMaterialsCheckbox = QtGui.QCheckBox( "Unused slim nodes" )
        self.slimLayout.addWidget( self.unusedSlimMaterialsCheckbox )
        self.unusedSlimMaterialsCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.unusedSlimPalettesCheckbox = QtGui.QCheckBox( "Unused slim palettes" )
        self.slimLayout.addWidget( self.unusedSlimPalettesCheckbox )
        self.unusedSlimPalettesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        
        self.referenceLabel = QtGui.QGroupBox( "Reference:" )
        self.referenceLabel.setFlat( True )
        self.referenceLabel.toggled.connect( lambda: self.updateCheckstate( self.referenceLabel ))
        self.referenceLabel.setCheckable( True )
        self.referenceLabel.setChecked( False )
        self.referenceLayout = QtGui.QVBoxLayout()
        self.referenceLayout.setContentsMargins( 2, 2, 2, 2, )
        self.referenceLabel.setLayout( self.referenceLayout )
        self.mainlayout.addWidget( self.referenceLabel )
        self.partedReferencesCheckbox = QtGui.QCheckBox( "Parted references" )
        self.referenceLayout.addWidget( self.partedReferencesCheckbox )
        self.partedReferencesCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.unusedMtorPartitionCheckbox = QtGui.QCheckBox( "Unused mtor partion" )
        self.referenceLayout.addWidget( self.unusedMtorPartitionCheckbox )
        self.unusedMtorPartitionCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.unusedReferenceConnectionsCheckbox = QtGui.QCheckBox( "Reference connected geometry" )
        self.referenceLayout.addWidget( self.unusedReferenceConnectionsCheckbox )
        self.unusedReferenceConnectionsCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.partedProxyCheckbox = QtGui.QCheckBox( "Reference parted proxy" )
        self.referenceLayout.addWidget( self.partedProxyCheckbox )
        self.partedProxyCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.partedNamespaceCheckbox = QtGui.QCheckBox( "Reference parted namespaces" )
        self.referenceLayout.addWidget( self.partedNamespaceCheckbox )
        self.partedNamespaceCheckbox.setStyleSheet("QCheckBox{ padding-left: 15px; }")
        self.cleanupButton = QtGui.QPushButton( "Cleanup" )
        self.cleanupButton.released.connect( self.apply )
        self.mainlayout.addWidget( self.cleanupButton )
        self.mainlayout.addStretch( 10 )
        self.isLoad = True 
        
    def changePreset( self ):
        preset = str( self.presetComboBox.currentText())
        if preset == "none":
            self.nodesLabel.setChecked( False )
            self.hierarchyLabel.setChecked( False )
            self.modelingLabel.setChecked( False )
            self.texturingLabel.setChecked( False )
            self.slimLabel.setChecked( False )
            self.referenceLabel.setChecked( False )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
        elif preset == "modeling":
            self.nodesLabel.setChecked( True )
            self.hierarchyLabel.setChecked( True )
            self.modelingLabel.setChecked( True )
            self.texturingLabel.setChecked( False )
            self.slimLabel.setChecked( False )
            self.referenceLabel.setChecked( False )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
        elif preset == "texturing":
            self.nodesLabel.setChecked( True )
            self.hierarchyLabel.setChecked( False )
            self.modelingLabel.setChecked( False )
            self.texturingLabel.setChecked( True )
            self.slimLabel.setChecked( True )
            self.referenceLabel.setChecked( False )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
        elif preset == "rigging":
            self.nodesLabel.setChecked( True )
            self.hierarchyLabel.setChecked( False )
            self.modelingLabel.setChecked( False )
            self.texturingLabel.setChecked( False )
            self.slimLabel.setChecked( False )
            self.referenceLabel.setChecked( False )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
        elif preset == "full":
            self.nodesLabel.setChecked( True )
            self.hierarchyLabel.setChecked( True )
            self.modelingLabel.setChecked( True )
            self.texturingLabel.setChecked( True )
            self.slimLabel.setChecked( True )
            self.referenceLabel.setChecked( True )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
        elif preset == "tmplate":
            self.nodesLabel.setChecked( True )
            self.hierarchyLabel.setChecked( True )
            self.modelingLabel.setChecked( False )
            self.texturingLabel.setChecked( False )
            self.slimLabel.setChecked( False )
            self.referenceLabel.setChecked( True )
            self.updateCheckstate( self.nodesLabel )
            self.updateCheckstate( self.hierarchyLabel )
            self.updateCheckstate( self.modelingLabel )
            self.updateCheckstate( self.texturingLabel )
            self.updateCheckstate( self.slimLabel )
            self.updateCheckstate( self.referenceLabel )
            self.transformTranslationsCheckbox.setChecked(0)
            self.nonManifoldNamesCheckbox.setChecked(0)
            self.nonManifoldHierarchyCheckbox.setChecked(0)
        
    def updateCheckstate( self, groupBox ):
        boolean = groupBox.isChecked()
        boolean = boolean is True and -1 or 0
        layout = groupBox.layout()
        if layout:
            count = layout.count()
            for i in range( 0, count ):
                layout.itemAt(i).widget().setCheckState( boolean )
        
    def apply( self ):
        global unusedNodes
        global transformTranslations
        global slimAttachements
        global nonManifoldMeshes
        global nonManifoldVertex
        global nonManifoldNormals
        global setupAttributes
        global unusedHistory
        global nonManifoldNames
        global nonManifoldHierarchy
        global setupSlimShaders
        global setupMayaShaders
        global unusedUv
        global notCompiledShaders
        global lockedCameras
        global unusedSlimPalettes
        global unusedSlimMaterials
        global partedReferences
        global unusedMtorPartition
        global referenceConnections
        global partedProxyManager
        global partedNamespaces
        unusedNodes = []
        transformTranslations = []
        slimAttachements = []
        nonManifoldMeshes = []
        nonManifoldVertex = []
        nonManifoldNormals = []
        setupAttributes = []
        unusedHistory = []
        nonManifoldNames = []
        nonManifoldHierarchy = []
        setupSlimShaders = []
        setupMayaShaders = []
        unusedUv = []
        notCompiledShaders = []
        lockedCameras = []
        unusedSlimPalettes = []
        unusedSlimMaterials = []
        partedReferences = []
        unusedMtorPartition = []
        referenceConnections = []
        partedProxyManager = []
        partedNamespaces = []
        i = 0
        maxi = 23
        if self.unusedNodesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check unused nodes" % ( i, maxi )
                unusedNodes = cleanup.checkUnusedNodes( query=True, debug=False )
            except:
                exception()
                unusedNodes = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            unusedNodes = []
            print "pass"
        if self.transformTranslationsCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check translates" % ( i, maxi )
                transformTranslations = cleanup.checkTransformTranslations( query=True, debug=False )
            except:
                exception()
                transformTranslations = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            transformTranslations = []
            print "pass"
        if self.unusedUvCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check unused uv" % ( i, maxi )
                unusedUv = cleanup.checkUnusedUv( query=True, debug=False )
            except:
                exception()
                unusedUv = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            unusedUv = []
            print "pass"
        if self.slimAttachementsCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check slim attachements" % ( i, maxi )
                slimAttachements = cleanup.checkSlimAttachements( debug=False )
            except:
                exception()
                slimAttachements = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            slimAttachements = []
            print "pass"
        if self.nonManifoldMeshesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check non-manifold geometry" % ( i, maxi )
                nonManifoldMeshes = cleanup.checkNonManifoldMeshes( debug=False )
            except:
                exception()
                nonManifoldMeshes = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            nonManifoldMeshes = []
            print "pass"
        if self.nonManifoldVertexCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check non-manifold vertices" % ( i, maxi )
                nonManifoldVertex = cleanup.checkNonManifoldVertex( query=True, debug=False, ignoreSkinned=True )
            except:
                exception()
                nonManifoldVertex = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            nonManifoldVertex = []
            print "pass"
        if self.nonManifoldNormalsCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check non-manifold normals" % ( i, maxi )
                nonManifoldNormals = cleanup.checkNonManifoldNormals( query=True, debug=False )
            except:
                exception()
                nonManifoldNormals = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            nonManifoldNormals = []
            print "pass"
        if self.setupAttributesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check non-manifold attributes" % ( i, maxi )            
                setupAttributes = cleanup.checkAttributes( query=True, debug=False )
            except:
                exception()
                setupAttributes = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            setupAttributes = []
            print "pass"
        if self.unusedHistoryCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check history" % ( i, maxi )
                unusedHistory = cleanup.checkHistory( query=True, debug=False )
            except:
                exception()
                unusedHistory = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            unusedHistory = []
            print "pass"
        if self.nonManifoldNamesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check names" % ( i, maxi )                
                nonManifoldNames = cleanup.checkUniqueNames( query=True, debug=False )
            except:
                exception()
                nonManifoldNames = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            nonManifoldNames = []
            print "pass"
        if self.nonManifoldHierarchyCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check hierarchy" % ( i, maxi )
                nonManifoldHierarchy = cleanup.checkHierarchy( query=True, debug=False )
            except:
                exception()
                nonManifoldHierarchy = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            nonManifoldHierarchy = []
            print "pass"
        if self.setupSlimShadersCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check slim shaders" % ( i, maxi )
                setupSlimShaders = cleanup.checkSlimShaders( query=True, debug=False )
            except:
                exception()
                setupSlimShaders = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            setupSlimShaders = []
            print "pass"
        if self.setupMayaShadersCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check maya shaders" % ( i, maxi )
                setupMayaShaders = cleanup.checkMayaShaders( query=True, debug=False )
            except:
                exception()
                setupMayaShaders = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            setupMayaShaders = []
            print "pass"
        if self.notCompiledShadersCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)
            try:
                i = i + 1
                print "\n(%s/%s) - check not compiled slim shaders" % ( i, maxi )    
                notCompiledShaders = cleanup.checkCompileSlim( query=True, debug=False )
            except:
                exception()
                notCompiledShaders = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            notCompiledShaders = []
            print "pass"
        if self.lockedCamerasCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)    
            try:
                i = i + 1
                print "\n(%s/%s) - check locked cameras" % ( i, maxi )
                lockedCameras = cleanup.checkNonManifoldCameras( query=True, debug=False )
            except:
                exception()
                lockedCameras = []
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            lockedCameras = []
            print "pass"
        if self.unusedSlimMaterialsCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check unused slim nodes" % ( i, maxi )
                unusedSlimMaterials = cleanup.checkUnusedSlimMaterials( query=True, debug=False )
            except:
                exception()
                unusedSlimMaterials = []  
            print "read in %s sec" % cmds.timer(endTimer=True) 
        else:
            unusedSlimMaterials = []
            print "pass"         
        if self.unusedSlimPalettesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True) 
            try:
                i = i + 1
                print "\n(%s/%s) - check unused slim palettes" % ( i, maxi )
                unusedSlimPalettes = cleanup.checkUnusedSlimPalettes( query=True, debug=False )                
            except:
                exception()
                unusedSlimPalettes = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            unusedSlimPalettes = []
            print "pass"
        if self.partedReferencesCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check parted references" % ( i, maxi )
                partedReferences = cleanup.checkReferenceParts( query=True, debug=False )
            except:
                exception()
                partedReferences = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            partedReferences = []
            print "pass"
        if self.unusedMtorPartitionCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check mtor partition" % ( i, maxi )
                unusedMtorPartition = cleanup.checkPartitions( query=True, debug=False )
            except:
                exception()
                unusedMtorPartition = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            unusedMtorPartition = []
            print "pass"
        if self.unusedReferenceConnectionsCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check reference connections" % ( i, maxi )
                referenceConnections = cleanup.checkReferenceConnections( query=True, debug=False )
            except:
                exception()
                referenceConnections = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            referenceConnections = []
            print "pass"
        if self.partedProxyCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check parted proxy" % ( i, maxi )
                partedProxyManager = cleanup.checkProxies( query=True, debug=False )
            except:
                exception()
                partedProxyManager = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            partedProxyManager = []
            print "pass"
        if self.partedNamespaceCheckbox.checkState() > 0:
            cmds.timer(startTimer=True)  
            try:
                i = i + 1
                print "\n(%s/%s) - check parted namespaces" % ( i, maxi )
                partedNamespaces = cleanup.checkReferenceNamespace( query=True, debug=False )
            except:
                exception()
                partedNamespaces = []  
            print "read in %s sec" % cmds.timer(endTimer=True)
        else:
            partedNamespaces = []
            print "pass"
        i = i + 1    
        print "\n(%s/%s) - initialization" % ( i, maxi )
        window = cleanupPreview()
        window.modal = False
        window.preset = ""
        window.show()
    
def setup():
    global unusedNodes
    global transformTranslations
    global slimAttachements
    global nonManifoldMeshes
    global nonManifoldVertex
    global nonManifoldNormals
    global setupAttributes
    global unusedHistory
    global nonManifoldNames
    global nonManifoldHierarchy
    global setupSlimShaders
    global setupMayaShaders
    global unusedUv
    global notCompiledShaders
    global lockedCameras
    global unusedSlimPalettes
    global unusedSlimMaterials
    global partedReferences
    global unusedMtorPartition
    global referenceConnections
    global partedProxyManager
    global partedNamespaces
    if unusedNodes:
        print "Remove unused nodes."
        cleanup.checkUnusedNodes( unusedNodes, query=False )
    if unusedUv:
        print "Remove unused uv."
        cleanup.checkUnusedUv( unusedUv, query=False )
    if transformTranslations:
        print "Freeze translates."
        cleanup.checkTransformTranslations( transformTranslations, query=False )
    if nonManifoldVertex:
        print "Remove non-manifold vertex."
        cleanup.checkNonManifoldVertex( nonManifoldVertex, query=False, ignoreSkinned=True )
    if nonManifoldNormals:
        print "Conform non-manifold normals."
        cleanup.checkNonManifoldNormals( nonManifoldNormals, query=False )
    if setupAttributes:
        print "Setup attributes."
        cleanup.checkAttributes( setupAttributes, query=False )
    if unusedHistory:
        print "Remove unused history."
        cleanup.checkHistory( unusedHistory, query=False )
    if nonManifoldNames:
        print "Rename non-manifold names."
        cleanup.checkUniqueNames( nonManifoldNames, query=False )
    if nonManifoldHierarchy:
        print "Build valid hierarchy"
        cleanup.checkHierarchy( nonManifoldHierarchy, query=False )
    if setupSlimShaders:
        print "Setup slim shaders"
        cleanup.checkSlimShaders( setupSlimShaders, query=False )
    if setupMayaShaders:
        print "Setup maya shaders"
        cleanup.checkMayaShaders( setupMayaShaders, query=False )
    if notCompiledShaders:
        print "Compile shaders"
        cleanup.checkCompileSlim( notCompiledShaders, query=False )
    if lockedCameras:
        print "Unlock cameras"
        cleanup.checkNonManifoldCameras( lockedCameras, query=False )
    if unusedSlimMaterials:
        print "Remove unused slim nodes"
        cleanup.checkUnusedSlimMaterials( unusedSlimMaterials, query=False )
    if unusedSlimPalettes:
        print "Remove unused slim palettes"
        cleanup.checkUnusedSlimPalettes( unusedSlimPalettes, query=False )
    if partedReferences:
        print "Parted references"    
        cleanup.checkReferenceParts( partedReferences, query=False )
    if unusedMtorPartition:
        print "Unused mtor partition"    
        cleanup.checkPartitions( unusedMtorPartition, query=False )
    if referenceConnections:
        print "Reference geometry connections"    
        cleanup.checkReferenceConnections( referenceConnections, query=False )
    if partedProxyManager:
        print "Parted proxy"    
        cleanup.checkProxies( partedProxyManager, query=False )
    if partedNamespaces:
        print "Parted namespaces"    
        cleanup.checkReferenceNamespace( partedNamespaces, query=False )

def globalInfo():
    global unusedNodes
    global transformTranslations
    global slimAttachements
    global nonManifoldMeshes
    global nonManifoldVertex
    global nonManifoldNormals
    global setupAttributes
    global unusedHistory
    global nonManifoldNames
    global nonManifoldHierarchy
    global setupSlimShaders
    global setupMayaShaders
    global unusedUv
    global notCompiledShaders
    global lockedCameras
    global unusedSlimPalettes
    global unusedSlimMaterials
    global partedReferences
    global unusedMtorPartition
    global referenceConnections
    global partedProxyManager
    global partedNamespaces
    print "-", unusedNodes
    print "-", transformTranslations
    print "-", slimAttachements
    print "-", nonManifoldMeshes
    print "-", nonManifoldVertex
    print "-", nonManifoldNormals
    print "-", setupAttributes
    print "-", unusedHistory
    print "-", nonManifoldNames
    print "-", nonManifoldHierarchy
    print "-", setupSlimShaders
    print "-", setupMayaShaders
    print "-", unusedUv
    print "-", notCompiledShaders
    print "-", lockedCameras
    print "-", unusedSlimPalettes
    print "-", unusedSlimMaterials
    print "-", partedReferences
    print "-", unusedMtorPartition
    print "-", referenceConnections
    print "-", partedProxyManager
    print "-", partedNamespaces

def test():
    f = cleanupPresetSettings()
    f.load()
    f.show()