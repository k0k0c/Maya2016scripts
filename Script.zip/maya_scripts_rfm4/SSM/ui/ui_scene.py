import re
import sys, os, shutil
from PyQt4 import QtCore, QtGui
import sip
import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMayaUI as mui
import sip
import ui_cleanup
reload( ui_cleanup )

global OSTYPE
OSTYPE = "//Server-3d/Project"
if sys.platform != "win32":
		OSTYPE="/Server-3d/Project"

import ui_save;reload(ui_save)
import ui_load;reload(ui_load)


def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return sip.wrapinstance(long(ptr), QtCore.QObject)


class Window(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(Window, self).__init__(parent)
        print "global OSTYPE:"+OSTYPE
        self.mainLayout = QtGui.QVBoxLayout()
        self.setProperty("index","Scene")
        self.isLoad=False
        self.loaded=[]
        self.mainLayout.setSpacing(0)
        self.mainLayout.setContentsMargins(2,2,2,2)
        self.setLayout(self.mainLayout)

    def load(self):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect(self.currentWidgetSlot)        
        self.tabWidget.setStyleSheet("QTabWidget{background: rgb(68,68,68);}")
        self.saveUI=ui_save.Window()
        self.tabWidget.addTab(self.saveUI, "Save")
        self.loadUI=ui_load.Window()
        self.tabWidget.addTab(self.loadUI, "Open")
        self.cleanupUI = ui_cleanup.cleanupPresetSettings()
        self.tabWidget.addTab(self.cleanupUI, "Cleanup")
        self.mainLayout.addWidget(self.tabWidget)        
        self.readSettings()
        self.isLoad=True

    def currentWidgetSlot(self,wi):
        if wi not in self.loaded:
            self.tabWidget.widget(wi).load()
            self.loaded.append(wi)

    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("ui_scene")        
        pos = settings.value("tabWidget", "0").toInt()
        self.tabWidget.setCurrentIndex(pos[0])
        settings.endGroup()
    
    def writeSettings(self):
        if self.isLoad:
            settings = QtCore.QSettings("Melnitsa Soft", "Yago")
            settings.beginGroup("ui_scene")
            settings.setValue("tabWidget", self.tabWidget.currentIndex())
            settings.endGroup()              
            for i in range(0,self.tabWidget.count()):
                if hasattr(self.tabWidget.widget(i), 'writeSettings'):
                    self.tabWidget.widget(i).writeSettings()

