import site
import codecs
import glob
import re
import shutil
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')

import chekProject
import re
import json
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel

def pathConvert(path):
    #print("path: " + path)
    if OSTYPE == "//Server-3d/Project":
        if path.capitalize()[:18] == "/Server-3d/Project":
            path = "//Server-3d/Project" + path[18:]
    else:
        if path.capitalize()[:19] == "//server-3d/project":
            path = "/Server-3d/Project" + path[19:]
    #print("path: " + path)
    return path

def pathBackConvert(path):
    if str(path).capitalize()[:18] == "/Server-3d/Project":
        path = "//Server-3d/Project" + path[18:]
    return path

   
def findAssetName(name):   
    test = name
    rSplit = test.split(".")
    rSplit = rSplit[0].split("_")
    if len(rSplit)>1:
        result = re.match("v[0-9]{3}", rSplit[1])
        if result is not None:
            return rSplit[0]
        testSlovar=["sceleton","tmp","anm","slp","tpl","geo","mod","map","tex","rig","hed","scl","shd","rnd","lgt","dyn","clt","bth","bg","light","fur","tmplate"]
        for i in testSlovar:
            if i == rSplit[1]:
                return rSplit[0]
        return rSplit[0]+"_"+rSplit[1]
    return rSplit[0]
            
class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        col = QtGui.QColor(index.model().data(index,QtCore.Qt.BackgroundColorRole))
        if col.name() == "#000000":
            col = option.palette.window().color()
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, col)
        gradient.setColorAt(0.95, col)
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        users = index.model().data(index,QtCore.Qt.UserRole+8).toString()
        if users == "-1":
            brush = QtGui.QBrush(QtGui.QColor(10,170,10))
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(brush)
            painter.drawEllipse(option.rect.x()+option.rect.width()-0.375*option.rect.height(),option.rect.y()+0.375*option.rect.height(),0.25*option.rect.height(),0.25*option.rect.height());
        elif users != "":
            painter.drawText( option.rect.x(),option.rect.y()+2,option.rect.width()-5,option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignRight,users)
        conflicts = index.model().data(index,QtCore.Qt.UserRole+10).toString()
        if conflicts == "1":
            brush = QtGui.QBrush(QtGui.QColor(170,10,10))
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(brush)
            painter.drawEllipse(option.rect.x()+option.rect.width()-0.775*option.rect.height(),option.rect.y()+0.375*option.rect.height(),0.25*option.rect.height(),0.25*option.rect.height());
            
            
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();


class listDelegate(QtGui.QItemDelegate):
    def __init__(self, parent=None):
        super(listDelegate, self).__init__(parent)
        self.mult = 1
                            
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        #print "resize"
        #print(str(option.rect.width())+"  "+str(option.rect.height()))
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize(11)
        myFontMetrics = QtGui.QFontMetrics(myFont)
        mySize = myFontMetrics.boundingRect(0,0, 260, 0,(QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), index.data(QtCore.Qt.DisplayRole).toString())
        #print(index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize))        
        return QtCore.QSize(mySize.width(),mySize.height()+40)
        
        #mySize = myFontMetrics.boundingRect(option.rect,QtCore.Qt.TextExpandTabs|QtCore.Qt.TextWordWrap,index.data(QtCore.Qt.DisplayRole).toString(),10)
        #mySize = myFontMetrics.size(QtCore.Qt.TextExpandTabs, index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize.width())+"  "+str(mySize.height()+50))        
        #return QtCore.QSize(mySize.width(),mySize.height()+50)
        #return index.data(QtCore.Qt.UserRole+5).toSize()*self.mult

    def paint(self, painter, option, index):
        #print painter.font().pixelSize() 
        #print "paint"
        #self.sizeHint(option, index)
        #self.emmit.sizeHintChanged(index)
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2
            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)


        if sys.platform == "win32":
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Multiply)
            gradient2 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height())
            gradient2.setColorAt(0,QtGui.QColor(255,255,255))
            gradient2.setColorAt(1,QtGui.QColor(200,200,200))
            brush2 = QtGui.QBrush(gradient2)
            painter.fillRect(option.rect,brush2)
    
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
            gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
            gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
            brush3 = QtGui.QBrush(gradient3)
            painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
        
            gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
            gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
            brush4 = QtGui.QBrush(gradient4)
            painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
    
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
    
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        #painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
    
        textSize = index.data(QtCore.Qt.UserRole+5).toString()
        one_widthSize = painter.fontMetrics().width(textSize)
        painter.drawText( option.rect.x()+option.rect.width()-one_widthSize-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textSize)

        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
    
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-6-one_widthSize,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
    
        text = index.data(QtCore.Qt.DisplayRole).toString()
        #newText = painter.fontMetrics().elidedText(text, QtCore.Qt.ElideRight, option.rect.width())
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();
        
#app = QtGui.qApp
class ChooseLoader(QtGui.QDialog):
    def __init__(self, parent=None):
        super(ChooseLoader, self).__init__(parent)
        self.num=""
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins(2,2,2,2)        
        self.setWindowTitle("How open file?")
        self.m_widgetLoadMode = QtGui.QWidget()
        self.m_layoutLoadMode = QtGui.QGridLayout()
        self.m_layoutLoadMode.setContentsMargins( 0, 0, 0, 0 )
        self.m_widgetLoadMode.setLayout( self.m_layoutLoadMode )
        self.m_loadModeButtonLabel = QtGui.QLabel( "Reference depth:" )
        self.m_layoutLoadMode.addWidget( self.m_loadModeButtonLabel, 0, 0 )
        self.m_loadReferenceDepthComboBox = QtGui.QComboBox()
        self.m_loadReferenceDepthComboBox.setToolTip( "Reference selection mode." )
        self.m_loadReferenceDepthComboBoxList = QtCore.QStringList()
        self.m_loadReferenceDepthComboBoxList.append( "Default" )
        self.m_loadReferenceDepthComboBoxList.append( "All" )
        self.m_loadReferenceDepthComboBoxList.append( "Top only" )
        self.m_loadReferenceDepthComboBoxList.append( "None" )
        self.m_loadReferenceDepthComboBox.addItems( self.m_loadReferenceDepthComboBoxList )
        self.m_layoutLoadMode.addWidget( self.m_loadReferenceDepthComboBox, 0, 1 )      
        self.label=QtGui.QLabel("Choose what you want...")
        self.HLayout = QtGui.QHBoxLayout()
        self.referenceLabel=QtGui.QLabel("Reference count:")
        self.referenceCount=QtGui.QSpinBox()
        self.referenceCount.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.referenceCount.setRange(0,100)
        self.referenceCount.setValue(1)
        self.openButton=QtGui.QPushButton("Open")
        self.openButton.released.connect(self.openSlot)
        self.referenceButton=QtGui.QPushButton("Reference")
        self.referenceButton.released.connect(self.referenceSlot)
        self.importButton=QtGui.QPushButton("Import")
        self.importButton.released.connect(self.importSlot)
        self.cancelButton=QtGui.QPushButton("Cancel")
        self.cancelButton.released.connect(self.cancelSlot)
        self.HLayout.addWidget(self.openButton)
        self.HLayout.addWidget( self.m_widgetLoadMode )
        self.HLayout.addWidget(self.referenceLabel)
        self.HLayout.addWidget(self.referenceCount)
        self.HLayout.addWidget(self.referenceButton)
        self.HLayout.addWidget(self.importButton)
        self.HLayout.addWidget(self.cancelButton)
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout )

    def getReferenceDepth(self):
        value = str(self.m_loadReferenceDepthComboBox.currentText())
        value = value == "All" and "all" or value == "Top only" and "topOnly" or value == "None" and "none" or ""
        return value

    def openSlot(self):
        self.done(1)

    def referenceSlot(self):
        self.done(2)

    def importSlot(self):
        self.done(3)

    def cancelSlot(self):
        self.done(0)

class Window(QtGui.QWidget):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.setProperty("index","O")
        self.mainLayout.setContentsMargins(4,4,2,2)        
        self.setLayout(self.mainLayout)
        self.isLoad=False


    def load(self):
        self.conn = mb.connect(host="192.168.0.7",user="root",passwd="12345",port=3306,db = "mel", use_unicode=True)
        self.conn.set_character_set("utf8")
        self.cursor = self.conn.cursor()
        self.expandItem = QtCore.QStringList()
        self.selectItemt = QtCore.QString("");
        self.chooseLoaderInstance=ChooseLoader()        
        self.oneLayout = QtGui.QGridLayout()
        self.oneLabel = QtGui.QLabel("Project: ")
        self.oneLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.cursor.execute("select id, name from projects")
        row = self.cursor.fetchall()
        self.conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()
        self.oneLayout.addWidget(self.oneLabel, 0, 0)
        self.oneLayout.addWidget(self.oneCombobox, 0, 1)

        self.fourLabel = QtGui.QLabel("Type: ")
        self.fourLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fourCombobox = QtGui.QComboBox()
        self.fourQlistNames = QtCore.QStringList()
        self.fourQlistNames.append("All")
        self.fourQlistNames.append("chars")
        self.fourQlistNames.append("props")
        self.fourQlistNames.append("sets")
        self.fourQlistNames.append("scenes")

        self.fiveLabel = QtGui.QLabel("Root: ")
        self.fiveLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fiveCombobox = QtGui.QComboBox()
        self.fiveQlistNames = QtCore.QStringList()
        self.fiveQlistNames.append("Network")
        self.fiveQlistNames.append("Local")
        
        self.fourCombobox.addItems(self.fourQlistNames)
        self.fiveCombobox.addItems(self.fiveQlistNames)
        self.oneLayout.addWidget(self.fourLabel, 0, 2)
        self.oneLayout.addWidget(self.fourCombobox, 0, 3)
        self.oneLayout.addWidget(self.fiveLabel, 0, 4)
        self.oneLayout.addWidget(self.fiveCombobox, 0, 5)
        
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)
        
        self.treePushButton = QtGui.QPushButton("Find last")
        self.treePushButton.released.connect(self.findNext)
        
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)
        self.twoLayout.addWidget(self.twoPushButton)
        self.twoLayout.addWidget(self.treePushButton)
        self.twoLineEdit.returnPressed.connect(self.findText)



        self.assetName = ""
        self.assetPath = ""
        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.connect(self.treeView, QtCore.SIGNAL("doubleClicked(const QModelIndex &)"), self.activeTreeCellDoubleClicked)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("clicked(const QModelIndex &)"), self.activeTreeCellCliked)
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        
        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        self.listView = QtGui.QTreeView()
        self.listView.connect(self.listView, QtCore.SIGNAL("doubleClicked(const QModelIndex &)"), self.activeListCellCliked)
        self.listView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = listDelegate()
        self.listView.setItemDelegate(self.delegate)
        self.listView.setIndentation(0)
        self.listView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.listView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.listModel = QtGui.QStandardItemModel()
        self.listView.setModel(self.listModel)
        self.listView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.listView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.listView.setHeaderHidden(True)
        self.listView.setMinimumWidth(300)
        
        self.layoutButtReference = QtGui.QHBoxLayout()
        self.layoutButtReference.setContentsMargins(2,2,2,2)        

        self.treeMLabelCopy = QtGui.QLabel("Copy:")
        self.treeMLabelCopy.setVisible(False)
        self.treeMLabel = QtGui.QLabel("Load from local: ")
        self.treeMLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.treeMcheck = QtGui.QCheckBox("")
        self.treeMcheck.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        estVal = cmds.optionVar(q="localSave")
        if estVal == 1:
            self.treeMcheck.setCheckState(QtCore.Qt.Checked)
        else:
            self.treeMcheck.setCheckState(QtCore.Qt.Unchecked)
            
        self.treeMcheck.connect(self.treeMcheck, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetLDFLC)

        self.treeMPushButton = QtGui.QPushButton("Cache scene data")
        self.treeMPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.treeMPushButton.released.connect(self.cacheSceneData)
        
        self.layoutButtReference.addWidget(self.treeMLabelCopy)
        self.layoutButtReference.addWidget(self.treeMLabel)
        self.layoutButtReference.addWidget(self.treeMcheck)
        self.layoutButtReference.addWidget(self.treeMPushButton,0,QtCore.Qt.AlignRight)
       
        self.connect(self, QtCore.SIGNAL("accepted()"), self.acceptedSig)
        
        self.mainLayout.addLayout(self.oneLayout)
        self.mainLayout.addLayout(self.twoLayout)
        self.splitter = QtGui.QSplitter(self)
        self.splitter.setFrameStyle(QtGui.QFrame.NoFrame or QtGui.QFrame.Sunken)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.splitter.addWidget(self.treeView)        
        self.splitter.addWidget(self.listView)
        self.mainLayout.addWidget(self.splitter)
        self.mainLayout.addLayout(self.layoutButtReference)
        self.resize(350, 550)
        self.setWindowTitle('Load asset/scene...')
        self.readSettings()
        self.findText()
        self.fiveCombobox.connect(self.fiveCombobox, QtCore.SIGNAL("currentIndexChanged(int)"), self.fiveComboboxCATCHER)
        self.loadDirectoryName(self.treeModel.invisibleRootItem())
        self.twoLineEdit.setFocus()
        self.isLoad=True



    def pathLocalOrNetwork(self, path):
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        path = expression.sub("//Server-3d/Project",path)
        #estVal = cmds.optionVar(q="localSave")
        #if estVal:
        if self.fiveCombobox.currentText() != "Network":
            path = expression.sub(os.environ['HOME']+"/Project",path)
        return path

    def stateChangetLDFLC(self, index):
        print("stateChangetLDFLC")
        estVal = cmds.optionVar(q="localSave")
        if estVal:
            cmds.optionVar(iv=("localSave",0))
        else:
            cmds.optionVar(iv=("localSave",1))
    
    def cacheSceneData(self):
        treeViewPath = str(self.treeView.selectionModel().currentIndex().data(QtCore.Qt.UserRole+1).toString())
        listViewPath = str(self.listView.selectionModel().currentIndex().data(QtCore.Qt.UserRole+1).toString())
        filePath=""
        if os.path.isfile(listViewPath):
            filePath = listViewPath
        elif os.path.isfile(treeViewPath):
            filePath = treeViewPath
        if filePath != "":
            print("Cache...")
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            file = open(filePath, "r")
            listOfstring=[]
            listOfstringOneIter=[]        
            partstring=""
            listOfPaths={}
            listOfLocalPaths=[]
            for f in file:
                if re.search("^file .*-rdi ",f) is not None:
                    if re.search("^file .*-rdi .*;$",f) is not None:
                        listOfstring.append(f.replace("\n",""))
                    else:
                        partstring+=f.replace("\n","")
                elif partstring != "" and re.search(";$",f) is not None:
                    listOfstring.append(partstring+f.replace("\n",""))
                    partstring=""
                elif partstring != "":
                    partstring+=f.replace("\n","")

            for li in listOfstring:
                if re.search(".* -dr 1 .*",li) is None:
                    listOfstringOneIter.append(li)


            for los in listOfstringOneIter:
                m=re.search("(/Server-3d/Project/.*\.m[a|b])|(/mnt/server-3d/.*\.m[a|b])|(P:/.*\.m[a|b])|(/home/.*/Project/.*\.m[a|b])|(D:/Work/Project/.*\.m[a|b])|(//Server-3d/Project/.*\.m[a|b])",los)
                if m is not None:
                    path = expression.sub(OSTYPE,m.group())
                    if os.path.exists(path) and path.lower() not in listOfPaths.keys():
                        listOfPaths[path.lower()]=path

            listOfPaths=listOfPaths.values()

            for sl in listOfPaths:         
                expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
                listOfLocalPaths.append(expression.sub(os.environ['HOME']+"/Project",sl))

            
            self.treeMLabelCopy.setVisible(True)
            self.treeMLabel.setVisible(False)
            self.treeMcheck.setVisible(False)         
            self.treeMPushButton.setEnabled(False)
                    
            for slp in range(0,len(listOfPaths)):
                QtGui.QApplication.processEvents()
                if not os.path.exists(os.path.dirname(listOfLocalPaths[slp])):
                    os.makedirs(os.path.dirname(listOfLocalPaths[slp]))
                copyDa=0
                if not os.path.exists(listOfLocalPaths[slp]):
                    copyDa=1
                elif os.path.getmtime(listOfPaths[slp]) > os.path.getmtime(listOfLocalPaths[slp]):
                    copyDa=1

                if copyDa == 1:   
                    print("copy: " + listOfPaths[slp] + " to " + listOfLocalPaths[slp])
                    QtGui.QApplication.processEvents()                
                    self.treeMLabelCopy.setText("("+str(slp+1)+"/"+str(len(listOfPaths))+") copy: "+str(os.path.basename(listOfLocalPaths[slp])))
                    QtGui.QApplication.processEvents()
                    shutil.copyfile(listOfPaths[slp], listOfLocalPaths[slp])

            self.treeMLabelCopy.setVisible(False)
            self.treeMLabel.setVisible(True)
            self.treeMcheck.setVisible(True)                   
            self.treeMPushButton.setEnabled(True)

    def fiveComboboxCATCHER(self, index):
        #self.treeModel.clear()
        self.findText()
                
    def acceptedSig(self):
            self.writeSettings()
            
    def closeEvent(self, event):
            self.writeSettings()
    
    def setResourceLabel(self, stroka):
            slpi = stroka.split("::")
            slpi = slpi[1:-1]
            ddd=""
            for f in slpi:
                if f != "-1":
                    ddd+=f+","
            ddd=ddd[0:-1]
            row = ""
            slpiImFam=QtCore.QStringList()
            if len(ddd):
                nuse=str("select id, familia, imya from people where id in (") + str(ddd) + str(")")
                #print nuse
                self.cursor.execute(nuse)
                row = self.cursor.fetchall()
                self.conn.commit()
                #print str(len(row))
                
            for x in slpi:
                x=x.split(",")
                slpiImFam.append("")
                postroiliImena=""
                for xz in x:
                    for y in row:
                        if str(xz)==str(y[0]):
                            postroiliImena+=" "+y[1]+"."+y[2][0]
                            
                if postroiliImena:
                    slpiImFam[-1]=postroiliImena
                else:
                    slpiImFam[-1]="-1"

            if len(slpiImFam)!=len(slpi):
                print "Dlinny ne ravny!!!!"
            for v in slpiImFam:
                #print "slpiImFam: "+v.toUtf8()
                pass
            parentItem = self.treeModel.invisibleRootItem()
            for item in range(parentItem.rowCount()):
                #print "item: "+str(item)
                if len(slpiImFam)>item:
                    parentItem.child(item,0).setData(slpiImFam[item],QtCore.Qt.UserRole+4)
            
    def activeListCellCliked(self, index):
        #print "activeListCellCliked"
        filePathToProcess = index.data(QtCore.Qt.UserRole+1).toString()
        filePathToProcessStr=str(filePathToProcess)
        fileNameToProcess = index.data(QtCore.Qt.UserRole+4).toString().split(".")[0]
        fileNameToProcessStr=str(fileNameToProcess)
        '''
        msgBox = QtGui.QMessageBox()
        msgBox.setWindowTitle("How open file?")
        msgBox.setText("Choose what you want...")
        #msgBox.setInformativeText("Do you want to save your changes?")
        but=msgBox.addButton("Open",QtGui.QMessageBox.AcceptRole)
        msgBox.addButton("Reference",QtGui.QMessageBox.AcceptRole)
        msgBox.addButton("Import",QtGui.QMessageBox.AcceptRole)
        cancel = msgBox.addButton(QtGui.QMessageBox.Cancel)
        msgBox.setDefaultButton(but)
        msgBox.setEscapeButton(cancel)
        ret = msgBox.exec_()
        if ret != QtGui.QMessageBox.Cancel:
        '''
        ret = self.chooseLoaderInstance.exec_()
        loadReferenceDepth = self.chooseLoaderInstance.getReferenceDepth()
        if ret:
            extenshen="mayaBinary"
            if filePathToProcessStr.split(".")[1]=="ma": extenshen="mayaAscii"                
            if ret == 1:
                chekProject.setMayaProject(self.pathLocalOrNetwork(str(self.assetPath)))
                #cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, open=True)
                if loadReferenceDepth != "":
                    loadReferenceDepthEval="-loadReferenceDepth \\\"%s\\\"" % loadReferenceDepth
                else:
                    loadReferenceDepthEval = ""
                mel.eval("saveChanges(\"file -f -options \\\"v=0\\\"  -ignoreVersion  -typ \\\""+extenshen+"\\\" "+loadReferenceDepthEval+" -o \\\""+filePathToProcessStr+"\\\"\")")
                #mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm3/openForOpen.mel\"")
                #mel.eval("openForOpen(\""+filePathToProcessStr+"\")")
                mel.eval("addRecentFile(\""+filePathToProcessStr+"\", \""+extenshen+"\")")
                melnik_setup.updateScene()
                #chekProject.chekProject()
            elif ret == 2:
                loadReferenceDepth = self.chooseLoaderInstance.getReferenceDepth()
                for n in range(0, self.chooseLoaderInstance.referenceCount.value()):
                    if loadReferenceDepth != "":
                        cmds.file( filePathToProcessStr, type=extenshen, options="v=0", reference=True, loadReferenceDepth=loadReferenceDepth, namespace=fileNameToProcessStr)
                    else:
                        cmds.file( filePathToProcessStr, type=extenshen, options="v=0", reference=True, namespace=fileNameToProcessStr)
            elif ret == 3:
                chekProject.setMayaProject(self.pathLocalOrNetwork(str(self.assetPath)))
                if loadReferenceDepth != "":
                    cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=False, i=True, preserveReferences=True, loadReferenceDepth=loadReferenceDepth)
                else:
                    cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=False, i=True, preserveReferences=True )
                #cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=True, i=True, namespace=fileNameToProcessStr, preserveReferences=True, loadReferenceDepth="all")
            
        
    def activeTreeCellDoubleClicked(self, index):
        #print "activeTreeCellDoubleClicked"
        filePathToProcessStr=str(index.data(QtCore.Qt.UserRole+1).toString())
        fileNameToProcessStr=str(index.data(QtCore.Qt.DisplayRole).toString().split(".")[0])
        #print filePathToProcessStr
        #print fileNameToProcessStr
        if index.data(QtCore.Qt.UserRole).toString()!="":
            if index.data(QtCore.Qt.UserRole+3).toString() != "5":
                filePathToProcessStr = filePathToProcessStr+"/"+fileNameToProcessStr+"/maya/"
            else:
                filePathToProcessStr = filePathToProcessStr+"/"+fileNameToProcessStr+"/"
       
            dir = QtCore.QDir(filePathToProcessStr)
            strList = dir.entryInfoList(QtCore.QDir.Files)
            for i in strList:
                #print i.baseName()
                if i.baseName().toLower()==fileNameToProcessStr.lower():
                    filePathToProcessStr=str(i.filePath())
                    fileNameToProcessStr=str(i.baseName())
                    #print("To chto my nashli: "+filePathToProcessStr)
                    break
        file = QtCore.QFile(filePathToProcessStr)
        if file.exists():
            '''
            msgBox = QtGui.QMessageBox()
            msgBox.setWindowTitle("How open file?")
            msgBox.setText("Choose what you want...")
            #msgBox.setInformativeText("Do you want to save your changes?")
            but=msgBox.addButton("Open",QtGui.QMessageBox.AcceptRole)
            msgBox.addButton("Reference",QtGui.QMessageBox.AcceptRole)
            msgBox.addButton("Import",QtGui.QMessageBox.AcceptRole)
            cancel = msgBox.addButton(QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(but)
            msgBox.setEscapeButton(cancel)
            ret = msgBox.exec_()
            if ret != QtGui.QMessageBox.Cancel:
            '''
            ret = self.chooseLoaderInstance.exec_()
            loadReferenceDepth = self.chooseLoaderInstance.getReferenceDepth()
            if ret:
                extenshen="mayaBinary"
                if filePathToProcessStr.split(".")[1]=="ma": extenshen="mayaAscii"                
                if ret == 1:
                    chekProject.setMayaProject(self.pathLocalOrNetwork(str(self.assetPath)))
                    #cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, open=True)
                    if loadReferenceDepth != "":
                        loadReferenceDepthEval="-loadReferenceDepth \\\"%s\\\"" % loadReferenceDepth
                    else:
                        loadReferenceDepthEval = ""
                    mel.eval("saveChanges(\"file -f -options \\\"v=0\\\"  -ignoreVersion  -typ \\\""+extenshen+"\\\" "+loadReferenceDepthEval+" -o \\\""+filePathToProcessStr+"\\\"\")")
                    #mel.eval("source \"//server-3d/Project/lib/setup/maya/maya_scripts_rfm3/openForOpen.mel\"")
                    #mel.eval("openForOpen(\""+filePathToProcessStr+"\")")
                    mel.eval("addRecentFile(\""+filePathToProcessStr+"\", \""+extenshen+"\")")
                    melnik_setup.updateScene()
                    #chekProject.chekProject()
                elif ret == 2:
                    loadReferenceDepth = self.chooseLoaderInstance.getReferenceDepth()
                    for n in range(0, self.chooseLoaderInstance.referenceCount.value()):
                        if loadReferenceDepth != "":
                            cmds.file( filePathToProcessStr, type=extenshen, options="v=0", reference=True, loadReferenceDepth=loadReferenceDepth, namespace=fileNameToProcessStr)
                        else:
                            cmds.file( filePathToProcessStr, type=extenshen, options="v=0", reference=True, namespace=fileNameToProcessStr)
                elif ret == 3:
                    chekProject.setMayaProject(self.pathLocalOrNetwork(str(self.assetPath)))
                    if loadReferenceDepth != "":
                        cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=False, i=True, preserveReferences=True, loadReferenceDepth=loadReferenceDepth)
                    else:
                        cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=False, i=True, preserveReferences=True )
                    #cmds.file( filePathToProcessStr, type=extenshen, options="v=0", ignoreVersion=True, force=True, renameAll=True, i=True, namespace=fileNameToProcessStr, preserveReferences=True, loadReferenceDepth="all")
        else:
            pass
        
    def activeTreeCellCliked(self, index):
        #print "activeTreeCellCliked"        
        self.listModel.clear()
        
        rootPath = index.data(QtCore.Qt.UserRole+1).toString()
        #print("rootPath: "+rootPath)
        eeeNew = index
        eeePast = index
        while eeeNew.row() != -1:
            eeePast = eeeNew
            eeeNew = eeeNew.parent()
        self.assetName = eeePast.data(QtCore.Qt.DisplayRole).toString()
        self.assetPath = eeePast.data(QtCore.Qt.UserRole+1).toString()+"/"+eeePast.data(QtCore.Qt.DisplayRole).toString()
        
        melnik_setup.globalAssetName=self.assetName
        #print "berem Imya!!!!!"+melnik_setup.globalAssetName
        #print self.assetPath
        self.userId = melnik_setup.userId
        
        if self.fiveCombobox.currentText() != "Network" and self.userId != -1:
            self.cursor.execute(u'select e.date, e.info, e.path, p.nickname from data as d, data_has_edits as dhe, edits as e, edits_has_people as ehp, people as p where d.path like %s and d.id = dhe.data_id and e.id = dhe.edits_id and dhe.edits_id=ehp.edits_id and p.id=ehp.people_id and p.id=%s order by e.date',(pathBackConvert(rootPath.split(".")[0]+".%"),self.userId,))        
        else:
            self.cursor.execute(u'select e.date, e.info, e.path, p.nickname from data as d, data_has_edits as dhe, edits as e, edits_has_people as ehp, people as p where d.path like %s and d.id = dhe.data_id and e.id = dhe.edits_id and dhe.edits_id=ehp.edits_id and p.id=ehp.people_id order by e.date',(pathBackConvert(rootPath.split(".")[0]+".%"),))        
        row = self.cursor.fetchall()
        self.conn.commit()
        #print len(row)        
        #print row
        myFileInfo=QtCore.QFileInfo(rootPath)
        myFileName = myFileInfo.fileName()
        twoPart = myFileName.split(".")
        #print "twoPart: "+myFileName
        treeFor = twoPart[0].split("_")
        parts=1
        #for iii in treeFor:
            #print iii
        if treeFor.count() == 2: 
            #print "IF"
            #for sl in treeFor:
                #print sl
            treeForOne=twoPart[0].split("_")
            treeForOne.insert(1,"v??[0-9]")
            treeForFullOne = treeForOne.join("_")
            treeForTwo=twoPart[0].split("_")
            treeForTwo.insert(2,"v??[0-9]")
            treeForFullTwo = treeForTwo.join("_")
            myStr=treeForFullOne+"_*.ma,"+treeForFullOne+"_*.mb,"+treeForFullOne+".ma,"+treeForFullOne+".mb,"+treeForFullTwo+"*.ma,"+treeForFullTwo+"*.mb"
            #myStr=treeForFullTwo+"*.ma,"+treeForFullTwo+"*.mb"
            #print "myStr2"+myStr
        else:
            #print "ELSE"
            if treeFor.count() > 0: 
                parts=2
            treeFor.insert(parts,"v??[0-9]")
            treeForFull = treeFor.join("_")
            myStr=treeForFull+"*.ma,"+treeForFull+"*.mb"
            #print "myStr0"+myStr
        
        #print("myStr: "+myStr)
        filters= myStr.split(",")
        dir = QtCore.QDir()
        dir.setNameFilters(filters)
        
        myPath = myFileInfo.path()
        dir.setPath(myPath+"/work")
        #print "myPath: "+myPath+"/work"
        strList = dir.entryInfoList(QtCore.QDir.Files,QtCore.QDir.Name or QtCore.QDir.Reversed)
        #strList = dir.entryInfoList()
        item = self.listModel.invisibleRootItem()
        filePathList = QtCore.QStringList()
        dateTimeList = QtCore.QStringList()        
        userList = QtCore.QStringList()
        fileNameList = QtCore.QStringList()        
        fileSizeList = QtCore.QStringList()        
        fileInfoList = QtCore.QStringList()                
        for i in range(0,len(strList)):
            ttimeNow=""
            lastUser=""
            fileEdits=""
            fileTmpEdits=""
            est=0
            #print "strList " + str(i) + ": " + str(strList[i].filePath())
            for j in range(0,len(row)):
                #print row[j][2]+" == "+strList[i].filePath()
                if pathConvert(row[j][2]) == strList[i].filePath():
                    #print fileEdits
                    if est>1:
                        fileEdits+=row[j][3]+"        "+row[j][0].isoformat(' ')+"\n"+row[j][1]+"\n\n"
                    elif est==1:
                        fileEdits=fileTmpEdits+row[j][3]+"        "+row[j][0].isoformat(' ')+"\n"+row[j][1]+"\n\n"
                    elif est==0:
                        fileEdits=row[j][1]
                        fileTmpEdits=row[j][3]+"        "+row[j][0].isoformat(' ')+"\n"+row[j][1]+"\n\n"
                    ttimeNow=row[j][0].isoformat(' ')
                    lastUser=row[j][3]
                    est+=1
            if est>0:
                filePathList.append(strList[i].filePath())                    
                fileNameList.append(strList[i].fileName())                    
                dateTimeList.append(ttimeNow) 
                userList.append(lastUser)
                #print fileEdits
                fileInfoList.append(fileEdits) #.decode('UTF-8')                                
            elif est == 0:                    
                filePathList.append(strList[i].filePath())
                ttime=strList[i].lastModified()
                dateTimeList.append(ttime.toString("yyyy-MM-dd hh:mm:ss"))             
                #dateTimeList.append(str(ttime.date().year())+"-"+str(ttime.date().month())+"-"+str(ttime.date().day())+" "+str(ttime.time().hour())+":"+str(ttime.time().minute())+":"+str(ttime.time().second()))             
                userList.append("unknovn")
                fileNameList.append(strList[i].fileName())
                fileInfoList.append("empty")

            sizeBites=strList[i].size()   
            rezsize=""
            if (float(sizeBites)/1024) > 1 and (float(sizeBites)/1024) < 1024:
                rezsize='%.2f' % (float(sizeBites)/1024)+" Kb"
            elif (float(sizeBites)/1048576) > 1 and (float(sizeBites)/1048576) < 1024:
                rezsize='%.2f' % (float(sizeBites)/1048576)+" Mb"
            else:
                rezsize='%.2f' % (float(sizeBites)/1073741824)+" Gb"
            fileSizeList.append(rezsize)
        
        for i in range(0,len(filePathList)):                        
            #print "filePathList " + str(i) + ": " + str(filePathList[i])
            child = QtGui.QStandardItem("empty")
            child.setData(filePathList[i],QtCore.Qt.UserRole+1)
            #print fileSizeList[i]
            child.setData(dateTimeList[i],QtCore.Qt.UserRole+2)
            child.setData(userList[i],QtCore.Qt.UserRole+3)
            child.setData(fileNameList[i],QtCore.Qt.UserRole+4)
            child.setData(fileSizeList[i],QtCore.Qt.UserRole+5)
            child.setData(fileInfoList[i],QtCore.Qt.DisplayRole)

            #myFont = QtGui.QFont("Tahoma")
            #myFont.setPixelSize(11)
            #myFontMetrics = QtGui.QFontMetrics(myFont)
            #mySize = myFontMetrics.boundingRect(0,0,40,60,QtCore.Qt.TextExpandTabs,fileInfoList[i],10)
            #print("razmer: "+str(mySize.width())+" na "+str(mySize.height()))

            #child.setData(QtCore.QSize(mySize.width(),mySize.height()+50),QtCore.Qt.UserRole+5)
            item.setChild(i,child)

    def activeTreeCellExpanded(self, index):
        #print("activeTreeCellExpanded: ")
        typeId = index.data(QtCore.Qt.UserRole+3).toString()
        if index.parent().row() == -1 and typeId!="5":
            #print("expanded: "+index.child(0,0).data().toString())            
            item = self.treeModel.itemFromIndex(index)
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data().toString()+"/maya"
            #print("rootPath: "+rootPath)            
            dir = QtCore.QDir(rootPath)
            myStr="*.ma,*.mb"
            filters= myStr.split(",")
            dir.setNameFilters(filters)
            strList = dir.entryList()
            #item.removeRow(0)
            for i in range(0,len(strList)):
                child = QtGui.QStandardItem(strList[i])
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+1)
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+2)
                adata = assetData()
                adata.setData( str(rootPath+"/"+strList[i]) )
                if adata.warningData():
                    child.setData("1",QtCore.Qt.UserRole+10)                    
                item.setChild(i,child)
            dir.setPath(rootPath+"/work/anm")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("anm")
                childItem.setData("anm",QtCore.Qt.UserRole+2)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/anm/"+strList[i],QtCore.Qt.UserRole+1)
                    child.setData(rootPath+"/work/anm/"+strList[i],QtCore.Qt.UserRole+2)
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/anm/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)  
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)

            dir.setPath(rootPath+"/referenceParts")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("referenceParts")
                childItem.setData("referenceParts",QtCore.Qt.UserRole+2)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/referenceParts/"+strList[i],QtCore.Qt.UserRole+1)                    
                    child.setData(rootPath+"/referenceParts/"+strList[i],QtCore.Qt.UserRole+2)    
                    adata = assetData()
                    adata.setData( str(rootPath+"/referenceParts/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                      
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)

            dir.setPath(rootPath+"/work/dyn")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("dyn")
                childItem.setData("dyn",QtCore.Qt.UserRole+2)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/dyn/"+strList[i],QtCore.Qt.UserRole+1)                    
                    child.setData(rootPath+"/work/dyn/"+strList[i],QtCore.Qt.UserRole+2)    
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/dyn/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                          
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/work/map")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("map")
                childItem.setData("map",QtCore.Qt.UserRole+2)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/map/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/work/map/"+strList[i],QtCore.Qt.UserRole+2)  
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/map/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                                
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/fur")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("fur")
                childItem.setData("fur",QtCore.Qt.UserRole+2)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/fur/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/work/fur/"+strList[i],QtCore.Qt.UserRole+2)     
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/fur/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                               
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/shd")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("shd")
                childItem.setData("shd",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/shd/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/shd/"+strList[i],QtCore.Qt.UserRole+2)      
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/shd/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                                                            
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/light")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("light")
                childItem.setData("light",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/light/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/light/"+strList[i],QtCore.Qt.UserRole+2)     
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/light/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                                                              
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/tex")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("tex")
                childItem.setData("tex",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/tex/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/tex/"+strList[i],QtCore.Qt.UserRole+2)    
                    adata = assetData()
                    adata.setData( str(rootPath+"/work/tex/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                                                               
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)               
            dir.setPath(rootPath+"/work/mod")
            strListRig = dir.entryList()
            dir.setPath(rootPath+"/work/mod/geo")
            strListHed = dir.entryList()
            dir.setPath(rootPath+"/work/mod/shape")
            strListScl = dir.entryList()
            dir.setPath(rootPath+"/work/mod/tpl")
            strListDev = dir.entryList()
            if len(strListRig) is not 0 or len(strListHed) is not 0 or len(strListScl) is not 0:                        
                childItemRig = QtGui.QStandardItem("mod")
                childItemRig.setData("mod",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItemRig)
                if len(strListRig) is not 0:
                    for i in range(0,len(strListRig)):                
                        child = QtGui.QStandardItem(strListRig[i])
                        child.setData(rootPath+"/work/mod/"+strListRig[i],QtCore.Qt.UserRole+1)                                                                                                                                                        
                        child.setData(rootPath+"/work/mod/"+strListRig[i],QtCore.Qt.UserRole+2)
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/mod/"+strListRig[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                                                                                                                                                                      
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                        
                        childItemRig.setChild(i,child)             
                if len(strListHed) is not 0:
                    childItem = QtGui.QStandardItem("geo")
                    childItem.setData("geo",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListHed)):                
                        child = QtGui.QStandardItem(strListHed[i])
                        child.setData(rootPath+"/work/mod/geo/"+strListHed[i],QtCore.Qt.UserRole+1)                                                                                                                                                                                
                        child.setData(rootPath+"/work/mod/geo/"+strListHed[i],QtCore.Qt.UserRole+2)     
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/mod/geo/"+strListHed[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                                                                                                                                                                                                     
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListScl) is not 0:
                    childItem = QtGui.QStandardItem("shape")
                    childItem.setData("shape",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListScl)):                
                        child = QtGui.QStandardItem(strListScl[i])
                        child.setData(rootPath+"/work/mod/shape/"+strListScl[i],QtCore.Qt.UserRole+1)                                            
                        child.setData(rootPath+"/work/mod/shape/"+strListScl[i],QtCore.Qt.UserRole+2)    
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/mod/shape/"+strListScl[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                                                                                 
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListDev) is not 0:
                    childItem = QtGui.QStandardItem("tpl")
                    childItem.setData("tpl",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListDev)):                
                        child = QtGui.QStandardItem(strListDev[i])
                        child.setData(rootPath+"/work/mod/tpl/"+strListDev[i],QtCore.Qt.UserRole+1)                                              
                        child.setData(rootPath+"/work/mod/tpl/"+strListDev[i],QtCore.Qt.UserRole+2)   
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/mod/tpl/"+strListDev[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                       
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                              
            dir.setPath(rootPath+"/work/rig")
            strListRig = dir.entryList()
            dir.setPath(rootPath+"/work/rig/face")
            strListHed = dir.entryList()
            dir.setPath(rootPath+"/work/rig/sceleton")
            strListScl = dir.entryList()
            dir.setPath(rootPath+"/work/rig/dev")
            strListDev = dir.entryList()
            if len(strListRig) is not 0 or len(strListHed) is not 0 or len(strListScl) is not 0:                        
                childItemRig = QtGui.QStandardItem("rig")
                childItemRig.setData("rig",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItemRig)
                if len(strListRig) is not 0:
                    for i in range(0,len(strListRig)):                
                        child = QtGui.QStandardItem(strListRig[i])
                        child.setData(rootPath+"/work/rig/"+strListRig[i],QtCore.Qt.UserRole+1)                                                  
                        child.setData(rootPath+"/work/rig/"+strListRig[i],QtCore.Qt.UserRole+2)        
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/rig/"+strListRig[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                     
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItemRig.setChild(i,child)             
                if len(strListHed) is not 0:
                    childItem = QtGui.QStandardItem("face")
                    childItem.setData("face",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListHed)):                
                        child = QtGui.QStandardItem(strListHed[i])
                        child.setData(rootPath+"/work/rig/face/"+strListHed[i],QtCore.Qt.UserRole+1)                                             
                        child.setData(rootPath+"/work/rig/face/"+strListHed[i],QtCore.Qt.UserRole+2)     
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/rig/face/"+strListHed[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                                                                   
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListScl) is not 0:
                    childItem = QtGui.QStandardItem("sceleton")
                    childItem.setData("sceleton",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListScl)):                
                        child = QtGui.QStandardItem(strListScl[i])
                        child.setData(rootPath+"/work/rig/sceleton/"+strListScl[i],QtCore.Qt.UserRole+1)                                         
                        child.setData(rootPath+"/work/rig/sceleton/"+strListScl[i],QtCore.Qt.UserRole+2)    
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/rig/sceleton/"+strListScl[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                                                                  
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListDev) is not 0:
                    childItem = QtGui.QStandardItem("dev")
                    childItem.setData("dev",QtCore.Qt.UserRole+2)                                
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListDev)):                
                        child = QtGui.QStandardItem(strListDev[i])
                        child.setData(rootPath+"/work/rig/dev/"+strListDev[i],QtCore.Qt.UserRole+1)                                              
                        child.setData(rootPath+"/work/rig/dev/"+strListDev[i],QtCore.Qt.UserRole+2) 
                        adata = assetData()
                        adata.setData( str(rootPath+"/work/rig/dev/"+strListDev[i]) )
                        if adata.warningData():
                            child.setData("1",QtCore.Qt.UserRole+10)                             
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                            
                        
                           
        elif index.parent().row() == -1 and typeId == "5":            
            item = self.treeModel.itemFromIndex(index)
            rootPath = index.data(QtCore.Qt.UserRole+1).toString()+"/"+index.data().toString()                
            #print("rootPath: "+rootPath)            
            dir = QtCore.QDir(rootPath)
            myStr="*.ma,*.mb"
            filters= myStr.split(",")
            dir.setNameFilters(filters)
            strList = dir.entryList()
            #if item.child(0,0).data(QtCore.Qt.DisplayRole).toString()==item.data(QtCore.Qt.UserRole+1).toString():
            #    item.removeRow(0)
            while item.takeRow(0) != []:
                pass                
            '''for i in range(0,len(strList)):
                child = QtGui.QStandardItem(strList[i])
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+1)
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+2)                
                item.setChild(i,child)
                '''
            dir.setPath(rootPath+"/tmplate")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("tmplate")
                childItem.setData("tmplate",QtCore.Qt.UserRole+2)                                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/tmplate/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/tmplate/"+strList[i],QtCore.Qt.UserRole+2)  
                    adata = assetData()
                    adata.setData( str(rootPath+"/tmplate/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                                                                 
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child) 
            dir.setPath(rootPath+"/anm")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("anm")
                childItem.setData("anm",QtCore.Qt.UserRole+2)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/anm/"+strList[i],QtCore.Qt.UserRole+1)
                    child.setData(rootPath+"/anm/"+strList[i],QtCore.Qt.UserRole+2)
                    adata = assetData()
                    adata.setData( str(rootPath+"/anm/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10) 
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/dyn")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("dyn")
                childItem.setData("dyn",QtCore.Qt.UserRole+2)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/dyn/"+strList[i],QtCore.Qt.UserRole+1)                    
                    child.setData(rootPath+"/dyn/"+strList[i],QtCore.Qt.UserRole+2)  
                    adata = assetData()
                    adata.setData( str(rootPath+"/dyn/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                       
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/light")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("light")
                childItem.setData("light",QtCore.Qt.UserRole+2)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/light/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/light/"+strList[i],QtCore.Qt.UserRole+2)       
                    adata = assetData()
                    adata.setData( str(rootPath+"/light/"+strList[i]) )
                    if adata.warningData():
                        child.setData("1",QtCore.Qt.UserRole+10)                                            
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
                                      
            
        
    def findText(self):   
        #twoLineEdit = self.sender()
        fingTextLine = self.twoLineEdit.text()

        rezTESET=""
        for t in str(fingTextLine):
            rezTESET=rezTESET+"["+t.upper()+t.lower()+"]"
            
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()        

        REALROOTOFFILES=OSTYPE
        if self.fiveCombobox.currentText() != "Network":
            REALROOTOFFILES=os.environ['HOME']+"/Project"
            if not os.path.exists(REALROOTOFFILES):
                os.makedirs(REALROOTOFFILES)


        slovarik={}
        if self.fourCombobox.currentText()!="All":
            mun=1
            if self.fourCombobox.currentText()=="props":    
                mun=3
                propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*'+rezTESET+'*')
                for epSc in propsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]            
            elif self.fourCombobox.currentText()=="sets":    
                mun=4
                setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*'+rezTESET+'*')
                for epSc in setsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]
            elif self.fourCombobox.currentText()=="scenes":    
                mun=5
                scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*'+rezTESET+'*')
                for epSc in scenesPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]                
            else:
                charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*'+rezTESET+'*')
                for epSc in charsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
            
            self.cursor.execute("select ar.id, ar.name, ar.path, atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),mun,"%"+fingTextLine+"%",))
        else:
            propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*' + rezTESET + '*')
            for epSc in propsPath:
                epSc=epSc.replace("\\","/")            
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]
            setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*' + rezTESET + '*')
            for epSc in setsPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]
            scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*' + rezTESET + '*')
            for epSc in scenesPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]
            charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*' + rezTESET + '*')
            for epSc in charsPath:
                epSc=epSc.replace("\\","/")            
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                           
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
            self.cursor.execute("select ar.id, ar.name, ar.path, atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),"%"+fingTextLine+"%",))
            
        row = self.cursor.fetchall()
        self.conn.commit()
        print("PROJECT: "+str(self.oneCombobox.currentText()))
        print(str(slovarik))
        #if self.fiveCombobox.currentText() == "Network":        
        for x in row:
            if os.path.isdir(pathConvert(str(x[2]+"/"+x[1]))) and pathConvert(str(x[2]+"/"+x[1])) in slovarik.keys():
                slovarik[pathConvert(str(x[2]+"/"+x[1]))]=[x[0],x[1],x[2],x[3]]

        liist=slovarik.values()
        liist=sorted(liist, key=lambda t: t[1].decode('utf8', 'ignore').lower())
        #print(str(slovarik))
                
        testString="MAYA::CHEKLIST"
        for x in liist:
            #print(x)
            testString+="::"+x[1].decode('utf8', 'ignore')
            item = QtGui.QStandardItem(x[1])
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            item.setFont(serifFont)
            child = QtGui.QStandardItem(pathConvert(x[2]))
            item.setData(x[1],QtCore.Qt.DisplayRole)
            item.setData(x[0],QtCore.Qt.UserRole)
            item.setData(pathConvert(x[2]),QtCore.Qt.UserRole+1)            
            item.setData(x[1],QtCore.Qt.UserRole+2)            
            item.setData(x[3],QtCore.Qt.UserRole+3)
            item.setData("",QtCore.Qt.UserRole+4)            
            item.setChild(0,child)
            parentItem.appendRow(item)
        melnik_setup.sendMessage(testString)

    def findNext(self):   
        nameOfSelected = self.treeView.selectionModel().currentIndex().data().toString()
        #print "nameOfSelected: " + nameOfSelected+"    "+self.treeView.selectionModel().currentIndex().data(QtCore.Qt.UserRole).toString()+"    "+self.treeView.selectionModel().currentIndex().data(QtCore.Qt.UserRole+1).toString()+"    "+self.treeView.selectionModel().currentIndex().data(QtCore.Qt.UserRole+2).toString()+"    "+self.treeView.selectionModel().currentIndex().data(QtCore.Qt.UserRole+3).toString()
        if len(nameOfSelected.split(".")) > 1:
            eeeNew = self.treeView.selectionModel().currentIndex()
            eeePast = self.treeView.selectionModel().currentIndex()
            while eeeNew.row() != -1:
                eeePast = eeeNew
                eeeNew = eeeNew.parent()
            
            idType = eeePast.data(QtCore.Qt.UserRole+3).toString()       
            rootAssetpath =  eeePast.data(QtCore.Qt.UserRole+1).toString()       
            rootAssetName =  eeePast.data().toString()
            item = self.treeModel.itemFromIndex(eeePast)
            if idType!="5":
                rootAssetpathName = rootAssetpath+"/"+rootAssetName+"/maya"
            else:                
                rootAssetpathName = rootAssetpath+"/"+rootAssetName
            #print "rootAssetpathName: " + rootAssetpathName
            #print "rootAssetpathName: " + rootAssetpathName + "  name0: " + nameOfSelected
            name = findAssetName(nameOfSelected)
            if name is not None:
                #print "name: " + name
                global dateCur
                global fileCur
                fileCur = ""
                dateCur = QtCore.QDateTime
        
                def recDateTime(path):   
                    global dateCur
                    global fileCur
                    dir = QtCore.QDir()
                    dir.setPath(path)
                    strList = dir.entryInfoList(QtCore.QDir.AllEntries.__or__(QtCore.QDir.NoDotAndDotDot))
                    for i in strList:
                        if i.isFile():
                            #print "ffff0: " + i.baseName()[0:len(name)]                             
                            #print "ffff: " + findAssetName(i.baseName()[0:len(name)])
                            if findAssetName(i.baseName()) == name and ( i.suffix() == "ma" or i.suffix() == "mb"):
                                #print i.filePath() + "   " + i.suffix()
                                if i.lastModified() > dateCur:
                                    #print (i.baseName()+"  "+str(i.lastModified()))
                                    fileCur = i.filePath()
                                    dateCur = i.lastModified()
                        if i.isDir(): 
                            #print (i.filePath())
                            recDateTime(i.filePath())
                            
                recDateTime(rootAssetpathName)
                #print "FIND FILE: " + fileCur
                chasty = fileCur[len(rootAssetpathName)+1:]
                chasty = chasty.split("/")
                estPodVersion=0
                i = 0
                while i < chasty.count():
                    nul = re.search("_v[0-9]{3}",chasty[i])
                    if nul is not None:
                        estPodVersion=chasty[i]
                        #print "estPodVersion: "+chasty[i]
                        chasty[i] = re.sub("_v[0-9]{3}","",str(chasty[i]))
                    x=0
                    while x != -1:
                        nextItem = item.child(x,0)
                        if nextItem is None: break
                        if nextItem.data(QtCore.Qt.DisplayRole).toString() == chasty[i]:
                                self.treeView.selectionModel().select(self.treeModel.indexFromItem(nextItem),QtGui.QItemSelectionModel.Clear.__or__(QtGui.QItemSelectionModel.Toggle))        
                                self.activeTreeCellCliked(self.treeModel.indexFromItem(nextItem))
                                #print nextItem.data(QtCore.Qt.DisplayRole).toString()+"    "+chasty[i]
                                self.treeView.expand(self.treeModel.indexFromItem(nextItem))
                                item=nextItem
                                break
                        x=x+1
                    i=i+1
                if estPodVersion:
                    itemList = self.listModel.invisibleRootItem()
                    z=0
                    while z != -1:
                        nextItemList = itemList.child(z,0)
                        if nextItemList is None: break
                        #print nextItemList.data(QtCore.Qt.UserRole+1).toString()+"  "+nextItemList.data(QtCore.Qt.UserRole).toString()+"  "+nextItemList.data(QtCore.Qt.UserRole+2).toString()+"  "+nextItemList.data(QtCore.Qt.UserRole+3).toString()+"  "+nextItemList.data(QtCore.Qt.UserRole+4).toString()
                        if nextItemList.data(QtCore.Qt.UserRole+4).toString() == estPodVersion:
                            #print "XXXXXX:  "+nextItemList.data(QtCore.Qt.UserRole+4).toString() +"   "+ estPodVersion
                            self.listView.selectionModel().select(self.listModel.indexFromItem(nextItemList),QtGui.QItemSelectionModel.Clear.__or__(QtGui.QItemSelectionModel.Toggle))        
                            break
                        z=z+1
                #print "FIND FILE: " + fileCur        
    
            

    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.curProject = settings.value("project", "1").toInt()
        self.curType = settings.value("type", "1").toInt()
        self.curRoot = settings.value("root", "0").toInt()        
        self.twoLineEdit.setText(codecs.encode(settings.value("findString", "%").toString(), 'utf-8'))
        self.splitter.restoreState(settings.value("OpenSplitter").toByteArray())

        self.expandItem=settings.value("expandItem", "").toString().split(",")
        self.selectItemt=settings.value("selectItemt", "-1").toString()
        
        self.resize(size)
        self.move(pos)
        self.oneCombobox.setCurrentIndex(self.curProject[0])
        self.fourCombobox.setCurrentIndex(self.curType[0])
        self.fiveCombobox.setCurrentIndex(self.curRoot[0])
       
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", OSTYPE+"/").toString()
        settings.endGroup()

    def saveDirectoryName(self, item):
        i=0
        while i != -1:
            eeewPast = item.child(i,0)
            if eeewPast is None: break
            if self.treeView.isExpanded(self.treeModel.indexFromItem(eeewPast)): 
                self.expandItem.append(eeewPast.data(QtCore.Qt.UserRole+2).toString())
                self.saveDirectoryName(eeewPast)
            i=i+1

    def loadDirectoryName(self, item):
        i=0
        while i != -1:
            eeewPast = item.child(i,0)
            if eeewPast is None: break
            if self.selectItemt!="": 
                if QtCore.QString.compare(self.selectItemt, eeewPast.data(QtCore.Qt.UserRole+2).toString(), QtCore.Qt.CaseInsensitive)==0: 
                    self.treeView.setCurrentIndex(self.treeModel.indexFromItem(eeewPast))
                    self.activeTreeCellCliked(self.treeModel.indexFromItem(eeewPast))
            for j in range(0,self.expandItem.count()):
                if QtCore.QString.compare(self.expandItem[j], eeewPast.data(QtCore.Qt.UserRole+2).toString())==0:
                    self.treeView.expand(self.treeModel.indexFromItem(eeewPast))
                    self.expandItem.takeAt(j)
                    self.loadDirectoryName(eeewPast)
                    break
            i=i+1

    def writeSettings(self):
        if self.isLoad:
            self.expandItem.clear()
            self.saveDirectoryName(self.treeModel.invisibleRootItem())
            for f in self.expandItem:
                #print f
                pass
            if len(self.treeView.selectionModel().selectedRows()): self.selectItemt=self.treeView.selectionModel().selectedRows()[0].data(QtCore.Qt.UserRole+2).toString()
            
            settings = QtCore.QSettings("Melnitsa Soft", "Yago")
            settings.setValue("posMayaApp", self.pos())
            settings.setValue("sizeMayaApp", self.size())
            settings.setValue("project", self.oneCombobox.currentIndex())
            settings.setValue("expandItem", self.expandItem.join(","))
            settings.setValue("selectItemt", self.selectItemt)
            settings.setValue("type", self.fourCombobox.currentIndex())        
            settings.setValue("root", self.fiveCombobox.currentIndex())        
            settings.setValue("findString", self.twoLineEdit.text())
            settings.setValue("OpenSplitter", self.splitter.saveState())
            chekStat = 0
        

class assetData():
    
    def __init__( self ):
        self.historyDataState = False
        self.history = []
        self.leaf = ""
        self.rdata = []
        self.new = False
        self.setData( cmds.file( query=True, sceneName=True ))
            
    def setData( self, filename ):
        self.data = []
        if filename != "":
            self.filename = filename
            self.name = self.filename.split( "/" )[-1]
            self.cname = "".join(re.split( "_v[0-9]+", self.name ))
            self.directory = self.name.join( self.filename.split( self.name )[:-1] )  
            self.path = ""
            m_buffer = self.directory.split( "/" )
            if re.findall( "(/|)[Ww][Oo][Rr][Kk](/|)", m_buffer[-2] ):
                self.path = os.path.join( "/".join( m_buffer[:-2] ) + "/", self.cname.split( "." )[0] + ".js" )
            else: 
                self.path = os.path.join( self.directory, self.cname.split( "." )[0] + ".js" )
            self.leaf = self.path.split( "/" )[-2]
            if not os.path.isfile( self.path ):
                m_file = file( self.path, "w" )
                json.dump( self.data, m_file, indent=4, ensure_ascii=False )
                m_file.close()
            self.updateData()
            if self.leaf not in self.history:
                self.history.append( self.leaf )
        else:
            self.new = True
            if self.historyDataState is True:
                self.history.append( "" )
        return self.data

    def updateData( self ):
        self.file = open( self.path ).read()
        self.data = json.loads( self.file )
        return self.data
        
    def writeData( self ):
        m_file = open( self.path, "w" )
        json.dump( self.data, m_file, indent=4, ensure_ascii=False )
        m_file.close()
        return self.path
    
    def readData( self ):
        return self.data
    
    def setHistoryDataState( self, state ):
        self.historyDataState = state
    
    def readHistoryData( self ):
        return [ self.history[i] for i in range( 0, len( self.history )) if self.history[i] != self.leaf ]
    
    def appendData( self, scene="", name="", user="", date="", comment="", dataType="" ):
        m_data = { "filename": scene, "name": name, "user": user, "date": date, "comments": comment, "references": self.referenceData(), "history": self.readHistoryData(), "new": self.new, "dataType": dataType } 
        self.data.append( m_data )
        return self.data
    
    def referenceData( self ):
        def referenceData_exec( reference, level ):
            if cmds.referenceQuery( reference, isLoaded=True ):
                m_level = []
                level.append( { "name":reference, "reference":m_level } )
                m_childs = cmds.referenceQuery( reference, child=True, rfn=True )
                if m_childs:
                    for i in range( 0, len( m_childs )):
                        referenceData_exec( m_childs[i], m_level )
        if not self.rdata:
            m_rdata = []
            m_cache = cmds.file( query=True, reference=True )
            m_references = []
            for i in range( 0, len( m_cache )):
                try:
                    m_references.append( cmds.referenceQuery( m_cache[i], rfn=True ))
                except:
                    try:
                        m_references.append( cmds.file( m_cache[i], query=True, rfn=True ))
                    except:
                        continue
            for i in range( 0, len(m_references) ):
                referenceData_exec( m_references[i], m_rdata )
            self.rdata = m_rdata
        return self.rdata
    
    def listFileData( self ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "filename" in m_keys:
                m_result.append( self.data[i]["filename"] )
        return m_result
    
    def readFileData( self, filename ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "filename" in m_keys:
                if self.data[i]["filename"] == filename:
                    m_result.append( self.data[i] )
        return m_result
    
    def listReferenceData( self ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "name" in m_keys and "references" in m_keys:
                m_cache = self.data[i]["references"]
                if m_cache:
                    m_result.append( self.data[i]["name"] )
        return m_result
    
    def readReferenceData( self, name ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "name" in m_keys and "references" in m_keys:
                if self.data[i]["name"] == name:
                    m_cache = self.data[i]["references"]
                    if m_cache:
                        m_result.append( m_cache )
        return m_result
    
    def warningData( self ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "name" in m_keys and "history" in m_keys:
                m_cache = self.data[i]["history"]
                if m_cache:
                    m_result.append( self.data[i]["name"] )
        return m_result
    
    def cleanWarningData( self ):
        m_result = []
        for i in range( 0, len( self.data )):
            m_keys = self.data[i].keys()
            if "name" in m_keys and "history" in m_keys:
                m_cache = self.data[i]["history"]
                if m_cache:
                    for i in range( len( m_cache )-1, -1, -1 ):
                        m_cache.pop(i)
                    m_result.append( self.data[i]["name"] )
        return m_result

#melnik_setup.mOd = Window()
#melnik_setup.mOd.exec_()
#cursor.close()    
#conn.close()

f = Window()
f.show()
f.load()