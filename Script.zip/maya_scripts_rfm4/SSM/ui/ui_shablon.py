import maya.cmds as cmds
import time
import sip
import re
import os
import sys
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import ml_reference
import shutil
import glob
reload( ml_reference )

globaljobBatchContextLE = ""

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )
    
class Window( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( Window, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.isLoad=False
        self.setProperty( "index", "Shablon" )
        self.loaded=[]
        
    def load( self ):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect( self.currentWidgetSlot )        
        self.tabWidget.setStyleSheet( "QTabWidget{background: rgb(68,68,68);}" )
        self.CMW = cameraManagerWidget()
        self.tabWidget.addTab( self.CMW, "Camera manager" )
        self.mainlayout.addWidget( self.tabWidget )
        self.readSettings()
        self.isLoad = True

    def currentWidgetSlot( self, wi ):
        if wi not in self.loaded:
            self.tabWidget.widget( wi ).load()
            self.loaded.append( wi )

    def readSettings( self ):
        settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
        settings.beginGroup("ShablonTabDialog")
        pos = settings.value("posMayaApp", QtCore.QPoint( 200, 200 )).toPoint()
        self.move( pos )        
        size = settings.value( "sizeMayaApp", QtCore.QSize( 400, 400 )).toSize()
        self.resize( size )
        pos = settings.value( "tabWidget", "0" ).toInt()
        self.tabWidget.setCurrentIndex( pos[0] )
        settings.endGroup()
        
    def writeSettings( self ):
        if self.isLoad:
            settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
            settings.beginGroup( "ShablonTabDialog" )
            settings.setValue( "posMayaApp", self.pos())
            settings.setValue( "sizeMayaApp", self.size())
            settings.setValue( "tabWidget", self.tabWidget.currentIndex())
            settings.setValue( "globaljobBatchContextLE", globaljobBatchContextLE )        
            settings.endGroup()              
            for i in range( 0, self.tabWidget.count()):
                if hasattr( self.tabWidget.widget(i), 'writeSettings' ):
                    self.tabWidget.widget( i ).writeSettings()

    def closeEvent( self, event ):
        self.writeSettings()
        event.accept()

class cameraManagerWidget( QtGui.QWidget ):
    
    def __init__( self, parent=getMayaWindow()):
        super( cameraManagerWidget, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        self.setProperty( "index" , "References" )
        self.isLoad=False
    
    def load( self ):
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainWidgetLayout.setContentsMargins( 2,2,2,2 )
        #Project.
        self.m_projectWidget = QtGui.QWidget()
        self.m_projectWidget.setMaximumHeight( 40 )
        self.m_projectLayout = QtGui.QGridLayout()
        self.m_projectWidget.setLayout( self.m_projectLayout )
        self.m_projectLabel = QtGui.QLabel( "Scene project:" )
        self.m_projectLayout.addWidget( self.m_projectLabel, 0, 0 )
        project = self.getTmplateDirectory()
        self.m_projectEditLine = QtGui.QLineEdit( project )
        self.m_projectLayout.addWidget( self.m_projectEditLine, 0, 1 )
        self.m_changeProjectButton = QtGui.QPushButton( "" )
        self.m_changeProjectButton.setIcon( self.style().standardIcon(QtGui.QStyle.SP_DialogOpenButton) )
        self.m_changeProjectButton.setToolTip( "Change camera project directory" )
        self.m_changeProjectButton.released.connect( self.changeProject )
        self.m_projectLayout.addWidget( self.m_changeProjectButton, 0, 2 )
        self.m_refreshCameraButton = QtGui.QPushButton( "" )
        self.m_refreshCameraButton.released.connect( self.refreshFileList )
        self.m_refreshCameraButton.setToolTip( "Refresh" )
        self.m_refreshCameraButton.setIcon( self.style().standardIcon(QtGui.QStyle.SP_BrowserReload) )
        self.m_projectLayout.addWidget( self.m_refreshCameraButton, 0, 3 )
        self.mainWidgetLayout.addWidget( self.m_projectWidget )
        #Selection list.
        self.m_splitter = QtGui.QSplitter()
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        #self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.SingleSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setMinimumWidth( 200 )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.treeMainModel = QtGui.QStandardItemModel()
        self.m_selectionListTree.setModel( self.treeMainModel )
        self.m_selectionListTree.setHeaderHidden( True )
        #List actions fiels.
        self.m_selectionListActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_selectionListActionLayout = QtGui.QVBoxLayout()
        self.m_selectionListActionLayout.setContentsMargins( 0,0,0,0 )
        self.m_selectionListActionLayout.setAlignment( QtCore.Qt.AlignTop )
        self.data = []
        self.m_actionListReferenceGroupBox = QtGui.QGroupBox( "" )
        self.m_actionListReferenceLayout = QtGui.QGridLayout()
        self.m_actionListReferenceLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionListReferenceGroupBox.setLayout( self.m_actionListReferenceLayout )
        #Controls.
        self.m_editCameraButton = QtGui.QPushButton( "Load" )
        self.m_editCameraButton.setToolTip( "Import selected file with cameras and replace \"cameras_grp\"" )
        self.m_editCameraButton.released.connect( self.importCamera )
        self.m_editCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_editCameraButton )
        self.m_saveSelectedCameraButton = QtGui.QPushButton( "Save" )
        self.m_saveSelectedCameraButton.setToolTip( "Export \"cameras_grp\" group to selected file" )
        self.m_saveSelectedCameraButton.released.connect( self.exportCamera )
        self.m_saveSelectedCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_saveSelectedCameraButton )
        
        self.m_importAllCameraButton = QtGui.QPushButton( "Import episode cameras" )
        self.m_importAllCameraButton.setToolTip( "Import all cameras for current episode" )
        self.m_importAllCameraButton.released.connect( self.importEpisodeCameras )
        self.m_importAllCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_importAllCameraButton )
        
        self.m_updateAllCameraButton = QtGui.QPushButton( "Update episode cameras" )
        self.m_updateAllCameraButton.setToolTip( "Update all cameras for current episode by last used cameras" )
        self.m_updateAllCameraButton.released.connect( self.updateEpisodeCameras )
        self.m_updateAllCameraButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_actionListReferenceLayout.addWidget( self.m_updateAllCameraButton )
        
        self.m_selectionListActionLayout.addWidget( self.m_actionListReferenceGroupBox )
        self.m_selectionListActionsGroupBox.setLayout( self.m_selectionListActionLayout )
        self.m_splitter.addWidget( self.m_selectionListActionsGroupBox )
        self.m_splitter.addWidget( self.m_selectionListTree )
        #Settings
        self.mainWidgetLayout.addWidget( self.m_splitter )
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        self.isLoad = True
        self.refreshFileList()
        
    def importCamera( self ):
        paths = self.getSelected()
        if paths:
            path = paths[-1]
            group = cmds.ls( "cameras_grp", assemblies=True )
            if group:
                self.removeCamera()
            path = path.replace( "\\", "/" )
            fileTypeShort = path.split( "." )[-1]
            fileType = fileTypeShort == "mb" and "mayaBinary" or "mayaAscii"
            fileName = path.split( "/" )[-1].split( "." )[0]
            namespace = fileName.split( "_v" )[0]
            nodes = cmds.file( path, type=fileType, options="v=0", ignoreVersion=True, force=True, namespace=namespace, i=True, returnNewNodes=True, mergeNamespacesOnClash=True )
            for i in range( len( nodes )-1,-1,-1 ):
                if re.findall( "cameras_grp$", nodes[i] ):
                    name = nodes[i].split( ":" )[-1]
                else:
                    sname = nodes[i].split( "|" )[-1]
                    name = ":".join( sname.split( ":" )[-2:])
                nodes[i] = cmds.rename( nodes[i], name )
            assemblies = cmds.ls( nodes, assemblies=True )
            if not cmds.ls( "cameras_grp", assemblies=True ):
                group = cmds.createNode( "transform", n="cameras_grp" )
                cmds.parent( assemblies, group )
            return True
        
    def importEpisodeCameras( self ):
        rootFolder = ""
        sceneName = cmds.file( query=True, sceneName=True )
        projectDir = str( self.m_projectEditLine.text())
        if re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", sceneName ):
            rootFolder = self.getEpisodeDirectory( sceneName, folder="cameras/" )
        elif re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", projectDir ):
            if os.path.isdir( projectDir ):
                rootFolder = self.getEpisodeDirectory( sceneName, folder="cameras/" )
        if rootFolder != "":
            group = cmds.ls( "cameras_grp", assemblies=True )
            if not group:
                group = cmds.createNode( "transform", n="cameras_grp" )
            else:
                group = group[-1]
            cameras = os.listdir( rootFolder )
            for camera in cameras:
                path = os.path.join( rootFolder, camera )
                path = path.replace( "\\", "/" )
                fileTypeShort = path.split( "." )[-1]
                fileType = fileTypeShort == "mb" and "mayaBinary" or "mayaAscii"
                fileName = path.split( "/" )[-1].split( "." )[0]
                namespace = fileName.split( "_v" )[0]
                nodes = cmds.file( path, type=fileType, options="v=0", ignoreVersion=True, force=True, namespace=namespace, i=True, returnNewNodes=True, mergeNamespacesOnClash=True )
                assemblies = cmds.ls( nodes, assemblies=True )
                if assemblies:
                    childs = cmds.listRelatives( assemblies, children=True, fullPath=True )
                    cmds.parent( childs, group )
                    cmds.delete( assemblies )
        else:
            print "Failed to find cameras directory"
        
    def updateEpisodeCameras( self ):
        rootFolder = ""
        sceneName = cmds.file( query=True, sceneName=True )
        projectDir = str( self.m_projectEditLine.text())
        if re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", sceneName ):
            rootFolder = self.getEpisodeDirectory( sceneName, folder="" )
        elif re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", projectDir ):
            if os.path.isdir( projectDir ):
                rootFolder = self.getEpisodeDirectory( projectDir, folder="" )
        if rootFolder != "":
            camFolder = os.path.join( rootFolder, "cameras/" )
            if not os.path.isdir( camFolder ):
                os.mkdir( camFolder )
            scenes = os.listdir( rootFolder )
            for scene in scenes:
                if re.findall( "ep[0-9]+sc[0-9]+", scene, re.IGNORECASE ):
                    scenepath = os.path.join( rootFolder, scene )
                    tmppath = os.path.join( scenepath, "tmplate/" )
                    if os.path.isdir( tmppath ):
                        cameras = os.listdir( tmppath )
                        cameras = [ os.path.join( tmppath, camera ) for camera in cameras if re.findall( scene + "_cam.m[ab]", camera ) ]
                        if cameras:
                            last = max( cameras, key=os.path.getmtime )
                            last = last.replace( "\\", "/" )
                            lastname = last.split( "/" )[-1]
                            try:
                                campath = os.path.join( camFolder, lastname )
                                campath = campath.replace( "\\", "/" )
                                print "update camera %s from %s" % ( campath, last )
                                if os.path.isfile( campath ):
                                    os.remove( campath )
                                shutil.copy2( last, campath ) 
                            except:
                                print "Failed to update camera -", last, campath
        
    def restoreLastVersion( self ):
        rootFolder = ""
        sceneName = cmds.file( query=True, sceneName=True )
        projectDir = str( self.m_projectEditLine.text())
        if re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", sceneName ):
            rootFolder = self.getEpisodeDirectory( sceneName, folder="" )
        elif re.findall( "/ep[0-9]+/ep[0-9]+sc[0-9]+.*", projectDir ):
            if os.path.isdir( projectDir ):
                rootFolder = self.getEpisodeDirectory( projectDir, folder="" )
        if rootFolder != "":
            print "root:", rootFolder
            scenes = os.listdir( rootFolder )
            for scene in scenes:
                if re.findall( "ep[0-9]+sc[0-9]+", scene, re.IGNORECASE ):
                    scenepath = os.path.join( rootFolder, scene )
                    tmppathwork = os.path.join( scenepath, "tmplate/work" )
                    tmppath = os.path.join( scenepath, "tmplate/" )
                    if os.path.isdir( tmppathwork ):
                        cameras = os.listdir( tmppathwork )
                        cameras = [ os.path.join( tmppathwork, camera ) for camera in cameras if re.findall( scene + "_cam_v[0-9]+.m[ab]", camera ) ]
                        if cameras:
                            last = max( cameras, key=os.path.getmtime )
                            last = last.replace( "\\", "/" )
                            lastName = last.split( "/" )[-1]
                            lastName = re.sub( "_v[0-9]+", "", lastName )
                            try:
                                campath = os.path.join( tmppath, lastName )
                                campath = campath.replace( "\\", "/" )
                                print "restore: %s from %s" % ( campath, last )
                                shutil.copy2( last, campath ) 
                            except:
                                print "Failed to restore camera -", last, campath
        
    def referenceCamera( self ):
        paths = self.getSelected()
        if paths:
            path = paths[-1]
            fileTypeShort = path.split( "." )[-1]
            fileType = fileTypeShort == "mb" and "mayaBinary" or "mayaAscii"
            fileName = path.split( "/" )[-1].split( "." )[0]
            nodes = cmds.file( path, type=fileType, options="v=0", ignoreVersion=True, force=True, namespace=fileName, r=True, returnNewNodes=True, mergeNamespacesOnClash=True )
            assemblies = cmds.ls( nodes, assemblies=True )
            if not cmds.ls( "cameras_locked_grp", assemblies=True ):
                group = cmds.createNode( "transform", n="cameras_locked_grp" )
                cmds.parent( assemblies, group )
            return True
    
    def exportCamera( self, path="" ):
        if path == "":
            path = self.getSelectedRoot()
        if path:
            group = cmds.ls( "cameras_grp", assemblies=True )
            if group:
                nodes = cmds.listRelatives( group, allDescendents=True, fullPath=True )
                if nodes:
                    sequencers = cmds.ls( type="sequencer" )
                    #references = []
                    #for node in nodes:
                        #if cmds.referenceQuery( node, isNodeReferenced=True ):
                            #rfn = cmds.referenceQuery( node, filename=True )
                            #if rfn not in references:
                                #references.append( rfn )
                    #if references:
                        #for reference in references:
                            #cmds.file( reference, importReference=True )
                    work = path.split( "/" )[:-1]
                    work = "/".join( work ) + "/work/"
                    fileTypeShort = path.split( "." )[-1]
                    name = path.split( "/" )[-1].split( "." )[0]
                    if not os.path.isdir( work ):
                        os.mkdir( work )
                    files = glob.glob( work + name + "_v*." + fileTypeShort )
                    if os.path.isfile( path ):
                        if not files:
                            self.makeVersion( path )
                    cmds.select( group )
                    if sequencers:
                        cmds.select( sequencers, add=True )
                    fileTypeShort = path.split( "." )[-1]
                    fileType = fileTypeShort == "mb" and "mayaBinary" or "mayaAscii"
                    cmds.file( path, force=True, options="v=0;", type=fileType, pr=False, es=True )
                    self.makeVersion( path )
                else:
                    cmds.error( "cameras_grp is empty" )
                    
    def getEpisodeDirectory( self, path, folder="" ):
        result = ""
        expression = re.compile( "(.*/ep[0-9]+/)ep[0-9]+sc[0-9]+.*/", re.IGNORECASE )
        ep = expression.findall( path )
        if ep:
            ep = ep[-1]
            if os.path.isdir( ep ):
                result = os.path.join( ep, folder )
        return result
                    
    def makeVersion( self, path="" ):
        if path and path != "":
            fileTypeShort = path.split( "." )[-1]
            work = path.split( "/" )[:-1]
            work = "/".join( work ) + "/work/"
            name = path.split( "/" )[-1].split( "." )[0]
            if not os.path.isdir( work ):
                os.mkdir( work )
            files = glob.glob( work + name + "_v*." + fileTypeShort )
            if files:
                lastFile = max( files )
                lastVersion = re.findall( "_(?:ver|v)([0-9]+)", lastFile )
                if lastVersion:
                    lastVersion = lastVersion[-1]
                nextVersion = str( int( lastVersion ) + 1 )
                nextName = work + name + "_v" + ( "0" * ( 3 - len( nextVersion ))) + nextVersion + "." + fileTypeShort
            else:
                nextName = work + name + "_v001." + fileTypeShort
            shutil.copy2( path, nextName )
            camdir = self.getEpisodeDirectory( path, folder="cameras/" )
            if camdir:
                if not os.path.isdir( camdir ):
                    os.mkdir( camdir )
                name = path.split( "/" )[-1]
                campath = os.path.join( camdir, name )
                print "copy to camera", campath
                try:
                    if os.path.isfile( campath ):
                        os.remove( campath )
                    shutil.copy2( path, campath )
                except:
                    print "failed to copy camera"
            print "Camera saved", nextName
            
    def needSaveTo( self ):
        result = ""
        group = cmds.ls( "cameras_grp", assemblies=True )
        if group:
            content = cmds.listRelatives( group, allDescendents=True, fullPath=True )
            if content:
                project = self.getTmplateDirectory()
                if "tmplate" in project:
                    shortname = cmds.workspace(query=True,shortName=True).split( "/" )[-1]
                    globpath = os.path.join( project, shortname + "*_cam.m[ab]" )
                    files = glob.glob( globpath )
                    if files:
                        final = max( files, key=os.path.getmtime )
                        final = final.replace( "\\", "/" )
                    else:
                        final = os.path.join( project, shortname + "_cam.mb" )
                        final = final.replace( "\\", "/" )
                    if self.cameraIsModified():
                        result = final
        return result 

    def autoSaveCamera( self, path="" ):
        if path == "":
            path = self.needSaveTo()
        if path:
            self.exportCamera( path )
                
    def cameraIsModified( self ):
        boolean = False
        content = cmds.ls( "cameras_grp", dag=True, long=True )        
        if content:
            connections = cmds.listConnections( content )
            if connections:
                content = content + connections
        modified = cmds.dgmodified()
        if modified:
            for modify in modified:
                if modify in content:
                    boolean = True
                    break
        return boolean
    
    def getTmplateDirectory( self ):
        expression = re.compile("^(/renderserver/Project/)|(/mnt/renderserver/)|(P:/)|(/home/.*/Project/)|(D:/Work/Project/)|(//renderserver/Project/)", re.IGNORECASE)
        OSTYPE = sys.platform
        if OSTYPE == "win32":
                OSTYPE="//Server-3d/Project/"
        else:
                OSTYPE="/Server-3d/Project/"
        project = cmds.workspace( query=True, rootDirectory=True )
        project = expression.sub( OSTYPE, project )
        temp = os.path.join( project, "tmplate" )
        if os.path.isdir( temp ):
            project = temp
        return project
            
    def removeCamera( self ):
        group = cmds.ls( "cameras_grp", assemblies=True )
        if group:
            nodes = cmds.listRelatives( group, allDescendents=True, fullPath=True )
            references = []
            importers = []
            if nodes:
                for node in nodes:
                    if cmds.referenceQuery( node, isNodeReferenced=True ):
                        filename = cmds.referenceQuery( node, filename=True )
                        if filename not in references:
                            references.append( filename )
                    else:
                        importers.append( node )
            if references:
                for reference in references:
                    cmds.file( reference, removeReference=True )
            if importers:
                for importer in importers:
                    if cmds.objExists( importer ):
                        cmds.delete( importer )
            cmds.delete( group )
        
    def changeProject( self ):
        directory = cmds.workspace( query=True, rootDirectory=True )
        path = cmds.fileDialog2( caption="Project", startingDirectory=directory, dialogStyle=1, fm=3 )
        if path:
            path = type( path ) is list and path[0] or path
            path = "/".join( path.split( "\\" ))
            self.m_projectEditLine.setText( path )
            self.refreshFileList()
        return path

    def refreshFileList( self ):
        self.removeAllContent()
        directory = str( self.m_projectEditLine.text())
        expr = re.compile( "(cam|camera|cams|cam_ver[0-9]+|cams_ver[0-9]+|camera_ver[0-9]+|cam_v[0-9]+)(.ma$|.mb$)", re.IGNORECASE )
        if os.path.isdir( directory ):
            files = os.listdir( directory )
            for i in range( 0, len( files )):
                if expr.findall( files[i] ):
                    if directory[-1] == "/":
                        self.addContent( os.path.join( directory, "/" + files[i] ))
                    else:
                        self.addContent( os.path.join( directory + "/", files[i] ))
        else:
            print "%s is not exists." % directory
            return None
    
    def listVersions( self, filename ):
        result = []
        fileTypeShort = filename.split( "." )[-1]
        work = filename.split( "/" )[:-1]
        work = "/".join( work ) + "/work/"
        name = filename.split( "/" )[-1].split( "." )[0]
        if os.path.isdir( work ):
            files = glob.glob( work + name + "_v*." + fileTypeShort )
            if files:
                result = files
        return result
    
    def addContent( self, filename ):
        filename = filename.replace( "\\", "/" )
        root = self.treeMainModel.invisibleRootItem()
        name = ( filename.split( "/" )[-1]).split( "." )[0]
        date = time.ctime(os.path.getmtime( filename ))
        if filename not in self.data:
            item = QtGui.QStandardItem( filename )
            item.setData( "",QtCore.Qt.UserRole + 1 )
            item.setData( date, QtCore.Qt.UserRole + 2 )
            item.setData( name, QtCore.Qt.UserRole + 3 )
            item.setData( "", QtCore.Qt.UserRole + 4 )
            item.setData( "", QtCore.Qt.UserRole + 5 )
            item.setData( "", QtCore.Qt.UserRole + 6 )
            item.setToolTip( "Last camera version" )
            root.appendRow( item )
            self.data.append( filename )
            versions = self.listVersions( filename )
            if versions:
                for version in versions:
                    self.addVersionContent( version, item )
            
    def addVersionContent( self, filename, parent ):
        filename = filename.replace( "\\", "/" )
        name = ( filename.split( "/" )[-1]).split( "." )[0]
        date = time.ctime(os.path.getmtime( filename ))
        parentName = parent.data( QtCore.Qt.DisplayRole ).toString()
        parentName = str( parentName )
        if filename not in self.data:
            item = QtGui.QStandardItem( filename )
            item.setData( "",QtCore.Qt.UserRole + 1 )
            item.setData( date, QtCore.Qt.UserRole + 2 )
            item.setData( name, QtCore.Qt.UserRole + 3 )
            item.setData( "", QtCore.Qt.UserRole + 4 )
            item.setData( "", QtCore.Qt.UserRole + 5 )
            item.setData( "", QtCore.Qt.UserRole + 6 )
            parent.appendRow( item )
            self.data.append( filename )
    
    def getSelected( self ):
        result = []
        indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( indexes )):
            temp = indexes[i].data().toString()
            temp = str( temp )
            if temp not in result:
                result.append( temp )
        return result
    
    def getSelectedRoot( self ):
        root = self.treeMainModel.invisibleRootItem()
        indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        if indexes:
            index = indexes[-1]
            item = self.treeMainModel.itemFromIndex( index )
            parent = item.parent()
            if parent == root or not parent:
                temp = item.data( QtCore.Qt.DisplayRole ).toString()
                temp = str( temp )
                return temp
            else:
                temp = parent.data( QtCore.Qt.DisplayRole ).toString()
                temp = str( temp )
                return temp
    
    def removeContent( self ):
        selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( selected )-1, -1, -1):
            path = selected[i].data().toString()
            self.treeMainModel.removeRow( selected[i].row() )
            if path in self.data:
                self.data.pop( self.data.index( path ))
            
    def removeAllContent( self ):
        self.treeMainModel.removeRows( 0, self.treeMainModel.rowCount())
        self.data = []

class confirmLoop( QtGui.QDialog ):
    def __init__(self, parent=None):
        super(confirmLoop, self).__init__(parent)
        
    def load( self, label="", text="" ):
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 2,2,2,2 )        
        self.setWindowTitle( label )
        self.label=QtGui.QLabel( text )
        self.HLayout = QtGui.QHBoxLayout()
        self.executeButton = QtGui.QPushButton( "Yes" )
        self.executeButton.released.connect( self.executeSlot )
        self.continueButton = QtGui.QPushButton( "No" )
        self.continueButton.released.connect( self.continueSlot )  
        self.breakButton = QtGui.QPushButton( "Cancel" )
        self.breakButton.released.connect( self.breakSlot )
        self.HLayout.addWidget( self.executeButton )
        self.HLayout.addWidget( self.continueButton )
        self.HLayout.addWidget( self.breakButton )
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout)
        
    def executeSlot( self ):
        self.done(1)
        
    def continueSlot( self ):
        self.done(2)

    def breakSlot( self ):
        self.done(3)

class listDelegate( QtGui.QItemDelegate ):
    
    def __init__( self, parent=None ):
        super(listDelegate, self).__init__( parent )
        self.mult = 1
                            
    def createEditor( self, parent, option, index ):
        editor = QtGui.QSpinBox( parent )
        editor.setMinimum( 0 )
        editor.setMaximum( 100 )
        return editor
    
    def setEditorData( self, spinBox, index ):
        value = index.model().data( index, QtCore.Qt.EditRole )
        spinBox.setValue(value)
        
    def setModelData( self, spinBox, model, index ):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData( index, value, QtCore.Qt.EditRole )
        
    def updateEditorGeometry( self, editor, option, index ):
        editor.setGeometry( option.rect )
        
    def sizeHint( self, option, index ):
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize( 11 )
        myFontMetrics = QtGui.QFontMetrics( myFont )
        mySize = myFontMetrics.boundingRect( 0,0, 260, 0,( QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft ), index.data( QtCore.Qt.DisplayRole ).toString() )     
        return QtCore.QSize( mySize.width(), mySize.height() + 40 )
    
    def paint( self, painter, option, index ):
        painter.save()
        painter.setRenderHint( QtGui.QPainter.Antialiasing )
        newMetr = QtGui.QFontMetrics( painter.font() )
        heit = newMetr.height() + 15   
        gradient = QtGui.QLinearGradient( option.rect.x() + option.rect.width() / 2, option.rect.y(), option.rect.x() + option.rect.width() / 2, option.rect.y() + option.rect.height() )
        gradient.setColorAt( 0.01, option.palette.base().color() )
        gradient.setColorAt( 0.02, option.palette.window().color() )
        gradient.setColorAt( 0.98,option.palette.window().color() )
        gradient.setColorAt( 0.99, option.palette.base().color() )
        brush = QtGui.QBrush( gradient )
        painter.fillRect( option.rect,brush )
        if sys.platform == "win32":
            painter.setCompositionMode( QtGui.QPainter.CompositionMode_Multiply )
            gradient2 = QtGui.QLinearGradient( option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height() )
            gradient2.setColorAt( 0, QtGui.QColor(255,255,255))
            gradient2.setColorAt( 1, QtGui.QColor(200,200,200))
            brush2 = QtGui.QBrush( gradient2 )
            painter.fillRect( option.rect,brush2 )
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
            gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
            gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
            brush3 = QtGui.QBrush(gradient3)
            painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
            gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
            gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
            brush4 = QtGui.QBrush(gradient4)
            painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
        textSize = index.data(QtCore.Qt.UserRole+5).toString()
        one_widthSize = painter.fontMetrics().width(textSize)
        painter.drawText( option.rect.x()+option.rect.width()-one_widthSize-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textSize)
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-6-one_widthSize,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
        text = index.data(QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)   
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore()