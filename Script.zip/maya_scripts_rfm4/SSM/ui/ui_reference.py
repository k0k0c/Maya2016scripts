import maya.cmds as cmds
import maya.mel as mel
import sip
import re
import os
import sys
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import maya.OpenMaya as om
import ml_reference
import ui_referenceEditor
reload( ui_referenceEditor )
reload( ml_reference )

globaljobBatchContextLE = ""

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )
    
class Window( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( Window, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.isLoad=False
        self.setProperty( "index", "References" )
        self.loaded=[]
        
    def load( self ):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect( self.currentWidgetSlot )        
        self.tabWidget.setStyleSheet( "QTabWidget{background: rgb(68,68,68);}" )
        self.RMW = referenceManagerSettingsWidget()
        self.tabWidget.addTab( self.RMW, "References manager" )
        self.RSW = referenceSetSettingsWidget()
        self.tabWidget.addTab( self.RSW, "References sets" )
        self.RE = ui_referenceEditor.referenceEditor()
        self.tabWidget.addTab( self.RE, "References editor ( beta )" )
        self.mainlayout.addWidget( self.tabWidget )
        self.readSettings()
        self.isLoad = True

    def currentWidgetSlot( self, wi ):
        if wi not in self.loaded:
            self.tabWidget.widget( wi ).load()
            self.loaded.append( wi )

    def readSettings( self ):
        settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
        settings.beginGroup("ReferencesTabDialog")
        pos = settings.value("posMayaApp", QtCore.QPoint( 200, 200 )).toPoint()
        self.move( pos )        
        size = settings.value( "sizeMayaApp", QtCore.QSize( 400, 400 )).toSize()
        self.resize( size )
        pos = settings.value( "tabWidget", "0" ).toInt()
        self.tabWidget.setCurrentIndex( pos[0] )
        settings.endGroup()
        
    def writeSettings( self ):
        if self.isLoad:
            settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
            settings.beginGroup( "ReferencesTabDialog" )
            settings.setValue( "posMayaApp", self.pos())
            settings.setValue( "sizeMayaApp", self.size())
            settings.setValue( "tabWidget", self.tabWidget.currentIndex())
            settings.setValue( "globaljobBatchContextLE", globaljobBatchContextLE )        
            settings.endGroup()              
            for i in range( 0, self.tabWidget.count()):
                if hasattr( self.tabWidget.widget(i), 'writeSettings' ):
                    self.tabWidget.widget( i ).writeSettings()

    def closeEvent( self, event ):
        self.writeSettings()
        event.accept()

class referenceSetSettingsWidget( QtGui.QWidget ):
    
    def __init__( self, parent=getMayaWindow()):
        super( referenceSetSettingsWidget, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        self.setProperty( "index" , "References" )
        self.isLoad=False
    
    def load( self ):
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainWidgetLayout.setContentsMargins( 4,4,4,4 )
        #Selection list.
        self.m_splitter = QtGui.QSplitter()
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListTree.setModel( self.m_selectionListModel )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_splitter.addWidget( self.m_selectionListTree )
        self.m_selectionListActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_selectionListActionLayout = QtGui.QGridLayout()
        self.m_selectionListActionLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_selectionListActionLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        #Save set settings.]
        self.m_saveSettingsGroupBox = QtGui.QGroupBox( "" )
        self.m_saveSettingsLayout = QtGui.QVBoxLayout()
        self.m_saveSettingsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_saveSettingsGroupBox.setLayout( self.m_saveSettingsLayout )
        self.m_selectionListActionLayout.addWidget( self.m_saveSettingsGroupBox )
        self.m_dopNameWidget = QtGui.QWidget()
        self.m_m_dopNameWidgetLayout = QtGui.QGridLayout()
        self.m_m_dopNameWidgetLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_dopNameWidget.setLayout( self.m_m_dopNameWidgetLayout )
        self.m_saveSettingsLayout.addWidget( self.m_dopNameWidget )
        self.m_saveSceneWidgetCheckBox = QtGui.QCheckBox( "Save scene" )
        self.m_saveSceneWidgetCheckBox.setToolTip( "Save scene after creating new reference set." )
        self.m_m_dopNameWidgetLayout.addWidget( self.m_saveSceneWidgetCheckBox, 1, 0 )
        self.m_dopNameWidgetEdit = QtGui.QLineEdit( "" )
        self.m_dopNameWidgetEdit.setToolTip( "User specified dop name for reference set." )
        self.m_dopNameWidgetEdit.setMaximumHeight( 32 )
        self.m_m_dopNameWidgetLayout.addWidget( self.m_dopNameWidgetEdit, 1, 1 )
        self.m_saveSettingsLayout.addWidget( self.m_dopNameWidget )
        self.m_saveButton = QtGui.QPushButton( "Save" )
        self.m_saveButton.setToolTip( "Create new reference set." )
        self.m_saveButton.released.connect( self.ml_SaveSet )
        self.m_saveSettingsLayout.addWidget( self.m_saveButton )
        self.m_loadSettingsGroupBox = QtGui.QGroupBox( "" )
        self.m_loadSettingsLayout = QtGui.QVBoxLayout()
        self.m_loadSettingsGroupBox.setLayout( self.m_loadSettingsLayout )
        self.m_selectionListActionLayout.addWidget( self.m_loadSettingsGroupBox )
        self.m_loadWidget = QtGui.QWidget()
        self.m_loadWidgetLayout = QtGui.QGridLayout()
        self.m_loadWidgetLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_loadWidget.setLayout( self.m_loadWidgetLayout )
        self.m_loadSettingsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_loadSettingsLayout.addWidget( self.m_loadWidget )
        self.m_unloadRefWidgetCheckBox = QtGui.QCheckBox( "Fast mode" )
        self.m_unloadRefWidgetCheckBox.setToolTip( "Load selected reference set, without unloading other references." )
        self.m_unloadRefWidgetCheckBox.setMaximumWidth( 90 )
        self.m_loadWidgetLayout.addWidget( self.m_unloadRefWidgetCheckBox, 0, 0 )
        self.m_loadButton = QtGui.QPushButton( "Load" )
        self.m_loadButton.setToolTip( "Load selected reference set." )
        self.m_loadButton.released.connect( self.ml_LoadSet )
        self.m_loadWidgetLayout.addWidget( self.m_loadButton, 0, 1 )
        self.m_deleteActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_deleteActionsLayout = QtGui.QVBoxLayout()
        self.m_deleteActionsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_deleteActionsGroupBox.setLayout( self.m_deleteActionsLayout )
        self.m_selectionListActionLayout.addWidget( self.m_deleteActionsGroupBox )
        self.m_deleteWidget = QtGui.QWidget()
        self.m_deleteWidgetLayout = QtGui.QGridLayout()
        self.m_deleteWidgetLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_deleteWidget.setLayout( self.m_deleteWidgetLayout )
        self.m_deleteActionsLayout.addWidget( self.m_deleteWidget )
        self.m_deleteProtectWidgetCheckBox = QtGui.QCheckBox( "Are you sure?" )
        self.m_deleteProtectWidgetCheckBox.setToolTip( "Do you want to remove selected reference set?" )
        self.m_deleteProtectWidgetCheckBox.setMaximumWidth( 90 )
        self.m_deleteProtectWidgetCheckBox.setStyleSheet("QCheckBox{ font-weight: bold; font-size: 10px; color: rgb( 118, 124, 128 ); }")
        self.m_deleteWidgetLayout.addWidget( self.m_deleteProtectWidgetCheckBox, 0, 0 )
        self.m_removeButton = QtGui.QPushButton( "Delete" )
        self.m_removeButton.setToolTip( "Remove selected reference set." )
        self.m_removeButton.released.connect( self.ml_removeContent )
        #self.m_removeButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_deleteWidgetLayout.addWidget( self.m_removeButton, 0, 1 )
        self.m_removeButton.setEnabled( False )
        
        self.m_advancedModeCheckBox = QtGui.QCheckBox( "Advanced options" )
        self.m_selectionListActionLayout.addWidget( self.m_advancedModeCheckBox )
        self.m_advancedModeCheckBox.toggled.connect( self.switchAdvancedMode )
        
        self.m_advancedModeGroupBox = QtGui.QGroupBox( "" )
        self.m_advancedModeLayout = QtGui.QVBoxLayout()
        self.m_advancedModeLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_advancedModeGroupBox.setLayout( self.m_advancedModeLayout )
        self.m_selectionListActionLayout.addWidget( self.m_advancedModeGroupBox )
        
        self.m_exportButton = QtGui.QPushButton( "Export" )
        self.m_exportButton.setToolTip( "Export reference sets to file." ) 
        self.m_exportButton.released.connect( self.ml_exportSets )
        self.m_exportButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_advancedModeLayout.addWidget( self.m_exportButton )
        self.m_importButton = QtGui.QPushButton( "Import" )
        self.m_importButton.setToolTip( "Import reference sets from file." )
        self.m_importButton.released.connect( self.ml_importSets )
        self.m_importButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_advancedModeLayout.addWidget( self.m_importButton )
        
        self.connect( self.m_deleteProtectWidgetCheckBox, QtCore.SIGNAL( "stateChanged( int )" ), self.m_removeButton.setEnabled )
        self.m_selectionListActionsGroupBox.setLayout( self.m_selectionListActionLayout )
        self.m_splitter.addWidget( self.m_selectionListActionsGroupBox )
        #Settings
        self.mainWidgetLayout.addWidget( self.m_splitter )
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        self.isLoad = True
        self.ml_updateContent( "perspShape" )
        self.switchAdvancedMode()
        
    def switchAdvancedMode( self ):
        if self.m_advancedModeCheckBox.isChecked():
            self.m_advancedModeGroupBox.setVisible( True )
        else:
            self.m_advancedModeGroupBox.setVisible( False )
        
    def ml_updateContent( self, node ):
        self.m_sets = ml_reference.listReferenceSets( "perspShape" )
        self.ml_removeAllContent()
        for i in range( 0, len( self.m_sets )):
            self.ml_addContent( self.m_sets[i].split( "referenceSet_" )[-1] )
    
    def ml_addContent( self, referenceSet ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_referenceSet = type( referenceSet ) is list and referenceSet or [ referenceSet ]
        for i in range( 0, len( m_referenceSet )):
            m_item = QtGui.QStandardItem( m_referenceSet[i] )
            m_list.appendRow( m_item )
    
    def ml_getSelected( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            m_temp = m_indexes[i].data().toString()
            m_temp = str( m_temp )
            if m_temp not in m_result:
                m_result.append( m_temp )
        return m_result
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            m_name = m_selected[i].data().toString()
            ml_reference.removeReferenceSet( "perspShape", "referenceSet_" + str( m_name ))
            self.m_selectionListModel.removeRow( m_selected[i].row())
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
        
    def ml_LoadSet( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            m_name = m_selected[i].data().toString()
            m_referenceList = ml_reference.readReferenceSet( "perspShape", str( m_name ))
            if m_referenceList:
                m_fast = self.m_unloadRefWidgetCheckBox.checkState()
                m_fast = not m_fast and True or False
                ml_reference.loadReferences( m_referenceList, unloadUnused=m_fast )
    
    def ml_SaveSet( self ):
        ml_reference.makeReferenceSet( "perspShape", name=str( self.m_dopNameWidgetEdit.text()))
        self.ml_updateContent( "perspShape" )
        if self.m_saveSceneWidgetCheckBox.checkState():
            cmds.file( save=True, force=True )
    
    def ml_importSets( self ):
        m_directory = cmds.workspace( query=True, rootDirectory=True )
        m_path = cmds.fileDialog2( caption="Import reference sets", startingDirectory=m_directory, dialogStyle=1, fm=1, fileFilter="Reference sets (*.set)" )
        if m_path:
            m_path = m_path[0]
            ml_reference.makeReferenceSet( "perspShape", name=str( self.m_dopNameWidgetEdit.text()), fromFile=m_path)
            self.ml_updateContent( "perspShape" )
    
    def ml_exportSets( self ):
        m_directory = cmds.workspace( query=True, rootDirectory=True )
        m_path = cmds.fileDialog2( caption="Export reference sets", startingDirectory=m_directory, dialogStyle=1, fm=0, fileFilter="Reference sets (*.set)" )
        if m_path:
            m_path = m_path[0]
            m_path = m_path.split( "." )[0]+".set"
            ml_reference.exportReferenceSet( "perspShape", m_path )

class referenceManagerSettingsWidget( QtGui.QWidget ):
    
    def __init__( self, parent=getMayaWindow()):
        super( referenceManagerSettingsWidget, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        self.setProperty( "index" , "References" )
        self.isLoad=False
    
    def load( self ):
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainWidgetLayout.setContentsMargins( 2,2,2,2 )
        #self.m_hideSelectionListButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 76, 76, 76 ); }")
        #Selection list.
        self.m_splitter = QtGui.QSplitter()
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setMinimumWidth( 200 )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListTree.setModel( self.m_selectionListModel )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_selectionListActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_selectionListActionLayout = QtGui.QVBoxLayout()
        self.m_selectionListActionLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.m_selectionListActionLayout.setContentsMargins( 2, 2, 2, 2 )
        self.m_selectionModeComboBox = QtGui.QComboBox()
        self.m_selectionModeComboBox.setToolTip( "Reference selection mode." )
        self.m_selectionModeComboBoxList = QtCore.QStringList()
        self.m_selectionModeComboBoxList.append( "Outliner" )
        self.m_selectionModeComboBoxList.append( "Selected references" )
        self.m_selectionModeComboBoxList.append( "All references" )
        self.m_selectionModeComboBox.addItems( self.m_selectionModeComboBoxList )
        self.m_selectionListActionLayout.addWidget( self.m_selectionModeComboBox )
        self.m_data = []
        #List actions fiels.
        self.m_actionListReferenceGroupBox = QtGui.QGroupBox( "" )
        self.m_actionListReferenceLayout = QtGui.QGridLayout()
        self.m_actionListReferenceLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionListReferenceGroupBox.setLayout( self.m_actionListReferenceLayout )
        self.m_selectionListActionLayout.addWidget( self.m_actionListReferenceGroupBox )
        self.m_findReferenceGroupBox = QtGui.QWidget()
        self.m_findReferenceLayout = QtGui.QGridLayout()
        self.m_findReferenceLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_findReferenceGroupBox.setLayout( self.m_findReferenceLayout )
        self.m_findReferenceTextEdit = QtGui.QLineEdit( "" )
        self.m_findReferenceTextEdit.setToolTip( "Regular expression text field." )
        self.m_findReferenceTextEdit.setMaximumHeight( 32 )
        self.m_findReferenceLayout.addWidget( self.m_findReferenceTextEdit, 0, 0 )
        self.findReferenceRefButton = QtGui.QPushButton( "Find" )
        self.findReferenceRefButton.setToolTip( "Find reference by user specified regular expression." )
        self.findReferenceRefButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.findReferenceRefButton.released.connect( self.ml_findReferences )
        self.m_findReferenceLayout.addWidget( self.findReferenceRefButton, 0, 1 )
        self.m_animationEnCheckBox = QtGui.QCheckBox( "Animation" )
        self.m_animationEnCheckBox.setToolTip( "List all reference from viewport with animation." )
        self.m_animationEnCheckBox.setMaximumHeight( 32 )
        self.m_findReferenceLayout.addWidget( self.m_animationEnCheckBox, 1, 0 )
        self.m_addViewportRefButton = QtGui.QPushButton( "Viewport" )
        self.m_addViewportRefButton.setToolTip( "List all reference from viewport." )
        self.m_addViewportRefButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_addViewportRefButton.released.connect( self.ml_getVisibleReferences )
        self.m_findReferenceLayout.addWidget( self.m_addViewportRefButton, 1, 1 )
        self.m_actionListReferenceLayout.addWidget( self.m_findReferenceGroupBox )
        self.m_labelAddReferenceRelatives = QtGui.QLabel( "Relatives:" )
        self.m_labelAddReferenceRelatives.setFrameStyle( QtGui.QFrame.HLine )
        self.m_labelAddReferenceRelatives.setFrameShadow( QtGui.QFrame.Raised )
        self.m_actionListReferenceLayout.addWidget( self.m_labelAddReferenceRelatives )
        self.m_AddChildsCheckbox = QtGui.QCheckBox( "Childs" )
        self.m_AddChildsCheckbox.setToolTip( "List all reference childs." )
        self.m_actionListReferenceLayout.addWidget( self.m_AddChildsCheckbox )
        self.m_AddParentsCheckbox = QtGui.QCheckBox( "Parents")
        self.m_AddParentsCheckbox.setToolTip( "List all reference parents." )
        self.m_actionListReferenceLayout.addWidget( self.m_AddParentsCheckbox )
        self.m_AddToSelectionListButton = QtGui.QPushButton( "Add" )
        self.m_AddToSelectionListButton.setToolTip( "Add selected reference from outliner." )
        self.m_AddToSelectionListButton.released.connect( self.ml_addFromOutliner )
        self.m_actionListReferenceLayout.addWidget( self.m_AddToSelectionListButton )
        self.m_RemoveFromSelectionListButton = QtGui.QPushButton( "Remove" )
        self.m_RemoveFromSelectionListButton.setToolTip( "Remove reference from selection list." )
        self.m_RemoveFromSelectionListButton.released.connect( self.ml_removeContent )
        self.m_actionListReferenceLayout.addWidget( self.m_RemoveFromSelectionListButton )
        self.m_ClearFromSelectionListButton = QtGui.QPushButton( "Clean" )
        self.m_ClearFromSelectionListButton.setToolTip( "Remove all references from selection list." )
        self.m_ClearFromSelectionListButton.released.connect( self.ml_removeAllContent )
        self.m_actionListReferenceLayout.addWidget( self.m_ClearFromSelectionListButton )
        self.m_SelectFromSelectionListButton = QtGui.QPushButton( "Select content" )
        self.m_SelectFromSelectionListButton.setToolTip( "Select content from selected reference." )
        self.m_SelectFromSelectionListButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_SelectFromSelectionListButton.released.connect( self.ml_selectReferenceContent )
        self.m_actionListReferenceLayout.addWidget( self.m_SelectFromSelectionListButton )
        #Reference statement buttons.
        self.m_referenceStatementGroupBox = QtGui.QGroupBox( "" )
        self.m_referenceStatementLayout = QtGui.QVBoxLayout()
        self.m_referenceStatementLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_referenceStatementGroupBox.setLayout( self.m_referenceStatementLayout )
        self.m_widgetUnLoadMode = QtGui.QWidget()
        self.m_layoutUnLoadMode = QtGui.QGridLayout()
        self.m_layoutUnLoadMode.setContentsMargins( 0, 0, 0, 0 )
        self.m_widgetUnLoadMode.setLayout( self.m_layoutUnLoadMode )
        self.m_referenceStatementLayout.addWidget( self.m_widgetUnLoadMode )
        self.m_unloadInvertCheckbox = QtGui.QCheckBox( "invert" )
        self.m_unloadInvertCheckbox.setToolTip( "Unload only not selected references." )
        self.m_unloadInvertCheckbox.setMaximumWidth( 50 )
        self.m_layoutUnLoadMode.addWidget( self.m_unloadInvertCheckbox, 0, 0 )
        self.m_unloadRefButton = QtGui.QPushButton( "Unload" )
        self.m_unloadRefButton.setToolTip( "Unload selected reference." )
        self.m_unloadRefButton.released.connect( self.ml_unloadReferences )
        self.m_layoutUnLoadMode.addWidget( self.m_unloadRefButton, 0, 1 )
        self.m_switchProxyRefButton = QtGui.QPushButton( "Switch" )
        self.m_switchProxyRefButton.setToolTip( "Switch reference to next avalaible proxy." )
        self.m_switchProxyRefButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_switchProxyRefButton.released.connect( self.ml_switchProxyNext )
        self.m_referenceStatementLayout.addWidget( self.m_switchProxyRefButton )
        self.m_loadRefButton = QtGui.QPushButton( "Load" )
        self.m_loadRefButton.setToolTip( "Load selected reference." )
        self.m_loadRefButton.released.connect( self.ml_loadReferences )
        self.m_referenceStatementLayout.addWidget( self.m_loadRefButton )
        self.m_widgetLoadMode = QtGui.QWidget()
        self.m_layoutLoadMode = QtGui.QGridLayout()
        self.m_layoutLoadMode.setContentsMargins( 0, 0, 0, 0 )
        self.m_widgetLoadMode.setLayout( self.m_layoutLoadMode )
        self.m_referenceStatementLayout.addWidget( self.m_widgetLoadMode )
        self.m_loadModeButtonLabel = QtGui.QLabel( "Mode:" )
        self.m_layoutLoadMode.addWidget( self.m_loadModeButtonLabel, 0, 0 )
        self.m_loadNoneButton = QtGui.QRadioButton( "None" )
        self.m_loadNoneButton.setToolTip( "Load no references." )
        self.m_layoutLoadMode.addWidget( self.m_loadNoneButton, 1, 0 )
        self.m_loadDefaultButton = QtGui.QRadioButton( "Default" )
        self.m_loadDefaultButton.setToolTip( "Load default references." )
        self.m_layoutLoadMode.addWidget( self.m_loadDefaultButton, 1, 1 )
        self.m_loadDefaultButton.setChecked( True )
        self.m_loadAllButton = QtGui.QRadioButton( "Full" )
        self.m_loadAllButton.setToolTip( "Load all references." )
        self.m_layoutLoadMode.addWidget( self.m_loadAllButton, 2, 0 )
        self.m_loadManualButton = QtGui.QRadioButton( "Top only" )
        self.m_loadManualButton.setToolTip( "Load only selected reference without nested references." )
        self.m_layoutLoadMode.addWidget( self.m_loadManualButton, 2, 1 )
        self.m_loadOriginalButton = QtGui.QRadioButton( "Original" )
        self.m_loadOriginalButton.setToolTip( "Load selected reference and all nested reference in original version." )
        self.m_layoutLoadMode.addWidget( self.m_loadOriginalButton, 3, 0 )
        self.m_loadProxyButton = QtGui.QRadioButton( "Proxy" )
        self.m_loadProxyButton.setToolTip( "Load selected reference and all nested reference in proxy version." )
        self.m_layoutLoadMode.addWidget( self.m_loadProxyButton, 3, 1 )
        self.m_selectionListActionLayout.addWidget( self.m_referenceStatementGroupBox )
        #Reference edits buttons.
        self.m_referenceEditsGroupBox = QtGui.QGroupBox( "Reference edits" )
        self.m_referenceEditsLayout = QtGui.QGridLayout()
        self.m_referenceEditsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_referenceEditsGroupBox.setLayout( self.m_referenceEditsLayout )
        self.m_showEditsRefButton = QtGui.QPushButton( "Show" )
        self.m_showEditsRefButton.setToolTip( "Show reference edits for selected references." )
        self.m_showEditsRefButton.released.connect( self.ml_listEditsReferences )
        self.m_referenceEditsLayout.addWidget( self.m_showEditsRefButton, 0, 0 )
        self.m_exportEditsRefButton = QtGui.QPushButton( "Export" )
        self.m_exportEditsRefButton.setToolTip( "Export reference edits from selected references." )
        self.m_exportEditsRefButton.released.connect( self.ml_exportEdits )
        self.m_referenceEditsLayout.addWidget( self.m_exportEditsRefButton, 0, 1 )
        self.m_cleaupEditsRefButton = QtGui.QPushButton( "Cleanup" )
        self.m_cleaupEditsRefButton.setToolTip( "Remove all edits from selected references, applied in current scene." )
        self.m_cleaupEditsRefButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_cleaupEditsRefButton.released.connect( self.ml_cleanUpReferences )
        self.m_referenceEditsLayout.addWidget( self.m_cleaupEditsRefButton, 1, 0 )
        self.m_openAdvancedEditsEditorButton = QtGui.QPushButton( "Editor" )
        self.m_openAdvancedEditsEditorButton.setToolTip( "Show advanced reference editor for selected references." )
        self.m_openAdvancedEditsEditorButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 78, 82, 85 ); }")
        self.m_openAdvancedEditsEditorButton.released.connect( self.ml_advancedReferenceEditsEditor )
        self.m_referenceEditsLayout.addWidget( self.m_openAdvancedEditsEditorButton, 1, 1 )
        self.m_selectionListActionLayout.addWidget( self.m_referenceEditsGroupBox )
        #Reference other buttons.
        self.m_referenceOtherGroupBox = QtGui.QGroupBox( "" )
        self.m_referenceOtherLayout = QtGui.QVBoxLayout()
        self.m_referenceOtherLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_referenceOtherGroupBox.setLayout( self.m_referenceOtherLayout )
        self.m_importRefButton = QtGui.QPushButton( "Import" )
        self.m_importRefButton.setToolTip( "Import selected references." )
        self.m_importRefButton.released.connect( self.ml_importReferences )
        self.m_referenceOtherLayout.addWidget( self.m_importRefButton )
        self.m_openRefButton = QtGui.QPushButton( "Open" )
        self.m_openRefButton.setToolTip( "Open selected reference in new maya window." )
        self.m_openRefButton.released.connect( self.ml_openReferenceInNewMaya )
        self.m_referenceOtherLayout.addWidget( self.m_openRefButton )
        self.m_removeRefButton = QtGui.QPushButton( "Remove" )
        self.m_removeRefButton.setToolTip( "Remove selected reference from current scene." )
        self.m_removeRefButton.released.connect( self.ml_removeReference )
        self.m_referenceOtherLayout.addWidget( self.m_removeRefButton )
        self.m_selectionListActionLayout.addWidget( self.m_referenceOtherGroupBox )
        self.m_selectionListActionsGroupBox.setLayout( self.m_selectionListActionLayout )
        self.m_splitter.addWidget( self.m_selectionListActionsGroupBox )
        self.m_splitter.addWidget( self.m_selectionListTree )
        #Settings
        self.mainWidgetLayout.addWidget( self.m_splitter )
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        self.isLoad = True
    
    def ml_getObjectsFromScreen( self, start=0, end=0 ):
        m_style = [ mui.M3dView.kBoundingBox, mui.M3dView.kFlatShaded, mui.M3dView.kGouraudShaded, mui.M3dView.kWireFrame, mui.M3dView.kPoints ]
        cmds.select( clear=True )
        if start == 0 and end == 0:
            start = int( cmds.currentTime( query=True ))
            end = start
        end = end + 1
        m_view = mui.M3dView.active3dView()
        m_style_id = m_view.displayStyle()
        m_view.setDisplayStyle( m_style[0] )
        for i in range( start, end ):
            cmds.currentTime( i )
            om.MGlobal.selectFromScreen( m_view.portWidth(), m_view.portHeight(), 0, 0, om.MGlobal.kAddToList )
        m_result = cmds.ls( sl=True )
        cmds.select( clear=True )
        m_view.setDisplayStyle( m_style[m_style_id] )
        return m_result               
    
    def ml_getVisibleReferences( self ):
        m_result = []
        if self.m_animationEnCheckBox.checkState():
            time = [ cmds.playbackOptions( query=True, animationStartTime=True ), cmds.playbackOptions( query=True, animationEndTime=True ) ]
        else:
            time = cmds.currentTime( query=True )
            time = [ time, time ]
        m_nodes = self.ml_getObjectsFromScreen( start=time[0], end=time[-1] )
        for i in range( 0, len( m_nodes )):
            if cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ):
                m_reference = cmds.referenceQuery( m_nodes[i], filename=True )
                m_rfn = cmds.referenceQuery( m_nodes[i], rfn=True )
                if m_reference not in m_result:
                    self.ml_addContent( m_reference )
                    if self.m_AddChildsCheckbox.checkState():
                        m_relatives = ml_reference.referenceRelatives( m_rfn, parents=False )
                        if m_relatives:
                            for r in range( 0, len( m_relatives )):
                                m_relatives_name = cmds.referenceQuery( m_relatives[r], filename=True )
                                self.ml_addContent( m_relatives_name )
                    if self.m_AddParentsCheckbox.checkState():
                        m_relatives = ml_reference.referenceRelatives( m_rfn, parents=True )
                        if m_relatives:
                            for r in range( 0, len( m_relatives )):
                                m_relatives_name = cmds.referenceQuery( m_relatives[r], filename=True )
                                self.ml_addContent( m_relatives_name )
        return m_result 
    
    def ml_exportEdits( self ):
        m_references = self.ml_getSelected()
        if m_references:
            m_directory = "/".join(cmds.fileDialog2( caption="Save edits", dialogStyle=1, fm=3 )[0].split("\\"))+"/"
            for i in range( 0, len( m_references )):
                m_node = self.ml_getCurrentReference( m_references[i] )
                m_filename = ( m_references[i].split( "/" )[-1] ).split( "." )[0]
                m_filename = m_filename.split( " " )[-1].split( ":" )[-1]
                m_path = os.path.join( m_directory, m_filename )
                cmds.exportEdits( m_path, includeNetwork=True, includeAnimation=True, includeShaders=True, includeSetAttrs=True, onReferenceNode=m_node, type="editMA" )
    
    def ml_advancedReferenceEditsEditor( self ):
        m_references = self.ml_getSelected()
        editsWindow = ReferenceEditsEditor()
        m_references_array = []
        for i in range( 0, len( m_references )):
            m_references_array.append( self.ml_getCurrentReference( m_references[i] ))
        editsWindow.setReferences( m_references_array )
        editsWindow.show()

    def ml_selectReferenceContent( self ):
        m_refences = self.ml_getSelected()
        m_nodes = []
        for i in range( 0, len( m_refences )):
            if cmds.referenceQuery( m_refences[i], isLoaded=True ):
                m_nodes = m_nodes + cmds.referenceQuery( m_refences[i],nodes=True, dagPath=True )
        if m_nodes:
            cmds.select( m_nodes )
    
    def ml_listEditsReferences( self ):
        m_references = self.ml_getSelected()
        for i in range( 0, len( m_references )):
            mel.eval("referenceEditsWindow \"%s\" false;" % m_references[i] )
    
    def ml_loadReferences( self ):
        m_result = []
        m_mode = self.m_loadNoneButton.isChecked() and "none" or self.m_loadDefaultButton.isChecked() and "default" or self.m_loadAllButton.isChecked() and "all" or self.m_loadManualButton.isChecked() and "topOnly" or self.m_loadOriginalButton.isChecked() and "original" or self.m_loadProxyButton.isChecked() and "proxy"
        m_references = self.ml_getSelected()
        for i in range( 0, len( m_references )):
            if cmds.objExists( m_references[i] ):
                m_namespace = self.ml_getCurrentReference( m_references[i] )
                if m_mode == "default":
                    cmds.file( loadReference=m_namespace )
                elif m_mode == "original":
                    ml_reference.loadContainer( m_namespace, 0 )
                elif m_mode == "proxy":
                    ml_reference.loadContainer( m_namespace, 1 )
                else:
                    cmds.file( loadReference=m_namespace, loadReferenceDepth=m_mode )
                m_result.append( m_references[i] )
        return m_result
    
    def ml_switchProxyNext( self ):
        m_result = []
        m_references = self.ml_getSelected()
        for i in range( 0, len( m_references )):
            if cmds.objExists( m_references[i] ):
                m_namespace = self.ml_getCurrentReference( m_references[i] )
                if m_namespace:
                    pm = cmds.listConnections( m_namespace, type="proxyManager" )
                    if pm:
                        m_proxy = cmds.listConnections( "%s.proxyList" % pm[0], type="reference" )
                        m_proxy = m_proxy and m_proxy or []
                    else:
                        m_proxy = []
                    if not pm or len( m_proxy )<2:
                        m_filename = cmds.referenceQuery( m_namespace, filename=True )
                        if m_filename:
                            m_filename = m_filename.split( "{" )[0]
                            m_proxy_filename = ml_reference.findReference( path=m_filename, expression="proxy|_proxy", force=True )
                            m_relatives = ml_reference.referenceRelatives( m_namespace, parents=True )
                            if m_proxy_filename and m_relatives and len( m_relatives ) < 2:
                                ml_reference.addReference( m_namespace, m_proxy_filename )
                            else:
                                print "%s has parent reference." % m_namespace
                                break
                    ml_reference.switchProxy( m_namespace )
                m_result.append( m_references[i] )
    
    def ml_cleanUpReferences( self ):
        m_references = self.ml_getSelected()
        for i in range( 0, len( m_references )):
            m_namespace = self.ml_getCurrentReference( m_references[i] )
            if m_namespace:
                ml_reference.cleanupReference( m_namespace )
    
    def ml_getCurrentReference( self, reference ):
        m_rfn = cmds.referenceQuery( reference, rfn=True )
        m_result = m_rfn
        m_connections = cmds.listConnections( m_rfn, type="proxyManager" )
        if m_connections:
            m_connections = cmds.listConnections( "%s.activeProxy" % m_connections[0], plugs=True )
            if m_connections:
                m_connections = cmds.listConnections( m_connections[0], type="reference" )
                if m_connections:
                    m_result = m_connections[0]  
        return m_result
    
    def ml_findReferences( self ):
        m_references = ml_reference.listReferences()
        m_expr = re.compile( "%s" % self.m_findReferenceTextEdit.text(), re.IGNORECASE )
        for i in range( 0, len( m_references )):
            if m_expr.findall( m_references[i] ):
                self.ml_addContent( m_references[i] )
    
    def ml_unloadReferences( self ):
        m_result = []
        m_selected = self.ml_getSelected()
        m_references = m_selected
        if self.m_unloadInvertCheckbox.checkState():
            m_unload = ml_reference.listReferences( referenceNodes=True )
            for i in range( 0, len( m_selected )):
                m_parents = ml_reference.referenceRelatives( m_selected[i], parents=True )
                if m_parents:
                    for p in range( 0, len( m_parents )):
                        m_references.append( m_parents[p] )
            m_references = [ m_unload[i] for i in range( 0, len( m_unload )) if m_unload[i] not in m_selected ]
        for i in range( 0, len( m_references )):
            if cmds.objExists( m_references[i] ) and  cmds.referenceQuery( m_references[i], isLoaded=True ):
                m_namespace = cmds.referenceQuery( m_references[i], rfn=True )
                if m_namespace:
                    m_proxyManager = cmds.listConnections( m_namespace, type="proxyManager" )
                    if m_proxyManager:
                        m_proxyList = cmds.listConnections( m_proxyManager, type="reference" )
                        if m_proxyList:
                            for p in range( 0, len( m_proxyList )):
                                if cmds.referenceQuery( m_proxyList[p], isLoaded=True ):
                                    cmds.file( unloadReference=m_proxyList[p] )
                    if cmds.referenceQuery( m_namespace, isLoaded=True ):
                        cmds.file( unloadReference=m_namespace )
                    m_result.append( m_references[i] )
        return m_result
    
    def ml_reloadReferences( self ):
        m_result = []
        m_references = self.ml_getSelected()
        for i in range(0, len( m_references )):
            if m_references[i] not in m_result:
                m_result.append( m_references[i] )
                m_namespace = cmds.referenceQuery( m_references[i], rfn=True )
                cmds.file( loadReference=m_namespace )
                
    def ml_openReferenceInNewMaya( self ):
        m_result = []
        m_references = self.ml_getSelected()
        for i in range(0, len( m_references )):
            if m_references[i] not in m_result:
                m_result.append( m_references[i] )
                m_namespace = cmds.referenceQuery( m_references[i], rfn=True )
                m_dialogLoop = confirmLoop()
                m_dialogLoop.load( label=m_namespace, text="Open this reference in new maya?" )
                m_bool = m_dialogLoop.exec_()
                if m_bool:
                    if m_bool == 1:
                        ml_reference.openReference( m_namespace )
                    elif m_bool == 2:
                        continue
                    else:
                        break
    
    def ml_removeReference( self ):
        m_references = self.ml_getSelected()
        if m_references:
            for i in range(0, len( m_references )):
                ml_reference.removeReference( m_references[i] )
    
    def ml_importReferences( self ):
        m_references = self.ml_getSelected()
        m_import = []
        m_result = []
        for i in range(0, len( m_references )):
            m_dialogLoop = confirmLoop()
            m_dialogLoop.load( label=m_references[i], text="Do you want to import this reference in the current scene?" )
            m_bool = m_dialogLoop.exec_()
            if m_bool:
                if m_bool == 1:
                    m_relatives = ml_reference.referenceRelatives( m_references[i], parents=True )
                    if m_relatives:
                        for r in range( 0, len( m_relatives )):
                            m_filename = cmds.referenceQuery( m_relatives[r], filename=True )
                            m_import.insert( 0, m_filename )
                elif m_bool == 2:
                    continue
                else:
                    break
        if m_import:
            for i in range( 0, len( m_import )):
                if m_import[i] not in m_result:
                    m_node = cmds.file( m_import[i], query=True, referenceNode=True )
                    pm = cmds.listConnections( m_node, type="proxyManager" )
                    m_proxy = []
                    if pm:
                        m_cache = cmds.listConnections( "%s.proxyList" % pm[0], type="reference" )
                        if m_cache:
                            for p in range( 0, len( m_cache )):
                                if m_cache[p] != m_node:
                                    m_name = cmds.referenceQuery( m_cache[p], filename=True )
                                    if m_name and m_name not in m_proxy:
                                        m_proxy.append( m_name ) 
                    cmds.file( m_import[i], importReference=True )
                    m_result.append( m_import[i] )
                    if m_proxy:
                        for p in range( 0, len( m_proxy )):
                            cmds.file( m_proxy[p], removeReference=True )
        return m_result
    
    def ml_addFromOutliner( self ):
        m_nodes = cmds.ls( sl=True, type=[ "mesh", "transform" ], long=True )
        for i in range( 0, len( m_nodes )):
            if cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ):
                m_reference = cmds.referenceQuery( m_nodes[i], filename=True )
                m_rfn = cmds.referenceQuery( m_nodes[i], rfn=True )
                self.ml_addContent( m_reference )
                if self.m_AddChildsCheckbox.checkState():
                    m_relatives = ml_reference.referenceRelatives( m_rfn, parents=False )
                    if m_relatives:
                        for r in range( 0, len( m_relatives )):
                            m_relatives_name = cmds.referenceQuery( m_relatives[r], filename=True )
                            self.ml_addContent( m_relatives_name )
                if self.m_AddParentsCheckbox.checkState():
                    m_relatives = ml_reference.referenceRelatives( m_rfn, parents=True )
                    if m_relatives:
                        for r in range( 0, len( m_relatives )):
                            m_relatives_name = cmds.referenceQuery( m_relatives[r], filename=True )
                            self.ml_addContent( m_relatives_name )
    
    def ml_addContent( self, reference ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_rfn = cmds.referenceQuery( reference, rfn=True )
        m_filename = cmds.referenceQuery( reference, filename=True )
        m_reference = str( reference )
        m_name = ( m_reference.split( "/" )[-1]).split( "." )[0]
        if m_reference not in self.m_data:
            m_item = QtGui.QStandardItem( m_filename )
            m_item.setData( "",QtCore.Qt.UserRole + 1 )
            m_item.setData( "", QtCore.Qt.UserRole + 2 )
            m_item.setData( m_name, QtCore.Qt.UserRole + 3 )
            m_item.setData( "", QtCore.Qt.UserRole + 4 )
            m_item.setData( "", QtCore.Qt.UserRole + 5 )
            m_item.setData( m_rfn, QtCore.Qt.UserRole + 6 )
            m_list.appendRow( m_item )
            self.m_data.append( m_reference )
    
    def ml_getSelected( self ):
        m_result = []
        mode = self.m_selectionModeComboBox.currentText()
        if mode == "Selected references":
            m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
            for i in range( 0, len( m_indexes )):
                m_temp = m_indexes[i].data( QtCore.Qt.UserRole + 6 ).toString()
                print m_temp
                m_temp = str( m_temp )
                if m_temp not in m_result:
                    m_result.append( m_temp )
        elif mode == "Outliner":
            m_nodes = cmds.ls( sl=True, type=[ "mesh", "transform" ], long=True )
            for i in range( 0, len( m_nodes )):
                if cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ):
                    m_reference = cmds.referenceQuery( m_nodes[i], rfn=True )
                    if m_reference not in m_result:
                        m_result.append( m_reference )
        else:
            for i in range( 0, self.m_selectionListModel.rowCount() ):
                m_reference = self.m_selectionListModel.item( i ).index()
                m_reference = str( m_reference.data( QtCore.Qt.UserRole + 6 ).toString())
                if m_reference not in m_result:
                    m_result.append( m_reference )
        return m_result
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            m_path = m_selected[i].data().toString()
            self.m_selectionListModel.removeRow( m_selected[i].row() )
            if m_path in self.m_data:
                self.m_data.pop( self.m_data.index( m_path ))
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
        self.m_data = []

class ReferenceEditsEditor( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( ReferenceEditsEditor, self ).__init__( parent )
        self.m_referenceNodes = []
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.m_splitter = QtGui.QSplitter()
        self.mainlayout.addWidget( self.m_splitter )
        self.m_editsListGroupBox = QtGui.QGroupBox( "Edits" )
        self.m_editsListLayout = QtGui.QVBoxLayout()
        self.m_editsListGroupBox.setLayout( self.m_editsListLayout )
        self.m_splitter.addWidget( self.m_editsListGroupBox )
        #Edits list view.
        self.m_filterWidget = QtGui.QWidget()
        self.m_filterLayout = QtGui.QGridLayout()
        self.m_filterLayout.setContentsMargins( 3,3,3,3 )
        self.m_filterWidget.setLayout( self.m_filterLayout )
        self.m_editsListLayout.addWidget( self.m_filterWidget )
        self.m_findEditsTextField = QtGui.QLineEdit( "" )
        self.m_findEditsTextField.setToolTip( "Regular expression field." )
        self.m_filterLayout.addWidget( self.m_findEditsTextField, 0, 0 )
        self.m_findEditsButton = QtGui.QPushButton( "Filter" )
        self.m_findEditsButton.setToolTip( "Filter edits by user specified regular expression." )
        self.m_findEditsButton.released.connect( self.ml_findReferenceEdits )
        self.m_findEditsButton.setMaximumWidth( 50 )
        self.m_filterLayout.addWidget( self.m_findEditsButton, 0, 1 )
        
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setMinimumWidth( 400 )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        
        self.m_selectionListModelProxy = QtGui.QSortFilterProxyModel()
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListModelProxy.setSourceModel( self.m_selectionListModel )
        
        self.m_selectionListTree.setModel( self.m_selectionListModelProxy )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_editsListLayout.addWidget( self.m_selectionListTree )
        self.m_actionEditsWidget = QtGui.QWidget()
        self.m_actionEditsLayout = QtGui.QGridLayout()
        self.m_actionEditsWidget.setLayout( self.m_actionEditsLayout )
        self.m_editsListLayout.addWidget( self.m_actionEditsWidget )
        self.m_removeEditsButton = QtGui.QPushButton( "Remove" )
        self.m_removeEditsButton.setToolTip( "Remove selected edits." )
        self.m_removeEditsButton.released.connect( self.ml_removeEdits )
        self.m_actionEditsLayout.addWidget( self.m_removeEditsButton, 0, 0 )
        self.m_refreshCurrentEditsButton = QtGui.QPushButton( "Refresh" )
        self.m_refreshCurrentEditsButton.setToolTip( "Refresh edits." )
        self.m_refreshCurrentEditsButton.released.connect( self.ml_refresh )
        self.m_actionEditsLayout.addWidget( self.m_refreshCurrentEditsButton, 0, 1 )
        self.setWindowTitle( "Reference edits editor" )
        
    def setReferences( self, referenceNodes ):
        self.m_referenceNodes = referenceNodes
        self.ml_removeAllContent()
        for i in range( 0, len( self.m_referenceNodes )):
            if cmds.objExists( self.m_referenceNodes[i] ) and cmds.nodeType( self.m_referenceNodes[i] ) == "reference" or cmds.referenceQuery( self.m_referenceNodes[i], isNodeReferenced=True ):
                self.ml_addContent( self.m_referenceNodes[i] )
    
    def ml_addContent( self, reference ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_edits = ml_reference.listReferenceEdits( reference )
        m_referenceFile = cmds.referenceQuery( reference, filename=True ) 
        for i in range( 0, len( m_edits )):
            #[ m_reference, m_content[c], m_levels[l][-1], m_levels[l][0], m_edits[e].split( " " )[0], m_edits[e] ]
            m_item = QtGui.QStandardItem( m_edits[i][-1] )
            m_item.setData( "", QtCore.Qt.UserRole + 1 )
            m_item.setData( m_edits[i][4], QtCore.Qt.UserRole + 2 )
            m_item.setData( m_edits[i][1].split( "|" )[-1], QtCore.Qt.UserRole + 3 )
            m_item.setData( "", QtCore.Qt.UserRole + 4 )
            m_item.setData( m_edits[i][2], QtCore.Qt.UserRole + 5 )
            m_item.setData( m_edits[i][1], QtCore.Qt.UserRole + 6 )
            m_item.setData( m_edits[i][0], QtCore.Qt.UserRole + 7 )
            m_item.setData( m_referenceFile, QtCore.Qt.UserRole + 8 )
            m_item.setData( m_edits[i][-1], QtCore.Qt.UserRole + 9 )
            m_list.appendRow( m_item )
    
    def ml_getSelected( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            m_temp = m_indexes[i].data().toString()
            m_temp = str( m_temp )
            if m_temp not in m_result:
                m_result.append( m_temp )
        return m_result
    
    def ml_refresh( self ):
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeEdits( self ):
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        m_strings = {}
        for i in range( 0, len( m_indexes )):
            m_keys = m_strings.keys()
            m_string = m_indexes[i].data( QtCore.Qt.UserRole + 9 ).toString()
            rfn = m_indexes[i].data( QtCore.Qt.UserRole + 7 ).toString()
            if rfn not in m_keys:
                m_strings.update( { rfn:[ m_string ] } )
            else:
                m_array = m_strings[rfn]
                m_array.append( m_string )
                m_strings.update( { rfn:m_array } )
        m_keys = m_strings.keys()
        for i in range( 0, len( m_keys )):
            m_array = m_strings[ m_keys[i] ]
            print "\nreference: %s\nremove: %s" % ( m_keys[i], m_array )
            ml_reference.removeEdits( m_keys[i], m_array )
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            self.m_selectionListModel.removeRow( m_selected[i].row() )
       
    def ml_findReferenceEdits( self ):
        self.m_selectionListModelProxy.setFilterRegExp( self.m_findEditsTextField.text())
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())

class confirmLoop( QtGui.QDialog ):
    def __init__(self, parent=None):
        super(confirmLoop, self).__init__(parent)
        
    def load( self, label="", text="" ):
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 2,2,2,2 )        
        self.setWindowTitle( label )
        self.label=QtGui.QLabel( text )
        self.HLayout = QtGui.QHBoxLayout()
        self.executeButton = QtGui.QPushButton( "Yes" )
        self.executeButton.released.connect( self.executeSlot )
        self.continueButton = QtGui.QPushButton( "No" )
        self.continueButton.released.connect( self.continueSlot )  
        self.breakButton = QtGui.QPushButton( "Cancel" )
        self.breakButton.released.connect( self.breakSlot )
        self.HLayout.addWidget( self.executeButton )
        self.HLayout.addWidget( self.continueButton )
        self.HLayout.addWidget( self.breakButton )
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout)
        
    def executeSlot( self ):
        self.done(1)
        
    def continueSlot( self ):
        self.done(2)

    def breakSlot( self ):
        self.done(3)

class listDelegate( QtGui.QItemDelegate ):
    
    def __init__( self, parent=None ):
        super(listDelegate, self).__init__( parent )
        self.mult = 1
                            
    def createEditor( self, parent, option, index ):
        editor = QtGui.QSpinBox( parent )
        editor.setMinimum( 0 )
        editor.setMaximum( 100 )
        return editor
    
    def setEditorData( self, spinBox, index ):
        value = index.model().data( index, QtCore.Qt.EditRole )
        spinBox.setValue(value)
        
    def setModelData( self, spinBox, model, index ):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData( index, value, QtCore.Qt.EditRole )
        
    def updateEditorGeometry( self, editor, option, index ):
        editor.setGeometry( option.rect )
        
    def sizeHint( self, option, index ):
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize( 11 )
        myFontMetrics = QtGui.QFontMetrics( myFont )
        mySize = myFontMetrics.boundingRect( 0,0, 260, 0,( QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft ), index.data( QtCore.Qt.DisplayRole ).toString() )     
        return QtCore.QSize( mySize.width(), mySize.height() + 40 )
    
    def paint( self, painter, option, index ):
        painter.save()
        painter.setRenderHint( QtGui.QPainter.Antialiasing )
        newMetr = QtGui.QFontMetrics( painter.font() )
        heit = newMetr.height() + 2   
        gradient = QtGui.QLinearGradient( option.rect.x() + option.rect.width() / 2, option.rect.y(), option.rect.x() + option.rect.width() / 2, option.rect.y() + option.rect.height() )
        gradient.setColorAt( 0.01, option.palette.base().color() )
        gradient.setColorAt( 0.02, option.palette.window().color() )
        gradient.setColorAt( 0.98,option.palette.window().color() )
        gradient.setColorAt( 0.99, option.palette.base().color() )
        brush = QtGui.QBrush( gradient )
        painter.fillRect( option.rect,brush )
        if sys.platform == "win32":
            painter.setCompositionMode( QtGui.QPainter.CompositionMode_Multiply )
            gradient2 = QtGui.QLinearGradient( option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height() )
            gradient2.setColorAt( 0, QtGui.QColor(255,255,255))
            gradient2.setColorAt( 1, QtGui.QColor(200,200,200))
            brush2 = QtGui.QBrush( gradient2 )
            painter.fillRect( option.rect,brush2 )
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
            gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
            gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
            brush3 = QtGui.QBrush(gradient3)
            painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
            gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
            gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
            brush4 = QtGui.QBrush(gradient4)
            painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
        textSize = index.data(QtCore.Qt.UserRole+5).toString()
        one_widthSize = painter.fontMetrics().width(textSize)
        painter.drawText( option.rect.x()+option.rect.width()-one_widthSize-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textSize)
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-6-one_widthSize,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
        text = index.data(QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)   
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore()