import maya.cmds as cmds
import re
import sip
import sys
import random
from PyQt4 import QtCore, QtGui

import maya.OpenMayaUI as mui

globaljobBatchContextLE = ""

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )

class Window( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( Window, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.isLoad=False
        self.setProperty( "index", "Modeling" )
        self.loaded=[]
        
    def load( self ):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect( self.currentWidgetSlot )        
        self.tabWidget.setStyleSheet( "QTabWidget{background: rgb(68,68,68);}" )
        self.DSW = deformationSettingsWidget()
        self.tabWidget.addTab( self.DSW, "Deformation" )
        self.mainlayout.addWidget( self.tabWidget )
        self.readSettings()
        self.isLoad = True

    def currentWidgetSlot( self, wi ):
        if wi not in self.loaded:
            self.tabWidget.widget( wi ).load()
            self.loaded.append( wi )

    def readSettings( self ):
        settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
        settings.beginGroup("ModelingTabDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint( 200, 200 )).toPoint()
        self.move( pos )        
        size = settings.value( "sizeMayaApp", QtCore.QSize( 400, 400 )).toSize()
        self.resize( size )
        pos = settings.value( "tabWidget", "0" ).toInt()
        self.tabWidget.setCurrentIndex( pos[0] )
        settings.endGroup()
        
    def writeSettings( self ):
        if self.isLoad:
            settings = QtCore.QSettings( "Melnitsa Soft", "Yago" )
            settings.beginGroup( "ModelingTabDialog" )
            settings.setValue( "posMayaApp", self.pos())
            settings.setValue( "sizeMayaApp", self.size())
            settings.setValue( "tabWidget", self.tabWidget.currentIndex())
            settings.setValue( "globaljobBatchContextLE", globaljobBatchContextLE )        
            settings.endGroup()              
            for i in range( 0, self.tabWidget.count()):
                if hasattr( self.tabWidget.widget(i), 'writeSettings' ):
                    self.tabWidget.widget( i ).writeSettings()

    def closeEvent( self, event ):
        self.writeSettings()
        event.accept()

class deformationSettingsWidget( QtGui.QWidget ):
    
    def __init__( self, parent=getMayaWindow()):
        super( deformationSettingsWidget, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.setLayout( self.mainlayout )
        self.setProperty( "index" , "Deformations" )
        self.isLoad=False
    
    def load( self ):
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable( True )
        self.mainScrollArea.setFocusPolicy( QtCore.Qt.NoFocus )
        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 0,0,0,0 )
        self.m_settingsBox = QtGui.QWidget()
        self.m_settingsLayout = QtGui.QHBoxLayout()
        self.m_settingsLayout.setSpacing( 0 )
        self.m_settingsLayout.setContentsMargins( 0,0,0,0 )
        self.m_settingsBox.setLayout( self.m_settingsLayout )
        self.m_hideSelectionListButton = QtGui.QPushButton( ">" )
        self.m_hideSelectionListButton.setMaximumWidth( 12 )
        self.m_hideSelectionListButton.setMinimumHeight( 50 )
        self.m_hideSelectionListButton.released.connect( self.ml_hideSelectionList )
        self.m_hideSelectionListButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 76, 76, 76 ); }")
        #self.splitter = QtGui.QSplitter()
        self.m_createOptionsLayout = QtGui.QGridLayout()
        self.m_createOptionsLayout.setContentsMargins( 2,2,2,2 )
        self.m_createOptionsGroupBox = QtGui.QGroupBox( "Deformation options: " )
        self.m_createOptionsGroupBox.setLayout( self.m_createOptionsLayout )
        self.m_createActionsLayout = QtGui.QHBoxLayout()
        self.m_createActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_createActionsGroupBox.setLayout( self.m_createActionsLayout )
        self.m_createActionsGroupBox.setMaximumHeight( 50 )
        #Selection list.
        self.m_selectionListGroupBox = QtGui.QGroupBox( "Selection list: " )
        self.m_selectionListLayout = QtGui.QHBoxLayout()
        self.m_selectionListLayout.setContentsMargins( 2,2,2,2 )
        self.m_selectionListGroupBox.setLayout( self.m_selectionListLayout )
        self.m_selectionListTree = QtGui.QTreeView()
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setMinimumWidth( 200 )
        self.m_selectionListTree.setSelectionMode( QtGui.QAbstractItemView.ExtendedSelection )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_selectionListModel = QtGui.QStringListModel()
        self.m_selectionListTree.setModel( self.m_selectionListModel )
        self.m_selectionListLayout.addWidget( self.m_selectionListTree )
        self.m_selectionListActionsGroupBox = QtGui.QGroupBox( "" )
        self.m_selectionListActionLayout = QtGui.QVBoxLayout()
        self.m_selectionListActionLayout.setContentsMargins( 2,2,2,2 )
        self.m_selectionListActionLayout.setAlignment( QtCore.Qt.AlignHCenter | QtCore.Qt.AlignTop )
        self.m_selectionModeComboBox = QtGui.QComboBox()
        self.m_selectionModeComboBoxList = QtCore.QStringList()
        self.m_selectionModeComboBoxList.append( "Outliner" )
        self.m_selectionModeComboBoxList.append( "Selected content" )
        self.m_selectionModeComboBoxList.append( "All content" )
        self.m_selectionModeComboBox.addItems( self.m_selectionModeComboBoxList )
        self.m_selectionListActionLayout.addWidget( self.m_selectionModeComboBox )
        self.m_AddToSelectionListButton = QtGui.QPushButton( "Add" )
        self.m_AddToSelectionListButton.released.connect( self.ml_addContent )
        self.m_selectionListActionLayout.addWidget( self.m_AddToSelectionListButton )
        self.m_RemoveFromSelectionListButton = QtGui.QPushButton( "Remove" )
        self.m_RemoveFromSelectionListButton.released.connect( self.ml_removeContent )
        self.m_selectionListActionLayout.addWidget( self.m_RemoveFromSelectionListButton )
        self.m_ClearFromSelectionListButton = QtGui.QPushButton( "Clear" )
        self.m_ClearFromSelectionListButton.released.connect( self.ml_removeAllContent )
        self.m_selectionListActionLayout.addWidget( self.m_ClearFromSelectionListButton )
        self.m_SelectFromSelectionListButton = QtGui.QPushButton( "Select" )
        self.m_SelectFromSelectionListButton.released.connect( self.ml_selectContent )
        self.m_selectionListActionLayout.addWidget( self.m_SelectFromSelectionListButton )
        self.m_selectionListActionsGroupBox.setLayout( self.m_selectionListActionLayout )
        self.m_selectionListLayout.addWidget( self.m_selectionListActionsGroupBox )
        #Settings.
        self.m_randomLayout = QtGui.QGridLayout()
        self.m_randomLayout.setContentsMargins( 3,3,3,3 )
        self.m_randomBox = QtGui.QGroupBox( "" )
        self.m_randomBox.setLayout( self.m_randomLayout )
        self.m_randomBox.setMaximumHeight( 100 )
        self.m_randomizeButton = QtGui.QPushButton( "Random" )
        self.m_randomLayout.addWidget( self.m_randomizeButton, 0, 0 )
        self.m_randomizeButton.released.connect( self.ml_randomizeSettings )
        self.m_randomizeButton = QtGui.QPushButton( "Apply seed" )
        self.m_randomLayout.addWidget( self.m_randomizeButton, 0, 1 )
        self.m_randomizeButton.released.connect( self.ml_randomizeSettings_arg )
        self.m_seedSpin = mySpinBox()
        self.m_seedSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_seedSpin.setRange( 0, sys.maxint - 100 )
        self.m_seed = random.randint( 0, sys.maxint - 100 )
        self.m_seedSpin.setValue( self.m_seed )
        self.m_randomLayout.addWidget( self.m_seedSpin, 0, 2 )
        self.m_presetComboBox = QtGui.QComboBox()
        self.m_presetComboBoxList = QtCore.QStringList()
        self.m_presetComboBoxList.append( "Default" )
        self.m_presetComboBoxList.append( "Medium" )
        self.m_presetComboBoxList.append( "low" )
        self.m_presetComboBox.addItems( self.m_presetComboBoxList )
        self.m_randomLayout.addWidget( self.m_presetComboBox, 0, 3 )
        self.m_createOptionsLayout.addWidget( self.m_randomBox, 2, 0 )
        #Base settings.
        self.m_baseLayout = QtGui.QGridLayout()
        self.m_baseLayout.setContentsMargins( 3,3,3,3 )
        self.m_baseBox = QtGui.QGroupBox( "" )
        self.m_baseBox.setLayout( self.m_baseLayout )
        self.m_baseEnvelopeLabel = QtGui.QLabel( "Envelope" )
        self.m_baseEnvelopeLabel.setMaximumWidth( 80 )
        self.m_baseLayout.addWidget( self.m_baseEnvelopeLabel, 0, 0 )
        self.m_baseEnvelopeMinSpin = myDoubleSpinBox()
        self.m_baseEnvelopeMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_baseEnvelopeMinSpin.setRange( 0, 100 )
        self.m_baseEnvelopeMinSpin.setValue( 100 )
        self.m_baseEnvelopeMaxSpin = myDoubleSpinBox()
        self.m_baseEnvelopeMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_baseEnvelopeMaxSpin.setRange( 0, 100 )
        self.m_baseEnvelopeMaxSpin.setValue( 100 )
        self.m_baseLayout.addWidget( self.m_baseEnvelopeMinSpin, 0, 1 )
        self.m_baseLayout.addWidget( self.m_baseEnvelopeMaxSpin, 0, 2 )
        self.m_baseRandomRotationLabel = QtGui.QLabel( "Angle offset" )
        self.m_baseRandomRotationLabel.setMaximumWidth( 80 )
        self.m_baseLayout.addWidget( self.m_baseRandomRotationLabel, 1, 0 )
        self.m_baseRandomRotationMinSpin = myDoubleSpinBox()
        self.m_baseRandomRotationMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_baseRandomRotationMinSpin.setRange( -360, 360 )
        self.m_baseRandomRotationMinSpin.setValue( 0 )
        self.m_baseRandomRotationMaxSpin = myDoubleSpinBox()
        self.m_baseRandomRotationMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_baseRandomRotationMaxSpin.setRange( -360, 360 )
        self.m_baseRandomRotationMaxSpin.setValue( 0 )
        self.m_baseLayout.addWidget( self.m_baseRandomRotationMinSpin, 1, 1 )
        self.m_baseLayout.addWidget( self.m_baseRandomRotationMaxSpin, 1, 2 )
        self.m_individualCreationOptions = QtGui.QCheckBox( "Individual deformations" )
        self.m_individualCreationOptions.setCheckState( True )
        self.m_baseLayout.addWidget( self.m_individualCreationOptions, 2, 0 )
        self.m_replacebaseOption = QtGui.QCheckBox( "Replace deformations" )
        self.m_replacebaseOption.setCheckState( True )
        self.m_baseLayout.addWidget( self.m_replacebaseOption, 3, 0 )
        self.m_hidebaseOption = QtGui.QCheckBox( "Hide deformations" )
        self.m_hidebaseOption.setCheckState( True )
        self.m_baseLayout.addWidget( self.m_hidebaseOption, 4, 0 )
        self.m_constraintbaseOption = QtGui.QCheckBox( "Constraint" )
        self.m_constraintbaseOption.setCheckState( True )
        self.m_baseLayout.addWidget( self.m_constraintbaseOption, 5, 0 )
        self.m_createOptionsLayout.addWidget( self.m_baseBox, 3, 0 )
        #Lattice settings.
        self.m_latticeLayout = QtGui.QGridLayout()
        self.m_latticeLayout.setContentsMargins( 3,3,3,3 )
        self.m_latticeBox = QtGui.QGroupBox( "Lattice: " )
        self.m_latticeBox.setCheckable( True )
        self.m_latticeBox.setLayout( self.m_latticeLayout )
        self.m_latticeDivisionLabel = QtGui.QLabel( "Division" )
        self.m_latticeDivisionLabel.setMaximumWidth( 80 )
        self.m_latticeLayout.addWidget( self.m_latticeDivisionLabel, 1, 0 )
        self.m_latticeNoiseLabel = QtGui.QLabel( "Noise" )
        self.m_latticeNoiseLabel.setMaximumWidth( 80 )
        self.m_latticeLayout.addWidget( self.m_latticeNoiseLabel, 2, 0 )
        self.m_latticeScaleLabel = QtGui.QLabel( "Scale" )
        self.m_latticeScaleLabel.setMaximumWidth( 80 )
        self.m_latticeLayout.addWidget( self.m_latticeScaleLabel, 3, 0 )
        self.m_latticeDivisionMinSpin = mySpinBox()
        self.m_latticeDivisionMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeDivisionMinSpin.setRange( 2, 1000 )
        self.m_latticeLayout.addWidget( self.m_latticeDivisionMinSpin, 1, 1 )
        self.m_latticeDivisionMaxSpin = mySpinBox()
        self.m_latticeDivisionMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeDivisionMaxSpin.setRange( 2, 1000 )
        self.m_latticeLayout.addWidget( self.m_latticeDivisionMaxSpin, 1, 2 )
        self.m_latticeNoiseMinSpin = myDoubleSpinBox()
        self.m_latticeNoiseMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeNoiseMinSpin.setRange( -1000, 1000 )
        self.m_latticeNoiseMinSpin.setSingleStep( 0.01 )
        self.m_latticeLayout.addWidget( self.m_latticeNoiseMinSpin, 2, 1 )
        self.m_latticeNoiseMaxSpin = myDoubleSpinBox()
        self.m_latticeNoiseMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeNoiseMaxSpin.setRange( -1000, 1000 )
        self.m_latticeNoiseMaxSpin.setSingleStep( 0.01 )
        self.m_latticeLayout.addWidget( self.m_latticeNoiseMaxSpin, 2, 2 )
        self.m_latticeScaleMinSpin = myDoubleSpinBox()
        self.m_latticeScaleMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeScaleMinSpin.setRange( -10000, 10000 )
        self.m_latticeLayout.addWidget( self.m_latticeScaleMinSpin, 3, 1 )
        self.m_latticeScaleMaxSpin = myDoubleSpinBox()
        self.m_latticeScaleMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_latticeScaleMaxSpin.setRange( -10000, 10000 )
        self.m_latticeLayout.addWidget( self.m_latticeScaleMaxSpin, 3, 2 )
        self.m_createOptionsLayout.addWidget( self.m_latticeBox, 4, 0 )
        #self.connect( self.m_enableLatticeOption, QtCore.SIGNAL( "stateChanged( int )" ), self.m_latticeScaleMaxSpin.setEnabled )
        #Bend settings.
        self.m_bendLayout = QtGui.QGridLayout()
        self.m_bendLayout.setContentsMargins( 3,3,3,3 )
        self.m_bendBox = QtGui.QGroupBox( "Bend: " )
        self.m_bendBox.setCheckable( True )
        self.m_bendBox.setLayout( self.m_bendLayout )
        self.m_bendCurvatureLabel = QtGui.QLabel( "Angle" )
        self.m_bendCurvatureLabel.setMaximumWidth( 80 )
        self.m_bendLayout.addWidget( self.m_bendCurvatureLabel, 1, 0 )
        self.m_bendCurvatureMinSpin = myDoubleSpinBox()
        self.m_bendCurvatureMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendCurvatureMinSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendCurvatureMinSpin, 1, 1 )
        self.m_bendCurvatureMaxSpin = myDoubleSpinBox()
        self.m_bendCurvatureMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendCurvatureMaxSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendCurvatureMaxSpin, 1, 2 )
        self.m_bendInfluenceLabel = QtGui.QLabel( "Influence" )
        self.m_bendInfluenceLabel.setMaximumWidth( 80 )
        self.m_bendLayout.addWidget( self.m_bendInfluenceLabel, 2, 0 )
        self.m_bendInfluenceMinSpin = myDoubleSpinBox()
        self.m_bendInfluenceMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendInfluenceMinSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendInfluenceMinSpin, 2, 1 )
        self.m_bendInfluenceMaxSpin = myDoubleSpinBox()
        self.m_bendInfluenceMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendInfluenceMaxSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendInfluenceMaxSpin, 2, 2 )
        self.m_bendPosOffsetLabel = QtGui.QLabel( "Offset %" )
        self.m_bendPosOffsetLabel.setMaximumWidth( 80 )
        self.m_bendLayout.addWidget( self.m_bendPosOffsetLabel, 3, 0 )
        self.m_bendPosOffsetMinSpin = myDoubleSpinBox()
        self.m_bendPosOffsetMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendPosOffsetMinSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendPosOffsetMinSpin, 3, 1 )
        self.m_bendPosOffsetMaxSpin = myDoubleSpinBox()
        self.m_bendPosOffsetMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_bendPosOffsetMaxSpin.setRange( -10000, 10000 )
        self.m_bendLayout.addWidget( self.m_bendPosOffsetMaxSpin, 3, 2 )
        self.m_createOptionsLayout.addWidget( self.m_bendBox, 5, 0 )
        #Twist settings.
        self.m_twistLayout = QtGui.QGridLayout()
        self.m_twistLayout.setContentsMargins( 3,3,3,3 )
        self.m_twistBox = QtGui.QGroupBox( "Twist: " )
        self.m_twistBox.setCheckable( True )
        self.m_twistBox.setLayout( self.m_twistLayout )
        self.m_twistCurvatureLabel = QtGui.QLabel( "Angle" )
        self.m_twistCurvatureLabel.setMaximumWidth( 80 )
        self.m_twistLayout.addWidget( self.m_twistCurvatureLabel, 1, 0 )
        self.m_twistCurvatureMinSpin = myDoubleSpinBox()
        self.m_twistCurvatureMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_twistCurvatureMinSpin.setRange( -10000, 10000 )
        self.m_twistLayout.addWidget( self.m_twistCurvatureMinSpin, 1, 1 )
        self.m_twistCurvatureMaxSpin = myDoubleSpinBox()
        self.m_twistCurvatureMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_twistCurvatureMaxSpin.setRange( -10000, 10000 )
        self.m_twistLayout.addWidget( self.m_twistCurvatureMaxSpin, 1, 2 )
        self.m_createOptionsLayout.addWidget( self.m_twistBox, 6, 0 )
        #Flare settings.
        self.m_flareLayout = QtGui.QGridLayout()
        self.m_flareLayout.setContentsMargins( 3,3,3,3 )
        self.m_flareBox = QtGui.QGroupBox( "Flare: " )
        self.m_flareBox.setCheckable( True )
        self.m_flareBox.setLayout( self.m_flareLayout )
        self.m_flareCurvatureLabel = QtGui.QLabel( "Size" )
        self.m_flareCurvatureLabel.setMaximumWidth( 80 )
        self.m_flareLayout.addWidget( self.m_flareCurvatureLabel, 1, 0 )
        self.m_flareCurvatureMinSpin = myDoubleSpinBox()
        self.m_flareCurvatureMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_flareCurvatureMinSpin.setRange( -10000, 10000 )
        self.m_flareLayout.addWidget( self.m_flareCurvatureMinSpin, 1, 1 )
        self.m_flareCurvatureMaxSpin = myDoubleSpinBox()
        self.m_flareCurvatureMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_flareCurvatureMaxSpin.setRange( -10000, 10000 )
        self.m_flareLayout.addWidget( self.m_flareCurvatureMaxSpin, 1, 2 )
        self.m_flareAngleLabel = QtGui.QLabel( "Angle" )
        self.m_flareAngleLabel.setMaximumWidth( 80 )
        self.m_flareLayout.addWidget( self.m_flareAngleLabel, 2, 0 )
        self.m_flareAngleMinSpin = myDoubleSpinBox()
        self.m_flareAngleMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_flareAngleMinSpin.setRange( -10000, 10000 )
        self.m_flareLayout.addWidget( self.m_flareAngleMinSpin, 2, 1 )
        self.m_flareAngleMaxSpin = myDoubleSpinBox()
        self.m_flareAngleMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_flareAngleMaxSpin.setRange( -10000, 10000 )
        self.m_flareLayout.addWidget( self.m_flareAngleMaxSpin, 2, 2 )
        self.m_createOptionsLayout.addWidget( self.m_flareBox, 7, 0 )
        #Sine settings.
        self.m_sineLayout = QtGui.QGridLayout()
        self.m_sineLayout.setContentsMargins( 3,3,3,3 )
        self.m_sineBox = QtGui.QGroupBox( "Sine: " )
        self.m_sineBox.setCheckable( True )
        self.m_sineBox.setLayout( self.m_sineLayout )
        self.m_sineCurvatureLabel = QtGui.QLabel( "Amplitude" )
        self.m_sineCurvatureLabel.setMaximumWidth( 80 )
        self.m_sineLayout.addWidget( self.m_sineCurvatureLabel, 1, 0 )
        self.m_sineCurvatureMinSpin = myDoubleSpinBox()
        self.m_sineCurvatureMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineCurvatureMinSpin.setRange( -10000, 10000 )
        self.m_sineLayout.addWidget( self.m_sineCurvatureMinSpin, 1, 1 )
        self.m_sineCurvatureMaxSpin = myDoubleSpinBox()
        self.m_sineCurvatureMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineCurvatureMaxSpin.setRange( -10000, 10000 )
        self.m_sineLayout.addWidget( self.m_sineCurvatureMaxSpin, 1, 2 )
        self.m_sineLenghtLabel = QtGui.QLabel( "Length" )
        self.m_sineLenghtLabel.setMaximumWidth( 80 )
        self.m_sineLayout.addWidget( self.m_sineLenghtLabel, 2, 0 )
        self.m_sineLenghtMinSpin = myDoubleSpinBox()
        self.m_sineLenghtMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineLenghtMinSpin.setRange( 0.1, 10000 )
        self.m_sineLayout.addWidget( self.m_sineLenghtMinSpin, 2, 1 )
        self.m_sineLenghtMaxSpin = myDoubleSpinBox()
        self.m_sineLenghtMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineLenghtMaxSpin.setRange( 0.1, 10000 )
        self.m_sineLayout.addWidget( self.m_sineLenghtMaxSpin, 2, 2 )
        self.m_sineDropoffLabel = QtGui.QLabel( "Dropoff" )
        self.m_sineDropoffLabel.setMaximumWidth( 80 )
        self.m_sineLayout.addWidget( self.m_sineDropoffLabel, 3, 0 )
        self.m_sineDropoffMinSpin = myDoubleSpinBox()
        self.m_sineDropoffMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineDropoffMinSpin.setRange( -1.0, 1.0 )
        self.m_sineLayout.addWidget( self.m_sineDropoffMinSpin, 3, 1 )
        self.m_sineDropoffMaxSpin = myDoubleSpinBox()
        self.m_sineDropoffMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_sineDropoffMaxSpin.setRange( -1.0, 1.0 )
        self.m_sineLayout.addWidget( self.m_sineDropoffMaxSpin, 3, 2 )
        self.m_createOptionsLayout.addWidget( self.m_sineBox, 8, 0 )
        #Wave settings.
        self.m_waveLayout = QtGui.QGridLayout()
        self.m_waveLayout.setContentsMargins( 3,3,3,3 )
        self.m_waveBox = QtGui.QGroupBox( "Wave: " )
        self.m_waveBox.setCheckable( True )
        self.m_waveBox.setLayout( self.m_waveLayout )
        self.m_waveCurvatureLabel = QtGui.QLabel( "Amplitude" )
        self.m_waveCurvatureLabel.setMaximumWidth( 80 )
        self.m_waveLayout.addWidget( self.m_waveCurvatureLabel, 1, 0 )
        self.m_waveCurvatureMinSpin = myDoubleSpinBox()
        self.m_waveCurvatureMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveCurvatureMinSpin.setRange( -10000, 10000 )
        self.m_waveLayout.addWidget( self.m_waveCurvatureMinSpin, 1, 1 )
        self.m_waveCurvatureMaxSpin = myDoubleSpinBox()
        self.m_waveCurvatureMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveCurvatureMaxSpin.setRange( -10000, 10000 )
        self.m_waveLayout.addWidget( self.m_waveCurvatureMaxSpin, 1, 2 )
        self.m_waveLenghtLabel = QtGui.QLabel( "Length" )
        self.m_waveLenghtLabel.setMaximumWidth( 80 )
        self.m_waveLayout.addWidget( self.m_waveLenghtLabel, 2, 0 )
        self.m_waveLenghtMinSpin = myDoubleSpinBox()
        self.m_waveLenghtMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveLenghtMinSpin.setRange( 0.1, 10000 )
        self.m_waveLayout.addWidget( self.m_waveLenghtMinSpin, 2, 1 )
        self.m_waveLenghtMaxSpin = myDoubleSpinBox()
        self.m_waveLenghtMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveLenghtMaxSpin.setRange( 0.1, 10000 )
        self.m_waveLayout.addWidget( self.m_waveLenghtMaxSpin, 2, 2 )
        self.m_waveDropoffLabel = QtGui.QLabel( "Dropoff" )
        self.m_waveDropoffLabel.setMaximumWidth( 80 )
        self.m_waveLayout.addWidget( self.m_waveDropoffLabel, 3, 0 )
        self.m_waveDropoffMinSpin = myDoubleSpinBox()
        self.m_waveDropoffMinSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveDropoffMinSpin.setRange( -1.0, 1.0 )
        self.m_waveLayout.addWidget( self.m_waveDropoffMinSpin, 3, 1 )
        self.m_waveDropoffMaxSpin = myDoubleSpinBox()
        self.m_waveDropoffMaxSpin.setFocusPolicy( QtCore.Qt.StrongFocus )
        self.m_waveDropoffMaxSpin.setRange( -1.0, 1.0 )
        self.m_waveLayout.addWidget( self.m_waveDropoffMaxSpin, 3, 2 )
        self.m_createOptionsLayout.addWidget( self.m_waveBox, 9, 0 )
        #Action buttons.
        self.m_createDeformationButton = QtGui.QPushButton( "Apply deformation" )
        self.m_createDeformationButton.released.connect( self.ml_applyDeformations )
        self.m_createActionsLayout.addWidget( self.m_createDeformationButton )
        self.m_removeDeformationButton = QtGui.QPushButton( "Remove deformation" )
        self.m_removeDeformationButton.released.connect( self.ml_removeDeformations )
        self.m_createActionsLayout.addWidget( self.m_removeDeformationButton )
        #Settings
        self.m_settingsLayout.addWidget( self.m_createOptionsGroupBox )
        self.m_settingsLayout.addWidget( self.m_hideSelectionListButton )
        self.m_selectionListGroupBox.hide()
        self.m_settingsLayout.addWidget( self.m_selectionListGroupBox )
        self.mainWidgetLayout.addWidget( self.m_settingsBox )
        #self.splitter.addWidget( self.m_createOptionsGroupBox )
        #self.splitter.addWidget( self.m_selectionListGroupBox )
        #self.splitter.moveSplitter ( 0, 0 ) 
        #self.mainWidgetLayout.addWidget( self.splitter )
        self.mainWidget.setLayout( self.mainWidgetLayout )
        self.mainScrollArea.setWidget( self.mainWidget )
        self.mainlayout.addWidget( self.mainScrollArea )
        self.mainlayout.addWidget( self.m_createActionsGroupBox )
        self.isLoad=True

    def ml_hideSelectionList( self ):
        if self.m_selectionListGroupBox.isHidden():
            self.m_hideSelectionListButton.setText( "<" )
            self.m_selectionListGroupBox.show()
        else:
            self.m_hideSelectionListButton.setText( ">" )
            self.m_selectionListGroupBox.hide()

    def ml_randomizeSettings_arg( self ):
        self.ml_randomizeSettings( seed=True )

    def ml_randomizeSettings( self, seed=False, preset="" ):
        
        def ml_loadPreset( m_preset ):
            m_result = ""
            if m_preset == "Default":
                m_result = """
                envelopeMin = ( 50.0, 100.0 )
                envelopeMax = ( 50.0, 100.0 )
                rotationOffsetMin = ( -25, 25 )
                rotationOffsetMax = ( -25, 25 )
                latticeDivisionMin = ( 2, 8 )
                latticeDivisionMax = ( 2, 8 )
                latticeNoiseMin = ( -0.1, 0.1 )
                latticeNoiseMax = ( -0.1, 0.1 )
                latticeScaleMin = ( -0.25, 0.25 )
                latticeScaleMax = ( -0.25, 0.25 )
                bendAngleMin = ( -0.50, 0.50 )
                bendAngleMax = ( -0.50, 0.50 )
                bendInfluenceMin = ( -5.0, 5.0 )
                bendInfluenceMax = ( -5.0, 5.0 )
                bendOffsetMin = ( -25.0, 25.0 )
                bendOffsetMax = ( -25.0, 25.0 )
                twistAngleMin = ( -90.0, 90.0 )
                twistAngleMax = ( -90.0, 90.0 )
                flareScaleMin = ( 0.0, 1.5 )
                flareScaleMax = ( 0.0, 1.5 )
                flareAngleMin = ( -1.0, 1.0 )
                flareAngleMax = ( -1.0, 1.0 )
                sineAmplitudeMin = ( -0.5, 0.5 )
                sineAmplitudeMax = ( -0.5, 0.5 ) 
                sineLengthMin = ( 1.0, 3.0 )
                sineLengthMax = ( 1.0, 3.0 )
                sineDropofMin = ( -1.0, 1.0 )
                sineDropofMax = ( -1.0, 1.0 )
                waveAmplitudeMin = ( -0.5, 0.5 )
                waveAmplitudeMax = ( -0.5, 0.5 ) 
                waveLengthMin = ( 1.0, 3.0 )
                waveLengthMax = ( 1.0, 3.0 )
                waveDropofMin = ( -1.0, 1.0 )
                waveDropofMax = ( -1.0, 1.0 )"""
            elif m_preset == "Medium":
                m_result = """
                envelopeMin = ( 50.0, 75.0 )
                envelopeMax = ( 75.0, 100.0 )
                rotationOffsetMin = ( -45.0, 0.0 )
                rotationOffsetMax = ( 0.0, 45.0 )
                latticeDivisionMin = ( 2, 4 )
                latticeDivisionMax = ( 4, 8 )
                latticeNoiseMin = ( -0.1, 0.0 )
                latticeNoiseMax = ( 0.0, 0.1 )
                latticeScaleMin = ( -0.25, 0.0 )
                latticeScaleMax = ( 0.0, 0.25 )
                bendAngleMin = ( -0.50, 0.0 )
                bendAngleMax = ( 0.0, 0.50 )
                bendInfluenceMin = ( -5.0, 0.0 )
                bendInfluenceMax = ( 0.0, 5.0 )
                bendOffsetMin = ( -25.0, 0.0 )
                bendOffsetMax = ( 0.0, 25.0 )
                twistAngleMin = ( -90.0, 0.0 )
                twistAngleMax = ( 0.0, 90.0 )
                flareScaleMin = ( 0.25, 0.75 )
                flareScaleMax = ( 0.75, 1.25 )
                flareAngleMin = ( -0.75, 0.0 )
                flareAngleMax = ( 0.0, 0.75 )
                sineAmplitudeMin = ( -0.25, 0.0 )
                sineAmplitudeMax = ( 0.0, 0.25 ) 
                sineLengthMin = ( 1.0, 2.0 )
                sineLengthMax = ( 2.0, 3.0 )
                sineDropofMin = ( -1.0, 0.0 )
                sineDropofMax = ( 0.0, 1.0 )
                waveAmplitudeMin = ( -0.5, 0.0 )
                waveAmplitudeMax = ( 0.0, 0.5 ) 
                waveLengthMin = ( 1.0, 2.0 )
                waveLengthMax = ( 2.0, 3.0 )
                waveDropofMin = ( -1.0, 0.0 )
                waveDropofMax = ( 0.0, 1.0 )"""
            elif m_preset == "low":
                m_result = """
                envelopeMin = ( 15.0, 25.0 )
                envelopeMax = ( 25.0, 50.0 )
                rotationOffsetMin = ( -10.0, 0.0 )
                rotationOffsetMax = ( 0.0, 10.0 )
                latticeDivisionMin = ( 2, 4 )
                latticeDivisionMax = ( 4, 8 )
                latticeNoiseMin = ( -0.1, 0.0 )
                latticeNoiseMax = ( 0.0, 0.1 )
                latticeScaleMin = ( -0.25, 0.0 )
                latticeScaleMax = ( 0.0, 0.25 )
                bendAngleMin = ( -0.50, 0.0 )
                bendAngleMax = ( 0.0, 0.50 )
                bendInfluenceMin = ( -2.5, 0.0 )
                bendInfluenceMax = ( 0.0, 2.5 )
                bendOffsetMin = ( -25.0, 0.0 )
                bendOffsetMax = ( 0.0, 25.0 )
                twistAngleMin = ( -45.0, 0.0 )
                twistAngleMax = ( 0.0, 45.0 )
                flareScaleMin = ( 0.75, 1.0 )
                flareScaleMax = ( 1.00, 1.25 )
                flareAngleMin = ( -0.5, 0.0 )
                flareAngleMax = ( 0.0, 0.5 )
                sineAmplitudeMin = ( -0.25, 0.0 )
                sineAmplitudeMax = ( 0.0, 0.25 ) 
                sineLengthMin = ( 1.0, 2.0 )
                sineLengthMax = ( 2.0, 3.0 )
                sineDropofMin = ( -1.0, 0.0 )
                sineDropofMax = ( 0.0, 1.0 )
                waveAmplitudeMin = ( -0.5, 0.0 )
                waveAmplitudeMax = ( 0.0, 0.5 ) 
                waveLengthMin = ( 1.5, 2.0 )
                waveLengthMax = ( 2.0, 2.5 )
                waveDropofMin = ( -0.5, 0.0 )
                waveDropofMax = ( 0.0, 0.5 )"""
            else:
                pass
            return m_result
        
        def ml_getPresetValue( attribute ):
            m_result = [ 0, 0 ]
            m_value = re.findall( "%s[=(\s]+([0-9.]+|-[0-9.]+)[,\s]+([0-9.]+|-[0-9.]+)[) ]" % attribute, m_settings )
            if m_value:
                m_value = m_value[0]
                if "." in m_value[0] or "." in m_value[-1]:
                    m_result = [ float( m_value[0]), float( m_value[-1] )]
                else:
                    m_result = [ int( m_value[0]), int( m_value[-1] )]
            return m_result
        
        if seed is False:
            self.m_seed = random.randint( 0, sys.maxint - 100 )
            self.m_seedSpin.setValue( self.m_seed )
        else:
            self.m_seed = self.m_seedSpin.value()
        if preset == "":
            preset = self.m_presetComboBox.currentText()
        #Load preset.
        m_settings = ml_loadPreset( preset )
        m_value = ml_getPresetValue( "envelopeMin" )
        random.seed( self.m_seed )
        self.m_baseEnvelopeMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
        m_value = ml_getPresetValue( "envelopeMax" )
        random.seed( self.m_seed + 1 )
        self.m_baseEnvelopeMaxSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
        m_value = ml_getPresetValue( "rotationOffsetMin" )
        random.seed( self.m_seed + 2 )
        self.m_baseRandomRotationMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
        m_value = ml_getPresetValue( "rotationOffsetMax" )
        random.seed( self.m_seed + 3 )
        self.m_baseRandomRotationMaxSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
        if self.m_latticeBox.isChecked():
            m_value = ml_getPresetValue( "latticeDivisionMin" )
            random.seed( self.m_seed + 4 )
            self.m_latticeDivisionMinSpin.setValue( int( random.uniform( m_value[0], m_value[-1] )))
            m_value = ml_getPresetValue( "latticeDivisionMax" )
            random.seed( self.m_seed + 5 )
            self.m_latticeDivisionMaxSpin.setValue( int( random.uniform( m_value[0], m_value[-1] )))
            m_value = ml_getPresetValue( "latticeNoiseMin" )
            random.seed( self.m_seed + 4 )
            self.m_latticeNoiseMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "latticeNoiseMax" )
            random.seed( self.m_seed + 5 )
            self.m_latticeNoiseMaxSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "latticeScaleMin" )
            random.seed( self.m_seed + 6 )
            self.m_latticeScaleMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "latticeScaleMax" )
            random.seed( self.m_seed + 7 )
            self.m_latticeScaleMaxSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "latticeScaleMin" )
            random.seed( self.m_seed + 8 )
            self.m_latticeScaleMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "latticeScaleMax" )
            random.seed( self.m_seed + 9 )
            self.m_latticeScaleMaxSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
        if self.m_bendBox.isChecked():
            m_value = ml_getPresetValue( "bendAngleMin" )
            random.seed( self.m_seed + 10 )
            self.m_bendCurvatureMinSpin.setValue( random.uniform( m_value[0], m_value[-1] ))
            m_value = ml_getPresetValue( "bendAngleMax" )
            random.seed( self.m_seed + 11 )
            self.m_bendCurvatureMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "bendInfluenceMin" )
            random.seed( self.m_seed + 12 )
            self.m_bendInfluenceMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "bendInfluenceMax" )
            random.seed( self.m_seed + 13 )
            self.m_bendInfluenceMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "bendOffsetMin" )
            random.seed( self.m_seed + 14 )
            self.m_bendPosOffsetMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "bendOffsetMax" )
            random.seed( self.m_seed + 15 )
            self.m_bendPosOffsetMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
        if self.m_twistBox.isChecked():
            m_value = ml_getPresetValue( "twistAngleMin" )
            random.seed( self.m_seed + 17 )
            self.m_twistCurvatureMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "twistAngleMax" )
            random.seed( self.m_seed + 17 )
            self.m_twistCurvatureMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
        if self.m_flareBox.isChecked():
            m_value = ml_getPresetValue( "flareScaleMin" )
            random.seed( self.m_seed + 18 )
            self.m_flareCurvatureMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "flareScaleMax" )
            random.seed( self.m_seed + 19 )
            self.m_flareCurvatureMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "flareAngleMin" )
            random.seed( self.m_seed + 20 )
            self.m_flareAngleMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "flareAngleMax" )
            random.seed( self.m_seed + 21 )
            self.m_flareAngleMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
        if self.m_sineBox.isChecked():
            m_value = ml_getPresetValue( "sineAmplitudeMin" )
            random.seed( self.m_seed + 22 )
            self.m_sineCurvatureMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "sineAmplitudeMax" )
            random.seed( self.m_seed + 23 )
            self.m_sineCurvatureMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "sineLengthMin" )
            random.seed( self.m_seed + 24 )
            self.m_sineLenghtMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "sineLengthMax" )
            random.seed( self.m_seed + 25 )
            self.m_sineLenghtMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "sineDropofMin" )
            random.seed( self.m_seed + 26 )
            self.m_sineDropoffMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "sineDropofMax" )
            random.seed( self.m_seed + 27 )
            self.m_sineDropoffMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
        if self.m_waveBox.isChecked():
            m_value = ml_getPresetValue( "waveAmplitudeMin" )
            random.seed( self.m_seed + 28 )
            self.m_waveCurvatureMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "waveAmplitudeMax" )
            random.seed( self.m_seed + 29 )
            self.m_waveCurvatureMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "waveLengthMin" )
            random.seed( self.m_seed + 30 )
            self.m_waveLenghtMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "waveLengthMax" )
            random.seed( self.m_seed + 31 )
            self.m_waveLenghtMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "waveDropofMin" )
            random.seed( self.m_seed + 32 )
            self.m_waveDropoffMinSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
            m_value = ml_getPresetValue( "waveDropofMax" )
            random.seed( self.m_seed + 33 )
            self.m_waveDropoffMaxSpin.setValue( random.uniform( m_value[0], m_value[-1]  ))
        
#         if preset == "Default":
#             if self.m_latticeBox.isChecked():
#                 random.seed( self.m_seed + 1 )
#                 self.m_latticeDivisionMinSpin.setValue( int( random.uniform( 2, 6 )))
#                 random.seed( self.m_seed + 2 )
#                 self.m_latticeDivisionMaxSpin.setValue( int( random.uniform( 2, 6 )))
#                 random.seed( self.m_seed + 3 )
#                 self.m_latticeNoiseMinSpin.setValue( random.uniform( -0.1, 0.1 ))
#                 random.seed( self.m_seed + 4 )
#                 self.m_latticeNoiseMaxSpin.setValue( random.uniform( -0.1, 0.1 ))
#                 random.seed( self.m_seed + 5 )
#                 self.m_latticeScaleMinSpin.setValue( random.uniform( -0.25, 0.25 ))
#                 random.seed( self.m_seed + 6 )
#                 self.m_latticeScaleMaxSpin.setValue( random.uniform( -0.25, 0.25 ))
#             if self.m_bendBox.isChecked():
#                 random.seed( self.m_seed + 7 )
#                 self.m_bendCurvatureMinSpin.setValue( random.uniform( -0.75, 0.75 ))
#                 random.seed( self.m_seed + 8 )
#                 self.m_bendCurvatureMaxSpin.setValue( random.uniform( -0.75, 0.75 ))
#                 random.seed( self.m_seed + 9 )
#                 self.m_bendInfluenceMinSpin.setValue( random.uniform( -5, 5 ))
#                 random.seed( self.m_seed + 10 )
#                 self.m_bendInfluenceMaxSpin.setValue( random.uniform( -5, 5 ))
#                 random.seed( self.m_seed + 11 )
#                 self.m_bendPosOffsetMinSpin.setValue( random.uniform( -50, 50 ))
#                 random.seed( self.m_seed + 12 )
#                 self.m_bendPosOffsetMaxSpin.setValue( random.uniform( -50, 50 ))
#             if self.m_twistBox.isChecked():
#                 random.seed( self.m_seed + 13 )
#                 self.m_twistCurvatureMinSpin.setValue( random.uniform( -90, 90 ))
#                 random.seed( self.m_seed + 14 )
#                 self.m_twistCurvatureMaxSpin.setValue( random.uniform( -90, 90 ))
#             if self.m_flareBox.isChecked():
#                 random.seed( self.m_seed + 15 )
#                 self.m_flareCurvatureMinSpin.setValue( random.uniform( 0, 1.5 ))
#                 random.seed( self.m_seed + 16 )
#                 self.m_flareCurvatureMaxSpin.setValue( random.uniform( 0, 1.5 ))
#                 random.seed( self.m_seed + 17 )
#                 self.m_flareAngleMaxSpin.setValue( random.uniform( -1, 1 ))
#                 random.seed( self.m_seed + 18 )
#                 self.m_flareAngleMinSpin.setValue( random.uniform( -1, 1 ))
#             if self.m_sineBox.isChecked():
#                 random.seed( self.m_seed + 19 )
#                 self.m_sineCurvatureMinSpin.setValue( random.uniform( -0.5, 0.5 ))
#                 random.seed( self.m_seed + 20 )
#                 self.m_sineCurvatureMaxSpin.setValue( random.uniform( -0.5, 0.5 ))
#                 random.seed( self.m_seed + 21 )
#                 self.m_sineLenghtMinSpin.setValue( random.uniform( 1, 3 ))
#                 random.seed( self.m_seed + 22 )
#                 self.m_sineLenghtMaxSpin.setValue( random.uniform( 1, 3 ))
#                 random.seed( self.m_seed + 23 )
#                 self.m_sineDropoffMinSpin.setValue( random.uniform( -1.0, 1.0 ))
#                 random.seed( self.m_seed + 24 )
#                 self.m_sineDropoffMaxSpin.setValue( random.uniform( -1.0, 1.0 ))
#             if self.m_waveBox.isChecked():
#                 random.seed( self.m_seed + 25 )
#                 self.m_waveCurvatureMinSpin.setValue( random.uniform( -0.5, 0.5 ))
#                 random.seed( self.m_seed + 26 )
#                 self.m_waveCurvatureMaxSpin.setValue( random.uniform( -0.5, 0.5 ))
#                 random.seed( self.m_seed + 27 )
#                 self.m_waveLenghtMinSpin.setValue( random.uniform( 1, 3 ))
#                 random.seed( self.m_seed + 28 )
#                 self.m_waveLenghtMaxSpin.setValue( random.uniform( 1, 3 ))
#                 random.seed( self.m_seed + 29 )
#                 self.m_waveDropoffMinSpin.setValue( random.uniform( -1.0, 1.0 ))
#                 random.seed( self.m_seed + 30 )
#                 self.m_waveDropoffMaxSpin.setValue( random.uniform( -1.0, 1.0 ))

    def ml_applyDeformations( self ):
        m_selectionMode = self.m_selectionModeComboBox.currentText()
        m_invividualCreation = self.m_individualCreationOptions.checkState()
        if m_selectionMode == "Outliner":
            m_nodes = cmds.ls( sl=True )
            if not m_invividualCreation and m_nodes:
                m_nodes = [ m_nodes ]
        elif m_selectionMode == "Selected content":
            m_nodes = self.ml_getSelectedItems()
        else:
            m_nodes = ( str( self.m_selectionListModel.stringList().join( "," )).split( "," ))
        m_constraint = self.m_constraintbaseOption.checkState()
        #Make root folder.
        m_root = cmds.ls( "|deformations" )
        if not m_root:
            m_root = cmds.createNode( "transform", n="deformations" )
        else:
            m_root = m_root[0]
        m_minRotationOffset = self.m_baseRandomRotationMinSpin.value()
        m_maxRotationOffset = self.m_baseRandomRotationMaxSpin.value()
        for n in range( 0, len( m_nodes )):
            if not m_invividualCreation and cmds.ls( m_nodes[n], dag=True, type="mesh" ) or cmds.nodeType( m_nodes[n] ) == "mesh" or cmds.nodeType( m_nodes[n] ) == "transform" and cmds.ls( m_nodes[n], dag=True, type="mesh" ): 
                #Create deformations.
                if self.m_replacebaseOption.checkState():
                    self.ml_removeDeformations( nodes=m_nodes[n] )
                if self.m_latticeBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create lattice.
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_division = int( random.uniform( self.m_latticeDivisionMinSpin.value(), self.m_latticeDivisionMaxSpin.value()))
                    m_lattice = cmds.lattice( m_nodes[n], divisions=( m_division, m_division, m_division ), oc=True, ldv=( 2, 2 ,2 ), ol=2 )
                    m_lattice_shape = cmds.ls( m_lattice[1], dag=True, type="lattice" )
                    cmds.setAttr( "%s.envelope" % m_lattice[0], m_envelope * 0.01 )
                    if m_lattice_shape:
                        m_lattice_shape = m_lattice_shape[0]
                        m_sdiv = cmds.getAttr( "%s.sDivisions" % m_lattice_shape )
                        m_tdiv = cmds.getAttr( "%s.tDivisions" % m_lattice_shape )
                        m_udiv = cmds.getAttr( "%s.uDivisions" % m_lattice_shape )
                        m_point = "{0}.pt[ %s ][ %s ][ %s ]".format( m_lattice_shape )
                        for s in range( m_sdiv ):
                            for t in range( m_tdiv ):
                                for u in range( m_udiv ):
                                    m_point_current = m_point % ( s, t, u )
                                    m_noise = [ random.uniform( self.m_latticeNoiseMinSpin.value(), self.m_latticeNoiseMaxSpin.value()) for v in range( 3 ) ]
                                    m_xyz = cmds.getAttr( m_point_current )[0]
                                    m_xyz = [ round( float( m_xyz[0] ), 3 ), round( float( m_xyz[1] ), 3 ), round( float( m_xyz[2] ), 3 ) ]
                                    m_xyz = [ m_xyz[0] + m_noise[0], m_xyz[1] + m_noise[1], m_xyz[2] + m_noise[2] ]
                                    cmds.setAttr( m_point_current, m_xyz[0], m_xyz[1], m_xyz[2] )
                    #Hide lattice.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_lattice )):
                            cmds.setAttr( "%s.visibility" % m_lattice[t], 0 )
                    #Scale lattice.
                    m_scale = random.uniform( self.m_latticeScaleMinSpin.value(), self.m_latticeScaleMaxSpin.value())
                    m_scale = m_scale + 1 
                    m_scale_current = cmds.getAttr( "%s.s" % m_lattice[1] )[0]
                    m_scale = [ random.uniform( m_scale_current[0], m_scale_current[0] * m_scale ), random.uniform( m_scale_current[1], m_scale_current[1] * m_scale ), random.uniform( m_scale_current[2], m_scale_current[2] * m_scale ) ]
                    cmds.scale( m_scale[0], m_scale[1], m_scale[2], m_lattice[1] )
                    #Constraint lattice.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_lattice[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_lattice[-1], maintainOffset=True, weight=1 )
                    #Rename lattice.
                    for t in range( 0, len( m_lattice )):
                        m_lattice[t] = cmds.rename( m_lattice[t], "deformer_" + m_lattice[t] )
                    #Group lattice.
                    cmds.parent( m_lattice[1], m_lattice[-1] )
                    cmds.parent( m_lattice[-1], m_root )
                if self.m_bendBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create bend.
                    m_bbox = cmds.exactWorldBoundingBox( m_nodes[n] )
                    m_lengthY = abs( round( m_bbox[1], 5) - round( m_bbox[4], 5))
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_min = self.m_bendInfluenceMinSpin.value()
                    m_max = self.m_bendInfluenceMaxSpin.value()
                    m_nonLinear = cmds.nonLinear( m_nodes[n], type="bend", lowBound=-abs( 1 + random.uniform( m_min, m_max )), highBound=abs( 1 + random.uniform( m_min, m_max )))
                    m_min = self.m_bendCurvatureMinSpin.value()
                    m_max = self.m_bendCurvatureMaxSpin.value()
                    cmds.setAttr( "%s.envelope" % m_nonLinear[0], m_envelope * 0.01 )
                    cmds.setAttr( "%s.curvature" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    #Hide bend.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_nonLinear )):
                            cmds.setAttr( "%s.visibility" % m_nonLinear[t], 0 )
                    #Offset bend
                    m_lengthY = m_lengthY * 0.01
                    m_lengthY = m_lengthY * random.uniform( self.m_bendPosOffsetMinSpin.value(), self.m_bendPosOffsetMaxSpin.value())
                    cmds.setAttr( "%s.ty" % m_nonLinear[-1], cmds.getAttr( "%s.ty" % m_nonLinear[-1] ) + m_lengthY )
                    #Rotation offset.
                    cmds.setAttr( "%s.ry" % m_nonLinear[-1], random.uniform( -360, 360 ))
                    cmds.setAttr( "%s.rx" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    cmds.setAttr( "%s.rz" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    #Constraint bend.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                    #Rename bend.
                    for t in range( 0, len( m_nonLinear )):
                        m_nonLinear[t] = cmds.rename( m_nonLinear[t], "deformer_" + m_nonLinear[t] )
                    #Group bend.
                    cmds.parent( m_nonLinear[-1], m_root )
                if self.m_twistBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create twist.
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_min = self.m_twistCurvatureMinSpin.value()
                    m_max = self.m_twistCurvatureMaxSpin.value()
                    m_nonLinear = cmds.nonLinear( m_nodes[n], type="twist", lowBound=-1, highBound=1 )
                    cmds.setAttr( "%s.envelope" % m_nonLinear[0], m_envelope * 0.01 )
                    m_startValue = random.uniform( m_min, m_max )
                    m_endValue = random.uniform( m_min, m_max )
                    cmds.setAttr( "%s.endAngle" % m_nonLinear[0], m_startValue )
                    cmds.setAttr( "%s.startAngle" % m_nonLinear[0], m_endValue )
                    #Hide twist.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_nonLinear )):
                            cmds.setAttr( "%s.visibility" % m_nonLinear[t], 0 )
                    #Rotation offset.
                    cmds.setAttr( "%s.ry" % m_nonLinear[-1], random.uniform( -360, 360 ))
                    cmds.setAttr( "%s.rx" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    cmds.setAttr( "%s.rz" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    #Constraint twist.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                    #Rename twist.
                    for t in range( 0, len( m_nonLinear )):
                        m_nonLinear[t] = cmds.rename( m_nonLinear[t], "deformer_" + m_nonLinear[t] )
                    #Group twist.
                    cmds.parent( m_nonLinear[-1], m_root )
                if self.m_flareBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create flare.
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_min = self.m_flareCurvatureMinSpin.value()
                    m_max = self.m_flareCurvatureMaxSpin.value()
                    m_nonLinear = cmds.nonLinear( m_nodes[n], type="flare", lowBound=-1, highBound=1 )
                    cmds.setAttr( "%s.envelope" % m_nonLinear[0], m_envelope * 0.01 )
                    m_startValue = random.uniform( m_min, m_max )
                    m_endValue = random.uniform( m_min, m_max )
                    cmds.setAttr( "%s.startFlareX" % m_nonLinear[0], m_startValue )
                    cmds.setAttr( "%s.startFlareZ" % m_nonLinear[0], m_startValue )
                    cmds.setAttr( "%s.endFlareX" % m_nonLinear[0], m_endValue )
                    cmds.setAttr( "%s.endFlareZ" % m_nonLinear[0], m_endValue )
                    m_min = self.m_flareAngleMinSpin.value()
                    m_max = self.m_flareAngleMaxSpin.value()
                    cmds.setAttr( "%s.curve" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    #Hide flare.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_nonLinear )):
                            cmds.setAttr( "%s.visibility" % m_nonLinear[t], 0 )
                    #Rotation offset.
                    cmds.setAttr( "%s.ry" % m_nonLinear[-1], random.uniform( -360, 360 ))
                    cmds.setAttr( "%s.rx" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    cmds.setAttr( "%s.rz" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    #Constraint flare.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                    #Rename flare.
                    for t in range( 0, len( m_nonLinear )):
                        m_nonLinear[t] = cmds.rename( m_nonLinear[t], "deformer_" + m_nonLinear[t] )
                    #Group flare.
                    cmds.parent( m_nonLinear[-1], m_root )
                if self.m_sineBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create sine.
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_min = self.m_sineCurvatureMinSpin.value()
                    m_max = self.m_sineCurvatureMaxSpin.value()
                    m_nonLinear = cmds.nonLinear( m_nodes[n], type="sine", lowBound=-1, highBound=1 )
                    cmds.setAttr( "%s.envelope" % m_nonLinear[0], m_envelope * 0.01 )
                    cmds.setAttr( "%s.amplitude" % m_nonLinear[0], random.uniform( m_min, m_max ) )
                    m_min = self.m_sineLenghtMinSpin.value()
                    m_max = self.m_sineLenghtMaxSpin.value()
                    cmds.setAttr( "%s.wavelength" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    m_min = self.m_sineDropoffMinSpin.value()
                    m_max = self.m_sineDropoffMaxSpin.value()
                    cmds.setAttr( "%s.dropoff" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    cmds.setAttr( "%s.offset" % m_nonLinear[0], random.uniform( -10, 10 ))
                    #Hide sine.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_nonLinear )):
                            cmds.setAttr( "%s.visibility" % m_nonLinear[t], 0 )
                    #Rotation offset.
                    cmds.setAttr( "%s.ry" % m_nonLinear[-1], random.uniform( -360, 360 ))
                    cmds.setAttr( "%s.rx" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    cmds.setAttr( "%s.rz" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    #Constraint sine.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                    #Rename sine.
                    for t in range( 0, len( m_nonLinear )):
                        m_nonLinear[t] = cmds.rename( m_nonLinear[t], "deformer_" + m_nonLinear[t] )
                    #Group sine.
                    cmds.parent( m_nonLinear[-1], m_root )
                if self.m_waveBox.isChecked():
                    #_________________________________________________________________________________________________________________
                    #Create wave.
                    m_envelope = random.uniform( self.m_baseEnvelopeMinSpin.value(), self.m_baseEnvelopeMaxSpin.value())
                    m_min = self.m_waveCurvatureMinSpin.value()
                    m_max = self.m_waveCurvatureMaxSpin.value()
                    m_nonLinear = cmds.nonLinear( m_nodes[n], type="wave", minRadius=0, maxRadius=1 )
                    cmds.setAttr( "%s.envelope" % m_nonLinear[0], m_envelope * 0.01 )
                    cmds.setAttr( "%s.amplitude" % m_nonLinear[0], random.uniform( m_min, m_max ) )
                    m_min = self.m_waveLenghtMinSpin.value()
                    m_max = self.m_waveLenghtMaxSpin.value()
                    cmds.setAttr( "%s.wavelength" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    m_min = self.m_waveDropoffMinSpin.value()
                    m_max = self.m_waveDropoffMaxSpin.value()
                    cmds.setAttr( "%s.dropoff" % m_nonLinear[0], random.uniform( m_min, m_max ))
                    cmds.setAttr( "%s.offset" % m_nonLinear[0], random.uniform( -10, 10 ))
                    #Hide sine.
                    if self.m_hidebaseOption.checkState():
                        for t in range( 1, len( m_nonLinear )):
                            cmds.setAttr( "%s.visibility" % m_nonLinear[t], 0 )
                    #Rotation offset.
                    cmds.setAttr( "%s.ry" % m_nonLinear[-1], random.uniform( -360, 360 ))
                    cmds.setAttr( "%s.rx" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    cmds.setAttr( "%s.rz" % m_nonLinear[-1], random.uniform( m_minRotationOffset, m_maxRotationOffset ))
                    #Constraint sine.
                    if m_constraint:
                        cmds.parentConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                        cmds.scaleConstraint( m_nodes[n], m_nonLinear[-1], maintainOffset=True, weight=1 )
                    #Rename sine.
                    for t in range( 0, len( m_nonLinear )):
                        m_nonLinear[t] = cmds.rename( m_nonLinear[t], "deformer_" + m_nonLinear[t] )
                    #Group sine.
                    cmds.parent( m_nonLinear[-1], m_root )
        
        if not m_invividualCreation and m_nodes and m_nodes[0]:
            m_nodes = m_nodes[0]
        if m_nodes:
            cmds.select( clear=True )
            cmds.select( m_nodes )
    
    def ml_removeDeformations( self, nodes="" ):
        if nodes:
            m_nodes = cmds.ls( nodes, long=True )
        else:
            m_nodes = cmds.ls( sl=True, long=True )
        for i in range( 0, len( m_nodes )):
            if cmds.nodeType( m_nodes[i] ) in [ "mesh", "transform" ]:
                m_deformers = self.ml_getCurrentDeformations( m_nodes[i] )
                for i in range( 0, len( m_deformers )):
                    try:
                        cmds.delete( m_deformers[i], constraints=True )
                        cmds.delete( m_deformers[i], inputConnectionsAndNodes=True )
                        cmds.delete( m_deformers[i] )
                    except:
                        pass
    
    def ml_getCurrentDeformations( self, node ):
        m_result = []
        if "."in node:
            node = node.split( "." )[0]
        m_history = cmds.listConnections( cmds.ls( node, dag=True, long=True ))
        m_history = cmds.ls( cmds.listHistory( m_history ), type=[ "lattice", "nonLinear", "transform" ], long=True )
        for i in range( 0, len( m_history )):
            if re.findall( "^deformer_|\|deformer_", m_history[i], re.IGNORECASE ):
                m_result.append( m_history[i] )
        return m_result    
    
    def ml_addContent( self ):
        m_content = ( str( self.m_selectionListModel.stringList().join( "," )).split( "," ))
        if len( "".join( m_content )) < 1:
            m_content = []
        m_nodes = cmds.ls( sl=True, type=[ "mesh", "transform" ], long=True )
        for i in range( 0, len( m_nodes )):
            if cmds.ls( m_nodes[i], dag=True, type="mesh" ) and m_nodes[i] not in m_content:
                m_content.append( m_nodes[i] )
        self.m_selectionListModel.setStringList( m_content )
    
    def ml_getSelectedItems( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            if m_indexes[i].isValid():
                m_temp = self.m_selectionListModel.data( m_indexes[i], 0 ).toString()
                m_temp = str( m_temp )
                m_result.append( m_temp )
        return m_result
    
    def ml_removeContent( self ):
        m_remove = self.ml_getSelectedItems()
        m_content = ( str( self.m_selectionListModel.stringList().join( "," )).split( "," ))
        for i in range( 0, len( m_remove )):
            if m_remove[i] in m_content:
                m_content.pop( m_content.index( m_remove[i] ))
        self.m_selectionListModel.setStringList( m_content )
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
    
    def ml_selectContent( self ):
        cmds.select( clear=True )
        m_selected = self.ml_getSelectedItems()
        for i in range( 0, len( m_selected )):
            if cmds.objExists( m_selected[i] ):
                cmds.select( m_selected[i], add=True )
                
class myDoubleSpinBox( QtGui.QDoubleSpinBox ):
    def __init__( self, parent=getMayaWindow() ):
        super( myDoubleSpinBox, self ).__init__( parent )

    def wheelEvent( self,event ):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QDoubleSpinBox.wheelEvent( self,event )
            
class mySpinBox( QtGui.QSpinBox ):
    def __init__( self, parent=getMayaWindow() ):
        super( mySpinBox, self ).__init__( parent )

    def wheelEvent( self,event ):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QSpinBox.wheelEvent( self,event )                 