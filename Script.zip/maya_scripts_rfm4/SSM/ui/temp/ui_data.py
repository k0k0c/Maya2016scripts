import site
import json
import codecs
import glob
import re
import main
#site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import sys, os, shutil
import sys

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import maya.OpenMayaUI as apiUI
import melnik_setup
import maya.mel as mel
import maya.OpenMayaUI as mui

   
def refnameTofname(x):
    return x.replace(".","_o_").replace("{","_p_").replace("}","_q_")

def fnameTorefname(x):
    return x.replace("_o_",".").replace("_p_","{").replace("_q_","}")
    
def fileExist(fileInput):
    try:
        cmds.file(fileInput,q=True,rfn=True)
        return True
    except:
        return False

def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return sip.wrapinstance(long(ptr), QtCore.QObject)


def FindAlembicSceneFolder(root=False,gpu=False):
    sss=mel.eval("rman getvar RMSPROJ")+"cache/alembic/"
    gpuString=""
    if gpu:
        gpuString="_gpu"
    addString=mel.eval("rman getvar STAGE")+"_new"+gpuString
    if not root:
       sss+=addString
    if not os.path.exists(sss):
        os.makedirs(sss)
    return sss



def uniqueTransforms( reference ):
    import maya.cmds as cmds
    result = []
    uniqueTransforms = []
    nodes = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    transforms = cmds.ls( nodes, dag=True, long=True )
    for transform in transforms:
        unique = True
        childs = cmds.ls( transform, dag=True )
        for child in childs:
            if cmds.referenceQuery( child, isNodeReferenced=True ):
                filename = cmds.referenceQuery( child, filename=True )
                if reference != filename:
                    unique = False
                    break
            else:
                unique = False
                break
        if unique is True:
            uniqueTransforms.append( transform )
    for uniqueTransform in uniqueTransforms:
        parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
        if parent:
            parent = parent[0]
            if parent not in uniqueTransforms:
                result.append( uniqueTransform )
        else:
            result.append( uniqueTransform )
    return result






class Window(QtGui.QDialog):
    def __init__(self, parent=getMayaWindow()):
        super(Window, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.loaded=[]
        self.setProperty("index","Data")
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setLayout(self.mainLayout)

    def load(self):
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect(self.currentWidgetSlot)        
        self.tabWidget.setStyleSheet("QTabWidget{background: rgb(68,68,68);}")
        self.AE=WindowAlembicExport()
        self.tabWidget.addTab(self.AE, "AE")
        self.mainLayout.addWidget(self.tabWidget)        
        self.AI=WindowAlembicImport()
        self.tabWidget.addTab(self.AI, "AI")
        self.mainLayout.addWidget(self.tabWidget)        
        self.readSettings()
        self.isLoad=True
        self.AE.installEventFilter(self)
        self.AI.installEventFilter(self)

    def currentWidgetSlot(self,wi):
        if wi not in self.loaded:
            self.tabWidget.widget(wi).load()
            self.loaded.append(wi)

    def eventFilter(self, obj, event):
        if (obj == self.AE or obj == self.AI) and event.type() == QtCore.QEvent.Show: 
            SSM = getMayaWindow().findChildren((QtGui.QDockWidget),"Yashka Return(CIT)")[0]
            if obj == self.AE and event.type() == QtCore.QEvent.Show:
                if SSM.sceneChanged != self.AE.sceneChanged:
                    self.AE.ml_update(SSM.sceneChanged) 
            elif obj == self.AI and event.type() == QtCore.QEvent.Show:
                if SSM.sceneChanged != self.AI.sceneChanged:
                    self.AI.ml_update(SSM.sceneChanged) 
        return False

    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("YashkaDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        pos = settings.value("tabWidget", "0").toInt()
        self.tabWidget.setCurrentIndex(pos[0])
        settings.endGroup()
    
    def writeSettings(self):
        if self.isLoad:
            settings = QtCore.QSettings("Melnitsa Soft", "Yago")
            settings.beginGroup("YashkaDialog")
            settings.setValue("posMayaApp", self.pos())
            settings.setValue("sizeMayaApp", self.size())
            settings.setValue("tabWidget", self.tabWidget.currentIndex())
            settings.endGroup()              
            for i in range(0,self.tabWidget.count()):
                if hasattr(self.tabWidget.widget(i), 'writeSettings'):
                    self.tabWidget.widget(i).writeSettings()

    def closeEvent(self, event):
        self.writeSettings()
        event.accept()




class ExportSpinBoxDelegate(QtGui.QItemDelegate):
    sT=QtCore.QVariant(0)
    sN=QtCore.QVariant(-1)

    #def __init__(self):
    #        super(QtGui.QItemDelegate, self).__init__()

    #def __init__(self,var):
    #        QtGui.QItemDelegate.__init__(self)
    #        sT=var

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        imageOffset=0
        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)
        elif index.data(QtCore.Qt.UserRole+1).toInt()[0] == 2:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.Dense6Pattern)
            painter.fillRect(option.rect,brush)
            #painter.drawImage( QtCore.QRect(option.rect.x()+2,option.rect.y()+2,option.rect.height()-4,option.rect.height()-4),QtGui.QImage("/Server-3d/Project/lib/setup/maya/maya_scripts_rfm4/SSM/resources/arrows-right-circular-icon.png"))
            #imageOffset=option.rect.height()

        one_width = 2
        if self.sT == 2:
            if index.data(QtCore.Qt.UserRole).toString()!="":
                textType = " ["+index.data(QtCore.Qt.UserRole).toString()[0:3]+"] "
                one_width = painter.fontMetrics().width(textType)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textType)
            elif index.data(QtCore.Qt.UserRole+2).toString()!="":
                textLoadedDraw=" ["+index.data(QtCore.Qt.UserRole+2).toString()+"] "
                one_width = painter.fontMetrics().width(textLoadedDraw)
                painter.drawText( option.rect.x()+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,textLoadedDraw)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        text_width = painter.fontMetrics().width(text)
        painter.drawText( option.rect.x()+one_width+imageOffset,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)

        overWidth=0
        '''if index.data(QtCore.Qt.UserRole+6).toString()!="":
            overText="    over    "
            overWidth = painter.fontMetrics().width(overText)
            painter.drawText( option.rect.x()+option.rect.width()-overWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,overText)
        '''
        proxyWidth=0
        if index.data(QtCore.Qt.UserRole+5).toString()!="":
            proxyText="     ["+index.data(QtCore.Qt.UserRole+5).toString()+"]"
            proxyWidth = painter.fontMetrics().width(proxyText)
            if option.rect.width()-overWidth-proxyWidth>one_width+imageOffset+text_width:
                painter.drawText( option.rect.x()+option.rect.width()-overWidth-proxyWidth,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,proxyText)



        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();

class ImportSpinBoxDelegate(QtGui.QItemDelegate):
    sN=QtCore.QVariant(-1)

    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051,option.palette.window().color())
        gradient.setColorAt(0.95,option.palette.window().color())
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

        colorONaydenom=QtGui.QColor(220,120,0,80)
        if index.data(QtCore.Qt.UserRole+1).toInt()[0] == 1:
            brush = QtGui.QBrush(colorONaydenom,QtCore.Qt.SolidPattern)
            painter.fillRect(option.rect,brush)

        serifFont=QtGui.QFont()
        serifFont.setBold(True)
        painter.setFont(serifFont)

        text = str(index.data(QtCore.Qt.DisplayRole).toString())
        if self.sN != -1:
            text=":".join(text.split(":")[-1-self.sN:])

        painter.drawText( option.rect.x()+2,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)


        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();








#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT
#######EEEEEEXXXXXXXXXXPPPPPPPPOOOOOOOOORRRRRRRRTTTTTTTT







class WindowAlembicExport(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowAlembicExport, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.sceneChanged=-2
        self.mainLayout.setSpacing(4)
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setProperty("index","Alembic Export")
        self.setLayout(self.mainLayout)


    def load(self):
        self.AEgroupBoxFind = QtGui.QVBoxLayout()
        self.framesLayout=QtGui.QHBoxLayout()
        self.framesLabel = QtGui.QLabel("Time range: ")
        self.TimeRangeBG = QtGui.QButtonGroup()
        self.rendSetR = QtGui.QRadioButton("Render settings")
        self.rendSetR.toggled.connect(self.setFrameRangeSlot)
        self.timeSliderR = QtGui.QRadioButton("Time slider")
        self.timeSliderR.toggled.connect(self.setFrameRangeSlot)
        self.startEndR = QtGui.QRadioButton("Custom")
        self.startEndR.toggled.connect(self.setFrameRangeSlot)
        self.TimeRangeBG.addButton(self.rendSetR)
        self.TimeRangeBG.addButton(self.timeSliderR)
        self.TimeRangeBG.addButton(self.startEndR)
        self.startEndLabel=QtGui.QLabel("start/end")
        self.startFrameSB = QtGui.QSpinBox()
        self.startFrameSB.setMaximum(100000)
        self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
        self.endFrameSB = QtGui.QSpinBox()
        self.endFrameSB.setMaximum(100000)
        self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
        self.framesLayout2=QtGui.QHBoxLayout()
        self.passesLabel=QtGui.QLabel("Passes: ")
        self.refPasses = QtGui.QSpinBox()
        self.refPasses.setValue(1)
        self.framesLayout.addWidget(self.framesLabel)
        self.framesLayout.addWidget(self.rendSetR)
        self.framesLayout.addWidget(self.timeSliderR)
        self.framesLayout.addWidget(self.startEndR)
        self.framesLayout.addStretch(1)
        self.framesLayout2.addWidget(self.startEndLabel)
        self.framesLayout2.addWidget(self.startFrameSB)
        self.framesLayout2.addWidget(self.endFrameSB)
        self.framesLayout2.addStretch(1)
        self.framesLayout2.addWidget(self.passesLabel)
        self.framesLayout2.addWidget(self.refPasses)

        self.AEgroupBoxFind.addLayout(self.framesLayout)        
        self.AEgroupBoxFind.addLayout(self.framesLayout2)        


        self.AEloadunloaded = QtGui.QCheckBox("load unloaded")

        self.options1Layout=QtGui.QHBoxLayout()
        self.labelSelectedMode=QtGui.QLabel("export: ")
        #self.AEExportAllChekbox = QtGui.QRadioButton("all")
        #self.AEExportAllChekbox.toggled.connect(self.exportAllstateChanged)
        self.AEExportAllLoadedChekbox = QtGui.QRadioButton("all loaded")
        self.AEExportAllLoadedChekbox.toggled.connect(self.exportAllLoadedstateChanged)
        self.AEExportChekbox = QtGui.QRadioButton("selected")
        self.AEExportChekbox.toggled.connect(self.exportstateChanged)
        self.AEExportAnimationChekbox = QtGui.QRadioButton("animation")
        self.AEExportAnimationChekbox.toggled.connect(self.exportanimationstateChanged)
        self.AECleanFolder = QtGui.QCheckBox("clean folder")
        self.AECleanFolder.setCheckState(QtCore.Qt.Checked)
        #self.options1Layout.addWidget(self.AEExportAllChekbox)
        self.options1Layout.addWidget(self.labelSelectedMode)
        self.options1Layout.addWidget(self.AEExportAllLoadedChekbox)
        self.options1Layout.addWidget(self.AEExportChekbox)
        self.options1Layout.addWidget(self.AEExportAnimationChekbox)
        self.options1Layout.addStretch(1)
        self.options1Layout.addWidget(self.AECleanFolder)
        self.AEgroupBoxFind.addLayout(self.options1Layout)        

        self.options2Layout=QtGui.QHBoxLayout()
        self.AEswithreferenceToOriginal = QtGui.QCheckBox("Switch proxy to original")
        self.AEswithreferenceToOriginal.setCheckState(QtCore.Qt.Checked)
        self.GEOGPUBG = QtGui.QButtonGroup()
        self.AECreateGpuCasheChekbox = QtGui.QRadioButton("GPU cashe")
        self.AECreateGeoCasheChekbox = QtGui.QRadioButton("Geo cashe")
        self.GEOGPUBG.addButton(self.AECreateGeoCasheChekbox)
        self.GEOGPUBG.addButton(self.AECreateGpuCasheChekbox)
        self.options2Layout.addWidget(self.AECreateGeoCasheChekbox)
        self.options2Layout.addWidget(self.AECreateGpuCasheChekbox)
        self.AEgroupBoxFind.addLayout(self.options2Layout)        

        self.AEExportButton = QtGui.QPushButton("Export")
        self.AEExportButton.released.connect(self.AEExportButtonSlot)
        self.options2Layout.addWidget(self.AEExportButton,1)

        self.oneWidget = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind = QtGui.QVBoxLayout()
        self.groupBoxFind.setSpacing(4)
        self.oneWidget.setLayout(self.groupBoxFind)
        self.groupBoxFind.setContentsMargins(3,3,3,3)
        self.twoLayout = QtGui.QHBoxLayout()
        self.twoLayout.setContentsMargins(0,0,0,0)
        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.released.connect(self.findText)
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit,1)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.groupBoxFind.addLayout(self.twoLayout)        



        self.showLabel = QtGui.QLabel("show type")
        self.checkShowType = QtGui.QCheckBox()
        self.namespaceLabel = QtGui.QLabel("namespace")
        self.checkShowNamespace = QtGui.QSpinBox()
        self.checkShowNamespace.setMinimum(-1)
        self.checkShowNamespace.setValue(-1)
        self.showNamespace=QtCore.QVariant(0)
        self.checkShowNamespace.connect(self.checkShowNamespace, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace)                
        self.showTypeLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showLabel)
        self.showTypeLayout.addWidget(self.checkShowType)
        self.showTypeLayout.addWidget(self.namespaceLabel)
        self.showTypeLayout.addWidget(self.checkShowNamespace)
        self.showTypeLayout.addStretch(1)

        self.showFindedLabel = QtGui.QLabel(" only found")
        self.checkShowFinded = QtGui.QCheckBox()
        self.checkShowFinded.setCheckState(QtCore.Qt.Unchecked)
        self.checkShowFinded.connect(self.checkShowFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded)                

        self.expandFindedLabel = QtGui.QLabel(" expand found")
        self.checkexpandFinded = QtGui.QCheckBox()
        self.checkexpandFinded.setCheckState(QtCore.Qt.Checked)
        self.checkexpandFinded.connect(self.checkexpandFinded, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetExpandFinded)                


        self.outLayout = QtGui.QHBoxLayout()
        self.outlonerLabel = QtGui.QLabel("Send")
        self.fromOutPushButton = QtGui.QPushButton("To")
        self.fromOutPushButton.setMinimumWidth( 10 )
        self.fromOutPushButton.released.connect(self.fromOutSlot)
        self.fromOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.toOutPushButton = QtGui.QPushButton("From")
        self.toOutPushButton.setMinimumWidth( 10 )
        self.toOutPushButton.released.connect(self.toOutSlot)
        self.toOutPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.outlonerLabel2 = QtGui.QLabel("Outliner")
        self.outLayout.addWidget(self.outlonerLabel)
        self.outLayout.addWidget(self.fromOutPushButton)
        self.outLayout.addWidget(self.toOutPushButton)
        self.outLayout.addWidget(self.outlonerLabel2)
        self.outLayout.addStretch(1)

        self.RELayout = QtGui.QHBoxLayout()
        self.referenceEditorLabel = QtGui.QLabel("Send")
        #self.fromREPushButton = QtGui.QPushButton("To")
        #self.fromREPushButton.setMinimumWidth( 10 )
        #self.fromREPushButton.released.connect(self.fromRESlot)
        #self.fromREPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.toREPushButton = QtGui.QPushButton("From")
        self.toREPushButton.setMinimumWidth( 10 )
        self.referenceEditorLabel2 = QtGui.QLabel("Reference editor")
        self.toREPushButton.released.connect(self.toRESlot)
        self.toREPushButton.setStyleSheet("QPushButton{padding: 2px;}")
        self.outLayout.addWidget(self.referenceEditorLabel)
        #self.outLayout.addWidget(self.fromREPushButton)
        self.outLayout.addWidget(self.toREPushButton)
        self.outLayout.addWidget(self.referenceEditorLabel2)
        self.outLayout.addStretch(1)

        self.collapsePushButton = QtGui.QPushButton("collapse all")
        self.collapsePushButton.released.connect(self.collapseAllSlot)
        self.showFindedLayout = QtGui.QHBoxLayout()
        self.showTypeLayout.addWidget(self.showFindedLabel)
        self.showTypeLayout.addWidget(self.checkShowFinded)
        self.showTypeLayout.addWidget(self.expandFindedLabel)
        self.showTypeLayout.addWidget(self.checkexpandFinded)
        self.showTypeLayout.addStretch(1)
        self.showFindedLayout.addWidget(self.collapsePushButton)
        self.showFindedLayout.addStretch(1)


        self.groupBoxFind.addLayout(self.showTypeLayout)
        self.groupBoxFind.addLayout(self.showFindedLayout)

        self.treeView = QtGui.QTreeView()
        #self.treeView.clicked.connect(self.activeCellData(self, QtCore.QModelIndex()))
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = ExportSpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)
        self.groupBoxFind.addWidget(self.treeView)        
        self.groupBoxFind.addLayout(self.outLayout)
        
        self.AEgroupBoxFind.addWidget(self.oneWidget)        
        self.mainLayout.addLayout(self.AEgroupBoxFind)
        self.checkShowType.connect(self.checkShowType, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowType)                
        self.checkShowType.setCheckState(QtCore.Qt.Checked)
        self.AEExportAllLoadedChekbox.setChecked(True)        
        self.AECreateGeoCasheChekbox.setChecked(True)        
        self.timeSliderR.setChecked(True)        
        self.isLoad=True


    def setFrameRangeSlot(self):
        if self.rendSetR.isChecked():
            self.startFrameSB.setValue(cmds.getAttr("defaultRenderGlobals.startFrame"))
            self.endFrameSB.setValue(cmds.getAttr("defaultRenderGlobals.endFrame"))
            self.startFrameSB.setDisabled(True)
            self.endFrameSB.setDisabled(True)
        elif self.timeSliderR.isChecked():
            self.startFrameSB.setValue(cmds.playbackOptions(query=True,animationStartTime=True))
            self.endFrameSB.setValue(cmds.playbackOptions(query=True,animationEndTime=True))
            self.startFrameSB.setDisabled(True)
            self.endFrameSB.setDisabled(True)
        elif self.startEndR.isChecked():
            self.startFrameSB.setDisabled(False)
            self.endFrameSB.setDisabled(False)


    def fromOutSlot(self):
        ar=[]
        for i in self.treeView.selectionModel().selectedRows():
            file=str(i.data(QtCore.Qt.UserRole+3).toString())
            isLoaded=1-int(cmds.file(file,q=True,dr=True))
            if isLoaded:
                temp=cmds.referenceQuery(file,n=True,dp=True)
                if temp:
                    ar+=temp
        cmds.select(cl=True)
        if ar:
            cmds.select(ar,ne=True)

    def toOutSlot(self):
        ar=cmds.ls(sl=True)
        fileList=[]
        for a in ar:
            temp=cmds.referenceQuery(a,f=True)
            if temp not in fileList:
                fileList.append(temp)
        if fileList:
            self.findText(massFiles=fileList,files=True)

    def toRESlot(self):
        ar=mel.eval("proc string[] blay(){global string $gReferenceEditorPanel;string $mmm[]=`lsUI -windows`;int $mozhno=0;for($m in $mmm){if(`gmatch $m \"*referenceEditorPanel*\"`){$mozhno=1;break;}}string $references[];if($mozhno){$references = `sceneEditor -q -selectReference $gReferenceEditorPanel`;return $references;}else{return $references;}}blay();")
        fileList=[]
        for a in ar:
            temp=cmds.referenceQuery(a,f=True)
            if temp not in fileList:
                fileList.append(temp)
        if fileList:
            self.findText(massFiles=fileList,files=True)

    def ml_update(self,sc):
        self.sceneChanged=sc
        self.setFrameRangeSlot()

    def stateChangetShowFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.showFindedRecurse(parentItem,typeIs)

    def showFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            if val:
                temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
                if temp > 0:
                    self.treeView.setRowHidden(chi,item.index(),False) 
                    self.showFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setRowHidden(chi,item.index(),True) 
            else:
                self.treeView.setRowHidden(chi,item.index(),False) 
                self.showFindedRecurse(item.child(chi,0),val)

    def stateChangetExpandFinded(self,typeIs):
        parentItem = self.treeModel.invisibleRootItem()
        self.expandFindedRecurse(parentItem,typeIs)

    def expandFindedRecurse(self,item,val):
        for chi in range(item.rowCount()):
            temp = item.child(chi,0).data(QtCore.Qt.UserRole+1).toInt()[0]
            if temp > 0:
                if val:
                        self.treeView.setExpanded(item.child(chi,0).index(),True) 
                        self.expandFindedRecurse(item.child(chi,0),val)
                else:
                    self.treeView.setExpanded(item.child(chi,0).index(),False) 


    def stateChangetShowNamespace(self,typeIs):
        self.delegate.sN=typeIs
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))


    def stateChangetShowType(self,typeIs):
        self.delegate.sT=QtCore.QVariant(typeIs)
        temp=self.treeModel.index(0,0)
        taak=self.treeView.isExpanded(temp)
        if taak:
            self.treeView.collapse(self.treeModel.index(0,0))
            self.treeView.expand(self.treeModel.index(0,0))
        else:
            self.treeView.expand(self.treeModel.index(0,0))
            self.treeView.collapse(self.treeModel.index(0,0))


    def exportstateChanged(self):
        self.AEExportButton.setText("Export selected")

    def exportAllLoadedstateChanged(self):
        self.AEExportButton.setText("Export All loaded")
        if self.AEExportAllLoadedChekbox.isChecked():
            self.AECleanFolder.setVisible(True) 
        else:
            self.AECleanFolder.setVisible(False) 


    def exportAllstateChanged(self):
        self.AEExportButton.setText("Export All")

    def exportanimationstateChanged(self):
        self.AEExportButton.setText("Export animation only")

    def collapseAllSlot(self):
        self.checkexpandFinded.setCheckState(QtCore.Qt.Unchecked)
        parentItem = self.treeModel.invisibleRootItem()
        self.collapseAllSlotRecurse(parentItem)

    def collapseAllSlotRecurse(self,item):
        for chi in range(item.rowCount()):
            self.treeView.setExpanded(item.child(chi,0).index(),False) 
            self.collapseAllSlotRecurse(item.child(chi,0))



    def loadReferenceFunction(self, referenceFile, rez, expandProxy=True, loadUnloaded=False, expandChildProxy=True, loadUnloadedChild=False):
        isLoaded=1-int(cmds.file(referenceFile,q=True,dr=True))
        if not isLoaded and loadUnloaded:
            cmds.file(referenceFile,loadReference=True)
            rn = cmds.file(referenceFile, query=True, reference=True )
            for r in rn:
                rez.append(self.loadReferenceFunction(r,rez,expandChildProxy,loadUnloadedChild,False,False))
            isLoaded=1

        if isLoaded:
            refNode=cmds.file(referenceFile,q=True,rfn=True)
            currentProxyTag=cmds.getAttr(refNode+".proxyTag")
            if expandProxy and not not currentProxyTag and currentProxyTag != "" and currentProxyTag != "original":
                    proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                    if proxyMnger:
                        proxyMnger=proxyMnger[0]
                        listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                        for lP in listProxyes:
                            if cmds.getAttr(lP+".proxyTag") == "" or cmds.getAttr(lP+".proxyTag") == "original":
                                self.proxyActivateFunction(lP)
                                rn = cmds.file(cmds.referenceQuery(lP,f=True), query=True, reference=True )
                                rez.append(cmds.referenceQuery(lP,f=True))
                                for r in rn:
                                    rez.append(self.loadReferenceFunction(r,rez,expandChildProxy,loadUnloadedChild,False,False))
            else:
                rez.append(referenceFile)


    def proxyActivateFunction(self,rnNode):
        proxyManager=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True)
        if proxyManager:
            proxyManager=proxyManager.split(".")[0]
        else:    
            return
        artiveProxy=cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0].split(".")[-1]
        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyManager+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
        currnetProxy=cmds.connectionInfo(rnNode+".proxyMsg",sfd=True).split(".")[-1]
        if artiveProxy != currnetProxy:
            cmds.disconnectAttr(proxyManager+".activeProxy",proxyManager+"."+artiveProxy)
            cmds.connectAttr(proxyManager+".activeProxy", proxyManager+"."+currnetProxy)
            filenameToUnload=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
            if filenameToUnload != "":
                if not cmds.file(filenameToUnload,q=True,dr=True):
                    cmds.file(filenameToUnload,unloadReference=artiveRnNode)
        filenameToLoad=cmds.reference(rfn=rnNode,q=True,filename=True)
        if filenameToLoad != "":
            cmds.file(filenameToLoad,loadReference=rnNode)
                
        srcLstPlugs=cmds.listConnections(artiveRnNode+".associatedNode",source=True,connections=True,plugs=True)
        if srcLstPlugs:
            for i in range(0,len(srcLstPlugs),2):
                    cmds.disconnectAttr(srcLstPlugs[i+1],srcLstPlugs[i])
                    cmds.connectAttr(srcLstPlugs[i+1],rnNode+"."+srcLstPlugs[i].split(".")[-1])



    def AEExportButtonSlot(self):
        start = cmds.timerX()
        
        ### geometry change attributes start
        setBool=1
        if self.AECreateGpuCasheChekbox.isChecked():
            setBool=0

        for im in cmds.ls(type="mesh",ni=True):
            if not cmds.attributeQuery("SubDivisionMesh",node=im,ex=True):
                cmds.addAttr(im,ln="SubDivisionMesh",at="bool",defaultValue=setBool)
            cmds.setAttr(im+".SubDivisionMesh",setBool)
        ### geometry change attributes end
        print "AE(1/5): ITERATE GEO: "+str(cmds.timerX(startTime=start))

        
        selectedFileslocal=[]

        if self.AEExportChekbox.isChecked():
            for i in self.treeView.selectionModel().selectedRows():
                selectedFileslocal.append(str(i.data(QtCore.Qt.UserRole+3).toString()))
        elif self.AEExportAnimationChekbox.isChecked():
            for i in main.animatedReferencedNodes(onlyFilename=True):
                selectedFileslocal.append(i)
        elif self.AEExportAllLoadedChekbox.isChecked():
            for i in main.listReferences(onlyLoaded=True,fullHierarchy=True):
                selectedFileslocal.append(i)


        gpu=False
        if self.AECreateGpuCasheChekbox.isChecked():
            gpu=True
        filePath=FindAlembicSceneFolder(False,gpu)+"/"

        if self.AEExportAllLoadedChekbox.isChecked() and self.AECleanFolder.isChecked():
            filesss = glob.glob(filePath+"*")
            for f in filesss:
                os.remove(f)    
            

        selectedFiles=[]
        for sF in range(len(selectedFileslocal)):
            self.loadReferenceFunction(selectedFileslocal[sF],selectedFiles,self.AEswithreferenceToOriginal.checkState()==QtCore.Qt.Checked,self.AEloadunloaded.checkState()==QtCore.Qt.Checked,True,False)
    
        print "AE(2/5): RELOAD PROXYES: "+str(cmds.timerX(startTime=start))
        
        ReferencesFilesAndNodes=main.listUniqueTransforms( selectedFiles, hasMesh=True, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True )

        dataFileABCRefs={}
        sceneName=cmds.file(q=True,sn=True)


        for sF in ReferencesFilesAndNodes:

            preloadTree=[]
            temp=sF
            while cmds.referenceQuery(temp,f=True,p=True):
                temp=cmds.referenceQuery(temp,f=True,p=True)
                if temp == sceneName:
                    break
                preloadTree.insert(0,temp)


            dataFileABCRefs[sF]={ "abcFiles":[], "namespace": cmds.referenceQuery(sF,ns=True), "parents": preloadTree }


            def hideParent(ttt):
                ttt = cmds.ls(ttt,l=True)[0]
                temp=ttt.split("|")
                if len(temp)>1:
                    for ifg in reversed(range(2,len(temp))):
                        tmp = "|".join(temp[:ifg])
                        if not cmds.getAttr(tmp+".visibility"):    
                            print "HIDED PARENT FOLDER: "+tmp
                            if not cmds.attributeQuery("ml_visibility",node=ttt,ex=True):
                                cmds.addAttr(ttt,ln="ml_visibility",at="bool",defaultValue=True)
                            cmds.setAttr(ttt+".ml_visibility",cmds.getAttr(ttt+".visibility"))
                            cmds.setAttr(ttt+".visibility",False)
                            break


            palenayaVersia=""
            for slovo in ReferencesFilesAndNodes[sF]:
                listFiles=cmds.ls(slovo,dag=True)
                net=1
                for i in listFiles:
                    if i.endswith("geometry_grp") and sF == cmds.referenceQuery(i,filename=True):
                        hideParent(i)
                        dataFileABCRefs[sF]["abcFiles"].append(i)
                        net=0
                    elif i.endswith("geo_normal") and sF == cmds.referenceQuery(i,filename=True):
                        hideParent(i)
                        dataFileABCRefs[sF]["abcFiles"].append(i)
                        net=0
                    elif i.endswith("switch_CT") and sF == cmds.referenceQuery(i,filename=True):
                        if cmds.ls(i+".position_modify"):
                            palenayaVersia = cmds.getAttr(i+".position_modify", asString=True)     
                        elif cmds.ls(i+".clothType"):
                            palenayaVersia = cmds.getAttr(i+".clothType", asString=True)
                        elif cmds.ls(i+".type_"):
                            palenayaVersia = cmds.getAttr(i+".type_", asString=True)

                if net:
                    hideParent(i)
                    dataFileABCRefs[sF]["abcFiles"].append(slovo)


            replacePers=main.getAssetFirstVersion(re.sub("\{[0-9]*\}","",sF),palevo=palenayaVersia)
            dataFileABCRefs[sF]["replaceReferenceVersion"]=replacePers


        print "AE(3/5) CATCH DATA: "+str(cmds.timerX(startTime=start))
        
        self.executeAlembic(dataFileABCRefs)
        print "AE(4/5): EXEC EXPORT: "+str(cmds.timerX(startTime=start))

        
        for dFAR in dataFileABCRefs:
            data={}
             
            if not self.AECreateGpuCasheChekbox.isChecked():
                data["namespaces"]=cmds.namespaceInfo(dataFileABCRefs[dFAR]["namespace"],lon=True,r=True,an=True)
             
                nodeNameExport={}
                listNodes=cmds.referenceQuery(dFAR,n=True,dp=True)
                for mP in cmds.ls(listNodes,type="partition"):
                    nodeNameExport[mP]={}
                    nodeNameExport[mP]["type"]=cmds.objectType(mP)
                    nodeNameExport[mP]["attributes"]={}
                    if cmds.attributeQuery("slimData",n=mP,ex=True):
                        temp=cmds.getAttr(mP+".slimData")
                        nodeNameExport[mP]["attributes"]["slimData"]={}
                        nodeNameExport[mP]["attributes"]["slimData"]["type"]=cmds.getAttr(mP+".slimData",typ=True)
                        if not temp:
                            temp=""
                        nodeNameExport[mP]["attributes"]["slimData"]["value"]=str(temp.encode("utf-8"))
                    if cmds.attributeQuery("slimRIB",n=mP,ex=True):
                        temp=cmds.getAttr(mP+".slimRIB")
                        nodeNameExport[mP]["attributes"]["slimRIB"]={}
                        nodeNameExport[mP]["attributes"]["slimRIB"]["type"]=cmds.getAttr(mP+".slimRIB",typ=True)
                        if not temp:
                            temp=""
                        nodeNameExport[mP]["attributes"]["slimRIB"]["value"]=str(temp.encode("utf-8"))
                    '''if cmds.attributeQuery("rlfData",n=mP,ex=True):
                        temp=cmds.getAttr(mP+".rlfData")
                        nodeNameExport[mP]["attributes"]["rlfData"]={}
                        nodeNameExport[mP]["attributes"]["rlfData"]["type"]=cmds.getAttr(mP+".rlfData",typ=True)
                        if not temp:
                            temp=""
                        nodeNameExport[mP]["attributes"]["rlfData"]["value"]=str(temp.encode("utf-8"))
                    '''

                data["nodes"]=nodeNameExport
             
             
            data["file"]=dFAR
            data["refsToFiles"]=dataFileABCRefs[dFAR]["abcFiles"]
            data["namespace"]=dataFileABCRefs[dFAR]["namespace"]
            data["parents"]=dataFileABCRefs[dFAR]["parents"]
            data["replaceReferenceVersion"]=dataFileABCRefs[dFAR]["replaceReferenceVersion"]

            
            m_file = file(filePath+refnameTofname(dFAR.split("/")[-1])+".js", "w" )
            json.dump( data, m_file, indent=4, ensure_ascii=False )
            m_file.close()

        dataMainSettings={}
        dataMainSettings["timeRange"]=[self.startFrameSB.value(),self.endFrameSB.value()]
        m_file = file(filePath+"/settings.js", "w" )
        json.dump( dataMainSettings, m_file, indent=4, ensure_ascii=False )
        m_file.close()
        print "AE(5/5): SAVE DATA: "+str(cmds.timerX(startTime=start))


    def executeAlembic(self,listObjects):
        stringToAlembic=""
        gpu=False
        alParametrsInput="-attr doubleSided -attr visibility -attrPrefix rman -uvWrite"
        if self.AECreateGpuCasheChekbox.isChecked():
            gpu=True
            alParametrsInput="-ro"

        for lO in listObjects:
            alParametrs=alParametrsInput
            abcFiles=""
            for af in listObjects[lO]["abcFiles"]:
                abcFiles+=" -root "+af
            if listObjects[lO]["replaceReferenceVersion"]!="" and not gpu:
                alParametrs=""
            stringToAlembic+=" -j \"-frameRange "+str(self.startFrameSB.value())+" "+str(self.endFrameSB.value())+" -worldSpace -dataFormat ogawa -writeVisibility -noNormals "+alParametrs+" "+abcFiles+" -file "+FindAlembicSceneFolder(False,gpu)+"/"+refnameTofname(lO.split("/")[-1])+".abc"+"\""    
            
        startTime=cmds.timerX()
        mel.eval("AbcExport -verbose "+stringToAlembic)
        print cmds.timerX(startTime=startTime)
        


    def findText(self,massFiles=[],files=False):   
        findTextLine = str(self.twoLineEdit.text())
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()
        #cmds.timer(s=True) 
        tree = []
        self.tree = []
        self.listReferences=[]
        self.loadAllrefs("",self.tree,self.tree,".*".join(findTextLine.split("*")),massFiles,files)
        self.printItemRefs(parentItem,self.tree)
        #print cmds.timer(e=True)
       
                        
    def printItemRefs(self, item, part):
        for i in range(len(part)):
            itemChild = QtGui.QStandardItem(part[i][5])
            itemChild.setData(part[i][2],QtCore.Qt.UserRole+2)
            itemChild.setData(part[i][3],QtCore.Qt.UserRole+3)
            itemChild.setData(part[i][5],QtCore.Qt.UserRole+4)
            itemChild.setData(part[i][6],QtCore.Qt.UserRole+5)
            itemChild.setData(part[i][7],QtCore.Qt.UserRole+6)
            itemChild.setData(part[i][1],QtCore.Qt.UserRole+1)
            #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            item.appendRow(itemChild)
            if self.checkShowFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] == "0":
                    self.treeView.setRowHidden(itemChild.row(),item.index(),True) 
            if self.checkexpandFinded.checkState()==QtCore.Qt.Checked:
                if part[i][1] != "0":
                    self.treeView.setExpanded(itemChild.index(),True) 
            self.printItemRefs(itemChild,part[i][4])    


    def loadAllrefs(self,f,tree,root,sear,massFiles=[],files=False):
        rn = cmds.file(f, query=True, reference=True )
        for r in rn:
            skolkoConnectov=cmds.listConnections(cmds.file(r,q=True,rfn=True)+".proxyMsg",d=True,s=True,type="proxyManager")
            proxyTag=cmds.getAttr(cmds.file(r,q=True,rfn=True)+".proxyTag")
            ifOverExists=""
            edem=1
            if skolkoConnectov:
                ifOverExists="1"
                if len(skolkoConnectov)==1:
                    edem=0  
            if edem:
                parentNamespace=cmds.file(r,query=True,pns=True)[0]
                namespaceThis=cmds.file(r,query=True,ns=True)
                if parentNamespace != "":
                    namespaceAll=parentNamespace+":"+namespaceThis
                else:
                    namespaceAll=namespaceThis
                isLoaded=1-int(cmds.file(r,q=True,dr=True))
                est="0"
                if sear!="" or files:
                    expression = re.compile(sear, re.IGNORECASE)
                    m=False
                    if files:
                        if r in massFiles:
                            m=True
                    else:
                        m = expression.search(namespaceThis)
                    if m:
                        est="1"
                        tempRoot=self.tree
                        for sp in parentNamespace.split(":"):
                            for tr in tempRoot:
                                if tr[0]==sp:
                                    if tr[1]!="1":
                                        tr[1]="2"
                                    tempRoot=tr[4]
                        
                root.append([namespaceThis,est,isLoaded,r,[],namespaceAll,proxyTag,ifOverExists])
                if isLoaded:
                    self.listReferences.append(r)
                temp=root[-1][4]
                self.loadAllrefs(r,self.tree,temp,sear,massFiles,files)








##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT
##########IIIIIMMMMMPPPPPPPOOOOOOORRRRRRTTTTTTT






class WindowAlembicImport(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowAlembicImport, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.isLoad=False
        self.sceneChanged=-2
        self.mainLayout.setSpacing(4)
        self.setProperty("index","Alembic Import")
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.setLayout(self.mainLayout)


    def load(self):
        self.treWLayout = QtGui.QVBoxLayout()
        self.treWLayout.setContentsMargins(0,0,0,0)

        self.importCacheLayout = QtGui.QHBoxLayout()
        self.labelToFolderCB=QtGui.QLabel("Cashe folder:")
        self.FolderCombobox = QtGui.QComboBox()
        self.m_renderTypeList = QtCore.QStringList()
        filesss = glob.glob(FindAlembicSceneFolder(root=True)+"*")
        self.m_renderTypeList.append("choose")
        filesssPath = []
        for f in filesss:
            self.m_renderTypeList.append( f.split("/")[-1] )
            filesssPath.append(f)
        self.FolderCombobox.addItems( self.m_renderTypeList )
        for f in range(len(filesssPath)):
            if f==0:
                self.FolderCombobox.setItemData(0,"",QtCore.Qt.UserRole)
            self.FolderCombobox.setItemData(f+1,filesssPath[f],QtCore.Qt.UserRole)

        self.importUnloadRefsChekbox = QtGui.QCheckBox("gpu:auto unload refs")
        self.importUnloadRefsChekbox.setCheckState(QtCore.Qt.Checked)
        self.importUnloadRefsChekbox.setVisible(False) 
        self.importTimeRangesChekbox = QtGui.QCheckBox("gpu:set frame range")
        self.importTimeRangesChekbox.setCheckState(QtCore.Qt.Checked)
        self.importTimeRangesChekbox.setVisible(False) 
        self.autoLoadOtherVersionChekbox = QtGui.QCheckBox("auto load render version")
        self.autoLoadOtherVersionChekbox.setCheckState(QtCore.Qt.Checked)

        self.importCacheLayout.addWidget(self.labelToFolderCB)
        self.importCacheLayout.addWidget(self.FolderCombobox)
        self.importCacheLayout.addStretch(1)
        self.importCacheLayout.addWidget(self.importUnloadRefsChekbox)
        self.importCacheLayout.addWidget(self.autoLoadOtherVersionChekbox)
        self.importCacheLayout.addWidget(self.importTimeRangesChekbox)

        self.radioLayout = QtGui.QHBoxLayout()
        self.importLabel = QtGui.QLabel("Import")
        self.importChekboxAll = QtGui.QRadioButton("all")
        self.importChekboxSelected = QtGui.QRadioButton("selected")
        self.importChekboxSelected.toggled.connect(self.importstateChanged)                
        self.importButton = QtGui.QPushButton("Import")
        self.importButton.released.connect(self.importButtonSlot)
        self.radioLayout.addWidget(self.importLabel)
        self.radioLayout.addWidget(self.importChekboxAll)
        self.radioLayout.addWidget(self.importChekboxSelected)
        self.radioLayout.addStretch(1)
        self.radioLayout.addWidget(self.importButton)





        self.oneWidget2 = QtGui.QGroupBox( " Find objects " )
        self.groupBoxFind2 = QtGui.QVBoxLayout()
        self.oneWidget2.setLayout(self.groupBoxFind2)
        self.groupBoxFind2.setContentsMargins(3,3,3,3)
        self.twoLayout2 = QtGui.QHBoxLayout()
        self.twoLayout2.setContentsMargins(0,0,0,0)
        self.twoLabel2 = QtGui.QLabel("Name: ")
        self.twoLineEdit2 = QtGui.QLineEdit()
        self.twoLineEdit2.setText("")        
        self.twoLineEdit2.returnPressed.connect(self.findTextImport)
        self.twoPushButton2 = QtGui.QPushButton("Find")
        self.twoPushButton2.released.connect(self.findTextImport)
        self.twoLayout2.addWidget(self.twoLabel2)
        self.twoLayout2.addWidget(self.twoLineEdit2,1)                        
        self.twoLayout2.addWidget(self.twoPushButton2)                        
        self.groupBoxFind2.addLayout(self.twoLayout2)        


        self.findOneLayout = QtGui.QHBoxLayout()
        self.namespaceLabel2 = QtGui.QLabel(" show namespace")
        self.checkShowNamespace2 = QtGui.QSpinBox()
        self.checkShowNamespace2.setMinimum(-1)
        self.checkShowNamespace2.setValue(-1)
        self.showNamespace2=QtCore.QVariant(0)
        self.checkShowNamespace2.connect(self.checkShowNamespace2, QtCore.SIGNAL("valueChanged(int)"), self.stateChangetShowNamespace2)                

        self.showFindedLabel2 = QtGui.QLabel(" only found")
        self.checkShowFinded2 = QtGui.QCheckBox()
        self.checkShowFinded2.setCheckState(QtCore.Qt.Checked)
        self.checkShowFinded2.connect(self.checkShowFinded2, QtCore.SIGNAL("stateChanged(int)"), self.stateChangetShowFinded2)                


        self.findOneLayout.addWidget(self.namespaceLabel2)
        self.findOneLayout.addWidget(self.checkShowNamespace2)
        self.findOneLayout.addWidget(self.showFindedLabel2)
        self.findOneLayout.addWidget(self.checkShowFinded2)
        self.findOneLayout.addStretch(1)
        self.groupBoxFind2.addLayout(self.findOneLayout)        


        self.treeView2 = QtGui.QTreeView()
        self.treeView2.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate2 = ImportSpinBoxDelegate()
        self.treeView2.setItemDelegate(self.delegate2)
        self.treeView2.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView2.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel2 = QtGui.QStandardItemModel()
        self.treeView2.setModel(self.treeModel2)
        self.treeView2.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView2.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView2.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView2.setHeaderHidden(True)
        self.groupBoxFind2.addWidget(self.treeView2)        


        self.treeViewGPU = QtGui.QTreeView()
        self.treeViewGPU.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegateGPU = ImportSpinBoxDelegate()
        self.treeViewGPU.setItemDelegate(self.delegateGPU)
        self.treeViewGPU.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeViewGPU.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModelGPU = QtGui.QStandardItemModel()
        self.treeViewGPU.setModel(self.treeModelGPU)
        self.treeViewGPU.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeViewGPU.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeViewGPU.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeViewGPU.setHeaderHidden(True)

        self.GPULayout = QtGui.QHBoxLayout()
        self.loadGPUButton = QtGui.QPushButton("Refresh")
        self.loadGPUButton.released.connect(self.GPUButtonSlot)
        self.switchGPUButton = QtGui.QPushButton("Switch")
        self.switchGPUButton.released.connect(self.switchGPUButtonSlot)
        self.GPULayout.addWidget(self.loadGPUButton)
        self.GPULayout.addWidget(self.switchGPUButton)

        self.treWLayout.addLayout(self.importCacheLayout)        
        self.treWLayout.addLayout(self.radioLayout)        
        self.treWLayout.addWidget(self.oneWidget2)
        self.treWLayout.addWidget(self.treeViewGPU)        
        self.treWLayout.addLayout(self.GPULayout)        
        self.importChekboxAll.setChecked(True)


        self.mainLayout.addLayout(self.treWLayout)
        self.FolderCombobox.currentIndexChanged.connect(self.changeFolderFiles)
        self.isLoad=True

    def ml_update(self,sc):
        self.sceneChanged=sc

    def GPUButtonSlot(self):
        self.treeModelGPU.clear()
        parentItem = self.treeModelGPU.invisibleRootItem()
        nodesss = cmds.ls("|system|gpu_cache",dag=True,type="gpuCache")
        for f in nodesss:
            itemChild = QtGui.QStandardItem(cmds.getAttr(f+".ml_namespace"))
            itemChild.setData(cmds.getAttr(f+".ml_origReferenceFile"),QtCore.Qt.UserRole)
            itemChild.setData(f,QtCore.Qt.UserRole+2)
            itemChild.setData(0,QtCore.Qt.UserRole+1)
            #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
            parentItem.appendRow(itemChild)

    def switchGPUButtonSlot(self):
        data={}
        folderPath=""
        for i in self.treeViewGPU.selectionModel().selectedRows():
            selectedFiles=str(i.data(QtCore.Qt.UserRole).toString())
            selectedNodes=str(i.data(QtCore.Qt.UserRole+2).toString())
            parentNode=cmds.listRelatives(selectedNodes,p=True)[0]
            fileJSPath=cmds.getAttr(parentNode+".cacheFileName").replace(".abc",".js")
            if os.path.exists(fileJSPath):
                fileOpen = open(fileJSPath).read()
                data = json.loads(fileOpen)
            if cmds.getAttr(parentNode+".visibility"):
                cmds.setAttr(parentNode+".visibility",0)
                for fRF in data["parents"]:
                    if cmds.file(fRF,q=True,dr=True):
                        cmds.file(fRF,loadReference=True,lrd="topOnly")
                if fileExist(selectedFiles):
                    refNode=cmds.file(selectedFiles,q=True,rfn=True)
                    proxyMnger=cmds.listConnections(cmds.file(selectedFiles,q=True,rfn=True)+".proxyMsg")
                    if proxyMnger:
                        proxyMnger=proxyMnger[0]
                        artiveProxy=cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0].split(".")[-1]
                        artiveRnNode=cmds.connectionInfo(cmds.connectionInfo(proxyMnger+".activeProxy",dfs=True)[0],dfs=True)[0].split(".")[0]
                        filenameToLoad=cmds.reference(rfn=artiveRnNode,q=True,filename=True)
                        if filenameToLoad != "":
                            if cmds.file(filenameToLoad,q=True,dr=True):
                                cmds.file(filenameToLoad,loadReference=artiveRnNode)
                    else:            
                        if cmds.file(selectedFiles,q=True,dr=True):
                            cmds.file(selectedFiles,loadReference=refNode)
            else:
                cmds.setAttr(parentNode+".visibility",1)
                nautiBilla=""
                try:
                    nautiBilla=cmds.file(selectedFiles,q=True,rfn=True)
                except:
                    pass
                if nautiBilla:
                    if cmds.file(selectedFiles,q=True,ex=True):
                        refNode=cmds.file(selectedFiles,q=True,rfn=True)
                        proxyMnger=cmds.listConnections(cmds.file(selectedFiles,q=True,rfn=True)+".proxyMsg")
                        if proxyMnger:
                            proxyMnger=proxyMnger[0]
                            listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                            for lP in listProxyes:
                                nextFile = cmds.referenceQuery(lP,f=True)
                                if not cmds.file(nextFile,q=True,dr=True):
                                    cmds.file(nextFile,unloadReference=lP)                
                        else:            
                            if not cmds.file(selectedFiles,q=True,dr=True):
                                cmds.file(selectedFiles,unloadReference=refNode)





    def findTextImport(self):
        findTextLine = str(self.twoLineEdit2.text())
        findTextLine = ".*".join(findTextLine.split("*"))
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.DisplayRole).toString()
                expression = re.compile(findTextLine, re.IGNORECASE)
                m = expression.search(temp)
                if m:
                    item.setData(1,QtCore.Qt.UserRole+1)
                    self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    item.setData(0,QtCore.Qt.UserRole+1)
                    if self.checkShowFinded2.checkState()==QtCore.Qt.Checked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 
                    else:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 

    def importstateChanged(self,a):
        if a:
            self.importButton.setText("Import selected")
        else:
            self.importButton.setText("Import All")


    def changeFolderFiles(self):
        if self.FolderCombobox.currentIndex()!=0:
            self.treeModel2.clear()
            parentItem = self.treeModel2.invisibleRootItem()
            folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
            filesss = glob.glob(folderPath+"/*.js")
            for f in filesss:
                if f.split("/")[-1]!="settings.js":
                    data={}
                    fileOpen=open(f).read()
                    data=json.loads(fileOpen)
                    itemChild = QtGui.QStandardItem(data["namespace"])
                    itemChild.setData(f,QtCore.Qt.UserRole)
                    itemChild.setData(0,QtCore.Qt.UserRole+1)
                    #itemChild.setData(QtCore.QSize(100,16),QtCore.Qt.SizeHintRole)            
                    parentItem.appendRow(itemChild)

        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if folderPath.endswith("_gpu"):
            self.importUnloadRefsChekbox.setVisible(True) 
            self.importTimeRangesChekbox.setVisible(True) 
            self.autoLoadOtherVersionChekbox.setVisible(False) 
        else:
            self.importUnloadRefsChekbox.setVisible(False) 
            self.importTimeRangesChekbox.setVisible(False) 
            self.autoLoadOtherVersionChekbox.setVisible(True) 



    def importButtonSlot(self): 
        for ddd in cmds.ls(type="camera",l=True):
            if cmds.camera(ddd,q=True,startupCamera=True):
                if ddd not in ["|front|frontShape","|persp|perspShape","|side|sideShape","|top|topShape"]:
                    cmds.camera(ddd,e=True,startupCamera=False)
                    print "Kamera popravlena: "+ddd

        selectedFiles=[]
        if self.importChekboxSelected.isChecked():
            for i in self.treeView2.selectionModel().selectedRows():
                selectedFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        else:
            parentItem = self.treeModel2.invisibleRootItem()
            for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                selectedFiles.append(str(item.data(QtCore.Qt.UserRole).toString()))

        folderPath=str(self.FolderCombobox.itemData(self.FolderCombobox.currentIndex(),QtCore.Qt.UserRole).toString())
        if folderPath.endswith("_gpu"):
            if cmds.ls("|system") == []:
                cmds.createNode("transform",n="system")    
            if cmds.ls("|system|gpu_cache") == []:
                cmds.createNode("transform",n="gpu_cache",p="system")    

        for ifn in selectedFiles:
            data={}
            fileOpen = open(ifn).read()
            data = json.loads( fileOpen )
            if folderPath.endswith("_gpu"):
                findedRefFile=data["file"]
                findedRefNamespace=data["namespace"]
                nameee=refnameTofname(findedRefFile.split("/")[-1])
                folderName=""
                if cmds.ls("|system|gpu_cache|"+nameee) == []:    
                    folderName = cmds.createNode("transform",n=nameee,p="|system|gpu_cache")
                else:
                    folderName=cmds.ls("|system|gpu_cache|"+nameee)[0] 
                nodeShapeName=""
                if cmds.ls("|system|gpu_cache|"+nameee,dag=True,type="gpuCache") == []:    
                    nodeShapeName=cmds.createNode("gpuCache",n=nameee+"Shape",p="|system|gpu_cache|"+folderName)
                else:
                    nodeShapeName=cmds.ls(nameee,dag=True,type="gpuCache")[0]
                cmds.setAttr(nodeShapeName+".cfn",ifn.replace(".js",".abc"),type="string")    

                if not cmds.attributeQuery("ml_origReferenceFile",n=nodeShapeName,ex=True):
                    cmds.addAttr(nodeShapeName,longName="ml_origReferenceFile",dt="string")
                cmds.setAttr(nodeShapeName+".ml_origReferenceFile",findedRefFile,type="string")
                if not cmds.attributeQuery("ml_namespace",n=nodeShapeName,ex=True):
                    cmds.addAttr(nodeShapeName,longName="ml_namespace",dt="string")
                cmds.setAttr(nodeShapeName+".ml_namespace",findedRefNamespace,type="string")

                if findedRefFile:
                    if self.importUnloadRefsChekbox.checkState()==QtCore.Qt.Checked:
                        if fileExist(findedRefFile):
                            refNode=cmds.file(findedRefFile,q=True,rfn=True)
                            proxyMnger=cmds.listConnections(refNode+".proxyMsg")
                            if proxyMnger:
                                proxyMnger=proxyMnger[0]
                                listProxyes=cmds.listConnections(proxyMnger+".proxyList",type="reference")
                                for lP in listProxyes:
                                    nextFile = cmds.referenceQuery(lP,f=True)
                                    if not cmds.file(nextFile,q=True,dr=True):
                                        cmds.file(nextFile,unloadReference=lP)                
                            else:            
                                if not cmds.file(findedRefFile,q=True,dr=True):
                                    cmds.file(findedRefFile,unloadReference=refNode)


                if self.importUnloadRefsChekbox.checkState()==QtCore.Qt.Checked:
                    dataMainSettings={}
                    fileOpen = open(folderPath+"/settings.js").read()
                    dataMainSettings = json.loads( fileOpen )
                    cmds.playbackOptions(animationStartTime=dataMainSettings["timeRange"][0])
                    cmds.playbackOptions(min=dataMainSettings["timeRange"][0])
                    cmds.playbackOptions(animationEndTime=dataMainSettings["timeRange"][1])
                    cmds.playbackOptions(max=dataMainSettings["timeRange"][1])
                
            else:
                replacePers=""
                if self.autoLoadOtherVersionChekbox.checkState()==QtCore.Qt.Checked:
                    replacePers=data["replaceReferenceVersion"]
                #if self.autoLoadOtherVersionChekbox.checkState()==QtCore.Qt.Checked:
                #    findedRefFile=data["file"]
                #    replacePers=main.getAssetFirstVersion(re.sub("\{[0-9]*\}","",findedRefFile))

                existsNameSpace=cmds.namespaceInfo(lon=True,r=True,an=True) 
                filenamespace=data["namespace"]
                if filenamespace not in existsNameSpace:
                    cmds.namespace(add=filenamespace)
                if data["namespaces"]:
                    for t in data["namespaces"]: 
                        if t not in existsNameSpace:
                            cmds.namespace(add=t)

                if "nodes" in data.keys():
                    for t in data["nodes"]:
                        if (replacePers and data["nodes"][t]["type"] != "partition") or (not replacePers):
                            if not cmds.objExists(t):
                                thisNode=cmds.createNode(data["nodes"][t]["type"])
                                thisNode=cmds.rename(thisNode,t)
                                for tt in data["nodes"][t]["attributes"]:
                                    if not cmds.attributeQuery(tt,n=thisNode,ex=True):
                                        cmds.addAttr(thisNode,longName=tt,dt=data["nodes"][t]["attributes"][tt]["type"])
                                    cmds.setAttr(thisNode+"."+tt,data["nodes"][t]["attributes"][tt]["value"],type=data["nodes"][t]["attributes"][tt]["type"])

                if replacePers:
                    if not cmds.namespaceInfo(filenamespace,ls=True):
                        print "LOAD RENDER VERSION:"+replacePers
                        cmds.file(replacePers,i=True,mergeNamespacesOnClash=True,namespace=filenamespace)

                mel.eval("AbcImport -mode import -fitTimeRange -connect \"/\" -setToStartFrame -createIfNotFound \""+ifn.replace(".js",".abc")+"\"")



    def stateChangetShowNamespace2(self,typeIs):
        self.delegate2.sN=typeIs
        temp=self.treeModel2.index(0,0)
        taak=self.treeView2.isExpanded(temp)
        if taak:
            self.treeView2.collapse(self.treeModel2.index(0,0))
            self.treeView2.expand(self.treeModel2.index(0,0))
        else:
            self.treeView2.expand(self.treeModel2.index(0,0))
            self.treeView2.collapse(self.treeModel2.index(0,0))

    def stateChangetShowFinded2(self,typeIs):
        parentItem = self.treeModel2.invisibleRootItem()
        for chi in range(parentItem.rowCount()):
                item = parentItem.child(chi,0)
                temp = item.data(QtCore.Qt.UserRole+1).toInt()[0]
                if self.checkShowFinded2.checkState()==QtCore.Qt.Unchecked:
                        self.treeView2.setRowHidden(chi,parentItem.index(),False) 
                else:
                    if not temp:
                        self.treeView2.setRowHidden(chi,parentItem.index(),True) 
