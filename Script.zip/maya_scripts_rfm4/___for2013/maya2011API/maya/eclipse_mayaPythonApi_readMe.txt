

##################################
Maya 2011 Python API Stub Files
for use with
Eclipse

##################################

Use these files to enable autocompletion
functionality in Eclipse when programming
with Maya 2011 Python API.

See tutorial on CreativeCrash.com


v. 01 - Dec 2008 - First release
v. 02 - Mar 2011 - Maya2011 API files