
'''
Stub class file for:
OpenMayaFX

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class MnCloth:
    '''Class for wrapping N cloth objects. This class wraps the internal Maya representation of N cloth objects suitable for use with the Nucleus solver. '''
    def __init__(self):
        pass


    def setInputMeshAttractPositions(self, positions): 
        '''setInputMeshAttractPositions(self, positions)
Arguments:
	[in]	positions = MFloatPointArray


Sets the positions for input mesh attract'''
        pass

    def setInputMeshAttractDamping(self, damping): 
        '''setInputMeshAttractDamping(self, damping)
Arguments:
	[in]	damping = float


Defines how springy the effect of Input Mesh Attract is. At a value of zero input mesh attract will behave like a spring connection from the input mesh to the output dynamic mesh. The cloth will tend to wiggle about the input mesh position. As the Input Attract Damp is increased to 1 the cloth mesh will still move to the input mesh position but not have the momentum to travel past it, so will no longer occillate about the input position.'''
        pass

    def setTangentialDrag(self, tangentialDrag): 
        '''setTangentialDrag(self, tangentialDrag)
Arguments:
	[in]	tangentialDrag = float


Sets the tangential drag values for the cloth. Defines the component of drag tangent to the surface. With a value of zero a flat plane will slice through air with no resistance and only have drag when moving along its normal axis. With a value of 1.0 the effect of drag will be equal in all directions.'''
        pass

    def setThickness(self, radius): 
        '''setThickness(self, radius)
Arguments:
	[in]	radius = float


sets a radius (thickness) on a per point basis for the mesh for collision purposes. The bigger the radius, the more easily things collide.'''
        pass

    def getNumVertices(self, numVerts): 
        '''getNumVertices(self, numVerts)
Arguments:
	[out]	numVerts = int


Returns the number of vertices in the underlying n Cloth'''
        pass

    def setInverseMass(self, invMass): 
        '''setInverseMass(self, invMass)
Arguments:
	[in]	invMass = float


sets the mass on a per point basis in this mesh'''
        pass

    def setSelfCollisionSoftness(self, softness): 
        '''setSelfCollisionSoftness(self, softness)
Arguments:
	[in]	softness = float


This allows one to lower the repulsive force of self collisions such that some interpenetration within the collide width is allowed. This can in some cases reduce jitter due to self collision with low selfCollideIterations. In general its use should be avoided, however.'''
        pass

    def setSealHoles(self, seal): 
        '''setSealHoles(self, seal)
Arguments:
	[in]	seal = bool


When the volume tracking pressure method is used this determines if physical holes in the cloth model are treated as being capped or not. If holes are not sealed, then air can escape out them, which also has the effect of pushing the cloth. For example, this can simulate a rubber balloon that is suddenly released. It also allows for inflow based on motion of the cloth. The opening in a parachute will allow air to flow in as it falls down, causing sideways pressure that inflates it. Note that drag alone cannot achieve this sort of effect'''
        pass

    def setSelfCollideWidth(self, width): 
        '''setSelfCollideWidth(self, width)
Arguments:
	[in]	width = float


Sets the self collision width'''
        pass

    def setBendRestAngleFromPositions(self, positions): 
        '''setBendRestAngleFromPositions(self, positions)
Arguments:
	[in]	positions = MFloatPointArray


Sets the the bend rest angle from the list of positions for the underlying N Object This sets the shape that bend resistance is trying to achieve.'''
        pass

    def setShearResistance(self, resistance): 
        '''setShearResistance(self, resistance)
Arguments:
	[in]	resistance = float


Sets the shear resistance. Shear can be thought of as the bend in the plane of the cloth.'''
        pass

    def setPressureDamping(self, damp): 
        '''setPressureDamping(self, damp)
Arguments:
	[in]	damp = float


Sets the damping value for pressure'''
        pass

    def setDamping(self, damping): 
        '''setDamping(self, damping)
Arguments:
	[in]	damping = float


sets the on a per point basis in this mesh'''
        pass

    def setTrackVolume(self, track): 
        '''setTrackVolume(self, track)
Arguments:
	[in]	track = bool


 Parameters: 
 
 [in]   track   whether to track volume 
 
 
 Returns: 
 MS::kSuccess  the operation was completed successfully  
 MS::kFailure  the operation failed  
 
 
'''
        pass

    def setSelfCrossoverPush(self, val): 
        '''setSelfCrossoverPush(self, val)
Arguments:
	[in]	val = float


See node documentation.'''
        pass

    def setInputMeshAttractAndRigidStrength(self, inputAttractArray, rigidArray, deformArray): 
        '''setInputMeshAttractAndRigidStrength(self, inputAttractArray, rigidArray, deformArray)
Arguments:
	[in]	inputAttractArray = float
	[in]	rigidArray = float
	[in]	deformArray = float


Sets on a per particle basis, the amount by which each particle is affected by the input mesh attract, rigidity, and deformability. High values for the input mesh attract will make points stick closely to the input mesh. High values for the rigidArray will make the object behave like a rigid body.'''
        pass

    def setRestitutionTension(self, tension): 
        '''setRestitutionTension(self, tension)
Arguments:
	[in]	tension = float


How far can the links be stretched before they fail to go back to their rest length when there are no forces acting on the cloth. When the tension is greater than the defined value the defined rest length will increase until the tension is equal this value. For very low values the material will pull apart like taffy, yet still resist stretching under mild forces.'''
        pass

    def createNCloth(self): 
        '''createNCloth(self)

Creates the underlying Maya TnCloth and sets this class to wrap it.'''
        pass

    def setLinksRestLengthFromPositions(self, positions): 
        '''setLinksRestLengthFromPositions(self, positions)
Arguments:
	[in]	positions = MFloatPointArray


Sets the the rest length from the list of positions for the underlying N Object. This sets the shape that the stretch/compression resistance are trying to achieve.'''
        pass

    def setIncompressibility(self, v): 
        '''setIncompressibility(self, v)
Arguments:
	[in]	v = float


When the volume tracking pressure model is used this defines how incompressible the internal volume of fluid is. This also will affect how much force is applied to the cloth when air is pumped in. In the case of a balloon higher values of incompressibility will overcome higher stretch resistance. Note that higher incompressibility may require more calculation time.'''
        pass

    def setPressure(self, pressure): 
        '''setPressure(self, pressure)
Arguments:
	[in]	pressure = float


Sets the pressure within the cloth. This defines a force applied along the surface normal direction'''
        pass

    def setAddCrossLinks(self, addCrossLinks): 
        '''setAddCrossLinks(self, addCrossLinks)
Arguments:
	[in]	addCrossLinks = float


For faces with more than 3 vertices this will create additional stretch and bends links such that each vertex is connected to each other vertex. If this is off then the links will exactly match the meshes list of edges. For a quad meshes having addCrossLinks off would allow the cloth to shear, unless shear resistance was used.'''
        pass

    def setBendAngleScale(self, scale): 
        '''setBendAngleScale(self, scale)
Arguments:
	[in]	scale = float


Defines the amount by which the rest state of the bend angle is scaled.'''
        pass

    def setTopology(self, numFaces, numVertsPerFace, faces, numEdges, edges): 
        '''setTopology(self, numFaces, numVertsPerFace, faces, numEdges, edges)
Arguments:
	[in]	numFaces = int
	[in]	numVertsPerFace = int
	[in]	faces = int
	[in]	numEdges = int
	[in]	edges = int


sets the topology of the underlying N Object. Before calling other methods, this must be the first method you call once the cloth object is created.'''
        pass

    def setComputeRestAngles(self, b): 
        '''setComputeRestAngles(self, b)
Arguments:
	[in]	b = bool


Sets whether rest angles will be automatically computed, or overridden manually. If this is set to false, then you must call  setBendRestAngleFromPositions()  to set the rest lengths.'''
        pass

    def setSelfTrappedCheck(self, on): 
        '''setSelfTrappedCheck(self, on)
Arguments:
	[in]	on = bool


This tracks self collision crossovers and attempts to push the crossed over points back. It assumes that the surface is in a good state at the start and attempts to preserve that relative state. It is useful in cases where cloth can get caught between passive objects than interpenetrate (for example an elbow passing through a chest). Rather than get stuck on the wrong side this allows the cloth to push back to the correct side when the passive objects later separate.'''
        pass

    def getPositions(self, positions): 
        '''getPositions(self, positions)
Arguments:
	[out]	positions = MFloatPointArray


gets the positions of the points of the underlying N Object.'''
        pass

    def setSelfCollisionFlags(self, vertToVert, vertToEdge, vertToFace, edgeToEdge, edgeToFace): 
        '''setSelfCollisionFlags(self, vertToVert, vertToEdge, vertToFace, edgeToEdge, edgeToFace)
Arguments:
	[in]	vertToVert = bool
	[in]	vertToEdge = bool
	[in]	vertToFace = bool
	[in]	edgeToEdge = bool
	[in]	edgeToFace = bool


Sets how (or if) this object will collide with itself.'''
        pass

    def setStartPressure(self, startPressure): 
        '''setStartPressure(self, startPressure)
Arguments:
	[in]	startPressure = float


With the volume tracking pressure method this defines the relative air pressure inside the object at the startframe.'''
        pass

    def setBendResistance(self, strength): 
        '''setBendResistance(self, strength)
Arguments:
	[in]	strength = float


Bend resistance measures the amount of attraction to the restAngle, which is defined between cvs on either side of an edge. Larger values will tend to make the surface more rigid and will take longer to compute.'''
        pass

    def getVelocities(self, velocities): 
        '''getVelocities(self, velocities)
Arguments:
	[out]	velocities = MFloatPointArray


gets the velocities of the points of the underlying N cloth object.'''
        pass

    def setVelocities(self, velocities): 
        '''setVelocities(self, velocities)
Arguments:
	[in]	velocities = MFloatPointArray


Sets the velocities of the vertices of the underlying Ncloth object'''
        pass

    def setPositions(self, positions, startFrame): 
        '''setPositions(self, positions, startFrame)
Arguments:
	[in]	positions = MFloatPointArray
	[in]	startFrame = bool


Sets the positions of the vertices of the underlying N cloth object'''
        pass

    def setBendAngleDropoff(self, dropoff): 
        '''setBendAngleDropoff(self, dropoff)
Arguments:
	[in]	dropoff = float


Defines the way bend resistance changes with the angle. At higher values the bend will resist more at high angles then when the surface is nearly flat.'''
        pass

    def setMaxSelfCollisionIterations(self, it): 
        '''setMaxSelfCollisionIterations(self, it)
Arguments:
	[in]	it = int


Sets the number of iterations the solver will perform for self collisions on this object.'''
        pass

    def setDragAndLift(self, drag, lift): 
        '''setDragAndLift(self, drag, lift)
Arguments:
	[in]	drag = float
	[in]	lift = float


Sets the drag and lift values for the cloth'''
        pass

    def setAirTightness(self, airTightness): 
        '''setAirTightness(self, airTightness)
Arguments:
	[in]	airTightness = float


Defines the rate at which air can escape from the object, or how permiable the surface is. This is in addition to any physical holes in the model, which can be be capped or not using the seal holes method.'''
        pass

    def setStretchAndCompressionResistance(self, stretchResist, compressionResist): 
        '''setStretchAndCompressionResistance(self, stretchResist, compressionResist)
Arguments:
	[in]	stretchResist = float
	[in]	compressionResist = float


Sets the stretch and compression resistance for the mesh on a per vertex basis'''
        pass

    def setBounce(self, bounce): 
        '''setBounce(self, bounce)
Arguments:
	[in]	bounce = float


sets the bounce on a per point basis in this mesh'''
        pass

    def setFriction(self, friction): 
        '''setFriction(self, friction)
Arguments:
	[in]	friction = float


sets the friction on a per point basis for this mesh'''
        pass

    def setRestitutionAngle(self, angle): 
        '''setRestitutionAngle(self, angle)
Arguments:
	[in]	angle = float


Defines how far we can bend across an edge before it will fail to go back to the rest angle when there are no forces acting on the cloth.'''
        pass

    def setComputeRestLength(self, b): 
        '''setComputeRestLength(self, b)
Arguments:
	[in]	b = bool


Sets whether rest lengths will be automatically computed, or overridden manually. If this is set to false, then you must call  setLinksRestLengthFromPositions()  to set the rest lengths.'''
        pass

    def setCollisionFlags(self, vertToVert, edgeToEdge, faceToFace): 
        '''setCollisionFlags(self, vertToVert, edgeToEdge, faceToFace)
Arguments:
	[in]	vertToVert = bool
	[in]	edgeToEdge = bool
	[in]	faceToFace = bool


Sets how (or if) this object will collide with other objects.'''
        pass

    def setPumpRate(self, pump): 
        '''setPumpRate(self, pump)
Arguments:
	[in]	pump = float


Defines the rate at which air pressure is added to the object'''
        pass

    def setMaxIterations(self, it): 
        '''setMaxIterations(self, it)
Arguments:
	[in]	it = int


Sets the number of iterations the solver will perform on various dynamic properties like drag, damping, stretch and bend. Higher iterations take longer, and the primary use of this attribute is to keep things from locking up should high iteration values be requested.'''
        pass

    def setDisableGravity(self, b): 
        '''setDisableGravity(self, b)
Arguments:
	[in]	b = bool


Sets whether gravity will affect this object'''
        pass

class MDynamicsUtil:
    '''Utility class for Maya dynamics. MDynamicsUtil provides utility methods related to Maya dynamics (eg. particles and fluids). '''
    def __init__(self):
        pass


    def evalDynamics2dTexture(self, node, texAttr, uCoords, vCoords, resultColors, resultAlphas): 
        '''evalDynamics2dTexture(self, node, texAttr, uCoords, vCoords, resultColors, resultAlphas)
Arguments:
	[in]	node = MObject
	[in]	texAttr = MObject
	[in]	uCoords = MDoubleArray
	[in]	vCoords = MDoubleArray
	[out]	resultColors = MVectorArray
	[out]	resultAlphas = MDoubleArray


If a supported 2d texture (see  hasValidDynamics2dTexture()  method documentation) is connected to the specified attribute, this method can be called to evaluate that texture at a number of (u,v) texture coordinate values.'''
        pass

    def hasValidDynamics2dTexture(self, node, texAttr): 
        '''hasValidDynamics2dTexture(self, node, texAttr) -> bool
Returns: true if the node connected to the specified attribute is a texture that can be evaluated using the evalDynamics2dTexture() method, false otherwise. 

Arguments:
	[in]	node = MObject
	[in]	texAttr = MObject


Certain aspects of Maya's dynamics can be textured using 2d textures. For example, surface particle emitters can use a 2d texture to modulate the emission rate over the surface. For these purposes, only a subset of Maya's textures are supported, namely the default 2d textures (bulge, checker, cloth, file, fluid texture 2d, fractal, grid, mountain, movie, noise, ocean, ramp, water). No other nodes are supported. This method takes an attribute and determines if there is a supported texture connected to it. If the texture is supported, then the  evalDynamics2dTexture()  method can be called to evaluate the texture at various (u,v) coordinate values.'''
        pass

class MDynSweptLine:
    '''Class for evaluating curve segments as lines over time. A MDynSweptLine provides access to a curve segment defined as a line. It can only be accessed with the MFnDynSweptGeometryData class that is provided as an output from the geoConnector node.The class provides parametric time evaluation for a curve. Time is in the range 0 to 1, where 1 represents the current frame and 0 represents the previous frame. In this way you can get interpolated values of a curve in motion. '''
    def __init__(self):
        pass


    def tangent(self, t): 
        '''tangent(self, t) -> MVector
Returns: A normalized vector 

Arguments:
	[in]	t = double


Given a parametric time specified by 't', returns normalized tangent of the line.'''
        pass

    def length(self, t): 
        '''length(self, t) -> double
Returns: Total line length 

Arguments:
	[in]	t = double


Given a parametric time specified by 't', returns the total length of the line.'''
        pass

    def vertex(self, vertexId, t): 
        '''vertex(self, vertexId, t) -> MVector
Returns: The vertex position 

Arguments:
	[in]	vertexId = int
	[in]	t = double


Return the vertex requested by id, at the parametric time value.'''
        pass

    def normal(self, x, y, z, t): 
        '''normal(self, x, y, z, t) -> MVector
Returns: A normalized vector 

Arguments:
	[in]	x = double
	[in]	y = double
	[in]	z = double
	[in]	t = double


Given a parametric time specified by 't' and a vector, returns a normalized vector perpendicular to the tangent, and rotated into the plane defined by the tangent and vector argument.'''
        pass

class MDynSweptTriangle:
    '''Class for evaluating surfaces as triangles over time. MDynSweptTriangle provides access to surfaces (Nurbs and Polys) defined as triangles. It can only be accessed with the MFnDynSweptGeometryData class that is provided as an output from the geoConnector node.The class provides parametric time evaluation for a triangle. Time is in the range 0 to 1, where 1 represents the current frame and 0 represents the previous frame. In this way you can get interpolated values of a triangle in motion. '''
    def __init__(self):
        pass


    def area(self): 
        '''area(self) -> double


This method returns the area.'''
        pass

    def vertex(self, vertexId, t): 
        '''vertex(self, vertexId, t) -> MVector
Returns: The vertex position. 

Arguments:
	[in]	vertexId = int
	[in]	t = double


Return the vertex requested by id, at the parametric time value.'''
        pass

    def normalToPoint(self, x, y, z, t): 
        '''normalToPoint(self, x, y, z, t) -> MVector
Returns: A normalized vector 

Arguments:
	[in]	x = double
	[in]	y = double
	[in]	z = double
	[in]	t = double


Given a point, returns the normal of the triangle in the direction towards the point. Determines which side of the triangle to return the normal.'''
        pass

    def uvPoint(self, vertexId): 
        '''uvPoint(self, vertexId) -> MVector
Returns: A vector. The u and v values are stored in the first two coordinates. The third coordinate is not meaningful. 

Arguments:
	[in]	vertexId = int


Given a vertex id, this method returns the UV point for the vertex as a  MVector .'''
        pass

    def normal(self, t): 
        '''normal(self, t) -> MVector
Returns: A normalized vector 

Arguments:
	[in]	t = double


Given a parametric time specified by 't', returns the normal of the triangle.'''
        pass

class MFnAirField:
    '''Function set for Air Fields. Function set for creation, edit, and query of Air Fields.An air field simulates the effects of moving air. '''
    def __init__(self):
        pass


    def direction(self): 
        '''direction(self) -> MVector
Returns: A vector representing direction.


Returns the direction the air is blowing.'''
        pass

    def setInheritRotation(self, enable): 
        '''setInheritRotation(self, enable)
Arguments:
	[in]	enable = bool


Enables the air field to undergo rotations and effect the direction that the air field points.'''
        pass

    def componentOnly(self): 
        '''componentOnly(self) -> bool
Returns: true Force applied only in direction of attributes. 
false Force applied to match velocities.


Returns true if the air field will apply force only in the direction specified by the combination of its direction, speed, and inherit velocity attributes. Returns false if the force is made to effect the object's velocity to match the air field's velocity.'''
        pass

    def setDirection(self, airDirection): 
        '''setDirection(self, airDirection)
Arguments:
	[in]	airDirection = MVector


Sets the direction vector for the air to blow.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setSpread(self, value): 
        '''setSpread(self, value)
Arguments:
	[in]	value = double


Sets the value representing an angle which objects are affected by the air fields direction setting. This value is taken into account when the Enable Spread attribute is turned on.'''
        pass

    def inheritVelocity(self): 
        '''inheritVelocity(self) -> double
Returns: A value from 0 to 1 representing the amount of velocity added.


Returns the amount of the moving air field's velocity that is added to the direction and magnitude of the wind.'''
        pass

    def setSpeed(self, value): 
        '''setSpeed(self, value)
Arguments:
	[in]	value = double


Sets the control setting on how quickly the objects match the velocity of the air field.'''
        pass

    def spread(self): 
        '''spread(self) -> double
Returns: A value from 0 to 1 representing an angle. 
A value of 0 effects objects only exactly in front of the direction vector. 
A value of 1 effects objects in front by 180 degrees along the direction vector.


Returns a value that represents an angle which objects are affected by the air fields direction setting. This value is taken into account when the Enable Spread attribute is turned on.'''
        pass

    def enableSpread(self): 
        '''enableSpread(self) -> bool
Returns: true Objects are affected in the area of the spread angle. 
false Objects are affected by the max distance setting.


Returns true if the air field is using the spread angle to define the influence of the air field.'''
        pass

    def setInheritVelocity(self, velocity): 
        '''setInheritVelocity(self, velocity)
Arguments:
	[in]	velocity = double


Sets the amount of the moving air field's velocity that is added to the direction and magnitude of the wind.'''
        pass

    def inheritRotation(self): 
        '''inheritRotation(self) -> bool
Returns: true Rotations will change the direction the air field points. 
false Rotations do not change the air field direction.


Returns true if the air field is rotating or parented to a rotating object, and will undergo that same rotation.'''
        pass

    def setComponentOnly(self, enable): 
        '''setComponentOnly(self, enable)
Arguments:
	[in]	enable = bool


Enables the air field to apply force specified as a combination of its direction, speed, and inherit veloicty attributes.'''
        pass

    def speed(self): 
        '''speed(self) -> double
Returns: The value of the speed setting.


Returns the control setting on how quickly objects match the velocity of the air field.'''
        pass

    def setEnableSpread(self, enable): 
        '''setEnableSpread(self, enable)
Arguments:
	[in]	enable = bool


Enables the air field to influence objects based on the spread angle setting.'''
        pass

class MFnDragField:
    '''Function set for Drag Fields. Function set for creation, edit, and query of Drag Fields.A drag field exerts a friction, or braking force, proportional to the speed of a moving object. '''
    def __init__(self):
        pass


    def useDirection(self): 
        '''useDirection(self) -> bool
Returns: true Use the direction setting to determine the braking force. 
false Use the objects velocity to determine the braking force.


Returns true if the braking force is exerted only against the component of the object's velocity that lies along the direction of the drag force.'''
        pass

    def direction(self): 
        '''direction(self) -> MVector
Returns: A vector representing direction.


Returns the direction of the drag force's influence along the x, y, and z axes. You must have the Use Direction setting turned on for this attribute to take effect.'''
        pass

    def setUseDirection(self, enable): 
        '''setUseDirection(self, enable)
Arguments:
	[in]	enable = bool


Enables the braking force to be exerted only against the component of the object's velocity that lies along the direction setting of the drag force.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setDirection(self, dragDirection): 
        '''setDirection(self, dragDirection)
Arguments:
	[in]	dragDirection = MVector


Sets the direction of the drag force's influence along the x, y, and z axes. You must have the Use Direction setting turned on for this attribute to take effect.'''
        pass

class MFnDynSweptGeometryData:
    '''Swept Geometry function set for dependency node data. MFnDynSweptGeometryData provides access to the MDynSweptLine and MDynSweptTriangle data for use in a user defined dependency graph node. The data is provided as an output from the geoConnector node and is primarily used to determine positional information over time.If a user written dependency node accepts MFnDynSweptGeometryData, then this class is used to extract data that comes from the geoConnector node. The MDataHandle::type method will return kDynSweptGeometry when data of this type is present. To access it, the MDataHandle::data() method is used to get an MObject for the data and this should then be used to initialize an instance of MFnDynSweptGeometryData.Important note: Users can create the data for connections but cannot produce the contents of the data as this is reserved for the Maya Dynamics internals. '''
    def __init__(self):
        pass


    def triangleCount(self): 
        '''triangleCount(self) -> int
Returns: Number of triangles 


Return the number of triangles contained in the data.'''
        pass

    def create(self): 
        '''create(self) -> MObject
Returns: A handle to the new swept geometry data object


This method create a new swept geometry data object for use with the dependency graph.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def lineCount(self): 
        '''lineCount(self) -> int
Returns: Number of line segments 


Return the number of line segments contained in the data.'''
        pass

    def sweptTriangle(self, index): 
        '''sweptTriangle(self, index) -> MDynSweptTriangle

Arguments:
	[in]	index = int


Return a constant reference to the swept triangle data.'''
        pass

    def sweptLine(self, index): 
        '''sweptLine(self, index) -> MDynSweptLine

Arguments:
	[in]	index = int


Return a constant reference to the swept line data.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnField:
    '''Function set for Dynamic Fields. Function set for creation, edit, and query of Dynamic Fields.There are several types of dynamic fields: Air, Drag, Gravity, Newton Radial, Turbulence, Uniform, and Vortex. '''
    def __init__(self):
        pass


    def isFalloffCurveConstantOne(self): 
        '''isFalloffCurveConstantOne(self) -> bool
Returns: If falloff curve always returns a constant one


Returns true if falloffCurve is a constant one (default) or false if not.'''
        pass

    def useMaxDistance(self): 
        '''useMaxDistance(self) -> bool
Returns: true Field uses the maximum distance setting. 
false Field ignores the maximum distance setting.


Returns true if the field will use the maximum distance setting to determine the area of influence.'''
        pass

    def attenuation(self): 
        '''attenuation(self) -> double
Returns: A positive value representing the exponent for rate of change. 
A value of 0 and the force remains constant over distance.


Returns the rate of change where the strength of the field changes as the distance between the field and the affected object increases.'''
        pass

    def setAttenuation(self, atten): 
        '''setAttenuation(self, atten)
Arguments:
	[in]	atten = double


Sets the rate of change where the strength of the field changes as the distance between the field and the affected object increases.'''
        pass

    def maxDistance(self): 
        '''maxDistance(self) -> double
Returns: A value representing distance in internal linear units.


Returns the maximum distance from the field at which the force of the field is exerted. The Use Max Distance setting must be turned on for maximum distance to take effect. The maximum distance is scaled by the falloff curve's non-zero range.'''
        pass

    def perVertex(self): 
        '''perVertex(self) -> bool
Returns: true Force is applied to each individual point. 
false Force is applied from the geometric center.


Returns true if the field exerts its force on each individual point (cv, particle, vertex) equally. Returns false if the force is exerted only from the geometric center of the object or set of points.'''
        pass

    def setPerVertex(self, enable): 
        '''setPerVertex(self, enable)
Arguments:
	[in]	enable = bool


Enables the field to exert its force on each individual point (cv, particle, vertex) equally. Otherwise, the force is exerted only from the geometric center of the object or set of points.'''
        pass

    def magnitude(self): 
        '''magnitude(self) -> double
Returns: A value representing the strength of the field.


Returns the strength of the field.'''
        pass

    def setMagnitude(self, mag): 
        '''setMagnitude(self, mag)
Arguments:
	[in]	mag = double


Sets the strength of the field.'''
        pass

    def falloffCurve(self, param): 
        '''falloffCurve(self, param) -> double
Returns: The falloff value given the param.

Arguments:
	[in]	param = double


Returns falloff given the param in [0,1]. This is enabled if the use the maximum distance is enabled.'''
        pass

    def setMaxDistance(self, dist): 
        '''setMaxDistance(self, dist)
Arguments:
	[in]	dist = double


Sets the maximum distance from the field at which the force of the field is exerted. The Use Max Distance setting must be turned on for maximum distance to take effect.'''
        pass

    def getForceAtPoint(self, point, velocity, mass, deltaTime, force): 
        '''getForceAtPoint(self, point, velocity, mass, deltaTime, force)
Arguments:
	[in]	point = MVectorArray
	[in]	velocity = MVectorArray
	[in]	mass = MDoubleArray
	[out]	force = MVectorArray
	[in]	deltaTime = double


Compute the force of a field on an array of points, given their position, velocity, and mass. Note that only the Air and Vortex fields require a time increment to compute forces, all other fields will igonore this argument.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setUseMaxDistance(self, enable): 
        '''setUseMaxDistance(self, enable)
Arguments:
	[in]	enable = bool


Enables the field to use the maximum distance setting to determine the area of influence.'''
        pass

class MFnFluid:
    '''Fluid node function set. This is the function set for fluid objects.A fluid object is a node in the dependency graph that contains a grid which is made up of cells. Each cell has a variety of values assigned to it such as density, velocity, temperature, and color. The grid may be 2D or 3D. See the methods below for full details.Fluid objects may be used for simulation purposes. This function set allows read and write access to the values in the cells of the fluid object. '''
    def __init__(self):
        pass


    def setTemperatureMode(self, method, gradient): 
        '''setTemperatureMode(self, method, gradient)
Arguments:
	[in]	method = MFnFluid.FluidMethod
	[in]	gradient = MFnFluid.FluidGradient


Set the modes by which the temperature values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def setColorMode(self, method): 
        '''setColorMode(self, method)
Arguments:
	[in]	method = MFnFluid.ColorMethod


Set the modes by which the color values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def toGridIndex(self, objectSpacePoint, gridCoords): 
        '''toGridIndex(self, objectSpacePoint, gridCoords) -> bool
Returns: True if the point is inside the fluid, false otherwise

Arguments:
	[in]	objectSpacePoint = MPoint
	[out]	gridCoords = int3


For the given point in object space, get the grid indices of the voxel that it happens to lie in. If the point is outside the fluid, the method returns false, and the indices should not be used.'''
        pass

    def getFuelMode(self, method, gradient): 
        '''getFuelMode(self, method, gradient)
Arguments:
	[out]	method = MFnFluid.FluidMethod
	[out]	gradient = MFnFluid.FluidGradient


Get the modes by which the fuel values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def getForceAtPoint(self, point, velocity, mass, deltaTime, force): 
        '''getForceAtPoint(self, point, velocity, mass, deltaTime, force)
Arguments:
	[in]	point = MVectorArray
	[in]	velocity = MVectorArray
	[in]	mass = MDoubleArray
	[out]	force = MVectorArray
	[in]	deltaTime = double


Compute the force of a field on an array of points, given their position, velocity, and mass. Note that only the Air and Vortex fields require a time increment to compute forces, all other fields will igonore this argument.'''
        pass

    def velocityGridSizes(self, xsize, ysize, zsize): 
        '''velocityGridSizes(self, xsize, ysize, zsize)
Arguments:
	[out]	xsize = int
	[out]	ysize = int
	[out]	zsize = int


Returns the number of elements in the velocity grids. X velocity size = (x resolution+1 * y resolution * z resolution). Y velocity size = (x resolution * y resolution+1 * z resolution). Z velocity size = (x resolution * y resolution * z resolution+1).'''
        pass

    def getCoordinates(self, u, v, w): 
        '''getCoordinates(self, u, v, w)
Arguments:
	[out]	u = float
	[out]	v = float
	[out]	w = float


This method returns pointers to the storage for the uvw coordinate data in the fluid. The size of these arrays can be obtained using the "gridSize" call. The uvw values supply the 3D texture mapping coordinates for each cell.'''
        pass

    def index(self, index, xres, yres, zres, xi, yi, zi): 
        '''index(self, index, xres, yres, zres, xi, yi, zi)
Arguments:
	[in]	index = int
	[in]	xres = int
	[in]	yres = int
	[in]	zres = int
	[out]	xi = int
	[out]	yi = int
	[out]	zi = int


This is a utility routine for finding the coordinates of a cell given the index, and the X, Y and Z resolutions. This is intended for use primarily with the velocity arrays, where the resolutions are different for each array. The X velocity array is one bigger in X, etc.'''
        pass

    def kNegYGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from one to zero along the Y axis.
Value: 5'''
        pass

    def kConstant(self):
        '''This is an enum of FluidGradient.
Description: Value is set to one across the volume.
Value: 0'''
        pass

    def kNegXGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from one to zero along the X axis.
Value: 4'''
        pass

    def kCenterGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramps the value from one at the center to zero at the edges.
Value: 7'''
        pass

    def kYGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from zero to one along the Y axis.
Value: 2'''
        pass

    def kXGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from zero to one along the X axis.
Value: 1'''
        pass

    def kZGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from zero to one along the Z axis.
Value: 3'''
        pass

    def kNegZGradient(self):
        '''This is an enum of FluidGradient.
Description: Ramp the value from one to zero along the Z axis.
Value: 6'''
        pass

    class FluidGradient:
        '''Non-functional class.  Values for this enum:
        kNegYGradient
        kConstant
        kNegXGradient
        kCenterGradient
        kYGradient
        kXGradient
        kZGradient
        kNegZGradient
'''
        def __init__(self):
            pass

    def getVelocity(self, Xvel, Yvel, Zvel): 
        '''getVelocity(self, Xvel, Yvel, Zvel)
Arguments:
	[out]	Xvel = float
	[out]	Yvel = float
	[out]	Zvel = float


This method returns pointers to the storage for the velocity data in the fluid. The size of these arrays can be obtained using the "gridSize" call.'''
        pass

    def density(self): 
        '''density(self) -> float*
Returns: Pointer to the density data of the grid


This method returns a pointer to the storage for the density data in the fluid. The size of this array can be obtained using the "gridSize" call.'''
        pass

    def getColorMode(self, method): 
        '''getColorMode(self, method)
Arguments:
	[out]	method = MFnFluid.ColorMethod


Get the modes by which the color values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def create3D(self, Xres, Yres, Zres, Xdim, Ydim, Zdim, parent): 
        '''create3D(self, Xres, Yres, Zres, Xdim, Ydim, Zdim, parent) -> MObject
Returns: If parent is NULL then the transform for this fluid shape is returned 
If parent is a DAG object then the new fluid shape is returned

Arguments:
	[in]	Xres = int
	[in]	Yres = int
	[in]	Zres = int
	[in]	Xdim = double
	[in]	Ydim = double
	[in]	Zdim = double
	[in]	parent = MObject


Creates a fluid object from the specified data and sets this function set to operate on the new fluid object.'''
        pass

    def getFalloffMode(self, method): 
        '''getFalloffMode(self, method)
Arguments:
	[out]	method = MFnFluid.FalloffMethod


Get the modes by which the falloff values in the grid are determined. If the falloff grid is enabled, its values must be set by the user.'''
        pass

    def setFuelMode(self, method, gradient): 
        '''setFuelMode(self, method, gradient)
Arguments:
	[in]	method = MFnFluid.FluidMethod
	[in]	gradient = MFnFluid.FluidGradient


Set the modes by which the fuel values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation. The fuel value for a cell can be thought of as the amount of fuel contained in the cell that will be consumed during the simulation.'''
        pass

    def fuel(self): 
        '''fuel(self) -> float*
Returns: Pointer to the fuel data of the grid


This method returns a pointer to the storage for the fuel data in the fluid. The size of this array can be obtained using the "gridSize" call.'''
        pass

    def setFalloffMode(self, method): 
        '''setFalloffMode(self, method)
Arguments:
	[in]	method = MFnFluid.FalloffMethod


Set the modes by which the shader falloff values in the grid are determined. If the falloff grid is enabled, its values must be set by the user.'''
        pass

    def setDensityMode(self, method, gradient): 
        '''setDensityMode(self, method, gradient)
Arguments:
	[in]	method = MFnFluid.FluidMethod
	[in]	gradient = MFnFluid.FluidGradient


Set the modes by which the density values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getTemperatureMode(self, method, gradient): 
        '''getTemperatureMode(self, method, gradient)
Arguments:
	[out]	method = MFnFluid.FluidMethod
	[out]	gradient = MFnFluid.FluidGradient


Get the modes by which the temperature values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def updateGrid(self): 
        '''updateGrid(self)

Tells the fluid shape that the contents of the fluid grid has changed. It is necessary to call this routine after modifying internal fluid data via a pointer recieved from any of the access routines in this function set. Failure to call this will result in the fluid not drawing with your changes.'''
        pass

    def gridSize(self): 
        '''gridSize(self) -> int
Returns: The number of elements.


Returns the number of elements in the grid. This is equal to (x resolution * y resolution * z resolution). This routine is provided as a convenience to be used with the methods that give direct access to the fluid data. This gives the upper bound on the arrays. This size applies to all grids except for the 3 velocity grids.'''
        pass

    def kFixed(self):
        '''This is an enum of CoordinateMethod.
Description: Values are equal the object space coordinates.
Value: 0'''
        pass

    def kGrid(self):
        '''This is an enum of CoordinateMethod.
Description: Coordinate values will be moved using the current density solver.
Value: 1'''
        pass

    class CoordinateMethod:
        '''Non-functional class.  Values for this enum:
        kFixed
        kGrid
'''
        def __init__(self):
            pass

    def falloff(self): 
        '''falloff(self) -> float*
Returns: Pointer to the float data of the grid


This method returns a pointer to the storage for the falloff data in the fluid. The size of this array can be obtained using the "gridSize" call.'''
        pass

    def getDimensions(self, Xdim, Ydim, Zdim): 
        '''getDimensions(self, Xdim, Ydim, Zdim)
Arguments:
	[out]	Xdim = double
	[out]	Ydim = double
	[out]	Zdim = double


Gets the dimensions of the fluid. The dimensions give the object space size of the fluid object in each direction.'''
        pass

    def getVelocityMode(self, method, gradient): 
        '''getVelocityMode(self, method, gradient)
Arguments:
	[out]	method = MFnFluid.FluidMethod
	[out]	gradient = MFnFluid.FluidGradient


Get the modes by which the velocity values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def kZero(self):
        '''This is an enum of FluidMethod.
Description: All values in grid are zero.
Value: 0'''
        pass

    def kStaticGrid(self):
        '''This is an enum of FluidMethod.
Description: Values in the grid are static.
Value: 1'''
        pass

    def kGradient(self):
        '''This is an enum of FluidMethod.
Description: Ramps the value based on the gradient setting.
Value: 3'''
        pass

    def kDynamicGrid(self):
        '''This is an enum of FluidMethod.
Description: Values in the grid come from a dynamic solver.
Value: 2'''
        pass

    class FluidMethod:
        '''Non-functional class.  Values for this enum:
        kZero
        kStaticGrid
        kGradient
        kDynamicGrid
'''
        def __init__(self):
            pass

    def setCoordinateMode(self, method): 
        '''setCoordinateMode(self, method)
Arguments:
	[in]	method = MFnFluid.CoordinateMethod


Set the modes by which the UVW coordinate values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def temperature(self): 
        '''temperature(self) -> float*
Returns: Pointer to the temperature data of the grid


This method returns a pointer to the storage for the temperature data in the fluid. The size of this array can be obtained using the "gridSize" call.'''
        pass

    def kStaticColorGrid(self):
        '''This is an enum of ColorMethod.
Description: Values in the grid are static.
Value: 1'''
        pass

    def kDynamicColorGrid(self):
        '''This is an enum of ColorMethod.
Description: Values in the grid come from a dynamic solver.
Value: 2'''
        pass

    def kUseShadingColor(self):
        '''This is an enum of ColorMethod.
Description: Off, use shading color instead.
Value: 0'''
        pass

    class ColorMethod:
        '''Non-functional class.  Values for this enum:
        kStaticColorGrid
        kDynamicColorGrid
        kUseShadingColor
'''
        def __init__(self):
            pass

    def pressure(self): 
        '''pressure(self) -> float*
Returns: Pointer to the pressure data of the grid


This method returns a pointer to the storage for the pressure data in the fluid. The size of this array can be obtained using the "gridSize" call. Note that the pressure data only exists if the velocity method is kStaticGrid or kDynamicGrid'''
        pass

    def emitIntoArrays(self, val, x, y, z, density, heat, fuel, doColor, emitColor): 
        '''emitIntoArrays(self, val, x, y, z, density, heat, fuel, doColor, emitColor)
Arguments:
	[in]	val = float
	[in]	x = int
	[in]	y = int
	[in]	z = int
	[in]	density = float
	[in]	heat = float
	[in]	fuel = float
	[in]	doColor = bool
	[in]	emitColor = MColor


Use this method to add density, heat, fuel, and/or color to a particular voxel of a fluid.'''
        pass

    def kNoFalloffGrid(self):
        '''This is an enum of FalloffMethod.
Description: No falloff grid should be defined.
Value: 0'''
        pass

    def kStaticFalloffGrid(self):
        '''This is an enum of FalloffMethod.
Description: Values in the falloff grid are static.
Value: 1'''
        pass

    class FalloffMethod:
        '''Non-functional class.  Values for this enum:
        kNoFalloffGrid
        kStaticFalloffGrid
'''
        def __init__(self):
            pass

    def create2D(self, Xres, Yres, Xdim, Ydim, parent): 
        '''create2D(self, Xres, Yres, Xdim, Ydim, parent) -> MObject
Returns: If parent is NULL then the transform for this fluid shape is returned 
If parent is a DAG object then the new fluid shape is returned

Arguments:
	[in]	Xres = int
	[in]	Yres = int
	[in]	Xdim = double
	[in]	Ydim = double
	[in]	parent = MObject


Creates a fluid object from the specified data and sets this function set to operate on the new fluid object.'''
        pass

    def voxelCenterPosition(self, xi, yi, zi, objectSpacePoint): 
        '''voxelCenterPosition(self, xi, yi, zi, objectSpacePoint)
Arguments:
	[in]	xi = int
	[in]	yi = int
	[in]	zi = int
	[out]	objectSpacePoint = MPoint


For the given voxel, get the location of the center in object space. If the voxel indices are not valid, the point may not be set to a valid point'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getCoordinateMode(self, method): 
        '''getCoordinateMode(self, method)
Arguments:
	[out]	method = MFnFluid.CoordinateMethod


Get the modes by which the UVW coordinates values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def getDensityMode(self, method, gradient): 
        '''getDensityMode(self, method, gradient)
Arguments:
	[out]	method = MFnFluid.FluidMethod
	[out]	gradient = MFnFluid.FluidGradient


Get the modes by which the density values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def getColors(self, r, g, b): 
        '''getColors(self, r, g, b)
Arguments:
	[out]	r = float
	[out]	g = float
	[out]	b = float


This method returns pointers to the storage for the color data in the fluid. The size of these arrays can be obtained using the "gridSize" call.'''
        pass

    def setVelocityMode(self, method, gradient): 
        '''setVelocityMode(self, method, gradient)
Arguments:
	[in]	method = MFnFluid.FluidMethod
	[in]	gradient = MFnFluid.FluidGradient


Set the modes by which the velocity values in the grid are determined. The values may be set by the user in various ways, or they may be computed as part of a simulation.'''
        pass

    def setSize(self, Xres, Yres, Xdim, Ydim, resample): 
        '''setSize(self, Xres, Yres, Xdim, Ydim, resample)
Arguments:
	[in]	Xres = int
	[in]	Yres = int
	[in]	Xdim = double
	[in]	Ydim = double
	[in]	resample = bool


Sets the size and resolution of the grid. The resolution parameters control the number of cells in the fluid grid and the dimension parameters set the size of the fluid shape in object space.'''
        pass

    def getResolution(self, Xres, Yres): 
        '''getResolution(self, Xres, Yres)
Arguments:
	[out]	Xres = int
	[out]	Yres = int


Gets the resolution of the fluid. The resolution gives the number of cells in the fluid grid in each direction.'''
        pass

class MFnGravityField:
    '''Function set for Gravity Fields. Function set for creation, edit, and query of Gravity Fields.A gravity field simulates the Earth's gravitational force. It pulls objects in a fixed direction entirely independent of their position or mass. '''
    def __init__(self):
        pass


    def direction(self): 
        '''direction(self) -> MVector
Returns: A vector representing direction.


Returns the direction of the gravitational force.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setDirection(self, gravityDirection): 
        '''setDirection(self, gravityDirection)
Arguments:
	[in]	gravityDirection = MVector


Sets the direction vector of the gravitational force.'''
        pass

class MFnInstancer:
    '''Particle Instancer object access class. Class for obtaining information about a particle instancer node. '''
    def __init__(self):
        pass


    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def particleCount(self): 
        '''particleCount(self) -> int


Returns the number of particles feeding the active instancer'''
        pass

    def instancesForParticle(self, p, paths, instancerMatrix): 
        '''instancesForParticle(self, p, paths, instancerMatrix) -> int
Returns: The number of visible paths instanced for the given particle. It is possible for no paths to be instanced for a particular particle.

Arguments:
	[in]	p = int
	[in]	paths = MDagPathArray
	[in]	instancerMatrix = MMatrix


Returns (via reference) the DAG paths and instancer matrix for all instances generated by a specified particle'''
        pass

class MFnNewtonField:
    '''Function set for Newton Fields. Function set for creation, edit, and query of Newton Fields.A newton field pulls an object toward another with a force that is dependent on the mass of the object exerting the field. It follows Newton's Law of Universal Gravitation. '''
    def __init__(self):
        pass


    def setMinDistance(self, distance): 
        '''setMinDistance(self, distance)
Arguments:
	[in]	distance = double


Sets the minimum distance from the newton field at which the force of the field is exerted.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def minDistance(self): 
        '''minDistance(self) -> double
Returns: A value representing distance in internal linear units.


Returns the minimum distance from the newton field at which the force of the field is exerted.'''
        pass

class MFnNObjectData:
    '''function set for nCloth object data Class for transferring N object data between connections '''
    def __init__(self):
        pass


    def getCollide(self, collide): 
        '''getCollide(self, collide)
Arguments:
	[out]	collide = bool


Get wether the nObject is allowed to participate in collisions'''
        pass

    def setCached(self, cached): 
        '''setCached(self, cached)
Arguments:
	[in]	cached = bool


Set wether the nObject is cached.'''
        pass

    def create(self): 
        '''create(self) -> MObject


Creates an underlying Maya N data object and return it as an  MObject'''
        pass

    def setObjectPtr(self, ptr): 
        '''setObjectPtr(self, ptr)
Arguments:
	[in]	ptr = MnCloth


Set the nCloth pointer'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getObjectPtr(self, ptr): 
        '''getObjectPtr(self, ptr)
Arguments:
	[out]	ptr = MnCloth


Get the nObject pointer'''
        pass

    def getCached(self, cached): 
        '''getCached(self, cached)
Arguments:
	[out]	cached = bool


Get wether the nObject is cached.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnParticleSystem:
    '''Class for obtaining information about a particle system. Particle object access class.Use this chart to determine which methods to call based on the render type of the particle object:'''
    def __init__(self):
        pass


    def radius1(self, radii): 
        '''radius1(self, radii)
Arguments:
	[in]	radii = MDoubleArray

'''
        pass

    def radius0(self, radii): 
        '''radius0(self, radii)
Arguments:
	[in]	radii = MDoubleArray

'''
        pass

    def hasEmission(self): 
        '''hasEmission(self) -> bool

'''
        pass

    def disableCloudAxis(self): 
        '''disableCloudAxis(self) -> bool

'''
        pass

    def renderType(self): 
        '''renderType(self) -> MFnParticleSystem.RenderType

'''
        pass

    def radius(self, radii): 
        '''radius(self, radii)
Arguments:
	[in]	radii = MDoubleArray

'''
        pass

    def threshold(self): 
        '''threshold(self) -> double

'''
        pass

    def acceleration(self, array): 
        '''acceleration(self, array)
Arguments:
	[out]	array = MVectorArray


To return acceleration array for all particles.'''
        pass

    def position(self, positions): 
        '''position(self, positions)
Arguments:
	[in]	positions = MVectorArray

'''
        pass

    def hasLifespan(self): 
        '''hasLifespan(self) -> bool

'''
        pass

    def isPerParticleDoubleAttribute(self, attrName): 
        '''isPerParticleDoubleAttribute(self, attrName) -> bool

Arguments:
	[in]	attrName = MString


To check if the input attribute is a per particle double attribute.'''
        pass

    def create(self, parentMObj): 
        '''create(self, parentMObj) -> MObject
Returns: The newly created particleShape

Arguments:
	[in]	parentMObj = MObject


To create a new particleShape. If the parent is not specified, a new transform will be created as the parent.'''
        pass

    def position1(self, positions): 
        '''position1(self, positions)
Arguments:
	[in]	positions = MVectorArray

'''
        pass

    def rgb(self, colors): 
        '''rgb(self, colors)
Arguments:
	[in]	colors = MVectorArray

'''
        pass

    def castsShadows(self): 
        '''castsShadows(self) -> bool

'''
        pass

    def kMultiPoint(self):
        '''This is an enum of RenderType.
Description: 
Value: 3'''
        pass

    def kMultiStreak(self):
        '''This is an enum of RenderType.
Description: 
Value: 4'''
        pass

    def kPoints(self):
        '''This is an enum of RenderType.
Description: 
Value: 6'''
        pass

    def kNumeric(self):
        '''This is an enum of RenderType.
Description: 
Value: 5'''
        pass

    def kStreak(self):
        '''This is an enum of RenderType.
Description: 
Value: 9'''
        pass

    def kSpheres(self):
        '''This is an enum of RenderType.
Description: 
Value: 7'''
        pass

    def kCloud(self):
        '''This is an enum of RenderType.
Description: 
Value: 0'''
        pass

    def kBlobby(self):
        '''This is an enum of RenderType.
Description: 
Value: 2'''
        pass

    def kSprites(self):
        '''This is an enum of RenderType.
Description: 
Value: 8'''
        pass

    def kTube(self):
        '''This is an enum of RenderType.
Description: 
Value: 1'''
        pass

    class RenderType:
        '''Non-functional class.  Values for this enum:
        kMultiPoint
        kMultiStreak
        kPoints
        kNumeric
        kStreak
        kSpheres
        kCloud
        kBlobby
        kSprites
        kTube
'''
        def __init__(self):
            pass

    def hasOpacity(self): 
        '''hasOpacity(self) -> bool

'''
        pass

    def surfaceShading(self): 
        '''surfaceShading(self) -> double

'''
        pass

    def betterIllum(self): 
        '''betterIllum(self) -> bool

'''
        pass

    def primaryVisibility(self): 
        '''primaryVisibility(self) -> bool

'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def particleIds(self, ids): 
        '''particleIds(self, ids)
Arguments:
	[out]	ids = MIntArray


Return an array of particle identifiers at the start of the time step. The array of particle id's is correlated with the other per-particle arrays returned by this class, so ids[i] will be the id for the particle with position position[i], velocity[i], etc., as long as all these arrays were retrieved for the same time step.'''
        pass

    def opacity(self, opacities): 
        '''opacity(self, opacities)
Arguments:
	[in]	opacities = MDoubleArray

'''
        pass

    def deformedParticleShape(self): 
        '''deformedParticleShape(self) -> MObject
Returns: The particle shape connecting to the output of the deformer(s) 


To get the deformed particleShape.'''
        pass

    def isValid(self): 
        '''isValid(self) -> bool

'''
        pass

    def emission(self, emissions): 
        '''emission(self, emissions)
Arguments:
	[in]	emissions = MVectorArray

'''
        pass

    def tailSize(self): 
        '''tailSize(self) -> double

'''
        pass

    def isPerParticleIntAttribute(self, attrName): 
        '''isPerParticleIntAttribute(self, attrName) -> bool

Arguments:
	[in]	attrName = MString


To check if the input attribute is a per particle integer attribute.'''
        pass

    def visibleInRefractions(self): 
        '''visibleInRefractions(self) -> bool

'''
        pass

    def hasRgb(self): 
        '''hasRgb(self) -> bool

'''
        pass

    def particleName(self): 
        '''particleName(self) -> MString

'''
        pass

    def receiveShadows(self): 
        '''receiveShadows(self) -> bool

'''
        pass

    def getPerParticleAttribute(self, attrName, array): 
        '''getPerParticleAttribute(self, attrName, array) -> int
Returns: The size of the returned double array

Arguments:
	[in]	attrName = MString
	[out]	array = MDoubleArray


To get the per particle double attribute of the given name'''
        pass

    def count(self): 
        '''count(self) -> int

'''
        pass

    def isPerParticleVectorAttribute(self, attrName): 
        '''isPerParticleVectorAttribute(self, attrName) -> bool

Arguments:
	[in]	attrName = MString


To check if the input attribute is a per particle vector attribute.'''
        pass

    def visibleInReflections(self): 
        '''visibleInReflections(self) -> bool

'''
        pass

    def saveInitialState(self): 
        '''saveInitialState(self)

To reset the particle's current state as the initial state.'''
        pass

    def age(self, ages): 
        '''age(self, ages)
Arguments:
	[in]	ages = MDoubleArray

'''
        pass

    def isDeformedParticleShape(self): 
        '''isDeformedParticleShape(self) -> bool
Returns: true  particle shape is deformed, false otherwise. 


To return if this particle shape is deformed.'''
        pass

    def lifespan(self, lifespans): 
        '''lifespan(self, lifespans)
Arguments:
	[in]	lifespans = MDoubleArray

'''
        pass

    def emit(self, pArray, vArray): 
        '''emit(self, pArray, vArray)
Arguments:
	[in]	pArray = MPointArray
	[in]	vArray = MVectorArray


To add an array of new particles at the given positions with their velocity values.'''
        pass

    def originalParticleShape(self): 
        '''originalParticleShape(self) -> MObject
Returns: The particle shape connecting to the input of the deformer(s) 


To get the original particleShape.'''
        pass

    def mass(self, array): 
        '''mass(self, array)
Arguments:
	[out]	array = MDoubleArray


To return mass array for all particles.'''
        pass

    def setPerParticleAttribute(self, attrName, array): 
        '''setPerParticleAttribute(self, attrName, array)
Arguments:
	[in]	attrName = MString
	[in]	array = MDoubleArray


To set the per particle double attribute of the given name with the given values.'''
        pass

    def velocity(self, array): 
        '''velocity(self, array)
Arguments:
	[out]	array = MVectorArray


To return velocity array for all particles.'''
        pass

    def evaluateDynamics(self, to, runupFromStart): 
        '''evaluateDynamics(self, to, runupFromStart)
Arguments:
	[in]	to = MTime
	[in]	runupFromStart = bool

'''
        pass

    def position0(self, positions): 
        '''position0(self, positions)
Arguments:
	[in]	positions = MVectorArray

'''
        pass

class MFnPfxGeometry:
    '''PfxGeometry node function set. This is the function set for paint effects objects.PfxGeometry is the parent class for the stroke and pfxHair node. The output geometry for pfxHair and stroke nodes may be accessed through this class. '''
    def __init__(self):
        pass


    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getLineData(self, doLines, doTwist, doWidth, doFlatness, doParameter, doColor, doIncandescence, doTransparency, worldSpace, mainLines, leafLines, flowerLines): 
        '''getLineData(self, doLines, doTwist, doWidth, doFlatness, doParameter, doColor, doIncandescence, doTransparency, worldSpace, mainLines, leafLines, flowerLines)
Arguments:
	[out]	mainLines = MRenderLineArray
	[out]	leafLines = MRenderLineArray
	[out]	flowerLines = MRenderLineArray
	[in]	doLines = bool
	[in]	doTwist = bool
	[in]	doWidth = bool
	[in]	doFlatness = bool
	[in]	doParameter = bool
	[in]	doColor = bool
	[in]	doIncandescence = bool
	[in]	doTransparency = bool
	[in]	worldSpace = bool


Get line data for the current output pfx tubes. The passed in arrays will be filled with pointers to MrenderLine classes. If there are no leaves or flowers then the passed in leafLine and flowerLine arrays will be left empty. Arrays are generated for only the specified attributes. This routine creates the memory for the arrays that it computes. This memory can only be released using the deleteArray method on the  MRenderLineArray  class. DeleteArray should be called for the mainLine, leafLine, and flowerLine variables when done. These variables wrap the returned data and allow access but the  MRenderLineArray  destructer does not delete this wrapped memory, so one must use  MRenderLineArray::deleteArray() . The  MRenderLine ,  MVectorArray  and MDoubleArrays returned from  MRenderLineArray  will point to deleted memory after calling deleteArray, so be careful to only call deleteArray when finished using the line data(or copy the arrays first).'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getBoundingBox(self, min, max): 
        '''getBoundingBox(self, min, max)
Arguments:
	[out]	min = double
	[out]	max = double


Gets the bounding box of the specified geometry. The passed in double arrays will be filled with minimum and maximum coordinates of the geometry.'''
        pass

class MFnRadialField:
    '''Function set for Radial Fields. Function set for creation, edit, and query of Radial Fields.A radial field pushes objects directly away or pulls them directly toward itself, like a magnet. '''
    def __init__(self):
        pass


    def radialType(self): 
        '''radialType(self) -> double
Returns: A value representing a type of radial field attenuation. 
A value of 1 uses the magnitude, attenuation, and distance settings from the field to determine the net force of the radial field. 
A value of 0 will use the ratio of the absolute distance and the maximum distance setting. 
A value between 0 and 1 will create a linear blend between the two types.


Returns a type that controls the way the radial field is attenuated.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setType(self, value): 
        '''setType(self, value)
Arguments:
	[in]	value = double


Sets a radial field type that controls the way the field is attenuated.'''
        pass

class MFnTurbulenceField:
    '''Function set for Turbulence Fields. Function set for creation, edit, and query of Turbulence Fields.A turbulence field causes irregularities in the motion of affected objects. These irregularities are also called noise or jitter. '''
    def __init__(self):
        pass


    def phase(self): 
        '''phase(self) -> double
Returns: A value representing a noise generation parameter.


Returns the phase shift parameter that influences the direction of the turbulence field disruption. Currently this returns the phaseZ attribute, which was called simply phase in versions of Maya prior to 3.0.'''
        pass

    def frequency(self): 
        '''frequency(self) -> double
Returns: A value representing a noise generation parameter.


Returns the frequency parameter that generates irregularities in the fields motion.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setPhase(self, value): 
        '''setPhase(self, value)
Arguments:
	[in]	value = double


Sets the phase shift parameter of the Perlin noise function used by the turbulence field. Both positive and negative values are legal and influence the direction of the disruption. Sets the phaseZ parameter, which was called simply phase in versions of Maya prior to 3.0.'''
        pass

    def setFrequency(self, value): 
        '''setFrequency(self, value)
Arguments:
	[in]	value = double


Sets the frequency parameter of the Perlin noise function used by the turbulence field. Values are positive, with larger values causing more frequent irregularities in the motion.'''
        pass

class MFnUniformField:
    '''Function set for Uniform Fields. Function set for creation, edit, and query of Uniform Fields.A uniform field pushes objects uniformly in a single direction. '''
    def __init__(self):
        pass


    def direction(self): 
        '''direction(self) -> MVector
Returns: A vector representing direction.


Returns the direction the uniform field pushes objects.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setDirection(self, uniformDirection): 
        '''setDirection(self, uniformDirection)
Arguments:
	[in]	uniformDirection = MVector


Sets the direction the uniform field pushes objects.'''
        pass

class MFnVolumeAxisField:
    '''Function set for VolumeAxis Fields. Function set for creation, edit, and query of VolumeAxis Fields.A volume axis field provides in field form some of the speed controls of volume emitters. '''
    def __init__(self):
        pass


    def speedAlongAxis(self): 
        '''speedAlongAxis(self) -> double
Returns: A double value representing the speed along axis.


Returns the alongAxis attribute of the field.'''
        pass

    def setTurbulenceSpeed(self, value): 
        '''setTurbulenceSpeed(self, value)
Arguments:
	[in]	value = double


Sets the turbulence speed attribute for the field force.'''
        pass

    def turbulenceFrequency(self): 
        '''turbulenceFrequency(self) -> MVector
Returns: A vector representing frequency or scale of the turbulence.


Returns the turbulenceFrequency attribute for the field force.'''
        pass

    def setSpeedAwayFromAxis(self, speed): 
        '''setSpeedAwayFromAxis(self, speed)
Arguments:
	[in]	speed = double


Sets the speed away from axis attribute for the field force.'''
        pass

    def turbulenceOffset(self): 
        '''turbulenceOffset(self) -> MVector
Returns: A vector representing an offset or translation of the turbulence.


Returns the turbulenceOffset attribute for the field force.'''
        pass

    def setDirection(self, direction): 
        '''setDirection(self, direction)
Arguments:
	[in]	direction = MVector


Sets the direction attribute for the field force.'''
        pass

    def speedAwayFromCenter(self): 
        '''speedAwayFromCenter(self) -> double
Returns: A double value representing the speed away from center.


Returns the awayFromCenter attribute of the field.'''
        pass

    def setTurbulenceFrequency(self, value): 
        '''setTurbulenceFrequency(self, value)
Arguments:
	[in]	value = MVector


Sets the turbulenceFrequency attribute for the field force.'''
        pass

    def detailTurbulence(self, value): 
        '''detailTurbulence(self, value)
Arguments:
	[in]	value = double


Sets the detailTurbulence attribute for the field force.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def invertAttenuation(self): 
        '''invertAttenuation(self) -> bool
Returns: true Field is strongest close to volume outer boundary. 
false Field is strongest close to volume center.


Returns the value of the invertAttenuation attribute for the field force.'''
        pass

    def setTurbulence(self, value): 
        '''setTurbulence(self, value)
Arguments:
	[in]	value = double


Sets the turbulence attribute for the field force.'''
        pass

    def setTurbulenceOffset(self, value): 
        '''setTurbulenceOffset(self, value)
Arguments:
	[in]	value = MVector


Sets the turbulenceOffset attribute for the field force.'''
        pass

    def direction(self): 
        '''direction(self) -> MVector
Returns: A vector representing direction.


Returns the direction attribute for the field force.'''
        pass

    def setSpeedAwayFromCenter(self, speed): 
        '''setSpeedAwayFromCenter(self, speed)
Arguments:
	[in]	speed = double


Sets the speed away from center attribute for the field force.'''
        pass

    def directionalSpeed(self): 
        '''directionalSpeed(self) -> double
Returns: A double value representing the directional speed.


Returns the directionalSpeed attribute of the field.'''
        pass

    def setInvertAttenuation(self, enable): 
        '''setInvertAttenuation(self, enable)
Arguments:
	[in]	enable = bool


Enables the field will be stronger the closer to the edge of the volume a point is.'''
        pass

    def turbulence(self): 
        '''turbulence(self) -> double
Returns: A double value representing the turbulence intensity.


Returns the turbulence intensity of the field.'''
        pass

    def setSpeedAroundAxis(self, speed): 
        '''setSpeedAroundAxis(self, speed)
Arguments:
	[in]	speed = double


Sets the speed around axis attribute for the field force.'''
        pass

    def speedAroundAxis(self): 
        '''speedAroundAxis(self) -> double
Returns: A double value representing the speed around axis.


Returns the aroundAxis attribute of the field.'''
        pass

    def setSpeedAlongAxis(self, speed): 
        '''setSpeedAlongAxis(self, speed)
Arguments:
	[in]	speed = double


Sets the speed along axis attribute for the field force.'''
        pass

    def turbulenceSpeed(self): 
        '''turbulenceSpeed(self) -> double
Returns: A double value representing the turbulence speed.


Returns the rate of change of the turbulence over time.'''
        pass

    def setDirectionalSpeed(self, speed): 
        '''setDirectionalSpeed(self, speed)
Arguments:
	[in]	speed = double


Sets the directional speed attribute for the field force.'''
        pass

    def speedAwayFromAxis(self): 
        '''speedAwayFromAxis(self) -> double
Returns: A double value representing the speed away from axis.


Returns the awayFromAxis attribute of the field.'''
        pass

class MFnVortexField:
    '''Function set for Vortex Fields. Function set for creation, edit, and query of Vortex Fields.A vortex field pulls objects in a circular direction, like a whirlpool or tornado. '''
    def __init__(self):
        pass


    def setAxis(self, axisVector): 
        '''setAxis(self, axisVector)
Arguments:
	[in]	axisVector = MVector


Sets the axis around which the vortex field exerts it's force.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def axis(self): 
        '''axis(self) -> MVector
Returns: A vector representing an axis.


Returns the axis around which the vortex field exerts it's force.'''
        pass

class MHairSystem:
    '''Interface with Maya's Dynamic Hair System. MHairSystem provides an interface with Maya's Dynamic Hair System.At present, this interface only supports the ability to override the geometry collision component of hair. There is currently no support for overriding the other hair collision components (i.e. implicit object collision and hair self collision).The rationale for providing a hair collision API is to allow the user to override Maya's internal algorithm which is a high-performance simulation. There is an example plug-in provided in the Developer's Toolkit called hairCollisionSolver.cpp. '''
    def __init__(self):
        pass


    def unregisterCollisionSolverPreFrame(self): 
        '''unregisterCollisionSolverPreFrame(self)

De-register any user-defined pre-frame callback that might have been registered via  MHairSystem::registerCollisionSolverPreFrame . 
  Reprocessed example  
 Examples: 
 
   
 hairCollisionSolver.cpp . 
 
'''
        pass

    def setRegisteringCallableScript(self): 
        '''setRegisteringCallableScript(self)
'''
        pass

    def getCollisionObject(self, hairSystem, objects, logicalIndices): 
        '''getCollisionObject(self, hairSystem, objects, logicalIndices)
Arguments:
	[in]	hairSystem = MObject
	[out]	objects = MObjectArray
	[out]	logicalIndices = MIntArray


Returns all collision objects for the hair system.'''
        pass

    def registerCollisionSolverPreFrame(self, fnPtr): 
        '''registerCollisionSolverPreFrame(self, fnPtr)
Arguments:
	[in]	fnPtr = MHairSystemCollisionSolverPreFrameFnPtr


Register the user-supplied pre-frame method `fnPtr' with Maya. This method will be invoked at the start of each frame.'''
        pass

    def registerCollisionSolverCollide(self, fnPtr): 
        '''registerCollisionSolverCollide(self, fnPtr)
Arguments:
	[in]	fnPtr = MHairSystemCollisionSolverCollideFnPtr


Register the user-supplied collision solver `fnPtr' with Maya. This method will be invoked per-hair times the number of iterations specified by the hairSystem node and the method can be used to perfrom several functions:'''
        pass

    def getFollicle(self, hairSystem, follicles, logicalIndices): 
        '''getFollicle(self, hairSystem, follicles, logicalIndices)
Arguments:
	[in]	hairSystem = MObject
	[out]	follicles = MObjectArray
	[out]	logicalIndices = MIntArray


Returns all follicles for the hair system.'''
        pass

    def unregisterCollisionSolverCollide(self): 
        '''unregisterCollisionSolverCollide(self)

De-register any user-defined collision solver that might have been registered via  registerCollisionSolverCollide() . 
  Reprocessed example  
 Examples: 
 
   
 hairCollisionSolver.cpp . 
 
'''
        pass

    def registeringCallableScript(self): 
        '''registeringCallableScript(self) -> bool

'''
        pass

class MRenderLine:
    '''Class for accessing paint effects output curve data. A MRenderLine provides access to paint effects curve rendering info. This class contains arrays for per vertex attributes along an individual curve: line: the vertices in worldspace twist: a twist vector at each vertice width: the tube widths flatness: the tube flatness along the twist vector direction parameter: the u parameterization value for each vertice color: color rgb value for each vertice incandescence: incandescence rgb value for each vertice transpareancy: transparency rgb value for each vertice '''
    def __init__(self):
        pass


    def getTransparency(self): 
        '''getTransparency(self) -> MVectorArray


Return the array of transparency along the curve.'''
        pass

    def getColor(self): 
        '''getColor(self) -> MVectorArray


Return the array of colors along the curve.'''
        pass

    def getParameter(self): 
        '''getParameter(self) -> MDoubleArray


Return the array of parameter along the curve.'''
        pass

    def getWidth(self): 
        '''getWidth(self) -> MDoubleArray


Return the array of tube widths along the curve.'''
        pass

    def getTwist(self): 
        '''getTwist(self) -> MVectorArray


Return the array of twist vectors along the curve.'''
        pass

    def getIncandescence(self): 
        '''getIncandescence(self) -> MVectorArray


Return the array of incandescence along the curve.'''
        pass

    def getFlatness(self): 
        '''getFlatness(self) -> MDoubleArray


Return the array of flatness along the curve.'''
        pass

    def getLine(self): 
        '''getLine(self) -> MVectorArray


Return the array of vertices along the curve.'''
        pass

class MRenderLineArray:
    '''Class for accessing paint effects output curve data. A MRenderLineArray provides access to paint effects curve rendering info. This class contains arrays for per vertex attributes along an individual curve: line: the vertices in worldspace twist: a twist vector at each vertex width: the tube widths flatness: the tube flatness along the twist vector direction parameter: the u parameterization value for each vertex color: color rgb value for each vertex incandescence: incandescence rgb value for each vertex transpareancy: transparency rgb value for each vertex '''
    def __init__(self):
        pass


    def length(self): 
        '''length(self) -> int


Return the number of entries in the array.'''
        pass

    def deleteArray(self): 
        '''deleteArray(self)

Free up the memory held in the render line array. This should be called once only and only on one copy of the  MRenderLineArray . (Assignment copies internal pointer data rather than the data its self) 
  Reprocessed example  
 Examples: 
 
   
 pfxInfoCmd.cpp . 
 
'''
        pass

    def renderLine(self, index): 
        '''renderLine(self, index) -> MRenderLine

Arguments:
	[in]	index = int


Return the render line at the defined index.'''
        pass

