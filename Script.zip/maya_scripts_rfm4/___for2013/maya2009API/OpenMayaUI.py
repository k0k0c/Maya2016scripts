
'''
Stub class file for:
OpenMayaUI

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class M3dView:
    '''A 3-D view. M3dView provides methods for working with 3D model views. 3D views are based on OpenGL drawing areas.Maya can operate in two different color modes, RGBA and color index. Color index mode is used to increase performance when shading is not required. Drawing in color index mode is more complicated, but this class provides methods to simplify color selection.Maya has four color tables that can be used in RGBA, and that must be used in color index mode. These four color tables represent four sets of bit planes that are independent of each other. So, for example, it is possible to clear all active objects from the display and redraw them without redrawing the dormant and templated objects. The active and dormant color tables contain the same colors, but use different bitplanes.The extra performance of color index mode comes at the cost of a limited number of colors. If this restriction causes difficulty, then it is possible for the user to force all displays into RGBA mode where any color may be used.When an object is affected by another in the scene, it is drawn in a magenta colour by default. This is denoted in the DisplayStatus enum by kActiveAffected. These objects are drawn in the active planes even though they are dormant for performance reasons. '''
    def __init__(self):
        pass


    def kLeft(self):
        '''This is an enum of TextPosition.
Description: Draw text to the left of the point.
Value: 0'''
        pass

    def kRight(self):
        '''This is an enum of TextPosition.
Description: Draw text to the right of the point.
Value: 2'''
        pass

    def kCenter(self):
        '''This is an enum of TextPosition.
Description: Draw text centered around the point.
Value: 1'''
        pass

    class TextPosition:
        '''Non-functional class.  Values for this enum:
        kLeft
        kRight
        kCenter
'''
        def __init__(self):
            pass

    def kDisplayCVs(self):
        '''This is an enum of DisplayObjects.
Description: Show NURBS CVs.
Value: 17'''
        pass

    def kDisplayDynamics(self):
        '''This is an enum of DisplayObjects.
Description: Show dynamics.
Value: 10'''
        pass

    def kDisplayMeshes(self):
        '''This is an enum of DisplayObjects.
Description: Show meshes.
Value: 3'''
        pass

    def kDisplayGrid(self):
        '''This is an enum of DisplayObjects.
Description: Show the grid.
Value: 16'''
        pass

    def kDisplayPlanes(self):
        '''This is an enum of DisplayObjects.
Description: Show planes.
Value: 4'''
        pass

    def kDisplayDeformers(self):
        '''This is an enum of DisplayObjects.
Description: Show deformers.
Value: 9'''
        pass

    def kDisplayJoints(self):
        '''This is an enum of DisplayObjects.
Description: Show joints.
Value: 7'''
        pass

    def kDisplaySubdivSurfaces(self):
        '''This is an enum of DisplayObjects.
Description: Show subdivision surfaces.
Value: 20'''
        pass

    def kDisplayPivots(self):
        '''This is an enum of DisplayObjects.
Description: Show pivots.
Value: 14'''
        pass

    def kDisplayTextures(self):
        '''This is an enum of DisplayObjects.
Description: Show textures.
Value: 15'''
        pass

    def kDisplayHulls(self):
        '''This is an enum of DisplayObjects.
Description: Show NURBS hulls.
Value: 18'''
        pass

    def kDisplayIkHandles(self):
        '''This is an enum of DisplayObjects.
Description: Show IK handles.
Value: 8'''
        pass

    def kDisplayLights(self):
        '''This is an enum of DisplayObjects.
Description: Show lights.
Value: 5'''
        pass

    def kDisplayDimensions(self):
        '''This is an enum of DisplayObjects.
Description: Show dimensions.
Value: 12'''
        pass

    def kDisplayNurbsSurfaces(self):
        '''This is an enum of DisplayObjects.
Description: Show nurbs surfaces.
Value: 2'''
        pass

    def kDisplayCameras(self):
        '''This is an enum of DisplayObjects.
Description: Show camera.
Value: 6'''
        pass

    def kDisplaySelectHandles(self):
        '''This is an enum of DisplayObjects.
Description: Show selection handles.
Value: 13'''
        pass

    def kDisplayLocators(self):
        '''This is an enum of DisplayObjects.
Description: Show locators.
Value: 11'''
        pass

    def kDisplayNurbsCurves(self):
        '''This is an enum of DisplayObjects.
Description: Show nurbs curves.
Value: 1'''
        pass

    def kDisplayStrokes(self):
        '''This is an enum of DisplayObjects.
Description: Show strokes.
Value: 19'''
        pass

    def kDisplayEverything(self):
        '''This is an enum of DisplayObjects.
Description: Show everything.
Value: 0'''
        pass

    class DisplayObjects:
        '''Non-functional class.  Values for this enum:
        kDisplayCVs
        kDisplayDynamics
        kDisplayMeshes
        kDisplayGrid
        kDisplayPlanes
        kDisplayDeformers
        kDisplayJoints
        kDisplaySubdivSurfaces
        kDisplayPivots
        kDisplayTextures
        kDisplayHulls
        kDisplayIkHandles
        kDisplayLights
        kDisplayDimensions
        kDisplayNurbsSurfaces
        kDisplayCameras
        kDisplaySelectHandles
        kDisplayLocators
        kDisplayNurbsCurves
        kDisplayStrokes
        kDisplayEverything
'''
        def __init__(self):
            pass

    def readDepthMap(self, x, y, width, height, bufferPtr, depthMapPrecision): 
        '''readDepthMap(self, x, y, width, height, bufferPtr, depthMapPrecision)
Arguments:
	[in]	x = short
	[in]	y = short
	[in]	width = int
	[in]	height = int
	[in]	bufferPtr = char
	[in]	depthMapPrecision = M3dView.DepthBufferFormat


Read the depth values from the frame buffer for a given view. The buffer is read into a block of data as defined as an argument. The data block size must be large enough to accomodate ( view width * view height * depth map precision ) bytes of data.'''
        pass

    def isLightVisible(self, lightNumber, visible): 
        '''isLightVisible(self, lightNumber, visible)
Arguments:
	[in]	lightNumber = int
	[out]	visible = bool


Find out if a light is visible in the view'''
        pass

    def isColorIndexMode(self): 
        '''isColorIndexMode(self) -> bool
Returns: Boolean indicating if color index mode is in use


Returns true if this view is currently in the OpenGL color index mode. A false return means that it is in RGBA mode.'''
        pass

    def beginOverlayDrawing(self): 
        '''beginOverlayDrawing(self)

Setup the OpenGL context for drawing on the overlay plane.'''
        pass

    def getLightCount(self, visible, count): 
        '''getLightCount(self, visible, count)
Arguments:
	[out]	count = int
	[in]	visible = bool


Get the number of lights for the view.'''
        pass

    def viewToObjectSpace(self, x_pos, y_pos, localMatrixInverse, oPt, oVector): 
        '''viewToObjectSpace(self, x_pos, y_pos, localMatrixInverse, oPt, oVector)
Arguments:
	[in]	x_pos = short
	[in]	y_pos = short
	[in]	localMatrixInverse = MMatrix
	[out]	oPt = MPoint
	[out]	oVector = MVector


Takes a point in port coordinates and returns a corresponding ray in object coordinates.'''
        pass

    def popName(self): 
        '''popName(self)
'''
        pass

    def numUserDefinedColors(self): 
        '''numUserDefinedColors(self) -> int
Returns: The number of user defined colors


Returns the number of user defined colors in the internal application color table. These colors may be changed by the user and assigned to specific objects. See the methods of  MFnDagNode  for information on assigning user defined colors to individual objects.'''
        pass

    def userDefinedColorIndex(self, index): 
        '''userDefinedColorIndex(self, index) -> int
Returns: Index of user-defined color into the active and dormant tables

Arguments:
	[in]	index = int


Returns the index for the given user-defined color. Valid values for the index argument range between zero and the number of user-defined colors minus one.'''
        pass

    def pushName(self, name): 
        '''pushName(self, name)
Arguments:
	[in]	name = M3dView.GLuint


Push a new name on the name stack. Valid only when  beginSelect()  has been called.'''
        pass

    def kLightSelected(self):
        '''This is an enum of LightingMode.
Description: Selected lights ON mode.
Value: 1'''
        pass

    def kLightActive(self):
        '''This is an enum of LightingMode.
Description: Active lights ON mode.
Value: 2'''
        pass

    def kLightAll(self):
        '''This is an enum of LightingMode.
Description: All lights ON mode.
Value: 0'''
        pass

    def kLightDefault(self):
        '''This is an enum of LightingMode.
Description: Default light ON mode.
Value: 3'''
        pass

    class LightingMode:
        '''Non-functional class.  Values for this enum:
        kLightSelected
        kLightActive
        kLightAll
        kLightDefault
'''
        def __init__(self):
            pass

    def templateColor(self): 
        '''templateColor(self) -> MColor
Returns: The template color


Returns the RGB values of the template color.'''
        pass

    def setShowViewSelectedChildren(self, show): 
        '''setShowViewSelectedChildren(self, show)
Arguments:
	[in]	show = bool


This method changes the way that view selected works. By default, view selected with show all of the children of the objects in the view selected set. If false is passed to this method, then only the obejcts in the view selected set and their shapes will be drawn.'''
        pass

    def pushViewport(self, x, y, width, height): 
        '''pushViewport(self, x, y, width, height)
Arguments:
	[in]	x = int
	[in]	y = int
	[in]	width = int
	[in]	height = int


Set the current viewport dimensions. Will keep track of the last viewport dimensions on a stack. When finished with this viewport, the current dimensions should be removed from the top of stack using  M3dView::popViewport() .'''
        pass

    def kDormantColors(self):
        '''This is an enum of ColorTable.
Description: Colors for dormant objects.
Value: 2'''
        pass

    def kTemplateColor(self):
        '''This is an enum of ColorTable.
Description: Colors for templated objects.
Value: 5'''
        pass

    def kBackgroundColor(self):
        '''This is an enum of ColorTable.
Description: Colors for background color.
Value: 6'''
        pass

    def kActiveColors(self):
        '''This is an enum of ColorTable.
Description: Colors for active objects.
Value: 0'''
        pass

    class ColorTable:
        '''Non-functional class.  Values for this enum:
        kDormantColors
        kTemplateColor
        kBackgroundColor
        kActiveColors
'''
        def __init__(self):
            pass

    def worldToView(self, worldPt, x_pos, y_pos): 
        '''worldToView(self, worldPt, x_pos, y_pos) -> bool
Returns: true point is not clipped 
false point is undefined or outside frustum

Arguments:
	[in]	worldPt = MPoint
	[out]	x_pos = short
	[out]	y_pos = short


converts a point in world space to port space. The return value indicates if the point is not clipped.'''
        pass

    def setCamera(self, camera): 
        '''setCamera(self, camera)
Arguments:
	[in]	camera = MDagPath


Set the camera for this view.'''
        pass

    def displayStyle(self): 
        '''displayStyle(self) -> M3dView.DisplayStyle
Returns: The display style for this view


Return the display style for this 3d view. The display style can be wireframe, flat-shaded, or smooth-shaded.'''
        pass

    def endGL(self): 
        '''endGL(self)

End OpenGL drawing.'''
        pass

    def kHighQualityRenderer(self):
        '''This is an enum of RendererName.
Description: Equivalent to when the renderer name is "hwRender_OpenGL_Renderer" when queried from the "modelEditor" command.
Value: 1'''
        pass

    def kExternalRenderer(self):
        '''This is an enum of RendererName.
Description: An externally defined renderer name has been set.
Value: 2'''
        pass

    def kDefaultQualityRenderer(self):
        '''This is an enum of RendererName.
Description: Equivalent to when the renderer name is "base_OpenGL_Renderer" when queried from the "modelEditor" command.
Value: 0'''
        pass

    class RendererName:
        '''Non-functional class.  Values for this enum:
        kHighQualityRenderer
        kExternalRenderer
        kDefaultQualityRenderer
'''
        def __init__(self):
            pass

    def viewSelectedPrefix(self): 
        '''viewSelectedPrefix(self) -> MString
Returns: The prefix.


Returns the Returns the prefix used when displaying the camera name in the heads up display when view selected in on.'''
        pass

    def getLightingMode(self, mode): 
        '''getLightingMode(self, mode)
Arguments:
	[out]	mode = M3dView.LightingMode


Get the current lighting mode for the view.'''
        pass

    def textureMode(self): 
        '''textureMode(self) -> bool


Tells if this  M3dView  is in texture mode.'''
        pass

    def colorMask(self, r, g, b, a): 
        '''colorMask(self, r, g, b, a)
Arguments:
	[out]	r = bool
	[out]	g = bool
	[out]	b = bool
	[out]	a = bool


Get the current color mask.'''
        pass

    def drawText(self, text, position, textPosition): 
        '''drawText(self, text, position, textPosition)
Arguments:
	[in]	text = MString
	[in]	position = MPoint
	[in]	textPosition = M3dView.TextPosition


Draws the given text at the given spot in the default font. This method is provided as a convienient way to draw OpenGL text.'''
        pass

    def projectionMatrix(self, projMat): 
        '''projectionMatrix(self, projMat)
Arguments:
	[out]	projMat = MMatrix


Returns the projection matrix currently being used by OpenGL in the current view'''
        pass

    def kDepth_Float(self):
        '''This is an enum of DepthBufferFormat.
Description: Floating point.
Value: 1'''
        pass

    def kDepth_8(self):
        '''This is an enum of DepthBufferFormat.
Description: 8 bits.
Value: 0'''
        pass

    class DepthBufferFormat:
        '''Non-functional class.  Values for this enum:
        kDepth_Float
        kDepth_8
'''
        def __init__(self):
            pass

    def wireframeOnlyInShadedMode(self): 
        '''wireframeOnlyInShadedMode(self) -> bool
Returns: true if we are in this mode.


Return whether we are in shaded mode, but that only non shaded drawing should occur (wireframe).'''
        pass

    def applicationShell(self): 
        '''applicationShell(self) -> M3dView.MWindow


Returns the X display for this view.'''
        pass

    def window(self): 
        '''window(self) -> M3dView.M3dWindow
Returns: The X window


Returns the X window for this view.'''
        pass

    def getRendererName(self): 
        '''getRendererName(self) -> M3dView.RendererName
Returns: The name of the current renderer.


Get the name of the current renderer being used for drawing to this view. The current possible return values are:'''
        pass

    def beginSelect(self, buffer, size): 
        '''beginSelect(self, buffer, size)
Arguments:
	[in]	buffer = M3dView.GLuint
	[in]	size = M3dView.GLsizei


Start selecting. The buffer passed is used to record selection hits. A selection hit consists of the following 4 items:'''
        pass

    def backgroundColor(self): 
        '''backgroundColor(self) -> MColor
Returns: The template color


Returns the RGB values of the active template color.'''
        pass

    def getColorIndexAndTable(self, glindex, index, table): 
        '''getColorIndexAndTable(self, glindex, index, table)
Arguments:
	[in]	glindex = int
	[out]	index = int
	[out]	table = M3dView.ColorTable


Returns the color table and index representing the given OpenGL color-index value. This method is useful when converting color indices obtained from glReadPixels(GL_COLOR_INDEX) to Maya color-index values suitable for use with the colorAtIndex and setDrawColor methods.'''
        pass

    def writeColorBuffer(self, image, x, y): 
        '''writeColorBuffer(self, image, x, y)
Arguments:
	[in]	image = MImage
	[in]	x = signed
	[in]	y = signed


Overwrite the RGB values for the frame buffer for a given view. Expected input is a block of RGBA, such that each channel is one byte in size.'''
        pass

    def setUserDefinedColor(self, index, color): 
        '''setUserDefinedColor(self, index, color)
Arguments:
	[in]	index = int
	[in]	color = MColor


Sets the user defined color at the given index. Valid indices range between zero and the number of user defined colors.'''
        pass

    def beginGL(self): 
        '''beginGL(self)

Setup port for native OpenGL drawing calls.'''
        pass

    def colorAtIndex(self, index, table): 
        '''colorAtIndex(self, index, table) -> MColor
Returns: The color

Arguments:
	[in]	index = int
	[in]	table = M3dView.ColorTable


Returns the RGB values of the color at the given index in the application's color table.'''
        pass

    def getM3dViewFromModelEditor(self, name, view): 
        '''getM3dViewFromModelEditor(self, name, view)
Arguments:
	[in]	name = MString
	[out]	view = M3dView


Given the name of a model editor, get the  M3dView  used by that editor. If this fails, then a editor with the given name could not be located.'''
        pass

    def setDrawColor(self, color): 
        '''setDrawColor(self, color)
Arguments:
	[in]	color = MColor


Set the color to draw in. This method should only be used in RGBA mode. It is a convenient replacement for glColor.'''
        pass

    def portWidth(self): 
        '''portWidth(self) -> int
Returns: The width of this viewport


Returns the width of the current viewport.'''
        pass

    def setViewSelectedPrefix(self, prefix): 
        '''setViewSelectedPrefix(self, prefix)
Arguments:
	[in]	prefix = MString


Sets the prefix for the camera name as displayed in the heads up display when view selected is enabled. The prefix is concatenated with the camera name.'''
        pass

    def getLightIndex(self, lightNumber, lightIndex): 
        '''getLightIndex(self, lightNumber, lightIndex)
Arguments:
	[in]	lightNumber = int
	[out]	lightIndex = int


Get the internal light index for a given light number'''
        pass

    def viewToWorld(self, x_pos, y_pos, nearClipPt, farClipPt): 
        '''viewToWorld(self, x_pos, y_pos, nearClipPt, farClipPt)
Arguments:
	[in]	x_pos = short
	[in]	y_pos = short
	[out]	nearClipPt = MPoint
	[out]	farClipPt = MPoint


Takes a point in port coordinates and returns a point on the near and far clipping planes.'''
        pass

    def active3dView(self): 
        '''active3dView(self) -> M3dView


Returns the active view in the form of a class ( M3dView ) that can operate on it.'''
        pass

    def setColorMask(self, r, g, b, a): 
        '''setColorMask(self, r, g, b, a)
Arguments:
	[in]	r = bool
	[in]	g = bool
	[in]	b = bool
	[in]	a = bool


Set the current color mask.'''
        pass

    def isShadeActiveOnly(self): 
        '''isShadeActiveOnly(self) -> bool
Returns: true Only active objects are shaded if this view is in shaded mode 
false All objects are shaded if this view is in shaded mode


Returns  true  if this view's display style is shaded for objects that are active and wireframe otherwise.'''
        pass

    def selectMode(self): 
        '''selectMode(self) -> bool


Tells if this  M3dView  is in selection mode.'''
        pass

    def endSelect(self): 
        '''endSelect(self) -> M3dView.GLint


Finish a selection sequence. Result is stored in the buffer passed in the beginSelect call. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp , and  apiSimpleShapeUI.cpp . 
 
'''
        pass

    def clearOverlayPlane(self): 
        '''clearOverlayPlane(self)

Clear the overlay plane.'''
        pass

    def readBufferTo2dTexture(self, x, y, width, height): 
        '''readBufferTo2dTexture(self, x, y, width, height)
Arguments:
	[in]	x = short
	[in]	y = short
	[in]	width = int
	[in]	height = int


Read the depth values from the frame buffer for a given view into a predefined OpenGL 2d texture. It is assumed that such a texture has been created and bound before making this call.'''
        pass

    def numDormantColors(self): 
        '''numDormantColors(self) -> int
Returns: The number of dormant colors


Returns the number of dormant object colors in the internal application color table.'''
        pass

    def viewport(self, x, y, width, height): 
        '''viewport(self, x, y, width, height)
Arguments:
	[out]	x = int
	[out]	y = int
	[out]	width = int
	[out]	height = int


Get the current viewport dimensions.'''
        pass

    def getM3dViewFromModelPanel(self, name, view): 
        '''getM3dViewFromModelPanel(self, name, view)
Arguments:
	[in]	name = MString
	[out]	view = M3dView


Given the name of a model panel, get the  M3dView  used by that panel. If this fails, then a panel with the given name could not be located.'''
        pass

    def get3dView(self, index, view): 
        '''get3dView(self, index, view)
Arguments:
	[in]	index = int
	[out]	view = M3dView


Returns the 3D view at the given index.'''
        pass

    def endOverlayDrawing(self): 
        '''endOverlayDrawing(self)

Set the OpenGL context to for normal screen drawing.'''
        pass

    def loadName(self, name): 
        '''loadName(self, name)
Arguments:
	[in]	name = M3dView.GLuint


Replace the top of the name stack with the given name. Valid only when  beginSelect()  has been called.'''
        pass

    def portHeight(self): 
        '''portHeight(self) -> int
Returns: The height of this viewport


Returns the height of the current viewport.'''
        pass

    def usingMipmappedTextures(self): 
        '''usingMipmappedTextures(self) -> bool


Returns if the view is using mipmapped texture display.'''
        pass

    def getScreenPosition(self, x, y): 
        '''getScreenPosition(self, x, y)
Arguments:
	[out]	x = int
	[out]	y = int


Returns the current position of this view window in screen coordinates.'''
        pass

    def readColorBuffer(self, image, readRGBA): 
        '''readColorBuffer(self, image, readRGBA)
Arguments:
	[in]	image = MImage
	[in]	readRGBA = bool


Read the RGB values from the frame buffer for a given view. The buffer is read in a pixel format which is BGRA by default, such that each channel is one byte in size.'''
        pass

    def modelViewMatrix(self, modelViewMatrix): 
        '''modelViewMatrix(self, modelViewMatrix)
Arguments:
	[out]	modelViewMatrix = MMatrix


Returns the modelview matrix currently being used by OpenGL in the current view'''
        pass

    def kHilite(self):
        '''This is an enum of DisplayStatus.
Description: Object is hilited (has selectable components).
Value: 4'''
        pass

    def kActiveTemplate(self):
        '''This is an enum of DisplayStatus.
Description: Object is active and templated.
Value: 6'''
        pass

    def kDormant(self):
        '''This is an enum of DisplayStatus.
Description: Object is domant.
Value: 2'''
        pass

    def kInvisible(self):
        '''This is an enum of DisplayStatus.
Description: Object is invisible (not drawn).
Value: 3'''
        pass

    def kActive(self):
        '''This is an enum of DisplayStatus.
Description: Object is active (selected).
Value: 0'''
        pass

    def kActiveComponent(self):
        '''This is an enum of DisplayStatus.
Description: Object has active components.
Value: 7'''
        pass

    def kActiveAffected(self):
        '''This is an enum of DisplayStatus.
Description: Affected by active object(s).
Value: 10'''
        pass

    def kNoStatus(self):
        '''This is an enum of DisplayStatus.
Description: Object does not have a valid display status.
Value: 11'''
        pass

    def kLive(self):
        '''This is an enum of DisplayStatus.
Description: Object is live (construction surface).
Value: 1'''
        pass

    def kTemplate(self):
        '''This is an enum of DisplayStatus.
Description: Object is templated (Not renderable).
Value: 5'''
        pass

    def kLead(self):
        '''This is an enum of DisplayStatus.
Description: Last selected object.
Value: 8'''
        pass

    def kIntermediateObject(self):
        '''This is an enum of DisplayStatus.
Description: Construction object (not drawn).
Value: 9'''
        pass

    class DisplayStatus:
        '''Non-functional class.  Values for this enum:
        kHilite
        kActiveTemplate
        kDormant
        kInvisible
        kActive
        kActiveComponent
        kActiveAffected
        kNoStatus
        kLive
        kTemplate
        kLead
        kIntermediateObject
'''
        def __init__(self):
            pass

    def refresh(self, buffer, offscreen, projMatrix): 
        '''refresh(self, buffer, offscreen, projMatrix)
Arguments:
	[in]	buffer = MPxGlBuffer
	[in]	offscreen = bool
	[in]	projMatrix = MMatrix


Refresh the this view into the GL buffer buffer.'''
        pass

    def kFlatShaded(self):
        '''This is an enum of DisplayStyle.
Description: Flat shaded display.
Value: 1'''
        pass

    def kWireFrame(self):
        '''This is an enum of DisplayStyle.
Description: Wire frame display.
Value: 3'''
        pass

    def kGouraudShaded(self):
        '''This is an enum of DisplayStyle.
Description: Gouraud shaded display.
Value: 2'''
        pass

    def kBoundingBox(self):
        '''This is an enum of DisplayStyle.
Description: Bounding box display.
Value: 0'''
        pass

    def kPoints(self):
        '''This is an enum of DisplayStyle.
Description: Points only display.
Value: 4'''
        pass

    class DisplayStyle:
        '''Non-functional class.  Values for this enum:
        kFlatShaded
        kWireFrame
        kGouraudShaded
        kBoundingBox
        kPoints
'''
        def __init__(self):
            pass

    def getCamera(self, camera): 
        '''getCamera(self, camera)
Arguments:
	[out]	camera = MDagPath


Get the camera for this view.'''
        pass

    def numActiveColors(self): 
        '''numActiveColors(self) -> int
Returns: The number of active colors


Returns the number of active object colors in the internal application color table.'''
        pass

    def initNames(self): 
        '''initNames(self)
'''
        pass

    def popViewport(self): 
        '''popViewport(self)

Pop the current viewport off of the viewport stack.'''
        pass

    def setDisplayStyle(self, style, activeOnly): 
        '''setDisplayStyle(self, style, activeOnly)
Arguments:
	[in]	style = M3dView.DisplayStyle
	[in]	activeOnly = bool


Sets the display style for this view. The display style can be wireframe, flat-shaded, or smooth-shaded.'''
        pass

    def showViewSelectedChildren(self): 
        '''showViewSelectedChildren(self) -> bool
Returns: true if the children of view selected objects are drawn.


Returns turn if view selected shows all of the children of the obejcts that are flagged for view selected.'''
        pass

    def getLightPath(self, lightNumber, lightPath): 
        '''getLightPath(self, lightNumber, lightPath)
Arguments:
	[in]	lightNumber = int
	[out]	lightPath = MDagPath


Get the path to a certain light.'''
        pass

    def rendererString(self): 
        '''rendererString(self) -> MString
Returns: String name


Get the string name of the current renderer being used for drawing to this view.'''
        pass

    def numberOf3dViews(self): 
        '''numberOf3dViews(self) -> int


Returns the number of 3D views currently in existance.'''
        pass

class MCursor:
    '''Manipulate Cursors. The MCursor class implements a cursor class, and is used to pass all cursor arguments to Maya API methods.The cursor image and mask are stored in xbm format to the constructor along with the cursor dimensions and the cursor hotspot. '''
    def __init__(self):
        pass


    defaultCursor = ''
    '''Maya default cursor, the left arrow. '''

    crossHairCursor = ''
    ''''+' cursor. '''

    handCursor = ''
    '''Open hand shaped cursor. '''

    doubleCrossHairCursor = ''
    ''''+' cursor with double lines. '''

    editCursor = ''
    '''Wedge-shaped arrow pointing left. '''

    pencilCursor = ''
    '''Pencil shape. '''

    def __eq__(self, other): 
        '''__eq__(self, other) -> bool
Returns: true if the objects are same. 
false if the objects are different. 

Arguments:
	[in]	other = MCursor


Equality operator. Allows 2 MCursors to be compared to see if they are identical.'''
        pass

    def __neq__(self, other): 
        '''__neq__(self, other) -> bool
Returns: true if the objects are different. 
false if the objects are same. 

Arguments:
	[in]	other = MCursor


Inequality operator. Allows 2 MCursors to be compared to see if they are not the same.'''
        pass

class MDeviceChannel:
    '''Input device channel. Input device channel class. '''
    def __init__(self):
        pass


    def axisIndex(self): 
        '''axisIndex(self) -> int


Returns the device state index corresponding to this device channel.'''
        pass

    def name(self): 
        '''name(self) -> MString


Return the short name of the channel.'''
        pass

    def parent(self): 
        '''parent(self) -> MDeviceChannel


Return the parent of this channel.'''
        pass

    def hasChildren(self): 
        '''hasChildren(self) -> bool


Determine whether this channel has children.'''
        pass

    def childByIndex(self, index): 
        '''childByIndex(self, index) -> MDeviceChannel

Arguments:
	[in]	index = int


Return the specified child of this channel.'''
        pass

    def numChildren(self): 
        '''numChildren(self) -> int


Return the number of children of this channel.'''
        pass

    def longName(self): 
        '''longName(self) -> MString


Return the long name of the channel.'''
        pass

class MDeviceState:
    '''Input device state. MDeviceState is a generic event class for input devices. Input device classes (such as MPxMidiInputDevice) are responsible for converting specific event types to an MDeviceState which Maya understands. '''
    def __init__(self):
        pass


    def maxAxis(self): 
        '''maxAxis(self) -> int


Return the value of the axis with the largest value. This is used to dejitter absolute devices.'''
        pass

    def buttonState(self, buttonName): 
        '''buttonState(self, buttonName) -> bool
Returns: true button pressed 
false button released 

Arguments:
	[in]	buttonName = MString


Returns the state of the named button.'''
        pass

    def devicePosition(self, axisName): 
        '''devicePosition(self, axisName) -> int
Returns: The position of the device for the specified axis 

Arguments:
	[in]	axisName = MString


Returns the position of the device for the specified axis.'''
        pass

    def setButtonState(self, state, buttonName): 
        '''setButtonState(self, state, buttonName)
Arguments:
	[in]	state = bool
	[in]	buttonName = MString


Set the state of the specified button.'''
        pass

    def isNull(self): 
        '''isNull(self) -> bool


Returns  true  if this device state is NULL;'''
        pass

    def setDevicePosition(self, position, axis): 
        '''setDevicePosition(self, position, axis)
Arguments:
	[in]	position = int
	[in]	axis = MString


Sets the position of the device for the specified axis.'''
        pass

class MDrawData:
    '''Draw data used in the draw methods of MPxSurfaceShapeUI. The MDrawData class holds geometry specific information for user defined shapes which maya does not intrinsicly know about.This class is used in the draw methods of MPxSurfaceShapeUI For each draw request you must create and add a draw data object which will contain geometry specific information that you will need in the subsequent call to MPxSurfaceShapeUI::draw.MDrawData contains one void* member which is a pointer to an object that you define. This object is the geometry needed to draw your shape.To create draw data use the function MPxSurfaceShapeUI::getDrawData. This function takes two arguments, the first is a pointer to your geometry object, the second is the draw data being created. To add the data to a request use MDrawRequest::setDrawData.Draw data is also used to carry texture information to your draw method. For materials with texture you must call MMaterial::evaluateTexture from your MPxSurfaceShapeUI::getDrawRequests method. Then in your draw method use MMaterial::applyTexture to set up the viewport to draw using the textured material. '''
    def __init__(self):
        pass


    def geometry(self): 
        '''geometry(self) -> void*


Returns the geometry associated with this draw data object. The geometry is set using the getDrawData method of  MPxSurfaceShapeUI .'''
        pass

class MDrawInfo:
    '''Drawing state used in the draw methods of MPxSurfaceShapeUI. This class is used by the getDrawRequests method of MPxSurfaceShapeUI to specify the current object drawing state for a user defined shape.This getPrototype method is used to construct a draw request object based on the current draw state for the object.See MDrawRequest for more information. '''
    def __init__(self):
        pass


    def objectDisplayStatus(self, displayObj): 
        '''objectDisplayStatus(self, displayObj) -> bool

Arguments:
	[in]	displayObj = M3dView.DisplayObjects


Determines whether the specified objects are allowed to be displayed.'''
        pass

    def completelyInside(self): 
        '''completelyInside(self) -> bool


Returns true if the object being drawn is inside the viewing frustum.'''
        pass

    def MMatrix(self): 
        '''MMatrix(self) -> const


Returns the world space inclusive matrix.'''
        pass

    def displayStatus(self): 
        '''displayStatus(self) -> M3dView.DisplayStatus


Returns the status of the object to draw.'''
        pass

    def inSelect(self): 
        '''inSelect(self) -> bool


Returns true if this is called from within the select method of  MPxSurfaceShapeUI .'''
        pass

    def MDagPath(self): 
        '''MDagPath(self) -> const


Returns the path to the object to be drawn.'''
        pass

    def inUserInteraction(self): 
        '''inUserInteraction(self) -> bool


Returns true during any interactive refresh, as when user is interacting with the scene in any way including camera changes, object or component TRS changes, etc. Use userChangingViewContext for determining whether user is changing the view using view context tools such as tumble, dolly or track.'''
        pass

    def canDrawComponent(self, isDisplayOn, mask): 
        '''canDrawComponent(self, isDisplayOn, mask) -> bool
Returns: true the specified component can be drawn 
false the specified component cannot be drawn 

Arguments:
	[in]	isDisplayOn = bool
	[in]	mask = MSelectionMask


Convenience method to test if components specified by the given mask can be drawn.'''
        pass

    def getPrototype(self, drawHandler): 
        '''getPrototype(self, drawHandler) -> MDrawRequest
Returns: A draw request 

Arguments:
	[in]	drawHandler = MPxSurfaceShapeUI


This method creates a draw request based on the current draw state.'''
        pass

    def userChangingViewContext(self): 
        '''userChangingViewContext(self) -> bool


Returns true during any interactive refresh, as when user is changing the view using view context tools such as tumble, dolly or track. Useful for changing drawing mode to something simpler to speed up interaction re-draw. Use inUserInteraction for determining whether user is interacting with the scene in any way.'''
        pass

    def displayStyle(self): 
        '''displayStyle(self) -> M3dView.DisplayStyle


The display appearance.'''
        pass

    def view(self): 
        '''view(self) -> M3dView


Returns the view that the drawing will take place.'''
        pass

class MDrawRequest:
    '''A draw reqeust used in the draw methods of MPxSurfaceShapeUI. This class encapsulates all the information needed to fulfill a request to draw an object or part of an object. This class is used by the draw methods of MPxSurfaceShapeUI derived objects.The draw request should be created in the overridden MPxSurfaceShapeUI::getDrawRequests method. Once created the appropriate "set" methods of this class should be used to define what is being requested. Then the request should be placed on the draw reqeust queue using MDrawRequestQueue::add.When your request gets processed by maya, your overriden MPxSurfaceShape::draw method will get called with your request. Use the query methods of this class to determine what to draw.You create a draw request using the method MDrawInfo::getPrototype. A draw request automatically picks up certain information (listed below) upon its creation. So you don't have to set any of this information unless you want to change it.Information automatically set by MDrawInfo::getPrototype :The draw token is an integer value which you can use to specify what is to be drawn. This is object specific and so you should define an enum with the information you require to decide what is being drawn in your MPxSurfaceShapeUI::draw method.Here is an example of draw token values for a polygonal mesh object as defined in an MPxSurfaceShapeUI derived class.'''
    def __init__(self):
        pass


    def displayCulling(self): 
        '''displayCulling(self) -> bool

'''
        pass

    def color(self, table): 
        '''color(self, table) -> int

Arguments:
	[in]	table = M3dView.ColorTable


Returns the wireframe display color.'''
        pass

    def setDisplayCullOpposite(self, value): 
        '''setDisplayCullOpposite(self, value)
Arguments:
	[in]	value = bool


Sets the state of the culling flag for the object.'''
        pass

    def setDrawLast(self, value): 
        '''setDrawLast(self, value)
Arguments:
	[in]	value = bool


Specifies the order in which this object will be drawn.'''
        pass

    def displayStyle(self): 
        '''displayStyle(self) -> M3dView.DisplayStyle

'''
        pass

    def setMaterial(self, material): 
        '''setMaterial(self, material)
Arguments:
	[in]	material = MMaterial


Returns the shaded material.'''
        pass

    def setComponent(self, comp): 
        '''setComponent(self, comp)
Arguments:
	[in]	comp = MObject


Set a component to be drawn.'''
        pass

    def MDagPath(self): 
        '''MDagPath(self) -> const


Returns the path to the object to be drawn. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp ,  blindDataShader.cpp ,  hwAnisotropicShader_NV20.cpp ,  hwDecalBumpShader_NV20.cpp ,  hwReflectBumpShader_NV20.cpp ,  hwRefractReflectShader_NV20.cpp ,  hwToonShader_NV20.cpp ,  hwUnlitShader.cpp ,  pnTrianglesNode.cpp , and  quadricShape.cpp . 
 
'''
        pass

    def displayCullOpposite(self): 
        '''displayCullOpposite(self) -> bool

'''
        pass

    def setDisplayStyle(self, style): 
        '''setDisplayStyle(self, style)
Arguments:
	[in]	style = M3dView.DisplayStyle


Sets how the object should be drawn (wireframe, shaded, etc.).'''
        pass

    def setDisplayCulling(self, value): 
        '''setDisplayCulling(self, value)
Arguments:
	[in]	value = bool


Sets the state of the culling flag for the object.'''
        pass

    def isTransparent(self): 
        '''isTransparent(self) -> bool


Returns the transparency state of the object. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp , and  quadricShape.cpp . 
 
'''
        pass

    def material(self): 
        '''material(self) -> MMaterial


Returns the shaded material. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp ,  pnTrianglesNode.cpp , and  quadricShape.cpp . 
 
'''
        pass

    def component(self): 
        '''component(self) -> MObject


An optional component. If set draw the components that are specified, otherwise draw all components of this type for the object. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp , and  apiSimpleShapeUI.cpp . 
 
'''
        pass

    def displayStatus(self): 
        '''displayStatus(self) -> M3dView.DisplayStatus

'''
        pass

    def setView(self, theView): 
        '''setView(self, theView)
Arguments:
	[in]	theView = M3dView

'''
        pass

    def setDrawData(self, data): 
        '''setDrawData(self, data)
Arguments:
	[in]	data = MDrawData


Set the object specific draw data.'''
        pass

    def setMultiPath(self, thePath): 
        '''setMultiPath(self, thePath)
Arguments:
	[in]	thePath = MDagPath

'''
        pass

    def setToken(self, value): 
        '''setToken(self, value)
Arguments:
	[in]	value = int


Set the user-defined draw token for this request.'''
        pass

    def setColor(self, value, table): 
        '''setColor(self, value, table)
Arguments:
	[in]	value = int
	[in]	table = M3dView.ColorTable


Sets the wireframe display color.'''
        pass

    def setDisplayStatus(self, status): 
        '''setDisplayStatus(self, status)
Arguments:
	[in]	status = M3dView.DisplayStatus


Set the state of object (active, dormant, etc.).'''
        pass

    def token(self): 
        '''token(self) -> int


Returns the user-defined draw token for this request.'''
        pass

    def drawData(self): 
        '''drawData(self) -> MDrawData


Returns the object specific draw data. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshShapeUI.cpp ,  apiSimpleShapeUI.cpp ,  pnTrianglesNode.cpp , and  quadricShape.cpp . 
 
'''
        pass

    def drawLast(self): 
        '''drawLast(self) -> bool

'''
        pass

    def setIsTransparent(self, value): 
        '''setIsTransparent(self, value)
Arguments:
	[in]	value = bool


Sets the transparency state of the object.'''
        pass

    def view(self): 
        '''view(self) -> M3dView

'''
        pass

class MDrawRequestQueue:
    '''Drawing queue used in MPxSurfaceShapeUI::getDrawRequests. This class defines a simple interface for a collection of MDrawRequest objects.An MDrawRequestQueue object is passed to the getDrawRequests method of a user defined shape's UI class (MPxSurfaceShapeUI). This queue keeps track of all the things that need to get draw when a refresh of the view occurs.Maya will call the getDrawRequest methods of all the visible DAG objects before a refresh happens. Then as the refresh happens, each draw request will be processed and the corresponding draw method for each DAG object will get called. For user defined shapes MPxSurfaceShapeUI::draw will get called. '''
    def __init__(self):
        pass


    def add(self, request): 
        '''add(self, request)
Arguments:
	[in]	request = MDrawRequest


Adds a draw request to the draw queue.'''
        pass

    def isEmpty(self): 
        '''isEmpty(self) -> bool


Returns true if the queu is empty.'''
        pass

    def remove(self): 
        '''remove(self) -> MDrawRequest


Removes a draw request from the draw queue.'''
        pass

class MDrawTraversal:
    '''A scene drawing traverser. MDrawTraversal is a utility class for interactive drawing. The purpose of the class is to traverse through the current scene dag and provide a means of accessing a list of visible objects with respect to a given frustum specification, and application "visibility" criteria.The additional "visibility" criteria include:Note that as the traversal is not dependent on a 3d modeling viewport. There are thus no checks for per viewport visibility properties such as per viewport dag object type overrides, and "isolate select".Additionally, render layer visibility checks are not performed, as these pertain to software rendering.After traversal the list will contain leaf level nodes (shapes), which have passed the "visibility" criteria.For the actual frustum culling, there is a choice of two culling algorithms:Note that hierarchical culling may force evaluation of geometry on dag objects which are not visible.The default is thus to perform leaf level culling only.Frustum culling is performed against the bounding boxes of dag objects encountered.API writers can derive from this class and change the filterNode() virtual method to perform custom filtering of objects during traversal. That is they will be excluded from the output list. By default this class does no additional filtering. '''
    def __init__(self):
        pass


    def filterNode(self, traversalItem): 
        '''filterNode(self, traversalItem) -> bool
Returns: Will always return false for MDrawTraversal class. 

Arguments:
	[in]	traversalItem = MDagPath


Method to allow filtering during traversal. The traversalItem can be examined, and if it is not match the desired criteria, it will not be added to the output traversal list.'''
        pass

    def itemHasStatus(self, itemNumber, test): 
        '''itemHasStatus(self, itemNumber, test) -> bool
Returns: true, if item status matches the display status to test against. 

Arguments:
	[in]	itemNumber = int
	[in]	test = int


Test the display status for a given item in the list of found items after traversal.'''
        pass

    def traverse(self): 
        '''traverse(self)

Perform traversal of the current scene from the root of the dag hierarchy. A valid frustum must be set before calling this method.'''
        pass

    def numberOfItems(self): 
        '''numberOfItems(self) -> int


Return the number of items found after traversal.'''
        pass

    def setFrustum(self, nearBottomLeft, nearBottomRight, nearTopLeft, nearTopRight, farBottomLeft, farBottomRight, farTopLeft, farTopRight, worldXform): 
        '''setFrustum(self, nearBottomLeft, nearBottomRight, nearTopLeft, nearTopRight, farBottomLeft, farBottomRight, farTopLeft, farTopRight, worldXform)
Arguments:
	[in]	nearBottomLeft = MPoint
	[in]	nearBottomRight = MPoint
	[in]	nearTopLeft = MPoint
	[in]	nearTopRight = MPoint
	[in]	farBottomLeft = MPoint
	[in]	farBottomRight = MPoint
	[in]	farTopLeft = MPoint
	[in]	farTopRight = MPoint
	[in]	worldXform = MMatrix


Set up a frustum to cull with by specifying the 8 corner points. Asymmetric frustum's can be set up using this method.'''
        pass

    def enum(self): 
        '''enum(self) -> anonymous


Item status enum. 
'''
        pass

    def itemPath(self, itemNumber, path): 
        '''itemPath(self, itemNumber, path)
Arguments:
	[in]	itemNumber = int
	[out]	path = MDagPath


Get the path for a given item in the list of found items after traversal.'''
        pass

    def setPerspFrustum(self, fovX, aspectXY, nearDist, farDist, worldXform): 
        '''setPerspFrustum(self, fovX, aspectXY, nearDist, farDist, worldXform)
Arguments:
	[in]	fovX = double
	[in]	aspectXY = double
	[in]	nearDist = double
	[in]	farDist = double
	[in]	worldXform = MMatrix


Set up an perspective view frustum to cull with. The frustum is symmetric about the vertical and horizontal.'''
        pass

    def enableFiltering(self, val): 
        '''enableFiltering(self, val)
Arguments:
	[in]	val = bool


Sets whether to use enable usage of the  filterNode()  method to perform custom filtering. By default this is set to false.'''
        pass

    def frustumValid(self): 
        '''frustumValid(self) -> bool


Returns whether the current frustum set is valid or not. If it is not valid a call to the  traverse()  function will result in returning failure.'''
        pass

    def setLeafLevelCulling(self, cullAtLeafLevel): 
        '''setLeafLevelCulling(self, cullAtLeafLevel)
Arguments:
	[in]	cullAtLeafLevel = bool


Set whether to cull at the leaf levels, or perform hierarchical culling.'''
        pass

    def leafLevelCulling(self): 
        '''leafLevelCulling(self) -> bool


Returns whether the current cull algorithm will cull at the leaf levels, or perform hierarchical culling. The default value is leaf level culling.'''
        pass

    def filteringEnabled(self): 
        '''filteringEnabled(self) -> bool


Tells whether custom filtering has been enabled. That is, to use the  filterNode()  method during traversal.'''
        pass

    def setOrthoFrustum(self, left, right, bottom, top, nearpt, farpt, worldXform): 
        '''setOrthoFrustum(self, left, right, bottom, top, nearpt, farpt, worldXform)
Arguments:
	[in]	left = double
	[in]	right = double
	[in]	bottom = double
	[in]	top = double
	[in]	nearpt = double
	[in]	farpt = double
	[in]	worldXform = MMatrix


Set up an orthographic view frustum to cull with. The frustum is symmetric about the vertical and horizontal.'''
        pass

class MEvent:
    '''System event information. The MEvent class is used for querying system events such as mouse presses.Events are handled by an MPxContext derived class in which MEvents are passed and can be accessed.Since Maya has default actions for several events, only a subset are avalaible through the API. The events that can be accessed are:Several modifiers for events are also accessible through the API. Modifiers are actions that occur during an event. For example, holding down the shift key while pressing a mouse button causes a button press event to occur with a shift modifier.A modifier can be used to determine if two mouse events occur simulaneously. The second mouse event is registered as a modifier in the hold event of the first mouse button. So if you wanted to determine if both the left and middle buttons are pressed then you would query the modifier in the hold event of the first mouse button using the isModifierMiddleMouseButton() and isModifierLeftMouseButton() methods. '''
    def __init__(self):
        pass


    def isModifierKeyRelease(self): 
        '''isModifierKeyRelease(self) -> bool


Was a modifier key released.'''
        pass

    def setModifiers(self, modType): 
        '''setModifiers(self, modType)
Arguments:
	[in]	modType = MEvent.ModifierType


set the event modifiers.'''
        pass

    def kMiddleMouse(self):
        '''This is an enum of MouseButtonType.
Description: 
Value: 128'''
        pass

    def kLeftMouse(self):
        '''This is an enum of MouseButtonType.
Description: 
Value: 64'''
        pass

    class MouseButtonType:
        '''Non-functional class.  Values for this enum:
        kMiddleMouse
        kLeftMouse
'''
        def __init__(self):
            pass

    def isModifierNone(self): 
        '''isModifierNone(self) -> bool


Determines if there are any modifiers for this event.'''
        pass

    def mouseButton(self): 
        '''mouseButton(self) -> MEvent.MouseButtonType


Get the mouse button of the last event.'''
        pass

    def isModifierMiddleMouseButton(self): 
        '''isModifierMiddleMouseButton(self) -> bool


Return the state of the middle mouse button.'''
        pass

    def isModifierControl(self): 
        '''isModifierControl(self) -> bool


return state of control key.'''
        pass

    def getWindowPosition(self, x_pos, y_pos): 
        '''getWindowPosition(self, x_pos, y_pos)
Arguments:
	[out]	x_pos = short
	[out]	y_pos = short


This routine is used by responders to query the position of the pointer when the event occurred. It is given in screen co-ordinates.'''
        pass

    def modifiers(self): 
        '''modifiers(self) -> MEvent.ModifierType


This routine is used by responders to find the state of the modifiers during the event.'''
        pass

    def isModifierShift(self): 
        '''isModifierShift(self) -> bool


return state of shift key.'''
        pass

    def shiftKey(self):
        '''This is an enum of ModifierType.
Description: 
Value: 1'''
        pass

    def controlKey(self):
        '''This is an enum of ModifierType.
Description: 
Value: 4'''
        pass

    class ModifierType:
        '''Non-functional class.  Values for this enum:
        shiftKey
        controlKey
'''
        def __init__(self):
            pass

    def setPosition(self, x_pos, y_pos): 
        '''setPosition(self, x_pos, y_pos)
Arguments:
	[in]	x_pos = short
	[in]	y_pos = short


set the location of the event to the specified location. The origin is at the lower left corner of the window.'''
        pass

    def isModifierLeftMouseButton(self): 
        '''isModifierLeftMouseButton(self) -> bool


Return the state of the left mouse button.'''
        pass

    def getPosition(self, x_pos, y_pos): 
        '''getPosition(self, x_pos, y_pos)
Arguments:
	[out]	x_pos = short
	[out]	y_pos = short


Get the location of the event in view co-ordinates. The origin is at the lower left corner of the window.'''
        pass

class MFeedbackLine:
    '''Feedback line. The MFeedbackLine class is used to display information back to the user. The format for the feedback line which indicates the number and type of the arguments should be set with the setFormat method. The values of the arguments should be set using the setValue method. '''
    def __init__(self):
        pass


    def setValue(self, index, value): 
        '''setValue(self, index, value)
Arguments:
	[in]	index = short
	[in]	value = double


Set the value of a given index in the feedback line'''
        pass

    def setFormat(self, format): 
        '''setFormat(self, format)
Arguments:
	[in]	format = MString


Set the format string for the feedback line. The format begins with a format specifier "^" followed by the format size, format decimal character ".", decimal size, and format type. For example: the format "^6.3f" which specifies that there is going to be one value given, it is a float, with 3 decimal places shown.'''
        pass

    def setTitle(self, title): 
        '''setTitle(self, title)
Arguments:
	[in]	title = MString


Set the title string.'''
        pass

    def setShowFeedback(self, showFeedback): 
        '''setShowFeedback(self, showFeedback)
Arguments:
	[in]	showFeedback = bool


Set whether the feedback line is supposed to be displaying data.'''
        pass

    def clear(self): 
        '''clear(self)
'''
        pass

    def showFeedback(self): 
        '''showFeedback(self) -> bool


Return whether or not the feedback line is is supposed to be displaying data.'''
        pass

class MFnCircleSweepManip:
    '''CircleSweepManip function set. The CircleSweepManip allows the user to manipulate a point constrained to move around a circle, in order to specify a sweep angle. This manipulator generates a single floating point value corresponding to the sweep angle. '''
    def __init__(self):
        pass


    def setEndPoint(self, endPoint): 
        '''setEndPoint(self, endPoint)
Arguments:
	[in]	endPoint = MPoint


Sets the end point of the CircleSweepManip.'''
        pass

    def endCircleIndex(self): 
        '''endCircleIndex(self) -> int
Returns: The circle end index


Returns the index for the end of the circle of CircleSweepManip. The data type corresponding to this index is a double.'''
        pass

    def setDrawAsArc(self, state): 
        '''setDrawAsArc(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to draw as arc.'''
        pass

    def setRadius(self, radius): 
        '''setRadius(self, radius)
Arguments:
	[in]	radius = double


Sets the radius of the CircleSweepManip.'''
        pass

    def axisIndex(self): 
        '''axisIndex(self) -> int
Returns: The axis index


Returns the index for the axis of CircleSweepManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setNormal(self, normal): 
        '''setNormal(self, normal)
Arguments:
	[in]	normal = MVector


Sets the normal of the CircleSweepManip.'''
        pass

    def setAngle(self, angle): 
        '''setAngle(self, angle)
Arguments:
	[in]	angle = MAngle


Sets the angle of the CircleSweepManip.'''
        pass

    def create(self, manipName, angleName): 
        '''create(self, manipName, angleName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	angleName = MString


Creates a new CircleSweepManip. This function set's object is set to be the new manipulator.'''
        pass

    def connectToAnglePlug(self, anglePlug): 
        '''connectToAnglePlug(self, anglePlug)
Arguments:
	[in]	anglePlug = MPlug


Connect to the angle plug. The data type corresponding to the anglePlug is a double. (Note that  MFnUnitAttribute::kAngle  is used to specify an angle attribute.)'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def endPoint(self): 
        '''endPoint(self) -> MPoint
Returns: The end point


Returns the end point.'''
        pass

    def startCircleIndex(self): 
        '''startCircleIndex(self) -> int
Returns: The circle start index


Returns the index for the start of the circle of CircleSweepManip. The data type corresponding to this index is a double.'''
        pass

    def centerIndex(self): 
        '''centerIndex(self) -> int
Returns: The center index


Returns the index for the center of the CircleSweepManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def angleIndex(self): 
        '''angleIndex(self) -> int
Returns: The angle index


Returns the index for the angle of CircleSweepManip. The data type corresponding to this index is a double.'''
        pass

    def setCenterPoint(self, centerPoint): 
        '''setCenterPoint(self, centerPoint)
Arguments:
	[in]	centerPoint = MPoint


Sets the center point of the CircleSweepManip.'''
        pass

    def setStartPoint(self, startPoint): 
        '''setStartPoint(self, startPoint)
Arguments:
	[in]	startPoint = MPoint


Sets the start point of the CircleSweepManip.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def startPoint(self): 
        '''startPoint(self) -> MPoint
Returns: The start point


Returns the start point.'''
        pass

class MFnCurveSegmentManip:
    '''CurveSegmentManip function set. The CurveSegmentManip allows the user to manipulate two points on a curve, in order to specify a curve segment. This manipulator generates two floating point values, which correspond to the parameters of the start and end of the curve segment. '''
    def __init__(self):
        pass


    def setStartParameter(self, startParameter): 
        '''setStartParameter(self, startParameter)
Arguments:
	[in]	startParameter = double


Sets the start parameter.'''
        pass

    def endParameter(self): 
        '''endParameter(self) -> double
Returns: End parameter


Returns the end parameter.'''
        pass

    def create(self, manipName, startParamName, endParamName): 
        '''create(self, manipName, startParamName, endParamName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	startParamName = MString
	[in]	endParamName = MString


Creates a new CurveSegmentManip. This function set's object is set to be the new manipulator.'''
        pass

    def connectToCurvePlug(self, curvePlug): 
        '''connectToCurvePlug(self, curvePlug)
Arguments:
	[in]	curvePlug = MPlug


Connect to the curve plug. The data type corresponding to the curvePlug is  MFnData::kNurbsCurve .'''
        pass

    def connectToStartParamPlug(self, startParamPlug): 
        '''connectToStartParamPlug(self, startParamPlug)
Arguments:
	[in]	startParamPlug = MPlug


Connect to the startParam plug. The data type corresponding to the startParamPlug is a double.'''
        pass

    def setEndParameter(self, endParameter): 
        '''setEndParameter(self, endParameter)
Arguments:
	[in]	endParameter = double


Sets the end parameter.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def curveIndex(self): 
        '''curveIndex(self) -> int
Returns: Curve index


Returns the index of the curve. The data type corresponding to this index is  MFnData::kNurbsCurve .'''
        pass

    def connectToEndParamPlug(self, endParamPlug): 
        '''connectToEndParamPlug(self, endParamPlug)
Arguments:
	[in]	endParamPlug = MPlug


Connect to the endParam plug. The data type corresponding to the endParamPlug is a double.'''
        pass

    def endParamIndex(self): 
        '''endParamIndex(self) -> int
Returns: End parameter index


Returns the index of the end parameter of the CurveSegmentManip. The data type corresponding this index is a double.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def startParamIndex(self): 
        '''startParamIndex(self) -> int
Returns: Start parameter index


Returns the index of the start parameter of the CurveSegmentManip. The data type corresponding to this index is a double.'''
        pass

    def startParameter(self): 
        '''startParameter(self) -> double
Returns: start parameter


Returns the start parameter.'''
        pass

class MFnDirectionManip:
    '''DirectionManip function set. The DirectionManip allows the user to specify a direction, as defined by the vector from the start point to the manipulator position. It uses a FreePointTriadManip to specify the end point of a vector relative to a given start point. This manipulator generates a vector from the start point to the end point. '''
    def __init__(self):
        pass


    def endPointIndex(self): 
        '''endPointIndex(self) -> int
Returns: End point index


Returns the index of the end point of the DirectionManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setDrawStart(self, state): 
        '''setDrawStart(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to draw the start of the DirectionManip. The start of the DirectionManip is indicated by a grey dot. By default the start is not drawn.'''
        pass

    def setDirection(self, direction): 
        '''setDirection(self, direction)
Arguments:
	[in]	direction = MVector


Sets the direction of the DirectionManip.'''
        pass

    def create(self, manipName, directionName): 
        '''create(self, manipName, directionName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	directionName = MString


Creates a new DirectionManip. This function set's object is set to be the new manipulator.'''
        pass

    def startPointIndex(self): 
        '''startPointIndex(self) -> int
Returns: Start point index


Returns the index of the start point of the DirectionManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def directionIndex(self): 
        '''directionIndex(self) -> int
Returns: Direction index


Returns the index of the direction. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setNormalizeDirection(self, state): 
        '''setNormalizeDirection(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to the direction should be normalized. By default the direction is normalized.'''
        pass

    def setStartPoint(self, startPoint): 
        '''setStartPoint(self, startPoint)
Arguments:
	[in]	startPoint = MPoint


Sets the start point of the DirectionManip.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def connectToDirectionPlug(self, directionPlug): 
        '''connectToDirectionPlug(self, directionPlug)
Arguments:
	[in]	directionPlug = MPlug


Connect to the direction plug. The data type corresponding to the directionPlug is  MFnNumericData::k3Double .'''
        pass

class MFnDiscManip:
    '''DiscManip function set. The DiscManip allows the user to rotate a disc in order to specify a rotation about an axis. This manipulator generates a single floating point value corresponding to the rotation. '''
    def __init__(self):
        pass


    def axisIndex(self): 
        '''axisIndex(self) -> int
Returns: Axis index


Returns the index of the axis of the DiscManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setNormal(self, normal): 
        '''setNormal(self, normal)
Arguments:
	[in]	normal = MVector


Sets the normal of the DiscManip.'''
        pass

    def setAngle(self, angle): 
        '''setAngle(self, angle)
Arguments:
	[in]	angle = MAngle


Sets the angle of the DiscManip.'''
        pass

    def create(self, manipName, angleName): 
        '''create(self, manipName, angleName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	angleName = MString


Creates a new DiscManip. This function set's object is set to be the new manipulator.'''
        pass

    def connectToAnglePlug(self, anglePlug): 
        '''connectToAnglePlug(self, anglePlug)
Arguments:
	[in]	anglePlug = MPlug


Connect to the angle plug. The data type corresponding to the anglePlug is a double. (Note that  MFnUnitAttribute::kAngle  is used to specify an angle attribute.)'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def angleIndex(self): 
        '''angleIndex(self) -> int
Returns: Angle index


Returns the index of the angle. The data type corresponding to this index is a double.'''
        pass

    def setCenterPoint(self, centerPoint): 
        '''setCenterPoint(self, centerPoint)
Arguments:
	[in]	centerPoint = MPoint


Sets the center point of the DiscManip.'''
        pass

    def setRadius(self, radius): 
        '''setRadius(self, radius)
Arguments:
	[in]	radius = double


Sets the radius of the DiscManip.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def centerIndex(self): 
        '''centerIndex(self) -> int
Returns: Center index


Returns the index of the center of the DiscManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

class MFnDistanceManip:
    '''DistanceManip function set. The DistanceManip allows the user to manipulate a point that is constrained to move along a line. This manipulator generates a single floating point value. Scaling factors can be used to determine how int the manipulator appears when it is drawn. '''
    def __init__(self):
        pass


    def setDrawStart(self, state): 
        '''setDrawStart(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to draw the start of the DistanceManip. The start of the DistanceManip is indicated by a grey dot. By default the start is not drawn.'''
        pass

    def setScalingFactor(self, scalingFactor): 
        '''setScalingFactor(self, scalingFactor)
Arguments:
	[in]	scalingFactor = double


Sets the scaling factor. The scaling factor is used to determine how int the DistanceManip appears when it is drawn. The default scaling factor is 1.0.'''
        pass

    def setDirection(self, direction): 
        '''setDirection(self, direction)
Arguments:
	[in]	direction = MVector


Sets the direction of the DistanceManip.'''
        pass

    def currentPointIndex(self): 
        '''currentPointIndex(self) -> int
Returns: Current point index


Returns the index of the current point of the DistanceManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def create(self, manipName, distanceName): 
        '''create(self, manipName, distanceName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	distanceName = MString


Creates a new DistanceManip. This function set's object is set to be the new manipulator.'''
        pass

    def setDrawLine(self, state): 
        '''setDrawLine(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to draw a line from the start to the end of the DistanceManip. By default the line is drawn.'''
        pass

    def connectToDistancePlug(self, distancePlug): 
        '''connectToDistancePlug(self, distancePlug)
Arguments:
	[in]	distancePlug = MPlug


Connect to the distance plug. The data type corresponding to the distancePlug is a double. (Note that  MFnUnitAttribute::kDistance  is used to specify a distance attribute.)'''
        pass

    def startPointIndex(self): 
        '''startPointIndex(self) -> int
Returns: Start point index


Returns the index of the start point of the DistanceManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def directionIndex(self): 
        '''directionIndex(self) -> int
Returns: Direction index


Returns the index of the direction. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def isDrawStartOn(self): 
        '''isDrawStartOn(self) -> bool
Returns: true the start of the DistanceManip is being drawn 
false the start of the DistanceManip is not being drawn


Returns whether or not the start of the DistanceManip is being drawn. By default the start is not drawn.'''
        pass

    def distanceIndex(self): 
        '''distanceIndex(self) -> int
Returns: Distance index


Returns the index of the distance. The data type corresponding to this index is a double.'''
        pass

    def isDrawLineOn(self): 
        '''isDrawLineOn(self) -> bool
Returns: true the line of the DistanceManip is being drawn 
false the line of the DistanceManip is not being drawn


Returns whether or not a line is being drawn from the start to the end of the DistanceManip. By default the line is drawn.'''
        pass

    def setStartPoint(self, startPoint): 
        '''setStartPoint(self, startPoint)
Arguments:
	[in]	startPoint = MPoint


Sets the start point of the DistanceManip.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def scalingFactor(self): 
        '''scalingFactor(self) -> double
Returns: Scaling factor


Returns the scaling factor. The scaling factor is used to determine how int the DistanceManip appears when it is drawn.'''
        pass

class MFnFreePointTriadManip:
    '''FreePointTriadManip function set. The FreePointTriadManip provides a moveable point, which can be moved anywhere, and has axes for constrained x, y, and z movement and obeys grid snapping, point snapping, and curve snapping. The FreePointTriadManip generates the 3D position of the moveable point. It is useful for specifying the position of an object in space. '''
    def __init__(self):
        pass


    def setDirection(self, direction): 
        '''setDirection(self, direction)
Arguments:
	[in]	direction = MVector


Sets the orientation of the FreePointTriadManip.'''
        pass

    def isKeyframeAllOn(self): 
        '''isKeyframeAllOn(self) -> bool
Returns: true the FreePointTriadManip is in keyframeAll mode 
false the FreePointTriadManip is not in keyframeAll mode


Returns whether or not the FreePointTriadManip is in keyframeAll mode.'''
        pass

    def create(self, manipName, pointName): 
        '''create(self, manipName, pointName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	pointName = MString


Creates a new FreePointTriadManip. This function set's object is set to be the new manipulator.'''
        pass

    def connectToPointPlug(self, pointPlug): 
        '''connectToPointPlug(self, pointPlug)
Arguments:
	[in]	pointPlug = MPlug


Connect to the point plug. The data type corresponding to the pointPlug is  MFnNumericData::k3Double .'''
        pass

    def setGlobalTriadPlane(self, whichPlane): 
        '''setGlobalTriadPlane(self, whichPlane)
Arguments:
	[in]	whichPlane = MFnFreePointTriadManip.ManipPlane


Sets which plane to use as the global triad plane. The global triad plane does not change until the context switches.'''
        pass

    def kYZPlane(self):
        '''This is an enum of ManipPlane.
Description: Y-Z Plane.
Value: 0'''
        pass

    def kXZPlane(self):
        '''This is an enum of ManipPlane.
Description: X-Z Plane.
Value: 1'''
        pass

    def kXYPlane(self):
        '''This is an enum of ManipPlane.
Description: X-Y Plane.
Value: 2'''
        pass

    def kViewPlane(self):
        '''This is an enum of ManipPlane.
Description: View Plane.
Value: 3'''
        pass

    class ManipPlane:
        '''Non-functional class.  Values for this enum:
        kYZPlane
        kXZPlane
        kXYPlane
        kViewPlane
'''
        def __init__(self):
            pass

    def isDrawAxesOn(self): 
        '''isDrawAxesOn(self) -> bool
Returns: true the axes of the FreePointTriadManip are being drawn 
false the axes of the FreePointTriadManip are not being drawn


Returns whether or not the axes of the FreePointTriadManip are being drawn. By default the axes are drawn.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def isSnapModeOn(self): 
        '''isSnapModeOn(self) -> bool
Returns: true the FreePointTriadManip is in snap mode 
false the FreePointTriadManip is not in snap mode


Returns whether or not the FreePointTriadManip is in snap mode.'''
        pass

    def pointIndex(self): 
        '''pointIndex(self) -> int
Returns: Point index


Returns the index of the point of the FreePointTriadManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setPoint(self, pointValue): 
        '''setPoint(self, pointValue)
Arguments:
	[in]	pointValue = MPoint


Set the point manipulator value to the given vector. This method can be called in the  MPxManipContainer::connectToDependNode()  method to set the initial position for the manipulator.'''
        pass

    def setSnapMode(self, state): 
        '''setSnapMode(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to the FreePointTriadManip should be in snap mode.'''
        pass

    def setDrawArrowHead(self, state): 
        '''setDrawArrowHead(self, state)
Arguments:
	[in]	state = bool


Sets whether or not drawArrowHead is on.'''
        pass

    def setKeyframeAll(self, state): 
        '''setKeyframeAll(self, state)
Arguments:
	[in]	state = bool


Sets whether or not keyframeAll is on.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setDrawAxes(self, state): 
        '''setDrawAxes(self, state)
Arguments:
	[in]	state = bool


Sets whether or not to draw the axes of the FreePointTriadManip. By default the axes are drawn.'''
        pass

class MFnManip3D:
    '''3D manipulator function set MFnManip3D allows the creation and manipulation of 3D manipulators. MFnManip3D is the base class from which MFnFreePointTriadManip, MFnDirectionManip, MFnDistanceManip, MFnPointOnCurveManip, MFnPointOnSurfaceManip, MFnDiscManip, MFnCircleSweepManip, MFnToggleManip, MFnStateManip, and MFnCurveSegmentManip are derived. '''
    def __init__(self):
        pass


    def globalSize(self): 
        '''globalSize(self) -> float


Returns the global manipulator size.'''
        pass

    def manipScale(self): 
        '''manipScale(self) -> float
Returns: The manipulator scale


Returns the manipulator scale.'''
        pass

    def lineSize(self): 
        '''lineSize(self) -> float


Returns the manipulator line size.'''
        pass

    def setManipScale(self, size): 
        '''setManipScale(self, size)
Arguments:
	[in]	size = float


Sets the manipulator scale.'''
        pass

    def setGlobalSize(self, size): 
        '''setGlobalSize(self, size)
Arguments:
	[in]	size = float


Sets the global manipulator size.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setLineSize(self, size): 
        '''setLineSize(self, size)
Arguments:
	[in]	size = float


Sets the manipulator line size.'''
        pass

    def handleSize(self): 
        '''handleSize(self) -> float


Returns the manipulator handle size.'''
        pass

    def setOptimizePlayback(self, optimizePlayback): 
        '''setOptimizePlayback(self, optimizePlayback)
Arguments:
	[in]	optimizePlayback = bool


Sets whether or not to optimize the playback'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def deleteManipulator(self, manip): 
        '''deleteManipulator(self, manip)
Arguments:
	[in]	manip = MObject


Delete a manipulator. This method should be used to delete manipulators that have been created using base manipulator  create()  methods.'''
        pass

    def isVisible(self): 
        '''isVisible(self) -> bool
Returns: true the manipulator is visible 
false the manipulator is not visible


Returns whether or not the manipulator is visible.'''
        pass

    def setHandleSize(self, size): 
        '''setHandleSize(self, size)
Arguments:
	[in]	size = float


Sets the manipulator handle size.'''
        pass

    def rotateXYZValue(self, valIndex): 
        '''rotateXYZValue(self, valIndex) -> MEulerRotation

Arguments:
	[in]	valIndex = int


Gets the rotation for the active manipulator.'''
        pass

    def setVisible(self, isVisible): 
        '''setVisible(self, isVisible)
Arguments:
	[out]	isVisible = bool


Sets whether or not the manipulator is visible.'''
        pass

    def isOptimizePlaybackOn(self): 
        '''isOptimizePlaybackOn(self) -> bool
Returns: true optimize playback is on 
false optimize playback is off


Returns whether or not optimize playback is on'''
        pass

class MFnPointOnCurveManip:
    '''PointOnCurveManip function set. The PointOnCurveManip allows the user to manipulate a point constrained to move along a curve, in order to specify the "u" curve parameter value. This manipulator generates a single floating point value corresponding to the curve parameter. '''
    def __init__(self):
        pass


    def curvePoint(self): 
        '''curvePoint(self) -> MPoint
Returns: The curve point


Returns the curve point.'''
        pass

    def parameter(self): 
        '''parameter(self) -> double
Returns: Parameter


Returns the parameter.'''
        pass

    def create(self, manipName, paramName): 
        '''create(self, manipName, paramName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	paramName = MString


Creates a new PointOnCurveManip. This function set's object is set to be the new manipulator.'''
        pass

    def setDrawCurve(self, state): 
        '''setDrawCurve(self, state)
Arguments:
	[in]	state = bool


Sets whether or not the curve is drawn.'''
        pass

    def connectToCurvePlug(self, curvePlug): 
        '''connectToCurvePlug(self, curvePlug)
Arguments:
	[in]	curvePlug = MPlug


Connect to the curve plug. The data type corresponding to the curvePlug is  MFnData::kNurbsCurve .'''
        pass

    def connectToParamPlug(self, paramPlug): 
        '''connectToParamPlug(self, paramPlug)
Arguments:
	[in]	paramPlug = MPlug


Connect to the param plug. The data type corresponding to the paramPlug is a double.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def curveIndex(self): 
        '''curveIndex(self) -> int
Returns: Curve index


Returns the index of the curve. The data type corresponding to this index is  MFnData::kNurbsCurve .'''
        pass

    def isDrawCurveOn(self): 
        '''isDrawCurveOn(self) -> bool
Returns: true the curve is being drawn 
false the curve is not being drawn


Returns whether or not the curve is drawn.'''
        pass

    def paramIndex(self): 
        '''paramIndex(self) -> int
Returns: Parameter index


Returns the index of the parameter of the PointOnCurveManip. The data type corresponding to this index is a double.'''
        pass

    def setParameter(self, parameter): 
        '''setParameter(self, parameter)
Arguments:
	[in]	parameter = double


Sets the parameter.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnPointOnSurfaceManip:
    '''PointOnSurfaceManip function set. The PointOnSurfaceManip allows the user to manipulate a point constrained to move along a surface, in order to specify the (u, v) surface parameter values. This manipulator generates two floating point values corresponding to the surface (u, v) parameters. '''
    def __init__(self):
        pass


    def setDrawArrows(self, state): 
        '''setDrawArrows(self, state)
Arguments:
	[in]	state = bool


Sets whether or not the arrows should be drawn.'''
        pass

    def isDrawSurfaceOn(self): 
        '''isDrawSurfaceOn(self) -> bool
Returns: true the surface is being drawn 
false the surface is not being drawn


Returns whether or not the surface is drawn.'''
        pass

    def setParameters(self, u, v): 
        '''setParameters(self, u, v)
Arguments:
	[in]	u = double
	[in]	v = double


Sets the u and v parameters.'''
        pass

    def create(self, manipName, paramName): 
        '''create(self, manipName, paramName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	paramName = MString


Creates a new PointOnSurfaceManip. This function set's object is set to be the new manipulator.'''
        pass

    def paramIndex(self): 
        '''paramIndex(self) -> int
Returns: Parameter index


Returns the index of the parameter of the PointOnSurfaceManip. The data type corresponding to this index is  MFnNumericData::k2Double .'''
        pass

    def connectToParamPlug(self, paramPlug): 
        '''connectToParamPlug(self, paramPlug)
Arguments:
	[in]	paramPlug = MPlug


Connect to the param plug. The data type corresponding to the paramPlug is  MFnNumericData::k2Double .'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def setDrawSurface(self, state): 
        '''setDrawSurface(self, state)
Arguments:
	[in]	state = bool


Sets whether or not the surface is drawn.'''
        pass

    def surfaceIndex(self): 
        '''surfaceIndex(self) -> int
Returns: Surface index


Returns the index of the surface. The data type corresponding to this index is  MFnData::kNurbsSurface .'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getParameters(self, u, v): 
        '''getParameters(self, u, v)
Arguments:
	[out]	u = double
	[out]	v = double


Returns the parameter.'''
        pass

    def connectToSurfacePlug(self, surfacePlug): 
        '''connectToSurfacePlug(self, surfacePlug)
Arguments:
	[in]	surfacePlug = MPlug


Connect to the surface plug. The data type corresponding to the surfacePlug is  MFnData::kNurbsSurface .'''
        pass

class MFnRotateManip:
    '''RotateManip function set. This class provides access to the built-in Maya rotate manipulator. The manipulator consists of three constrained-axis rotation rings, a view rotation ring, as well as an invisible trackball that allows the user to rotate in arbitrary directions on the sphere.The manipulator provides data to the plugin through the rotation manipVal. The rotation value is a vector consisting of x, y, and z rotations. Rotations are measured from the initial rotation (usually <0,0,0>) of the manipulator.The manipulator can be configured either to display with an object (which must be a DAG node) or to display at an arbitrary point using the rotationCenter manipVal. '''
    def __init__(self):
        pass


    def connectToRotationCenterPlug(self, rotationCenterPlug): 
        '''connectToRotationCenterPlug(self, rotationCenterPlug)
Arguments:
	[in]	rotationCenterPlug = MPlug


Create a 1-1 association of the rotation center on the manipulator and the rotationCenterPlug parameter. When both the rotation center is attached to a plug and the  displayWithNode()  method has been called, the manipulator will display with the node regardless of the connection made to the rotation center.'''
        pass

    def setSnapMode(self, snapEnabled): 
        '''setSnapMode(self, snapEnabled)
Arguments:
	[in]	snapEnabled = bool


Sets the snap mode. The snap modes can be either on (true) or off (false). When snap mode is on, rotation manip values will snap to the values within some increment apart.'''
        pass

    def create(self, manipName, rotationName): 
        '''create(self, manipName, rotationName) -> MObject
Returns: An object corresponding to the new manipulator

Arguments:
	[in]	manipName = MString
	[in]	rotationName = MString


Creates a new RotateManip, and attaches this function set to the new manipulator.'''
        pass

    def rotateMode(self): 
        '''rotateMode(self) -> MFnRotateManip.RotateMode


Returns the current rotation mode.'''
        pass

    def snapIncrement(self): 
        '''snapIncrement(self) -> double


Returns the snapping increment in degrees.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def kWorldSpace(self):
        '''This is an enum of RotateMode.
Description: World Space.
Value: 1'''
        pass

    def kObjectSpace(self):
        '''This is an enum of RotateMode.
Description: Object Space (default).
Value: 0'''
        pass

    def kGimbal(self):
        '''This is an enum of RotateMode.
Description: Gimbal.
Value: 2'''
        pass

    class RotateMode:
        '''Non-functional class.  Values for this enum:
        kWorldSpace
        kObjectSpace
        kGimbal
'''
        def __init__(self):
            pass

    def setSnapIncrement(self, snapInc): 
        '''setSnapIncrement(self, snapInc)
Arguments:
	[in]	snapInc = double


Sets the snap increment. The snap increment is specified in degrees. Manipulator values will snap to the next rotation at an angle of snapInc from the original rotation. Note that snap rotate does not apply to the trackball rotations (when dragging between the rotate discs).'''
        pass

    def setInitialRotation(self, rotation): 
        '''setInitialRotation(self, rotation)
Arguments:
	[in]	rotation = MEulerRotation


Sets the initial rotation for the rotate manipulator. Setting the initial rotation will prevent the manipulator from jumping back to the default rotation when there is already an existing rotation on the target plug.'''
        pass

    def setRotateMode(self, mode): 
        '''setRotateMode(self, mode)
Arguments:
	[in]	mode = MFnRotateManip.RotateMode


Sets the mode for the rotation manipulator. The manipulator mode controls the appearance of the manipulator when is it used.'''
        pass

    def connectToRotationPlug(self, rotationPlug): 
        '''connectToRotationPlug(self, rotationPlug)
Arguments:
	[in]	rotationPlug = MPlug


Create a 1-1 connection from the rotation manipVal to the rotationPlug parameter. Any changes to the rotation manipVal will be immediately reflected in the connected plug. Connecting to the "rotation" plug on a transform node will produce similar behavior to the built-in rotate manipulator.'''
        pass

    def rotationIndex(self): 
        '''rotationIndex(self) -> int
Returns: Rotation index


Returns the index of the rotation manipVal for the manipulator. When plugToManip conversion functions are used to produce the rotation manipVal, the manipulator data must be of the type  MFnNumericData::k3Double , with X,Y, and Z rotations given in radians. This is easily accomplished by using the  MEulerRotation  class to manage the rotations.'''
        pass

    def rotationCenterIndex(self): 
        '''rotationCenterIndex(self) -> int
Returns: Rotation center index


Returns the index of the rotation center for the manipulator.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def displayWithNode(self, node): 
        '''displayWithNode(self, node)
Arguments:
	[in]	node = MObject


Configures the manipulator to display with the node, causing the position of the manipulator to follow the position of the node whenever the node is moved. The node must be a DAG object.'''
        pass

    def isSnapModeOn(self): 
        '''isSnapModeOn(self) -> bool


Returns true when snap mode is on.'''
        pass

class MFnScaleManip:
    '''ScaleManip function set. This class provides access to the built-in Maya scale manipulator. The manipulator consists of three constrained-axis scale handles for non-proportional scaling, and a central handle for proportional scaling.The manipulator provides data to the plugin through the scale manipVal. The scale value is a vector consisting of X, Y, and Z scale values. Each scale value represents a factor controlling how much an object should be extended along that dimension. The scale values are absolute and the initial scale value has a default of <1.0,1.0,1.0>.The manipulator can be configured either to display with an object (which must be a DAG node) or to display at an arbitrary point using the scaleCenter manipVal. '''
    def __init__(self):
        pass


    def connectToScaleCenterPlug(self, scaleCenterPlug): 
        '''connectToScaleCenterPlug(self, scaleCenterPlug)
Arguments:
	[in]	scaleCenterPlug = MPlug


Create a 1-1 association of the scale center on the manipulator and the scaleCenterPlug parameter. When both the scale center is attached to a plug and the  displayWithNode()  method has been called, the manipulator will display with the node regardless of the connection made to the scale center.'''
        pass

    def create(self, manipName, scaleName): 
        '''create(self, manipName, scaleName) -> MObject
Returns: An object corresponding to the new manipulator

Arguments:
	[in]	manipName = MString
	[in]	scaleName = MString


Creates a new ScaleManip, and attaches this function set to the new manipulator.'''
        pass

    def snapIncrement(self): 
        '''snapIncrement(self) -> double


Returns the snapping increment in working units.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def isSnapModeOn(self): 
        '''isSnapModeOn(self) -> bool


Returns true when snap mode is on.'''
        pass

    def setSnapIncrement(self, snapInc): 
        '''setSnapIncrement(self, snapInc)
Arguments:
	[in]	snapInc = double


Sets the snap increment. The snap increment is specified in the working unit, and is the distance between snap points when dragging the scale handles.'''
        pass

    def setInitialScale(self, scale): 
        '''setInitialScale(self, scale)
Arguments:
	[in]	scale = MVector


Sets the initial scale for the scale manipulator. Setting the initial scale will prevent the manipulator from jumping back to the default scale when there is already an existing scale on the target plug.'''
        pass

    def setSnapMode(self, snapEnabled): 
        '''setSnapMode(self, snapEnabled)
Arguments:
	[in]	snapEnabled = bool


Sets the snap mode. The snap modes can be either on (true) or off (false). When snap mode is on, scale values will snap to scale value within some interval apart. The interval is set using  setSnapIncrement() .'''
        pass

    def scaleIndex(self): 
        '''scaleIndex(self) -> int
Returns: Scale index


Returns the index of the scale manipVal for this manipulator.'''
        pass

    def connectToScalePlug(self, scalePlug): 
        '''connectToScalePlug(self, scalePlug)
Arguments:
	[in]	scalePlug = MPlug


Create a 1-1 connection from the scale manipVal to the scalePlug parameter. Any changes to the scale manipVal will be immediately reflected in the connected plug. Connecting to the "scale" plug on a transform node will produce similar behavior to the built-in scale manipulator.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def displayWithNode(self, node): 
        '''displayWithNode(self, node)
Arguments:
	[in]	node = MObject


Configures the manipulator to display with the node, causing the position of the manipulator to follow the position of the node whenever the node is moved. The node must be a DAG object.'''
        pass

    def scaleCenterIndex(self): 
        '''scaleCenterIndex(self) -> int
Returns: Scale center index


Returns the index of the scale center manipVal for this manipulator.'''
        pass

class MFnStateManip:
    '''StateManip function set. The StateManip allows the user to switch between multiple states. It is drawn as a circle with a notch. Each click on the circle increments the value of the state (modulo the maximum number of states). This manipulator generates an integer value corresponding to the state of the manip. '''
    def __init__(self):
        pass


    def setMaxStates(self, numStates): 
        '''setMaxStates(self, numStates)
Arguments:
	[in]	numStates = int


Sets the maximum number of states that the StateManip will have. The default number of maximum states is 4.'''
        pass

    def create(self, manipName, stateName): 
        '''create(self, manipName, stateName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	stateName = MString


Creates a new StateManip. This function set's object is set to be the new manipulator.'''
        pass

    def setInitialState(self, initialState): 
        '''setInitialState(self, initialState)
Arguments:
	[in]	initialState = int


Sets the initial state of the StateManip.'''
        pass

    def state(self): 
        '''state(self) -> int
Returns: Current states


Returns the current state.'''
        pass

    def positionIndex(self): 
        '''positionIndex(self) -> int
Returns: Position index


Returns the index of the position of the StateManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def connectToStatePlug(self, statePlug): 
        '''connectToStatePlug(self, statePlug)
Arguments:
	[in]	statePlug = MPlug


Connect to the state plug. The data type corresponding to the statePlug is a int integer.'''
        pass

    def stateIndex(self): 
        '''stateIndex(self) -> int
Returns: State index


Returns the index of the state. The data type corresponding to this index is a int integer.'''
        pass

    def maxStates(self): 
        '''maxStates(self) -> int
Returns: Maximum states


Returns the number of maximum states.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnToggleManip:
    '''ToggleManip function set. The ToggleManip allows the user to switch between two modes or some on/off state. It is drawn as a circle with or without a dot. When the mode is on, the dot is drawn in the circle; when the mode is off, the circle is drawn without the dot. This manipulator generates a boolean value corresponding to whether or not the mode is on or off. '''
    def __init__(self):
        pass


    def direction(self): 
        '''direction(self) -> MVector
Returns: The direction


Returns the direction.'''
        pass

    def setToggle(self, toggle): 
        '''setToggle(self, toggle)
Arguments:
	[in]	toggle = bool


Sets the toggle of the ToggleManip.'''
        pass

    def connectToTogglePlug(self, togglePlug): 
        '''connectToTogglePlug(self, togglePlug)
Arguments:
	[in]	togglePlug = MPlug


Connect to the toggle plug. The data type corresponding to the togglePlug is a boolean value.'''
        pass

    def setDirection(self, direction): 
        '''setDirection(self, direction)
Arguments:
	[in]	direction = MVector


Sets the direction of the ToggleManip.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def create(self, manipName, toggleName): 
        '''create(self, manipName, toggleName) -> MObject

Arguments:
	[in]	manipName = MString
	[in]	toggleName = MString


Creates a new ToggleManip. This function set's object is set to be the new manipulator.'''
        pass

    def toggle(self): 
        '''toggle(self) -> bool
Returns: Toggle


Returns the toggle.'''
        pass

    def lengthIndex(self): 
        '''lengthIndex(self) -> int
Returns: Length index


Returns the index of the length of the ToggleManip. The data type corresponding to this index is a double.'''
        pass

    def startPointIndex(self): 
        '''startPointIndex(self) -> int
Returns: Start point index


Returns the index of the start point of the ToggleManip. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def toggleIndex(self): 
        '''toggleIndex(self) -> int
Returns: Toggle index


Returns the index of the toggle of the ToggleManip. The data type corresponding to this index is a boolean.'''
        pass

    def length(self): 
        '''length(self) -> double
Returns: Length


Returns the length.'''
        pass

    def directionIndex(self): 
        '''directionIndex(self) -> int
Returns: Direction index


Returns the index of the direction. The data type corresponding to this index is  MFnNumericData::k3Double .'''
        pass

    def setStartPoint(self, startPoint): 
        '''setStartPoint(self, startPoint)
Arguments:
	[in]	startPoint = MPoint


Sets the start point of the ToggleManip.'''
        pass

    def startPoint(self): 
        '''startPoint(self) -> MPoint
Returns: The start point


Returns the start point.'''
        pass

    def setLength(self, length): 
        '''setLength(self, length)
Arguments:
	[in]	length = double


Sets the length of the ToggleManip.'''
        pass

class MHWShaderSwatchGenerator:
    '''Hardware shader swatch generator utility class. Derived from the MSwatchRenderBase class as a utility for generating a swatch for a plugin hardware shader class. This class supports hardware shaders derived from both MPxHardwareShader and the older MPxHwShaderNode base classes. '''
    def __init__(self):
        pass


    def MString(self): 
        '''MString(self) -> const


This method sets a swatch name, and registers a new swatch generator creation function for the swatch name. The string returned from this method can be used for node classification purpose. 
  Reprocessed example  
 Examples: 
 
   
 AshliPluginMain.cpp ,  hwColorPerVertexShader.cpp ,  hwPhongShader.cpp , and  pluginMain.cpp . 
 
'''
        pass

    def createObj(self, obj, renderObj, resolution): 
        '''createObj(self, obj, renderObj, resolution) -> MSwatchRenderBase

Arguments:
	[in]	obj = MObject
	[in]	renderObj = MObject
	[in]	resolution = int


Class constructor. Saves the Node object and image resolution as data members for future use.'''
        pass

    def doIteration(self): 
        '''doIteration(self) -> bool

'''
        pass

    def getSwatchBackgroundColor(self, r, g, b, a): 
        '''getSwatchBackgroundColor(self, r, g, b, a)
Arguments:
	[out]	r = float
	[out]	g = float
	[out]	b = float
	[out]	a = float


This method returns the default background color for the hardware rendered swatch.'''
        pass

class MManipData:
    '''Manipulator Data. This class encapulates manipulator data which is returned from the manipulator conversion functions. MManipData is used to represent data that is either simple or complex. Simple data is used to represent bool, short, int, unsigned int, float, and double types. Complex data is used to represent MObjects created by MFnData, or classes derived from MFnData. '''
    def __init__(self):
        pass


    def asMObject(self): 
        '''asMObject(self) -> MObject


Returns the manipulator data as an  MObject . The MObjects returned from this method are created and used by  MFnData  or classes derived from  MFnData .'''
        pass

    def asBool(self): 
        '''asBool(self) -> bool


Returns the manipulator data as a bool.'''
        pass

    def isSimple(self): 
        '''isSimple(self) -> bool


Returns whether or not the manipulator data is simple or complex. Simple data is used to represent bool, short, int, unsigned int, float, and double types. Complex data is used to represent MObjects created by  MFnData , or classes derived from  MFnData .'''
        pass

    def asShort(self): 
        '''asShort(self) -> short


Returns the manipulator data as a short.'''
        pass

    def asDouble(self): 
        '''asDouble(self) -> double


Returns the manipulator data as a double.'''
        pass

    def asFloat(self): 
        '''asFloat(self) -> float


Returns the manipulator data as a float.'''
        pass

    def asLong(self): 
        '''asLong(self) -> int


Returns the manipulator data as a int'''
        pass

    def asUnsigned(self): 
        '''asUnsigned(self) -> int


Returns the manipulator data as an unsigned int.'''
        pass

class MMaterial:
    '''Hardware shading material class used in MPxSurfaceShapeUI. This class is used in the draw functions of user defined shapes (see MPxSurfaceShapeUI) for setting up and querying materials used in shaded mode drawing. '''
    def __init__(self):
        pass


    def getDiffuse(self, color): 
        '''getDiffuse(self, color)
Arguments:
	[out]	color = MColor


Get the GL diffuse color.'''
        pass

    def getTextureTransformation(self, scaleU, scaleV, translateU, translateV, rotate): 
        '''getTextureTransformation(self, scaleU, scaleV, translateU, translateV, rotate)
Arguments:
	[out]	scaleU = float
	[out]	scaleV = float
	[out]	translateU = float
	[out]	translateV = float
	[out]	rotate = float


Get the current textures transformation.'''
        pass

    def getShininess(self, value): 
        '''getShininess(self, value)
Arguments:
	[out]	value = float


Get the GL shininess.'''
        pass

    def setMaterial(self, path, hasTransparency): 
        '''setMaterial(self, path, hasTransparency)
Arguments:
	[in]	path = MDagPath
	[in]	hasTransparency = bool


Set the current GL material.'''
        pass

    def getHasTransparency(self, value): 
        '''getHasTransparency(self, value)
Arguments:
	[out]	value = bool


Get flag to determine if material or texture has transparency.'''
        pass

    def evaluateTextureTransformation(self): 
        '''evaluateTextureTransformation(self)

Perform necessary evaluation to be able to get the texture transformation information back.'''
        pass

    def getSpecular(self, color): 
        '''getSpecular(self, color)
Arguments:
	[out]	color = MColor


Get the GL specular color.'''
        pass

    def textureImage(self, image, color, chan, mapped, dagPath, xRes, yRes): 
        '''textureImage(self, image, color, chan, mapped, dagPath, xRes, yRes)
Arguments:
	[in]	image = MImage
	[in]	color = MColor
	[in]	chan = MMaterial.MtextureChannel
	[in]	mapped = bool
	[in]	dagPath = MDagPath
	[in]	xRes = int
	[in]	yRes = int


For materials that have texture, this method will attempt to retrieve the pixel map for a given mapped channel of that material. If the channel is not mapped than a status of failure will be returned.'''
        pass

    def materialIsTextured(self): 
        '''materialIsTextured(self) -> bool


Do we have a texture (evaluated or not).'''
        pass

    def getHwShaderNode(self): 
        '''getHwShaderNode(self) -> MPxHwShaderNode


Get the hardware shader node. If this material has a hardware shader, a pointer to it will be returned in hwShader. If there is no hardware shader, hwShader will be set to NULL.'''
        pass

    def getEmission(self, color): 
        '''getEmission(self, color)
Arguments:
	[out]	color = MColor


Get the GL emission color.'''
        pass

    def kRoughness(self):
        '''This is an enum of MtextureChannel.
Description: PhongE only.
Value: 7'''
        pass

    def kTransluscence(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 6'''
        pass

    def kWhiteness(self):
        '''This is an enum of MtextureChannel.
Description: PhongE only.
Value: 9'''
        pass

    def kBumpMap(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 4'''
        pass

    def kTransparency(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 1'''
        pass

    def kColor(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 0'''
        pass

    def kDiffuse(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 5'''
        pass

    def kSpecularRollOff(self):
        '''This is an enum of MtextureChannel.
Description: Blinn only.
Value: 12'''
        pass

    def kReflectedColor(self):
        '''This is an enum of MtextureChannel.
Description: Blinn and Phong(E) only.
Value: 15'''
        pass

    def kHighlightSize(self):
        '''This is an enum of MtextureChannel.
Description: PhongE only.
Value: 8'''
        pass

    def kCosinePower(self):
        '''This is an enum of MtextureChannel.
Description: Phong only.
Value: 10'''
        pass

    def kReflectivity(self):
        '''This is an enum of MtextureChannel.
Description: Blinn and Phong(E) only.
Value: 14'''
        pass

    def kSpecularColor(self):
        '''This is an enum of MtextureChannel.
Description: Blinn and Phong(E) only.
Value: 13'''
        pass

    def kAmbientColor(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 2'''
        pass

    def kEccentricity(self):
        '''This is an enum of MtextureChannel.
Description: Blinn only.
Value: 11'''
        pass

    def kIncandescence(self):
        '''This is an enum of MtextureChannel.
Description: 
Value: 3'''
        pass

    class MtextureChannel:
        '''Non-functional class.  Values for this enum:
        kRoughness
        kTransluscence
        kWhiteness
        kBumpMap
        kTransparency
        kColor
        kDiffuse
        kSpecularRollOff
        kReflectedColor
        kHighlightSize
        kCosinePower
        kReflectivity
        kSpecularColor
        kAmbientColor
        kEccentricity
        kIncandescence
'''
        def __init__(self):
            pass

    def evaluateMaterial(self, view, path): 
        '''evaluateMaterial(self, view, path)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath


Evaluate a material. Must be called before evaluating for getting any material properties.'''
        pass

    def evaluateSpecular(self): 
        '''evaluateSpecular(self)

Perform necessary evaluation to be able to get emission back.'''
        pass

    def applyTexture(self, view, data): 
        '''applyTexture(self, view, data)
Arguments:
	[in]	view = M3dView
	[in]	data = MDrawData


For materials that have texture, this method must be used before the OpenGL drawing to apply the texture to the current view. This method should be called from within your  MPxSurfaceShapeUI::draw  method.'''
        pass

    def evaluateTexture(self, data): 
        '''evaluateTexture(self, data)
Arguments:
	[in]	data = MDrawData


Do texture evaluation and set a flag to tell if the texture is transparent.'''
        pass

    def evaluateShininess(self): 
        '''evaluateShininess(self)

Perform necessary evaluation to be able to get shininess back.'''
        pass

    def evaluateEmission(self): 
        '''evaluateEmission(self)

Perform necessary evaluation to be able to get emission back.'''
        pass

    def evaluateDiffuse(self): 
        '''evaluateDiffuse(self)

Perform necessary evaluation to be able to get diffuse back.'''
        pass

class MProgressWindow:
    '''Create and manipulate progress windows. The MProgressWindow class manages a window containing a status message, a graphical progress gauge, and optionally a "Hit ESC to Cancel" label for interruptable operations.Only a single progress window may be displayed at any time. To reserve the use of the progress window, use the reserve() method in this class. Any methods that change the state of the progress window will fail unless the progress window has first been successfully reserved.The startProgress() and endProgress() functions show and hide the progress window. endProgress() also has the effect of unreserving the progress window, allowing it to be reserved for another use.The MEL command "progressWindow" provides equivalent functionality to this class. Attempting to manipulate a progress window that is in use by MEL will cause the methods in this class to fail. '''
    def __init__(self):
        pass


    def startProgress(self): 
        '''startProgress(self)

Displays the progress window on the screen.'''
        pass

    def progressMax(self): 
        '''progressMax(self) -> int
Returns: Maximum progress value. Returns -1 if query fails. 


Get the maximum progress value.'''
        pass

    def setInterruptable(self, value): 
        '''setInterruptable(self, value)
Arguments:
	[in]	value = bool


Sets whether the progress window is interruptable. An interruptable progress window can accept a signal from the user indicating that the operation should be cancelled.'''
        pass

    def setProgressMax(self, maxValue): 
        '''setProgressMax(self, maxValue)
Arguments:
	[in]	maxValue = int


Sets the maximum value for the progress. Any progress value greater then maxValue will be set to maxValue, with the progress bar displayed as full.'''
        pass

    def setProgressRange(self, minValue, maxValue): 
        '''setProgressRange(self, minValue, maxValue)
Arguments:
	[in]	minValue = int
	[in]	maxValue = int


Sets the range (minValue, maxValue) of the progress indicator. When the progress value is set through  setProgress()  or  advanceProgress() , it is checked against the minimum and maximum progress values. If the new progress value lies outside this range, it is clamped to a value in this range.'''
        pass

    def endProgress(self): 
        '''endProgress(self)

Destroys the progress window and removes it from the screen. This method also unreserves the progress window, making it available for future reservation.'''
        pass

    def setTitle(self, title): 
        '''setTitle(self, title)
Arguments:
	[in]	title = MString


Sets the title of the progress window.'''
        pass

    def title(self): 
        '''title(self) -> MString
Returns: Window title string. 


Get the window title.'''
        pass

    def isCancelled(self): 
        '''isCancelled(self) -> bool
Returns: true when user has tried to cancel progress. If the progress window is not interruptable, this method returns false. 


Determine whether the user has tried to cancel an interruptable progress window.'''
        pass

    def advanceProgress(self, amount): 
        '''advanceProgress(self, amount)
Arguments:
	[in]	amount = int


Increases the progress value by amount. If the resulting progress value is not between  progressMin()  and  progressMax()  inclusively, it is set to whichever of  progressMin()  or  progressMax()  is closest.'''
        pass

    def isInterruptable(self): 
        '''isInterruptable(self) -> bool
Returns: true when the progress window is interruptable 


Determine whether the progress window is interruptable.'''
        pass

    def setProgressStatus(self, progressStatus): 
        '''setProgressStatus(self, progressStatus)
Arguments:
	[in]	progressStatus = MString


Sets the progress status string. This string is shown above the progress bar and usually is of the form "Performing operation:  XXX " where  XXX  is a numerical indication of the amount completed.'''
        pass

    def progress(self): 
        '''progress(self) -> int
Returns: Progress value. Returns -1 if query fails. 


Get the progress value.'''
        pass

    def progressStatus(self): 
        '''progressStatus(self) -> MString
Returns: Progress status string. 


Get the progress status string.'''
        pass

    def setProgressMin(self, minValue): 
        '''setProgressMin(self, minValue)
Arguments:
	[in]	minValue = int


Sets the minimum value for the progress. Any progress value less then minValue will be set to minValue, with the progress bar displayed as empty.'''
        pass

    def setProgress(self, progress): 
        '''setProgress(self, progress)
Arguments:
	[in]	progress = int


Sets the progress value. If progress is not between  progressMin()  and  progressMax()  inclusively, it is set to whichever of  progressMin()  or  progressMax()  is closest.'''
        pass

    def progressMin(self): 
        '''progressMin(self) -> int
Returns: Minimum progress value. Returns -1 if query fails. 


Get the minimum progress value.'''
        pass

    def reserve(self): 
        '''reserve(self) -> bool


Reserves a progress window for use through this class. This method must be called before setting progress window parameters or starting progress.'''
        pass

class MSelectInfo:
    '''Selection state information used in MPxSurfaceShapeUI::select. MSelectInfo is used with user defined shape selection and is passed as an argument to the MPxSurfaceShapeUI::select method. This class encapsulates all the selection state information for selected objects. '''
    def __init__(self):
        pass


    def isRay(self): 
        '''isRay(self) -> bool


Is there a selection ray. This method isused to find ray object intersection.'''
        pass

    def selectClosest(self): 
        '''selectClosest(self) -> bool


Determines if we want to select the closest object.'''
        pass

    def selectableComponent(self, displayed, mask): 
        '''selectableComponent(self, displayed, mask) -> bool
Returns: true the component is selectable 
false the component not is selectable 

Arguments:
	[in]	displayed = bool
	[in]	mask = MSelectionMask


Given the selection mask, this method determines if the component is selectable.'''
        pass

    def getLocalRay(self, pnt, vec): 
        '''getLocalRay(self, pnt, vec)
Arguments:
	[out]	pnt = MPoint
	[out]	vec = MVector


Get the selection ray. This method isused to find ray object intersection.'''
        pass

    def highestPriority(self): 
        '''highestPriority(self) -> int


Returns the highest selection priority value.'''
        pass

    def selectPath(self): 
        '''selectPath(self) -> MDagPath


Returns a path to the item that is being selected.'''
        pass

    def addSelection(self, item, point, mask, isComponent, list, points): 
        '''addSelection(self, item, point, mask, isComponent, list, points)
Arguments:
	[in]	item = MSelectionList
	[in]	point = MPoint
	[out]	list = MSelectionList
	[out]	points = MPointArray
	[in]	mask = MSelectionMask
	[in]	isComponent = bool


Adds components or objects to the active selection list. For an example of how this is used please refer to the method definition apiMeshShapeUI::select() in the devkit example code apiMeshShape.cpp.'''
        pass

    def setHighestPriority(self, value): 
        '''setHighestPriority(self, value)
Arguments:
	[in]	value = int


Sets the highest selection priority value.'''
        pass

    def selectForHilite(self, mask): 
        '''selectForHilite(self, mask) -> bool
Returns: true can select for hilite 
false can't select for hilite 

Arguments:
	[in]	mask = MSelectionMask


Give the selection mask, can this object be selected for the hilite list.'''
        pass

    def singleSelection(self): 
        '''singleSelection(self) -> bool


This methods determines if we want to select a single object.'''
        pass

    def selectable(self, mask): 
        '''selectable(self, mask) -> bool
Returns: true the object is selectable 
false the object not is selectable 

Arguments:
	[in]	mask = MSelectionMask


Given the selection mask, this method determines if the object is selectable.'''
        pass

    def selectOnHilitedOnly(self): 
        '''selectOnHilitedOnly(self) -> bool


This means that you can only select components if the object is hilited.'''
        pass

    def getAlignmentMatrix(self): 
        '''getAlignmentMatrix(self) -> MMatrix


Returns the alignment matrix. This method is used to find ray object intersection.'''
        pass

    def view(self): 
        '''view(self) -> M3dView


Returns the view that the current selection is taking place in.'''
        pass

class MTextureEditorDrawInfo:
    '''Drawing state for drawing to the UV texture window with custom shapes. This class is used by drawUV method of MPxSurfaceShapeUI to specify the current UV drawing state for a user defined shape. API users must override the canDrawUV method on MPxSurfaceShapeUI to recieve drawUV calls. The only situation where the drawing style can change is during a selection event. However, selection events are currently not passed onto the API user. Therefore, most of the functionality in this class is place holder for future work.'''
    def __init__(self):
        pass


    def kDrawVertexForSelect(self):
        '''This is an enum of DrawingFunction.
Description: Draw vertices for selection.
Value: 3'''
        pass

    def kDrawFunctionLast(self):
        '''This is an enum of DrawingFunction.
Description: Highest possible enum value.
Value: 6'''
        pass

    def kDrawWireframe(self):
        '''This is an enum of DrawingFunction.
Description: Draw wireframe only (default).
Value: 1'''
        pass

    def kDrawFacetForSelect(self):
        '''This is an enum of DrawingFunction.
Description: Draw faces for selection.
Value: 5'''
        pass

    def kDrawEdgeForSelect(self):
        '''This is an enum of DrawingFunction.
Description: Draw edges for selection.
Value: 4'''
        pass

    def kDrawEverything(self):
        '''This is an enum of DrawingFunction.
Description: Draw vertices, uvs, faces, and edges.
Value: 2'''
        pass

    def kDrawFunctionFirst(self):
        '''This is an enum of DrawingFunction.
Description: Lowest possible enum value.
Value: 1'''
        pass

    def kDrawUVForSelect(self):
        '''This is an enum of DrawingFunction.
Description: Draw uvs for selection.
Value: 6'''
        pass

    class DrawingFunction:
        '''Non-functional class.  Values for this enum:
        kDrawVertexForSelect
        kDrawFunctionLast
        kDrawWireframe
        kDrawFacetForSelect
        kDrawEdgeForSelect
        kDrawEverything
        kDrawFunctionFirst
        kDrawUVForSelect
'''
        def __init__(self):
            pass

    def setDrawingFunction(self, func): 
        '''setDrawingFunction(self, func)
Arguments:
	[in]	func = MTextureEditorDrawInfo.DrawingFunction


Sets the current drawing state. Currently the API user is unable to set these values. All drawing state values are determined internally and passed onto the API programmer.'''
        pass

    def drawingFunction(self): 
        '''drawingFunction(self) -> MTextureEditorDrawInfo.DrawingFunction


Indicates the current drawing state for a drawUV method call.'''
        pass

class MToolsInfo:
    '''Tool information. MToolsInfo is a caretaker class used to keep track of the state of the current tool property sheet. The tool writer should make sure to call the setDirtyFlag method when any of the values are modified. The dirty flag is used to indicate that the UI needs to be updated when the value of a tool property sheet option has changed. '''
    def __init__(self):
        pass


    def setDirtyFlag(self, context): 
        '''setDirtyFlag(self, context)
Arguments:
	[in]	context = MPxContext


This method should be called by a tool when the value of a tool property sheet option has changed. The dirty flag will only be set if this is the current tool.'''
        pass

    def resetDirtyFlag(self): 
        '''resetDirtyFlag(self)
'''
        pass

    def isDirty(self): 
        '''isDirty(self) -> bool


This method returns whether or not the dirty flag is set.'''
        pass

class MUiMessage:
    '''UI messages. This class is used to register callbacks to track the deletion of UI objects.The first parameter passed to the add callback method is the name of the UI that will trigger the callback.The method returns an id which is used to remove the callback.To remove a callback use MMessage::removeCallback.All callbacks that are registered by a plug-in must be removed by that plug-in when it is unloaded. Failure to do so will result in a fatal error. '''
    def __init__(self):
        pass


    def addCameraChangedCallback(self, panelName, func, clientData): 
        '''addCameraChangedCallback(self, panelName, func, clientData) -> MCallbackId

Arguments:
	[in]	panelName = MString
	[in]	func = MMessage.MStringNode
	[in]	clientData = void


This method registers a callback for cameras being changed in 3d views. The callback is called when the camera changes for the given panel, not when attributes on the panel's camera change.'''
        pass

    def add3dViewPostRenderMsgCallback(self, panelName, func, clientData): 
        '''add3dViewPostRenderMsgCallback(self, panelName, func, clientData) -> MCallbackId

Arguments:
	[in]	panelName = MString
	[in]	func = MUiMessage.MStringFunction
	[in]	clientData = void


This method registers a callback for when the 3d view is about to display it's rendered contents to the viewport. It is called for every refresh of the view, after the scene is drawn, but before any 2d adornments are drawn.'''
        pass

    def add3dViewDestroyMsgCallback(self, panelName, func, clientData): 
        '''add3dViewDestroyMsgCallback(self, panelName, func, clientData) -> MCallbackId

Arguments:
	[in]	panelName = MString
	[in]	func = MUiMessage.MStringFunction
	[in]	clientData = void


This method registers a callback for when a particular 3d view gets destroyed. The callback is called before the destruction of the view.'''
        pass

    def add3dViewPreRenderMsgCallback(self, panelName, func, clientData): 
        '''add3dViewPreRenderMsgCallback(self, panelName, func, clientData) -> MCallbackId

Arguments:
	[in]	panelName = MString
	[in]	func = MUiMessage.MStringFunction
	[in]	clientData = void


This method registers a callback for when a particular 3d view is about to render it's contents. It is called before the scene is drawn, but after the background has been drawn.'''
        pass

    def addUiDeletedCallback(self, uiName, func, clientData): 
        '''addUiDeletedCallback(self, uiName, func, clientData) -> MCallbackId

Arguments:
	[in]	uiName = MString
	[in]	func = MMessage.MBasicFunction
	[in]	clientData = void


This method registers a callback for UI deleted messages.'''
        pass

