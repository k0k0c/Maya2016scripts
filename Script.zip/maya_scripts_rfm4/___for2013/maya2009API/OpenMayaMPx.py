
'''
Stub class file for:
OpenMayaMPx

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class MPx3dModelView:
    '''3d Model View MPx3dModelView is the class for user defined model views. The MPx3dModelView class works with the MPxModelEditorCommand class to create a user defined model editor that may be used in a window or in a scripted panel. When registering the model editor with the MFnPlugin::registerModelEditorCommand() method, an appropriate MPx3dModelView::creator() method is required. This class works for interactive Maya views and is not designed for rendering.One of the interesting uses of a MPx3dModelView is that it allows multiple cameras to be drawn into the same window. Like a normal model view, this view has a main camera associated with it. This camera is obtained with the getCamera() method and is the camera used for manipulations and selection.To setup a multiple camera draw, first the number of passes must be set by an overloaded multipleDrawPassCount() method. The preMultipleDraw() method allows any setup to be performed. The preMultipleDrawPass(unsigned int) is called for each pass, with the argument indicating which pass is currently being used. The camera for the specific pass may be set with the setCameraInDraw() method. The postMultipleDrawPass(unsigned int) method is called after the drawing for the indicated pass is complete. Finally any cleanup may be done with the postMultipleDraw() method.During the drawing, a filter exists to determine which items should be drawn. The okForMultipleDraw(MdagPath &) allows filtering of what should be drawn. Another approach which is faster is to tuen on the view selected mode (setViewSelected()) and use the setObjectsToView() or viewSelectedSet() to specify which items should be drawn. These values may be set per pass so that each camera has control over what gets drawn. '''
    def __init__(self):
        pass


    def setColorIndexMode(self, colorIndexOn): 
        '''setColorIndexMode(self, colorIndexOn)
Arguments:
	[in]	colorIndexOn = bool


Sets color index mode - swaps buffers!'''
        pass

    def objectDisplay(self, dispObjs): 
        '''objectDisplay(self, dispObjs) -> bool

Arguments:
	[in]	dispObjs = M3dView.DisplayObjects


Returns true is the passed flag is set.'''
        pass

    def preMultipleDraw(self): 
        '''preMultipleDraw(self)

This method is called before any drawing is performed in the model view. It should control any setting required for every pass that will be drawn. 
  Reprocessed example  
 Examples: 
 
   
 narrowPolyViewer.h . 
 
'''
        pass

    def setDrawAdornments(self, display): 
        '''setDrawAdornments(self, display)
Arguments:
	[in]	display = bool


Toggles the control of how adornments are drawn in the view. Adornments are objects that are drawn in the viewport that are not scene entities. This includes the origin axis and the camera decorations like film gate and resolution gate. These items are usually drawn last and outside of the multiple refresh loop. You can choose to disable the drawing of the adornments by specifying false here, and you can control the drawing of the feature within their display loop calling displayAdornmentsNow() method on this class. By default this flag is true; so adornments are always drawn unless explicitly disabled by you.'''
        pass

    def postMultipleDrawPass(self, index): 
        '''postMultipleDrawPass(self, index)
Arguments:
	[in]	index = int


This method is called when a specified pass is finshed.'''
        pass

    def drawText(self, text, position, textPosition): 
        '''drawText(self, text, position, textPosition)
Arguments:
	[in]	text = MString
	[in]	position = MPoint
	[in]	textPosition = M3dView.TextPosition


Draws the given text at the given spot in the default font. This method is provided as a convienient way to draw OpenGL text.'''
        pass

    def clearOverlayPlane(self): 
        '''clearOverlayPlane(self)

Clear the overlay plane.'''
        pass

    def updateViewingParameters(self): 
        '''updateViewingParameters(self)

This method tells the camera to set the view's transformation matrix.'''
        pass

    def setUserDefinedColor(self, index, color): 
        '''setUserDefinedColor(self, index, color)
Arguments:
	[in]	index = int
	[in]	color = MColor


Sets the user defined color at the given index. Valid indices range between zero and the number of user defined colors.'''
        pass

    def beginGL(self): 
        '''beginGL(self)

Setup port for native OpenGL drawing calls. Only make openGL calls between the  beginGL()  and  endGL()  methods.  M3dView  and  MPx3dModelView  calls should not be made betwen  beginGL()  and  endGL()  calls.'''
        pass

    def setFogEnabled(self, state): 
        '''setFogEnabled(self, state)
Arguments:
	[in]	state = bool


Enables and disables fog. If fog is enabled for one pass and disabled for another, the background fog will not be drawn. To display background fog in that configuration, use the  MPx3dModelView::setBackgroundFogEnabled()  call.'''
        pass

    def viewSelectedPrefix(self): 
        '''viewSelectedPrefix(self) -> MString
Returns: The prefix.


Returns the prefix used when displaying the camera name in the heads up display when view selected in on.'''
        pass

    def setTextureDisplayEnabled(self, textureDisplay): 
        '''setTextureDisplayEnabled(self, textureDisplay)
Arguments:
	[in]	textureDisplay = bool


Enables texture display'''
        pass

    def getColorIndexAndTable(self, glindex, index, table): 
        '''getColorIndexAndTable(self, glindex, index, table)
Arguments:
	[in]	glindex = int
	[out]	index = int
	[out]	table = M3dView.ColorTable


Returns the color table and index representing the given OpenGL color-index value. This method is useful when converting color indices obtained from glReadPixels(GL_COLOR_INDEX) to Maya color-index values suitable for use with the colorAtIndex and setDrawColor methods.'''
        pass

    def isShadeActiveOnly(self): 
        '''isShadeActiveOnly(self) -> bool
Returns: true Only active objects are shaded if this view is in shaded mode 
false All objects are shaded if this view is in shaded mode


Returns  true  if this view's display style is shaded for objects that are active and wireframe otherwise.'''
        pass

    def isTwoSidedLighting(self): 
        '''isTwoSidedLighting(self) -> bool
Returns: true if two sided lighting is enabled.


Returns the state of two sided lighting.'''
        pass

    def fogColor(self): 
        '''fogColor(self) -> MColor
Returns: The fog color.


Returns the fog color.'''
        pass

    def setBackfaceCulling(self, culling): 
        '''setBackfaceCulling(self, culling)
Arguments:
	[in]	culling = bool


Sets backface culling.'''
        pass

    def name(self): 
        '''name(self) -> MString
Returns: The name of the view.


Returns the name of the view.'''
        pass

    def isBackgroundFogEnabled(self): 
        '''isBackgroundFogEnabled(self) -> bool
Returns: true, if the background fog is enabled, otherwise false.


Returns true if the background fog is enabled.'''
        pass

    def viewSelectedSet(self): 
        '''viewSelectedSet(self) -> MObject
Returns: The MObject


Returns an  MObject  for the set used by view selected. If there is not a set associated with this view, then an invalid  MObject  will be returned. Check the isNull() method of the  MObject  to see if a valid set was found.'''
        pass

    def setLightingMode(self, lightingMode): 
        '''setLightingMode(self, lightingMode)
Arguments:
	[in]	lightingMode = MPx3dModelView.LightingMode


Sets the lighting mode.'''
        pass

    def refresh(self, all, force): 
        '''refresh(self, all, force)
Arguments:
	[in]	all = bool
	[in]	force = bool


Refresh the this view. If  all  is set to  true  then all of the 3d-view will be refreshed.'''
        pass

    def multipleDrawPassCount(self): 
        '''multipleDrawPassCount(self) -> int


This method returns the number of multiple draw passes that are going to be made. By default a 1 is returned.'''
        pass

    def viewToObjectSpace(self, x_pos, y_pos, localMatrixInverse, oPt, oVector): 
        '''viewToObjectSpace(self, x_pos, y_pos, localMatrixInverse, oPt, oVector)
Arguments:
	[in]	x_pos = short
	[in]	y_pos = short
	[in]	localMatrixInverse = MMatrix
	[out]	oPt = MPoint
	[out]	oVector = MVector


Takes a point in port coordinates and returns a corresponding ray in object coordinates.'''
        pass

    def preMultipleDrawPass(self, index): 
        '''preMultipleDrawPass(self, index)
Arguments:
	[in]	index = int


This method is called immediately before a specific pass is about to be drawn. The unsigned int argument indictates which pass is about to be drawn.'''
        pass

    def setDisplayStyle(self, style, activeOnly): 
        '''setDisplayStyle(self, style, activeOnly)
Arguments:
	[in]	style = M3dView.DisplayStyle
	[in]	activeOnly = bool


Sets the display style for this view. The display style can be wireframe, flat-shaded, or smooth-shaded.'''
        pass

    def setFogColor(self, color): 
        '''setFogColor(self, color)
Arguments:
	[in]	color = MColor


Sets the color used for hardware fogging.'''
        pass

    def displayCameraAnnotationOn(self): 
        '''displayCameraAnnotationOn(self) -> bool
Returns: true if the camera annotation is displayed.


Returns the camera annotation display state for this  MPx3dModelView .'''
        pass

    def setFogEnd(self, end): 
        '''setFogEnd(self, end)
Arguments:
	[in]	end = double


Determines the end location of hardware fogging. This is meaniful for kFogLinear drop off type (set by the  MPx3dModelView::setFogMode()  method).'''
        pass

    def beginOverlayDrawing(self): 
        '''beginOverlayDrawing(self)

Setup the OpenGL context for drawing on the overlay plane.'''
        pass

    def setInStereoDrawMode(self, flag): 
        '''setInStereoDrawMode(self, flag)
Arguments:
	[in]	flag = bool


Derived classes should call this method to indicate to Maya whether the view is currently drawing in stereo.'''
        pass

    def setDrawColor(self, color): 
        '''setDrawColor(self, color)
Arguments:
	[in]	color = MColor


Set the color to draw in. This method should only be used in RGBA mode. It is a convenient replacement for glColor.'''
        pass

    def kLightSelected(self):
        '''This is an enum of LightingMode.
Description: Selected lights only.
Value: 1'''
        pass

    def kLightNone(self):
        '''This is an enum of LightingMode.
Description: Use no lights.
Value: 4'''
        pass

    def kLightActive(self):
        '''This is an enum of LightingMode.
Description: Active lights only.
Value: 2'''
        pass

    def kLightAll(self):
        '''This is an enum of LightingMode.
Description: Use all lights.
Value: 0'''
        pass

    def kLightDefault(self):
        '''This is an enum of LightingMode.
Description: Default light only.
Value: 3'''
        pass

    def kLightQuality(self):
        '''This is an enum of LightingMode.
Description: Use per pixel lighting.
Value: 5'''
        pass

    class LightingMode:
        '''Non-functional class.  Values for this enum:
        kLightSelected
        kLightNone
        kLightActive
        kLightAll
        kLightDefault
        kLightQuality
'''
        def __init__(self):
            pass

    def multipleDrawEnabled(self): 
        '''multipleDrawEnabled(self) -> bool


This method returns the multiple draw enable state for this view.'''
        pass

    def displayAxisAtOriginOn(self): 
        '''displayAxisAtOriginOn(self) -> bool
Returns: true if the origin axis is displayed.


Returns the origin axis display state for this  MPx3dModelView .'''
        pass

    def getCameraHUDName(self): 
        '''getCameraHUDName(self) -> MString


Return the name to use for the camera in the heads up display.'''
        pass

    def setFogMode(self, mode): 
        '''setFogMode(self, mode)
Arguments:
	[in]	mode = MPx3dModelView.FogMode


Sets the drop-off mode for fog. The possibilities are:'''
        pass

    def viewSelected(self): 
        '''viewSelected(self) -> bool
Returns: true if view selected is enabled.


Returns the state of view selected for this view.'''
        pass

    def fogSource(self): 
        '''fogSource(self) -> MPx3dModelView.FogSource
Returns: The algorithm used to compute fog.


Returns the algorithm used to compute fog. See  MPx3dModelView::setFogSource  for a description.'''
        pass

    def getModelView(self, name): 
        '''getModelView(self, name) -> MPx3dModelView
Returns: A pointer to the MPx3dModelView.

Arguments:
	[in]	name = MString


Returns a pointer to a  MPx3dModelView  that has the passed name with the specified type (the same typed when registering the control). If one does not exist, then a NULL pointer is returned.'''
        pass

    def destroyOnPanelDestruction(self): 
        '''destroyOnPanelDestruction(self) -> bool


This method queries the destruction setting for this  MPx3dModelView  which is employed when the panel associated with this view is destroyed.'''
        pass

    def backgroundColor(self): 
        '''backgroundColor(self) -> MColor
Returns: The template color


Returns the RGB values of the active template color.'''
        pass

    def colorAtIndex(self, index, table): 
        '''colorAtIndex(self, index, table) -> MColor
Returns: The color

Arguments:
	[in]	index = int
	[in]	table = M3dView.ColorTable


Returns the RGB values of the color at the given index in the application's color table.'''
        pass

    def isTextureDisplayEnabled(self): 
        '''isTextureDisplayEnabled(self) -> bool
Returns: true if texture display is enabled.


Returns the enable state of texture display.'''
        pass

    def setBackgroundFogEnabled(self, state): 
        '''setBackgroundFogEnabled(self, state)
Arguments:
	[in]	state = bool


Enables and disables background fog.'''
        pass

    def setDoUpdateOnMove(self, value): 
        '''setDoUpdateOnMove(self, value)
Arguments:
	[in]	value = bool


Some viewports require a refresh when the user has moved the top level window. This flag enables this custom view to trigger a refresh event when the top level window of the view is moved to a new location.'''
        pass

    def wantStereoGLBuffer(self): 
        '''wantStereoGLBuffer(self) -> bool


Users should override this method if they want a stereo buffer enabled  MPx3dModelView . You must have a graphics card that can support stereo mode. If your graphics card does not support stereo mode, a non-stereo buffer is created.'''
        pass

    def templateColor(self): 
        '''templateColor(self) -> MColor
Returns: The template color


Returns the RGB values of the template color.'''
        pass

    def setFogStart(self, start): 
        '''setFogStart(self, start)
Arguments:
	[in]	start = double


Determines the start location of hardware fogging. This is meaniful for kFogLinear drop off type (set by the  MPx3dModelView::setFogMode()  method).'''
        pass

    def endOverlayDrawing(self): 
        '''endOverlayDrawing(self)

Set the OpenGL context to for normal screen drawing.'''
        pass

    def kFogLinear(self):
        '''This is an enum of FogMode.
Description: Linear drop off.
Value: 0'''
        pass

    def kFogExponential(self):
        '''This is an enum of FogMode.
Description: Exponential drop-off.
Value: 1'''
        pass

    def kFogExponentialSquared(self):
        '''This is an enum of FogMode.
Description: Squared exponential drop-off.
Value: 2'''
        pass

    class FogMode:
        '''Non-functional class.  Values for this enum:
        kFogLinear
        kFogExponential
        kFogExponentialSquared
'''
        def __init__(self):
            pass

    def isVisible(self): 
        '''isVisible(self) -> bool
Returns: true if the view is visible, otherwise false is returned.


This method returns true if this view is visible, otherwise false is returned.'''
        pass

    def setObjectsToView(self, list): 
        '''setObjectsToView(self, list)
Arguments:
	[in]	list = MSelectionList


Sets the list of objects used by view selected as a selection list. View selected must be turned on for this to have an effect.'''
        pass

    def setMultipleDrawEnable(self, enable): 
        '''setMultipleDrawEnable(self, enable)
Arguments:
	[in]	enable = bool


This method turns enables/disables multiple camera drawing for this view. If multiple draw is disabled, then this view will behave like a normal Maya view.'''
        pass

    def fogMode(self): 
        '''fogMode(self) -> MPx3dModelView.FogMode
Returns: The type of drop off used with fog.


Return the type of drop off used with fog. See  MPx3dModelView::setFogMode  for description of the drop off types.'''
        pass

    def isXrayEnabled(self): 
        '''isXrayEnabled(self) -> bool
Returns: true if xray is enabled.


Returns the state of xray display.'''
        pass

    def userDefinedColorIndex(self, index): 
        '''userDefinedColorIndex(self, index) -> int
Returns: Index of user-defined color into the active and dormant tables

Arguments:
	[in]	index = int


Returns the index for the given user-defined color. Valid values for the index argument range between zero and the number of user-defined colors minus one.'''
        pass

    def removingCamera(self, cameraPath): 
        '''removingCamera(self, cameraPath)
Arguments:
	[in]	cameraPath = MDagPath


This method should be overloaded in  MPx3dModelView  derived classes. It will get called whenever a camera that was used with this  MPx3dModelView  is deleted. The  MPx3dModelView  should then remove any reference to the deleted camera.'''
        pass

    def isColorIndexMode(self): 
        '''isColorIndexMode(self) -> bool
Returns: Boolean indicating if color index mode is in use


Returns true if this view is currently in the OpenGL color index mode. A false return means that it is in RGBA mode.'''
        pass

    def displayAxisOn(self): 
        '''displayAxisOn(self) -> bool
Returns: true if the axis is displayed.


Returns the axis display state for this  MPx3dModelView .'''
        pass

    def drawAdornments(self): 
        '''drawAdornments(self) -> bool


Returns the state of the adornment drawing for this view. See setDrawAdornments for more information on adornment drawing.'''
        pass

    def displayStyle(self): 
        '''displayStyle(self) -> M3dView.DisplayStyle
Returns: The display style for this view


Return the display style for this 3d view. The display style can be wireframe, flat-shaded, or smooth-shaded.'''
        pass

    def endGL(self): 
        '''endGL(self)

End OpenGL drawing.'''
        pass

    def setViewSelectedSet(self, set): 
        '''setViewSelectedSet(self, set)
Arguments:
	[in]	set = MObject


Returns a set that contains the memebers used by view selected.'''
        pass

    def fogDensity(self): 
        '''fogDensity(self) -> double
Returns: The fog density.


Returns the fog density.'''
        pass

    def setCameraInDraw(self, camera): 
        '''setCameraInDraw(self, camera)
Arguments:
	[in]	camera = MDagPath


Sets the camera during a draw. If the normal  setCamera()  method is used, then that camera will not get its parameters loaded during the draw.'''
        pass

    def portWidth(self): 
        '''portWidth(self) -> int
Returns: The width of this viewport


Returns the width of the current viewport.'''
        pass

    def numUserDefinedColors(self): 
        '''numUserDefinedColors(self) -> int
Returns: The number of user defined colors


Returns the number of user defined colors in the internal application color table. These colors may be changed by the user and assigned to specific objects. See the methods of  MFnDagNode  for information on assigning user defined colors to individual objects.'''
        pass

    def postMultipleDraw(self): 
        '''postMultipleDraw(self)

This method is called after the drawing is finished. Any cleanup should be done by this method. 
  Reprocessed example  
 Examples: 
 
   
 narrowPolyViewer.h . 
 
'''
        pass

    def fogEnd(self): 
        '''fogEnd(self) -> double
Returns: The fog end location.


Returns the fog end position.'''
        pass

    def getObjectsToView(self, list): 
        '''getObjectsToView(self, list)
Arguments:
	[out]	list = MSelectionList


Returns a selection list containing all of the objects on the view selected list.'''
        pass

    def setDestroyOnPanelDestruction(self, how): 
        '''setDestroyOnPanelDestruction(self, how)
Arguments:
	[in]	how = bool


This method enables/disables destruction of the  MPx3dModelView  object when the panel is destroyed. By default, Maya does not destroy the  MPx3dModelView  when the panel is destroyed. Example cases of destroying a panel are when you tear off a panel, or close a torn-off panel.'''
        pass

    def setWireframeOnShaded(self, onShaded): 
        '''setWireframeOnShaded(self, onShaded)
Arguments:
	[in]	onShaded = bool


Displays as wireframe on shaded.'''
        pass

    def setFogDensity(self, density): 
        '''setFogDensity(self, density)
Arguments:
	[in]	density = double


Determines the density of hardware fogging. This is meaniful for kFogExponential and kFogExponentialSquared drop off types (set by the  MPx3dModelView::setFogMode()  method).'''
        pass

    def setObjectDisplay(self, displayType, display): 
        '''setObjectDisplay(self, displayType, display)
Arguments:
	[in]	displayType = M3dView.DisplayObjects
	[in]	display = bool


Sets the display option for various types of objects. By default everything is displayed.'''
        pass

    def isBackfaceCulling(self): 
        '''isBackfaceCulling(self) -> bool
Returns: true if backface culling is enabled.


Returns the state of backface culling.'''
        pass

    def portHeight(self): 
        '''portHeight(self) -> int
Returns: The height of this viewport


Returns the height of the current viewport.'''
        pass

    def setDisplayAxisAtOrigin(self, enable): 
        '''setDisplayAxisAtOrigin(self, enable)
Arguments:
	[in]	enable = bool


Sets the origin axis display in the  MPx3dModelView .'''
        pass

    def okForMultipleDraw(self, dp): 
        '''okForMultipleDraw(self, dp) -> bool
Returns: true if it is OK to draw the passed object. 

Arguments:
	[in]	dp = MDagPath


This method provides some filter capabilities as to what is drawn. When ever a draw operation during the multiple camera drawing, this method will get called. If true is returned, then the object will be drawn.'''
        pass

    def displayHUD(self): 
        '''displayHUD(self) -> bool
Returns: The enable state for the HUD


Returns the heads up display state for this view.'''
        pass

    def setDisplayAxis(self, enable): 
        '''setDisplayAxis(self, enable)
Arguments:
	[in]	enable = bool


Sets the axis display in the  MPx3dModelView .'''
        pass

    def isWireframeOnShaded(self): 
        '''isWireframeOnShaded(self) -> bool
Returns: true if backface onShaded is enabled.


Returns the state of wireframe on shaded.'''
        pass

    def drawHUDNow(self): 
        '''drawHUDNow(self)

Forces the HUD viewport elements to be drawn immediately. This should only be called when setDrawAdornments has been set to false. And this method should only be called in the postMultiple* draw methods. This allows the drawing of display elements during a specific pass while attached to a specific camera.'''
        pass

    def drawAdornmentsNow(self): 
        '''drawAdornmentsNow(self)

Forces the adornment viewport elements to be drawn immediately. This should only be called when setDrawAdornments has been set to false. And this method should only be called in the postMultiple* draw methods. This allows you to draw camera adornments during a specific pass while attached to a specific camera.'''
        pass

    def setViewSelected(self, enable): 
        '''setViewSelected(self, enable)
Arguments:
	[in]	enable = bool


Enables the view selected mode.'''
        pass

    def getAsM3dView(self, view): 
        '''getAsM3dView(self, view)
Arguments:
	[out]	view = M3dView


Get this  MPx3dModelView  as a  M3dView .'''
        pass

    def worldToView(self, worldPt, x_pos, y_pos): 
        '''worldToView(self, worldPt, x_pos, y_pos) -> bool
Returns: true point is not clipped 
false point is undefined or outside frustum

Arguments:
	[in]	worldPt = MPoint
	[out]	x_pos = short
	[out]	y_pos = short


converts a point in world space to port space. The return value indicates if the point is not clipped.'''
        pass

    def setCamera(self, camera): 
        '''setCamera(self, camera)
Arguments:
	[in]	camera = MDagPath


Set the camera for this view.'''
        pass

    def setXrayEnabled(self, xray): 
        '''setXrayEnabled(self, xray)
Arguments:
	[in]	xray = bool


Sets xray display state.'''
        pass

    def lightingMode(self): 
        '''lightingMode(self) -> MPx3dModelView.LightingMode
Returns: The lighting mode.


Returns the lighting mode.'''
        pass

    def setDisplayHUD(self, enable): 
        '''setDisplayHUD(self, enable)
Arguments:
	[in]	enable = bool


Enables or disables the drawing the heads up display in this view. This method only affects this view and will stop all heads up display elements from being drawn in this view.'''
        pass

    def fogStart(self): 
        '''fogStart(self) -> double
Returns: The fog start position.


Returns the fog start position.'''
        pass

    def viewToWorld(self, x_pos, y_pos, nearClipPt, farClipPt): 
        '''viewToWorld(self, x_pos, y_pos, nearClipPt, farClipPt)
Arguments:
	[in]	x_pos = short
	[in]	y_pos = short
	[out]	nearClipPt = MPoint
	[out]	farClipPt = MPoint


Takes a point in port coordinates and returns a point on the near and far clipping planes.'''
        pass

    def doUpdateOnMove(self): 
        '''doUpdateOnMove(self) -> bool
Returns: the state of the doUpdateOnMove flag


Returns the state of the doUpdateOnMove flag. This flag tells the refresh architecture if it is necessary to refresh your view when the user moves the control window for this viewport. If this flag is true, then refresh will be triggered on window move.'''
        pass

    def setFogSource(self, source): 
        '''setFogSource(self, source)
Arguments:
	[in]	source = MPx3dModelView.FogSource


Sets the type of fog algorithm to use. If the  source  argument is kFogFragment (default) then fog is computed per pixel. If the argument is kFogCoordinate then if the geometry has specified vertex fog coordinates, and the OpenGL extension for vertex fog is supported by the graphics system, then fog is computed per vertex.'''
        pass

    def setViewSelectedPrefix(self, prefix): 
        '''setViewSelectedPrefix(self, prefix)
Arguments:
	[in]	prefix = MString


Sets the prefix for the camera name as displayed in the heads up display when view selected is enabled. The prefix is concatenated with the camera name.'''
        pass

    def kFogCoordinate(self):
        '''This is an enum of FogSource.
Description: Computed by specified vertex fog coordinates.
Value: 1'''
        pass

    def kFogFragment(self):
        '''This is an enum of FogSource.
Description: Computed per pixel (default).
Value: 0'''
        pass

    class FogSource:
        '''Non-functional class.  Values for this enum:
        kFogCoordinate
        kFogFragment
'''
        def __init__(self):
            pass

    def setTwoSidedLighting(self, twoSided): 
        '''setTwoSidedLighting(self, twoSided)
Arguments:
	[in]	twoSided = bool


Enables two sided lighting.'''
        pass

    def setDisplayCameraAnnotation(self, enable): 
        '''setDisplayCameraAnnotation(self, enable)
Arguments:
	[in]	enable = bool


Sets the camera annotation display in the  MPx3dModelView .'''
        pass

    def numDormantColors(self): 
        '''numDormantColors(self) -> int
Returns: The number of dormant colors


Returns the number of dormant object colors in the internal application color table.'''
        pass

    def getCamera(self, camera): 
        '''getCamera(self, camera)
Arguments:
	[out]	camera = MDagPath


Get the camera for this view.'''
        pass

    def numActiveColors(self): 
        '''numActiveColors(self) -> int
Returns: The number of active colors


Returns the number of active object colors in the internal application color table.'''
        pass

    def hasStereoBufferSupport(self): 
        '''hasStereoBufferSupport(self) -> bool

'''
        pass

    def viewType(self): 
        '''viewType(self) -> MString


Returns a string specifying the view type. The view type should be a different string for every class derived from  MPx3dModelView . The default type is "MPx3dModelView".'''
        pass

    def isFogEnabled(self): 
        '''isFogEnabled(self) -> bool
Returns: true is fog is enabled.


Returns true if fog is enabled.'''
        pass

class MPxBakeEngine:
    '''Baking functionality. The MPxBakeEngine class is a way for users to override the viewport representation of shaders. Users can provide their own baking engine to bake advanced shading properties into a texture. This texture is used by the viewport to represent the shading properties. '''
    def __init__(self):
        pass


    def bake(self, objectPath, cameraPath, samplePlug, result): 
        '''bake(self, objectPath, cameraPath, samplePlug, result)
Arguments:
	[in]	objectPath = MDagPath
	[in]	cameraPath = MDagPath
	[in]	samplePlug = MPlug
	[out]	result = MImage


Bake the texture Maya will use to approximate shading properties.'''
        pass

    def setNeedTransparency(self, t): 
        '''setNeedTransparency(self, t)
Arguments:
	[in]	t = bool


Set whether the bake engine needs to produce an image with transparency.'''
        pass

    def getUVRange(self, minUV, maxUV): 
        '''getUVRange(self, minUV, maxUV)
Arguments:
	[out]	minUV = MFloatArray
	[out]	maxUV = MFloatArray


Tells Maya the UV range the baked texture should cover.'''
        pass

class MPxCacheFormat:
    '''CacheFormat definition. The MPxCacheFormat class can be used to implement support for new cache file formats in Maya. '''
    def __init__(self):
        pass


    def MString(self): 
        '''MString(self) -> virtual


Provide the disk file extension for this format. This is not the same as the format's key, which is used by the plugin to identify itself. 
  Reprocessed example  
 Examples: 
 
   
 XmlGeometryCache.cpp . 
 
'''
        pass

    def beginWriteChunk(self): 
        '''beginWriteChunk(self) -> virtualvoid


Perform any actions required prior to writing a chunk's information. A chunk contains the cache information for a specfic time, and may contain multiple channels. 
  Reprocessed example  
 Examples: 
 
   
 XmlGeometryCache.cpp . 
 
'''
        pass

    def endWriteChunk(self): 
        '''endWriteChunk(self) -> virtualvoid


Perform any actions required after writing a chunk's information. A chunk contains the cache information for a specfic time, and may contain multiple channels. 
  Reprocessed example  
 Examples: 
 
   
 XmlGeometryCache.cpp . 
 
'''
        pass

    def MStatus(self, time): 
        '''MStatus(self, time) -> virtual

Arguments:
	[out]	time = MTime


Read the current time from the cache.  Parameters: 
 
 [out]   time   Variable to read the time value into.  
 
 
  Reprocessed example  
 Examples: 
 
   
 XmlGeometryCache.cpp . 
 
'''
        pass

    def endReadChunk(self): 
        '''endReadChunk(self) -> virtualvoid


Perform any actions required after reading a chunk's information. A chunk contains the cache information for a specfic time, and may contain multiple channels. 
  Reprocessed example  
 Examples: 
 
   
 XmlGeometryCache.cpp . 
 
'''
        pass

    def kReadWrite(self):
        '''This is an enum of FileAccessMode.
Description: read and write (e.g. append, edit, etc.)
Value: 2'''
        pass

    def kWrite(self):
        '''This is an enum of FileAccessMode.
Description: write only
Value: 1'''
        pass

    def kRead(self):
        '''This is an enum of FileAccessMode.
Description: read only
Value: 0'''
        pass

    class FileAccessMode:
        '''Non-functional class.  Values for this enum:
        kReadWrite
        kWrite
        kRead
'''
        def __init__(self):
            pass

class MPxCommand:
    '''Base class for user commands. This is the proxy class for creating MEL commands through the API.Each command is derived from this one, and must have a  method, and optionally , and  methods.The  method should collect whatever information is required to do the task, and store it in local class data. It should finally call  to make the command happen. The  method should do the actual work, using only the local class data. The  method should undo the actual work, again using only the local class data.Maya contains support for infinite levels of undo. If a command written in a plug-in changes the state of anything in Maya, it should implement  and  methods. As well, if the  method returns successfully, Maya will call the method's  method immediately afterwards. If that method returns true, the instance of this class is retained and passed to Maya's undo manager so that the  and  methods can be called when appropriate. If  returns false, the command instance is destroyed right away.So, for example, if a command supports both  and  modes, in query mode the command should set a flag so that the  method returns false to prevent that command instance from being retained by the undo manager. In edit mode, where the state of Maya is changed,  should return true to enable undo and redo. '''
    def __init__(self):
        pass


    def displayInfo(self, theInfo): 
        '''displayInfo(self, theInfo)
Arguments:
	[in]	theInfo = MString


This method is used to display information in the script editor.'''
        pass

    def setCommandString(self, name): 
        '''setCommandString(self, name)
Arguments:
	[in]	name = MString


Sets the command string that is associated with this command object.'''
        pass

    def syntax(self): 
        '''syntax(self) -> MSyntax


This method is intended to be used in an MArgDataBase or  MArgParser  contructor when the plugin command's syntax is being initialized. The user should declare and define a syntax contstructing method that must be registered with Maya by passing the function pointer as a parameter in  MFnPlugin::registerCommand() . The result is that when  MPxCommand::syntax()  is called it returns the syntax object that the user has created in the custom syntax constructing method that was registered. To avoid conflicts it is important that the user's custom syntax defining method be given a name other than "syntax." It can have any other name as long as it corresponds with the function pointer used to register the method with Maya.'''
        pass

    def hasSyntax(self): 
        '''hasSyntax(self) -> bool


This method specifies whether or not the command has a syntax object.'''
        pass

    def commandString(self): 
        '''commandString(self) -> MString


This method returns the command string that is associated with this command.'''
        pass

    def doIt(self, args): 
        '''doIt(self, args)
Arguments:
	[in]	args = MArgList


This method should perform a command by setting up internal class data and then calling the  redoIt  method. The actual action performed by the command should be done in the  redoIt  method. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def redoIt(self): 
        '''redoIt(self)

This method should do the actual work of the command based on the internal class data only. Internal class data should be set in the  doIt  method.'''
        pass

    def isHistoryOn(self): 
        '''isHistoryOn(self) -> bool


Returns whether history is on.'''
        pass

    def kLong(self):
        '''This is an enum of MResultType.
Description: 
Value: 0'''
        pass

    def kString(self):
        '''This is an enum of MResultType.
Description: 
Value: 2'''
        pass

    def kDouble(self):
        '''This is an enum of MResultType.
Description: 
Value: 1'''
        pass

    def kNoArg(self):
        '''This is an enum of MResultType.
Description: 
Value: 3'''
        pass

    class MResultType:
        '''Non-functional class.  Values for this enum:
        kLong
        kString
        kDouble
        kNoArg
'''
        def __init__(self):
            pass

    def currentDoubleResult(self): 
        '''currentDoubleResult(self) -> double
Returns: The double result.


This method gets the current node's result as a double, if possible.'''
        pass

    def undoIt(self): 
        '''undoIt(self)

This method should undo the work done be the  redoIt  method based on the internal class data only.'''
        pass

    def appendToResult(self, val): 
        '''appendToResult(self, val)
Arguments:
	[in]	val = MStringArray


This method will add the given value to the end of the result array of strings. The result array can only be of a single type so this method can only be used when the result string has not been set or is already of type string.'''
        pass

    def currentResultType(self): 
        '''currentResultType(self) -> MPxCommand.MResultType

'''
        pass

    def currentStringResult(self): 
        '''currentStringResult(self) -> MString
Returns: The string result.


This method gets the current node's result as a  MString , if possible.'''
        pass

    def isUndoable(self): 
        '''isUndoable(self) -> bool


This method is used to specify whether or not the command is undoable. In the base class, it always returns false. If you are writing a command that might be eligible for undo, you should override this method.'''
        pass

    def displayWarning(self, theWarning, wantDisplayLineNumber): 
        '''displayWarning(self, theWarning, wantDisplayLineNumber)
Arguments:
	[in]	theWarning = MString
	[in]	wantDisplayLineNumber = bool


This method is used to display a warning in the script editor.'''
        pass

    def currentIntResult(self): 
        '''currentIntResult(self) -> int
Returns: The int result.


This method gets the current node's result as a int, if possible.'''
        pass

    def getCurrentResult(self, val): 
        '''getCurrentResult(self, val)
Arguments:
	[out]	val = MStringArray


This method gets the current node's result as an array of strings, if possible.'''
        pass

    def displayError(self, theError, wantDisplayLineNumber): 
        '''displayError(self, theError, wantDisplayLineNumber)
Arguments:
	[in]	theError = MString
	[in]	wantDisplayLineNumber = bool


This method is used to display an error in the script editor.'''
        pass

    def setHistoryOn(self, state): 
        '''setHistoryOn(self, state)
Arguments:
	[in]	state = bool


This method specifies if history for this command is on.'''
        pass

    def setResult(self, val): 
        '''setResult(self, val)
Arguments:
	[in]	val = MStringArray


This method puts the given values into the return value area for a command.'''
        pass

    def clearResult(self): 
        '''clearResult(self)
'''
        pass

class MPxComponentShape:
    '''Component helper class for surface shapes. MPxComponentShape allows the implementation of new user defined shapes using components. User defined shapes are dependency nodes (and DAG nodes) which contain overridable drawing, selection, and component methods. This class provides enhanced functionality for working with components. As a result, it is a better starting point than MPxSurfaceShape for writing surface shape components.This class provides methods to manipulate and select the components that make up the shape.The UI dependent aspects of the shape should be implemented in a class derived from MPxSurfaceShapeUI. This includes the drawing and interactive selection of the shape. '''
    def __init__(self):
        pass


    def setControlPoints(self, cps): 
        '''setControlPoints(self, cps)
Arguments:
	[in]	cps = MVectorArray


Push the given control points into the node's data block'''
        pass

    def createFullVertexGroup(self): 
        '''createFullVertexGroup(self) -> MObject


This method is used to create a component containing every vertex/CV in the object.'''
        pass

    def componentToPlugs(self, component, list): 
        '''componentToPlugs(self, component, list)
Arguments:
	[in]	component = MObject
	[in]	list = MSelectionList


Converts the given component into a selection list of plugs. This method is used to associate a shapes components into the corresponding attributes (plugs) within the shape.'''
        pass

    def transformUsing(self, mat, componentList, cachingMode, pointCache): 
        '''transformUsing(self, mat, componentList, cachingMode, pointCache)
Arguments:
	[in]	mat = MMatrix
	[in]	componentList = MObjectArray
	[in]	cachingMode = MPxSurfaceShape.MVertexCachingMode
	[in]	pointCache = MPointArray


Transform the given components using the specified transformation matrix. This method should be overridden if the shape supports components that can be transformed using maya's move, scale, and rotate tools.'''
        pass

    def match(self, mask, componentList): 
        '''match(self, mask, componentList) -> bool
Returns: true the match was successfull 
false the match failed 

Arguments:
	[in]	mask = MSelectionMask
	[in]	componentList = MObjectArray


This method is used to check for matches between a selection type (or mask) and a given component. This method is used to match up your components with selection masks.'''
        pass

    def localShapeInAttr(self): 
        '''localShapeInAttr(self) -> MObject


Returns the input attribute of the shape, which are the control points.'''
        pass

    def getControlPoints(self): 
        '''getControlPoints(self) -> MVectorArray


Extract the control points from the data block and store them locally.'''
        pass

class MPxConstraint:
    '''Proxy constraint node. MPxConstraint is the parent class for user defined constraint nodes. Position, orientation or scale of an object can be constrained by other objects. This class works in conjunction with the MPxConstraintCommand class. '''
    def __init__(self):
        pass


    def kObjectRotation(self):
        '''This is an enum of UpVectorType.
Description: Object rotation up vector.
Value: 2'''
        pass

    def kLast(self):
        '''This is an enum of UpVectorType.
Description: Last value, used for counting.
Value: 4'''
        pass

    def kScene(self):
        '''This is an enum of UpVectorType.
Description: Scene up vector.
Value: 0'''
        pass

    def kObject(self):
        '''This is an enum of UpVectorType.
Description: Object up vector.
Value: 1'''
        pass

    def kVector(self):
        '''This is an enum of UpVectorType.
Description: Specified vector.
Value: 3'''
        pass

    class UpVectorType:
        '''Non-functional class.  Values for this enum:
        kObjectRotation
        kLast
        kScene
        kObject
        kVector
'''
        def __init__(self):
            pass

    def getOutputAttributes(self, attributeArray): 
        '''getOutputAttributes(self, attributeArray)
Arguments:
	[out]	attributeArray = MObjectArray


Returns output attributes for the constraint. Default implementation clears the input attributeArray and returns. 
  Reprocessed example  
 Examples: 
 
   
 geometrySurfaceConstraint.h . 
 
'''
        pass

    def closestNormal(self, dataGeometryObject, toThisPoint, theNormal): 
        '''closestNormal(self, dataGeometryObject, toThisPoint, theNormal)
Arguments:
	[in]	dataGeometryObject = MObject
	[in]	toThisPoint = MPoint
	[out]	theNormal = MVector


Returns the closest normal on this surface to the given point.'''
        pass

    def worldConstraintPoint(self, parentInverseMatrix, translate, rotatePivot, rotatePivotTranslate): 
        '''worldConstraintPoint(self, parentInverseMatrix, translate, rotatePivot, rotatePivotTranslate) -> MPoint

Arguments:
	[in]	parentInverseMatrix = MMatrix
	[in]	translate = MVector
	[in]	rotatePivot = MVector
	[in]	rotatePivotTranslate = MVector


Returns the world constraint point.'''
        pass

    def closestTangent(self, dataGeometryObject, toThisPoint, theTangent): 
        '''closestTangent(self, dataGeometryObject, toThisPoint, theTangent)
Arguments:
	[in]	dataGeometryObject = MObject
	[in]	toThisPoint = MPoint
	[out]	theTangent = MVector


Returns the closest tangent on this surface to the given point.'''
        pass

    def computeAim(self, parentInverseMatrix, targetVector, aimVector, upVector, wUpVector, order, jointOrient): 
        '''computeAim(self, parentInverseMatrix, targetVector, aimVector, upVector, wUpVector, order, jointOrient) -> MEulerRotation

Arguments:
	[in]	parentInverseMatrix = MMatrix
	[in]	targetVector = MVector
	[in]	aimVector = MVector
	[in]	upVector = MVector
	[in]	wUpVector = MVector
	[in]	order = MEulerRotation.RotationOrder
	[in]	jointOrient = MQuaternion


Returns the rotation which aligns the aimVector in local space with the targetVector in local space while keeping the upVector in local space and the wUpVector world space aligned as closely as possible.'''
        pass

    def closestPoint(self, dataGeometryObject, toThisPoint, theClosestPoint): 
        '''closestPoint(self, dataGeometryObject, toThisPoint, theClosestPoint)
Arguments:
	[in]	dataGeometryObject = MObject
	[in]	toThisPoint = MPoint
	[out]	theClosestPoint = MPoint


Returns the closest point on this surface to the given point.'''
        pass

    def MObject(self): 
        '''MObject(self) -> const

'''
        pass

    def worldUpVector(self, upType, upVector, upMatrix, constrPoint): 
        '''worldUpVector(self, upType, upVector, upMatrix, constrPoint) -> MVector

Arguments:
	[in]	upType = MPxConstraint.UpVectorType
	[in]	upVector = MVector
	[in]	upMatrix = MMatrix
	[in]	constrPoint = MPoint


Returns the world up vector based on the requested up type.'''
        pass

class MPxConstraintCommand:
    '''Proxy constraint command. MPxConstraintCommand is the base class for user defined constraint commands. This command gives all of the flags and options of the base constraint command in addition allows user defined flags or behaviours. When registering this command, use the MFnPlugin::registerConstraintCommand() method. A MPxConstraint is also required to be used with MPxConstraintCommand. The constraintTypeId() virtual must be implemented to return the correct constraint node. '''
    def __init__(self):
        pass


    def kLast(self):
        '''This is an enum of TargetType.
Description: Last value, used for counting.
Value: 2'''
        pass

    def kGeometryShape(self):
        '''This is an enum of TargetType.
Description: Geometry shape(or children of) targets.
Value: 1'''
        pass

    def kTransform(self):
        '''This is an enum of TargetType.
Description: Transform target.
Value: 0'''
        pass

    class TargetType:
        '''Non-functional class.  Values for this enum:
        kLast
        kGeometryShape
        kTransform
'''
        def __init__(self):
            pass

    def connectObjectAttribute(self, objectAttr, constraintAttr, toConstraint, instanced): 
        '''connectObjectAttribute(self, objectAttr, constraintAttr, toConstraint, instanced)
Arguments:
	[in]	objectAttr = MObject
	[in]	constraintAttr = MObject
	[in]	toConstraint = bool
	[in]	instanced = bool


This method is used  connectObjectAndConstraint()  to make any required connections between the constraint and the constrained object.'''
        pass

    def parseArgs(self, argList): 
        '''parseArgs(self, argList)
Arguments:
	[in]	argList = MArgList


This method is used for parsing any custom flags/params that have been added to the command. Return  MS::kUnknownParameter  to allow the processing of base flags/params.'''
        pass

    def doEdit(self): 
        '''doEdit(self)

This method is used for editing any custom setting on the command. Return  MS::kUnknownParameter  to allow processing of the base class functionality.'''
        pass

    def syntax(self): 
        '''syntax(self) -> MSyntax
Returns: the syntax object


USE _syntax() IN SCRIPT. 
'''
        pass

    def supportsOffset(self): 
        '''supportsOffset(self) -> bool

'''
        pass

    def MObject(self): 
        '''MObject(self) -> const

'''
        pass

    def handleNewTargets(self, dagObject): 
        '''handleNewTargets(self, dagObject)
Arguments:
	[in]	dagObject = MDagPath


This method is used to perform any special processing when targets are added to the constraint. For example, the constraint may need to keep track of the list of targets to properly calculate an offset.'''
        pass

    def doIt(self, args): 
        '''doIt(self, args)
Arguments:
	[in]	args = MArgList


This method should execute a command by setting up internal class data and then return control to Maya for executing the base constraint command functionality. This is a virtual, and can be overridden in derived classes.'''
        pass

    def redoIt(self): 
        '''redoIt(self)

This method should do the actual work of the command based on the internal class data only. Internal class data should be set in the  doIt  method.'''
        pass

    def doCreate(self): 
        '''doCreate(self)

This method is used for creating resources required by the command. Return MS:kUnknownParameter to allow processing of base class functionality.'''
        pass

    def appendSyntax(self): 
        '''appendSyntax(self)

This method should be overridden to append syntax to the constraint command. The syntax object can be obtained by calling the syntax method. The following flags cannot be used as user-defined flags as they are reserved for edit and query: "-e", "-edit", "-q", "-query".'''
        pass

    def connectTarget(self, targetPath, index): 
        '''connectTarget(self, targetPath, index)
Arguments:
	[in]	targetPath = MDagPath
	[in]	index = int


This method is called to make connections between the constraint and the target. Since the default behaviour is to do nothing it is generally necessary to override this method if your constraint is to work properly. The  connectTargetAttribute()  convenience method can be useful in this regard.'''
        pass

    def connectObjectAndConstraint(self, modifier): 
        '''connectObjectAndConstraint(self, modifier)
Arguments:
	[in]	modifier = MDGModifier


This method is used for connecting the constraint and constrained object. The utility method  MPxConstraintCommand::connectObjectAttribute()  is used to connect the attributes.'''
        pass

    def connectTargetAttribute(self, targetPath, index, targetAttribute, constraintAttr, instanced): 
        '''connectTargetAttribute(self, targetPath, index, targetAttribute, constraintAttr, instanced)
Arguments:
	[in]	targetPath = MDagPath
	[in]	index = int
	[in]	targetAttribute = MObject
	[in]	constraintAttr = MObject
	[in]	instanced = bool


Utility method to make any required connections for the constraint.'''
        pass

    def targetType(self): 
        '''targetType(self) -> MPxConstraintCommand.TargetType


Maya supports constraints targets which are either transforms or nodes derived from "geometryShape". Return the appropriate target type in this method.'''
        pass

    def hasVectorFlags(self): 
        '''hasVectorFlags(self) -> bool

'''
        pass

    def getObjectAttributesArray(self, array): 
        '''getObjectAttributesArray(self, array)
Arguments:
	[out]	array = MObjectArray

'''
        pass

    def doQuery(self): 
        '''doQuery(self)

This method is used for querying information defined in the command. Return MS:kUnknownParameter to allow processing of base class functionality.'''
        pass

    def constraintTypeId(self): 
        '''constraintTypeId(self) -> MTypeId


This method is used to return the  MTypeId  of the  MPxConstraint  node that is used with this command. This virtual must be implemented in a proxy constraint command.'''
        pass

    def undoIt(self): 
        '''undoIt(self)

This method should undo the work done be the  redoIt  method based on the internal class data only.'''
        pass

    def createdConstraint(self, constraint): 
        '''createdConstraint(self, constraint)
Arguments:
	[in]	constraint = MPxConstraint


This method is called when an  MPxConstraintCommand  creates a new  MPxConstraint  node. It can be used for transferring state from the command to the node object.'''
        pass

    def connectGeometryAttribute(self, opaqueTarget, index, constraintAttribute): 
        '''connectGeometryAttribute(self, opaqueTarget, index, constraintAttribute)
Arguments:
	[in]	opaqueTarget = void
	[in]	index = int
	[in]	constraintAttribute = MObject


Utility method to make any required connections for the constraint. Note that it is called by the default implementation of  connectTarget() .'''
        pass

class MPxContext:
    '''Base class for user defined contexts. This is the base class for user defined contexts.Contexts provide a way to create interactive tools in Maya. A context class defines what happens when interactive events, such as mouse events, occur within an interactive panel in Maya.Since there are default actions for all tools in Maya, such as the right mouse button event which brings up an options menu, only as subset of the events that occur in a view can be overridden. The events that can be overridden are:A context is  by pressing the toolButton for that context. Once the context is activated, it will handle the events that occur within 3d panel.A context is  when some other tool button is pressed.There can be more than one instance of a context in Maya, for example, dragging a tool icon into the shelf creates another instance of that context. Since there can be multiple instances of the same context there is a command class, , which is responsible for the creation of contexts. See  for more information. '''
    def __init__(self):
        pass


    def feedbackNumericalInput(self): 
        '''feedbackNumericalInput(self) -> bool


This method is called to update the numerical feedback. The format and values for the feedback line can be set through the methods in  MFeedbackLine , specifically setFormat and setValue. The return value should indicate whether or not the numerical feedback has been provided.'''
        pass

    def image(self, index): 
        '''image(self, index) -> MString
Returns: String name

Arguments:
	[in]	index = MPxContext.ImageIndex


This method is used to retrieve an XPM icon image that has previously been set for this tool context. This icon image will be used to represent this tool context in various places including the tool bar and can be queried from mel using the contextInfo command.'''
        pass

    def dragMarquee(self, event): 
        '''dragMarquee(self, event)
Arguments:
	[in]	event = MEvent


USE _dragMarquee() IN SCRIPT. 
'''
        pass

    def doHold(self, event): 
        '''doHold(self, event)
Arguments:
	[in]	event = MEvent


This method is called when a mouse button is pressed but before the mouse is dragged. The base method does nothing and should be overriden if the user needs to do anything on a button hold.'''
        pass

    def kImage1(self):
        '''This is an enum of ImageIndex.
Description: 
Value: 0'''
        pass

    def kImage3(self):
        '''This is an enum of ImageIndex.
Description: 
Value: 2'''
        pass

    def kImage2(self):
        '''This is an enum of ImageIndex.
Description: 
Value: 1'''
        pass

    class ImageIndex:
        '''Non-functional class.  Values for this enum:
        kImage1
        kImage3
        kImage2
'''
        def __init__(self):
            pass

    def argTypeNumericalInput(self, index): 
        '''argTypeNumericalInput(self, index) -> MSyntax.MArgType
Returns: MSyntax::kNoArg the default return value 

Arguments:
	[in]	index = int


This method is used by the feedback line to determine what units to display. Users should override this method to return the appropriate argument type for the given index of the numeric input field. Specifically, this method should be overridden to return one of the following:'''
        pass

    def processNumericalInput(self, values, flags, isAbsolute): 
        '''processNumericalInput(self, values, flags, isAbsolute) -> bool
Returns: false the default return value 

Arguments:
	[in]	values = MDoubleArray
	[in]	flags = MIntArray
	[in]	isAbsolute = bool


This method processes the input from the numerical input field. Users can override this method if they wish to process numerical input. For a given entry in the numeric input field, if the user types a dot ".", this indicates that the entry should not be modified. The overridden version of this method should take this into account using the ignoreEntry method with the flags that are passed in. The overridden version of this method should also process the numeric input as an absolute input or relative input depending on whether the isAbsolute flag is true or not. The return value should indicate whether or not the numerical input has been processed.'''
        pass

    def newToolCommand(self): 
        '''newToolCommand(self) -> MPxToolCommand


CALL _newToolCommand() IN SCRIPT. 
'''
        pass

    def stringClassName(self): 
        '''stringClassName(self) -> MString


This method is called to determine the name that uniquely identifies the context. Either this method, or the getClassName method, should be overridden such that the name is set to the appropriate string. For example:           MString  MPxExampleContext::stringClassName()  const 
          {  return   "exampleTool" ; }
'''
        pass

    def deleteAction(self): 
        '''deleteAction(self)
'''
        pass

    def setTitleString(self, str): 
        '''setTitleString(self, str)
Arguments:
	[in]	str = MString


USE _setTitleString() IN SCRIPT. 
'''
        pass

    def doEnterRegion(self, event): 
        '''doEnterRegion(self, event)
Arguments:
	[in]	event = MEvent


This method is called when the mouse pointer enters a screen panel region. The base method sets the help string and the cursor which may have been set via  setHelpString  and  setCursor  respectively.'''
        pass

    def setCursor(self, newCursor): 
        '''setCursor(self, newCursor)
Arguments:
	[in]	newCursor = MCursor


USE _setCursor() IN SCRIPT. 
'''
        pass

    def doPress(self, event): 
        '''doPress(self, event)
Arguments:
	[in]	event = MEvent


This method is called when any mouse button is pressed. The base method does nothing and should be overriden if the user needs to do anything on a button press.'''
        pass

    def toolOnSetup(self, event): 
        '''toolOnSetup(self, event)
Arguments:
	[in]	event = MEvent


This method is called when the context is activated, i.e when the toolButton for the context is pressed. Users can override this method and use it to set up any user defined data that needs to be initialized on each activation.'''
        pass

    def setHelpString(self, str): 
        '''setHelpString(self, str)
Arguments:
	[in]	str = MString


USE _setHelpString() IN SCRIPT. 
'''
        pass

    def addManipulator(self, manipulator): 
        '''addManipulator(self, manipulator)
Arguments:
	[in]	manipulator = MObject


This method adds a manipulator to the context.'''
        pass

    def beginMarquee(self, event): 
        '''beginMarquee(self, event)
Arguments:
	[in]	event = MEvent


USE _beginMarquee() IN SCRIPT. 
'''
        pass

    def abortAction(self): 
        '''abortAction(self)
'''
        pass

    def toolOffCleanup(self): 
        '''toolOffCleanup(self)

This method is called when the context is deactivated, i.e when another context is activated. Users can override this method and use it to reset any user defined data to a specific state. 
'''
        pass

    def ignoreEntry(self, flags, entry): 
        '''ignoreEntry(self, flags, entry) -> bool
Returns: true the given entry should be ignored 
false the given entry should not be ignored 

Arguments:
	[in]	flags = MIntArray
	[in]	entry = int


USE _ignoreEntry() IN SCRIPT. 
'''
        pass

    def setImage(self, image, index): 
        '''setImage(self, image, index)
Arguments:
	[in]	image = MString
	[in]	index = MPxContext.ImageIndex


This method is used to set an XPM icon image that is to be used to represent this tool context in various places including the tool bar and can be queried from mel using the contextInfo command.'''
        pass

    def releaseMarquee(self, event, top, left, bottom, right): 
        '''releaseMarquee(self, event, top, left, bottom, right)
Arguments:
	[in]	event = MEvent
	[out]	top = short
	[out]	left = short
	[out]	bottom = short
	[out]	right = short


USE _releaseMarquee() IN SCRIPT. 
'''
        pass

    def completeAction(self): 
        '''completeAction(self)
'''
        pass

    def deleteManipulators(self): 
        '''deleteManipulators(self)

This method deletes all the manipulators that belong to the context.'''
        pass

    def doRelease(self, event): 
        '''doRelease(self, event)
Arguments:
	[in]	event = MEvent


This method is called when any mouse button is released. The base method does nothing and should be overriden if the user needs to do anything on a button release.'''
        pass

    def doDrag(self, event): 
        '''doDrag(self, event)
Arguments:
	[in]	event = MEvent


This method is called when a mouse drag event occurs. The base method does nothing and should be overriden if the user needs to do anything during a mouse drag.'''
        pass

    def helpStateHasChanged(self, event): 
        '''helpStateHasChanged(self, event)
Arguments:
	[in]	event = MEvent


This method is called whenever the help state may need to be updated. The base method does nothing and should be overriden if the user needs to change the help information based on events.'''
        pass

class MPxContextCommand:
    '''Base class for context creation commands. This is the base class for context creation commands.The purpose of this command class is to create instances of user contexts derived from , and to allow the MEL programmer to edit and query various properties of the context related to this command.The user will derive off of this class and override the  method which will be called when this command is invoked in Maya.The context command is registered in Maya using MFnPlugin::registerContextCommand'''
    def __init__(self):
        pass


    def doEditFlags(self): 
        '''doEditFlags(self)

This method is called when the command is called in edit mode. This method should be overridden by context commands to determine which edit flags are set in conjunction with the argument parser for this command. The argument parser for this command can be obtained by calling the parser method. If the command is called with both the edit flag and the query flag, then the query flag will be ignored.'''
        pass

    def makeObj(self): 
        '''makeObj(self) -> MPxContext


This function is used to instantiate a proxy context. In your derived class, declare this function:'''
        pass

    def parser(self): 
        '''parser(self) -> MArgParser
Returns: The argument parser


USE _parser() IN SCRIPT. 
'''
        pass

    def doQueryFlags(self): 
        '''doQueryFlags(self)

This method is called when the command is called in query mode. This method should be overridden by context commands to determine which query flags are set in conjunction with the argument parser for this command. The argument parser for this command can be obtained by calling the parser method. If the command is called with both the edit flag and the query flag, then the query flag will be ignored.'''
        pass

    def syntax(self): 
        '''syntax(self) -> MSyntax
Returns: The syntax object


USE _syntax() IN SCRIPT. 
'''
        pass

    def setResult(self, result): 
        '''setResult(self, result)
Arguments:
	[out]	result = MString


This method should be called when the result of the context command a string.'''
        pass

    def appendSyntax(self): 
        '''appendSyntax(self)

This method should be overridden to append syntax to the context command. The syntax object can be obtained by calling the syntax method. The following flags cannot be used as user-defined flags as they are reserved for edit and query: "-e", "-edit", "-q", "-query".'''
        pass

class MPxControlCommand:
    '''Base class for control creation commands. MPxControlCommand is the base class for user defined UI control commands. This command gives all of the flags and options of the base control command in addition to any user defined flags or behaviours. When registering this command, use the MFnPlugin::registerControlCommand() method. All control commands have a corresponding MPxUIControl. It is important to note that a given MPxControlCommand is reponsible for only ONE MPxUIControl. '''
    def __init__(self):
        pass


    def control(self): 
        '''control(self) -> MPxUIControl


USE _control() IN SCRIPT. 
'''
        pass

    def doEditFlags(self): 
        '''doEditFlags(self)

This method is called when the command is called in edit mode. This method should be overridden by control commands to determine which edit flags are set in conjunction with the argument parser for this command. The argument parser for this command can be obtained by calling the parser method.'''
        pass

    def skipFlagForCreate(self, longFlag): 
        '''skipFlagForCreate(self, longFlag) -> bool
Returns: true if the flag shoiuld be skipped during creation.

Arguments:
	[in]	longFlag = MString


Returns true if the passed long flag name should be skipped during the creation portion of the command.'''
        pass

    def parser(self): 
        '''parser(self) -> MArgParser
Returns: The argument parser


USE _parser() IN SCRIPT. 
'''
        pass

    def doQueryFlags(self): 
        '''doQueryFlags(self)

This method is invoked during query mode, and the default method should be overridden in user-defined control commands to determine which query flags are set in conjunction with the argument parser for the command. The argument parser for this command can be obtained by calling the parser method. If the command is called with both the edit flag and the query flag, then the query flag will be ignored.'''
        pass

    def syntax(self): 
        '''syntax(self) -> MSyntax
Returns: the syntax object


USE _syntax() IN SCRIPT. 
'''
        pass

    def setResult(self, result): 
        '''setResult(self, result)
Arguments:
	[out]	result = MIntArray


This method should be called when the result of the control command is a integer array.'''
        pass

    def appendSyntax(self): 
        '''appendSyntax(self)

This method should be overridden to append syntax to the control command. The syntax object can be obtained by calling the syntax method. The following flags cannot be used as user-defined flags as they are reserved for edit and query: "-e", "-edit", "-q", "-query".'''
        pass

    def makeControl(self): 
        '''makeControl(self) -> MPxUIControl


This method is called when the UI control should be created. You need to create a new  MPxUIControl  on call to this method (the base implementation is abstract, so that the compiler will force you to define an implementation of this method).'''
        pass

    def clearResult(self): 
        '''clearResult(self)
'''
        pass

class MPxData:
    '''Base Class for User-defined Dependency Graph Data Types. In Maya, both intrinsic and user-defined Maya Objects are registered and recognized by their type identifier (MTypeId). Data which flows in the Dependency Graph (DG) is implemented as Maya objects, therefore, the type characteristics of DG Data are specified by the type id (MTypeId). The type id is used to at run-time to determine how to create and destroy Maya Objects, and how they are to be input/output from/to files.User-defined Data has two parts. One part is an internal Maya Data object of neutral type which is common to all user-defined types. This common Data object implements the interface and behaviour characteristics required for user-defined Data to act as Data within Maya. The second part is unique to each user-defined type and implements the type-specific behaviour.The Proxy Data (MPxData) class is the base class for user-defined Data types. All user-defined Data that is to be passed between Nodes in the DG must be derived from MPxData. MPxData transparently incorporates the common behaviour and defines the common interface required for DG Data. When initialized with a unique type id, Data objects of classes derived from MPxData are recognized by Maya the same as built-in DG Data types, but are be able to implement user-specified behaviour.The MPxData class defines the interface for methods to read, write and assign Data objects of the the user-defined type. User-defined types must override these methods to provide type-specific behaviour.MPxData also provides common methods for querying the type id and type name of the Data object.All user-defined DG Data types require an associated static creator function that returns a void pointer to a new instance of the data class. This function is usually a static function within the user defined data type class.The registration of the new data type is performed by the MFnPlugin::registerData() which is invoked in the initializePlugin() function during Plug-in loading. One of the most important thing that the registration does is it associates the type id with the data.Once a user-defined Data type based on MPxData has been defined and registered, use the Typed Attribute Function Set (MFnTypedAttribute) to create an Attribute of the user-defined type. The Attribute may also be an multi-Attribute (array). Use the DG Node Function Set (MFnDependencyNode) to add the Attribute to a user- defined Node. This is usually done in the initialize() method of the Node creator.Data of a user-defined type on a Node is accessed in the same way as intrinsic Data types. The Data is actually held in an Data Block (MDataBlock). Use a Data Handle (MDataHandle) or Array Data Handle (MArrayDataHandle) to access the Data within a Data Block. Use a Data Block to obtain a Data Handle or Array Data Handle for either an Attribute or the associated Plug on the Attribute. The Data Handle or Array data handle can then be queried for the underlying Data object. The underlying Data object is a generic Maya Object (MObject) with a type id of the user-defined type.Use the Plug-in Data Function Set (MFnPluginData) to obtain an MPxData pointer which can be safely cast to a pointer of the user-defined type. '''
    def __init__(self):
        pass


    def writeASCII(self, outarg): 
        '''writeASCII(self, outarg)
Arguments:
	[in]	outarg = std.ostream


/fn  MStatus   MPxData::writeASCII( std::ostream& out)  Encodes Data in accordance with the ASCII file format and outputs it to the given stream.'''
        pass

    def readBinary(self, inarg, length): 
        '''readBinary(self, inarg, length)
Arguments:
	[in]	inarg = std.istream
	[in]	length = int


/fn  MStatus   MPxData::readBinary( std::istream& in, unsigned int length )  Creates Data in Data Block as specified by binary data from the given stream.'''
        pass

    def readASCII(self, argList, endOfTheLastParsedElement): 
        '''readASCII(self, argList, endOfTheLastParsedElement)
Arguments:
	[in]	argList = MArgList
	[in]	endOfTheLastParsedElement = int


Creates Data in Data Block as specified by input from ASCII file record.'''
        pass

    def name(self): 
        '''name(self) -> MString


Determines the type name of the Data object. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def typeId(self): 
        '''typeId(self) -> MTypeId


Determines the type id of the Data object. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def copy(self, src): 
        '''copy(self, src)
Arguments:
	[in]	src = MPxData


This method initializes an instance of an  MPxData  derived class from another existing instance. This method can be thought of as the  second half  of a copy constructor for the class. The default constructor has already been called for the instance, and this method is used to set the private data by copying the values from an existing instance. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def kGeometryData(self):
        '''This is an enum of Type.
Description: 
Value: 1'''
        pass

    def kLast(self):
        '''This is an enum of Type.
Description: 
Value: 2'''
        pass

    def kData(self):
        '''This is an enum of Type.
Description: 
Value: 0'''
        pass

    class Type:
        '''Non-functional class.  Values for this enum:
        kGeometryData
        kLast
        kData
'''
        def __init__(self):
            pass

    def writeBinary(self, outarg): 
        '''writeBinary(self, outarg)
Arguments:
	[in]	outarg = std.ostream


/fn  MStatus   MPxData::writeBinary( std::ostream& out)  Encodes Data in accordance with the binary file format and outputs it to the given stream.'''
        pass

class MPxDeformerNode:
    '''Base class for user defined Deformers. MPxDeformerNode allows the creation of user-defined deformers. A deformer is a node which takes any number of input geometries, deforms them, and places the output into the output geometry attribute.If you write a deformer by deriving from MPxDeformerNode, your deformer will derive the benefit of Maya's internal deformer functionality, namely:Deformers are full dependency nodes and can have attributes and a deform() method. In general, to derive the full benefit of the Maya deformer base class, it is suggested that you do not write your own compute() method. Instead, write the deform() method, which is called by the MPxDeformerNode's compute() method. However, there are some exceptions when you would instead write your own compute(), namely:In the case where you cannot simply override the deform() method, the following example code shows one possible compute() method implementation. This compute() example creates an iterator for the deformer set corresponding to the output geometry being computed. Note that this sample compute() implementation does not do any deformation, and does not implement handling of the nodeState attribute. If you do choose to override compute() in your node, there is no reason to implement the deform() method, since it will not be called by the base class.For most deformers, implementing compute() is unnecessary. To create a deformer, derive from this class and override the deform() method as demonstrated in the "offsetNode.cpp" example plug-in. The other methods of the parent class MPxNode may also be overridden to perform standard dependency node capabilities.When implementing the compute method for a deformer, another consideration is that the input geometry attribute is not cached. This means that all of the inputs will evaluate each time MDataBlock::inputArrayValue is called on "inputGeom". If you only want a single inputGeometry, you can prevent unneeded evaluations by avoiding calls to MDataBlock.inputArrayValue. For example, use the technique shown in the above example or use MDataBlock::outputArrayValue. '''
    def __init__(self):
        pass


    weightList = ''
    '''weight list attribute, multi '''

    envelope = ''
    '''envelope attribute '''

    outputGeom = ''
    '''geometry output attribute '''

    weights = ''
    '''weight attribute, multi '''

    inputGeom = ''
    '''input geometry attribute '''

    input = ''
    '''input attribute, multi '''

    groupId = ''
    '''input group id attribute '''

    def weightValue(self, block, multiIndex, wtIndex): 
        '''weightValue(self, block, multiIndex, wtIndex) -> float
Returns: Weight 

Arguments:
	[in]	block = MDataBlock
	[in]	multiIndex = int
	[in]	wtIndex = int


This method returns the weightValue stored in the datablock for the given geometry's lattice point/CV/vertex.'''
        pass

    def setUseExistingConnectionWhenSetEditing(self, state): 
        '''setUseExistingConnectionWhenSetEditing(self, state)
Arguments:
	[in]	state = bool


This method allows the plugin node to request special treatment during set editing. It controls the connection behavior if all of a geometry's points are removed from the deformer set, and then points are subsequently added back in to the set again. By default, Maya will reconnect the deformer to the shape using a new input/output index. If this method is called in the custom deformer's postConstructor method and the state is set to true, the deformer will attempt to use the original input/output index when reconnecting to the shape.'''
        pass

    def deform(self, block, iterator, matrix, multiIndex): 
        '''deform(self, block, iterator, matrix, multiIndex)
Arguments:
	[in]	block = MDataBlock
	[in]	iterator = MItGeometry
	[in]	matrix = MMatrix
	[in]	multiIndex = int


This method performs the deformation algorithm. A status code of  MS::kSuccess  should be returned unless there was a problem during the deformation, such as insufficient memory or required input data is missing or invalid.'''
        pass

    def setModifiedCallback(self, list, listAdded): 
        '''setModifiedCallback(self, list, listAdded)
Arguments:
	[in]	list = MSelectionList
	[in]	listAdded = bool


This callback method can be overriden and is called whenever the set this deformer is operating on is modified. It passes in a selection list of items that are either being added/removed.'''
        pass

    def accessoryAttribute(self): 
        '''accessoryAttribute(self) -> MObject


This method returns an  MObject  for the attribute to which an accessory shape is connected. If the accessory shape is deleted, the deformer node will automatically be deleted.'''
        pass

    def accessoryNodeSetup(self, cmd): 
        '''accessoryNodeSetup(self, cmd)
Arguments:
	[in]	cmd = MDagModifier


This method is called by the "deformer -type" command when your node is specified.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kDeformerNode .'''
        pass

class MPxDragAndDropBehavior:
    '''Drag and Drop Behavior. This is the base class for user defined drag and drop behaviors. This class allows a plugin to override the behavior of drag and drop connections from nodes in the hyperGraph/hyperShade to other nodes or other UI. These behaviors are defined by the type of relationship that is trying to be resolved. These are connectAttrToAttr(), connectAttrToNode(), connectNodeToAttr(), connectNodeToNode(). In order for the overridden methods to be executed the shouldBeUsedFor() method must be overridden in order to decide which behavior to use given the source and destination node. '''
    def __init__(self):
        pass


    def connectAttrToNode(self, sourcePlug, destinationNode, force): 
        '''connectAttrToNode(self, sourcePlug, destinationNode, force)
Arguments:
	[in]	sourcePlug = MPlug
	[in]	destinationNode = MObject
	[in]	force = bool


This method is called by the defaultNavigation command to connect a source attribute to a destination node.You should override this method if you can determine from the type of source node and attribute and the type of destination node what the user is trying to do and you know the appropriate connections that must be made for the end result to be what the user expects.'''
        pass

    def connectNodeToNode(self, sourceNode, destinationNode, force): 
        '''connectNodeToNode(self, sourceNode, destinationNode, force)
Arguments:
	[in]	sourceNode = MObject
	[in]	destinationNode = MObject
	[in]	force = bool


This method is called by the defaultNavigation command to connect a source node to a destination node.You should override this method if you can determine from the type of source node and the type of destination node what the user is trying to do and you know the appropriate connections that must be made for the end result to be what the user expects.'''
        pass

    def connectAttrToAttr(self, sourcePlug, destinationPlug, force): 
        '''connectAttrToAttr(self, sourcePlug, destinationPlug, force)
Arguments:
	[in]	sourcePlug = MPlug
	[in]	destinationPlug = MPlug
	[in]	force = bool


This method is called by the defaultNavigation command to connect a source attribute to a destination attribute. If this method is overidden it should attempt to determine what the user probably wants this connection to be, and set up the connection appropriately. If the force argument is true it is intended to notify the user to break any existing connections to the plug, similar to what the mel command "connectAttr" -f flag is used for.'''
        pass

    def shouldBeUsedFor(self, sourceNode, destinationNode, sourcePlug, destinationPlug): 
        '''shouldBeUsedFor(self, sourceNode, destinationNode, sourcePlug, destinationPlug) -> bool

Arguments:
	[in]	sourceNode = MObject
	[in]	destinationNode = MObject
	[in]	sourcePlug = MPlug
	[in]	destinationPlug = MPlug


This method must be overridden in order to use a drag and drop behavior. The overridden method will be called by the defaultNavigation command to determine wether or not to use this drag and drop behavior to finish a connection. If the user would like to handle the connection between sourceNode/Plug and destinationNode/Plug than this routine must pass back true, otherwise the routine must pass back false in order for the default connection mechinism to work between these two nodes. sourcePlug and destinationPlug may be null depending on if there were any attributes given in the drag and drop. Use the isNull() method on  MPlug  to assure the plugs are valid.'''
        pass

    def connectNodeToAttr(self, sourceNode, destinationPlug, force): 
        '''connectNodeToAttr(self, sourceNode, destinationPlug, force)
Arguments:
	[in]	sourceNode = MObject
	[in]	destinationPlug = MPlug
	[in]	force = bool


This method is called by the defaultNavigation command to connect a source node to a destination attribute. You should override this method if you can determine from the type of source node and the type of destination node and attribute what the user is trying to do and you know the appropriate connections that must be made for the end result to be what the user expects.'''
        pass

class MPxEmitterNode:
    '''Base class for user defined particle emitters. MPxEmitterNode allows the creation and manipulation of dependency graph nodes representing particle emitters. '''
    def __init__(self):
        pass


    mMinDistance = ''
    '''min distance attribute '''

    mOwnerVelData = ''
    '''owner velocity attribute, multi '''

    mOwnerCentroid = ''
    '''owner centroid attribute '''

    mOutput = ''
    '''output particle attribute, multi '''

    mDirection = ''
    '''direction attribute '''

    mIsFull = ''
    '''flag for maximum count attribute '''

    mRate = ''
    '''rate attribute '''

    mSeed = ''
    '''random seed attribute '''

    mMaxDistance = ''
    '''max distance attribute '''

    mOwnerPosData = ''
    '''owner postion attribute, multi '''

    mCurrentTime = ''
    '''current time attribute '''

    mSweptGeometry = ''
    '''input swept geometry attribute '''

    mOwnerCentroidY = ''
    '''Y component of mOwnerCentroid. '''

    mOwnerCentroidX = ''
    '''X component of mOwnerCentroid. '''

    mDirectionY = ''
    '''Y component of mDirection. '''

    mDirectionX = ''
    '''X component of mDirection. '''

    mRandState = ''
    '''random state attribute '''

    mEmitterType = ''
    '''emitter type attribute '''

    mInheritFactor = ''
    '''inherit factor attribute '''

    mDeltaTime = ''
    '''delta time attribute '''

    mSpeed = ''
    '''speed attribute '''

    mDirectionZ = ''
    '''Z component of mDirection. '''

    mWorldMatrix = ''
    '''world matrix attribute '''

    mOwnerCentroidZ = ''
    '''Z component of mOwnerCentroid. '''

    mStartTime = ''
    '''start time attribute '''

    def hasValidEmission2dTexture(self, texAttr): 
        '''hasValidEmission2dTexture(self, texAttr) -> bool
Returns: true if the node connected to the specified emitter attribute is a texture that can be evaluated using the evalEmission2dTexture() method, false otherwise. 

Arguments:
	[in]	texAttr = MObject


Certain aspects of Maya's particle and fluid emitters can be textured using 2d textures. For example, surface particle emitters can use a 2d texture to modulate the emission rate over the surface. For these purposes, only a subset of Maya's textures are supported, namely the default 2d textures (bulge, checker, cloth, file, fluid texture 2d, fractal, grid, mountain, movie, noise, ocean, ramp, water). No other nodes are supported. This method takes an attribute on an emitter, and determines if there is a supported texture connected to it. If the texture is supported, then the  evalEmission2dTexture()  method can be called to evaluate the texture at various (u,v) coordinate values.'''
        pass

    def getOwnerShape(self): 
        '''getOwnerShape(self) -> MObject


If the emitter is a emitting from an object, this method returns the shape node for the object.'''
        pass

    def getRandomState(self, plugIndex, block): 
        '''getRandomState(self, plugIndex, block)
Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method copies the emitter node attribute representing the current random state for a particular emitter target into a local variable on the emitter object, to facilitate efficient random number generation using the  randgen()  method. See the documentation for  resetRandomState()  for a description of how to use this method in conjunction with the other random stream methods of this class.'''
        pass

    def getDeltaTime(self, plugIndex, block): 
        '''getDeltaTime(self, plugIndex, block) -> MTime
Returns: The time delta for the current emitter evaluation on the specified target. 

Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method returns the width of the time interval represented by the current emitter evaluation. Usually emitter emission rates are given as rates per second, so by converting this deltaTime value to seconds, plugin emitters can determine how many particles or how much fluid to emit in the current evaluation. This value is taken from the emitter's "deltaTime" attribute value, and can vary between different emitter targets (particle systems or fluid shapes into which the emitter is emitting), due to potential differences in oversampling settings. The "plugIndex" parameter indicates which target's time delta is being evaluated.'''
        pass

    def getStartTime(self, plugIndex, block): 
        '''getStartTime(self, plugIndex, block) -> MTime
Returns: The start time for the specified target, ie the time at which the emitter is to start emitting into that target. 

Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method returns the start times for each particle system or fluid into which the emitter is emitting. Each of these "targets" is identified by an index value corresponding to the order in which they are connected to the emitter. The start time value gives the time at which the given target is to start receiving particles or fluid. If the current time is less than the start time for a target, then nothing should be emitted into that target in the current evaluation. This value is taken by evaluating an element of the emitter node's "startTime" array attribute.'''
        pass

    def volumePrimitiveBoundingBox(self, box): 
        '''volumePrimitiveBoundingBox(self, box) -> bool
Returns: true if the emitter has an associated volume primitive, false otherwise. 

Arguments:
	[out]	box = MBoundingBox


For volume emitters, this method returns the object-space bounding box of the volume primitive associated with the emitter.'''
        pass

    def volumePrimitivePointInside(self, worldPoint, emitterWorldMatrix): 
        '''volumePrimitivePointInside(self, worldPoint, emitterWorldMatrix) -> bool
Returns: true if the point lies inside the emitter's volume primitive, false otherwise. 

Arguments:
	[in]	worldPoint = MPoint
	[in]	emitterWorldMatrix = MMatrix


For volume emitters, this method determines whether a particular point in space lies within the volume defined by the emitter's volume primitive.'''
        pass

    def resetRandomState(self, plugIndex, block): 
        '''resetRandomState(self, plugIndex, block)
Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method resets the emitter's random state data member. To implement repeatable randomized emitter behavior, the following steps should be followed:'''
        pass

    def getRate(self, block): 
        '''getRate(self, block) -> double
Returns: The emission rate for the emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "rate" attribute value common to all particle and fluid emitters. For particle emitters, this indicates the number of particles to be emitted per second. For fluid emitters, this value is usually used as a multiplier applied to the emission rates for various fluid grids such as density, temperature, etc.'''
        pass

    def getCurrentTime(self, block): 
        '''getCurrentTime(self, block) -> MTime
Returns: The time at which the emitter is being evaluated. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method returns the time at which the emitter is currently being evaluated. This is equivalent to querying the "currentTime" attribute on the emitter.'''
        pass

    def setRandomState(self, plugIndex, block): 
        '''setRandomState(self, plugIndex, block)
Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method copies the emitter node class random state data member onto the emitter node's random state attribute. See the documentation for  resetRandomState()  for a description of how to use this method in conjunction with the other random stream methods of this class.'''
        pass

    def kSurface(self):
        '''This is an enum of MEmitterType.
Description: 
Value: 2'''
        pass

    def kVolume(self):
        '''This is an enum of MEmitterType.
Description: 
Value: 4'''
        pass

    def kDirectional(self):
        '''This is an enum of MEmitterType.
Description: 
Value: 0'''
        pass

    def kCurve(self):
        '''This is an enum of MEmitterType.
Description: 
Value: 3'''
        pass

    def kOmni(self):
        '''This is an enum of MEmitterType.
Description: 
Value: 1'''
        pass

    class MEmitterType:
        '''Non-functional class.  Values for this enum:
        kSurface
        kVolume
        kDirectional
        kCurve
        kOmni
'''
        def __init__(self):
            pass

    def volumePrimitiveDistanceFromAxis(self, worldPoint, emitterWorldMatrix): 
        '''volumePrimitiveDistanceFromAxis(self, worldPoint, emitterWorldMatrix) -> double
Returns: The distance from the point to the major axis of the emitter's volume primitive. 

Arguments:
	[in]	worldPoint = MPoint
	[in]	emitterWorldMatrix = MMatrix


For volume emitters, this method determines the distance from a particular point to the major axis of the volumetric primitive associated with the emitter. For fluid emitters, this distance can be used to implement simple emission dropoff behavior.'''
        pass

    def draw(self, view, path, style): 
        '''draw(self, view, path, style)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath
	[in]	style = M3dView.DisplayStyle


Overriding this method allows the drawing of custom geometry using standard OpenGL calls. The OpenGL state should be left in the same state that it was in previously. The OpenGL routine glPushAttrib may be used to make this easier.'''
        pass

    def getWorldMatrix(self): 
        '''getWorldMatrix(self) -> MMatrix


Returns the matrix that maps from the emitter's local space coordinates to worldspace.'''
        pass

    def getRandomSeed(self, plugIndex, block): 
        '''getRandomSeed(self, plugIndex, block) -> int
Returns: The random seed value for the specified target. 

Arguments:
	[in]	plugIndex = int
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method returns the random seed for a specified emission target (particle system or fluid shape into which the emitter is emitting). This seed value is set on the target itself, and should be used to ensure that any randomized emission behavior is repeatable when animations are played back repeatedly. The  resetRandomState()  method uses this value (see its documentation for details on how to implement repeatable randomized behaviour in emitters). This value is obtained by evaluating an element of the emitter's "seed" array attribute.'''
        pass

    def getWorldPosition(self): 
        '''getWorldPosition(self) -> MPoint


Returns the worldspace coordinates of the emitter. For curve, surface, and volume emitters, this returns the worldspace coordinates of the center of the emitter's local space. For point emitters, this value usually corresponds to the position of the emitter object itself.'''
        pass

    def getEmitterType(self, block): 
        '''getEmitterType(self, block) -> MPxEmitterNode.MEmitterType
Returns: An MEmitterType value representing the type of emitter (directional, omni, surface, curve, or volume) 

Arguments:
	[out]	block = MDataBlock


Retrieves the type of the emitter, determined by the "emitterType" attribute value. This is intended to be called from within the emitter's  compute()  method, in order to decide how the emitter should behave when evaluated.'''
        pass

    def getMinDistance(self, block): 
        '''getMinDistance(self, block) -> double
Returns: The minimum emission distance for the emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "minDistance" attribute value common to all particle and fluid emitters. This value indicates the minimum distance from the emitter center at which fluid or particles will be emitted.'''
        pass

    def evalEmission2dTexture(self, texAttr, uCoords, vCoords, resultColors, resultAlphas): 
        '''evalEmission2dTexture(self, texAttr, uCoords, vCoords, resultColors, resultAlphas)
Arguments:
	[in]	texAttr = MObject
	[in]	uCoords = MDoubleArray
	[in]	vCoords = MDoubleArray
	[out]	resultColors = MVectorArray
	[out]	resultAlphas = MDoubleArray


If a supported 2d texture (see  hasValidEmission2dTexture()  method documentation) is connected to the given emitter attribute, this method can be called to evaluate that texture at a number of (u,v) texture coordinate values.'''
        pass

    def compute(self, plug, dataBlock): 
        '''compute(self, plug, dataBlock)
Arguments:
	[in]	plug = MPlug
	[out]	dataBlock = MDataBlock


This method should be overridden in user defined nodes.'''
        pass

    def getMaxDistance(self, block): 
        '''getMaxDistance(self, block) -> double
Returns: The maximum emission distance for the emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "maxDistance" attribute value common to all particle and fluid emitters. This value indicates the maximum distance from the emitter center at which fluid or particles will be emitted.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. It should not be overridden by the user. It will return  MPxNode::kEmitterNode .'''
        pass

    def randgen(self): 
        '''randgen(self) -> double


Intended to be called from within the emitter's  compute()  method, this method generates a double-precision random number in the rand [0,1]. The emitter object's random state data member is used to generate the random number, and will be updated after the number is generated. To generate a stream of random numbers for a particular target, ensure that  getRandomState()  is called before calling  randgen() , and that  setRandomState()  is called after all the random numbers have been generated. See the documentation for  resetRandomState()  for a description of how to use this method in conjunction with the other random stream methods of this class.'''
        pass

class MPxFieldNode:
    '''Base class for user defined fields. MPxFieldNode allows the creation and manipulation of dependency graph nodes representing fields. This is the top level of a hierarchy of field node function sets. It permits manipulation of the attributes common to all types of fields. '''
    def __init__(self):
        pass


    mDeltaTime = ''
    '''child attribute '''

    mOwnerCentroidX = ''
    '''X component of mOwnerCentroid. '''

    mInputPPData = ''
    '''Attribute for input pp data from particleShape. '''

    mInputVelocities = ''
    '''child attribute, multi '''

    mInputPositions = ''
    '''child attribute, multi '''

    mInputForce = ''
    '''forces input attribute, multi '''

    mWorldMatrix = ''
    '''world matrix attribute '''

    mOwnerVelData = ''
    '''owner velocity attribute, multi '''

    mMagnitude = ''
    '''magnitude attribute '''

    mOwnerCentroid = ''
    '''owner centroid attribute '''

    mApplyPerVertex = ''
    '''flag for per vertex attribute '''

    mOwnerPosData = ''
    '''owner position attribute, multi '''

    mAttenuation = ''
    '''attenuation attribute '''

    mOwnerCentroidY = ''
    '''Y component of mOwnerCentroid. '''

    mInputMass = ''
    '''child attribute, multi '''

    mOwnerCentroidZ = ''
    '''Z component of mOwnerCentroid. '''

    mMaxDistance = ''
    '''maximum distance attribute '''

    mUseMaxDistance = ''
    '''flag for maximum distance attribute '''

    mOutputForce = ''
    '''forces output attribute, multi '''

    mOwnerPPData = ''
    '''Attribute for input pp data from owner particleShape. '''

    mInputData = ''
    '''input attribute compound, multi '''

    def isFalloffCurveConstantOne(self): 
        '''isFalloffCurveConstantOne(self) -> bool
Returns: true if the falloff curve is a constant one, false otherwise


Returns true if the falloffCurve is a constant one (default) or false if not.'''
        pass

    def draw(self, view, path, style): 
        '''draw(self, view, path, style)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath
	[in]	style = M3dView.DisplayStyle


Overriding this method allows the drawing of custom geometry using standard OpenGL calls. The OpenGL state should be left in the same state that it was in previously. The OpenGL routine glPushAttrib may be used to make this easier.'''
        pass

    def compute(self, plug, dataBlock): 
        '''compute(self, plug, dataBlock)
Arguments:
	[in]	plug = MPlug
	[out]	dataBlock = MDataBlock


This method should be overridden in user defined nodes.'''
        pass

    def iconSizeAndOrigin(self, width, height, xbo, ybo): 
        '''iconSizeAndOrigin(self, width, height, xbo, ybo)
Arguments:
	[in]	width = MPxFieldNode.GLuint
	[in]	height = MPxFieldNode.GLuint
	[in]	xbo = MPxFieldNode.GLuint
	[in]	ybo = MPxFieldNode.GLuint


This method is not required to be overridden. The arguments have the same meaning as defined in OpenGL's glBitmap method.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kFieldNode .'''
        pass

    def falloffCurve(self, param): 
        '''falloffCurve(self, param) -> double
Returns: The falloff value at the given the param.

Arguments:
	[in]	param = double


Returns the falloff at the given parameter value.'''
        pass

    def getForceAtPoint(self, point, velocity, mass, deltaTime, force): 
        '''getForceAtPoint(self, point, velocity, mass, deltaTime, force)
Arguments:
	[in]	point = MVectorArray
	[in]	velocity = MVectorArray
	[in]	mass = MDoubleArray
	[out]	force = MVectorArray
	[in]	deltaTime = double


This method is not required to be overridden, it is only necessary for compatibility with the  MFnField  function set.'''
        pass

    def iconBitmap(self, bitmap): 
        '''iconBitmap(self, bitmap)
Arguments:
	[in]	bitmap = MPxFieldNode.GLubyte


This method is not required to be overridden. The arguments have the same meaning as defined in OpenGL's glBitmap method.'''
        pass

class MPxFileTranslator:
    '''Base Class for creating Maya File Translators. This class provides the connection to Maya by which user written file translators can be added as plug-ins.This class provides a base class from which one derives in order to implement Maya "File Translator Plug-Ins." A file translator plug-in allows Maya to read or write 3rd party file formats.The identifyFile method is called whenever Maya's file save or restore dialogs are run, and identifyFile uses the filename and first few bytes of the file to determine whether it is of a type supported by the translator. If it is, then Maya will display the file with the "name" and "icon" specified as arguments to MFnPlugin::registerFileTranslator.If an attempt is made to read the file, the "reader" method in the derived class is called, if an attempt is made to write the file, the "writer" method is called. '''
    def __init__(self):
        pass


    def writer(self, file, optionsString, mode): 
        '''writer(self, file, optionsString, mode)
Arguments:
	[in]	file = MFileObject
	[in]	optionsString = MString
	[in]	mode = MPxFileTranslator.FileAccessMode


This routine is called by Maya when it is necessary to save a file of a type supported by this translator.'''
        pass

    def haveNamespaceSupport(self): 
        '''haveNamespaceSupport(self) -> bool


When a file is imported or referenced into an existing scene, there is the possibility that nodes in the incoming file will have the same names as nodes already in the scene. Although DAG nodes may legally have the same name so long as their DAG paths are different, in all other cases node names must be unique.'''
        pass

    def canBeOpened(self): 
        '''canBeOpened(self) -> bool


This routine is called by Maya while it is executing in the  MPxFileTranslator  constructor. Maya uses this entry point to query the translator and determine if it can open files. The default is  true .'''
        pass

    def haveReadMethod(self): 
        '''haveReadMethod(self) -> bool


This routine is called by Maya while it is executing in the  MPxFileTranslator  constructor. Maya uses this entry point to query the translator and determine if it provides a reader method.'''
        pass

    def filter(self): 
        '''filter(self) -> MString


This virtual method may be overloaded in a derived class to set the filter extension that will be used by the file dialog. If this method is not implemented in a derived class, the standard filter *.* will be returned by  MPxFileTranslator  and used by the file dialog.'''
        pass

    def haveWriteMethod(self): 
        '''haveWriteMethod(self) -> bool


This routine is called by Maya while it is executing in the  MPxFileTranslator  constructor. Maya uses this entry point to query the translator and determine if it provides a write method.'''
        pass

    def kCouldBeMyFileType(self):
        '''This is an enum of MFileKind.
Description: Translator is not best available to read/write this file.
Value: 1'''
        pass

    def kNotMyFileType(self):
        '''This is an enum of MFileKind.
Description: Translator does not understand how to read/write this file.
Value: 2'''
        pass

    def kIsMyFileType(self):
        '''This is an enum of MFileKind.
Description: Translator understands how to read/write this file.
Value: 0'''
        pass

    class MFileKind:
        '''Non-functional class.  Values for this enum:
        kCouldBeMyFileType
        kNotMyFileType
        kIsMyFileType
'''
        def __init__(self):
            pass

    def haveReferenceMethod(self): 
        '''haveReferenceMethod(self) -> bool


This routine is called by Maya while it is executing in the  MPxFileTranslator  constructor. Maya uses this entry point to query the translator and determine if it provides a reference method.'''
        pass

    def defaultExtension(self): 
        '''defaultExtension(self) -> MString


This routine is called by Maya whenever it needs to know the default extension of a translator.'''
        pass

    def reader(self, file, optionsString, mode): 
        '''reader(self, file, optionsString, mode)
Arguments:
	[in]	file = MFileObject
	[in]	optionsString = MString
	[in]	mode = MPxFileTranslator.FileAccessMode


This routine is called by Maya when it is necessary to load a file of a type supported by this translator.'''
        pass

    def identifyFile(self, file, buffer, size): 
        '''identifyFile(self, file, buffer, size) -> MPxFileTranslator.MFileKind
Returns: MFileKind::kIsMyFileType this file is understood by this translator 
MFileKind::kNotMyFileType this file is not understood by this translator 
MFileKind::kCouldBeMyFileType this file is understood by this translator, but this translator is not the best one to use for reading or writing it 

Arguments:
	[in]	file = MFileObject
	[in]	buffer = char
	[in]	size = short


This routine is called by Maya when a file selection dialog accesses a new directory. It will potentially be called once for every file in the directory.'''
        pass

    def fileAccessMode(self): 
        '''fileAccessMode(self) -> MPxFileTranslator.FileAccessMode


This routine returns the fileAccess mode maya is currently in.'''
        pass

    def kExportActiveAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Export active (selected) data.
Value: 6'''
        pass

    def kUnknownAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Unknown file access mode.
Value: 0'''
        pass

    def kOpenAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Import data into new scene.
Value: 1'''
        pass

    def kExportAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Export data.
Value: 5'''
        pass

    def kSaveAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Save data.
Value: 4'''
        pass

    def kImportAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Import data into current scene.
Value: 3'''
        pass

    def kReferenceAccessMode(self):
        '''This is an enum of FileAccessMode.
Description: Reference data into current scene.
Value: 2'''
        pass

    class FileAccessMode:
        '''Non-functional class.  Values for this enum:
        kExportActiveAccessMode
        kUnknownAccessMode
        kOpenAccessMode
        kExportAccessMode
        kSaveAccessMode
        kImportAccessMode
        kReferenceAccessMode
'''
        def __init__(self):
            pass

class MPxFluidEmitterNode:
    '''Base class for user defined particle emitters. MPxFluidEmitterNode allows the creation and manipulation of dependency graph nodes representing fluid emitters. '''
    def __init__(self):
        pass


    mFluidFuelEmission = ''
    '''fuel emission rate attribute '''

    mFluidColorG = ''
    '''emission green color channel attribute '''

    mFluidColorR = ''
    '''emission red color channel attribute '''

    mFluidColorB = ''
    '''emission blue color channel attribute '''

    mEmissionFunction = ''
    '''emission function attribute '''

    mFluidDropoff = ''
    '''emission dropoff attribute '''

    mFluidHeatEmission = ''
    '''heat emission rate attribute '''

    mFluidDensityEmission = ''
    '''density emission rate attribute '''

    mFluidColor = ''
    '''emission color attribute '''

    mEmitFluidColor = ''
    '''color emission toggle attribute '''

    mTurbulence = ''
    '''emission turbulence attribute '''

    mFluidJitter = ''
    '''emission jitter attribute '''

    def fluidJitter(self, block): 
        '''fluidJitter(self, block) -> bool
Returns: true if jitter should be applied to the emission behavior, false otherwise. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidJitter" attribute value common to all fluid emitters. This specifies how the voxel grid should be sampled for emission. Without jitter, the grid is sampled only at voxel centers, but with jitter enabled, each voxel is sampled at a random location. The fluid emitter is responsible for implementing this behavior. It is recommended that the random stream methods on  MPxEmitterNode  be used to implement repeatable randomized behavior in this area.'''
        pass

    def compute(self, plug, dataBlock): 
        '''compute(self, plug, dataBlock)
Arguments:
	[in]	plug = MPlug
	[out]	dataBlock = MDataBlock


This method should be overridden in user defined nodes.'''
        pass

    def fluidDensityEmission(self, block): 
        '''fluidDensityEmission(self, block) -> double
Returns: The fluid density emission rate for the fluid emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidDensityEmission" attribute value common to all fluid emitters. This indicates the amount of fluid material to be emitted per second, and it is modulated by the emitter's "rate" attribute value.'''
        pass

    def fluidEmitColor(self, block): 
        '''fluidEmitColor(self, block) -> bool
Returns: true if the emitter should emit color into the fluid, false otherwise. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidEmitColor" attribute value common to all fluid emitters. This indicates whether or not the emitter should emit color into the fluid.'''
        pass

    def fluidDropoff(self, block): 
        '''fluidDropoff(self, block) -> double
Returns: The dropoff rate for the fluid emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidDropoff" attribute value common to all fluid emitters. This specifies the the speed with which fluid emission drops off with increasing distance from the emitter, with higher values meaning faster dropoff.'''
        pass

    def fluidFuelEmission(self, block): 
        '''fluidFuelEmission(self, block) -> double
Returns: The fluid fuel emission rate for the fluid emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidFuelEmission" attribute value common to all fluid emitters. This indicates the amount of fuel to be emitted per second, and it is modulated by the emitter's "rate" attribute value.'''
        pass

    def turbulence(self, block): 
        '''turbulence(self, block) -> double
Returns: The turbulence value for the fluid emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "turbulence" attribute value common to all fluid emitters. This specifies the amount of turbulence that should be applied to the emitter's output.'''
        pass

    def fluidHeatEmission(self, block): 
        '''fluidHeatEmission(self, block) -> double
Returns: The fluid heat emission rate for the fluid emitter. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidHeatEmission" attribute value common to all fluid emitters. This indicates the amount of heat to be emitted per second, and it is modulated by the emitter's "rate" attribute value.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. It should not be overridden by the user. It will return  MPxNode::kEmitterNode .'''
        pass

    def fluidEmitter(self, fluidObj, worldMatrix, plugIndex): 
        '''fluidEmitter(self, fluidObj, worldMatrix, plugIndex)
Arguments:
	[in]	fluidObj = MObject
	[in]	worldMatrix = MMatrix
	[in]	plugIndex = int


This is the main method that plug-in fluid emitter nodes must override in order to emit into fluids. When an emitter is attached to a fluid, at every evaluation step the fluid will call this method on the emitter. The method receives a fluid object into which to emit, the index of the fluid in the array of fluid targets for this emitter, and the worldspace matrix of the fluid. The emitter should query its attributes to determine how much density, heat, color, and/or fuel to emit into the fluid, then call the  MFnFluid::emitIntoArrays()  method to actually add the necessary quantities to the fluid.'''
        pass

    def fluidColor(self, block): 
        '''fluidColor(self, block) -> MColor
Returns: The color that should be emitted into the fluid. 

Arguments:
	[out]	block = MDataBlock


Intended to be called from within the emitter's  compute()  method, this method retrieves the "fluidColor" attribute value common to all fluid emitters. This specifies the color to be added to the fluid.'''
        pass

class MPxGeometryData:
    '''Base Class for User-defined Dependency Graph Geometry Data Types. This class is used to provide a wrapper or container for some arbitrary geometry type that you have defined. This allows your data type to exist as typed attributes on dependency nodes and to be passed through dependency graph connections.MP`xGeometryData is similar to MPxData but includes methods to support sets (also known as groups) and component iteration.For user defined shapes (MPxSurfaceShape derived classes), in order to support maya's deformers you must declare an MPxGeometryData class as well as a geometry iterator (MPxGeometryIterator).To register geometry data use MFnPlugin::registerData with the type argument equal to MPxData::kGeometryData. '''
    def __init__(self):
        pass


    def smartCopy(self, srcGeom): 
        '''smartCopy(self, srcGeom)
Arguments:
	[in]	srcGeom = MPxGeometryData


This method is used in conjunction with  MPxSurfaceShape  classes which support maya's deformations.'''
        pass

    def name(self): 
        '''name(self) -> MString


Determines the type name of the Data object. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def iterator(self, componentList, component, useComponents, world): 
        '''iterator(self, componentList, component, useComponents, world) -> MPxGeometryIterator
Returns: A pointer to an iterator for your geometry 

Arguments:
	[in]	componentList = MObjectArray
	[in]	component = MObject
	[in]	useComponents = bool
	[in]	world = bool


Associates a control point based geometry iterator with this data. This method is used in conjunction with  MPxSurfaceShape  and should be overridden if your shape is to support maya's deformations.'''
        pass

    def typeId(self): 
        '''typeId(self) -> MTypeId


Determines the type id of the Data object. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def MMatrix(self): 
        '''MMatrix(self) -> const


Return the matrix associated to  MPxGeometryData .'''
        pass

    def setMatrix(self, m): 
        '''setMatrix(self, m)
Arguments:
	[in]	m = MMatrix


Store the matrix associated to  MPxGeometryData . The matrix transformation will take place when the data is used, for example in deformer.'''
        pass

    def deleteComponentsFromGroups(self, compList, groupIdArray, groupComponentArray): 
        '''deleteComponentsFromGroups(self, compList, groupIdArray, groupComponentArray) -> bool
Returns: true if the deletion was successfull, false otherwise 

Arguments:
	[in]	compList = MObjectArray
	[in]	groupIdArray = MIntArray
	[in]	groupComponentArray = MObjectArray


This method should be overridden to modify the groups that flows along with the geometry, as part of the data, based on the components being deleted. It should intelligently update the groups based on what gets deleted. The class  MFnGeometryData  can be used to access and modify grouping information for data.'''
        pass

    def copy(self, src): 
        '''copy(self, src)
Arguments:
	[in]	src = MPxData


This method initializes an instance of an  MPxGeometryData  derived class from another existing instance. This method can be thought of as the  second half  of a copy constructor for the class. The default constructor has already been called for the instance, and this method is used to set the private data by copying the values from an existing instance. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def updateCompleteVertexGroup(self, component): 
        '''updateCompleteVertexGroup(self, component) -> bool
Returns: Returns true if the component was updated, false if it was already complete 

Arguments:
	[in]	component = MObject


This method is used in conjunction with  MPxSurfaceShape  classes which support maya's deformations.'''
        pass

    def deleteComponent(self, compList): 
        '''deleteComponent(self, compList) -> bool
Returns: true if the deletion was successfull, false otherwise 

Arguments:
	[in]	compList = MObjectArray


This method should be overridden if this data is to support component deletion. For user defined shapes ( MPxSurfaceShape ) which support components, this method must be overridden if component deletion is to be supported when the shape has history.'''
        pass

    def matrix(self, m): 
        '''matrix(self, m) -> bool
Returns: true if m is not an identity matrix, false otherwise 

Arguments:
	[out]	m = MMatrix


Return the matrix associated to  MPxGeometryData .'''
        pass

class MPxGeometryIterator:
    '''Base class for user defined geometry iterators. This is the base class for user defined geometry iterators. Geometry iterator allow iterating over components in geometry in a geometry independent manner. This base class defines the interface to be used by maya when a generic component iteration is required.This class is used in conjunction with MPxSurfaceShape to provide an iterator for components in a user defined shape. Also this method can is used by MPxGeometryData to provide an iterator over geometry that is passed through DG connections.The main methods to override in this class are point and setPoint. The reset, isDone, and next methods have a default implementation and should only be overridden if the component being iterator on is not a single indexed component type.The iterator works in two modes, over components or over all elements in some geometry. If the components passed into the constructors are null or empty then the iteration is meant to be over the entire object. '''
    def __init__(self):
        pass


    def reset(self): 
        '''reset(self)

Resets the iterator to the start of the components so that another pass over them may be made. 
  Reprocessed example  
 Examples: 
 
   
 apiMeshIterator.cpp ,  apiMeshIterator.h ,  apiSimpleShapeIterator.cpp , and  apiSimpleShapeIterator.h . 
 
'''
        pass

    def index(self): 
        '''index(self) -> int


Returns a unique index for the current item in the iteration. If the iteration is over the whole geometry then this index is the same as current point. If the iteration is over some elements of the geometry specified by a component then this index is the index in your geometry.'''
        pass

    def setObject(self, shape): 
        '''setObject(self, shape)
Arguments:
	[in]	shape = MPxSurfaceShape


Optional method to set a shape object to iterate over to allow tweaking of the shape's history (input geometry).'''
        pass

    def indexUnsimplified(self): 
        '''indexUnsimplified(self) -> int


Returns a unique index for the current item in the iteration Rather than being the iterator index this is the index for the actual item when simplification is skipping items. This index will be equal to  index()  if no simplification, otherwise it will be larger.'''
        pass

    def iteratorCount(self): 
        '''iteratorCount(self) -> int


Returns an estimate of how many items will be iterated over.'''
        pass

    def point(self): 
        '''point(self) -> MPoint


Returns the current component's positional data.'''
        pass

    def geometry(self): 
        '''geometry(self) -> void*

'''
        pass

    def setPoint(self, point): 
        '''setPoint(self, point)
Arguments:
	[in]	point = MPoint


Sets the current component's positional data.'''
        pass

    def component(self, component): 
        '''component(self, component)
Arguments:
	[out]	component = MObject


Returns a component for the current item in the iteration.'''
        pass

    def next(self): 
        '''next(self)
'''
        pass

    def hasNormals(self): 
        '''hasNormals(self) -> bool


Indicates whether the underlying geometry has normals.'''
        pass

    def hasPoints(self): 
        '''hasPoints(self) -> bool


Indicates whether the underlying geometry has point data.'''
        pass

    def currentPoint(self): 
        '''currentPoint(self) -> int


Returns the index that is being iterated on. This value is used when iterating over all elements of your geometry, i.e. when there are no components specified.'''
        pass

    def setCurrentPoint(self, index): 
        '''setCurrentPoint(self, index)
Arguments:
	[in]	index = int


Set the current index of the iteration. This value is used when iterating over all elements of your geometry, i.e. when there are no components specified.'''
        pass

    def setPointGetNext(self, point): 
        '''setPointGetNext(self, point) -> int
Returns: The next index value 

Arguments:
	[in]	point = MPoint


Sets the current component's positional data, gets the next point.'''
        pass

    def maxPoints(self): 
        '''maxPoints(self) -> int


Returns the largest index that will be iterated over. This value is used when iterating over all elements of your geometry, i.e. when there are no components specified.'''
        pass

    def isDone(self): 
        '''isDone(self) -> bool


Indicates if all the items have been traversed yet.'''
        pass

    def setMaxPoints(self, index): 
        '''setMaxPoints(self, index)
Arguments:
	[in]	index = int


Sets the largest index that will be iterated over. This value is used when iterating over all elements of your geometry, i.e. when there are no components specified.'''
        pass

class MPxGlBuffer:
    '''Base class for user defined GL buffers. This is the base class for user defined GL buffers, however; it is seldom necessary to derive from this class. It is generally suficient to directly use it. In cases where creating a child class is desirable, it will only work if  overridden method calls the parent method at some point in its execution.There are two basic ways to use this class, to draw to a pbuffer and to draw to an external window:To draw to a pbuffer:To draw to an externally defined window:Note: It is usually a good idea to use the MPxGlBuffer( M3dView &view ) form of the constructor to insure that the context created is done so correctly.NOTE: This class only works with the Linux version of Maya. '''
    def __init__(self):
        pass


    def close(self): 
        '''close(self)

Close and deallocate the actual pixel buffer.'''
        pass

    def beginBufferNotify(self): 
        '''beginBufferNotify(self)

This method is called when the GL buffer is being setup by the viewport renderer. Overriding this call will allow you to access the full GL state after it has been setup but before any drawing has occurred.'''
        pass

    def endBufferNotify(self): 
        '''endBufferNotify(self)

This method is called when the GL buffer is being shutdown by the viewport renderer. Overriding this call will allow you to access the full GL state after drawing has completed but just before the GL buffer is shut down.'''
        pass

class MPxHardwareShader:
    '''Base class for user defined hardware shaders. MPxHardwareShader allows the creation of user-defined hardware shaders. A hardware shader allows the plug-in writer to control the on-screen display of an object in Maya.You must derive a hardware shader node from MPxHardwareShader for it to have any affect on the on-screen display at all. In addition to their affect on the on-screen display of objects, hardware shaders function as surface shader nodes. This allows you to connect any shading network up to the hardware shader's outColor attribute to handle the shading during a software render.To create a working hardware shader, derive from this class and override the render() and optionally the populateRequirements() methods. The other methods of the parent class MPxNode may also be overridden to perform dependency node capabilities.NOTE: Plug-in hardware shaders are fully supported for polygonal mesh shapes. NURBS surfaces are only supported in the High Quality Interactive viewport and Hardware Renderer. '''
    def __init__(self):
        pass


    outColorR = ''
    '''output color red '''

    outColor = ''
    '''output color value '''

    outColorB = ''
    '''output color blue '''

    outColorG = ''
    '''output color green '''

    def MRenderProfile(self): 
        '''MRenderProfile(self) -> const


Override this method to specify the renderers your shader supports. If this method is not overridden, Maya will assume your shader supports only Maya's iternal OpenGL based renderer.'''
        pass

    def kNoTransparencyPolygonSort(self):
        '''This is an enum of TransparencyOptions.
Description: When set means ignore polygon sorting.
Value: 4'''
        pass

    def kIsTransparent(self):
        '''This is an enum of TransparencyOptions.
Description: When set means draw transparent.
Value: 1'''
        pass

    def kNoTransparencyFrontBackCull(self):
        '''This is an enum of TransparencyOptions.
Description: When set means ignore front back cull.
Value: 2'''
        pass

    class TransparencyOptions:
        '''Non-functional class.  Values for this enum:
        kNoTransparencyPolygonSort
        kIsTransparent
        kNoTransparencyFrontBackCull
'''
        def __init__(self):
            pass

    def renderImage(self, context, imageName, region, imageWidth, imageHeight): 
        '''renderImage(self, context, imageName, region, imageWidth, imageHeight)
Arguments:
	[in]	context = MPxHardwareShader.ShaderContext
	[in]	imageName = MString
	[in]	region = floatRegion
	[out]	imageWidth = int
	[out]	imageHeight = int


 This method is not available in Python. 
'''
        pass

    def getAvailableImages(self, context, uvSetName, imageNames): 
        '''getAvailableImages(self, context, uvSetName, imageNames)
Arguments:
	[out]	context = MPxHardwareShader.ShaderContext
	[out]	uvSetName = MString
	[out]	imageNames = MStringArray


 This method is not available in Python. 
'''
        pass

    def render(self, iterator): 
        '''render(self, iterator)
Arguments:
	[in]	iterator = MGeometryList


Override this method to render geometry using your hardware shader. It is important to note that you can only access surface data (e.g. uv sets) that you specified in populateRequirements. Any data you did not ask for is unlikely to be available in the geometry cache passed to you.'''
        pass

    def setVaryingParameters(self, parameters, remapCurrentValues, dagModifier): 
        '''setVaryingParameters(self, parameters, remapCurrentValues, dagModifier)
Arguments:
	[in]	parameters = MVaryingParameterList
	[in]	remapCurrentValues = bool
	[in]	dagModifier = MDagModifier


Call this method to set the list of varying parameters this shader uses. Once set, you can use these parameters directly to access geometry data for surfaces being shaded. When using this method to manage shader varying parameters, there is no need to override populateRequirements or handle the node interface as Maya will handle parameter setup, presentation and configuration for you.'''
        pass

    def populateRequirements(self, context, requirements): 
        '''populateRequirements(self, context, requirements)
Arguments:
	[in]	context = MPxHardwareShader.ShaderContext
	[out]	requirements = MGeometryRequirements


Override this method to let Maya know what surface data (e.g. positions, normals, uv sets, tangents, binormals, etc) you shader needs in order to render the specified geometry. This is the only data your shader will be able to access when rendering the geometry. For example, if your shader needs uv set "foo" to render a texture, you must include that here before trying to use it in your render method.'''
        pass

    def getHardwareShaderPtr(self, object): 
        '''getHardwareShaderPtr(self, object) -> MPxHardwareShader
Returns: A pointer to an MPxHardwareShader. If the method failed for any reason then a 0 (null) will be returned. 

Arguments:
	[in]	object = MObject


This is a static convenience method to be able to get an  MPxHardwareShader  from an  MObject  provided by a swatch generator class (Class derived from  MSwatchRenderRegister ).'''
        pass

    def setUniformParameters(self, parameters, remapCurrentValues, dagModifier): 
        '''setUniformParameters(self, parameters, remapCurrentValues, dagModifier)
Arguments:
	[in]	parameters = MUniformParameterList
	[in]	remapCurrentValues = bool
	[in]	dagModifier = MDagModifier


Call this method to set the list of uniform parameters this shader uses. Once set, you can use these parameters to access the cached values of shader parameters, including testing when the value has been updated (to minimise the shader state changes). When using this method to manage uniform parameters, Maya will handle the underlyintg attributes, serialization and user interface for you.'''
        pass

    def findResource(self, name, shaderPath): 
        '''findResource(self, name, shaderPath) -> MString
Returns: The full path of the resource (e.g. "C:/shaders/textures/normals.dds") 

Arguments:
	[in]	name = MString
	[in]	shaderPath = MString


This is a static utility to find the full path to a shader resource (typically a texture). This method will search the list of paths in the MAYA_HW_SHADER_RESOURCE_PATH environment variable, resolving relative paths based on the directory containing the shader.'''
        pass

    def transparencyOptions(self): 
        '''transparencyOptions(self) -> int


This method returns transparency options for usage as hints for Maya's internal draw during a given rendering pass. Parameters are returned via an integer containing masked out bits. By default the mask is set to 0, meaning that the drawing should be treated as regular opaque object drawing. This will generally mean one call per draw pass.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kHwShaderNode .'''
        pass

    def renderSwatchImage(self, image): 
        '''renderSwatchImage(self, image)
Arguments:
	[in]	image = MImage


If the shader specifies to override swatch rendering, then this method must be overridden in order to draw anything into a swatch. The default implementation is to draw nothing. The basic logic to draw a swatch is as follows:'''
        pass

class MPxHwShaderNode:
    '''Base class for user defined hardware shaders. MPxHwShaderNode allows the creation of user-defined hardware shaders. A hardware shader allows the plug-in writer to control the on-screen display of an object in Maya.You must derive a hardware shader node from MPxHwShaderNode for it to have any affect on the on-screen display at all. In addition to their affect on the on-screen display of objects, hardware shaders function as surface shader nodes. This allows you to connect any shading network up to the hardware shader's outColor attribute to handle the shading during a software render.To create a working hardware shader, derive from this class and override the bind(), unbind(), and geometry() methods. If your hardware shader uses texture coordinates from Maya, you also need to override either texCoordsPerVertex or getTexCoordSetNames(). The other methods of the parent class MPxNode may also be overridden to perform dependency node capabilities.NOTE: Plug-in hardware shaders are fully supported for polygonal mesh shapes. NURBS surfaces are only supported in the High Quality Interactive viewport and Hardware Renderer if the glBind/glGeometry/glUnbind methods of this class are implemented. '''
    def __init__(self):
        pass


    outColorB = ''
    '''output color blue '''

    outTransparencyR = ''
    '''output transparency red '''

    outGlowColorG = ''
    '''output glow color green '''

    outColorG = ''
    '''output color green '''

    outMatteOpacity = ''
    '''output matte opacity value '''

    outMatteOpacityB = ''
    '''output matte opacity blue '''

    outGlowColorB = ''
    '''output glow color blue '''

    outMatteOpacityG = ''
    '''output matte opacity green '''

    outColorR = ''
    '''output color red '''

    outColor = ''
    '''output color value '''

    outGlowColor = ''
    '''output glow color value '''

    outTransparencyG = ''
    '''output transparency green '''

    outGlowColorR = ''
    '''output glow color red '''

    outMatteOpacityR = ''
    '''output matte opacity red '''

    outTransparency = ''
    '''output transparency value '''

    outTransparencyB = ''
    '''output transparency blue '''

    def supportsBatching(self): 
        '''supportsBatching(self) -> bool


Specifies whether or not this shader supports batched rendering of shapes.'''
        pass

    def dirtyMask(self): 
        '''dirtyMask(self) -> int


This method returns a "dirty" mask that indicates which geometry items have changed from the last invocation of the plugin to draw. The mask is valid at the time that  geometry()  or  glGeometry()  is called and at no other time.'''
        pass

    def invertTexCoords(self): 
        '''invertTexCoords(self) -> bool


Specifies whether this shader requires inverted texture coordinates. (i.e. where the top-left hand corner of UV space is (0,0) instead of the bottom-left corner).'''
        pass

    def transparencyOptions(self): 
        '''transparencyOptions(self) -> int


This method returns transparency options for usage as hints for Maya's internal draw during a given rendering pass. Parameters are returned via an integer containing masked out bits. By default the mask is set to 0, meaning that the drawing should be treated as regular opaque object drawing. This will generally mean one call per draw pass.'''
        pass

    def currentShadingEngine(self): 
        '''currentShadingEngine(self) -> MObject


This method returns an  MObject  to the shading engine that is currently being rendered. This method will only return a valid  MObject  during the following calls:'''
        pass

    def glGeometry(self, shapePath, prim, indexCount, indexArray, vertexCount, vertexIDs, vertexArray, normalCount, normalArrays, colorCount, colorArrays, texCoordCount, texCoordArrays, writable): 
        '''glGeometry(self, shapePath, prim, indexCount, indexArray, vertexCount, vertexIDs, vertexArray, normalCount, normalArrays, colorCount, colorArrays, texCoordCount, texCoordArrays, writable)
Arguments:
	[in]	shapePath = MDagPath
	[in]	prim = int
	[out]	writable = int
	[in]	indexCount = int
	[in]	indexArray = int
	[in]	vertexCount = int
	[in]	vertexIDs = int
	[in]	vertexArray = float
	[in]	normalCount = int
	[in]	normalArrays = floatArrayPtr
	[in]	colorCount = int
	[in]	colorArrays = floatArrayPtr
	[in]	texCoordCount = int
	[in]	texCoordArrays = floatArrayPtr


This method should only be overridden for hardware rendering.'''
        pass

    def kWriteAll(self):
        '''This is an enum of Writeable.
Description: 
Value: 15'''
        pass

    def kWriteNormalArray(self):
        '''This is an enum of Writeable.
Description: 
Value: 2'''
        pass

    def kWriteVertexArray(self):
        '''This is an enum of Writeable.
Description: 
Value: 1'''
        pass

    def kWriteTexCoordArrays(self):
        '''This is an enum of Writeable.
Description: 
Value: 8'''
        pass

    def kWriteNone(self):
        '''This is an enum of Writeable.
Description: 
Value: 0'''
        pass

    def kWriteColorArrays(self):
        '''This is an enum of Writeable.
Description: 
Value: 4'''
        pass

    class Writeable:
        '''Non-functional class.  Values for this enum:
        kWriteAll
        kWriteNormalArray
        kWriteVertexArray
        kWriteTexCoordArrays
        kWriteNone
        kWriteColorArrays
'''
        def __init__(self):
            pass

    def glUnbind(self, shapePath): 
        '''glUnbind(self, shapePath)
Arguments:
	[in]	shapePath = MDagPath


This method should only be overridden for hardware rendering.'''
        pass

    def hasTransparency(self): 
        '''hasTransparency(self) -> bool


This method returns a boolean value that indicates whether the object will be drawn transparently or not. Transparent objects must be drawn after all the opaque objects in the scene or they will not display correctly. Maya uses the return value to determine when it can draw this shape.'''
        pass

    def kDirtyColorArrays(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 4'''
        pass

    def kDirtyTexCoordArrays(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 8'''
        pass

    def kDirtyVertexArray(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 1'''
        pass

    def kDirtyNone(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 0'''
        pass

    def kDirtyNormalArray(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 2'''
        pass

    def kDirtyAll(self):
        '''This is an enum of DirtyMask.
Description: 
Value: 15'''
        pass

    class DirtyMask:
        '''Non-functional class.  Values for this enum:
        kDirtyColorArrays
        kDirtyTexCoordArrays
        kDirtyVertexArray
        kDirtyNone
        kDirtyNormalArray
        kDirtyAll
'''
        def __init__(self):
            pass

    def MDagPath(self): 
        '''MDagPath(self) -> const


This method returns a reference to the current path that the shader is invoked for.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kHwShaderNode .'''
        pass

    def renderSwatchImage(self, image): 
        '''renderSwatchImage(self, image)
Arguments:
	[in]	image = MImage


If the shader specifies to override swatch rendering, then this method must be overridden in order to draw anything into a swatch. The default implementation is to draw nothing. The basic logic to draw a swatch is as follows:'''
        pass

    def provideVertexIDs(self): 
        '''provideVertexIDs(self) -> bool


This method returns a boolean value that indicates whether a map of the vertex IDs will be provided to the geometry method.'''
        pass

    def normalsPerVertex(self): 
        '''normalsPerVertex(self) -> int


Specifies how many normals per vertex the HW shader would like Maya to provide. This can range from 0 to 3. The first normal is the surface normal. The second "normal" is the primary tangent (generally the "u" direction). The third "normal" is the secondary tangent or the binormal (generally the "v" direction). Together, the normal, tangent and binormal form an orthogonal basis frequently named "tangent space basis".'''
        pass

    def glBind(self, shapePath): 
        '''glBind(self, shapePath)
Arguments:
	[in]	shapePath = MDagPath


This method should only be overridden for hardware rendering.'''
        pass

    def getHwShaderNodePtr(self, object): 
        '''getHwShaderNodePtr(self, object) -> MPxHwShaderNode
Returns: A pointer to an MPxHwShaderNode. If the method failed for any reason then a 0 (null) will be returned. 

Arguments:
	[in]	object = MObject


This is a static convenience method to be able to get an  MPxHwShaderNode  from an  MObject  provided by a swatch generator class (Class derived from  MSwatchRenderRegister ).'''
        pass

    def texCoordsPerVertex(self): 
        '''texCoordsPerVertex(self) -> int


This method returns the number of texture coordinate values per vertex that the hw shader node would like to receive from Maya. Maya will attempt to provide all the texture coordinate data that the shader would like but it will never provide more data than is actually available in the shape. The uv sets returned by  getTexCoordSetNames()  will override the number of uv sets specified by  texCoordsPerVertex() . If you do not override this method or  getTexCoordSetNames() , Maya will provide no texture coordinates per vertex.'''
        pass

    def unbind(self, request, view): 
        '''unbind(self, request, view)
Arguments:
	[in]	request = MDrawRequest
	[in]	view = M3dView


This method is invoked for hardware rendering to Maya's 3D view.'''
        pass

    def kNoTransparencyPolygonSort(self):
        '''This is an enum of TransparencyOptions.
Description: Do not use two-pass drawing of back-to-front sorted polygons.
Value: 4'''
        pass

    def kIsTransparent(self):
        '''This is an enum of TransparencyOptions.
Description: Draw as a transparent object. If this bit is not set then the others are ignored.
Value: 1'''
        pass

    def kNoTransparencyFrontBackCull(self):
        '''This is an enum of TransparencyOptions.
Description: Do not use the two-pass front-and-back culling algorithm.
Value: 2'''
        pass

    class TransparencyOptions:
        '''Non-functional class.  Values for this enum:
        kNoTransparencyPolygonSort
        kIsTransparent
        kNoTransparencyFrontBackCull
'''
        def __init__(self):
            pass

    def geometry(self, request, view, prim, indexCount, indexArray, vertexCount, vertexIDs, vertexArray, normalCount, normalArrays, colorCount, colorArrays, texCoordCount, texCoordArrays, writable): 
        '''geometry(self, request, view, prim, indexCount, indexArray, vertexCount, vertexIDs, vertexArray, normalCount, normalArrays, colorCount, colorArrays, texCoordCount, texCoordArrays, writable)
Arguments:
	[in]	request = MDrawRequest
	[in]	view = M3dView
	[in]	prim = int
	[out]	writable = int
	[in]	indexCount = int
	[in]	indexArray = int
	[in]	vertexCount = int
	[in]	vertexIDs = int
	[in]	vertexArray = float
	[in]	normalCount = int
	[in]	normalArrays = floatArrayPtr
	[in]	colorCount = int
	[in]	colorArrays = floatArrayPtr
	[in]	texCoordCount = int
	[in]	texCoordArrays = floatArrayPtr


This method is invoked for hardware rendering to Maya's 3D view.'''
        pass

    def bind(self, request, view): 
        '''bind(self, request, view)
Arguments:
	[in]	request = MDrawRequest
	[in]	view = M3dView


This method is invoked for hardware rendering to Maya's 3D view.'''
        pass

    def colorsPerVertex(self): 
        '''colorsPerVertex(self) -> int


This method returns the number of color values per vertex that the hw shader node would like to receive from Maya. Maya will attempt to provide all the color data that the shader would like but it will never provide more data that is actually available in the shape. The color sets returned by  getColorSetNames()  will override the number of color sets specified by  colorsPerVertex() . If you do not override this method or  getColorSetNames() , Maya will provide no colors per vertex.'''
        pass

class MPxIkSolverNode:
    '''Base class for user defined IK solvers. This is the base class for writing user-defined IK solvers. Users must at least override the following methods in order to write a solver:Note that the following virtual methods (declared in MPxNode) are irrelevant for the MPxIkSolverNode. If these methods are overridden in a class derived from MPxIkSolverNode, they will be ignored.A creator method is necessary to return an instance of the user solver:In order to create and register the solver, execute the mel command: Once the solver is registered it can be assigned to IK handles and its solve methods will be called in the same manner as the solvers within Maya. '''
    def __init__(self):
        pass


    def setRotatePlane(self, rotatePlane): 
        '''setRotatePlane(self, rotatePlane)
Arguments:
	[in]	rotatePlane = bool


This method sets whether or not this solver supports the rotate plane. Solvers that support the rotate plane allow the user to manipulate the IK handle's pole vector with the rotate plane manipulators.'''
        pass

    def setJointAngles(self, angles): 
        '''setJointAngles(self, angles)
Arguments:
	[in]	angles = MDoubleArray


 This method is not available in Python. 
'''
        pass

    def solverTypeName(self): 
        '''solverTypeName(self) -> MString


This method returns the type name of the solver. The user must override this method in order for the solver to be identifiable when it is registered.'''
        pass

    def setPositionOnly(self, positionOnly): 
        '''setPositionOnly(self, positionOnly)
Arguments:
	[in]	positionOnly = bool


Sets whether or not the solver supports handle orientation.'''
        pass

    def snapHandle(self, handle): 
        '''snapHandle(self, handle)
Arguments:
	[in]	handle = MObject


This function positions the handle at the end effector position. The user can override this method.'''
        pass

    def setHandleGroup(self, group): 
        '''setHandleGroup(self, group)
Arguments:
	[in]	group = MIkHandleGroup


Set the handle group of this solver.'''
        pass

    def setSingleChainOnly(self, singleChainOnly): 
        '''setSingleChainOnly(self, singleChainOnly)
Arguments:
	[in]	singleChainOnly = bool


This method sets whether or not this solver is a single chain solver. Single chain solvers are solvers which act on one handle only, i.e. the handle groups have only one handle if they are for single chain solvers.'''
        pass

    def singleChainOnly(self): 
        '''singleChainOnly(self) -> bool


This method indicates whether this solver is a single chain solver. Single chain solvers are solvers which act on one handle only, i.e. the handle groups have only one handle if they are for single chain solvers.'''
        pass

    def MMatrix(self): 
        '''MMatrix(self) -> const


Returns the local space matrix for this solver.'''
        pass

    def uniqueSolution(self): 
        '''uniqueSolution(self) -> bool


This method indicates whether the solver provides a unique solution.'''
        pass

    def positionOnly(self): 
        '''positionOnly(self) -> bool


Indicates whether the ik solution is dependent on the ikHandle position only or also uses the orientation.'''
        pass

    def getJointAngles(self, angles): 
        '''getJointAngles(self, angles)
Arguments:
	[out]	angles = MDoubleArray


 This method is not available in Python. 
'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kIkSolverNode .'''
        pass

    def setSupportJointLimits(self, supportJointLimits): 
        '''setSupportJointLimits(self, supportJointLimits)
Arguments:
	[in]	supportJointLimits = bool


This method sets whether or not the solver supports limits on joint angles.'''
        pass

    def maxIterations(self): 
        '''maxIterations(self) -> int


Return the the maximum nuber of itertations for a solution by this solver.'''
        pass

    def setUniqueSolution(self, uniqueSolution): 
        '''setUniqueSolution(self, uniqueSolution)
Arguments:
	[in]	uniqueSolution = bool


This method sets whether or not the solver provides a unique solution.'''
        pass

    def setFuncValueTolerance(self, tolerance): 
        '''setFuncValueTolerance(self, tolerance)
Arguments:
	[in]	tolerance = double


Set the error value for this solver. The user can override this if any other calcluations should be done here.'''
        pass

    def supportJointLimits(self): 
        '''supportJointLimits(self) -> bool


This method indicates whether the solver supports limits on joint angles.'''
        pass

    def postSolve(self): 
        '''postSolve(self)

This method is called after  doSolve  has finished. The user should override this method if there are any post calculations to be done.'''
        pass

    def rotatePlane(self): 
        '''rotatePlane(self) -> bool


This method indicates whether this solver supports the rotate plane. Solvers that support the rotate plane allow the user to manipulate the IK handle's pole vector with the rotate plane manipulators.'''
        pass

    def preSolve(self): 
        '''preSolve(self)

This method is called before  doSolve . Users should override this method if there is any preprocessing that needs to be done before solving..'''
        pass

    def funcValueTolerance(self): 
        '''funcValueTolerance(self) -> double


Return the error value for this solver.'''
        pass

    def doSolve(self): 
        '''doSolve(self)

This is where the main solving takes place. The user must override this method.'''
        pass

    def setToRestAngles(self): 
        '''setToRestAngles(self)
'''
        pass

    def handleGroup(self): 
        '''handleGroup(self) -> MIkHandleGroup


Returns the handle group for this solver. The handle group provides access to handles associated with the solver.'''
        pass

    def setMaxIterations(self, value): 
        '''setMaxIterations(self, value)
Arguments:
	[in]	value = int


Set the maximum iterations for a solution by this solver. The user can override this if any other calcluations should be done here.'''
        pass

class MPxImageFile:
    '''Image manipulation. This class provides methods for reading file images stored on disk.The MPxImageFile class can be used to implement support for new image file formats in Maya. The implementation is able to support both fixed and floating point image formats. '''
    def __init__(self):
        pass


    def load(self, image, imageNumber): 
        '''load(self, image, imageNumber)
Arguments:
	[in]	image = MImage
	[in]	imageNumber = int


Load the previously opened image file into an  MImage .'''
        pass

    def close(self): 
        '''close(self)

Close the image file.'''
        pass

    def open(self, pathname, info): 
        '''open(self, pathname, info)
Arguments:
	[in]	pathname = MString
	[out]	info = MImageFileInfo


Attempt to open the specified file as an image and extract the image characteristics. It is important that this function only return success if the image is definitely supported by this implementation.'''
        pass

    def glLoad(self, info, imageNumber): 
        '''glLoad(self, info, imageNumber)
Arguments:
	[in]	info = MImageFileInfo
	[in]	imageNumber = int


Load the previously opened image file as an OpenGL texture. The OpenGL texture will already have been bound by the caller of this method (i.e. do not call glBind again inside your implementation of this method - just use glTexImage2D or equivalent to load the texture). The type of texture that has been bound is specified in the information structure provided. It is important that your implementation verifies this type before loading any data, as loading an incompatible type may lead to instability. By overriding this method, you can implement non-2D texture support (such as cube maps), non-byte texture support (such as float and half), and compressed hardware texture support (such as DXT). You are free to use any available OpenGL extensions you want to load in the texture. While standard Maya shaders will only be able to use standard 2D textures, plugin hardware shaders can access non-2D textures loaded via this method. If your plugin set mipmaps to true at file open time, it is responsible for loading or generating the mipmap information inside this method.'''
        pass

class MPxImagePlane:
    '''Base class for user defined imagePlane nodes. MPxImagePlane provides you with the ability to write your own image plane classes. This allows you to support non-standard image data in an image plane or change the standard behaviour of the image plane.Note, once you have created a custom image plane and created the node in a scene. You must attach the image plane to a camera using the 'imagePlane' attribute on the 'cameraShape'. '''
    def __init__(self):
        pass


    composite = ''
    '''Separate file that contains depth information. '''

    sourceTexture = ''
    '''Controls how the image file will be fit into the image plane. '''

    alphaGain = ''
    '''A multiplier that is applied to the alpha value. '''

    maxShadingSamples = ''
    '''Specifies the max number of shading samples can be taken for this surface during rendering. '''

    lockedToCamera = ''
    '''If enabled, the image plane is locked to the camera's position. '''

    offsetY = ''
    '''Vertical component of Offset. '''

    depthOversample = ''
    '''Separate file that contains depth information. '''

    squeezeCorrection = ''
    '''Applies a horizontal scaling to an image. '''

    colorGain = ''
    '''A multiplier applied to the colors in the image plane. '''

    coverageOriginY = ''
    '''The pixel position of the bottom edge of the area of the source image to be used. '''

    coverageOriginX = ''
    '''The pixel position of the left edge of the area of the source image to be used. '''

    size = ''
    '''Controls the width and height of the image plane. '''

    colorOffsetB = ''
    '''The blue component of Color Offset. '''

    alreadyPremult = ''
    '''Indicates that the image plane has depth information. '''

    depthBias = ''
    '''Depth offset value -- centered at the center of the view frustum. '''

    fit = ''
    '''Controls how the image file will be fit into the image plane. '''

    colorOffsetG = ''
    '''The green component of Color Offset. '''

    depthFile = ''
    '''Separate file that contains depth information. '''

    colorOffset = ''
    '''An additive value applied to the colors in the image plane. '''

    width = ''
    '''Controls the width of the image plane in world space. '''

    colorOffsetR = ''
    '''The red component of Color Offset. '''

    imageName = ''
    '''The frame extension in Image Name is replaced by the number here. '''

    centerZ = ''
    '''Z component of Center. '''

    centerX = ''
    '''X component of Center. '''

    centerY = ''
    '''Y component of Center. '''

    visibleInReflections = ''
    '''Rotation of the image plane around the view vector. '''

    coverageOrigin = ''
    '''The pixel position of the left edge of the area of the source image to be used. '''

    imageType = ''
    '''controls the source of the image on the Image plane. '''

    shadingSamplesOverride = ''
    '''The flag to control if this surface should override global shading sample settings. '''

    useFrameExtension = ''
    '''The frame extension in Image Name is replaced by the number here. '''

    frameExtension = ''
    '''The frame extension in Image Name is replaced by the number here. '''

    sizeX = ''
    '''Image plane width. '''

    coverageY = ''
    '''The height in pixels of the area on the source image to be used. '''

    coverageX = ''
    '''The width in pixels of the area on the source image to be used. '''

    displayMode = ''
    '''A multiplier applied to the colors in the image plane. '''

    sizeY = ''
    '''Image plane height. '''

    useDepthMap = ''
    '''Indicates that the image plane has depth information. '''

    visibleInRefractions = ''
    '''Rotation of the image plane around the view vector. '''

    coverage = ''
    '''Controls the amount of the image that will be used in the image plane. '''

    offset = ''
    '''Horizontal component of Offset. '''

    height = ''
    '''Controls the height of the image plane in world space. '''

    rotate = ''
    '''Rotation of the image plane around the view vector. '''

    displayOnlyIfCurrent = ''
    '''A multiplier applied to the colors in the image plane. '''

    center = ''
    '''X component of Center. '''

    colorGainR = ''
    '''The red component of Color Gain. '''

    offsetX = ''
    '''Horizontal component of Offset. '''

    shadingSamples = ''
    '''Specifies the minimum number of shading samples should be taken for this surface during rendering. '''

    depthScale = ''
    '''Scale the depth -- centered at the center of the view frustum. '''

    depth = ''
    '''Controls the distance of the plane from the camera. '''

    colorGainB = ''
    '''The blue component of Color Gain. '''

    separateDepth = ''
    '''Separate file that contains depth information. '''

    colorGainG = ''
    '''The green component of Color Gain. '''



    def getExactImageFile(self, refFileName, actualName): 
        '''getExactImageFile(self, refFileName, actualName) -> bool
Returns: true The file was found and the file name was expanded. 
false The file was not found and the file name was not expanded. 

Arguments:
	[in]	refFileName = MString
	[in]	actualName = MString


API users can call this method to resolve a file name. Sometimes the file path specified by the user node are relative or contain environment variables that require expansion. Also  getExactImageFile()  will try to find the image file sequence if use sequence is on. API users do not have to call this method, and it is only provided for convienence purposes. The full path name will be returned in actualName.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


Returns the type of node that this is. This is used to differentiate user defined nodes that are derived off different MPx base classes.'''
        pass

    def loadImageMap(self, fileName, frame, image): 
        '''loadImageMap(self, fileName, frame, image)
Arguments:
	[in]	fileName = MString
	[in]	frame = int
	[in]	image = MImage


Override this method to load the file of name fileName into the image  MImage .'''
        pass

    def exactImageFile(self, refFileName): 
        '''exactImageFile(self, refFileName) -> MString
Returns: String containing the image file name, will be empty string on failure 

Arguments:
	[in]	refFileName = MString


API users can call this method to resolve a file name. Sometimes the file path specified by the user node are relative or contain environment variables that require expansion. Also  getExactImageFile()  will try to find the image file sequence if use sequence is on. API users do not have to call this method, and it is only provided for convienence purposes. The full path name will be returned in actualName.'''
        pass

    def setImageDirty(self): 
        '''setImageDirty(self)
'''
        pass

    def refreshImage(self): 
        '''refreshImage(self)
'''
        pass

class MPxLocatorNode:
    '''Base class for user defined locators. MPxLocatorNode allows the creation of user-defined locators. A locator is a DAG shaped that is drawn on the screen, but that has is not rendered. Locators are full dependency nodes and can have attributes and a compute method.To create a locator, derive off of this class and override the draw method. The draw method can be overridden to draw custom geometry using standard OpenGL calls. The other methods of the parent class MPxNode may also be overridden to perform dependency node capabilities as well. '''
    def __init__(self):
        pass


    instObjGroups = ''
    '''instances object group info attribute '''

    intermediateObject = ''
    '''intermediate object attribute '''

    underWorldObject = ''
    '''under world attribute '''

    localPositionZ = ''
    '''Z component of localPosition. '''

    localPositionX = ''
    '''X component of localPosition. '''

    nodeBoundingBoxMin = ''
    '''bounding box minimum point '''

    worldPosition = ''
    '''world position attribute '''

    nodeBoundingBoxSizeX = ''
    '''X component of boundingBoxSize. '''

    worldInverseMatrix = ''
    '''inverse world matrix attribute '''

    isTemplated = ''
    '''template attribute '''

    matrix = ''
    '''matrix attribute '''

    nodeBoundingBoxSize = ''
    '''bounding box size vector '''

    objectGroupId = ''
    '''group id attribute '''

    useObjectColor = ''
    '''controls choice of wireframe dormant object color '''

    localScaleX = ''
    '''X component of localScale. '''

    localScaleY = ''
    '''Y component of localScale. '''

    localScaleZ = ''
    '''Z component of localScale. '''

    worldMatrix = ''
    '''world matrix attribute '''

    nodeBoundingBox = ''
    '''bounding box attribute '''

    objectGrpCompList = ''
    '''component in object groups attribute '''

    worldPositionY = ''
    '''Y component of worldPosition. '''

    worldPositionX = ''
    '''X component of worldPosition. '''

    worldPositionZ = ''
    '''Z component of worldPosition. '''

    parentInverseMatrix = ''
    '''inverse parent matrix attribute '''

    localPosition = ''
    '''local position attribute '''

    objectGroups = ''
    '''object groups attributes '''

    objectGroupColor = ''
    '''group id attribute '''

    visibility = ''
    '''visibility attribute '''

    parentMatrix = ''
    '''parent matrix attribute '''

    nodeBoundingBoxMaxZ = ''
    '''Z component of boundingBoxMax. '''

    nodeBoundingBoxSizeY = ''
    '''Y component of boundingBoxSize. '''

    nodeBoundingBoxMaxX = ''
    '''X component of boundingBoxMax. '''

    nodeBoundingBoxMaxY = ''
    '''Y component of boundingBoxMax. '''

    localPositionY = ''
    '''Y component of localPosition. '''

    nodeBoundingBoxMinX = ''
    '''X component of boundingBoxMin. '''

    nodeBoundingBoxMinY = ''
    '''Y component of boundingBoxMin. '''

    nodeBoundingBoxMinZ = ''
    '''Z component of boundingBoxMin. '''

    boundingBoxCenterZ = ''
    '''Z component of boundingBoxCenter. '''

    nodeBoundingBoxMax = ''
    '''bounding box maximum point '''

    boundingBoxCenterX = ''
    '''X component of boundingBoxCenter. '''

    boundingBoxCenterY = ''
    '''Y component of boundingBoxCenter. '''

    center = ''
    '''object center attribute '''

    localScale = ''
    '''local scale attribute '''

    nodeBoundingBoxSizeZ = ''
    '''Z component of boundingBoxSize. '''

    objectColor = ''
    '''the per object dormant wireframe color '''

    inverseMatrix = ''
    '''inverse matrix attribute '''

    def draw(self, view, path, style, status): 
        '''draw(self, view, path, style, status)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath
	[in]	style = M3dView.DisplayStyle
	[in]	status = M3dView.DisplayStatus


Overriding this method allows the drawing of custom geometry using standard OpenGL calls. The OpenGL state should be left in the same state that it was in previously. The OpenGL routine glPushAttrib may be used to make this easier.'''
        pass

    def isTransparent(self): 
        '''isTransparent(self) -> bool


Indicates that this locator uses transparency during draw method calls. Objects with transparency must be drawn in a special queue, i.e. after all opaque objects are drawn.'''
        pass

    def colorRGB(self, displayStatus): 
        '''colorRGB(self, displayStatus) -> MColor
Returns: The color 

Arguments:
	[in]	displayStatus = M3dView.DisplayStatus


This method returns the RGB values of the default draw color for the given display status.'''
        pass

    def color(self, displayStatus): 
        '''color(self, displayStatus) -> int
Returns: The index of the color 

Arguments:
	[in]	displayStatus = M3dView.DisplayStatus


This method returns the index of the color that is the default draw color for the given display status. The index should be used with the methods of  M3dView . The value is not an index into the OpenGL color table.'''
        pass

    def excludeAsLocator(self): 
        '''excludeAsLocator(self) -> bool


When the modelPanel is set to not draw locators, returing true will also not draw the custom locator. If false is returned, the custom locator will also be drawn.'''
        pass

    def isBounded(self): 
        '''isBounded(self) -> bool


This method should be overridden to return true if the user supplies a bounding box routine. Supplying a bounding box routine makes refresh and selection more efficient.'''
        pass

    def boundingBox(self): 
        '''boundingBox(self) -> MBoundingBox


This method should be overridden to return a bounding box for the locator. If this method is overridden, then  MPxLocatorNode::isBounded  should also be overridden to return true.'''
        pass

    def drawLast(self): 
        '''drawLast(self) -> bool


Indicates that this locator should be the last item draw in a given refresh cycle. Objects drawn out-of-order will not preserve the proper transparency sorting. Conflicts among multiple objects with the drawLast indicator set to TRUE will be resolved by their order in the Outliner, where they will be drawn top-to-bottom.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kLocatorNode .'''
        pass

class MPxManipulatorNode:
    '''Base class for manipulator creation. MPxManipulatorNode is the base class used for creating user-defined manipulators. This class is derived from MPxNode since manipulators in Maya are dependency nodes.An MPxManipulatorNode should implement the following method:Additionally, several of the following virtuals will need to be defined: Implement the following method to properly support undo: The draw() method is very important since drawing and picking are done together. The colorAndName() method should be called before drawing a GL component that should be pickable. Several color methods which return color indexes that Maya use are provided to allow custom manipulators to have a similar look.When drawing a GL pickable component, an active name must be set. Use the glFirstHandle() to get this value from the base class.A manipulator can be connected to a depend node instead of updating a node attribute directly in one of the do*() methods. To connect to a depend node, you must:This class can work standalone or with MPxManipContainer. '''
    def __init__(self):
        pass


    connectedNodes = ''
    '''Connected node, message attribute. '''

    def glFirstHandle(self, firstHandle): 
        '''glFirstHandle(self, firstHandle)
Arguments:
	[in]	firstHandle = MPxManipulatorNode.MGLuint


This method is used to find the unsigned int value that should be used for the first GL handle.'''
        pass

    def yColor(self): 
        '''yColor(self) -> short

'''
        pass

    def addDoubleValue(self, valueName, defaultValue, valueIndex): 
        '''addDoubleValue(self, valueName, defaultValue, valueIndex)
Arguments:
	[in]	valueName = MString
	[in]	defaultValue = double
	[out]	valueIndex = int


Manipulators which call  connectPlugToValue()  must first create the value on the node. Use this method to create a value of double type.'''
        pass

    def mouseRayWorld(self, linePoint, lineDirection): 
        '''mouseRayWorld(self, linePoint, lineDirection)
Arguments:
	[out]	linePoint = MPoint
	[out]	lineDirection = MVector


This method returns the location of the mouse within a view. The location is defined by a point and a direction through the point. Both point and direction are in world space.'''
        pass

    def connectPlugToValue(self, plug, valueIndex, plugIndex): 
        '''connectPlugToValue(self, plug, valueIndex, plugIndex)
Arguments:
	[in]	plug = MPlug
	[in]	valueIndex = int
	[out]	plugIndex = int


This method is called in the  connectToDependNode()  virtual if it is implemented for the custom manipulator. It will connect a plug to an already added manipulator value of the same type.'''
        pass

    def mouseRay(self, linePoint, lineDirection): 
        '''mouseRay(self, linePoint, lineDirection)
Arguments:
	[out]	linePoint = MPoint
	[out]	lineDirection = MVector


This method returns the location of the mouse within a view. The location is defined by a point and a direction through the point. Both point and direction are in local space.'''
        pass

    def setVectorValue(self, valueIndex, value): 
        '''setVectorValue(self, valueIndex, value)
Arguments:
	[in]	valueIndex = int
	[in]	value = MVector


This method is used for setting a  MVector  value associated with the manipulator.'''
        pass

    def finishAddingManips(self): 
        '''finishAddingManips(self)

This method should be called from the user-defined manipulator plug-in near the end of the connectToDependNode method so that the converter in the manipulator can be initialized. The converter cannot be initialized until all the connections from the manip values to the plug values have been specified.'''
        pass

    def xColor(self): 
        '''xColor(self) -> short

'''
        pass

    def labelColor(self): 
        '''labelColor(self) -> short

'''
        pass

    def mouseDown(self, x_pos, y_pos): 
        '''mouseDown(self, x_pos, y_pos)
Arguments:
	[out]	x_pos = short
	[out]	y_pos = short


This method returns the mouse down position within a view. The position is in port coordinates.'''
        pass

    def getDoubleValue(self, valueIndex, previousValue, value): 
        '''getDoubleValue(self, valueIndex, previousValue, value)
Arguments:
	[in]	valueIndex = int
	[in]	previousValue = bool
	[out]	value = double


This method is used for getting a double value associated with the manipulator.'''
        pass

    def doPress(self, view): 
        '''doPress(self, view)
Arguments:
	[in]	view = M3dView


This method gets called when the manipulator receives a mouse down event.'''
        pass

    def draw(self, view, path, style, status): 
        '''draw(self, view, path, style, status)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath
	[in]	style = M3dView.DisplayStyle
	[in]	status = M3dView.DisplayStatus


This method is overloaded to draw the manipulators. Selection is also setup with this method using the  colorAndName()  method call.'''
        pass

    def connectToDependNode(self, node): 
        '''connectToDependNode(self, node)
Arguments:
	[in]	node = MObject


This method connects the manipulator to the dependency node. This is a virtual method and needs to be overridden from the plug-in.'''
        pass

    def addPointValue(self, valueName, defaultValue, valueIndex): 
        '''addPointValue(self, valueName, defaultValue, valueIndex)
Arguments:
	[in]	valueName = MString
	[in]	defaultValue = MPoint
	[out]	valueIndex = int


Manipulators which call  connectPlugToValue()  must first create the value on the node. Use this method to create a value of double  MPoint .'''
        pass

    def setDoubleValue(self, valueIndex, value): 
        '''setDoubleValue(self, valueIndex, value)
Arguments:
	[in]	valueIndex = int
	[in]	value = double


This method is used for setting a double value associated with the manipulator.'''
        pass

    def zColor(self): 
        '''zColor(self) -> short

'''
        pass

    def getVectorValue(self, valueIndex, previousValue, value): 
        '''getVectorValue(self, valueIndex, previousValue, value)
Arguments:
	[in]	valueIndex = int
	[in]	previousValue = bool
	[out]	value = MVector


This method is used for getting a  MVector  value associated with the manipulator.'''
        pass

    def prevColor(self): 
        '''prevColor(self) -> short

'''
        pass

    def dimmedColor(self): 
        '''dimmedColor(self) -> short

'''
        pass

    def mousePosition(self, x_pos, y_pos): 
        '''mousePosition(self, x_pos, y_pos)
Arguments:
	[out]	x_pos = short
	[out]	y_pos = short


This method returns the current mouse position within a view. The position is in port coordinates.'''
        pass

    def addVectorValue(self, valueName, defaultValue, valueIndex): 
        '''addVectorValue(self, valueName, defaultValue, valueIndex)
Arguments:
	[in]	valueName = MString
	[in]	defaultValue = MVector
	[out]	valueIndex = int


Manipulators which call  connectPlugToValue()  must first create the value on the node. Use this method to create a value of double  MVector .'''
        pass

    def labelBackgroundColor(self): 
        '''labelBackgroundColor(self) -> short

'''
        pass

    def selectedColor(self): 
        '''selectedColor(self) -> short

'''
        pass

    def mouseUp(self, x_pos, y_pos): 
        '''mouseUp(self, x_pos, y_pos)
Arguments:
	[out]	x_pos = short
	[out]	y_pos = short


This method returns the mouse up position within a view. The position is in port coordinates.'''
        pass

    def setPointValue(self, valueIndex, value): 
        '''setPointValue(self, valueIndex, value)
Arguments:
	[in]	valueIndex = int
	[in]	value = MPoint


This method is used for setting an  MPoint  value associated with the manipulator.'''
        pass

    def getPointValue(self, valueIndex, previousValue, value): 
        '''getPointValue(self, valueIndex, previousValue, value)
Arguments:
	[in]	valueIndex = int
	[in]	previousValue = bool
	[out]	value = MPoint


This method is used for getting a  MPoint  value associated with the manipulator.'''
        pass

    def lineColor(self): 
        '''lineColor(self) -> short

'''
        pass

    def doRelease(self, view): 
        '''doRelease(self, view)
Arguments:
	[in]	view = M3dView


This method gets called when the manipulator recieves a mouse release event.'''
        pass

    def mainColor(self): 
        '''mainColor(self) -> short

'''
        pass

    def doDrag(self, view): 
        '''doDrag(self, view)
Arguments:
	[in]	view = M3dView


This method gets called when the manipulator recieves a mouse drag event.'''
        pass

    def newManipulator(self, manipName, manipObject): 
        '''newManipulator(self, manipName, manipObject) -> MPxManipulatorNode

Arguments:
	[in]	manipName = MString
	[in]	manipObject = MObject


This static function is used to create a user-defined manipulator. The manipObject argument is set to the new manipulator node. Note that the manipName argument must be the name of a manipulator derived from  MPxManipulatorNode . Also note that this method creates the newManipulator, but doesn't add it to the DAG. The primary use of this method is in conjunction with  MPxSelectionContext::addManipulator , to add user-defined manipulators to a context.'''
        pass

    def colorAndName(self, view, glName, glNameIsPickable, colorIndex): 
        '''colorAndName(self, view, glName, glNameIsPickable, colorIndex)
Arguments:
	[in]	view = M3dView
	[in]	glName = MPxManipulatorNode.MGLuint
	[in]	glNameIsPickable = bool
	[in]	colorIndex = short


This method is used to set the color of the GL component that is being drawn next. It is also used to set GL name of the component so that picking can be supported.'''
        pass

    def glActiveName(self, glName): 
        '''glActiveName(self, glName)
Arguments:
	[in]	glName = MPxManipulatorNode.MGLuint


This method returns the unsigned int value which specifies the current active handle.'''
        pass

class MPxManipContainer:
    '''Base class for user defined manipulator containers. MPxManipContainer is the base class for user-defined container manipulators. This class is derived from MPxNode since manipulators in Maya are dependency nodes.MPxManipContainer is a container manipulator that has at least one base manipulator. MPxManipContainer has methods for adding the following base manipulators types to the container: FreePointTriadManip, DirectionManip, DistanceManip, PointOnCurveManip, PointOnSurfaceManip, DiscManip, CircleSweepManip, ToggleManip, StateManip, and CurveSegmentManip.A container manipulator has one converter which is the interface between the container's children manipulators and the node plugs they affect. The values on the converter that are related to children manipulators are called converterManipValues, and the values on the converter that are related to the node plugs are called converterPlugValues.The conversion between converterManipValues and converterPlugValues are performed through conversion callback methods, except when there is a one-to-one connection between a converterManipValue and a converterPlugValue.There are two kinds of conversion callback methods: manipToPlug and plugToManip. A plugToManipConversionCallback is used to calculate a converterManipValue from various converterPlugValues. This callback has access to all the converterPlugValues and returns the value of a converterManipValue. A manipToPlugConversionCallback is used to calculate a converterPlugValue from various converterManipValues. This callback has access to all the converterManipValues and returns the value of a converterPlugValue.In order for an MPxManipContainer to be able to run, the manipulator needs to know that the initialization is finished through the finishAddingManips method. '''
    def __init__(self):
        pass


    def addPlugToManipConversion(self, manipIndex): 
        '''addPlugToManipConversion(self, manipIndex)
Arguments:
	[in]	manipIndex = int


This method adds a plug to manipulator converter. The converter must be implemented in the  plugToManipConversion()  virtual method of this class.'''
        pass

    def removeFromManipConnectTable(self, id): 
        '''removeFromManipConnectTable(self, id)
Arguments:
	[in]	id = MTypeId


This method removes the user defined node entry from the manipConnectTable.'''
        pass

    def addStateManip(self, manipName, stateName): 
        '''addStateManip(self, manipName, stateName) -> MDagPath
Returns: New StateManip 

Arguments:
	[in]	manipName = MString
	[in]	stateName = MString


This method creates a StateManip and adds it to the  MPxManipContainer  container.'''
        pass

    def plugToManipConversion(self, manipIndex): 
        '''plugToManipConversion(self, manipIndex) -> MManipData
Returns: Calculated manipulator data. 

Arguments:
	[in]	manipIndex = int


This virtual method works in conjunction with the  addPlugToManipConversion()  method. If  addPlugToManipConversion()  is called successfully, then this method or handler will be invoked to handle the conversion.'''
        pass

    def addDiscManip(self, manipName, angleName): 
        '''addDiscManip(self, manipName, angleName) -> MDagPath
Returns: New DiscManip 

Arguments:
	[in]	manipName = MString
	[in]	angleName = MString


This method creates a DiscManip and adds it to the  MPxManipContainer  container.'''
        pass

    def draw(self, view, path, style, status): 
        '''draw(self, view, path, style, status)
Arguments:
	[in]	view = M3dView
	[in]	path = MDagPath
	[in]	style = M3dView.DisplayStyle
	[in]	status = M3dView.DisplayStatus


This method can be overloaded to customize the drawing of the child manipulators. If the default draw is also required, this method should be called from the derived method.'''
        pass

    def addToggleManip(self, manipName, toggleName): 
        '''addToggleManip(self, manipName, toggleName) -> MDagPath
Returns: New ToggleManip 

Arguments:
	[in]	manipName = MString
	[in]	toggleName = MString


This method creates a ToggleManip and adds it to the  MPxManipContainer  container.'''
        pass

    def getConverterManipValue(self, manipIndex, xform): 
        '''getConverterManipValue(self, manipIndex, xform)
Arguments:
	[in]	manipIndex = int
	[out]	xform = MTransformationMatrix


This method retrieves the value of a converterManipValue of type  MTransformationMatrix  at a given index from the converter.'''
        pass

    def initialize(self): 
        '''initialize(self)

This method initializes the manipulator, and should be overriden in user-defined manipulators.'''
        pass

    def finishAddingManips(self): 
        '''finishAddingManips(self)

This method should be called from the user-defined manipulator plug-in near the end of the connectToDependNode method so that the converter in the manipulator can be initialized. The converter cannot be initialized until all the connections from the manip values to the plug values have been specified.'''
        pass

    def getConverterPlugValue(self, plugIndex, rotation): 
        '''getConverterPlugValue(self, plugIndex, rotation)
Arguments:
	[in]	plugIndex = int
	[out]	rotation = MEulerRotation


This method retrieves the value of a converterPlugValue of type  MEulerRotation  at a given index from the converter.'''
        pass

    def addToManipConnectTable(self, mid): 
        '''addToManipConnectTable(self, mid)
Arguments:
	[in]	mid = MTypeId


This method adds the user defined node as an entry in the manipConnectTable so that when this node is selected the user can use the show manip tool to get the user defined manipulator associated with this node. Note that the name of the manipulator node has to be the name of the plug-in node appended with "Manip".'''
        pass

    def doDrag(self): 
        '''doDrag(self)

This method gets called when the manipulator recieves a mouse drag event.'''
        pass

    def addScaleManip(self, manipName, scaleName): 
        '''addScaleManip(self, manipName, scaleName) -> MDagPath
Returns: Dag path to the new scale manipulator 

Arguments:
	[in]	manipName = MString
	[in]	scaleName = MString


This method creates a scale manipulator and adds it to the  MPxManipContainer  container.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node.'''
        pass

    def addMPxManipulatorNode(self, manipTypeName, manipName, proxyManip): 
        '''addMPxManipulatorNode(self, manipTypeName, manipName, proxyManip)
Arguments:
	[in]	manipTypeName = MString
	[in]	manipName = MString
	[out]	proxyManip = MPxManipulatorNode


This method creates a custom  MPxManipulatorNode  and adds it to the  MPxManipContainer  container.'''
        pass

    def addFreePointTriadManip(self, manipName, pointName): 
        '''addFreePointTriadManip(self, manipName, pointName) -> MDagPath
Returns: New FreePointTriadManip 

Arguments:
	[in]	manipName = MString
	[in]	pointName = MString


This method creates a FreePointTriadManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addPointOnCurveManip(self, manipName, paramName): 
        '''addPointOnCurveManip(self, manipName, paramName) -> MDagPath
Returns: New PointOnCurveManip 

Arguments:
	[in]	manipName = MString
	[in]	paramName = MString


This method creates a PointOnCurveManip and adds it to the  MPxManipContainer  container.'''
        pass

    def connectToDependNode(self, node): 
        '''connectToDependNode(self, node)
Arguments:
	[in]	node = MObject


This method connects the manipulator to the dependency node. This is a virtual method and needs to be overridden from the plug-in.'''
        pass

    def isManipActive(self, manipType, manipObject): 
        '''isManipActive(self, manipType, manipObject) -> bool
Returns: true custom manip is active 
false custom manip is inactive 

Arguments:
	[in]	manipType = MFn.Type
	[in]	manipObject = MObject


This method determines if custom manip is active & gets the current manip object.'''
        pass

    def addCircleSweepManip(self, manipName, angleName): 
        '''addCircleSweepManip(self, manipName, angleName) -> MDagPath
Returns: New CircleSweepManip 

Arguments:
	[in]	manipName = MString
	[in]	angleName = MString


This method creates a CircleSweepManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addDirectionManip(self, manipName, directionName): 
        '''addDirectionManip(self, manipName, directionName) -> MDagPath
Returns: New DirectionManip 

Arguments:
	[in]	manipName = MString
	[in]	directionName = MString


This method creates a DirectionManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addDistanceManip(self, manipName, distanceName): 
        '''addDistanceManip(self, manipName, distanceName) -> MDagPath
Returns: New DistanceManip 

Arguments:
	[in]	manipName = MString
	[in]	distanceName = MString


This method creates a DistanceManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addPointOnSurfaceManip(self, manipName, paramName): 
        '''addPointOnSurfaceManip(self, manipName, paramName) -> MDagPath
Returns: New PointOnSurfaceManip 

Arguments:
	[in]	manipName = MString
	[in]	paramName = MString


This method creates a PointOnSurfaceManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addCurveSegmentManip(self, manipName, startParamName, endParamName): 
        '''addCurveSegmentManip(self, manipName, startParamName, endParamName) -> MDagPath
Returns: New CurveSegmentManip 

Arguments:
	[in]	manipName = MString
	[in]	startParamName = MString
	[in]	endParamName = MString


This method creates a CurveSegmentManip and adds it to the  MPxManipContainer  container.'''
        pass

    def addManipToPlugConversion(self, plug): 
        '''addManipToPlugConversion(self, plug) -> int
Returns: The index of the plug to be manipulated 

Arguments:
	[in]	plug = MPlug


This method adds a manipulator to plug converter. The converter must be implemented in the  manipToPlugConversion()  virtual method of this class.'''
        pass

    def manipToPlugConversion(self, manipIndex): 
        '''manipToPlugConversion(self, manipIndex) -> MManipData
Returns: Calculated manipulator data. 

Arguments:
	[in]	manipIndex = int


This virtual method works in conjunction with the  addManipToPlugConversion()  method. If  addManipToPlugConversion()  is called successfully, then this method or handler will be invoked to handle the conversion.'''
        pass

    def createChildren(self): 
        '''createChildren(self)

This method should be overridden in user defined manipulators. This method is called after the user node derived from  MPxManipContainer  is set up. 
  Reprocessed example  
 Examples: 
 
   
 componentScaleManip.cpp ,  customAttrManip.cpp ,  footPrintManip.cpp ,  lineManipContainer.h ,  moveManip.cpp ,  rotateManip.cpp ,  surfaceBumpManip.cpp , and  swissArmyManip.cpp . 
 
'''
        pass

    def doRelease(self): 
        '''doRelease(self)

This method gets called when the manipulator recieves a mouse release event.'''
        pass

    def addRotateManip(self, manipName, rotationName): 
        '''addRotateManip(self, manipName, rotationName) -> MDagPath
Returns: Dag path to the new rotate manipulator 

Arguments:
	[in]	manipName = MString
	[in]	rotationName = MString


This method creates a rotate manipulator and adds it to the  MPxManipContainer  container.'''
        pass

    def doPress(self): 
        '''doPress(self)

This method gets called when the manipulator recieves a mouse down event.'''
        pass

    def newManipulator(self, manipName, manipObject): 
        '''newManipulator(self, manipName, manipObject) -> MPxManipContainer

Arguments:
	[in]	manipName = MString
	[in]	manipObject = MObject


This static function is used to create a user-defined manipulator. The manipObject argument is set to the new manipulator node. Note that the manipName argument must be the name of a manipulator derived from  MPxManipContainer . Also note that this method creates the newManipulator, but doesn't add it to the DAG. The primary use of this method is in conjunction with  MPxSelectionContext::addManipulator , to add user-defined manipulators to a context.'''
        pass

class MPxMaterialInformation:
    '''Material information proxy. The MPxMaterialInformation class is a way for users to override the viewport representation of shaders. The viewport uses a simple phong model for display in the viewport. With this class users can provide their own values for the phong shading parameters. '''
    def __init__(self):
        pass




    def useMaterialAsTexture(self): 
        '''useMaterialAsTexture(self) -> bool


Tells Maya whether to this material should be displayed as a texture, ie whether it should be baked.'''
        pass

    def textureDisconnected(self, plug): 
        '''textureDisconnected(self, plug) -> bool
Returns: true if connection should be treated as a texture, false otherwise 

Arguments:
	[in]	plug = MPlug


Called whenever an incoming connection to the shader is broken.'''
        pass

    def computeMaterial(self, data): 
        '''computeMaterial(self, data) -> bool
Returns: true if valid material properties/information were created, false otherwise 

Arguments:
	[in]	data = MaterialInputData


Compute the material properties/information for the shader. These properties are the parameters for a simple phong shading model used for display in the viewport'''
        pass

    def materialInfoIsDirty(self, plug): 
        '''materialInfoIsDirty(self, plug) -> bool
Returns: true if the material information is dirty, false otherwise 

Arguments:
	[in]	plug = MPlug


Called by Maya to when a plug on the shader has been changed. This method tells Maya if the material information is dirty. If it is dirty Maya triggers a refresh of the viewport.'''
        pass

    def connectAsTexture(self, plug): 
        '''connectAsTexture(self, plug) -> bool
Returns: true if connection should be treated as a texture, false otherwise 

Arguments:
	[in]	plug = MPlug


Called by Maya to when an incoming connection is made to plug on the shader. This method tells Maya if connection should be treated as a to a texture. If the connection is treated as a texture the Maya will bake the properties of the source plug for display in the viewport. Currently only one channel/plug on the shader can be treated as a texture.'''
        pass

    def kTexture(self):
        '''This is an enum of MaterialType.
Description: 
Value: 1'''
        pass

    def kSimpleMaterial(self):
        '''This is an enum of MaterialType.
Description: 
Value: 0'''
        pass

    def kOverrideDraw(self):
        '''This is an enum of MaterialType.
Description: 
Value: 2'''
        pass

    class MaterialType:
        '''Non-functional class.  Values for this enum:
        kTexture
        kSimpleMaterial
        kOverrideDraw
'''
        def __init__(self):
            pass

class MPxMayaAsciiFilter:
    '''Translator to output filtered Maya ASCII files. MPxMayaAsciiFilter allows output to the Maya ASCII (.ma) file format to be filtered by a plug-in. The file is output using the same internal mechanism that is used for normal Maya ASCII output, but allows your plug-in to prevent certain lines (such as createNodes or connectAttrs) from being output to the file. In addition, it allows you to write directly to the file at specific points during output.MPxMayaAsciiFilter allows your plug-in to write out files similar to Maya ASCII in a custom format. It can be used, for example, to partition a scene into several files, each of which has been filtered to write out different parts of the scene. Note that the order of the file cannot be changed - for example, connectAttrs are always written after createNodes - but it does allow you to control which connectAttrs and createNodes are output.MPxMayaAsciiFilter inherits from MPxFileTranslator. It overrides the haveWriteMethod(), haveReadMethod(), reader(), and writer() methods in MPxFileTranslator in such a way that the internal Maya mechanism for reading and writing Maya ASCII files is used. Because of this, it is not advised that you override these methods in your plug-in. If you do, make sure you first call these methods in MPxMayaAsciiFilter. A pseudo-code example is shown here:To determine if a given line should be output, override the methods writesCreateNode(), writesSetAttr() and so on. Each of these methods takes as its arguments the relevant data which is about to be processed and your plug-in can use this to determine whether or not the line will be output.For example, you may want to write out everything but render layer data. The code to do this might look something like what is shown here:Note that writesConnectAttr() has to be overridden as well (as would writesSetAttr(), writesSelectAttr(), and so on). This is because each line is handled separately, and nothing clever is done in the base class' implementation of writesConnectAttr(), such as having a default behaviour of only outputting connectAttrs for nodes that are being output. This gives you the most flexible control over what will be written.If you were using this class to save a segmented file, a master file might have to know about the locations of each of the segments. If your file saved everything but render layers in one file, and render layers in another, the first file might need to contain a pointer to the second, so that when the first file is loaded the second gets read into memory too. To do this, you would use MPxMayaAsciiFilter's ability to write directly to the stream during file output.You can write to the stream during output by overriding the methods writePreCreateNodesBlock(), writePostCreateNodesBlock() and so on. These give you a simple mechanism to write directly to the file. Each of these methods take an MPxMayaAsciiFilterOutput as its only argument. To write to the file, simply use the output operator (MPxMayaAsciiFilterOutput::operator<<() ) and output the string you wish.In the example above, the pointer to the render layer file might be inserted into the main file after all nodes have been created. The code to do this would look something like what is shown here:In the above example, after the createNode block was output, the linewas output. When the file is read in, Maya would reach the line above and execute it like any other MEL command. It is assumed in this example that there would be a custom command plug-in called importRenderLayerFile which would do the work of actually importing the layer file.Note: MPxMayaAsciiFilter gives you the ability to create your own custom file formats based on standard Maya ASCII files. However, Autodesk does not support such custom files as they will not, by definition, be standard Maya ASCII files. '''
    def __init__(self):
        pass


    def writesCreateNode(self, node): 
        '''writesCreateNode(self, node) -> bool

Arguments:
	[in]	node = MObject


Determines if a "createNode" command should be written for a particular node.'''
        pass

    def writesParentNode(self, parent, child): 
        '''writesParentNode(self, parent, child) -> bool
Returns: bool true if the disconnectAttr should be written; false otherwise. 

Arguments:
	[in]	parent = MDagPath
	[in]	child = MDagPath


Determines if a "parent" command should be written for a particular parent and child.'''
        pass

    def MFileObject(self): 
        '''MFileObject(self) -> const


Returns the  MFileObject  associated with the file currently being read or written, allowing access to the file's name, path and so on.'''
        pass

    def writePreCreateNodesBlock(self, filterOutput): 
        '''writePreCreateNodesBlock(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file before the create nodes block.'''
        pass

    def writePreTrailer(self, filterOutput): 
        '''writePreTrailer(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file before the trailer block.'''
        pass

    def haveReadMethod(self): 
        '''haveReadMethod(self) -> bool


Overrides  MPxFileTranslator::haveReadMethod()  to indicate that this translator has a read method. In general this should not be overridden.'''
        pass

    def writesConnectAttr(self, srcPlug, destPlug): 
        '''writesConnectAttr(self, srcPlug, destPlug) -> bool
Returns: bool true if the connectAttr should be written; false otherwise. 

Arguments:
	[in]	srcPlug = MPlug
	[in]	destPlug = MPlug


Determines if a "connectAttr" command should be written for a particular node.'''
        pass

    def writePostHeader(self, filterOutput): 
        '''writePostHeader(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file after the header block.'''
        pass

    def writesDisconnectAttr(self, srcPlug, destPlug): 
        '''writesDisconnectAttr(self, srcPlug, destPlug) -> bool
Returns: bool true if the disconnectAttr should be written; false otherwise. 

Arguments:
	[in]	srcPlug = MPlug
	[in]	destPlug = MPlug


Determines if a "disconnectAttr" command should be written for a particular connection.'''
        pass

    def processWriteOptions(self, optionsString): 
        '''processWriteOptions(self, optionsString)
Arguments:
	[in]	optionsString = MString


Allows the translator to handle any options passed into the  reader()  method, above. This call is made before the file is actually read. The default implementation does nothing.'''
        pass

    def writesRequirements(self): 
        '''writesRequirements(self) -> bool


Determines if "requires" commands should be written in the file.'''
        pass

    def writer(self, file, optionsString, mode): 
        '''writer(self, file, optionsString, mode)
Arguments:
	[in]	file = MFileObject
	[in]	optionsString = MString
	[in]	mode = MPxMayaAsciiFilter.FileAccessMode


Writer method for the ascii filter translator. In general this should not be overridden, since internal Maya methods are called in this method.'''
        pass

    def writePostCreateNodesBlock(self, filterOutput): 
        '''writePostCreateNodesBlock(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file after the create nodes block.'''
        pass

    def writePostRequires(self, filterOutput): 
        '''writePostRequires(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file after the requires block.'''
        pass

    def reader(self, file, optionsString, mode): 
        '''reader(self, file, optionsString, mode)
Arguments:
	[in]	file = MFileObject
	[in]	optionsString = MString
	[in]	mode = MPxMayaAsciiFilter.FileAccessMode


Reader method for the ascii filter translator. In general this should not be overridden, since internal Maya methods are called in this method.'''
        pass

    def writePreConnectAttrsBlock(self, filterOutput): 
        '''writePreConnectAttrsBlock(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file before the connect attrs block.'''
        pass

    def writesSetAttr(self, srcPlug): 
        '''writesSetAttr(self, srcPlug) -> bool
Returns: bool true if the setAttr should be written; false otherwise. 

Arguments:
	[in]	srcPlug = MPlug


Determines if a "setAttr" command should be written for a particular node.'''
        pass

    def writesFileReference(self, referenceFile): 
        '''writesFileReference(self, referenceFile) -> bool
Returns: bool true if the fileReference should be written; false otherwise. 

Arguments:
	[in]	referenceFile = MFileObject


Determines if a "fileReference" command should be written for a file.'''
        pass

    def writesSelectNode(self, node): 
        '''writesSelectNode(self, node) -> bool
Returns: bool true if the select should be written; false otherwise. 

Arguments:
	[in]	node = MObject


Determines if a "select" command should be written for a particular node.'''
        pass

    def processReadOptions(self, optionsString): 
        '''processReadOptions(self, optionsString)
Arguments:
	[in]	optionsString = MString


Allows the translator to handle any options passed into the  reader()  method, above. This call is made before the file is actually read. The default implementation does nothing.'''
        pass

    def haveWriteMethod(self): 
        '''haveWriteMethod(self) -> bool


Overrides  MPxFileTranslator::haveWriteMethod()  to indicate that this translator has a write method. In general this should not be overridden.'''
        pass

    def writePostConnectAttrsBlock(self, filterOutput): 
        '''writePostConnectAttrsBlock(self, filterOutput)
Arguments:
	[in]	filterOutput = MPxMayaAsciiFilterOutput


Allows data to be written out to the file after the connect attrs block.'''
        pass

class MPxMidiInputDevice:
    '''Midi input device. This is the base class for user defined MIDI input devices.Child classes of MPxMidiInputDevice should define:'''
    def __init__(self):
        pass


    def nameButtons(self): 
        '''nameButtons(self)

Assign names to the buttons of the device. 
  Reprocessed example  
 Examples: 
 
   
 jlcVcrDevice.cpp . 
 
'''
        pass

    def addChannel(self, channel): 
        '''addChannel(self, channel)
Arguments:
	[in]	channel = MDeviceChannel

'''
        pass

    def nameAxes(self): 
        '''nameAxes(self)

Assign names to the axes of the device. 
  Reprocessed example  
 Examples: 
 
   
 jlcVcrDevice.cpp . 
 
'''
        pass

    def doMovementEvents(self, val): 
        '''doMovementEvents(self, val)
Arguments:
	[in]	val = bool

'''
        pass

    def setNumberOfButtons(self, buttons): 
        '''setNumberOfButtons(self, buttons)
Arguments:
	[in]	buttons = int

'''
        pass

    def doButtonEvents(self, val): 
        '''doButtonEvents(self, val)
Arguments:
	[in]	val = bool

'''
        pass

    def openDevice(self): 
        '''openDevice(self)
'''
        pass

    def closeDevice(self): 
        '''closeDevice(self)
'''
        pass

    def getMessage(self, messageType, messageResponse): 
        '''getMessage(self, messageType, messageResponse) -> char*

Arguments:
	[in]	messageType = char
	[in]	messageResponse = char

'''
        pass

    def sendMessage(self, messageType, messageParams): 
        '''sendMessage(self, messageType, messageParams)
Arguments:
	[in]	messageType = char
	[in]	messageParams = char

'''
        pass

    def setNamedButton(self, buttonName, button): 
        '''setNamedButton(self, buttonName, button)
Arguments:
	[in]	buttonName = MString
	[in]	button = short

'''
        pass

    def setDegreesOfFreedom(self, freedom): 
        '''setDegreesOfFreedom(self, freedom)
Arguments:
	[in]	freedom = int

'''
        pass

    def deviceState(self): 
        '''deviceState(self) -> MDeviceState


Return the current state of the input device. 
  Reprocessed example  
 Examples: 
 
   
 jlcVcrDevice.cpp . 
 
'''
        pass

class MPxModelEditorCommand:
    '''Base class for editor creation commands. MPxModelEditorCommand is the base class for user defined model editor commands. This command gives all of the flags and options of the modelEditor command in addition to any user defined flags or behaviours. When registering this command, use the MFnPlugin::MFnPlugin::registerModelEditorCommand() method. A MPx3dModelView is also required to be used with MPxModelEditorCommand and is specified when the MPxModelEditorCommand is registered. '''
    def __init__(self):
        pass


    def parser(self): 
        '''parser(self) -> MArgParser
Returns: The argument parser


USE _parser() IN SCRIPT. 
'''
        pass

    def doEditFlags(self): 
        '''doEditFlags(self)

This method is called when the command is called in edit mode. This method should be overridden by panel commands to determine which edit flags are set in conjunction with the argument parser for this command. The argument parser for this command can be obtained by calling the parser method. If the command is called with both the edit flag and the query flag, then the query flag will be ignored.'''
        pass

    def skipFlagForCreate(self, longFlag): 
        '''skipFlagForCreate(self, longFlag) -> bool
Returns: Return true if the flag shoiuld be skipped during creation.

Arguments:
	[in]	longFlag = MString


Returns true if the passed long flag name should be skipped during the creation portion of the command.'''
        pass

    def makeModelView(self): 
        '''makeModelView(self) -> MPx3dModelView
Returns: NULL - unable to create the modelView for this command. 
pointer to modelView - modelView successfully created. 


This method is called when the modelEditor is being created and it can be overriden to allow the user to handle the allocation of the modelView directly. Also, as this method exists on  MPxModelEditorCommand , the user has direct access to the command line flags in create mode for the command (an example use would be to detect that a -quadbuffer flag was passed on creating the view, and you could then bring up the panel with quadbuffering enabled).'''
        pass

    def doQueryFlags(self): 
        '''doQueryFlags(self)

This method is called when the command is called in query mode. This method should be overridden by panel commands to determine which query flags are set in conjunction with the argument parser for this command. The argument parser for this command can be obtained by calling the parser method. If the command is called with both the edit flag and the query flag, then the query flag will be ignored.'''
        pass

    def syntax(self): 
        '''syntax(self) -> MSyntax
Returns: The syntax object


USE _syntax() IN SCRIPT. 
'''
        pass

    def editorCommandName(self): 
        '''editorCommandName(self) -> MString


Returns the name of editor command.'''
        pass

    def modelView(self): 
        '''modelView(self) -> MPx3dModelView


Returns a pointer to the  MPx3dModelView  created by this command. If the  MPx3dModelView  was not created, NULL may be returned.'''
        pass

    def setResult(self, result): 
        '''setResult(self, result)
Arguments:
	[out]	result = MIntArray


This method should be called when the result of the panel command is an integer array.'''
        pass

    def appendSyntax(self): 
        '''appendSyntax(self)

This method should be overridden to append syntax to the panel command. The syntax object can be obtained by calling the syntax method. The following flags cannot be used as user-defined flags as they are reserved for edit and query: "-e", "-edit", "-q", "-query".'''
        pass

    def editorMenuScriptName(self): 
        '''editorMenuScriptName(self) -> MString


Returns the name of the script that should get executed to construct the menu for the editor. The script should take a string argument that holds the name of the created editor.'''
        pass

class MPxNode:
    '''Base class for user defined dependency nodes. MPxNode is the the parent class for user defined dependency nodes. A dependency node is an object that resides in the dependency graph. It computes output attributes based on a set of input attributes. When an input changes, the compute method is called for each dependent output.The dependency graph is made up of nodes that have connections between their attributes. When an attribute changes, recomputation propagates through the graph until all affected values have been updated.When writing a dependency node, there is a very basic rule that should be observed. The outputs should be calculated only using the values of the inputs. All information about the world outside the node should come from input attributes. If this rule is not observed, then the results may be unpredictable.All dependency nodes have four basic attributes. Documentation for them may be found with the documentation for the dependency nodes in Maya. Only one attribute requires special attention by node developers. Developers must decide whether to support the  setting of the  attribute. { means that a node should pass through all data without performing computations on it. For example, a deformer node will pass geometry through unmodified when  is set to . It is up the the plug-in writer to observe the  if it is relevant to the type of node. '''
    def __init__(self):
        pass


    isHistoricallyInteresting = ''
    '''is historically interesting attribute '''

    setMPSafe = ''
    '''USE _setMPSafe() IN SCRIPT.  '''

    state = ''
    '''state attribute '''

    forceCache = ''
    '''USE _forceCache() IN SCRIPT.  '''

    caching = ''
    '''caching attribute '''

    message = ''
    '''message attribute '''

    def typeId(self): 
        '''typeId(self) -> MTypeId


Returns the TYPEID of this node. The TYPEID is a four byte identifier that uniquely identifies this type of node to the binary file format.'''
        pass

    def addAttribute(self, attr): 
        '''addAttribute(self, attr)
Arguments:
	[in]	attr = MObject


This method adds a new attribute to a user defined node type during the type's initialization.'''
        pass

    def connectionMade(self, plug, otherPlug, asSrc): 
        '''connectionMade(self, plug, otherPlug, asSrc)
Arguments:
	[in]	plug = MPlug
	[in]	otherPlug = MPlug
	[in]	asSrc = bool


This method gets called when connections are made to attributes of this node.'''
        pass

    def passThroughToMany(self, plug, plugArray): 
        '''passThroughToMany(self, plug, plugArray) -> bool
Returns: true if plug was handled, false to invoke base class implementation 

Arguments:
	[in]	plug = MPlug
	[in]	plugArray = MPlugArray


This method is overriden by nodes that want to control the traversal behavior of some Maya search algorithms which traverse the history/future of shape nodes looking for directly related nodes. In particular, the Artisan paint code uses this method when searching for paintable nodes, and the disk cache code uses this method when searching for upstream cacheFile nodes.'''
        pass

    def typeName(self): 
        '''typeName(self) -> MString


Returns the type name of this node. The type name identifies the node type to the ASCII file format. It may also be used with the MEL command "createNode" to create a new node of this type.'''
        pass

    def shouldSave(self, plug, isSaving): 
        '''shouldSave(self, plug, isSaving)
Arguments:
	[in]	plug = MPlug
	[in]	isSaving = bool


This method may be overridden by the user defined node. It should only be required to override this on rare occasions.'''
        pass

    def internalArrayCount(self, plug, ctx): 
        '''internalArrayCount(self, plug, ctx) -> int

Arguments:
	[in]	plug = MPlug
	[in]	ctx = MDGContext


This method is overriden by nodes that have internal array attributes which are not stored in Maya's datablock. This method is used by Maya to determine the non-sparse count of array elements during file io. If the internal array is stored sparsely, you should return the maximum index of the array plus one. If the internal array is non-sparse then return the length of the array.'''
        pass

    def kFieldNode(self):
        '''This is an enum of Type.
Description: Custom field derived from
Value: 5'''
        pass

    def kDependNode(self):
        '''This is an enum of Type.
Description: Custom node derived from
Value: 0'''
        pass

    def kObjectSet(self):
        '''This is an enum of Type.
Description: Custom set derived from
Value: 12'''
        pass

    def kParticleAttributeMapperNode(self):
        '''This is an enum of Type.
Description: Custom particle attribute mapper derived from
Value: 15'''
        pass

    def kSpringNode(self):
        '''This is an enum of Type.
Description: Custom spring derived from
Value: 7'''
        pass

    def kFluidEmitterNode(self):
        '''This is an enum of Type.
Description: Custom fluid emitter derived from MpxFluidEmitterNode.
Value: 13'''
        pass

    def kHwShaderNode(self):
        '''This is an enum of Type.
Description: Custom shader derived from
Value: 10'''
        pass

    def kImagePlaneNode(self):
        '''This is an enum of Type.
Description: Custom image plane derived from
Value: 14'''
        pass

    def kHardwareShader(self):
        '''This is an enum of Type.
Description: Custom shader derived from
Value: 9'''
        pass

    def kManipulatorNode(self):
        '''This is an enum of Type.
Description: Custom manipulator derived from
Value: 17'''
        pass

    def kConstraintNode(self):
        '''This is an enum of Type.
Description: Custom constraint derived from
Value: 16'''
        pass

    def kSurfaceShape(self):
        '''This is an enum of Type.
Description: Custom shape derived from
Value: 4'''
        pass

    def kTransformNode(self):
        '''This is an enum of Type.
Description: Custom transform derived from
Value: 11'''
        pass

    def kLast(self):
        '''This is an enum of Type.
Description: Last value, used for counting.
Value: 18'''
        pass

    def kEmitterNode(self):
        '''This is an enum of Type.
Description: Custom emitter derived from
Value: 6'''
        pass

    def kDeformerNode(self):
        '''This is an enum of Type.
Description: Custom deformer derived from
Value: 2'''
        pass

    def kIkSolverNode(self):
        '''This is an enum of Type.
Description: Custom IK solver derived from
Value: 8'''
        pass

    def kManipContainer(self):
        '''This is an enum of Type.
Description: Custom container derived from
Value: 3'''
        pass

    def kLocatorNode(self):
        '''This is an enum of Type.
Description: Custom locator derived from
Value: 1'''
        pass

    class Type:
        '''Non-functional class.  Values for this enum:
        kFieldNode
        kDependNode
        kObjectSet
        kParticleAttributeMapperNode
        kSpringNode
        kFluidEmitterNode
        kHwShaderNode
        kImagePlaneNode
        kHardwareShader
        kManipulatorNode
        kConstraintNode
        kSurfaceShape
        kTransformNode
        kLast
        kEmitterNode
        kDeformerNode
        kIkSolverNode
        kManipContainer
        kLocatorNode
'''
        def __init__(self):
            pass

    def attributeAffects(self, whenChanges, isAffected): 
        '''attributeAffects(self, whenChanges, isAffected)
Arguments:
	[in]	whenChanges = MObject
	[in]	isAffected = MObject


This method specifies that a particular input attribute affects a specific output attribute. This is required to make evaluation efficient. When an input changes, only the affected outputs will be computed. Output attributes cannot be keyable - if they are keyable, this method will fail.'''
        pass

    def setMPSafe(self, flag): 
        '''setMPSafe(self, flag)
Arguments:
	[in]	flag = bool


USE _setMPSafe() IN SCRIPT. 
'''
        pass

    def isPassiveOutput(self, plug): 
        '''isPassiveOutput(self, plug) -> bool
Returns: true indicates passive 

Arguments:
	[in]	plug = MPlug


This method may be overridden by the user defined node if it wants to provide output attributes which do not prevent value modifications to the destination attribute. For example, output plugs on animation curve nodes are passive. This allows the attributes driven by the animation curves to be set to new values by the user.'''
        pass

    def existWithoutInConnections(self): 
        '''existWithoutInConnections(self) -> bool


Determines whether or not this node can exist without input connections.'''
        pass

    def getInternalValueInContext(self, plug, ctx, dataHandle): 
        '''getInternalValueInContext(self, plug, ctx, dataHandle) -> bool
Returns: true the attribute was place on the datablock 
false could not handle the specified attribute, pass this request to the default handler 

Arguments:
	[in]	plug = MPlug
	[out]	dataHandle = MDataHandle
	[in]	ctx = MDGContext


This method is overriden by nodes that store attribute data in some internal format.'''
        pass

    def setInternalValueInContext(self, plug, dataHandle, ctx): 
        '''setInternalValueInContext(self, plug, dataHandle, ctx) -> bool
Returns: true the attribute was set 
false could not handle the specified attribute, pass this request to the default handler 

Arguments:
	[in]	plug = MPlug
	[in]	dataHandle = MDataHandle
	[in]	ctx = MDGContext


This method is overriden by nodes that store attribute data in some internal format.'''
        pass

    def passThroughToOne(self, plug): 
        '''passThroughToOne(self, plug) -> MPlug
Returns: The corresponding plug, or an empty plug if no corresponding plug exists 

Arguments:
	[in]	plug = MPlug


This method may be overriden by nodes that have a one-to-one relationship between an input attribute and a corresponding output attribute. This method is used by Maya to perform the following capabilities:'''
        pass

    def existWithoutOutConnections(self): 
        '''existWithoutOutConnections(self) -> bool


Determines whether or not this node can exist without output connections.'''
        pass

    def postConstructor(self): 
        '''postConstructor(self)

Post constructor.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


Returns the type of node that this is. This is used to differentiate user defined nodes that are derived off different MPx base classes.'''
        pass

    def legalConnection(self, plug, otherPlug, asSrc, isLegal): 
        '''legalConnection(self, plug, otherPlug, asSrc, isLegal)
Arguments:
	[in]	plug = MPlug
	[in]	otherPlug = MPlug
	[in]	asSrc = bool
	[in]	isLegal = bool


This method allows you to check for legal connections being made to attributes of this node.'''
        pass

    def thisMObject(self): 
        '''thisMObject(self) -> MObject


Returns the  MObject  associated with this user defined node. This makes it possible to use  MFnDependencyNode  or to construct plugs to this node's attributes.'''
        pass

    def setExistWithoutInConnections(self, flag): 
        '''setExistWithoutInConnections(self, flag)
Arguments:
	[in]	flag = bool


This method specifies whether or not the node can exist without input connections.'''
        pass

    def setExistWithoutOutConnections(self, flag): 
        '''setExistWithoutOutConnections(self, flag)
Arguments:
	[in]	flag = bool


This method specifies whether or not the node can exist without output connections.'''
        pass

    def forceCache(self, context): 
        '''forceCache(self, context) -> MDataBlock
Returns: The datablock 

Arguments:
	[in]	context = MDGContext


USE _forceCache() IN SCRIPT. 
'''
        pass

    def connectionBroken(self, plug, otherPlug, asSrc): 
        '''connectionBroken(self, plug, otherPlug, asSrc)
Arguments:
	[in]	plug = MPlug
	[in]	otherPlug = MPlug
	[in]	asSrc = bool


This method gets called when connections are broken with attributes of this node.'''
        pass

    def setDoNotWrite(self, flag): 
        '''setDoNotWrite(self, flag)
Arguments:
	[in]	flag = bool


Use this method to mark the "do not write" state of this proxy node. If set, this node will not be saved when the Maya model is written out.'''
        pass

    def copyInternalData(self, node): 
        '''copyInternalData(self, node)
Arguments:
	[in]	node = MPxNode


This method is overriden by nodes that store attribute data in some internal format.'''
        pass

    def compute(self, plug, block): 
        '''compute(self, plug, block)
Arguments:
	[in]	plug = MPlug
	[out]	block = MDataBlock


This method should be overridden in user defined nodes.'''
        pass

    def name(self): 
        '''name(self) -> MString


Returns the name of this particular instance of this class. Each object in the dependency graph has a name. This name will be used by the UI and by MEL.'''
        pass

    def setDependentsDirty(self, plugBeingDirtied, affectedPlugs): 
        '''setDependentsDirty(self, plugBeingDirtied, affectedPlugs)
Arguments:
	[in]	plugBeingDirtied = MPlug
	[in]	affectedPlugs = MPlugArray


This method can be overridden in user defined nodes to specify which plugs should be set dirty based upon an input plug { plugBeingDirtied}  which Maya is marking dirty. The list of plugs for Maya to mark dirty is returned by the plug array { affectedPlugs} . This method handles both dynamic as well as non-dynamic plugs and is useful in the following ways:'''
        pass

    def legalDisconnection(self, plug, otherPlug, asSrc, isLegal): 
        '''legalDisconnection(self, plug, otherPlug, asSrc, isLegal)
Arguments:
	[in]	plug = MPlug
	[in]	otherPlug = MPlug
	[in]	asSrc = bool
	[out]	isLegal = bool


This method allows you to check for legal disconnections being made to attributes of this node.'''
        pass

    def isAbstractClass(self): 
        '''isAbstractClass(self) -> bool


Override this class to return true if this node is an abstract node. An abstract node can only be used as a base class. It cannot be created using the 'createNode' command.'''
        pass

    def doNotWrite(self): 
        '''doNotWrite(self) -> bool


Use this method to query the "do not write" state of this proxy node. True is returned if this node will not be saved when the Maya model is written out.'''
        pass

    def inheritAttributesFrom(self, parentClassName): 
        '''inheritAttributesFrom(self, parentClassName)
Arguments:
	[in]	parentClassName = MString


This method allows a class of plugin node to inherit all of the attributes of a second class of plugin node.'''
        pass

class MPxObjectSet:
    '''Parent class of all user defined object sets. MPxObjectSet is the parent class of all user defined sets. '''
    def __init__(self):
        pass


    editPointsOnlySet = ''
    '''References to the partition nodes this set is a member of. '''

    verticesOnlySet = ''
    '''References to the partition nodes this set is a member of. '''

    edgesOnlySet = ''
    '''References to the partition nodes this set is a member of. '''

    groupNodes = ''
    '''References to nodes that operate upon this set, such as deformers. '''

    partition = ''
    '''References to the partition nodes this set is a member of. '''

    memberWireframeColor = ''
    '''A text string to annotate the set. '''

    facetsOnlySet = ''
    '''References to the partition nodes this set is a member of. '''

    usedByNodes = ''
    '''References to nodes that operate upon this set, such as deformers. '''

    DNSetMembers = ''
    '''References to dependNode attributes which defines set membership. '''

    isLayer = ''
    '''This attribute is obsolete and should no longer be used. '''

    dagSetMembers = ''
    '''References to dependNode attributes which defines set membership. '''

    annotation = ''
    '''A text string to annotate the set. '''

    renderableOnlySet = ''
    '''References to the partition nodes this set is a member of. '''



    def canBeDeleted(self, isSrcNode): 
        '''canBeDeleted(self, isSrcNode) -> bool
Returns: true Delete this node 
false Do not delete this node 

Arguments:
	[in]	isSrcNode = bool


A method that is called whenever a neighboring node is deleted, to check if this node should be deleted alongside or as a result of the neighboring node. This method will not be called in the case where construction history is being deleted.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


Returns the type of node that this is. This is used to differentiate user defined nodes that are derived off different MPx base classes.'''
        pass

class MPxParticleAttributeMapperNode:
    '''User defined per particle attribute mapping nodes. MPxParticleAttributeMapperNode is the parent class of all user defined per particle attribute mapping nodes. This class extends Maya's internal 'arrayMapper' node, inheriting its attributes and default behaviour. '''
    def __init__(self):
        pass


    computeNodeColorG = ''
    '''The G component of the computeNodeColor. '''

    outColorPP = ''
    '''The outputColor vector per-particle attribute. '''

    computeNodeColorB = ''
    '''The B component of the computeNodeColor. '''

    time = ''
    '''This attribute holds the value for time (in seconds). '''

    computeNodeColor = ''
    '''This attribute allows the propagation of any changes to the. '''

    vCoordPP = ''
    '''The V component of an array of sample positions. '''

    computeNode = ''
    '''Input node used to compute output values. '''

    outMaxValue = ''
    '''The maximum limit on the output attribute outValuePP. '''

    uCoordPP = ''
    '''The U component of an array of sample positions. '''

    computeNodeColorR = ''
    '''The R component of the computeNodeColor. '''

    outMinValue = ''
    '''The minimum limit on the output attribute outValuePP. '''

    outValuePP = ''
    '''The outputValue vector per-particle attribute. '''

    def compute(self, plug, dataBlock): 
        '''compute(self, plug, dataBlock)
Arguments:
	[in]	plug = MPlug
	[out]	dataBlock = MDataBlock


This method should be overridden in user defined nodes.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


Returns the type of node that this is. This is used to differentiate user defined nodes that are derived off different MPx base classes.'''
        pass

class MPxPolyTrg:
    '''User defined poly triangulation support.  is the the parent class for nodes which define a custom face triangulation for meshes. In order to override default maya triangulation, the user has to do the following things:Note: The number of vertices can be calculated by adding all the loop sizes.The output of this function is an array of triangle description:nbTrg = 2 trg: 0 1 2 2 3 0Tip: Refer to the example plugin:  for more details on how to implement it. Once the node is defined, the user has to inform the mesh about it. For each mesh the user wants to override the default triangulation, he has to set the  attribute on the mesh to the name under which the function has been registered.Example: /code setAttr mesh.userTrg -type "string" "triangulate"; /endcodeOnce that attribute is set, the default maya triangulation is turned off and the one provided by the user is used to draw the mesh. '''
    def __init__(self):
        pass


    def postConstructor(self): 
        '''postConstructor(self)

Post constructor.'''
        pass

    def unregisterTrgFunction(self, functName): 
        '''unregisterTrgFunction(self, functName)
Arguments:
	[in]	functName = char


 Parameters: 
 
 [in]   functName   Function name under which the function is register with maya. 
 
 
 Returns: Status code 
 Status Codes: 
 MS::kSuccess  Compute was successful  
 MS::kFailure  Compute failed  
 
 
'''
        pass

    def registerTrgFunction(self, functName, funct): 
        '''registerTrgFunction(self, functName, funct)
Arguments:
	[in]	functName = char
	[in]	funct = polyTrgFnct


Register a triangulation function with maya. The name provided as a first argument is the name under which the function is registered. This name has to be used when setting 'userTrg' attribute on a mesh.'''
        pass

    def compute(self, plug, block): 
        '''compute(self, plug, block)
Arguments:
	[in]	plug = MPlug
	[out]	block = MDataBlock


This method should be overridden in user defined nodes. However, fror this particaular node we don't need to to do anything in the compute functione. Therefore, all we do is return MS:kSuccess in the derive class.'''
        pass

    def isAbstractClass(self): 
        '''isAbstractClass(self) -> bool


Each new node has to implement that fuction. It returns false since this is not an abstract class.'''
        pass

class MPxPolyTweakUVCommand:
    '''Base class used for moving polygon UV's. This is the base class for UV editing commands on polygonal objects.The purpose of this command class is to simplify the process of moving UVs on a polygonal object. The use is only required to provide the new positions of the UVs that have been modified. '''
    def __init__(self):
        pass


    def getTweakedUVs(self, mesh, uvList, uPos, vPos): 
        '''getTweakedUVs(self, mesh, uvList, uPos, vPos)
Arguments:
	[in]	mesh = MObject
	[in]	uvList = MIntArray
	[out]	uPos = MFloatArray
	[out]	vPos = MFloatArray


This computes and returns modified UVs.'''
        pass

    def newSyntax(self): 
        '''newSyntax(self) -> MSyntax


This method creates and returns an  MSyntax  object required for the poly tweak UV proxy command. 
  Reprocessed example  
 Examples: 
 
   
 flipUVCmd.cpp , and  flipUVCmd.h . 
 
'''
        pass

    def parseSyntax(self, argData): 
        '''parseSyntax(self, argData)
Arguments:
	[in]	argData = MArgDatabase


This method parses the additionnal flags before the command is executed.'''
        pass

class MPxRenderPassImpl:
    '''Render pass implementation. The MPxRenderPassImpl class is an abstract base class which provides a common interface for pass implementations. Extend this class to create custom pass implementations. '''
    def __init__(self):
        pass


    def getNumChannels(self): 
        '''getNumChannels(self) -> int


Called by Maya to get the number of channels supported by this pass'''
        pass

    def frameBufferSemantic(self): 
        '''frameBufferSemantic(self) -> MPxRenderPassImpl.PassSemantic


Called by Maya to get the frame buffer semantic. The semantic is an enum that provides a hint on the nature of the data stored in the frame buffer. This hint may affect how the renderer interpolates and filters sample values.'''
        pass

    def isCompatible(self, renderer): 
        '''isCompatible(self, renderer) -> bool
Returns: true if the implementation is compatible 

Arguments:
	[in]	renderer = MString


Called by Maya check whether this pass implementation is compatible with the given renderer.'''
        pass

    def kFloat32(self):
        '''This is an enum of PassTypeBit.
Description: single precision floating point
Value: 512'''
        pass

    def kFloat16(self):
        '''This is an enum of PassTypeBit.
Description: half precision floating point
Value: 256'''
        pass

    def kUInt32(self):
        '''This is an enum of PassTypeBit.
Description: Unsigned 32-bit integer.
Value: 4'''
        pass

    def kInt16(self):
        '''This is an enum of PassTypeBit.
Description: Signed 16-bit integer.
Value: 32'''
        pass

    def kUInt8(self):
        '''This is an enum of PassTypeBit.
Description: Unsigned 8-bit integer.
Value: 1'''
        pass

    def kOther(self):
        '''This is an enum of PassTypeBit.
Description: undefined type
Value: 4096'''
        pass

    def kInt64(self):
        '''This is an enum of PassTypeBit.
Description: Signed 64-bit integer.
Value: 128'''
        pass

    def kBit(self):
        '''This is an enum of PassTypeBit.
Description: single bit
Value: 2048'''
        pass

    def kFloat64(self):
        '''This is an enum of PassTypeBit.
Description: double precision floating point
Value: 1024'''
        pass

    def kInt32(self):
        '''This is an enum of PassTypeBit.
Description: Signed 32-bit integer.
Value: 64'''
        pass

    def kUInt64(self):
        '''This is an enum of PassTypeBit.
Description: Unsigned 64-bit integer.
Value: 8'''
        pass

    def kUInt16(self):
        '''This is an enum of PassTypeBit.
Description: Unsigned 16-bit integer.
Value: 2'''
        pass

    def kInt8(self):
        '''This is an enum of PassTypeBit.
Description: Signed 8-bit integer.
Value: 16'''
        pass

    class PassTypeBit:
        '''Non-functional class.  Values for this enum:
        kFloat32
        kFloat16
        kUInt32
        kInt16
        kUInt8
        kOther
        kInt64
        kBit
        kFloat64
        kInt32
        kUInt64
        kUInt16
        kInt8
'''
        def __init__(self):
            pass

    def perLightPassContributionSupported(self): 
        '''perLightPassContributionSupported(self) -> bool


Called by Maya to determine if this pass implementation supports per-light contributions defined by pass contribution maps.'''
        pass

    def typesSupported(self): 
        '''typesSupported(self) -> MPxRenderPassImpl.PassTypeMask


Called by Maya to determine which types are supported by this pass'''
        pass

    def kVectorSemantic(self):
        '''This is an enum of PassSemantic.
Description: General vector data (e.g. motion vectors, surface displacements).
Value: 2'''
        pass

    def kInvalidSemantic(self):
        '''This is an enum of PassSemantic.
Description: Invalid.
Value: 0'''
        pass

    def kDirectionVectorSemantic(self):
        '''This is an enum of PassSemantic.
Description: Vectors that represent a direction (e.g. surface normals, light directions).
Value: 3'''
        pass

    def kOtherSemantic(self):
        '''This is an enum of PassSemantic.
Description: Undefined, unknown or custom semantic.
Value: 7'''
        pass

    def kColorSemantic(self):
        '''This is an enum of PassSemantic.
Description: RGB, RGBA, alpha, luminance, etc.
Value: 1'''
        pass

    def kLabelSemantic(self):
        '''This is an enum of PassSemantic.
Description: Labels, such as material tags or object tags.
Value: 5'''
        pass

    def kDepthSemantic(self):
        '''This is an enum of PassSemantic.
Description: Depth or range data.
Value: 4'''
        pass

    def kMaskSemantic(self):
        '''This is an enum of PassSemantic.
Description: Pixel mask (e.g. a stencil buffer).
Value: 6'''
        pass

    class PassSemantic:
        '''Non-functional class.  Values for this enum:
        kVectorSemantic
        kInvalidSemantic
        kDirectionVectorSemantic
        kOtherSemantic
        kColorSemantic
        kLabelSemantic
        kDepthSemantic
        kMaskSemantic
'''
        def __init__(self):
            pass

    def getDefaultType(self): 
        '''getDefaultType(self) -> MPxRenderPassImpl.PassTypeBit


Called by Maya to determine the default type for this pass'''
        pass

class MPxSelectionContext:
    '''Base class for interative selection tools. This class is used in creating user defined tools that use the internal selection mechanism in maya. '''
    def __init__(self):
        pass


    def lastDragPoint(self): 
        '''lastDragPoint(self) -> MPoint


USE _lastDragPoint() IN SCRIPT. 
'''
        pass

    def argTypeNumericalInput(self, index): 
        '''argTypeNumericalInput(self, index) -> MSyntax.MArgType
Returns: MSyntax::kNoArg the default return value 

Arguments:
	[in]	index = int


This method is used by the feedback line to determine what units to display. Users should override this method to return the appropriate argument type for the given index of the numeric input field. Specifically, this method should be overridden to return one of the following:'''
        pass

    def isSelecting(self): 
        '''isSelecting(self) -> bool


USE _isSelecting() IN SCRIPT. 
'''
        pass

    def processNumericalInput(self, values, flags, isAbsolute): 
        '''processNumericalInput(self, values, flags, isAbsolute) -> bool
Returns: false the default return value. 

Arguments:
	[in]	values = MDoubleArray
	[in]	flags = MIntArray
	[in]	isAbsolute = bool


This method processes the input from the numerical input field. Users can override this method if they wish to process numerical input. For a given entry in the numeric input field, if the user types a dot ".", this indicates that the entry should not be modified. The overridden version of this method should take this into account using the ignoreEntry method with the flags that are passed in. The overridden version of this method should also process the numeric input as an absolute input or relative input depending on whether the isAbsolute flag is true or not. The return value should indicate whether or not the numerical input has been processed.'''
        pass

    def newToolCommand(self): 
        '''newToolCommand(self) -> MPxToolCommand


CALL _newToolCommand() IN SCRIPT. 
'''
        pass

    def setImage(self, image, index): 
        '''setImage(self, image, index)
Arguments:
	[in]	image = MString
	[in]	index = MPxSelectionContext.ImageIndex


This method is used to set an XPM icon image that is to be used to represent this tool context in various places including the tool bar and can be queried from mel using the contextInfo command.'''
        pass

    def image(self, index): 
        '''image(self, index) -> MString
Returns: String name

Arguments:
	[in]	index = MPxSelectionContext.ImageIndex


This method is used to retrieve an XPM icon image that has previously been set for this tool context. This icon image will be used to represent this tool context in various places including the tool bar and can be queried from mel using the contextInfo command.'''
        pass

    def feedbackNumericalInput(self): 
        '''feedbackNumericalInput(self) -> bool


This method is called to update the numerical feedback. The format and values for the feedback line can be set through the methods in  MFeedbackLine , specifically setFormat and setValue. The return value should indicate whether or not the numerical feedback has been provided.'''
        pass

    def addManipulator(self, manipulator): 
        '''addManipulator(self, manipulator)
Arguments:
	[in]	manipulator = MObject


This method adds a manipulator to the context, and also adds the manipulator to the DAG. Note that the manipulator should not yet be added to the DAG when this method is called.'''
        pass

    def helpStateHasChanged(self, event): 
        '''helpStateHasChanged(self, event)
Arguments:
	[in]	event = MEvent


This method is called whenever the help state may need to be updated. The base method does nothing and should be overriden if the user needs to change the help information based on events.'''
        pass

    def deleteManipulators(self): 
        '''deleteManipulators(self)

This method deletes all the manipulators that belong to the context.'''
        pass

    def abortAction(self): 
        '''abortAction(self)
'''
        pass

    def doRelease(self, event): 
        '''doRelease(self, event)
Arguments:
	[in]	event = MEvent


This method is called when any mouse button is released. The base method does nothing except marquee selection and should be overriden if the user needs to do anything on a button release.'''
        pass

    def getClassName(self, name): 
        '''getClassName(self, name)
Arguments:
	[out]	name = MString


This method is called to determine the name that uniquely identifies the context. This method should be overridden such that the name is set to the appropriate string. For example:           void  MPxExampleContext::getClassName( MString  &name)  const 
          { name. set ( "exampleTool" ); }
'''
        pass

    def doHold(self, event): 
        '''doHold(self, event)
Arguments:
	[in]	event = MEvent


This method is called when after a mouse button is pressed but before the mouse is dragged. The base method does nothing except marquee selection and should be overriden if the user needs to do anything on a button hold.'''
        pass

    def doDrag(self, event): 
        '''doDrag(self, event)
Arguments:
	[in]	event = MEvent


This method is called when a mouse drag event occurs. The base method does nothing except marquee selection and should be overriden if the user needs to do anything during a mouse drag.'''
        pass

    def startPoint(self): 
        '''startPoint(self) -> MPoint


USE _startPoint() IN SCRIPT. 
'''
        pass

    def doPress(self, event): 
        '''doPress(self, event)
Arguments:
	[in]	event = MEvent


This method is called when any mouse button is pressed. The base method does nothing and should be overriden if the user needs to do anything on a button press.'''
        pass

class MPxSpringNode:
    '''Base class for user defined spring law. MPxSpringNode allows the creation and manipulation of dependency graph nodes representing a spring law. The class is a DAG node and Maya manages the drawing, creation, and selection of springs.A user defined spring node is a DAG node that can have attributes and a applySpringLaw() method. To derive the full benefit of the MPxSpringNode class, it is suggested that you do not write your own compute() method. Instead, write the applySpringLaw() method. All of the parameters passed into this method will be supplied by Maya.To create a user defined spring node, derive from this class and override the applySpringLaw() method. The other methods of the parent class MPxNode may also be overridden to perform dependency node capabilities. '''
    def __init__(self):
        pass


    mDeltaTime = ''
    '''delta time attribute '''

    mEnd1Weight = ''
    '''from end weight attribute '''

    mEnd2Weight = ''
    '''to end weight attribute '''

    def applySpringLaw(self, stiffness, damping, restLength, endMass1, endMass2, endP1, endP2, endV1, endV2, forceV1, forceV2): 
        '''applySpringLaw(self, stiffness, damping, restLength, endMass1, endMass2, endP1, endP2, endV1, endV2, forceV1, forceV2)
Arguments:
	[in]	stiffness = double
	[in]	damping = double
	[in]	restLength = double
	[in]	endMass1 = double
	[in]	endMass2 = double
	[in]	endP1 = MVector
	[in]	endP2 = MVector
	[in]	endV1 = MVector
	[in]	endV2 = MVector
	[in]	forceV1 = MVector
	[in]	forceV2 = MVector


This method should be overridden in user defined nodes.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. It should not be overridden by the user. It will return  MPxNode::kSpringNode .'''
        pass

class MPxSurfaceShape:
    '''Parent class of all user defined shapes. MPxSurfaceShape is the parent class of all user defined shapes. User defined shapes are dependency nodes (and DAG nodes) which contain overridable drawing, selection, and component methods.This class can be used to implement new kinds of shapes within Maya that can have selectable/manipulatable components and behave in a similar manner to the default shapes in maya.The UI dependent aspects of the shape should be implemented in a class derived from MPxSurfaceShapeUI. This includes the drawing and interactive selection of the shape and any components that the shape implements. '''
    def __init__(self):
        pass


    instObjGroups = ''
    '''instances object group info attribute '''

    intermediateObject = ''
    '''intermediate object attribute '''

    useObjectColor = ''
    '''controls choice of wireframe dormant object color '''

    nodeBoundingBoxMin = ''
    '''bounding box minimum point '''

    mControlPoints = ''
    '''Control points for the derived shapes. '''

    nodeBoundingBoxSizeX = ''
    '''X component of boundingBoxSize. '''

    worldInverseMatrix = ''
    '''inverse world matrix attribute '''

    isTemplated = ''
    '''template attribute '''

    matrix = ''
    '''matrix attribute '''

    nodeBoundingBoxSize = ''
    '''bounding box size vector '''

    objectGroupId = ''
    '''group id attribute '''

    worldMatrix = ''
    '''world matrix attribute '''

    nodeBoundingBox = ''
    '''bounding box attribute '''

    objectGrpCompList = ''
    '''component in object groups attribute '''

    parentInverseMatrix = ''
    '''inverse parent matrix attribute '''

    objectGroups = ''
    '''object groups attributes '''

    objectGroupColor = ''
    '''group id attribute '''

    visibility = ''
    '''visibility attribute '''

    parentMatrix = ''
    '''parent matrix attribute '''

    nodeBoundingBoxMaxZ = ''
    '''Z component of boundingBoxMax. '''

    nodeBoundingBoxSizeY = ''
    '''Y component of boundingBoxSize. '''

    nodeBoundingBoxSizeZ = ''
    '''Z component of boundingBoxSize. '''

    nodeBoundingBoxMaxY = ''
    '''Y component of boundingBoxMax. '''

    nodeBoundingBoxMinX = ''
    '''X component of boundingBoxMin. '''

    nodeBoundingBoxMinY = ''
    '''Y component of boundingBoxMin. '''

    nodeBoundingBoxMinZ = ''
    '''Z component of boundingBoxMin. '''

    boundingBoxCenterZ = ''
    '''Z component of boundingBoxCenter. '''

    nodeBoundingBoxMax = ''
    '''bounding box maximum point '''

    boundingBoxCenterX = ''
    '''X component of boundingBoxCenter. '''

    boundingBoxCenterY = ''
    '''Y component of boundingBoxCenter. '''

    center = ''
    '''object center attribute '''

    nodeBoundingBoxMaxX = ''
    '''X component of boundingBoxMax. '''

    objectColor = ''
    '''the per object dormant wireframe color '''

    inverseMatrix = ''
    '''inverse matrix attribute '''

    mControlValueZ = ''
    '''Z value of a control point. '''

    mControlValueY = ''
    '''Y value of a control point. '''

    mControlValueX = ''
    '''X value of a control point. '''

    def setRenderable(self, flag): 
        '''setRenderable(self, flag)
Arguments:
	[in]	flag = bool


Specifies whether the shape is a renderable shape. Making a shape renderable allows the shape to have shading group assignments.'''
        pass

    def localShapeOutAttr(self): 
        '''localShapeOutAttr(self) -> MObject


Returns the local output attribute of the shape.'''
        pass

    def acceptsGeometryIterator(self, component, writeable, forReadOnly): 
        '''acceptsGeometryIterator(self, component, writeable, forReadOnly) -> bool
Returns: true the shape can supply an iterator 
false the shape cannot supply an iterator 

Arguments:
	[in]	component = MObject
	[in]	writeable = bool
	[in]	forReadOnly = bool


If the shape can supply a component iterator then then this method should be overridden to return true. The default is to return false. The component argument can be used to when the shape has multiple components and not all of them can be iterator over.'''
        pass

    def worldShapeOutAttr(self): 
        '''worldShapeOutAttr(self) -> MObject


Returns the world space output attribute of the shape.'''
        pass

    def newControlPointComponent(self): 
        '''newControlPointComponent(self) -> MObject


The default action of this method is to return an  MFnSingleIndexedComponent  (of type  MFn::kMeshVertComponent ) in order to support rigid skinning binds.'''
        pass

    def geometryIteratorSetup(self, componentList, components, forReadOnly): 
        '''geometryIteratorSetup(self, componentList, components, forReadOnly) -> MPxGeometryIterator
Returns: The component match result 

Arguments:
	[in]	componentList = MObjectArray
	[in]	components = MObject
	[in]	forReadOnly = bool


This method should be overridden by the user to return a geometry iterator compatible with the user's geometry. A geometry iterator is used for iterating over the components of a shape, such as the vertices of a mesh, in a generic manner.'''
        pass

    def isRenderable(self): 
        '''isRenderable(self) -> bool


Returns true if the shape is a renderable shape. Making a shape renderable allows the shape to have shading group assignments.'''
        pass

    def vertexOffsetDirection(self, component, direction, mode, normalize): 
        '''vertexOffsetDirection(self, component, direction, mode, normalize) -> bool

Arguments:
	[in]	component = MObject
	[in]	direction = MVectorArray
	[in]	mode = MPxSurfaceShape.MVertexOffsetMode
	[in]	normalize = bool


This method should be overridden if the shape supports components that can be moved in the direction of the normal or UV's using the move vertex normal tool.'''
        pass

    def hasActiveComponents(self): 
        '''hasActiveComponents(self) -> bool


This method is used to determine whether or not the shape has active (selected) components.'''
        pass

    def kNoPointCaching(self):
        '''This is an enum of MVertexCachingMode.
Description: No point caching.
Value: 0'''
        pass

    def kUpdatePoints(self):
        '''This is an enum of MVertexCachingMode.
Description: Update the points.
Value: 3'''
        pass

    def kSavePoints(self):
        '''This is an enum of MVertexCachingMode.
Description: Points should be saved for undo in the point cache.
Value: 1'''
        pass

    def kRestorePoints(self):
        '''This is an enum of MVertexCachingMode.
Description: Points should be restored from the point cache.
Value: 2'''
        pass

    class MVertexCachingMode:
        '''Non-functional class.  Values for this enum:
        kNoPointCaching
        kUpdatePoints
        kSavePoints
        kRestorePoints
'''
        def __init__(self):
            pass

    def matchComponent(self, item, spec, list): 
        '''matchComponent(self, item, spec, list) -> MPxSurfaceShape.MatchResult
Returns: The component match result 

Arguments:
	[in]	item = MSelectionList
	[in]	spec = MAttributeSpecArray
	[in]	list = MSelectionList


This method is used to convert the string representation of a component into a component object and to validate that the indices.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


Returns the type of node that this is. This is used to differentiate user defined nodes that are derived off different MPx base classes.'''
        pass

    def match(self, mask, componentList): 
        '''match(self, mask, componentList) -> bool
Returns: true the match was successfull 
false the match failed 

Arguments:
	[in]	mask = MSelectionMask
	[in]	componentList = MObjectArray


This method is used to check for matches between a selection type (or mask) and a given component. If your shape has components representing attributes then this method is used to match up your components with selection masks.'''
        pass

    def closestPoint(self, toThisPoint, theClosestPoint, tolerance): 
        '''closestPoint(self, toThisPoint, theClosestPoint, tolerance)
Arguments:
	[in]	toThisPoint = MPoint
	[in]	theClosestPoint = MPoint
	[in]	tolerance = double


This method is used by Maya in functions (such as select) that require closest point information from your surface.'''
        pass

    def createFullVertexGroup(self): 
        '''createFullVertexGroup(self) -> MObject


This method is used to create a component containing every vertex/CV in the object.'''
        pass

    def getWorldMatrix(self, block, instanceGeom): 
        '''getWorldMatrix(self, block, instanceGeom) -> MMatrix

Arguments:
	[in]	block = MDataBlock
	[in]	instanceGeom = int


Returns  MMatrix  which takes a point from local object space to world space.'''
        pass

    def transformUsing(self, mat, componentList, cachingMode, pointCache): 
        '''transformUsing(self, mat, componentList, cachingMode, pointCache)
Arguments:
	[in]	mat = MMatrix
	[in]	componentList = MObjectArray
	[in]	cachingMode = MPxSurfaceShape.MVertexCachingMode
	[in]	pointCache = MPointArray


Transform the given components using the specified transformation matrix. This method should be overridden if the shape supports components that can be transformed using maya's move, scale, and rotate tools.'''
        pass

    def geometryData(self): 
        '''geometryData(self) -> MObject


Returns the geometry data of the shape. The geometry data must be derived from the  MPxGeometryData  class.'''
        pass

    def deleteComponents(self, componentList, undoInfo): 
        '''deleteComponents(self, componentList, undoInfo) -> bool
Returns: true if this method was successful, false otherwise 

Arguments:
	[in]	componentList = MObjectArray
	[in]	undoInfo = MDoubleArray


This method should be overridden if the shape is to support deletion of components. A list of components to be deleted will be passed in as well as an array of doubles where information about each deleted component can be stored for undo purposes. A typical use for this array is to store knot values or weights for control points that are deleted.'''
        pass

    def boundingBox(self): 
        '''boundingBox(self) -> MBoundingBox


This method should be overridden to return a bounding box for the shape. If this method is overridden, then  MPxSurfaceShape::isBounded  should also be overridden to return true.'''
        pass

    def kObjectChanged(self):
        '''This is an enum of MChildChanged.
Description: Object geometry changed. Internal caches need to be updated.
Value: 0'''
        pass

    def kBoundingBoxChanged(self):
        '''This is an enum of MChildChanged.
Description: Object geometry is unchanged but its bounding box has changed. This might happen if the object was moved or an offset changed.
Value: 1'''
        pass

    class MChildChanged:
        '''Non-functional class.  Values for this enum:
        kObjectChanged
        kBoundingBoxChanged
'''
        def __init__(self):
            pass

    def localShapeInAttr(self): 
        '''localShapeInAttr(self) -> MObject


Returns the input attribute of the shape. This method will be called by Maya to determine if the shape has construction history.'''
        pass

    def activeComponents(self): 
        '''activeComponents(self) -> MObjectArray


Returns a list of active (selected) components for the shape.'''
        pass

    def isBounded(self): 
        '''isBounded(self) -> bool


This method should be overridden to return true if the user supplies a bounding box routine. Supplying a bounding box routine makes refresh and selection more efficient.'''
        pass

    def pointAtParm(self, atThisParm, evaluatedPoint): 
        '''pointAtParm(self, atThisParm, evaluatedPoint) -> bool
Returns: true if a point was found, false otherwise 

Arguments:
	[in]	atThisParm = MPoint
	[out]	evaluatedPoint = MPoint


This method is used by Maya in functions (such as select) that require point at parameter values. This only makes sense for parametric surfaces such as NURBS.'''
        pass

    def componentToPlugs(self, component, list): 
        '''componentToPlugs(self, component, list)
Arguments:
	[in]	component = MObject
	[in]	list = MSelectionList


Converts the given component into a selection list of plugs. This method is used to associate a shapes components into the corresponding attributes (plugs) within the shape. For example, it gets called by the translate manipulator to determine which attributes should be driven by the manipulator, and by the setKeyframe command to determine where to connect animCurves for components.'''
        pass

    def kMatchTooMany(self):
        '''This is an enum of MatchResult.
Description: Not used.
Value: 2'''
        pass

    def kMatchInvalidAttributeRange(self):
        '''This is an enum of MatchResult.
Description: An attribute index was out of range.
Value: 6'''
        pass

    def kMatchNone(self):
        '''This is an enum of MatchResult.
Description: No component was matched.
Value: 1'''
        pass

    def kMatchInvalidAttribute(self):
        '''This is an enum of MatchResult.
Description: Not used.
Value: 4'''
        pass

    def kMatchInvalidAttributeIndex(self):
        '''This is an enum of MatchResult.
Description: The attribute specification contained an index for a non-array attribute.
Value: 5'''
        pass

    def kMatchInvalidAttributeDim(self):
        '''This is an enum of MatchResult.
Description: The attribute specification provided the wrong number of dimensions for an attribute.
Value: 7'''
        pass

    def kMatchInvalidName(self):
        '''This is an enum of MatchResult.
Description: One of the names in the attribute specification was not valid.
Value: 3'''
        pass

    def kMatchOk(self):
        '''This is an enum of MatchResult.
Description: The component was matched without error.
Value: 0'''
        pass

    class MatchResult:
        '''Non-functional class.  Values for this enum:
        kMatchTooMany
        kMatchInvalidAttributeRange
        kMatchNone
        kMatchInvalidAttribute
        kMatchInvalidAttributeIndex
        kMatchInvalidAttributeDim
        kMatchInvalidName
        kMatchOk
'''
        def __init__(self):
            pass

    def convertToTweakNodePlug(self, plug): 
        '''convertToTweakNodePlug(self, plug) -> bool
Returns: true if a tweak node was found, false if the plug was unchanged 

Arguments:
	[in]	plug = MPlug


Check if a tweak node is connected to this node. If it is, then reset the supplied plug to contain the controlPoints attribute on the tweak node.'''
        pass

    def undeleteComponents(self, componentList, undoInfo): 
        '''undeleteComponents(self, componentList, undoInfo) -> bool
Returns: true if this method was successful, false otherwise 

Arguments:
	[in]	componentList = MObjectArray
	[in]	undoInfo = MDoubleArray


This method should be overridden if the shape is to support undeletion of components. A list of components to be deleted will be passed in as well as an array of doubles where information about each deleted component is stored for undo purposes. A typical use for this array is to store knot values or weights for control points that are deleted.'''
        pass

    def tweakUsing(self, mat, componentList, cachingMode, pointCache, handle): 
        '''tweakUsing(self, mat, componentList, cachingMode, pointCache, handle)
Arguments:
	[in]	mat = MMatrix
	[in]	componentList = MObjectArray
	[in]	cachingMode = MPxSurfaceShape.MVertexCachingMode
	[in]	pointCache = MPointArray
	[in]	handle = MArrayDataHandle


Transform the given components using the specified transformation matrix. This method should be overridden if the shape supports components that can be transformed using maya's move, scale, and rotate tools. This method is called when the shape has history & connected to a tweak node. The most common reason why the shape would be connected to a tweak node is if it is being deformed. When a shape is connected to a tweak node, transformations applied to the points are placed in the tweak node rather than in the shape itself.'''
        pass

    def childChanged(self, state): 
        '''childChanged(self, state)
Arguments:
	[in]	state = MPxSurfaceShape.MChildChanged


This method can be used to trigger the shape to recalculate its bounding box.'''
        pass

    def kUVNTriad(self):
        '''This is an enum of MVertexOffsetMode.
Description: Calculate u, v, and normal offsets.
Value: 3'''
        pass

    def kNormal(self):
        '''This is an enum of MVertexOffsetMode.
Description: Move in normal direction.
Value: 0'''
        pass

    def kUTangent(self):
        '''This is an enum of MVertexOffsetMode.
Description: Move in u tangent direction.
Value: 1'''
        pass

    def kVTangent(self):
        '''This is an enum of MVertexOffsetMode.
Description: Move in v tangent direction.
Value: 2'''
        pass

    class MVertexOffsetMode:
        '''Non-functional class.  Values for this enum:
        kUVNTriad
        kNormal
        kUTangent
        kVTangent
'''
        def __init__(self):
            pass

    def cachedShapeAttr(self): 
        '''cachedShapeAttr(self) -> MObject


Returns the cached shape attribute of the shape.'''
        pass

class MPxSurfaceShapeUI:
    '''drawing and selection for user defined shapes The base class for the UI portion of all user defined shapes. '''
    def __init__(self):
        pass


    def surfaceShape(self): 
        '''surfaceShape(self) -> MPxSurfaceShape


Returns the non-ui shape associated with current instance of this class.'''
        pass

    def getDrawData(self, geom, data): 
        '''getDrawData(self, geom, data)
Arguments:
	[in]	geom = void
	[out]	data = MDrawData


Sets up draw data for the shape. The draw data is meant to be a light weight class which can be used to pass geometry data through draw requests.'''
        pass

    def draw(self, request, view): 
        '''draw(self, request, view)
Arguments:
	[in]	request = MDrawRequest
	[in]	view = M3dView


This routine must be overriden if the shape is to be drawn in the interactive display. Maya will call this routine with requests that have been previously added to the drawing queue.'''
        pass

    def canDrawUV(self): 
        '''canDrawUV(self) -> bool


Called by Maya to determine if this surface shape supports UV drawing.'''
        pass

    def drawUV(self, view, info): 
        '''drawUV(self, view, info)
Arguments:
	[in]	view = M3dView
	[in]	info = MTextureEditorDrawInfo


This method is called when the surface shape is selected and the texture view is open. Users should override this method if their custom shape supports UVs.'''
        pass

    def selectUV(self, view, selType, xmin, ymin, xmax, ymax, singleSelect, selList): 
        '''selectUV(self, view, selType, xmin, ymin, xmax, ymax, singleSelect, selList) -> bool
Returns: true if something was selected, false otherwise. 

Arguments:
	[in]	view = M3dView
	[in]	selType = MPxSurfaceShapeUI.UVSelectionType
	[in]	xmin = int
	[in]	ymin = int
	[in]	xmax = int
	[in]	ymax = int
	[in]	singleSelect = bool
	[in]	selList = MSelectionList


This method is called when the user performs a selection within the texture view. The method is called only when the surface shape is member of the active selection list.'''
        pass

    def material(self, path): 
        '''material(self, path) -> MMaterial
Returns: The material associated with this shape 

Arguments:
	[in]	path = MDagPath


Returns the material associated with this shape. The user must supply a DAG path as a shape can have several materials if instanced.'''
        pass

    def getDrawRequests(self, objectAndActiveOnly, info, queue): 
        '''getDrawRequests(self, objectAndActiveOnly, info, queue)
Arguments:
	[out]	info = MDrawInfo
	[in]	objectAndActiveOnly = bool
	[out]	queue = MDrawRequestQueue


This routine must be overriden if the shape is to be drawn in the interactive display. This function places drawing requests on maya's drawing queue and is called whenever the view is refreshed and the shape needs to be redrawn.'''
        pass

    def kSelectMeshVerts(self):
        '''This is an enum of UVSelectionType.
Description: The UV selection type is vertices.
Value: 1'''
        pass

    def kSelectMeshFaces(self):
        '''This is an enum of UVSelectionType.
Description: The UV selection type is faces.
Value: 2'''
        pass

    def kSelectMeshEdges(self):
        '''This is an enum of UVSelectionType.
Description: The UV selection type is edges.
Value: 3'''
        pass

    def kSelectMeshUVs(self):
        '''This is an enum of UVSelectionType.
Description: The UV selection type is UVs.
Value: 0'''
        pass

    class UVSelectionType:
        '''Non-functional class.  Values for this enum:
        kSelectMeshVerts
        kSelectMeshFaces
        kSelectMeshEdges
        kSelectMeshUVs
'''
        def __init__(self):
            pass

    def select(self, selectInfo, selectionList, worldSpaceSelectPts): 
        '''select(self, selectInfo, selectionList, worldSpaceSelectPts) -> bool
Returns: true something was selected 
false nothing was selected 

Arguments:
	[in]	selectInfo = MSelectInfo
	[in]	selectionList = MSelectionList
	[in]	worldSpaceSelectPts = MPointArray


This routine must be overriden if the shape is to support interactive object and/or component selection. The implementation of this method should call selectInfo.addSelection with information about the selected item and its selection mask. For single click selection, detected using the selectInfo.singleSection() method, the hit point should also be passed as an argument to selectInfo.addSelection.'''
        pass

class MPxToolCommand:
    '''Base class for interactive tool commands. This is the base class for interactive tool commands.An interactive tool command is a command that can be invoked as a MEL command or from within a user defined context (see MPxContext).Tool commands have the same functionality as MPxCommands, but include several additional methods for use in interactive contexts: , , , and . '''
    def __init__(self):
        pass


    def cancel(self): 
        '''cancel(self)

This method cancels the command. The user should override this method when the original program state needs to be restored.'''
        pass

    def doFinalize(self, command): 
        '''doFinalize(self, command)
Arguments:
	[in]	command = MArgList


USE _doFinalize() IN SCRIPT. 
'''
        pass

    def MStatus(self, args): 
        '''MStatus(self, args) -> virtual

Arguments:
	[in]	args = MArgList


This method should perform a command by setting up internal class data and then calling the  redoIt  method. The actual action performed by the command should be done in the  redoIt  method. This is a pure virtual method, and must be overridden in derived classes.'''
        pass

    def finalize(self): 
        '''finalize(self)

This method is used to create a string representing the command and its arguments. Users should override this method and contruct an  MArgList  and then pass it to  doFinalize  for journalling.'''
        pass

class MPxTransform:
    '''Base class for user defined transforms. MPxTransform allows the creation of user defined transform nodes. User defined transform nodes can introduce new transform types or change the transformation order. They are designed to be an extension of the standard Maya transform node and include all of the normal transform attributes. Standard behaviors such as limit enforcement and attribute locking are managed by this class, but may be overriden in derived classes.In general, a complete implementation of user defined transforms will require the deriving from two classes; MPxTransform defines the node while MPxTransformationMatrix describes the mathematical functions of the user defined transform.The MPxTransform class is registered using the MFnPlugin::registerTransform() method. Both the MPxTransform and the MPxTransformationMatrix classes are registered in the same method. This allows for a clear association between a MPxTransform and a MPxTransformationMatrix. Both the MPxTransform and the MPxTransformationMatrix classes need unique MTypeIds.MPxTransform nodes are DAG nodes and therefore a change to one element will affect every node beneath the changed node. Since this can involve quite a bit of calculation, DAG nodes internally handle clean and dirty differently than other nodes. What this means is that the updateMatrixAttrs() method should be used when getting one of the matrix attributes from a method on this node. Additionally, after a value is changed, the appropriate dirty method (i.e. dirtyTranslate(), dirtyRotate(), etc.) should be called. When in doubt, dirtyMatrix() will flag everything as needing to be updated.It is up to each transform node to determine if it will obey limits or Since transform attributes may have limits or may be involved in some sort of constraint, there needs to be a way to accept, reject, or modify a value when a plug is set on the node. The mustCallValidateAndSet() method allows for this kind of control. When an attribute is flagged with the mustCallValidateAndSet() method in the initialize() method, every plug change will call the validateAndSetValue() method for approval. From the validateAndSetValue() method things like limits and value locking can be enforced. It is important to note that for new attributes on the transform node, any locking or limits are left as an implementation detail.If any of the public methods are affected by the addition of transform components, or by the order of computation, they should be overriden in the derived class. Many of the public methods are used by internal Maya code and exist for more than just convenience.The createTransformationMatrix() class must be overloaded if a transformation matrix other than the default MPxTransformationMatrix is used.NOTES: 1) The setDependentsDirty() virtual method is available in this class since MPxTransform derives from MPxNode. During a call to MPxTransform::setDependentsDirty(), a plug-in should not invoke any of the dirty*() or updateMatrixAttrs() calls of this class. For example, the methods dirtyMatrix(), dirtyTranslation() or updateMatrixAttrs() should not be called. 2) Updating world space attributes is an expensive operation. Maya updates world space attributes on demand such as in the case of a getAttr being issued or a connection exists for the attribute. '''
    def __init__(self):
        pass


    rotateOrder = ''
    '''Rotate order attribute. '''

    maxRotXLimitEnable = ''
    '''Enable maximum rotate X limit attribute. '''

    intermediateObject = ''
    '''Intermediate object attribute. '''

    renderLayerColor = ''
    '''Render layer attribute. '''

    rotatePivot = ''
    '''rotate pivot attribute '''

    useObjectColor = ''
    '''Controls choice of wireframe dormant object color. '''

    maxTransYLimit = ''
    '''Maximum translate Y limit attribute. '''

    nodeBoundingBoxMin = ''
    '''bounding box minimum point '''

    minRotYLimit = ''
    '''Minimum rotate Y limit attribute. '''

    isTemplated = ''
    '''Template attribute. '''

    nodeBoundingBoxSize = ''
    '''bounding box size vector '''

    transMinusRotatePivot = ''
    '''translate minus rotate pivot attribute '''

    rotateX = ''
    '''rotateX attribute '''

    rotateY = ''
    '''rotateY attribute '''

    rotateZ = ''
    '''rotateZ attribute '''

    nodeBoundingBox = ''
    '''bounding box attribute '''

    identification = ''
    '''Obsolete attribute. '''

    minScaleYLimitEnable = ''
    '''Enable minimum scale Y limit attribute. '''

    translateX = ''
    '''translateX attribute '''

    translateY = ''
    '''translateY attribute '''

    translateZ = ''
    '''translateZ attribute '''

    objectGroupColor = ''
    '''Group id attribute. '''

    applyRotationLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    parentMatrix = ''
    '''Parent matrix attribute. '''

    layerRenderable = ''
    '''Obsolete attribute. '''

    scalePivotTranslate = ''
    '''Scale pivot translate attribute. '''

    renderLayerId = ''
    '''Render layer attribute. '''

    objectGroups = ''
    '''Object groups attributes. '''

    minTransLimit = ''
    '''Minumum translation limits attribute. '''

    rotate = ''
    '''rotate attribute '''

    minRotLimit = ''
    '''Minimum rotation limits attribute. '''

    applyTranslationLimits = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    applyRotationLimits = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    maxRotZLimit = ''
    '''Maximum rotate Z limit attribute. '''

    minTransXLimit = ''
    '''Minimum translate X limit attribute. '''

    scalePivotY = ''
    '''scale pivot Y attribute '''

    scalePivotX = ''
    '''scale pivot X attribute '''

    scalePivotZ = ''
    '''scale pivot Z attribute '''

    minRotXLimit = ''
    '''Minimum rotate X limit attribute. '''

    maxScaleZLimit = ''
    '''Maximum scale Z limit attribute. '''

    rotateAxis = ''
    '''Rotate orientation attribute. '''

    maxTransZLimitEnable = ''
    '''Enable the maximum translate Z limit attribute. '''

    dirtyRotateOrientation = ''
    '''USE _dirtyRotateOrientation() IN SCRIPT.  '''

    maxScaleXLimitEnable = ''
    '''Enable maximum scale X limit attribute. '''

    maxTransZLimit = ''
    '''Maximum translate Z limit attribute. '''

    scalePivotTranslateX = ''
    '''scale pivot translate X attribute '''

    scalePivotTranslateY = ''
    '''scale pivot translate Y attribute '''

    scalePivotTranslateZ = ''
    '''scale pivot translate Z attribute '''

    minRotZLimit = ''
    '''Minimum rotate Z limit attribute. '''

    scale = ''
    '''scale attribute '''

    matrix = ''
    '''matrix attribute '''

    minRotZLimitEnable = ''
    '''Enable minimum rotate Z limit attribute. '''

    dirtyRotatePivot = ''
    '''USE _dirtyRotatePivot() IN SCRIPT.  '''

    objectGroupId = ''
    '''Group id attribute. '''

    applyScaleLocksPivotTranslate = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    worldMatrix = ''
    '''world matrix attribute '''

    minScaleLimitEnable = ''
    '''Enable minimum scale limit attribute. '''

    applyRotatePivotLocksTranslate = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    parentInverseMatrix = ''
    '''Inverse parent matrix attribute. '''

    maxTransLimit = ''
    '''Maximum translation limits attribute. '''

    dirtyTranslation = ''
    '''USE _dirtyTranslation() IN SCRIPT.  '''

    objectColor = ''
    '''The per object dormant wireframe color. '''

    maxRotLimit = ''
    '''Maximum rotation limits attribute. '''

    boundingBoxCenterZ = ''
    '''Z component of the bounding box center. '''

    nodeBoundingBoxMaxZ = ''
    '''Z component of nodeBoundingBoxMax. '''

    boundingBoxCenterX = ''
    '''X component of the bounding box center. '''

    boundingBoxCenterY = ''
    '''Y component of the bounding box center. '''

    minRotXLimitEnable = ''
    '''Enable minimum rotate X limit attribute. '''

    nodeBoundingBoxMaxX = ''
    '''X component of nodeBoundingBoxMax. '''

    minScaleZLimitEnable = ''
    '''Enable minimum scale Z limit attribute. '''

    applyScaleLimits = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    maxScaleYLimitEnable = ''
    '''Enable maximum scale Y limit attribute. '''

    applyRotatePivotLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    instObjGroups = ''
    '''Instances object group info attribute. '''

    maxTransLimitEnable = ''
    '''Enable the maximum translation limits attribute. '''

    minScaleXLimit = ''
    '''Minimum scale X limit attribute. '''

    dirtyMatrix = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    maxScaleLimit = ''
    '''Maximum scale limit attribute. '''

    ghosting = ''
    '''Ghosting attribute. '''

    dirtyShear = ''
    '''USE _dirtyShear() IN SCRIPT.  '''

    minTransYLimit = ''
    '''Minimum translate Y limit attribute. '''

    shearYZ = ''
    '''shearYZ attribute '''

    maxTransXLimit = ''
    '''Maximum translate X limit attribute. '''

    scaleX = ''
    '''scaleX attribute '''

    scaleY = ''
    '''scaleY attribute '''

    scaleZ = ''
    '''scaleZ attribute '''

    dirtyRotatePivotTranslation = ''
    '''USE _dirtyRotatePivotTranslation() IN SCRIPT.  '''

    rotatePivotTranslateX = ''
    '''rotate pivot translate X attribute '''

    rotatePivotTranslateY = ''
    '''rotate pivot translate Y attribute '''

    rotatePivotTranslateZ = ''
    '''rotate pivot translate Z attribute '''

    translate = ''
    '''translate attribute '''

    objectGrpCompList = ''
    '''Component in object groups attribute. '''

    maxRotZLimitEnable = ''
    '''Enable maximum rotate Z limit attribute. '''

    nodeBoundingBoxMax = ''
    '''bounding box maximum point '''

    minTransZLimitEnable = ''
    '''Enable the minimum translate Z limit attribute. '''

    visibility = ''
    '''Visibility attribute. '''

    layerOverrideColor = ''
    '''Obsolete attribute. '''

    minScaleZLimit = ''
    '''Minimum scale Z limit attribute. '''

    applyRotateOrientationLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    minTransXLimitEnable = ''
    '''Enable the minimum translate X limit attribute. '''

    center = ''
    '''object center attribute '''

    rotateAxisY = ''
    '''rotate orientation Y attribute '''

    rotateAxisX = ''
    '''rotate orientation X attribute '''

    rotateAxisZ = ''
    '''rotate orientation Z attribute '''

    minScaleYLimit = ''
    '''Minimum scale Y limit attribute. '''

    minTransYLimitEnable = ''
    '''Enable the minimum translate Y limit attribute. '''

    maxScaleYLimit = ''
    '''Maximum scale Y limit attribute. '''

    scalePivot = ''
    '''scale pivot attribute '''

    dirtyScalePivot = ''
    '''USE _dirtyScalePivot() IN SCRIPT.  '''

    maxTransYLimitEnable = ''
    '''Enable the maximum translate Y limit attribute. '''

    applyScaleLocksPivot = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    worldInverseMatrix = ''
    '''Inverse world matrix attribute. '''

    minScaleLimit = ''
    '''Minimum scale limit attribute. '''

    maxScaleLimitEnable = ''
    '''Enable aximum scale limit attribute. '''

    applyTranslationLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    maxTransXLimitEnable = ''
    '''Enable the maximum translate X limit attribute. '''

    dirtyScalePivotTranslation = ''
    '''USE _dirtyScalePivotTranslation() IN SCRIPT.  '''

    applyShearLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    transMinusRotatePivotY = ''
    '''translateY minus rotate pivotY attribute '''

    transMinusRotatePivotX = ''
    '''translateX minus rotate pivotX attribute '''

    maxScaleZLimitEnable = ''
    '''Enable maximum scale Z limit attribute. '''

    transMinusRotatePivotZ = ''
    '''translateZ minus rotate pivotZ attribute '''

    minRotYLimitEnable = ''
    '''Enable minimum rotate Y limit attribute. '''

    maxRotXLimit = ''
    '''Maximum rotate X limit attribute. '''

    minScaleXLimitEnable = ''
    '''Enable minimum scale X limit attribute. '''

    applyScaleLocks = ''
    '''USE _dirtyMatrix() IN SCRIPT.  '''

    maxRotYLimit = ''
    '''Maximum rotate Y limit attribute. '''

    maxRotYLimitEnable = ''
    '''Enable maximum rotate Y limit attribute. '''

    minTransZLimit = ''
    '''Minimum translate Z limit attribute. '''

    nodeBoundingBoxSizeX = ''
    '''X component of nodeBoundingBoxSize. '''

    nodeBoundingBoxSizeY = ''
    '''Y component of nodeBoundingBoxSize. '''

    nodeBoundingBoxSizeZ = ''
    '''Z component of nodeBoundingBoxSize. '''

    nodeBoundingBoxMaxY = ''
    '''Y component of nodeBoundingBoxMax. '''

    minRotLimitEnable = ''
    '''Enable minimum rotation limits attribute. '''

    renderInfo = ''
    '''Obsolete attribute. '''

    renderLayerInfo = ''
    '''Render layer attribute. '''

    dirtyRotation = ''
    '''USE _dirtyRotation() IN SCRIPT.  '''

    nodeBoundingBoxMinX = ''
    '''X component of nodeBoundingBoxMin. '''

    nodeBoundingBoxMinY = ''
    '''Y component of nodeBoundingBoxMin. '''

    nodeBoundingBoxMinZ = ''
    '''Z component of nodeBoundingBoxMin. '''

    rotatePivotY = ''
    '''rotate pivot Y attribute '''

    rotatePivotX = ''
    '''rotate pivot X attribute '''

    rotatePivotZ = ''
    '''rotate pivot Z attribute '''

    shearXY = ''
    '''shearXY attribute '''

    shearXZ = ''
    '''shearXZ attribute '''

    renderLayerRenderable = ''
    '''Render layer attribute. '''

    maxScaleXLimit = ''
    '''Maximum scale X limit attribute. '''

    maxRotLimitEnable = ''
    '''Enable maximum rotation limits attribute. '''

    minTransLimitEnable = ''
    '''Enable the mimimum translation limits attribute. '''

    rotatePivotTranslate = ''
    '''rotate pivot translate attribute '''

    inverseMatrix = ''
    '''inverse matrix attribute '''

    dirtyScale = ''
    '''USE _dirtyScale() IN SCRIPT.  '''

    def applyRotatePivotLocks(self, toTest, savedRP): 
        '''applyRotatePivotLocks(self, toTest, savedRP) -> MVector
Returns: The value after the locking checks are applied.

Arguments:
	[in]	toTest = MPoint
	[in]	savedRP = MPoint


This method allows the custom transform to apply its own locking mechanism to rotation pivots. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def getScalePivotTranslation(self, space, context): 
        '''getScalePivotTranslation(self, space, context) -> MVector
Returns: An MVector containing the value of the scale pivot translation in centimeters.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the scale pivot translation in internal units (centimeters). The scale pivot translation is an offset applied to the transform to allow adjustments to the scale pivot to be made without changing the overall transform.'''
        pass

    def rotateTo(self, euler, space, context): 
        '''rotateTo(self, euler, space, context)
Arguments:
	[in]	euler = MEulerRotation
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Sets the rotation component of the transform using an euler rotation. If the new rotation's order of rotation is different from that of the transform it will be reordered to match the transform.'''
        pass

    def dirtyRotateOrientation(self, savedRO): 
        '''dirtyRotateOrientation(self, savedRO)
Arguments:
	[in]	savedRO = MEulerRotation


USE _dirtyRotateOrientation() IN SCRIPT. 
'''
        pass

    def getRotatePivotTranslation(self, space, context): 
        '''getRotatePivotTranslation(self, space, context) -> MVector
Returns: An MVector containing the value of the rotate pivot translation in centimeters.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the rotate pivot translation in internal units (centimeters). The rotate pivot translation is an offset applied to the transform to allow adjustments to the rotate pivot to be made without changing the overall transform.'''
        pass

    def getShear(self, space, context): 
        '''getShear(self, space, context) -> MVector
Returns: A MVector holding the xy, xz, yz values of shear.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Get the shear value for this transform.'''
        pass

    def dirtyShear(self, savedSh): 
        '''dirtyShear(self, savedSh)
Arguments:
	[in]	savedSh = MVector


USE _dirtyShear() IN SCRIPT. 
'''
        pass

    def translateBy(self, transOffset, space, context): 
        '''translateBy(self, transOffset, space, context)
Arguments:
	[in]	transOffset = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Add to the translation component by translating relative to the existing transform. The transform value should be in internal units (centimeters).'''
        pass

    def dirtyScalePivotTranslation(self, savedST): 
        '''dirtyScalePivotTranslation(self, savedST)
Arguments:
	[in]	savedST = MVector


USE _dirtyScalePivotTranslation() IN SCRIPT. 
'''
        pass

    def checkAndSetScalePivotTranslation(self, block, plug, newPT, space): 
        '''checkAndSetScalePivotTranslation(self, block, plug, newPT, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newPT = MVector
	[in]	space = MSpace.Space


This method verifies that the passed value can be set on the scalePivotTranslate plugs. In the base class, only the locking conditions are enforced.'''
        pass

    def applyRotateOrientationLocks(self, toTest, savedRO): 
        '''applyRotateOrientationLocks(self, toTest, savedRO) -> MEulerRotation
Returns: The rotate orientation value after the locking checks are applied.

Arguments:
	[in]	toTest = MEulerRotation
	[in]	savedRO = MEulerRotation


This method allows the custom transform to apply its own locking mechanism to rotation orientation. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def getTranslation(self, space, context): 
        '''getTranslation(self, space, context) -> MVector
Returns: The translation MVector in internal units (centimeters).

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the translation component of the transform as a  MVector  in internal units (centimeters).'''
        pass

    def dirtyMatrix(self): 
        '''dirtyMatrix(self)

USE _dirtyMatrix() IN SCRIPT. 
'''
        pass

    def enableLimit(self, type, flag): 
        '''enableLimit(self, type, flag)
Arguments:
	[in]	type = MFnTransform.LimitType
	[in]	flag = bool


Enable or disable the limit value for the specified limit type.'''
        pass

    def createTransformationMatrix(self): 
        '''createTransformationMatrix(self) -> MPxTransformationMatrix


This method returns a new transformation matrix. The function that calls this method is responsible for deleting the transformation matrix.'''
        pass

    def setLimit(self, type, value): 
        '''setLimit(self, type, value)
Arguments:
	[in]	type = MFnTransform.LimitType
	[in]	value = double


Change the limit value for the specified limit type, and automatically enable the limit to be true.'''
        pass

    def scaleTo(self, newScale, space, context): 
        '''scaleTo(self, newScale, space, context)
Arguments:
	[in]	newScale = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method will set the scale of the transform to the passed value.'''
        pass

    def setRotatePivotTranslation(self, newPT, space, context): 
        '''setRotatePivotTranslation(self, newPT, space, context)
Arguments:
	[in]	newPT = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method sets the rotate pivot translation in internal units (centimeters). The rotate pivot translation is normally used to automatically compensate for changes in the rotate pivot when the  setRotatePivot()  method is used.'''
        pass

    def applyTranslationLocks(self, toTest, savedT): 
        '''applyTranslationLocks(self, toTest, savedT) -> MVector
Returns: The value after the locking checks are applied.

Arguments:
	[in]	toTest = MVector
	[in]	savedT = MVector


This method allows the custom transform to apply its own locking mechanism to translation. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def getMatrixInverse(self, context): 
        '''getMatrixInverse(self, context) -> MMatrix
Returns: The inverse of the transform as a MMatrix.

Arguments:
	[in]	context = MDGContext


This method returns the inverse of the 4x4 matrix that describes this transformation.'''
        pass

    def translateTo(self, newTrans, space, context): 
        '''translateTo(self, newTrans, space, context)
Arguments:
	[in]	newTrans = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Set the translation component of the transform in centimeters.'''
        pass

    def setScalePivot(self, newSP, space, balance, context): 
        '''setScalePivot(self, newSP, space, balance, context)
Arguments:
	[in]	newSP = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool
	[in]	context = MDGContext


This method sets the position of the scale pivot. The position of the pivot is defined as a  MPoint  in internal units (centimeters).'''
        pass

    def getRotatePivot(self, space, context): 
        '''getRotatePivot(self, space, context) -> MPoint

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the position of the pivot used by the rotate component of the transform. The position is represented in internal units (centimeters).'''
        pass

    def applyShearLocks(self, toTest, savedS): 
        '''applyShearLocks(self, toTest, savedS) -> MVector
Returns: The shear value after the locking checks are applied.

Arguments:
	[in]	toTest = MVector
	[in]	savedS = MVector


This method allows the custom transform to apply its own locking mechanism to shear. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def shearBy(self, shearOffset, space, context): 
        '''shearBy(self, shearOffset, space, context)
Arguments:
	[in]	shearOffset = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method will apply a relative shear to the existing shear.'''
        pass

    def updateMatrixAttrs(self, attr, context): 
        '''updateMatrixAttrs(self, attr, context)
Arguments:
	[in]	attr = MObject
	[in]	context = MDGContext


This method ensures that a passed attribute will have its values current.'''
        pass

    def dirtyRotatePivot(self, savedRP): 
        '''dirtyRotatePivot(self, savedRP)
Arguments:
	[in]	savedRP = MPoint


USE _dirtyRotatePivot() IN SCRIPT. 
'''
        pass

    def checkAndSetShear(self, block, plug, newS, space): 
        '''checkAndSetShear(self, block, plug, newS, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newS = MVector
	[in]	space = MSpace.Space


This method verifies that the passed value can be set on the shear plugs. In the base class, only the locking conditions are enforced.'''
        pass

    def resetTransformation(self, xform): 
        '''resetTransformation(self, xform)
Arguments:
	[in]	xform = MPxTransformationMatrix


This method will reset the transformation matrix to the one specified by the passed transformation matrix pointer. The contents of the passed transformation matrix are copied into this class's transformation matrix.'''
        pass

    def dirtyRotatePivotTranslation(self, savedRT): 
        '''dirtyRotatePivotTranslation(self, savedRT)
Arguments:
	[in]	savedRT = MVector


USE _dirtyRotatePivotTranslation() IN SCRIPT. 
'''
        pass

    def applyScaleLocksPivotTranslate(self, toTest, savedSPT): 
        '''applyScaleLocksPivotTranslate(self, toTest, savedSPT) -> MVector
Returns: The value after the locking checks are applied.

Arguments:
	[in]	toTest = MVector
	[in]	savedSPT = MVector


This method allows the custom transform to apply its own locking mechanism to the scalePivotTranslate attribute. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def isNonAffineMatricesEnabled(self): 
        '''isNonAffineMatricesEnabled(self) -> bool
Returns: true if non-affine matrix calculations are enabled.


This method returns true is non-affine matrix calculations are being used for transforms.'''
        pass

    def rotateBy(self, euler, space, context): 
        '''rotateBy(self, euler, space, context)
Arguments:
	[in]	euler = MEulerRotation
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Adds to the rotation component of the transform by rotating relative to the existing transform using a euler rotation. The only valid transformation spaces for this method are  MSpace::kTransform  and  MSpace::kPreTransform /MSpacekObject. All other spaces are treated as being equivalent to  MSpace::kTransform . If the supplied rotation's order of rotation is different from that of the transform, it will be reordered to match the transform before being added in.'''
        pass

    def getScalePivot(self, space, context): 
        '''getScalePivot(self, space, context) -> MPoint
Returns: A MPoint given the position of the scale pivot in centimeters.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the position of the pivot used by the scale component of the transform. The position is represented in internal units (centimeters).'''
        pass

    def checkAndSetRotatePivotTranslation(self, block, plug, newPT, space): 
        '''checkAndSetRotatePivotTranslation(self, block, plug, newPT, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newPT = MVector
	[in]	space = MSpace.Space


This method verifies that the passed value can be set on the rotatePivotTranslate plugs. In the base class, only the locking conditions are enforced.'''
        pass

    def postConstructor(self): 
        '''postConstructor(self)

Post constructor.'''
        pass

    def limitValue(self, type): 
        '''limitValue(self, type) -> double
Returns: Returns the current value of the specified limit in internal units as a double.

Arguments:
	[in]	type = MFnTransform.LimitType


Returns the current value of the specified limit in internal units as a double.'''
        pass

    def type(self): 
        '''type(self) -> MPxNode.Type


This method returns the type of the node. This method should not be overridden by the user. It will return  MPxNode::kTransformNode .'''
        pass

    def checkAndSetRotatePivot(self, block, plug, newRP, space, balance): 
        '''checkAndSetRotatePivot(self, block, plug, newRP, space, balance)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newRP = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool


This method verifies that the passed value can be set on the rotatePivot plugs. In the base class, only the locking conditions are enforced. This method will also update the rotatePivotTranslate value if balance is true.'''
        pass

    def setScalePivotTranslation(self, newPT, space, context): 
        '''setScalePivotTranslation(self, newPT, space, context)
Arguments:
	[in]	newPT = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method sets the scale pivot translation in internal units (centimeters). The scale pivot translation is normally used to automatically compensate for changes in the scale pivot when the  setScalePivot()  method is used.'''
        pass

    def getRotateOrientation(self, space, context): 
        '''getRotateOrientation(self, space, context) -> MQuaternion
Returns: A MQuaternion representing the rotate orientation.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Returns the rotate orientation for the transformation matrix as a quaternion. The rotate orientation is the value associated with the rotateAxis attribute on this node. The rotate orientation value is used to orient the local rotation space of the transform.'''
        pass

    def checkAndSetScale(self, block, plug, newS, space): 
        '''checkAndSetScale(self, block, plug, newS, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newS = MVector
	[in]	space = MSpace.Space


This method verifies that the passed value can be set on the scale plugs. In the base class, limits as well as locking are checked by this method.'''
        pass

    def applyScaleLocks(self, toTest, savedS): 
        '''applyScaleLocks(self, toTest, savedS) -> MVector
Returns: The scale value after the locking checks are applied.

Arguments:
	[in]	toTest = MVector
	[in]	savedS = MVector


This method allows the custom transform to apply its own locking mechanism to scale. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def shearTo(self, newShear, space, context): 
        '''shearTo(self, newShear, space, context)
Arguments:
	[in]	newShear = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


The method sets the shear component of the transform.'''
        pass

    def setRotatePivot(self, newRP, space, balance, context): 
        '''setRotatePivot(self, newRP, space, balance, context)
Arguments:
	[in]	newRP = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool
	[in]	context = MDGContext


This method sets the position of the rotate pivot. The position of the pivot is defined as a  MPoint  in internal units (centimeters).'''
        pass

    def applyRotatePivotLocksTranslate(self, toTest, savedRPT): 
        '''applyRotatePivotLocksTranslate(self, toTest, savedRPT) -> MVector
Returns: The value after the locking checks are applied.

Arguments:
	[in]	toTest = MVector
	[in]	savedRPT = MVector


This method allows the custom transform to apply its own locking mechanism to the rotatePivotTranslate attribute. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def applyRotationLocks(self, toTest, savedR): 
        '''applyRotationLocks(self, toTest, savedR) -> MEulerRotation
Returns: The value after the locking checks are applied.

Arguments:
	[in]	toTest = MEulerRotation
	[in]	savedR = MEulerRotation


This method allows the custom transform to apply its own locking mechanism to rotation. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def MPxTransformationMatrix(self): 
        '''MPxTransformationMatrix(self) -> const


This method returns a reference to the transformation matrix used by this transform.'''
        pass

    def validateAndSetValue(self, plug, handle, context): 
        '''validateAndSetValue(self, plug, handle, context)
Arguments:
	[in]	plug = MPlug
	[in]	handle = MDataHandle
	[in]	context = MDGContext


When a plug's value is set, and the plug is on a default transform attribute, or has been flagged by the  mustCallValidateAndSet()  method, then this method will be called. The purpose of  validateAndSetValue()  is to enforce limits, constraints, or plug value locking.'''
        pass

    def checkAndSetRotation(self, block, plug, newR, space): 
        '''checkAndSetRotation(self, block, plug, newR, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newR = MEulerRotation
	[in]	space = MSpace.Space


This method verifies that the passed value can be set on the rotate plugs. In the base class, limits as well as locking are checked by this method.'''
        pass

    def dirtyTranslation(self, savedT): 
        '''dirtyTranslation(self, savedT)
Arguments:
	[in]	savedT = MVector


USE _dirtyTranslation() IN SCRIPT. 
'''
        pass

    def boundingBox(self): 
        '''boundingBox(self) -> MBoundingBox


This method should be overridden to return a bounding box for the transform. If this method is overridden, then  MPxTransform::isBounded  should also be overridden to return true.'''
        pass

    def transformationMatrixPtr(self): 
        '''transformationMatrixPtr(self) -> MPxTransformationMatrix

'''
        pass

    def getScale(self, space, context): 
        '''getScale(self, space, context) -> MVector
Returns: A MVector holding the x, y, and z scale components

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Returns the scale component of the transform. If the space is invalid a <1.0, 1.0, 1.0> vector is returned.'''
        pass

    def dirtyRotation(self, savedR): 
        '''dirtyRotation(self, savedR)
Arguments:
	[in]	savedR = MEulerRotation


USE _dirtyRotation() IN SCRIPT. 
'''
        pass

    def mustCallValidateAndSet(self, obj): 
        '''mustCallValidateAndSet(self, obj)
Arguments:
	[in]	obj = MObject


This method must be called in the initialize() method for all attributes that affect the matrix of the transform. It will ensure that the matrix is properly calculated when the passed attribute is changed and that the validateAndSetValue method will get called for this attribute.'''
        pass

    def getMatrix(self, context): 
        '''getMatrix(self, context) -> MMatrix
Returns: The transform as a MMatrix.

Arguments:
	[in]	context = MDGContext


This method returns a 4x4 matrix that is produced by applying all of the components of the transform.'''
        pass

    def applyScaleLocksPivot(self, toTest, savedSP): 
        '''applyScaleLocksPivot(self, toTest, savedSP) -> MVector
Returns: The scale pivot value after the locking checks are applied.

Arguments:
	[in]	toTest = MPoint
	[in]	savedSP = MPoint


This method allows the custom transform to apply its own locking mechanism to scale pivot. Standard dependency graph attribute locking happens automatically and cannot be modified by custom nodes.'''
        pass

    def copyInternalData(self, node): 
        '''copyInternalData(self, node)
Arguments:
	[in]	node = MPxNode


This function copies the internal data of the transform node.'''
        pass

    def isBounded(self): 
        '''isBounded(self) -> bool


This method should be overridden to return true if the user supplies a bounding box routine. Supplying a bounding box routine makes refresh and selection more efficient.'''
        pass

    def compute(self, plug, block): 
        '''compute(self, plug, block)
Arguments:
	[in]	plug = MPlug
	[in]	block = MDataBlock


The transform's compute method. The compute method should call any supporting methods to proper handle limits as well as the cases where the plug's value should not change. The  MPlug::isFreeToChange()  method is used to determine if a plug's value may be changed.'''
        pass

    def checkAndSetRotateOrientation(self, block, plug, newRO, space, balance): 
        '''checkAndSetRotateOrientation(self, block, plug, newRO, space, balance)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newRO = MEulerRotation
	[in]	space = MSpace.Space
	[in]	balance = bool


This method verifies that the passed value can be set on the rotateAxis plugs. In the base class, only the locking conditions are enforced. This method will also update the rotation value if balance is true.'''
        pass

    def getRotationOrder(self, context): 
        '''getRotationOrder(self, context) -> MTransformationMatrix.RotationOrder
Returns: The MTransformationMatrix::RotationOrder enum describing the rotation order of the transform. 

Arguments:
	[in]	context = MDGContext


Returns the rotation order used by the rotation component of the transformation matrix.'''
        pass

    def dirtyScalePivot(self, savedSP): 
        '''dirtyScalePivot(self, savedSP)
Arguments:
	[in]	savedSP = MPoint


USE _dirtyScalePivot() IN SCRIPT. 
'''
        pass

    def checkAndSetTranslation(self, block, plug, newT, space): 
        '''checkAndSetTranslation(self, block, plug, newT, space)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newT = MVector
	[in]	space = MSpace.Space


This method is used to modify and set the new translate values being passed in from the compute method or from the validateAndSetValue. The data block should be set with the corrected values. Corrections would come from enforcing any active limits as well as verifying that the plug's value may be changed. If the plug is locked or if it is the destination in a connection that disallows value changes, then the plug will be set to its unchanged value.'''
        pass

    def setNonAffineMatricesEnabled(self, enabled): 
        '''setNonAffineMatricesEnabled(self, enabled)
Arguments:
	[in]	enabled = bool


Normal Maya transforms consist of translate, rotate, scale, and shear. All of these transform types produce an affine matrix. With  MPxTransform  it is possible to introduce non-affine matrices into places that previously did not consider their effects.'''
        pass

    def scaleBy(self, scaleOffset, space, context): 
        '''scaleBy(self, scaleOffset, space, context)
Arguments:
	[in]	scaleOffset = MVector
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method will apply a relative scale to an existing scale.'''
        pass

    def applyTranslationLimits(self, unlimitedT, block): 
        '''applyTranslationLimits(self, unlimitedT, block) -> MVector
Returns: The limited translation value.

Arguments:
	[in]	unlimitedT = MVector
	[in]	block = MDataBlock


This method returns a copy of the passed translation value with its members limited by any enabled translation limits on this node.'''
        pass

    def applyRotationLimits(self, unlimitedR, block): 
        '''applyRotationLimits(self, unlimitedR, block) -> MEulerRotation
Returns: A MEulerRotation with limits applied to it.

Arguments:
	[in]	unlimitedR = MEulerRotation
	[in]	block = MDataBlock


This method returns a copy of the passed rotation value with its members limited by any enabled rotation limits on this node.'''
        pass

    def clearLimits(self): 
        '''clearLimits(self)

This method turns off all of the limits and sets them to their default values. Before this method is called, the base class clears all of the limits on the standard transform attributes, so this method only needs to be implemented for custom transform attributes.'''
        pass

    def getEulerRotation(self, space, context): 
        '''getEulerRotation(self, space, context) -> MEulerRotation
Returns: The rotation component of the transform as an euler rotation.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


Returns the rotation component of the transform as a euler rotation. The rotation is returned in  MSpace::kTransform  space. If an invalid space is used,  MEulerRotation::identity  will be returned.'''
        pass

    def isLimited(self, type): 
        '''isLimited(self, type) -> bool
Returns: Returns true if the limit is enabled, otherwise false is returned.

Arguments:
	[in]	type = MFnTransform.LimitType


Determine if the specified limit attribute is enabled or disabled.'''
        pass

    def setRotateOrientation(self, newRO, space, balance, context): 
        '''setRotateOrientation(self, newRO, space, balance, context)
Arguments:
	[in]	newRO = MQuaternion
	[in]	space = MSpace.Space
	[in]	balance = bool
	[in]	context = MDGContext


This method sets the rotate orientation for this transform. The rotate orientation is used to define the local rotation space. The rotate orientation is the value associated with the rotateAxis attribute on this node.'''
        pass

    def checkAndSetScalePivot(self, block, plug, newSP, space, balance): 
        '''checkAndSetScalePivot(self, block, plug, newSP, space, balance)
Arguments:
	[in]	block = MDataBlock
	[in]	plug = MPlug
	[in]	newSP = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool


This method verifies that the passed value can be set on the scalePivot plugs. In the base class, only the locking conditions are enforced. This method will also update the scalePivotTranslate value if balance is true.'''
        pass

    def setRotationOrder(self, ro, reorder, context): 
        '''setRotationOrder(self, ro, reorder, context)
Arguments:
	[in]	ro = MTransformationMatrix.RotationOrder
	[in]	reorder = bool
	[in]	context = MDGContext


Sets the rotation order used by the rotation component of the transformation matrix.'''
        pass

    def dirtyScale(self, savedS): 
        '''dirtyScale(self, savedS)
Arguments:
	[in]	savedS = MVector


USE _dirtyScale() IN SCRIPT. 
'''
        pass

    def computeLocalTransformation(self, block, xform): 
        '''computeLocalTransformation(self, block, xform)
Arguments:
	[out]	xform = MPxTransformationMatrix
	[in]	block = MDataBlock


This method computes the transformation matrix for a passed data block and places the output into a passed transformation matrix.'''
        pass

    def applyScaleLimits(self, unlimitedS, block): 
        '''applyScaleLimits(self, unlimitedS, block) -> MVector
Returns: The scale value with limits applied.

Arguments:
	[in]	unlimitedS = MVector
	[in]	block = MDataBlock


This method returns a copy of the passed scale value with its members limited by any enabled scale limits on this node.'''
        pass

    def getRotation(self, space, context): 
        '''getRotation(self, space, context) -> MQuaternion
Returns: The rotate component of the transform as a quaternion.

Arguments:
	[in]	space = MSpace.Space
	[in]	context = MDGContext


This method returns the rotation of the transform as a quaternion. The rotation is returned in  MSpace::kTransform  space. If an invalid space is used,  MQuaternion::identity  will be returned.'''
        pass

class MPxTransformationMatrix:
    '''Base class of all user defined transformation matrices. MPxTransformationMatrix is the parent class for all user defined transformation matrices. A transformation matrix is a class that holds the individual components (i.e. translate, rotate, scale, pivots, etc.) that are used to construct a 4x4 matrix. Given that different combinations of transform components may produce similar 4x4 matrices, it is not always possible to get a generic 4x4 matrix and decompose it into unique components. This class allows better control over which components are changed than a generic 4x4 MMatrix could offer.The MPxTransformationMatrix class is designed for use as the mathematical brains behind the MPxTransform node. This separation is useful for class reuse (different types of MPxTransform nodes may still use the same MPxTransformationMatrix class) as well as simplifying the MPxTransform class.The MPxTransformationMatrix class is registered using the MFnPlugin::registerTransform() method. Both the MPxTransform and the MPxTransformationMatrix classes are registered in the same method. This allows for a clear association between a MPxTransform and a MPxTransformationMatrix.When registering the MPxTransformationMatrix, a MTypeId is required. For nodes using the default MPxTransformationMatrix, a statically defined MTypeId is provided by the MPxTransformationMatrix::baseTransformationMatrixId data member.Since the MPxTransformationMatrix class gives extended functionality to a native Maya class, several methods are given that are needed by Maya for this class to properly function in different settings.To create a transformation matrix, derive from this class and overload the creator() method and the assignment operator for the derived class. If any additional data items are added to this class, the copyValues() method should also be overloaded. This will ensure that the new values will get properly handed by Maya. The rest of the methods may be overloaded as needed. '''
    def __init__(self):
        pass


    def typeId(self): 
        '''typeId(self) -> MTypeId


Returns the  MTypeId  of this transformation matrix. The  MTypeId  is a four byte identifier that uniquely identifies this type of transformation matrix.'''
        pass

    def asInterpolationMatrix(self, toM, percent, rot, direction): 
        '''asInterpolationMatrix(self, toM, percent, rot, direction) -> MMatrix
Returns: The interpolated matrix. 

Arguments:
	[in]	toM = MTransformationMatrix
	[in]	percent = double
	[in]	rot = bool
	[in]	direction = int


Returns a matrix that represents the specified percentage of this transformation matrix. The two matrices involved in the interpolation are this transformation matrix and the passed transformation matrix, toMatrix.'''
        pass

    def asTransformationMatrix(self): 
        '''asTransformationMatrix(self) -> MTransformationMatrix


Returns the custom transformation matrix as a standard  MTransformationMatrix .'''
        pass

    def creator(self): 
        '''creator(self) -> MPxTransformationMatrix


A method to use when registering a custom transform that uses a default  MPxTransformationMatrix .'''
        pass

    def translateBy(self, t, space): 
        '''translateBy(self, t, space)
Arguments:
	[in]	t = MVector
	[in]	space = MSpace.Space


Add to the translate component by translating relative to the existing transformation. The relative translate should be in centimeters.'''
        pass

    def setRotateOrientation(self, euler, space, balance): 
        '''setRotateOrientation(self, euler, space, balance)
Arguments:
	[in]	euler = MEulerRotation
	[in]	space = MSpace.Space
	[in]	balance = bool


Sets the rotate orientation for the transformation matrix to the passed quaternion. The rotate orientation is the rotation that orients the local rotation space.'''
        pass

    def rotateTo(self, euler, space): 
        '''rotateTo(self, euler, space)
Arguments:
	[in]	euler = MEulerRotation
	[in]	space = MSpace.Space


Sets the rotation component of the transformation matrix using an euler rotation.'''
        pass

    def scalePivot(self, space): 
        '''scalePivot(self, space) -> MPoint
Returns: The scale pivot point.

Arguments:
	[in]	space = MSpace.Space


Returns the pivot used by the scale. The value is in centimeters.'''
        pass

    def scaleTo(self, newScale, space): 
        '''scaleTo(self, newScale, space)
Arguments:
	[in]	newScale = MVector
	[in]	space = MSpace.Space


Set the scale component of the transformation matrix. If an invalid space is passed, the scale will not be changed.'''
        pass

    def rotation(self, space): 
        '''rotation(self, space) -> MQuaternion
Returns: The quaternion that is the rotation component of the transformation matrix

Arguments:
	[in]	space = MSpace.Space


Returns the rotation component of the transformation matrix as a quaternion. If an invalid space is used,  MQuaternion::identity  will be returned.'''
        pass

    def __neq__(self, rhs): 
        '''__neq__(self, rhs) -> bool
Returns: Boolean value: true The matrices are not identical, false otherwise. 

Arguments:
	[in]	rhs = MMatrix


Equality operator.'''
        pass

    def translateTo(self, t, space): 
        '''translateTo(self, t, space)
Arguments:
	[in]	t = MVector
	[in]	space = MSpace.Space


Sets the translate component of the transformation matrix in centimeters.'''
        pass

    def scale(self, space): 
        '''scale(self, space) -> MVector
Returns: Vector holding the x, y, and z scale components

Arguments:
	[in]	space = MSpace.Space


Returns the scale component of the transformation matrix. If the space is invalid a  MVector  with all of its components being 1.0 is returned.'''
        pass

    def shearBy(self, shearOffset, space): 
        '''shearBy(self, shearOffset, space)
Arguments:
	[in]	shearOffset = MVector
	[in]	space = MSpace.Space


Apply a new shear to the existing shear component of the transformation matrix. The shear values are added by multiplying the individual shear components with the offset values.'''
        pass

    def asMatrixInverse(self): 
        '''asMatrixInverse(self) -> MMatrix


Returns the inverse of the four by four matrix that describes this transformation.'''
        pass

    def shearTo(self, newShear, space): 
        '''shearTo(self, newShear, space)
Arguments:
	[in]	newShear = MVector
	[in]	space = MSpace.Space


Sets the shear component of the transformation matrix.'''
        pass

    def rotatePivot(self, space): 
        '''rotatePivot(self, space) -> MPoint
Returns: The rotation pivot point.

Arguments:
	[in]	space = MSpace.Space


Returns the pivot used by the rotation.'''
        pass

    def setRotatePivotTranslation(self, v, space): 
        '''setRotatePivotTranslation(self, v, space)
Arguments:
	[in]	v = MVector
	[in]	space = MSpace.Space


Set the rotate pivot translation. When the scale pivot is changed, there is an option to automatically compensate for the change so that the overall transformation is not altered. The compensating factor is the rotate pivot translation.'''
        pass

    def rotatePivotTranslation(self, space): 
        '''rotatePivotTranslation(self, space) -> MVector
Returns: The rotate pivot translation.

Arguments:
	[in]	space = MSpace.Space


Returns the rotate pivot translation, which is used to compensate for changes of the rotate pivot.'''
        pass

    def unSquishMatrix(self): 
        '''unSquishMatrix(self) -> MMatrix


Remove any shearing and any non-proportional scaling. If the scaling is non-proportional, then the maximum scale of the three scale axes will be used on all of the scale axes. The method creates a new 4x4  MMatrix  and leaves this transformation matrix unchanged.'''
        pass

    def rotateBy(self, euler, space): 
        '''rotateBy(self, euler, space)
Arguments:
	[in]	euler = MEulerRotation
	[in]	space = MSpace.Space


Rotates relative to the current rotation value of the transformation matrix. By default, the only valid transformation spaces for this method are  MSpace::kTransform  and  MSpace::kPreTransform . All other spaces are treated as being equivalent to  MSpace::kTransform .'''
        pass

    def asScaleMatrix(self): 
        '''asScaleMatrix(self) -> MMatrix


Returns scale matrix. The scale matrix takes points from object space to the space immediately following scale and shear transformations.'''
        pass

    def asMatrix(self, percent): 
        '''asMatrix(self, percent) -> MMatrix

Arguments:
	[in]	percent = double


Returns a matrix that represents the specified percentage of this transformation matrix. This is performed on a component basis.'''
        pass

    def eulerRotateOrientation(self, space): 
        '''eulerRotateOrientation(self, space) -> MEulerRotation
Returns: The rotate orientation as an euler angle.

Arguments:
	[in]	space = MSpace.Space


Returns the rotate orientation for the transformation matrix as an euler rotation. The rotate orientation orients the local rotation space.'''
        pass

    def setScalePivotTranslation(self, v, space): 
        '''setScalePivotTranslation(self, v, space)
Arguments:
	[in]	v = MVector
	[in]	space = MSpace.Space


Set the scale pivot translation. When the scale pivot is changed, there is an option to automatically compensate for the change so that the overall transformation is not altered. The compensating factor is the scale pivot translation.'''
        pass

    def convertTransformationRotationOrder(self, xformOrder): 
        '''convertTransformationRotationOrder(self, xformOrder) -> MEulerRotation.RotationOrder
Returns: The corresponding MEulerRotation::RotationOrder.

Arguments:
	[in]	xformOrder = MTransformationMatrix.RotationOrder


Convert from  MTransformationMatrix::RotationOrder  to  MEulerRotation::RotationOrder . If  MTransformationMatrix::kLast  or  MTransformationMatrix::kInvalid  is passed in,  MEulerRotation::kXYZ  will be returned along with a kInvalidParameter return status.'''
        pass

    def rotationOrder(self): 
        '''rotationOrder(self) -> MTransformationMatrix.RotationOrder
Returns: The rotation order use by the rotation component of the transformation matrix.


Returns the rotation order used by the rotation component of the transformation matrix.'''
        pass

    def setRotatePivot(self, rotatePivot, space, balance): 
        '''setRotatePivot(self, rotatePivot, space, balance)
Arguments:
	[in]	rotatePivot = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool


Set the pivot used by the rotation.'''
        pass

    def asRotateMatrixInverse(self): 
        '''asRotateMatrixInverse(self) -> MMatrix


Returns the inverse of the rotate matrix. By default this is described as:'''
        pass

    def scalePivotTranslation(self, space): 
        '''scalePivotTranslation(self, space) -> MVector
Returns: The scale pivot translation.

Arguments:
	[in]	space = MSpace.Space


Returns the scale pivot translation, which is used to compensate for changes of the scale pivot.'''
        pass

    def setScalePivot(self, scalePivot, space, balance): 
        '''setScalePivot(self, scalePivot, space, balance)
Arguments:
	[in]	scalePivot = MPoint
	[in]	space = MSpace.Space
	[in]	balance = bool


Set the pivot used by the scale.'''
        pass

    def isEquivalent(self, other, tolerance): 
        '''isEquivalent(self, other, tolerance) -> bool
Returns: Boolean value; true The matrices are identical within the specified tolerance, false otherwise. 

Arguments:
	[in]	other = MMatrix
	[in]	tolerance = double


Determine if the  MMatrix  is equivalent within a specified tolerance.'''
        pass

    def unSquishIt(self): 
        '''unSquishIt(self)

Remove any shearing and any non-proportional scaling from this transform. If the scaling is non-proportional, then the maximum scale of the three scale axes will be used on all of the scale axes.'''
        pass

    def translation(self, space): 
        '''translation(self, space) -> MVector
Returns: The translation vector in centimeters.

Arguments:
	[in]	space = MSpace.Space


Returns the translation component of the transformation matrix as a  MVector  in centimeters (the internal Maya linear unit).'''
        pass

    def copyValues(self, xform): 
        '''copyValues(self, xform)
Arguments:
	[in]	xform = MPxTransformationMatrix


This method should be overridden for any transform that uses more then the default transform values. The values from the passed class (which should be type checked and downcast to its appropriate value) should be copied to this class.'''
        pass

    def __eq__(self, rhs): 
        '''__eq__(self, rhs) -> bool
Returns: Boolean value: true The matrices are identical, false otherwise. 

Arguments:
	[in]	rhs = MMatrix


Equality operator'''
        pass

    def decomposeMatrix(self, m): 
        '''decomposeMatrix(self, m)
Arguments:
	[in]	m = MMatrix


This method converts a passed  MMatrix  into individual transformation matrix components. The default algorithm will solve under the assumption that the pivots and pivot translates are all zero.'''
        pass

    def reverse(self): 
        '''reverse(self) -> MPxTransformationMatrix


Returns the negated translate, rotate, and scale without taking the pivots into account.'''
        pass

    def asScaleMatrixInverse(self): 
        '''asScaleMatrixInverse(self) -> MMatrix


Returns inverse of the scale matrix. The scale matrix takes points from object space to the space immediately following scale and shear transformations.'''
        pass

    def asRotateMatrix(self): 
        '''asRotateMatrix(self) -> MMatrix


Returns the rotate section of the transformation matrix. By default this is described as:'''
        pass

    def eulerRotation(self, space): 
        '''eulerRotation(self, space) -> MEulerRotation
Returns: The euler angle that is the rotation component of the transformation matrix.

Arguments:
	[in]	space = MSpace.Space


Returns the rotation component of the transformation matrix as a euler rotation. If an invalid space is used,  MEulerRotation::identity  will be returned.'''
        pass

    def scaleBy(self, scaleFactor, space): 
        '''scaleBy(self, scaleFactor, space)
Arguments:
	[in]	scaleFactor = MVector
	[in]	space = MSpace.Space


Apply a relative scale to the existing scale.'''
        pass

    def rotateOrientation(self, space): 
        '''rotateOrientation(self, space) -> MQuaternion
Returns: The rotate orientation.

Arguments:
	[in]	space = MSpace.Space


Returns the rotate orientation for the transformation matrix as a quaternion. The rotate orientation orients the local rotation space.'''
        pass

    def shear(self, space): 
        '''shear(self, space) -> MVector
Returns: A MVector holding the xy, xz, yz values of shear.

Arguments:
	[in]	space = MSpace.Space


Returns the shear component of the transformation matrix.'''
        pass

    def transformBy(self, transMat): 
        '''transformBy(self, transMat) -> MPxTransformationMatrix
Returns: This transformation matrix. 

Arguments:
	[in]	transMat = MTransformationMatrix


Transforms the transformation matrix by the passed  MTransformationMatrix . The individual components are considered with the exception of the pivot translations.'''
        pass

    def setRotationOrder(self, rotOrder, preserve): 
        '''setRotationOrder(self, rotOrder, preserve)
Arguments:
	[in]	rotOrder = MTransformationMatrix.RotationOrder
	[in]	preserve = bool


Sets the rotation order used by the rotation component of the transformation matrix.'''
        pass

    def convertEulerRotationOrder(self, eulerOrder): 
        '''convertEulerRotationOrder(self, eulerOrder) -> MTransformationMatrix.RotationOrder
Returns: The corresponding MTransformationMatrix::RotationOrder.

Arguments:
	[in]	eulerOrder = MEulerRotation.RotationOrder


Convert from  MEulerRotation::RotationOrder  to  MTransformationMatrix::RotationOrder .'''
        pass

class MPxUIControl:
    '''Base class for control creation. MPxUIControl is the base class for user defined UI. This class should never be extended. Extend the derived classes of this class. '''
    def __init__(self):
        pass


class MPxUITableControl:
    '''Base class for creating new spreadsheet controls. MPxUITableControl is the base class for creating new spreadsheet like interfaces. Every UI control has an associated command that is 'in-charge' of that control. Therefore, when creating a new table control, you will need to create an associated MPxControlCommand. Please refer to the MPxControlCommand documentation for details on how to use these class together.At a minimum, when creating a new table control, you must overload getCell( ... ). Other methods available for overloading are getLabel(...), allowEdit( ... ), allowSelection( ... ), and collapseOrExpandRow( ... ). '''
    def __init__(self):
        pass


    def redrawLabels(self, labelType): 
        '''redrawLabels(self, labelType)
Arguments:
	[in]	labelType = MPxUITableControl.MLabelType


Tells the table control to redraw the label entries.'''
        pass

    def clearSelection(self): 
        '''clearSelection(self)

Clears the selection table. This will remove all highlighted cells from the table.'''
        pass

    def allowEdit(self): 
        '''allowEdit(self) -> bool


Tells the base UI table control class if this control is editable. It is possible to implement tables that simple display information and do not allow the user to edit them.'''
        pass

    def setSelection(self, firstRow, lastRow, firstCol, lastCol): 
        '''setSelection(self, firstRow, lastRow, firstCol, lastCol)
Arguments:
	[in]	firstRow = int
	[in]	lastRow = int
	[in]	firstCol = int
	[in]	lastCol = int


Sets the selection to be the range of cells specified. This replaces the current selection with the specified selection range.'''
        pass

    def isSelected(self, row, col): 
        '''isSelected(self, row, col) -> bool

Arguments:
	[in]	row = int
	[in]	col = int


Returns true if the specified cell is selected.'''
        pass

    def numberOfColumns(self): 
        '''numberOfColumns(self) -> int
Returns: MS::kSuccess Successfully returned the number of rows. 
MS::kFailure Internal error. 


Returns the number of columns in the table.'''
        pass

    def setNumberOfColumns(self, count): 
        '''setNumberOfColumns(self, count)
Arguments:
	[in]	count = int


Specifies the number of columns for the table.'''
        pass

    def setNumberOfRows(self, count): 
        '''setNumberOfRows(self, count)
Arguments:
	[in]	count = int


Specifies the number of rows for the table.'''
        pass

    def allowSelection(self, top, left, bottom, right): 
        '''allowSelection(self, top, left, bottom, right) -> bool
Returns: true the table can be edited. 
false the table should not be edited. 

Arguments:
	[in]	top = int
	[in]	left = int
	[in]	bottom = int
	[in]	right = int


This method is called when a selection occurs. In this base implementation it always returns true. However, this method can be overridden to allow or disallow a selection.'''
        pass

    def labelString(self, labelType, n): 
        '''labelString(self, labelType, n) -> MString
Returns: Label for the specified row or column. 

Arguments:
	[in]	labelType = MPxUITableControl.MLabelType
	[in]	n = int


Specifies the label value for the given row or column (as defined by) MLabelType. The base implementation of the method always returns an empty string.'''
        pass

    def numberOfRows(self): 
        '''numberOfRows(self) -> int
Returns: Number of rows in the table or zero on failure.


Returns the number of rows in the table.'''
        pass

    def suspendUpdates(self, update): 
        '''suspendUpdates(self, update) -> bool
Returns: MS::kSuccess Suspend status updated. 
MS::kFailure Internal error. 

Arguments:
	[in]	update = bool


When set to true, it prevents the UI from updating the table. The old suspend status is returned.'''
        pass

    def removeFromSelection(self, row, column): 
        '''removeFromSelection(self, row, column)
Arguments:
	[in]	row = int
	[in]	column = int


Removes the specified cell entry from the internal selection list.'''
        pass

    def redrawCells(self): 
        '''redrawCells(self)

Tells the UI control to redraw the cells of the table. The table control maintains a database of cell entries and it will populate these entries using getCell interface.'''
        pass

    def collapseOrExpandRow(self, row): 
        '''collapseOrExpandRow(self, row) -> bool
Returns: true the action was handled. 
false the action was not handled. 

Arguments:
	[in]	row = int


This is called when a row should be collapsed or expanded (depending on its current state).'''
        pass

    def addToSelection(self, row, col): 
        '''addToSelection(self, row, col)
Arguments:
	[in]	row = int
	[in]	col = int


Add the follow cell to the selection data structure. To keep track of which entries that should be highlighted, an internal table is maintained.'''
        pass

    def kRowLabel(self):
        '''This is an enum of MLabelType.
Description: 
Value: 1'''
        pass

    def kNoLabel(self):
        '''This is an enum of MLabelType.
Description: 
Value: 0'''
        pass

    def kColumnLabel(self):
        '''This is an enum of MLabelType.
Description: 
Value: 2'''
        pass

    def kAllLabels(self):
        '''This is an enum of MLabelType.
Description: 
Value: 3'''
        pass

    class MLabelType:
        '''Non-functional class.  Values for this enum:
        kRowLabel
        kNoLabel
        kColumnLabel
        kAllLabels
'''
        def __init__(self):
            pass

    def cellString(self, r, c, isValidCell): 
        '''cellString(self, r, c, isValidCell) -> MString
Returns: Return a true state if a valid value was returned. 

Arguments:
	[in]	r = int
	[in]	c = int
	[in]	isValidCell = bool


Derived classes MUST either override this method or the cellString method. It is used to describe the contents of a cell.'''
        pass

