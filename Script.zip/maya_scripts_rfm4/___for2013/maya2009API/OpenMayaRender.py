
'''
Stub class file for:
OpenMayaRender

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class MCommonRenderSettingsData:
    '''Data container for common rendering settings. This class is a container that encapsulates the data for common rendering globals. The data is intended to be accessed using the following method: '''
    def __init__(self):
        pass


    def MString(self, renderPass, layer, cameraName, customTokenString, leaveUnmatchedTokens): 
        '''MString(self, renderPass, layer, cameraName, customTokenString, leaveUnmatchedTokens) -> const
Returns: The name of buffer as a string. 

Arguments:
	[in]	renderPass = MObject
	[in]	layer = MObject
	[in]	cameraName = MString
	[in]	customTokenString = MString
	[in]	leaveUnmatchedTokens = bool


Get image buffer name'''
        pass

    def isAnimated(self): 
        '''isAnimated(self) -> bool


Determines if there is animation. 
'''
        pass

    def setFieldName(self, field): 
        '''setFieldName(self, field)
Arguments:
	[in]	field = MString


Used with getImageName. Sets the field name for later use. 
'''
        pass

    def isMovieFormat(self): 
        '''isMovieFormat(self) -> bool


Determines if the output format is a single movie file. 
'''
        pass

    def setPassName(self, passn): 
        '''setPassName(self, passn)
Arguments:
	[in]	passn = MString


Used with getImageName. Sets the pass name for later use. 
'''
        pass

    def kFullPathTmp(self):
        '''This is an enum of MpathType.
Description: Full path in the temporary directory.
Value: 2'''
        pass

    def kFullPathImage(self):
        '''This is an enum of MpathType.
Description: Full path.
Value: 1'''
        pass

    def kRelativePath(self):
        '''This is an enum of MpathType.
Description: Relative to the project.
Value: 0'''
        pass

    class MpathType:
        '''Non-functional class.  Values for this enum:
        kFullPathTmp
        kFullPathImage
        kRelativePath
'''
        def __init__(self):
            pass

class MD3D9Renderer:
    '''Access DirectX utility class. MD3D9Renderer is a wrapper class to provide access to Maya's DirectX resources. '''
    def __init__(self):
        pass


    def setBackgroundColor(self, color): 
        '''setBackgroundColor(self, color)
Arguments:
	[in]	color = MColor


Set the back ground color of the swatch. This clear the reading buffer as well.'''
        pass

    def readSwatchContextPixels(self, image): 
        '''readSwatchContextPixels(self, image)
Arguments:
	[in]	image = MImage


Reads out the current swatch context color buffer into an image format.'''
        pass

    def makeSwatchContextCurrent(self, width, height): 
        '''makeSwatchContextCurrent(self, width, height)
Arguments:
	[out]	width = int
	[out]	height = int


Create a directX render target (or context) to render into for swatches.'''
        pass

    def theRenderer(self): 
        '''theRenderer(self) -> MD3D9Renderer


Returns a static pointer to the hardware renderer wrapper class.'''
        pass

class MDrawProcedureBase:
    '''Base user draw procedure class. This class provides an interface through which a plug-in can be writen to implement a class to provide custom hardware drawing effects.The derived class can be added, removed, or reordered in a list of draw procedures used by the hardware renderer. Please refer to documentation for MhardwareRenderer for more details.Each procedure has a user defined string name and can be enabled or disabled. Name, and enabling methods must be defined.All derived classes must over the execute() method. This is the method that will be called by the hardware renderer to which the procedure is attached. The call will only be made if the procedure is enabled. '''
    def __init__(self):
        pass


    def setEnabled(self, value): 
        '''setEnabled(self, value)
Arguments:
	[in]	value = bool


This method sets whether the draw procedure is enabled or not.'''
        pass

    def execute(self): 
        '''execute(self) -> bool


This method gets called by the renderer to execture the draw procedure. Derived class of  MDrawProcedureBase  must implement this method as it defined as a pure virtual method on this class. The implementation is free to perform any drawing functionality from within this method.'''
        pass

    def enabled(self): 
        '''enabled(self) -> bool


This method returns whether the draw procedure is enabled or not.'''
        pass

    def setName(self, name): 
        '''setName(self, name)
Arguments:
	[in]	name = MString


This method sets the name for the draw procedure.'''
        pass

    def MString(self): 
        '''MString(self) -> const

'''
        pass

class MFnRenderLayer:
    '''Function set for render layer. Provide functionalities for working with render layers such as getting the objects present in the render layer or checking whether the given object is in the current layer. '''
    def __init__(self):
        pass


    def listAllRenderLayers(self, array): 
        '''listAllRenderLayers(self, array)
Arguments:
	[in]	array = MObjectArray


Returns the list of render layers currently in the system.'''
        pass

    def isPlugAdjusted(self, scenePlug): 
        '''isPlugAdjusted(self, scenePlug) -> bool

Arguments:
	[in]	scenePlug = MPlug


The function checks if the specified plug is adjusted or not; returns true if the plug is adjusted, else returns false.'''
        pass

    def listMembers(self, objectsInLayer): 
        '''listMembers(self, objectsInLayer)
Arguments:
	[in]	objectsInLayer = MObjectArray


Returns the objects present in the render layer.'''
        pass

    def externalRenderPasses(self, renderPassArray): 
        '''externalRenderPasses(self, renderPassArray)
Arguments:
	[in]	renderPassArray = MObjectArray

'''
        pass

    def passHasLight(self, renderPass, light): 
        '''passHasLight(self, renderPass, light) -> bool

Arguments:
	[in]	renderPass = MObject
	[in]	light = MObject


Returns true if the specified light contributes to the given render pass, based on the pass contribution maps attached to this layer. This method does not verify whether the light or the renderPass are actually rendered by the layer.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def findLayerByName(self, renderLayer): 
        '''findLayerByName(self, renderLayer) -> MObject

Arguments:
	[in]	renderLayer = MString


This function returns an  MObject  to a render layer that matches the specified name. If no render layer is found with the given name,  MObject::kNullObj  is returned.'''
        pass

    def inCurrentRenderLayer(self, objectPath): 
        '''inCurrentRenderLayer(self, objectPath) -> bool

Arguments:
	[in]	objectPath = MDagPath


The function checks if the given object is present in the current render layer or not.'''
        pass

    def defaultRenderLayer(self): 
        '''defaultRenderLayer(self) -> MObject


Returns the  MObject  for the defaultRenderLayer. This  MObject  can be used in  MFnRenderLayer .'''
        pass

    def inLayer(self, transform): 
        '''inLayer(self, transform) -> bool

Arguments:
	[in]	transform = MObject


Returns true if the given shape is in this layer. This method will check all container layers for transform containment. The  MObject  specified must be a shape node.'''
        pass

    def passHasObject(self, renderPass, objectInstance): 
        '''passHasObject(self, renderPass, objectInstance) -> bool

Arguments:
	[in]	renderPass = MObject
	[in]	objectInstance = MDagPath


Returns true if the specified object instance contributes to the given render pass, based on the pass contribution maps attached to the layer. This method does not verify whether the object instance or the renderPass are actually rendered by the layer.'''
        pass

    def layerChildren(self, array, recurse): 
        '''layerChildren(self, array, recurse)
Arguments:
	[in]	array = MObjectArray
	[in]	recurse = bool


Returns the container layers for this layer. Container layers provide the ability for a given render layer to "contain" other render layers.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def currentLayer(self): 
        '''currentLayer(self) -> MObject


Returns the  MObject  for the current render layer. This  MObject  can be used in  MFnRenderLayer .'''
        pass

class MFnRenderPass:
    '''Function set for render passes. Provide functionalities for working with render passes such as retrieving renderer-specific implementations. '''
    def __init__(self):
        pass


    def frameBufferChannels(self): 
        '''frameBufferChannels(self) -> int


Returns the number of channels of the frame buffer associated with the render pass.'''
        pass

    def usesFiltering(self): 
        '''usesFiltering(self) -> bool


Returns true if frame buffer filtering is requested. This setting may be ignored in the cases of frame buffer types and frame buffer semantics that do not allow interpolation.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def passID(self): 
        '''passID(self) -> MString


Returns the passID string that uniquely identifies the renderpass definition associated with the pass'''
        pass

    def frameBufferType(self): 
        '''frameBufferType(self) -> MPxRenderPassImpl.PassTypeBit


Returns the data type of the frame buffer associated with the render pass.'''
        pass

    def setImplementation(self, renderer): 
        '''setImplementation(self, renderer) -> MPxRenderPassImpl
Returns: A pointer to the render implementation object.

Arguments:
	[in]	renderer = MString


Returns the first render pass implementation compatible with the specified renderer and that supports the currently selected frame buffer data type and the selected number of channels.'''
        pass

    def customTokenString(self): 
        '''customTokenString(self) -> MString


Returns a custom token string that can be passed to  MCommonRenderSettingsData::getImageName()  to generate a file name for the pass.'''
        pass

    def getImplementation(self): 
        '''getImplementation(self) -> MPxRenderPassImpl

'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MGeometry:
    '''Geometric data cache. MGeometry stores the collection of MGeometryData arrays which describe a Maya surface, including per-component data such as UV mapping and colour. '''
    def __init__(self):
        pass


    def primitiveArrayCount(self): 
        '''primitiveArrayCount(self) -> int


Get the number of primitive data for this surface.'''
        pass

    def MGeometryData(self, what, name): 
        '''MGeometryData(self, what, name) -> const
Returns: The geometry data (which may be empty). 

Arguments:
	[in]	what = MGeometryData.DataType
	[in]	name = MString


Get arbitrary surface data by name.'''
        pass

    def MGeometryPrimitive(self, arrayNumber): 
        '''MGeometryPrimitive(self, arrayNumber) -> const

Arguments:
	[in]	arrayNumber = int


Get the primitive data for this surface. The primitive describes how the data arrays should be used when rendering.'''
        pass

class MGeometryData:
    '''Geometric data container. This class allows storage of arbitrary data which is formated to be specifically suitable for usage using a 3D display interface such as OpenGL.Format options include:Currently Maya only interprets a fixed format subset for data with recongnized semantics, This does not mean that the user cannot create any arbitrary format for data storage. Support formats with semantics includes:Memory allocation of the correct size is left up to the user of this class.Memory can be marked as "owned" by this class or the user of this class. Ownership by this class is the default behaviour specified in the constructor. If the data is marked as being owned by the class, it is assumed that the data is created using a "new" operation, as the destructor of this class will use a "delete" operation to free memory.Internal Maya data which is passed to the user via this class is always assumed to be non-modifiable. '''
    def __init__(self):
        pass


    def elementType(self): 
        '''elementType(self) -> MGeometryData.ElementType


Returns the data type.'''
        pass

    def elementTypeSize(self): 
        '''elementTypeSize(self) -> int


Return the element type size'''
        pass

    def objectName(self): 
        '''objectName(self) -> char*


Return the logical name of the geometry'''
        pass

    def elementCount(self): 
        '''elementCount(self) -> int


Return element count.'''
        pass

    def kThree(self):
        '''This is an enum of ElementSize.
Description: 3-tuple
Value: 3'''
        pass

    def kTwo(self):
        '''This is an enum of ElementSize.
Description: 2-tuple
Value: 2'''
        pass

    def kInvalidElementSize(self):
        '''This is an enum of ElementSize.
Description: Invalid element size.
Value: 0'''
        pass

    def kOne(self):
        '''This is an enum of ElementSize.
Description: Single value.
Value: 1'''
        pass

    def kFour(self):
        '''This is an enum of ElementSize.
Description: 4-tuple
Value: 4'''
        pass

    class ElementSize:
        '''Non-functional class.  Values for this enum:
        kThree
        kTwo
        kInvalidElementSize
        kOne
        kFour
'''
        def __init__(self):
            pass

    def setCollectionNumber(self, collectionNumber): 
        '''setCollectionNumber(self, collectionNumber)
Arguments:
	[in]	collectionNumber = int


Set the collection number for the object. Numbers less than 0 are invalid collection numbers.'''
        pass

    def elementSize(self): 
        '''elementSize(self) -> MGeometryData.ElementSize


Return element size.'''
        pass

    def dataType(self): 
        '''dataType(self) -> MGeometryData.DataType


Get the data type for the data.'''
        pass

    def kWeight(self):
        '''This is an enum of DataType.
Description: Vertex weighting data.
Value: 5'''
        pass

    def kAPISupported(self):
        '''This is an enum of DataType.
Description: Separator to indicate native draw API supported types.
Value: 6'''
        pass

    def kVelocity(self):
        '''This is an enum of DataType.
Description: Velocity vector.
Value: 9'''
        pass

    def kTangent(self):
        '''This is an enum of DataType.
Description: Tangent vector.
Value: 7'''
        pass

    def kBiNormal(self):
        '''This is an enum of DataType.
Description: Bi-normal vector.
Value: 8'''
        pass

    def kColor(self):
        '''This is an enum of DataType.
Description: Color tuple.
Value: 4'''
        pass

    def kUserData(self):
        '''This is an enum of DataType.
Description: Arbitrary "user data".
Value: 12'''
        pass

    def kTexCoord(self):
        '''This is an enum of DataType.
Description: Texture coordinate tuple.
Value: 3'''
        pass

    def kPrimitiveCenter(self):
        '''This is an enum of DataType.
Description: Center of primitive.
Value: 10'''
        pass

    def kColorMask(self):
        '''This is an enum of DataType.
Description: Mapped, unmapped color mask.
Value: 11'''
        pass

    def kMaxDataTypeIndex(self):
        '''This is an enum of DataType.
Description: Valid entries are < kMaxDataTypeIndex.
Value: 13'''
        pass

    def kPosition(self):
        '''This is an enum of DataType.
Description: Position vector.
Value: 1'''
        pass

    def kInvalidDataType(self):
        '''This is an enum of DataType.
Description: Invalid data type (default value).
Value: 0'''
        pass

    def kNormal(self):
        '''This is an enum of DataType.
Description: Normal vector.
Value: 2'''
        pass

    class DataType:
        '''Non-functional class.  Values for this enum:
        kWeight
        kAPISupported
        kVelocity
        kTangent
        kBiNormal
        kColor
        kUserData
        kTexCoord
        kPrimitiveCenter
        kColorMask
        kMaxDataTypeIndex
        kPosition
        kInvalidDataType
        kNormal
'''
        def __init__(self):
            pass

    def setObjectOwnsData(self, value): 
        '''setObjectOwnsData(self, value)
Arguments:
	[in]	value = bool


Set ownship of the interal data.'''
        pass

    def objectOwnsData(self): 
        '''objectOwnsData(self) -> bool


Return if the  MGeometryData  object owns the internal data or not.'''
        pass

    def uniqueID(self): 
        '''uniqueID(self) -> int


Return the per session unique identifier'''
        pass

    def kUnsignedInt32(self):
        '''This is an enum of ElementType.
Description: Unsigned 32-bit integer.
Value: 7'''
        pass

    def kUnsignedInt16(self):
        '''This is an enum of ElementType.
Description: Unsigned 16-bit integer.
Value: 5'''
        pass

    def kInt32(self):
        '''This is an enum of ElementType.
Description: Signed 32-bit integer.
Value: 6'''
        pass

    def kInt16(self):
        '''This is an enum of ElementType.
Description: Signed 16-bit integer.
Value: 4'''
        pass

    def kUnsignedChar(self):
        '''This is an enum of ElementType.
Description: Unsigned char.
Value: 3'''
        pass

    def kDouble(self):
        '''This is an enum of ElementType.
Description: IEEE double precision floating point.
Value: 1'''
        pass

    def kFloat(self):
        '''This is an enum of ElementType.
Description: IEEE single precision floating point.
Value: 0'''
        pass

    def kChar(self):
        '''This is an enum of ElementType.
Description: Signed char.
Value: 2'''
        pass

    def kInvalidElementType(self):
        '''This is an enum of ElementType.
Description: Invalid element type (default value).
Value: -1'''
        pass

    class ElementType:
        '''Non-functional class.  Values for this enum:
        kUnsignedInt32
        kUnsignedInt16
        kInt32
        kInt16
        kUnsignedChar
        kDouble
        kFloat
        kChar
        kInvalidElementType
'''
        def __init__(self):
            pass

    def data(self): 
        '''data(self) -> void*


Retrieve a pointer to the internal data'''
        pass

    def collectionNumber(self): 
        '''collectionNumber(self) -> int


Get the collection number of the data. Collection numbers are zero-based.'''
        pass

class MGeometryList:
    '''Geometric data cache. This class holds the set of data elements which represent a Maya surface. It provides iterated access to a list of geometry items, along with the rendering context require to render them (e.g. matrix, etc). '''
    def __init__(self):
        pass


    def reset(self): 
        '''reset(self)
'''
        pass

    def addLast(self, geometry, matrix): 
        '''addLast(self, geometry, matrix) -> bool
Returns: True if the element was added to the iterator, false otherwise. 

Arguments:
	[in]	geometry = MGeometry
	[in]	matrix = MMatrix


Add arbitrary geometry to this geometry iterator. Note that you are only able to add geometry items to MGeometryLists you have created using the public constructor. Trying to add elements to an iterator passed to you from Maya (e.g. in a shader render call) will fail.'''
        pass

    def geometry(self, setupFlags): 
        '''geometry(self, setupFlags) -> MGeometry
Returns: The geometry for the current element. 

Arguments:
	[in]	setupFlags = int


Get the geometry for the current element in the iterator.'''
        pass

    def MMatrix(self): 
        '''MMatrix(self) -> const


Get the camera view matrix for the current element in the iterator.'''
        pass

    def enum(self): 
        '''enum(self) -> anonymous


Bit flags for the geometry method that govern which OpenGL state Maya sets for you. 
'''
        pass

    def setCurrentElement(self, i): 
        '''setCurrentElement(self, i)
Arguments:
	[in]	i = int


Randomly access the ith element in the iterator.'''
        pass

    def cullMode(self): 
        '''cullMode(self) -> MGeometryList.MCullMode


Get the rendering cull mode to use for current element in the iterator.'''
        pass

    def next(self): 
        '''next(self)

Advance to the next element in the iterator. This should only be called if the iterator indicates it has more elements through the  isDone()  method. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp . 
 
'''
        pass

    def length(self): 
        '''length(self) -> int


Query the total number of elements available through this iterator.'''
        pass

    def kCullCCW(self):
        '''This is an enum of MCullMode.
Description: Cull counter-clockwise faces when rendering this geometry.
Value: 2'''
        pass

    def kCullNone(self):
        '''This is an enum of MCullMode.
Description: No culling should be performed on this geometry.
Value: 0'''
        pass

    def kCullCW(self):
        '''This is an enum of MCullMode.
Description: Cull clockwise faces when rendering this geometry.
Value: 1'''
        pass

    class MCullMode:
        '''Non-functional class.  Values for this enum:
        kCullCCW
        kCullNone
        kCullCW
'''
        def __init__(self):
            pass

    def path(self): 
        '''path(self) -> MDagPath


Get the dag path for the current element in the iterator.'''
        pass

    def isDone(self): 
        '''isDone(self) -> bool


Tests to see if the iterator has reached the end of the elements it contains. Once this method returns true, you should not call any further methods on the iterator.'''
        pass

class MGeometryManager:
    '''Geometry cache management. This class provides methods for managing MGeometry resources.It provides an interface for loading and using hardware textures. '''
    def __init__(self):
        pass


    def kDefaultPlane(self):
        '''This is an enum of GeometricShape.
Description: Plane with width and height of 1, centered at 0,0,0. Assuming "Y-Up" orientation: width = x-axis, and height = y-axis.
Value: 1'''
        pass

    def kDefaultSphere(self):
        '''This is an enum of GeometricShape.
Description: Sphere with radius 1, centered at 0,0,0.
Value: 0'''
        pass

    def kDefaultCube(self):
        '''This is an enum of GeometricShape.
Description: Cube with width, height and depth of 1, centered at 0,0,0.
Value: 2'''
        pass

    class GeometricShape:
        '''Non-functional class.  Values for this enum:
        kDefaultPlane
        kDefaultSphere
        kDefaultCube
'''
        def __init__(self):
            pass

    def dereferenceDefaultGeometry(self, geomIterator): 
        '''dereferenceDefaultGeometry(self, geomIterator)
Arguments:
	[in]	geomIterator = MGeometryList


This is the companion method to  referenceDefaultGeometry()  and must always be called immediately after usage of data supplied by the reference call.'''
        pass

    def referenceDefaultGeometry(self, geomShape, requirements): 
        '''referenceDefaultGeometry(self, geomShape, requirements) -> MGeometryList
Returns: A pointer to a geometry iterator (MGeometryList), which contains a reference to the geometric data (MGeometry). The MGeometry information which tries to match the requirements passed in. ( e.g. position, normal, texture coordinates, tangents, and binormals etc). It can be assumed that all data is floating point such that:


Positions are 3 float (x,y,z) positions 

Normals are 3 float (x,y,z) vectors. 

Texture coordinates are 2 float (u,v) tuples. 

Tangents are 3 float (x,y,z) vectors. 

Binormals are 3 float (x,y,z) vectors. 

Arguments:
	[in]	geomShape = MGeometryManager.GeometricShape
	[in]	requirements = MGeometryRequirements


Obtain a reference to geometry for some "default" shapes maintained by the manager such that the geometry returned will match a set of geometric requirements ( MGeometryRequirements ). The actual form is a geometric iterator ( MGeometryList ), which can be used to iterate over the internal data kept ( MGeometry ).'''
        pass

    def getGeometry(self, shape, requirements, components): 
        '''getGeometry(self, shape, requirements, components) -> MGeometry
Returns: The cached geometry. 

Arguments:
	[in]	shape = MDagPath
	[in]	requirements = MGeometryRequirements
	[in]	components = MObject


Access the Geometry cache for a shape.'''
        pass

class MGeometryPrimitive:
    '''Geometric index container. MGeometryPrimitive is a class describes the topology used for accessing MGeometryData.Topology is specified as a set of index values which references into data elements in an MGeometryData. Index values can be assumed to be stored in contiguous memory.A "draw primitive type" indicates the format of the indexing as follows:Internal Maya data which is passed to the user via this class is always assumed to be non-modifiable. '''
    def __init__(self):
        pass


    def dataType(self): 
        '''dataType(self) -> MGeometryData.ElementType


Return element data type.'''
        pass

    def kTriangles(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_TRIANGLES In OpenGL.
Value: 5'''
        pass

    def kQuadStrip(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_QUAD_STRIP in OpenGL.
Value: 9'''
        pass

    def kMaxDrawPrimitiveTypeIndex(self):
        '''This is an enum of DrawPrimitiveType.
Description: Number of primitive types.
Value: 11'''
        pass

    def kPoints(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_POINTS in OpenGL.
Value: 1'''
        pass

    def kLineLoop(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_LINE_LOOP in OpenGL (non-filled, connected line segments).
Value: 4'''
        pass

    def kLines(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_LINES in OpenGL (individual unconnected line segments).
Value: 2'''
        pass

    def kTriangleFan(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_TRIANGLE_FAN in OpenGL.
Value: 7'''
        pass

    def kTriangleStrip(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_TRIANGLE_STRIP in OpenGL.
Value: 6'''
        pass

    def kInvalidIndexType(self):
        '''This is an enum of DrawPrimitiveType.
Description: Default value is not valid.
Value: 0'''
        pass

    def kPolygon(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_POLYGON in OpenGL.
Value: 10'''
        pass

    def kLineStrip(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_LINE_STRIP in OpenGL.
Value: 3'''
        pass

    def kQuads(self):
        '''This is an enum of DrawPrimitiveType.
Description: Corresponds to GL_QUADS in OpenGL.
Value: 8'''
        pass

    class DrawPrimitiveType:
        '''Non-functional class.  Values for this enum:
        kTriangles
        kQuadStrip
        kMaxDrawPrimitiveTypeIndex
        kPoints
        kLineLoop
        kLines
        kTriangleFan
        kTriangleStrip
        kInvalidIndexType
        kPolygon
        kLineStrip
        kQuads
'''
        def __init__(self):
            pass

    def drawPrimitiveType(self): 
        '''drawPrimitiveType(self) -> MGeometryPrimitive.DrawPrimitiveType


Get the data type for the data.'''
        pass

    def elementCount(self): 
        '''elementCount(self) -> int


Return element count.'''
        pass

    def uniqueID(self): 
        '''uniqueID(self) -> int


Return the per session unique identifier'''
        pass

    def data(self): 
        '''data(self) -> void*


Retrieve a pointer to the internal data'''
        pass

class MGeometryRequirements:
    '''Image manipulation. MGeometryRequirements stores the collection of MGeometryRequirementsData arrays which describe a Maya surface, including per-component data such as UV mapping and colour. '''
    def __init__(self):
        pass


    def addTexCoord(self, name): 
        '''addTexCoord(self, name)
Arguments:
	[in]	name = MString


Add a texture coordinate set to the list of required elements.'''
        pass

    def addColor(self, name): 
        '''addColor(self, name)
Arguments:
	[in]	name = MString


Add a color set to the list of required elements.'''
        pass

    def addComponentId(self): 
        '''addComponentId(self)

Add component id to the set of required elements. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp . 
 
'''
        pass

    def addBinormal(self, name): 
        '''addBinormal(self, name)
Arguments:
	[in]	name = MString


Add a binormal set to the list of required elements.'''
        pass

    def addTangent(self, name): 
        '''addTangent(self, name)
Arguments:
	[in]	name = MString


Add a tangent set to the list of required elements.'''
        pass

    def addPosition(self): 
        '''addPosition(self)

Add position to the set of required elements. 
  Reprocessed example  
 Examples: 
 
   
 D3DGeometryItem.cpp ,  hlslShader.cpp , and  OpenGLViewportRenderer.cpp . 
 
'''
        pass

    def addNormal(self): 
        '''addNormal(self)

Add normal to the set of required elements. 
  Reprocessed example  
 Examples: 
 
   
 D3DGeometryItem.cpp ,  hlslShader.cpp , and  OpenGLViewportRenderer.cpp . 
 
'''
        pass

class MGLFunctionTable:
    '''Utility class which provides wrappers for the OpenGL API. MGLFunctionTable is a utility class which provides wrappers for the basic functions in the OpenGL API.Core functions up to OpenGL 2.0 are provided here, as well as a number of ARB/EXT and vendor specific extensions. Refer to the MGLExtension enumeration for extensions which are checked.Please refer to an OpenGL reference for usage of the OpenGL functions provided in this wrapper class.When using the functions provided, the standard GL* type and constant definitions to be used can be found in MGLDefinitions.h.MGLDefinitions.h basically provides a wrapper for what would normally be found in gl.h and glext.h files.The naming convention used in this file is to take the regular GL* definitions and add a "M" prefix. This is to avoid conflicts with existing type and constant declarations which may be found in files such as gl.h and glext.h. It is recommended that externally provided files which have GL definitions not be included in the same C++ file to avoid conflicts. MGLFunctionTable cannot be created on its own, and must be retrieved via a method on the MHardwareRenderer class. It is possible that this class will not be available, if the hardware renderer class cannot be instantiated. This would be due to insufficient graphics hardware support.Below is an example of initializing and using the function table to draw a simple 3-line axis. Note the usage of the definitions from MGLDefinitions such as MGL_LIGHTING versus GL_LIGHTING, and MGL_LINES and MGL_DEPTH_TEST.Here is a similar example of using the function table in Python.'''
    def __init__(self):
        pass


    def numTexImageUnits(self): 
        '''numTexImageUnits(self) -> int


Get information about the maximum number of texture image units available.'''
        pass

    def maxVertexAttributes(self): 
        '''maxVertexAttributes(self) -> int


Get information about the maximum number of vertex attributes available.'''
        pass

    def numTexInterpolants(self): 
        '''numTexInterpolants(self) -> int


Get information about the maximum number of texture interpolants.'''
        pass

    def kMGL_Version20(self):
        '''This is an enum of MGLversion.
Description: GL 2.0.
Value: 6'''
        pass

    def kMGL_Version11(self):
        '''This is an enum of MGLversion.
Description: GL 1.1.
Value: 0'''
        pass

    def kMGL_Version13(self):
        '''This is an enum of MGLversion.
Description: GL 1.3.1.
Value: 3'''
        pass

    def kMGL_Version12(self):
        '''This is an enum of MGLversion.
Description: GL 1.2.
Value: 1'''
        pass

    def kMGL_Version15(self):
        '''This is an enum of MGLversion.
Description: GL 1.5.
Value: 5'''
        pass

    def kMGL_Version14(self):
        '''This is an enum of MGLversion.
Description: GL 1.4.1.
Value: 4'''
        pass

    def kMGL_Version121(self):
        '''This is an enum of MGLversion.
Description: GL 1.2.1.
Value: 2'''
        pass

    class MGLversion:
        '''Non-functional class.  Values for this enum:
        kMGL_Version20
        kMGL_Version11
        kMGL_Version13
        kMGL_Version12
        kMGL_Version15
        kMGL_Version14
        kMGL_Version121
'''
        def __init__(self):
            pass

    def extensionExists(self, extension): 
        '''extensionExists(self, extension) -> bool
Returns: true if the extension exists, false otherwise. 

Arguments:
	[in]	extension = MGLFunctionTable.MGLExtension


Provides information as to whether a given OpenGL extension exists. That is, the extension is reported to be supported.'''
        pass

    def numTexUnits(self): 
        '''numTexUnits(self) -> int


Get information about the maximum number of texture units. This may not be the same as the number of interpolants available.'''
        pass

    def maxTextureSize(self): 
        '''maxTextureSize(self) -> int


Get information about the maximum texture size.'''
        pass

class MHardwareRenderer:
    '''Static hardware renderer interface class. MHardwareRenderer is an interface class which wraps the hardware renderer. '''
    def __init__(self):
        pass


    def drawSwatchBackGroundQuads(self, quadColor, textured, numberOfRepeats): 
        '''drawSwatchBackGroundQuads(self, quadColor, textured, numberOfRepeats)
Arguments:
	[in]	quadColor = MColor
	[in]	textured = bool
	[in]	numberOfRepeats = int


This draws a set of quads in a checkboard pattern. Areas that are not drawn will have the background color show through.'''
        pass

    def makeSwatchContextCurrent(self, backEndString, desiredWidth, desiredHeight): 
        '''makeSwatchContextCurrent(self, backEndString, desiredWidth, desiredHeight)
Arguments:
	[in]	backEndString = MString
	[in]	desiredWidth = int
	[in]	desiredHeight = int


The swatch context is a "scratch" context which can be used to hardware render an image for swatch display. The swatch context has the following pixel format:'''
        pass

    def MString(self): 
        '''MString(self) -> const


Returns a string identifying the current "backend" being used. A backend represents a drawing API. Currently the only backend supported natively is OpenGL.'''
        pass

    def getColorBufferPixelFormat(self, backEndString, fmt): 
        '''getColorBufferPixelFormat(self, backEndString, fmt)
Arguments:
	[in]	backEndString = MString
	[out]	fmt = MHardwareRenderer.BufferPixelFormat


This method returns the pixel format of the current color buffer'''
        pass

    def getCurrentExposureNumber(self, backEndString, number): 
        '''getCurrentExposureNumber(self, backEndString, number)
Arguments:
	[in]	backEndString = MString
	[out]	number = int


This method returns the current exposure number during rendering. If the renderer is not currently rendering a value of 0 is returned as the current exposure number.'''
        pass

    def getBufferSize(self, backEndString, width, height): 
        '''getBufferSize(self, backEndString, width, height)
Arguments:
	[in]	backEndString = MString
	[out]	width = int
	[out]	height = int


This method returns the size of the current buffer'''
        pass

    def dereferenceGeometry(self, pGeomData, numberOfData): 
        '''dereferenceGeometry(self, pGeomData, numberOfData)
Arguments:
	[in]	pGeomData = MGeometryData
	[in]	numberOfData = int


This is the companion method to  MHardwareRenderer::referenceDefaultGeometry()  and must always be called immediate after usage of data supplied by the reference call.'''
        pass

    def getSwatchPerspectiveCameraSetting(self, l, r, b, t, n, f): 
        '''getSwatchPerspectiveCameraSetting(self, l, r, b, t, n, f)
Arguments:
	[out]	l = double
	[out]	r = double
	[out]	b = double
	[out]	t = double
	[out]	n = double
	[out]	f = double


This method returns a perspective camera clipping plane values which form the camera viewing volume. These values are the default values used for rendering the swatch.'''
        pass

    def getSwatchPerspectiveCameraTranslation(self, x, y, z, w): 
        '''getSwatchPerspectiveCameraTranslation(self, x, y, z, w)
Arguments:
	[out]	x = float
	[out]	y = float
	[out]	z = float
	[out]	w = float


This method returns a perspective camera 3D translation values. These are the default values used for rendering the swatch.'''
        pass

    def kDepth_Float32(self):
        '''This is an enum of BufferPixelFormat.
Description: 32 bit floating point depth buffer
Value: 2'''
        pass

    def kRGBA_Fix8(self):
        '''This is an enum of BufferPixelFormat.
Description: 8 bit Red, Green, Blue, and Alpha channel
Value: 0'''
        pass

    def kRGBA_Float16(self):
        '''This is an enum of BufferPixelFormat.
Description: 16 bit Red, Green, Blue, and Alpha channel
Value: 1'''
        pass

    class BufferPixelFormat:
        '''Non-functional class.  Values for this enum:
        kDepth_Float32
        kRGBA_Fix8
        kRGBA_Float16
'''
        def __init__(self):
            pass

    def getTotalExposureCount(self, backEndString, number): 
        '''getTotalExposureCount(self, backEndString, number)
Arguments:
	[in]	backEndString = MString
	[out]	number = int


This method returns the total number of exposures for rendering a single frame. If the renderer is not currently rendering a value of 0 is returned as the total exposure count.'''
        pass

    def kDefaultPlane(self):
        '''This is an enum of GeometricShape.
Description: Plane with width and height of 1, centered at 0,0,0. Assuming "Y-Up" orientation: width = x-axis, and height = y-axis.
Value: 1'''
        pass

    def kDefaultSphere(self):
        '''This is an enum of GeometricShape.
Description: Sphere with radius 1, centered at 0,0,0.
Value: 0'''
        pass

    def kDefaultCube(self):
        '''This is an enum of GeometricShape.
Description: Cube with width, height and depth of 1, centered at 0,0,0.
Value: 2'''
        pass

    class GeometricShape:
        '''Non-functional class.  Values for this enum:
        kDefaultPlane
        kDefaultSphere
        kDefaultCube
'''
        def __init__(self):
            pass

    def referenceDefaultGeometry(self, geomShape, numberOfData, pIndexing, indexLength): 
        '''referenceDefaultGeometry(self, geomShape, numberOfData, pIndexing, indexLength) -> MGeometryData
Returns: A pointer to an array of geometric data attributes (MGeometryData). Currently four attributes are returned. In array order they are: position, normal, texture coordinates, tangents, and binormals. It can be assumed that all data is float such that:

Arguments:
	[in]	geomShape = MHardwareRenderer.GeometricShape
	[out]	numberOfData = int
	[out]	pIndexing = int
	[out]	indexLength = int


Obtain a reference to geometry for some "default" shapes maintained by the hardware renderer. All data can be assumed to be "read-only", as  the data is not owned by the caller .'''
        pass

    def findDrawProcedure(self, backEndString, location, procName): 
        '''findDrawProcedure(self, backEndString, location, procName) -> MDrawProcedureBase
Returns: Pointer to a MDrawProcedureBase. null is returned if not found. 

Arguments:
	[in]	backEndString = MString
	[in]	location = MHardwareRenderer.CallLocation
	[in]	procName = MString


Find a drawing procedure instance with a specific name within a procedure list at a given render location.'''
        pass

    def getDrawProcedureCount(self, backEndString, location, count): 
        '''getDrawProcedureCount(self, backEndString, location, count) -> MHardwareRenderer.DrawProcedureStatusCode
Returns: DrawProcedureStatusCode : kSuccess, kFailure, or kLocationNotFound. if item already exists. 

Arguments:
	[in]	backEndString = MString
	[in]	location = MHardwareRenderer.CallLocation
	[out]	count = int


Find the length of the procedure list for a given render location.'''
        pass

    def kLocationNotFound(self):
        '''This is an enum of DrawProcedureStatusCode.
Description: Location not found.
Value: 4'''
        pass

    def kSuccess(self):
        '''This is an enum of DrawProcedureStatusCode.
Description: Success.
Value: 0'''
        pass

    def kItemExists(self):
        '''This is an enum of DrawProcedureStatusCode.
Description: Item already exists.
Value: 2'''
        pass

    def kItemNotFound(self):
        '''This is an enum of DrawProcedureStatusCode.
Description: Item is not found.
Value: 3'''
        pass

    def kFailure(self):
        '''This is an enum of DrawProcedureStatusCode.
Description: Failure.
Value: 1'''
        pass

    class DrawProcedureStatusCode:
        '''Non-functional class.  Values for this enum:
        kLocationNotFound
        kSuccess
        kItemExists
        kItemNotFound
        kFailure
'''
        def __init__(self):
            pass

    def restoreCurrent(self, backEndString): 
        '''restoreCurrent(self, backEndString)
Arguments:
	[in]	backEndString = MString


This method restores the current context to the one that the HWrenderer is using'''
        pass

    def getSwatchLightDirection(self, x, y, z, w): 
        '''getSwatchLightDirection(self, x, y, z, w)
Arguments:
	[out]	x = float
	[out]	y = float
	[out]	z = float
	[out]	w = float


This method returns the direction vector of the default directional light used for rendering the swatch.'''
        pass

    def kPostExposure(self):
        '''This is an enum of CallLocation.
Description: After rendering one "exposure".
Value: 2'''
        pass

    def kPreRendering(self):
        '''This is an enum of CallLocation.
Description: Before rendering one frame. No model or view matrices.
Value: 0'''
        pass

    def kPreExposure(self):
        '''This is an enum of CallLocation.
Description: Before rendering one "exposure". If multiple exposures are are required to render one frame. After the frame buffer is cleared and model and view matrices are set up for the current exposure.
Value: 1'''
        pass

    def kPostRendering(self):
        '''This is an enum of CallLocation.
Description: After rendering one frame. Before a possible fame buffer swap.
Value: 3'''
        pass

    class CallLocation:
        '''Non-functional class.  Values for this enum:
        kPostExposure
        kPreRendering
        kPreExposure
        kPostRendering
'''
        def __init__(self):
            pass

    def readSwatchContextPixels(self, backEndString, image): 
        '''readSwatchContextPixels(self, backEndString, image)
Arguments:
	[in]	backEndString = MString
	[out]	image = MImage


Read the contents of the swatch context into an  MImage .  MImage  is assumed to be of the correct pixel format (24-bit RGBA, with 8-bits per channel).  MImage  is assumed to also have pre-allocated the correct amount of data as this routine will copy the swatch context contents directly into the  MImage .'''
        pass

    def getSwatchOrthoCameraSetting(self, l, r, b, t, n, f): 
        '''getSwatchOrthoCameraSetting(self, l, r, b, t, n, f)
Arguments:
	[out]	l = double
	[out]	r = double
	[out]	b = double
	[out]	t = double
	[out]	n = double
	[out]	f = double


This method returns an orthographics camera clipping plane values which form the camera viewing volume. These values are the default values used for rendering the swatch.'''
        pass

    def getDepthBufferPixelFormat(self, backEndString, fmt): 
        '''getDepthBufferPixelFormat(self, backEndString, fmt)
Arguments:
	[in]	backEndString = MString
	[out]	fmt = MHardwareRenderer.BufferPixelFormat


This method returns the pixel format of the current depth buffer'''
        pass

    def addDrawProcedure(self, backEndString, drawProcedurePtr, location): 
        '''addDrawProcedure(self, backEndString, drawProcedurePtr, location) -> MHardwareRenderer.DrawProcedureStatusCode
Returns: DrawProcedureStatusCode : kSuccess, kFailure, kItemExists, or kLocationNotFound. if item already exists. 

Arguments:
	[in]	backEndString = MString
	[in]	drawProcedurePtr = MDrawProcedureBase
	[in]	location = MHardwareRenderer.CallLocation


Add a drawing procedure to the renderer.'''
        pass

    def glFunctionTable(self): 
        '''glFunctionTable(self) -> MGLFunctionTable


Get a pointer to a OpenGL function table class.'''
        pass

    def removeDrawProcedure(self, backEndString, drawProcedurePtr, location): 
        '''removeDrawProcedure(self, backEndString, drawProcedurePtr, location) -> MHardwareRenderer.DrawProcedureStatusCode
Returns: DrawProcedureStatusCode : kSuccess, kFailure, kItemNotFound, or kLocationNotFound. if item cannot be found. 

Arguments:
	[in]	backEndString = MString
	[in]	drawProcedurePtr = MDrawProcedureBase
	[in]	location = MHardwareRenderer.CallLocation


Remove a drawing procedure to the renderer. The procedure to remove is searched for based on procedure name. If a procedure with the given name is not found then an appropriate error code will be returned (kItemNotFound).'''
        pass

    def makeResourceContextCurrent(self, backEndString): 
        '''makeResourceContextCurrent(self, backEndString)
Arguments:
	[in]	backEndString = MString


Make the hardware renderer's "resource context" current. The "resource context" is used by the hardware renderer for sharing drawing resources such as hardware textures, geometry and shader programs. In fact all resources in the resource context are shared by all other Maya defined 3d contexts.'''
        pass

    def getDrawProcedureListNames(self, backEndString, location, namesOfProcs): 
        '''getDrawProcedureListNames(self, backEndString, location, namesOfProcs) -> MHardwareRenderer.DrawProcedureStatusCode

Arguments:
	[in]	backEndString = MString
	[in]	location = MHardwareRenderer.CallLocation
	[in]	namesOfProcs = MStringArray


Get the names of drawing procedures for a given procedure list at a given render location.'''
        pass

    def insertDrawProcedure(self, backEndString, drawProcedurePtr, location, listIndex, moveExistingItem): 
        '''insertDrawProcedure(self, backEndString, drawProcedurePtr, location, listIndex, moveExistingItem) -> MHardwareRenderer.DrawProcedureStatusCode
Returns: DrawProcedureStatusCode : kSuccess, kFailure, kItemExists, or kLocationNotFound. if item already exists. 

Arguments:
	[in]	backEndString = MString
	[in]	drawProcedurePtr = MDrawProcedureBase
	[in]	location = MHardwareRenderer.CallLocation
	[in]	listIndex = int
	[in]	moveExistingItem = bool


Insert a drawing procedure to a list of procedures at a specific index location in the list.'''
        pass

class MHwrCallback:
    '''Rendering Callbacks. This class is used to register callbacks to gain access to Maya's Hardware Rendering device status. You can be notified of device creation, lost reset and deletion.To register callbacks, inherit from this class and override deviceNew, deviceLost, deviceReset, deviceDeleted. Any number of these methods can be overridden by the callback. Then register the callbacks by calling the addCallback() method.If multiple callbacks need to be registered, the order of invocation can be set by adding each callback with a priority number, 0 being the highest priority. '''
    def __init__(self):
        pass


    def deviceLost(self): 
        '''deviceLost(self)

Method to override for being notified of device Lost. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp , and  hlslShader.h . 
 
'''
        pass

    def deviceReset(self): 
        '''deviceReset(self)

Method to override for being notified of device Reset. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.h . 
 
'''
        pass

    def deviceNew(self): 
        '''deviceNew(self)

Method to override for being notified of new device creation 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp , and  hlslShader.h . 
 
'''
        pass

    def addCallback(self, callback, priority): 
        '''addCallback(self, callback, priority)
Arguments:
	[in]	callback = MHwrCallback
	[in]	priority = int


Static procedure to add a rendering callback. The callbacks are stored internally in a sorted list and are invoked following the appropriate device state change depending on which methods are overridden. Adding the same callback more than once will have no effect.'''
        pass

    def deviceDeleted(self): 
        '''deviceDeleted(self)

Method to override for being notified of device Deletion. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp , and  hlslShader.h . 
 
'''
        pass

    def removeCallback(self, callback): 
        '''removeCallback(self, callback)
Arguments:
	[in]	callback = MHwrCallback


Static procedure to remove a rendering callback. The callback will be removed from the list of callbacks, but its up to the client to actually delete the object. Unstability may result if a callback is deleted and not removed from the callback list.Removing an un-installed callback will have no effect.'''
        pass

class MHwTextureManager:
    '''Hardware Texture management. The MHwTextureManager provides an interface for loading and using hardware textures. '''
    def __init__(self):
        pass


    def deregisterTextureFile(self, hTexture): 
        '''deregisterTextureFile(self, hTexture)
Arguments:
	[in]	hTexture = MHwTextureManager.MHwTextureFileHandle


Deregisters the given handle to a texture entry in the manager. If there are no other handles to this texture entry, the texture resource will be freed.'''
        pass

    def registerTextureFile(self, fileName, hTexture): 
        '''registerTextureFile(self, fileName, hTexture)
Arguments:
	[in]	fileName = MString
	[out]	hTexture = MHwTextureManager.MHwTextureFileHandle


Register a named texture file. Returns a handle to a texture entry in the texture manager. The caller is responsible for calling the associated deregisterTextureFile to avoid leaking memory.'''
        pass

    def glBind(self, hTexture, targetType, imageType): 
        '''glBind(self, hTexture, targetType, imageType)
Arguments:
	[in]	hTexture = MHwTextureManager.MHwTextureFileHandle
	[in]	targetType = MImageFileInfo.MHwTextureType
	[in]	imageType = MImageFileInfo.MImageType


Bind the contents of a specific file to the currently active OpenGL texture unit. As part of this operation, the texture target will also be enabled (i.e. there is no need to call glEnable( targetType) before or after calling this method).'''
        pass

    def textureFile(self, hTexture, fileName): 
        '''textureFile(self, hTexture, fileName)
Arguments:
	[in]	hTexture = MHwTextureManager.MHwTextureFileHandle
	[in]	fileName = MString


Return the file name associated with a given texture file handle.'''
        pass

class MLightLinks:
    '''Class providing read-only Light Linking API functions. This class provides read-only access to the light linking information expressed in Maya's light linker nodes.To extract Maya's light linking information, use the following sequence of calls:Lights can be linked either to DAG hierarchies or to shading groups. Additionnally, light linking information can store a list of illuminating lights and a list excluded lights. The algorithm used to determine which light should contribute can be described by the pseudo code below.for each face group on the object, corresponding to each shading engine, do the following:For the given face group, the set of lights illuminating it are then (ObjectLink - FaceIgnore) + (FaceLink - ObjectIgnore).It is important to note that component linking works at the granularity of a shading group on a surface. In order to get results from the MLightLinks API, it is necessary to pass in components that correspond exactly to all the faces on that object in a particular shading group. For example, if pPlaneShape1.f[0:10] belongs to a shading group which is linked to a given light, then there will be no result from MLightLinks::getLinkedLights() if the argument is set to pPlaneShape1.f[0], or pPlaneShape1.f[0:5], or pPlaneShape1.f[10], etc - it must be exactly pPlaneShape1.f[0:10]. '''
    def __init__(self):
        pass


    def getIgnoredLights(self, objectPath, objectComponent, ignoredLights): 
        '''getIgnoredLights(self, objectPath, objectComponent, ignoredLights)
Arguments:
	[in]	objectPath = MDagPath
	[in]	objectComponent = MObject
	[out]	ignoredLights = MDagPathArray


Queries the light link table to find the lights that ignores a particular object or object component.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def parseLinks(self, linkNode, verbose, stream, useIgnore, componentSupport): 
        '''parseLinks(self, linkNode, verbose, stream, useIgnore, componentSupport)
Arguments:
	[in]	linkNode = MObject
	[in]	verbose = bool
	[in]	stream = std.ostream
	[in]	useIgnore = bool
	[in]	componentSupport = bool


Compiles the information contained in a light linker node into a table of object/light links. The  getLinkedLights()  and  getLinkedObjects()  methods are used to query this table.'''
        pass

    def getLinkedLights(self, objectPath, objectComponent, linkedLights): 
        '''getLinkedLights(self, objectPath, objectComponent, linkedLights)
Arguments:
	[in]	objectPath = MDagPath
	[in]	objectComponent = MObject
	[out]	linkedLights = MDagPathArray


Queries the light link table to find the lights that are linked to a particular object or object component.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getIgnoredObjects(self, lightPath, ignoredObjects): 
        '''getIgnoredObjects(self, lightPath, ignoredObjects)
Arguments:
	[in]	lightPath = MDagPath
	[out]	ignoredObjects = MSelectionList


Queries the light link table to find the objects or object components that are ignored to a particular light.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getLinkedObjects(self, lightPath, linkedObjects): 
        '''getLinkedObjects(self, lightPath, linkedObjects)
Arguments:
	[in]	lightPath = MDagPath
	[out]	linkedObjects = MSelectionList


Queries the light link table to find the objects or object components that are linked to a particular light.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getShadowLinkedObjects(self, lightPath, linkedObjects): 
        '''getShadowLinkedObjects(self, lightPath, linkedObjects)
Arguments:
	[in]	lightPath = MDagPath
	[out]	linkedObjects = MSelectionList


Queries the light link table to find the objects or object components that are shadow linked to a particular light.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getShadowLinkedLights(self, objectPath, objectComponent, linkedLights): 
        '''getShadowLinkedLights(self, objectPath, objectComponent, linkedLights)
Arguments:
	[in]	objectPath = MDagPath
	[in]	objectComponent = MObject
	[out]	linkedLights = MDagPathArray


Queries the light link table to find the lights that are shadow linked to a particular object or object component.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getShadowIgnoredLights(self, objectPath, objectComponent, ignoredLights): 
        '''getShadowIgnoredLights(self, objectPath, objectComponent, ignoredLights)
Arguments:
	[in]	objectPath = MDagPath
	[in]	objectComponent = MObject
	[out]	ignoredLights = MDagPathArray


Queries the light link table to find the lights that ignore a particular object or object component when casting shadows. This is referred to as shadow ignoring the objects.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

    def getShadowIgnoredObjects(self, lightPath, ignoredObjects): 
        '''getShadowIgnoredObjects(self, lightPath, ignoredObjects)
Arguments:
	[in]	lightPath = MDagPath
	[out]	ignoredObjects = MSelectionList


Queries the light link table to find the objects or object components that are ignored to a particular light when calculating shadows. These are referred to as shadow ignored objects.  parseLinks()  must have been called at some point to generate the table that is being queried.'''
        pass

class MRenderingInfo:
    '''Information to perform rendering into a hardware render target. MRenderingInfo is a class which holds information about rendering into hardware render targets. '''
    def __init__(self):
        pass


    def renderingAPI(self): 
        '''renderingAPI(self) -> MViewportRenderer.RenderingAPI


Native target rendering API. 
'''
        pass

    def MRenderTarget(self): 
        '''MRenderTarget(self) -> const


Current render target. 
'''
        pass

    def MMatrix(self): 
        '''MMatrix(self) -> const


Current projection matrix. 
'''
        pass

    def originY(self): 
        '''originY(self) -> int


Origin (y) of region to render to in pixels. 
'''
        pass

    def originX(self): 
        '''originX(self) -> int


Origin (x) of region to render to in pixels. 
'''
        pass

    def height(self): 
        '''height(self) -> int


Height of region to render in pixels. 
'''
        pass

    def width(self): 
        '''width(self) -> int


Width of region to render in pixels. 
'''
        pass

    def MDagPath(self): 
        '''MDagPath(self) -> const


Current camera being used to render with. 
'''
        pass

    def renderingVersion(self): 
        '''renderingVersion(self) -> float


Native target rendering version. 
'''
        pass

class MRenderCallback:
    '''Rendering Callbacks. This class is used to register callbacks to gain access to Maya's rendering information during software rendering. You can modify Maya's shadow maps, RGB pixmap, and depth map to composite your own rendering effects into Maya's rendering.To register callbacks, inherit from this class and override renderCallback(), shadowCastCallback(), or postProcessCallback(). Any number of these methods can be overridden by the callback. Then register the callbacks by calling the addCallback() method.Each of the callback method gets passed a MRenderData which contains the information. MRenderData also provides utility methods for converting between world space and screen space. In the case of shadowCastCallback, MRenderShadowData is provided and it also has utility methods for converting between world space and shadow map space.If there are callbacks registered, prior to shadow maps being written out, shadowCastCallback() will be invoked with light information and a pointer to the shadow map passed in. Then immediately after software rendering completes, renderCallback() will be invoked with the rendering's dimension info and image passed in. Lastly, during post-processing, postProcessCallback() will be invoked with the rendering's dimension and pointers to the rgb pixmap and depthmap passed in.If multiple callbacks need to be registered, the order of invocation can be set by adding each callback with a priority number, 0 being the highest priority. '''
    def __init__(self):
        pass


    def addCallback(self, callback, priority): 
        '''addCallback(self, callback, priority)
Arguments:
	[in]	callback = MRenderCallback
	[in]	priority = int


Static procedure to add a rendering callback. The callbacks are stored internally in a sorted list and are invoked following the shadow map generation, software render, or post process depending on which methods are overridden. Adding the same callback more than once will have no effect.'''
        pass

    def postProcessCallback(self, data): 
        '''postProcessCallback(self, data) -> bool
Returns: True if the operation was successful and false otherwise. 

Arguments:
	[in]	data = MRenderData


Method to override for plugging into the post-process. This method will be invoked following the post process rendering (shader glow, optical effects, 2D motion blur). The data argument provides information about the image and camera projection; these are useful in transforming to and from world and image space. If false is returned, the renderer will abort and no image will be generated.'''
        pass

    def removeCallback(self, callback): 
        '''removeCallback(self, callback)
Arguments:
	[in]	callback = MRenderCallback


Static procedure to remove a rendering callback. The callback will be removed from the list of callbacks, but its up to the client to actually delete the object. Unstability may result if a callback is deleted and not removed from the callback list.Removing an un-installed callback will have no effect.'''
        pass

    def shadowCastCallback(self, data): 
        '''shadowCastCallback(self, data) -> bool
Returns: True if the operation was successful and false otherwise. 

Arguments:
	[in]	data = MRenderShadowData


Method to override for plugging into shadow map creation. The argument provides information about the light and shadow map currently being processed. If false is returned, the renderer will abort and no image will be generated.'''
        pass

    def renderCallback(self, data): 
        '''renderCallback(self, data) -> bool
Returns: True if the operation was successful and false otherwise. 

Arguments:
	[in]	data = MRenderData


Method to override for plugging into image rendering. This method will be invoked following the software render (but before the post process) of each frame. The data argument provides information about the image and camera projection; these are useful in transforming to and from world and image space. If false is returned, the renderer will abort and no image will be generated.'''
        pass

class MRenderData:
    '''Access Rendering Data. The rendered image and depth map can be changed following the software render by instanciating a MRenderCallback and overriding renderCallback() or postProcessCallback(). When these methods are invoked, a MRenderData is passed as an argument; the rgbaArr and depthArr can then be changed by this API. Methods and data are provided to assist in transforming back and forth from world space to image space. Paint Effects and Fur are two examples which use this mechanism to change the rendered image. '''
    def __init__(self):
        pass


    def rgbaArr(self): 
        '''rgbaArr(self) -> unsigned char*


this is a 1d array representing the output image buffer. It is of size: resX * resY * 4 * bytesPerChannel. The array is indexed as [(resX * x + y) * 4 * bytesPerChannel], where (x,y) is the current pixel coordinates. The "4" multiplier is used for storing RGBA information, in the order of a,b,g,r (on OSX) or b,g,r,a (on Windows and Linux). 
  Reprocessed example  
 Examples: 
 
   
 renderAccessNode.cpp . 
 
'''
        pass

    def depthArr(self): 
        '''depthArr(self) -> float*


this is a 1d array representing the output depth buffer. It is of size: resX * resY, where each depth value is a single precision floating point vlue. It is indexed as [resX * x + y], where (x,y) is the current pixel coordinates. 
  Reprocessed example  
 Examples: 
 
   
 renderAccessNode.cpp . 
 
'''
        pass

    def screenToWorld(self, inPoint, outPoint): 
        '''screenToWorld(self, inPoint, outPoint)
Arguments:
	[in]	inPoint = MFloatPoint
	[out]	outPoint = MFloatPoint


Converts screen space point to world space. Screen depth is stored in inPoint.z.'''
        pass

    def worldToScreen(self, inPoint, outPoint): 
        '''worldToScreen(self, inPoint, outPoint)
Arguments:
	[in]	inPoint = MFloatPoint
	[out]	outPoint = MFloatPoint


Converts world space point to screen space. Screen depth is stored in outPoint.z.'''
        pass

class MRenderPassDef:
    '''Render pass information. This class provides a means to access information about a specific render pass. Initialize by passing to MRenderPassRegistry::getRenderPassDefinition(), or by calling create() to generate and register a new pass. '''
    def __init__(self):
        pass


    def addFloatParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue): 
        '''addFloatParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue)
Arguments:
	[in]	longName = MString
	[in]	shortName = MString
	[in]	UIName = MString
	[in]	minValue = float
	[in]	maxValue = float
	[in]	defaultValue = float


Define a single-precision floating-point parameter for the pass'''
        pass

    def getName(self): 
        '''getName(self) -> MString
Returns: The pass name


Retrieve the pass name for this pass'''
        pass

    def getDescription(self): 
        '''getDescription(self) -> MString
Returns: The description


Retrieve the description for this pass'''
        pass

    def getID(self): 
        '''getID(self) -> MString
Returns: The pass ID


Retrieve the pass ID for this pass.'''
        pass

    def addDoubleParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue): 
        '''addDoubleParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue)
Arguments:
	[in]	longName = MString
	[in]	shortName = MString
	[in]	UIName = MString
	[in]	minValue = double
	[in]	maxValue = double
	[in]	defaultValue = double


Define a double-precision floating-point parameter for the pass'''
        pass

    def getImplementation(self, renderer): 
        '''getImplementation(self, renderer) -> MPxRenderPassImpl
Returns: A pointer to the pass implementation or null if no definition exists

Arguments:
	[in]	renderer = MString


Retrieve an implementation of this render pass for the given renderer.'''
        pass

    def getAttributeType(self, attributeName): 
        '''getAttributeType(self, attributeName) -> MString

Arguments:
	[in]	attributeName = MString


Retrieve the type of a given render pass attribute'''
        pass

    def getGroup(self): 
        '''getGroup(self) -> MString
Returns: The pass group


Retrieve the pass group for this pass'''
        pass

    def addIntParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue): 
        '''addIntParameter(self, longName, shortName, UIName, minValue, maxValue, defaultValue)
Arguments:
	[in]	longName = MString
	[in]	shortName = MString
	[in]	UIName = MString
	[in]	minValue = int
	[in]	maxValue = int
	[in]	defaultValue = int


Define an integer parameter for the pass'''
        pass

class MRenderPassRegistry:
    '''Access the render pass registry. This class provides a means to register custom render pass definitions with Maya's internal render pass registry. It can also be used to query pass definitions. '''
    def __init__(self):
        pass


    def registerRenderPassDefinition(self, passID, passName, passGroup, description, overload): 
        '''registerRenderPassDefinition(self, passID, passName, passGroup, description, overload) -> MRenderPassDef
Returns: The render pass definition if successful

Arguments:
	[in]	passID = MString
	[in]	passName = MString
	[in]	passGroup = MString
	[in]	description = MString
	[in]	overload = bool


Creates a new render pass definition and registers it with the internal render pass registry. Returns the definition.'''
        pass

    def getRenderPassDefinition(self, passID): 
        '''getRenderPassDefinition(self, passID) -> MRenderPassDef

Arguments:
	[in]	passID = MString


Retrieve the definition of the specified render pass'''
        pass

class MRenderProfile:
    '''Render profile. The MRenderProfile class describes the rendering APIs and algorithms supported by a given rendering entity (e.g. a shading node, a renderer). A single profile can contain multiple entries allowing, for example, a shading node to specify that it supports both OpenGL and Direct3D rendering. The profile entries refer to renderers rather than rendering APIs as the rendering elements may depend on specific services, information or algorithms implemented by the renderer (e.g. a global light table, or render state cache). '''
    def __init__(self):
        pass


    def numberOfRenderers(self): 
        '''numberOfRenderers(self) -> int


Find the number of renderers in this profile.'''
        pass

    def hasRenderer(self, name, version): 
        '''hasRenderer(self, name, version) -> bool

Arguments:
	[in]	name = MString
	[in]	version = float


Find a custom entry in this render profile.'''
        pass

    def kMayaD3D(self):
        '''This is an enum of MStandardRenderer.
Description: 
Value: 2'''
        pass

    def kMayaSoftware(self):
        '''This is an enum of MStandardRenderer.
Description: 
Value: 0'''
        pass

    def kMayaOpenGL(self):
        '''This is an enum of MStandardRenderer.
Description: 
Value: 1'''
        pass

    class MStandardRenderer:
        '''Non-functional class.  Values for this enum:
        kMayaD3D
        kMayaSoftware
        kMayaOpenGL
'''
        def __init__(self):
            pass

    def addRenderer(self, name, version): 
        '''addRenderer(self, name, version)
Arguments:
	[in]	name = MString
	[in]	version = float


Add a custom entry to this render profile. The name and version specified must correspond to a renderer registered with Maya. Currently, only Maya's internal renderers (just named after the APIs they use: "OpenGL", "D3D", or "Software") are supported. When registering support for Maya's internal renderers, it's simpler to use the other version of this method.'''
        pass

class MRenderShadowData:
    '''Access Rendering Shadow Map Data. The shadow map can be changed by instanciating a MRenderCallback and overriding shadowCastCallback(). When this is invoked, a MRenderShadowData is passed as an argument; the depthMaps and midDistMaps members can then be changed by this API. Methods and data are provided to assist in transforming back and forth from world space to z buffer space. Paint Effects and Fur are two examples which use this mechanism to change the shadow map.To prevent self shadowing, Maya uses a mid distance map to resolve the ambiguity. Details of this technique can be obtained from Graphics Gems III, "The Shadow Depth Map Revisited". '''
    def __init__(self):
        pass


    def zbufferToWorld(self, inPoint, outPoint): 
        '''zbufferToWorld(self, inPoint, outPoint)
Arguments:
	[in]	inPoint = MFloatPoint
	[out]	outPoint = MFloatPoint


Converts shadow map point to world space. Shadow depth is stored in inPoint.z.'''
        pass

    def kPoint(self):
        '''This is an enum of LightType.
Description: 
Value: 1'''
        pass

    def kInvalid(self):
        '''This is an enum of LightType.
Description: 
Value: 0'''
        pass

    def kDirectional(self):
        '''This is an enum of LightType.
Description: 
Value: 2'''
        pass

    def kSpot(self):
        '''This is an enum of LightType.
Description: 
Value: 3'''
        pass

    class LightType:
        '''Non-functional class.  Values for this enum:
        kPoint
        kInvalid
        kDirectional
        kSpot
'''
        def __init__(self):
            pass

    def worldToZbuffer(self, inPoint, outPoint): 
        '''worldToZbuffer(self, inPoint, outPoint)
Arguments:
	[in]	inPoint = MFloatPoint
	[out]	outPoint = MFloatPoint


Converts world space point to shadow map. Shadow depth is stored in inPoint.z'''
        pass

class MRenderTarget:
    '''Information to perform rendering into a hardware render target. MRenderTarget is a class contains information about a given hardware render target. '''
    def __init__(self):
        pass


    def writeColorBuffer(self, image, x, y, writeDepth): 
        '''writeColorBuffer(self, image, x, y, writeDepth)
Arguments:
	[in]	image = MImage
	[in]	x = signed
	[in]	y = signed
	[in]	writeDepth = bool


Write a 2d image directly to the color buffer, without any transformation. Method will make the context current if it is not already.'''
        pass

    def width(self): 
        '''width(self) -> int


Width of render target in pixels. 
'''
        pass

    def makeTargetCurrent(self): 
        '''makeTargetCurrent(self)
'''
        pass

    def height(self): 
        '''height(self) -> int


Height of render target in pixels. 
'''
        pass

class MRenderUtil:
    '''Common API rendering functions. MRenderUtil is a class which provides static API methods to access Maya's rendering functionalities. '''
    def __init__(self):
        pass


    def kAmbientOnly(self):
        '''This is an enum of MRenderPass.
Description: Compute only ambient information.
Value: 3'''
        pass

    def kAll(self):
        '''This is an enum of MRenderPass.
Description: Default case, compute everything.
Value: 0'''
        pass

    def kColorOnly(self):
        '''This is an enum of MRenderPass.
Description: Compute only color information, no shadows.
Value: 1'''
        pass

    def kShadowOnly(self):
        '''This is an enum of MRenderPass.
Description: Compute only shadow information, no color.
Value: 2'''
        pass

    def kSpecularOnly(self):
        '''This is an enum of MRenderPass.
Description: Compute only specular information.
Value: 5'''
        pass

    def kDiffuseOnly(self):
        '''This is an enum of MRenderPass.
Description: Compute only diffuse information.
Value: 4'''
        pass

    class MRenderPass:
        '''Non-functional class.  Values for this enum:
        kAmbientOnly
        kAll
        kColorOnly
        kShadowOnly
        kSpecularOnly
        kDiffuseOnly
'''
        def __init__(self):
            pass

    def inCurrentRenderLayer(self, objectPath): 
        '''inCurrentRenderLayer(self, objectPath) -> bool
Returns: true if the object is in the current render layer.

Arguments:
	[in]	objectPath = MDagPath


Returns true if the specified path is in the current render layer.'''
        pass

    def raytrace(self, rayOrigins, rayDirections, notUsed, raySampler, rayDepth, isReflectedRays, resultColors, resultTransparencies): 
        '''raytrace(self, rayOrigins, rayDirections, notUsed, raySampler, rayDepth, isReflectedRays, resultColors, resultTransparencies)
Arguments:
	[in]	rayOrigins = MFloatVectorArray
	[in]	rayDirections = MFloatVectorArray
	[in]	notUsed = void
	[in]	raySampler = void
	[in]	rayDepth = short
	[out]	resultColors = MFloatVectorArray
	[out]	resultTransparencies = MFloatVectorArray
	[in]	isReflectedRays = bool


This utility method provides functionality to raytrace from within a shader plug-in.'''
        pass

    def generatingIprFile(self): 
        '''generatingIprFile(self) -> bool


Returns true if an IPR file is being created. This can be used to optimize the IPR file. Lights do not need to request particle information (IPR does not support particle rendering) when creating a IPR file.'''
        pass

    def sampleShadingNetwork(self, shadingNodeName, numSamples, useShadowMaps, reuseMaps, cameraMatrix, points, uCoords, vCoords, normals, refPoints, tangentUs, tangentVs, filterSizes, resultColors, resultTransparencies): 
        '''sampleShadingNetwork(self, shadingNodeName, numSamples, useShadowMaps, reuseMaps, cameraMatrix, points, uCoords, vCoords, normals, refPoints, tangentUs, tangentVs, filterSizes, resultColors, resultTransparencies)
Arguments:
	[in]	shadingNodeName = MString
	[in]	numSamples = int
	[in]	useShadowMaps = bool
	[in]	reuseMaps = bool
	[in]	cameraMatrix = MFloatMatrix
	[in]	points = MFloatPointArray
	[in]	uCoords = MFloatArray
	[in]	vCoords = MFloatArray
	[in]	normals = MFloatVectorArray
	[in]	refPoints = MFloatPointArray
	[in]	tangentUs = MFloatVectorArray
	[in]	tangentVs = MFloatVectorArray
	[in]	filterSizes = MFloatArray
	[out]	resultColors = MFloatVectorArray
	[out]	resultTransparencies = MFloatVectorArray


This utility method allows you to sample a shading node/shading engine. You can specify the location and property of the sample point, and the method will return the result color and transparency. If you are sampling a shading engine, and there are lights in the scene, you can optionally request shadows to be computed as well.'''
        pass

    def relativeFileName(self, absFileName): 
        '''relativeFileName(self, absFileName) -> MString
Returns: file name without the project path

Arguments:
	[in]	absFileName = MString


Extract relative file name from the given (absolute) file name. If the given file name does not begin with a project root, return value is same as the input file name.'''
        pass

    def mainBeautyPassCustomTokenString(self): 
        '''mainBeautyPassCustomTokenString(self) -> MString


Returns the custom token string of the main beauty pass for use by renderers in file naming.'''
        pass

    def getCommonRenderSettings(self, mrgData): 
        '''getCommonRenderSettings(self, mrgData)
Arguments:
	[out]	mrgData = MCommonRenderSettingsData

'''
        pass

    def renderObjectItem(self, objectId, item): 
        '''renderObjectItem(self, objectId, item)
Arguments:
	[in]	objectId = void
	[in]	item = MSelectionList


Procedure to look up a selection item for a given sample object id. This is only guaranteed to work when software rendering. As multiple processors may be used when software rendering; a critical section should be used to protect multiple threads from simulaneously performing DG evaluation. This includes querying attribute values.'''
        pass

    def raytraceFirstGeometryIntersections(self, rayOrigins, rayDirections, notUsed, raySampler, resultIntersections, resultIntersected): 
        '''raytraceFirstGeometryIntersections(self, rayOrigins, rayDirections, notUsed, raySampler, resultIntersections, resultIntersected)
Arguments:
	[in]	rayOrigins = MFloatVectorArray
	[in]	rayDirections = MFloatVectorArray
	[in]	notUsed = void
	[in]	raySampler = void
	[out]	resultIntersections = MFloatVectorArray
	[out]	resultIntersected = MIntArray


This utility method provides functionality to find the location of the first geometry intersected by a ray from within a shader plug-in.'''
        pass

    def mainBeautyPassName(self): 
        '''mainBeautyPassName(self) -> MString


Returns the name of the main beauty pass for use by renderers for token substitution.'''
        pass

    def maximumSpecularReflection(self, lightBlindData, lightDirection, pointCamera, normal, rayDirection): 
        '''maximumSpecularReflection(self, lightBlindData, lightDirection, pointCamera, normal, rayDirection) -> MFloatVector

Arguments:
	[in]	lightBlindData = void
	[in]	lightDirection = MFloatVector
	[in]	pointCamera = MFloatVector
	[in]	normal = MFloatVector
	[in]	rayDirection = MFloatVector


This utility function computes and returns the vector corresponding to the point on the light source that provides the maximum specular reflection.'''
        pass

    def hemisphereCoverage(self, lightBlindData, lightDirection, pointCamera, rayDirection, lightBackFace): 
        '''hemisphereCoverage(self, lightBlindData, lightDirection, pointCamera, rayDirection, lightBackFace) -> float

Arguments:
	[in]	lightBlindData = void
	[in]	lightDirection = MFloatVector
	[in]	pointCamera = MFloatVector
	[in]	rayDirection = MFloatVector
	[in]	lightBackFace = bool


This utility function computes and returns the fraction of the light that is transmitted by an object. It is mostly used for translucence and scattering effects.'''
        pass

    def diffuseReflectance(self, lightBlindData, lightDirection, pointCamera, normal, lightBackFace): 
        '''diffuseReflectance(self, lightBlindData, lightDirection, pointCamera, normal, lightBackFace) -> float

Arguments:
	[in]	lightBlindData = void
	[in]	lightDirection = MFloatVector
	[in]	pointCamera = MFloatVector
	[in]	normal = MFloatVector
	[in]	lightBackFace = bool


This utility function computes and returns the diffuse or lambertian reflectance for a given light source and surface.'''
        pass

    def kHardwareRender(self):
        '''This is an enum of MRenderState.
Description: Performing a hardware render.
Value: 4'''
        pass

    def kInteractiveRender(self):
        '''This is an enum of MRenderState.
Description: Performing an interactive render.
Value: 2'''
        pass

    def kIprRender(self):
        '''This is an enum of MRenderState.
Description: Performing an IPR render.
Value: 3'''
        pass

    def kBatchRender(self):
        '''This is an enum of MRenderState.
Description: Performing a batch render.
Value: 1'''
        pass

    def kNotRendering(self):
        '''This is an enum of MRenderState.
Description: Not rendering.
Value: 0'''
        pass

    class MRenderState:
        '''Non-functional class.  Values for this enum:
        kHardwareRender
        kInteractiveRender
        kIprRender
        kBatchRender
        kNotRendering
'''
        def __init__(self):
            pass

    def sendRenderProgressInfo(self, pixFile, percentageDone): 
        '''sendRenderProgressInfo(self, pixFile, percentageDone)
Arguments:
	[in]	pixFile = MString
	[in]	percentageDone = int


This utility function sends batch rendering status to Maya'''
        pass

    def exactFileTextureName(self, baseName, useFrameExt, currentFrameExt): 
        '''exactFileTextureName(self, baseName, useFrameExt, currentFrameExt) -> MString
Returns: true if the file pathname was successfully resolved. 
false if the pathname could not be resolved.

Arguments:
	[in]	baseName = MString
	[in]	useFrameExt = bool
	[in]	currentFrameExt = MString


Attempts to resolve the file name specified into an absolute path to a file on disk. The function applies exactly the same logic that is used by the file texture node internally for resolving the image file path.'''
        pass

    def convertPsdFile(self, fileNode, state): 
        '''convertPsdFile(self, fileNode, state) -> MString

Arguments:
	[in]	fileNode = MObject
	[in]	state = bool


Internal use only. 
'''
        pass

    def exactImagePlaneFileName(self, imagePlaneNode): 
        '''exactImagePlaneFileName(self, imagePlaneNode) -> MString
Returns: An absolute pathname to the texture file referenced by the node. If the pathname cannot be resolved, then the returned string is empty

Arguments:
	[in]	imagePlaneNode = MObject


Attempts to resolve the file texture name specified on an image plane node into an absolute path to an image file on disk. The function applies exactly the same logic that is used by the image plane node internally for resolving the image file path.'''
        pass

    def mayaRenderState(self): 
        '''mayaRenderState(self) -> MRenderUtil.MRenderState


Returns an enumerated type specifying the current state of the Maya renderer.'''
        pass

    def renderPass(self): 
        '''renderPass(self) -> MRenderUtil.MRenderPass


Returns an enumerated type specifying the current pass the Maya renderer is executing.'''
        pass

    def lightAttenuation(self, lightBlindData, pointCamera, normal, lightBackFace): 
        '''lightAttenuation(self, lightBlindData, pointCamera, normal, lightBackFace) -> float

Arguments:
	[in]	lightBlindData = void
	[in]	pointCamera = MFloatVector
	[in]	normal = MFloatVector
	[in]	lightBackFace = bool


This utility function computes and returns light attentuation factor of a light. Note that the result of 1 will be returned if the light being evaluated does not support light attentuation.'''
        pass

class MRenderView:
    '''Static class providing Render View API functions. This class provides access to the Maya Render View. The class allows plugins to send image data to the Render View in the same way that the Maya renderer does. Either a "full render" or a "region render" can be performed. In a full render, the Render View expects to receive pixel data that fills the entire image, while a region render expects only updates to a specified image region.To send an image to the Render View, use the following sequence of calls:'''
    def __init__(self):
        pass


    def startRegionRender(self, imageWidth, imageHeight, regionLeft, regionRight, regionBottom, regionTop, doNotClearBackground, immediateFeedback): 
        '''startRegionRender(self, imageWidth, imageHeight, regionLeft, regionRight, regionBottom, regionTop, doNotClearBackground, immediateFeedback)
Arguments:
	[in]	imageWidth = int
	[in]	imageHeight = int
	[in]	regionLeft = int
	[in]	regionRight = int
	[in]	regionBottom = int
	[in]	regionTop = int
	[in]	doNotClearBackground = bool
	[in]	immediateFeedback = bool


Informs the Render View that a region render is about to begin. The specified region will be cleared in anticipation of receiving new image data for it. The specified region must lie within the image region (0,0)->(imageWidth-1,imageHeight-1). The region 'left' coordinate must be less than the region 'right' coordinate, and the region 'bottom' coordinate must be less than the region 'top' coordinate.'''
        pass

    def endRender(self): 
        '''endRender(self)

Informs the Render View that the current render has completed. The Render View is refreshed and no further updates are accepted.'''
        pass

    def refresh(self, left, right, bottom, top): 
        '''refresh(self, left, right, bottom, top)
Arguments:
	[in]	left = int
	[in]	right = int
	[in]	bottom = int
	[in]	top = int


Requests that the Render View refresh the display of a particular region of the displayed image.'''
        pass

    def getRenderRegion(self, left, right, bottom, top): 
        '''getRenderRegion(self, left, right, bottom, top)
Arguments:
	[out]	left = int
	[out]	right = int
	[out]	bottom = int
	[out]	top = int


Retrieves the currently selected Render Region in Maya's Render View. The region extends from the bottom-left corner (left,bottom) to the upper-right corner (right,top) inclusive (i.e. the row y=top and column x=right are part of the region).'''
        pass

    def doesRenderEditorExist(self): 
        '''doesRenderEditorExist(self) -> bool


Determines whether or not a Render View exists to receive image data. If this function returns false, then Maya is currently running in batch mode, so it would be pointless to try to send data to the Render View.'''
        pass

    def updatePixels(self, left, right, bottom, top, pPixels): 
        '''updatePixels(self, left, right, bottom, top, pPixels)
Arguments:
	[in]	left = int
	[in]	right = int
	[in]	bottom = int
	[in]	top = int
	[in]	pPixels = RV_PIXEL


Sends a block of pixels to the Render View. Pixel colours are represented as 4-channel floating point values in the range (0,255.0).'''
        pass

    def setCurrentCamera(self, currentCamera): 
        '''setCurrentCamera(self, currentCamera)
Arguments:
	[in]	currentCamera = MDagPath


Informs the render client of the camera that will be performing the rendering.'''
        pass

    def startRender(self, width, height, doNotClearBackground, immediateFeedback): 
        '''startRender(self, width, height, doNotClearBackground, immediateFeedback)
Arguments:
	[in]	width = int
	[in]	height = int
	[in]	doNotClearBackground = bool
	[in]	immediateFeedback = bool


Informs the Render View that a full image render is about to begin. The entire Render View buffer will be cleared in anticipation of receiving an entire image.'''
        pass

class MSwatchRenderBase:
    '''Swatch Render Base class. A class providing an interface through which a plugin can implement a class to provide custom rendered images for swatches which are displayed in hypershade and the Attribute Editor.By deriving from this class and implementing the doIteration function, swatches for nodes (having the required classification) can be custom rendered by the plugin.The derived class needs to be registered with Maya using the interface provided by MSwatchRenderRegister. Please refer to documentation of MSwatchRenderRegister for more details.To indicate that swatch for a certain node type will be generated by the plugin the classfication string of the node needs to contain the following string : "swatch/<swatch generator name>" The swatch generator name string should match the name used to register the swatch generator class. '''
    def __init__(self):
        pass


    def node(self): 
        '''node(self) -> MObject

'''
        pass

    def swatchNode(self): 
        '''swatchNode(self) -> MObject

'''
        pass

    def doIteration(self): 
        '''doIteration(self) -> bool


Method called to do swatch image generation, derived classes needs to implement this.'''
        pass

    def resolution(self): 
        '''resolution(self) -> int

'''
        pass

    def image(self): 
        '''image(self) -> MImage

'''
        pass

class MSwatchRenderRegister:
    '''Manages swatch generators. Provides an interface for plugins to register/unregister swatch generator classes (derived from MSwatchRenderBase) with Maya. Whenever a swatch needs to be generated for a node, it checks the classfication string of the node for the preferred swatch generator. If a match is found, it creates and manages the swatch generator object (that is it deletes the swatch generator object once the image has been generated). The doIteration function is called for generating the swatch. The doIteration function is called repeatedly (during idle events) till it returns true. This allows for generation of the swatch in stages. '''
    def __init__(self):
        pass


    def unregisterSwatchRender(self, swatchGen): 
        '''unregisterSwatchRender(self, swatchGen)
Arguments:
	[in]	swatchGen = MString


removes the previously registered swatch generator 
'''
        pass

    def registerSwatchRender(self, swatchGenName, fnPtr): 
        '''registerSwatchRender(self, swatchGenName, fnPtr)
Arguments:
	[in]	swatchGenName = MString
	[in]	fnPtr = MSwatchRenderCreatorFnPtr


registers a new swatch generator creation function by name. 
'''
        pass

class MUniformParameter:
    '''Uniform parameter.The MUniformParameter class provides a high-level interface to hardware shader uniform parameters. By defining your shader's uniform parameters through this class, you allow Maya to handle the attributes, editing, serialisation, and caching for you in a standard way that ensure you'll be able to leverage future performance and functionlity improvements.At setup time (either initial load or when the effect/technique is changed), your shader simply creates the list of parameters it requires, specifying the name, type, semantic of the parameters. At render time, you can then use the parameters to directly access the appropriate buffers for that surface data.If you include a custom Attribute Editor template for your shader node, you can include these surface parameters by calling the AEhwUniformTemplateParameters script function. The following sample code provides a basic template you can modify - however your AE template can use as much or as little of this as you like:'''
    def __init__(self):
        pass


    def numColumns(self): 
        '''numColumns(self) -> int


Get the number of columns in this parameter'''
        pass

    def semantic(self): 
        '''semantic(self) -> MUniformParameter.DataSemantic


Get the semantic of this parameter'''
        pass

    def userData(self): 
        '''userData(self) -> void*


Get the user data for this parameter. User data can be used to store plugin specific information that you want to associate with this parameter. Typically this will be used to store a handle to the effect parameter.'''
        pass

    def setAsBool(self, value): 
        '''setAsBool(self, value)
Arguments:
	[in]	value = bool


Set the value of this uniform parameter as a boolean value. Note that it is not possible to set shape-dependent parameters.'''
        pass

    def getAsFloatArray(self, iterator): 
        '''getAsFloatArray(self, iterator) -> float*
Returns: The current floating point value of this uniform parameter. 

Arguments:
	[in]	iterator = MGeometryList


Get the value of this uniform parameter as one or more floating point values. Because some parameters can be shape-dependent, the method requires access to the current geometry item being rendered.'''
        pass

    def setAsInt(self, value): 
        '''setAsInt(self, value)
Arguments:
	[in]	value = int


Set the value of this uniform parameter as an integer value. Note that it is not possible to set shape-dependent parameters.'''
        pass

    def getAsFloat(self, iterator): 
        '''getAsFloat(self, iterator) -> float
Returns: The current float value of this uniform parameter. 

Arguments:
	[in]	iterator = MGeometryList


Get the value of this uniform parameter as a float. Because some parameters can be shape-dependent, the method requires access to the current geometry item being rendered.'''
        pass

    def numRows(self): 
        '''numRows(self) -> int


Get the number of rows in this parameter'''
        pass

    def numElements(self): 
        '''numElements(self) -> int


Get the number of elements in this parameter (including rows and columns)'''
        pass

    def setAsString(self, value): 
        '''setAsString(self, value)
Arguments:
	[in]	value = MString


Set the value of this uniform parameter as a string. Note that it is not possible to set shape-dependent parameters.'''
        pass

    def type(self): 
        '''type(self) -> MUniformParameter.DataType


Get the type of this parameter'''
        pass

    def MString(self): 
        '''MString(self) -> const


Get the name of this parameter'''
        pass

    def setAsFloat(self, value): 
        '''setAsFloat(self, value)
Arguments:
	[in]	value = float


Set the value of this uniform parameter as a float. Note that it is not possible to set shape-dependent parameters.'''
        pass

    def getAsBool(self, iterator): 
        '''getAsBool(self, iterator) -> bool
Returns: The current boolean value of this uniform parameter. 

Arguments:
	[in]	iterator = MGeometryList


Get the value of this uniform parameter as a boolean value. Because some parameters can be shape-dependent, the method requires access to the current geometry item being rendered.'''
        pass

    def setDirty(self): 
        '''setDirty(self)

Mark the data for this parameter as dirty. This will force the parameter to report that it has been changed the next time it is accessed. This allows external events (e.g. device lost, texture management, etc) to force a shader to re-set parameters tied to externally managed resources. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp . 
 
'''
        pass

    def isATexture(self): 
        '''isATexture(self) -> bool


Test if this parameter stores a texture.'''
        pass

    def setAsFloatArray(self, value, maxElements): 
        '''setAsFloatArray(self, value, maxElements)
Arguments:
	[in]	value = float
	[in]	maxElements = int


Set the value of this uniform parameter as one or more floating point values. Note that it is not possible to set shape-specific parameters.'''
        pass

    def kType1DTexture(self):
        '''This is an enum of DataType.
Description: 
Value: 4'''
        pass

    def kType3DTexture(self):
        '''This is an enum of DataType.
Description: 
Value: 6'''
        pass

    def kTypeString(self):
        '''This is an enum of DataType.
Description: 
Value: 9'''
        pass

    def kTypeBool(self):
        '''This is an enum of DataType.
Description: 
Value: 1'''
        pass

    def kTypeFloat(self):
        '''This is an enum of DataType.
Description: 
Value: 3'''
        pass

    def kType2DTexture(self):
        '''This is an enum of DataType.
Description: 
Value: 5'''
        pass

    def kTypeInt(self):
        '''This is an enum of DataType.
Description: 
Value: 2'''
        pass

    def kTypeUnknown(self):
        '''This is an enum of DataType.
Description: 
Value: 0'''
        pass

    def kTypeEnvTexture(self):
        '''This is an enum of DataType.
Description: 
Value: 8'''
        pass

    def kTypeCubeTexture(self):
        '''This is an enum of DataType.
Description: 
Value: 7'''
        pass

    class DataType:
        '''Non-functional class.  Values for this enum:
        kType1DTexture
        kType3DTexture
        kTypeString
        kTypeBool
        kTypeFloat
        kType2DTexture
        kTypeInt
        kTypeUnknown
        kTypeEnvTexture
        kTypeCubeTexture
'''
        def __init__(self):
            pass

    def getAsInt(self, iterator): 
        '''getAsInt(self, iterator) -> int
Returns: The current integer value of this uniform parameter. 

Arguments:
	[in]	iterator = MGeometryList


Get the value of this uniform parameter as an integer. Because some parameters can be shape-dependent, the method requires access to the current geometry item being rendered.'''
        pass

    def getAsString(self, iterator): 
        '''getAsString(self, iterator) -> MString
Returns: The current string value of this uniform parameter. 

Arguments:
	[in]	iterator = MGeometryList


Get the value of this uniform parameter as a string. Because some parameters can be shape-dependent, the method requires access to the current geometry item being rendered.'''
        pass

    def kSemanticNormal(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 10'''
        pass

    def kSemanticProjectionDir(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 4'''
        pass

    def kSemanticViewInverseMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 17'''
        pass

    def kSemanticProjectionPos(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 8'''
        pass

    def kSemanticWorldViewProjectionInverseMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 26'''
        pass

    def kSemanticWorldInverseMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 14'''
        pass

    def kSemanticWorldViewProjectionInverseTransposeMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 27'''
        pass

    def kSemanticWorldMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 13'''
        pass

    def kSemanticWorldDir(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 2'''
        pass

    def kSemanticWorldPos(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 6'''
        pass

    def kSemanticObjectPos(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 5'''
        pass

    def kSemanticUnknown(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 0'''
        pass

    def kSemanticColorTexture(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 28'''
        pass

    def kSemanticViewMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 16'''
        pass

    def kSemanticViewInverseTransposeMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 18'''
        pass

    def kSemanticProjectionMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 19'''
        pass

    def kSemanticViewPos(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 7'''
        pass

    def kSemanticWorldViewMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 22'''
        pass

    def kSemanticWorldViewInverseMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 23'''
        pass

    def kSemanticProjectionInverseMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 20'''
        pass

    def kSemanticObjectDir(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 1'''
        pass

    def kSemanticProjectionInverseTransposeMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 21'''
        pass

    def kSemanticWorldViewProjectionMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 25'''
        pass

    def kSemanticWorldInverseTransposeMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 15'''
        pass

    def kSemanticBumpTexture(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 30'''
        pass

    def kSemanticBump(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 11'''
        pass

    def kSemanticNormalTexture(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 29'''
        pass

    def kSemanticNormalizationTexture(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 31'''
        pass

    def kSemanticViewDir(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 3'''
        pass

    def kSemanticEnvironment(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 12'''
        pass

    def kSemanticWorldViewInverseTransposeMatrix(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 24'''
        pass

    def kSemanticTime(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 32'''
        pass

    def kSemanticColor(self):
        '''This is an enum of DataSemantic.
Description: 
Value: 9'''
        pass

    class DataSemantic:
        '''Non-functional class.  Values for this enum:
        kSemanticNormal
        kSemanticProjectionDir
        kSemanticViewInverseMatrix
        kSemanticProjectionPos
        kSemanticWorldViewProjectionInverseMatrix
        kSemanticWorldInverseMatrix
        kSemanticWorldViewProjectionInverseTransposeMatrix
        kSemanticWorldMatrix
        kSemanticWorldDir
        kSemanticWorldPos
        kSemanticObjectPos
        kSemanticUnknown
        kSemanticColorTexture
        kSemanticViewMatrix
        kSemanticViewInverseTransposeMatrix
        kSemanticProjectionMatrix
        kSemanticViewPos
        kSemanticWorldViewMatrix
        kSemanticWorldViewInverseMatrix
        kSemanticProjectionInverseMatrix
        kSemanticObjectDir
        kSemanticProjectionInverseTransposeMatrix
        kSemanticWorldViewProjectionMatrix
        kSemanticWorldInverseTransposeMatrix
        kSemanticBumpTexture
        kSemanticBump
        kSemanticNormalTexture
        kSemanticNormalizationTexture
        kSemanticViewDir
        kSemanticEnvironment
        kSemanticWorldViewInverseTransposeMatrix
        kSemanticTime
        kSemanticColor
'''
        def __init__(self):
            pass

    def getSource(self): 
        '''getSource(self) -> MPlug


Get the source plug connected to this parameter. Other than textures, this will typically be a NULL plug. 
  Reprocessed example  
 Examples: 
 
   
 hlslShader.cpp . 
 
'''
        pass

    def hasChanged(self, iterator): 
        '''hasChanged(self, iterator) -> bool
Returns: true if this parameter's value has changed since the last time its value was accessed. false otherwise. 

Arguments:
	[in]	iterator = MGeometryList


Has the value of this parameter changed since the last time it was accessed? This allow your shader to minimise state changes by only updating modified parameters.'''
        pass

class MUniformParameterList:
    '''Uniform Parameter. MUniformParameterArray specify the list of uniform shader parameters used by a hardware shader, allowing Maya to handle setting up the node and user interfaces to the data, the population and access of cached data, etc. '''
    def __init__(self):
        pass


    def setElement(self, n, p): 
        '''setElement(self, n, p)
Arguments:
	[in]	n = int
	[in]	p = MUniformParameter


Get the nth parameter in this list.'''
        pass

    def length(self): 
        '''length(self) -> int


Get the number of parameters in this list.'''
        pass

    def getElement(self, n): 
        '''getElement(self, n) -> MUniformParameter
Returns: The nth parameter in the list 

Arguments:
	[in]	n = int


Get the nth parameter in this list.'''
        pass

    def setLength(self, n): 
        '''setLength(self, n)
Arguments:
	[in]	n = int


Set the number of parameters in this list. If this is greater than the current number of parameters in the list, the caller is responsible for setting the new parameters to valid values using setElement.'''
        pass

    def append(self, element): 
        '''append(self, element)
Arguments:
	[in]	element = MUniformParameter


Append a new parameter to this end of this list.'''
        pass

class MVaryingParameter:
    '''Geometric data cache. The MVaryingParameter class provides a high-level interface to hardware shader varying parameters. By defining your shader's varying data through this class, you allow Maya to handle the attributes, editing, serialisation, requirements setup, and cache management for you in a standard way that ensure you'll be able to leverage future performance and functionlity improvements.At setup time (either initial load or when the effect/technique is changed), your shader simply creates the list of parameters it requires, specifying the name, type, semantic of the parameters. At render time, you can then use the parameters to directly access the appropriate buffers for that surface data.If you include a custom Attribute Editor template for your shader node, you can include these surface parameters by calling the AEhwShaderTemplateParameters script function. The following sample code provides a basic template you can modify - however your AE template can use as much or as little of this as you like:'''
    def __init__(self):
        pass


    def MString(self): 
        '''MString(self) -> const


Get the name of this parameter'''
        pass

    def semantic(self): 
        '''semantic(self) -> MVaryingParameter.MVaryingParameterSemantic


Get the semantic of this parameter'''
        pass

    def getMaximumStride(self): 
        '''getMaximumStride(self) -> int


Get the maximum stride of this parameter in bytes. For parameter that accept a range of element counts, this corresponds to the maximum number of elements the parameter supports.'''
        pass

    def getElement(self, i): 
        '''getElement(self, i) -> MVaryingParameter
Returns: The structure element. This will be a NULL element if an invalid index was specified. 

Arguments:
	[in]	i = int


Get an element within a structure. This operation is only valid for parameters of type kStructure.'''
        pass

    def removeElements(self): 
        '''removeElements(self)

Remove all child elements from a structure. This operation is only valid for parameters of type kStructure.'''
        pass

    def numElements(self): 
        '''numElements(self) -> int


Get the number of elements in this structure. This operation is only valid for parameters of type kStructure.'''
        pass

    def getElementSize(self): 
        '''getElementSize(self) -> int


Get the size in bytes of one element of this parameter.'''
        pass

    def getSourceSetName(self): 
        '''getSourceSetName(self) -> MString


If the current data type supports data sets (e.g. uv sets, color sets), get the name of the data set populating this parameter. This method will only return a useful value when called on leaf-level parameters (e.g. structures do not have sources, only the elements of a structure have sources).'''
        pass

    def getSourceType(self): 
        '''getSourceType(self) -> MVaryingParameter.MVaryingParameterSemantic


Get the type of data (e.g. position, normal, uv) currently populating this parameter. This method will only return a useful value when called on leaf-level parameters (e.g. structures do not have sources, only the elements of a structure have sources).'''
        pass

    def kWeight(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 5'''
        pass

    def kTangent(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 7'''
        pass

    def kBinormal(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 8'''
        pass

    def kNoSemantic(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 0'''
        pass

    def kColor(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 4'''
        pass

    def kTexCoord(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 3'''
        pass

    def kPosition(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 1'''
        pass

    def kNormal(self):
        '''This is an enum of MVaryingParameterSemantic.
Description: 
Value: 2'''
        pass

    class MVaryingParameterSemantic:
        '''Non-functional class.  Values for this enum:
        kWeight
        kTangent
        kBinormal
        kNoSemantic
        kColor
        kTexCoord
        kPosition
        kNormal
'''
        def __init__(self):
            pass

    def kInvalidParameter(self):
        '''This is an enum of MVaryingParameterType.
Description: 
Value: -1'''
        pass

    def kStructure(self):
        '''This is an enum of MVaryingParameterType.
Description: 
Value: 0'''
        pass

    def kFloat(self):
        '''This is an enum of MVaryingParameterType.
Description: 
Value: 1'''
        pass

    class MVaryingParameterType:
        '''Non-functional class.  Values for this enum:
        kInvalidParameter
        kStructure
        kFloat
'''
        def __init__(self):
            pass

    def getBuffer(self, geometry, data, elements, count): 
        '''getBuffer(self, geometry, data, elements, count)
Arguments:
	[in]	geometry = MGeometry
	[out]	data = void
	[out]	elements = int
	[out]	count = int


Get the data for this parameter as a system memory buffer.'''
        pass

    def type(self): 
        '''type(self) -> MVaryingParameter.MVaryingParameterType


Get the type of this parameter'''
        pass

    def addElement(self, child): 
        '''addElement(self, child)
Arguments:
	[in]	child = MVaryingParameter


Add a child element to this parameter. This operation is only valid for parameters of type kStructure.'''
        pass

    def setSource(self, type, setName): 
        '''setSource(self, type, setName)
Arguments:
	[in]	type = MVaryingParameter.MVaryingParameterSemantic
	[in]	setName = MString


While the source of geometry parameters is usually configured by the artist through Maya's user interface, this method allows you to programatically set the source of a geometry parameter, including both the data type (e.g. position, normal, etc) and an optional set name (e.g. UV set "map1"). This is useful for implementing custom default values or shader operations.'''
        pass

class MVaryingParameterList:
    '''Geometric data cache. MVaryingParameterArrays specify the surface component level data used by a hardware shader, allowing Maya to handle setting up the node and user interfaces to the data, the population and access of cached data, etc. '''
    def __init__(self):
        pass


    def setElement(self, n, p): 
        '''setElement(self, n, p)
Arguments:
	[in]	n = int
	[in]	p = MVaryingParameter


Set the nth parameter in this list.'''
        pass

    def length(self): 
        '''length(self) -> int


Get the number of parameters in this list.'''
        pass

    def getElement(self, n): 
        '''getElement(self, n) -> MVaryingParameter
Returns: The nth parameter in the list 

Arguments:
	[in]	n = int


Get the nth parameter in this list.'''
        pass

    def setLength(self, n): 
        '''setLength(self, n)
Arguments:
	[in]	n = int


Set the number of parameters in this list. If this is greater than the current number of parameters in the list, the caller is responsible for setting the new parameters to valid values using setElement.'''
        pass

    def append(self, element): 
        '''append(self, element)
Arguments:
	[in]	element = MVaryingParameter


Append a new parameter to this end of this list.'''
        pass

class MViewportRenderer:
    '''Base class for hardware viewport renderers. MViewportRenderer is a class which represents a hardware viewport renderer. '''
    def __init__(self):
        pass


    def MString(self): 
        '''MString(self) -> const


Return the user interface name of the renderer'''
        pass

    def kDirect3D(self):
        '''This is an enum of RenderingAPI.
Description: Renderer uses hardware Direct3D for rendering.
Value: 1'''
        pass

    def kOpenGL(self):
        '''This is an enum of RenderingAPI.
Description: Renderer uses hardware OpenGL for rendering.
Value: 0'''
        pass

    def kSoftware(self):
        '''This is an enum of RenderingAPI.
Description: Renderer renders using software.
Value: 2'''
        pass

    class RenderingAPI:
        '''Non-functional class.  Values for this enum:
        kDirect3D
        kOpenGL
        kSoftware
'''
        def __init__(self):
            pass

    def render(self, info): 
        '''render(self, info)
Arguments:
	[in]	info = MRenderingInfo


Rendering method. Must be overridden. 
'''
        pass

    def nativelySupports(self, api, version): 
        '''nativelySupports(self, api, version) -> bool
Returns: MViewportRenderer::RenderingAPI : rendering API. 

Arguments:
	[in]	api = MViewportRenderer.RenderingAPI
	[in]	version = float


Query the native rendering API's supported by this renderer. Must be overridden.'''
        pass

    def setUIName(self, name): 
        '''setUIName(self, name)
Arguments:
	[in]	name = MString


Set the user interface name of the renderer.'''
        pass

    def registerRenderer(self): 
        '''registerRenderer(self)

Register the renderer. Registration should occur when the plugin is initialized. A renderer will be available for usage from 3d modeling viewports if and only if it has been registered.'''
        pass

    def uninitialize(self): 
        '''uninitialize(self)

Renderer de-initialization. Must be overridden. 
'''
        pass

    def override(self, override): 
        '''override(self, override) -> bool
Returns: true if the renderer overrides the render target override. 

Arguments:
	[in]	override = MViewportRenderer.RenderingOverride


Check if override exists. 
'''
        pass

    def deregisterRenderer(self): 
        '''deregisterRenderer(self)

Deregister the renderer. Deregistration should occur when the plugin is unloaded.'''
        pass

    def renderingOverride(self): 
        '''renderingOverride(self) -> MViewportRenderer.RenderingOverride


Get the rendering API version number'''
        pass

    def initialize(self): 
        '''initialize(self)

Renderer initialization. Must be overridden. 
'''
        pass

    def kNoOverride(self):
        '''This is an enum of RenderingOverride.
Description: Override nothing.
Value: 0'''
        pass

    def kOverrideAllDrawing(self):
        '''This is an enum of RenderingOverride.
Description: Override all drawing.
Value: 1'''
        pass

    class RenderingOverride:
        '''Non-functional class.  Values for this enum:
        kNoOverride
        kOverrideAllDrawing
'''
        def __init__(self):
            pass

    def setRenderingOverride(self, override): 
        '''setRenderingOverride(self, override)
Arguments:
	[in]	override = MViewportRenderer.RenderingOverride


Set the rendering override for the renderer.'''
        pass

