
'''
Stub class file for:
OpenMayaAnim

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class MAnimControl:
    '''Control over animation playback and values. This class provide access to the values that control how an animation is played. This includes the minimum and maximum frames included in the playback, whether the playback loops, and whether the animation runs in all views, or only the active view, etc.Methods also exist that mirror the functionality of the controls found on the time slider in the UI to start and stop the playback. '''
    def __init__(self):
        pass


    def setCurrentTime(self, newTime): 
        '''setCurrentTime(self, newTime)
Arguments:
	[in]	newTime = MTime


Set the current animation frame.'''
        pass

    def setMinMaxTime(self, min, max): 
        '''setMinMaxTime(self, min, max)
Arguments:
	[in]	min = MTime
	[in]	max = MTime


Set the values of the first and last frames of the playback time range.'''
        pass

    def setViewMode(self, newMode): 
        '''setViewMode(self, newMode)
Arguments:
	[in]	newMode = MAnimControl.PlaybackViewMode


Set the current viewing mode. Controls whether the animation is run in only the active view, or simultaneously in all views.'''
        pass

    def kPlaybackViewAll(self):
        '''This is an enum of PlaybackViewMode.
Description: Playback in all views.
Value: 0'''
        pass

    def kPlaybackViewActive(self):
        '''This is an enum of PlaybackViewMode.
Description: Playback in only the active view.
Value: 1'''
        pass

    class PlaybackViewMode:
        '''Non-functional class.  Values for this enum:
        kPlaybackViewAll
        kPlaybackViewActive
'''
        def __init__(self):
            pass

    def playbackSpeed(self): 
        '''playbackSpeed(self) -> double


Return the speed with with to play the animation.'''
        pass

    def weightedTangents(self): 
        '''weightedTangents(self) -> bool
Returns: true the tangents on the Anim Curve are weighted 
false the tangents on the Anim Curve are not weighted


Determine whether or not the tangents on the Anim Curve are weighted.'''
        pass

    def setPlaybackSpeed(self, newSpeed): 
        '''setPlaybackSpeed(self, newSpeed)
Arguments:
	[in]	newSpeed = double


Set the desired speed factor at which the animation will play back.'''
        pass

    def minTime(self): 
        '''minTime(self) -> MTime


Return an  MTime  specifying the first frame of the current playback time range. This corresponds to the minTime which can also be set and queried using the playbackOptions mel command. It does not represent the first frame of the total animation time unless the two coincide.'''
        pass

    def playbackBy(self): 
        '''playbackBy(self) -> double


Return a double specifying the increment between times viewed during the playing of the animation.'''
        pass

    def setAnimationStartEndTime(self, newStartTime, newEndTime): 
        '''setAnimationStartEndTime(self, newStartTime, newEndTime)
Arguments:
	[in]	newStartTime = MTime
	[in]	newEndTime = MTime


Set the values of the first and last frames in the animation.'''
        pass

    def animationEndTime(self): 
        '''animationEndTime(self) -> MTime


Return an  MTime  specifying the last frame of the animation, as specified by the Maya user in the Range Slider UI. This corresponds to the animationEndTime which can also be set and queried using the playbackOptions mel command.'''
        pass

    def setAutoKeyMode(self, mode): 
        '''setAutoKeyMode(self, mode)
Arguments:
	[in]	mode = bool


Set the autoKeyMode.'''
        pass

    def maxTime(self): 
        '''maxTime(self) -> MTime


Return an  MTime  specifying the last frame of the current playback time range. This corresponds to the maxTime which can also be set and queried using the playbackOptions mel command. It does not represent the final frame of the total animation time unless the two coincide.'''
        pass

    def setGlobalOutTangentType(self, tangentType): 
        '''setGlobalOutTangentType(self, tangentType)
Arguments:
	[in]	tangentType = MFnAnimCurve.TangentType


Set the current global out tangent type.'''
        pass

    def globalInTangentType(self): 
        '''globalInTangentType(self) -> MFnAnimCurve.TangentType
Returns: MFnAnimCurve::TangentType the current global in tangent type


Return the current global in tangent type.'''
        pass

    def setMinTime(self, newMinTime): 
        '''setMinTime(self, newMinTime)
Arguments:
	[in]	newMinTime = MTime


Set the first frame of the current playback time range.'''
        pass

    def playBackward(self): 
        '''playBackward(self)

Start playing the current animation backwards.'''
        pass

    def stop(self): 
        '''stop(self)

Stop playing the current animation.'''
        pass

    def setPlaybackBy(self, newTime): 
        '''setPlaybackBy(self, newTime)
Arguments:
	[in]	newTime = double


Specify the increment between times viewed during the playing of the animation.'''
        pass

    def animationStartTime(self): 
        '''animationStartTime(self) -> MTime


Return an  MTime  specifying the first frame of the animation, as specified by the Maya user in the Range Slider UI. This corresponds to the animationStartTime which can also be set and queried using the playbackOptions mel command.'''
        pass

    def globalOutTangentType(self): 
        '''globalOutTangentType(self) -> MFnAnimCurve.TangentType
Returns: The current global out tangent type


Return the current global out tangent type.'''
        pass

    def setPlaybackMode(self, newMode): 
        '''setPlaybackMode(self, newMode)
Arguments:
	[in]	newMode = MAnimControl.PlaybackMode


Set the current playback mode.'''
        pass

    def kPlaybackOscillate(self):
        '''This is an enum of PlaybackMode.
Description: Play forwards, then backwards continuously.
Value: 2'''
        pass

    def kPlaybackOnce(self):
        '''This is an enum of PlaybackMode.
Description: Play once then stop.
Value: 0'''
        pass

    def kPlaybackLoop(self):
        '''This is an enum of PlaybackMode.
Description: Play continuously.
Value: 1'''
        pass

    class PlaybackMode:
        '''Non-functional class.  Values for this enum:
        kPlaybackOscillate
        kPlaybackOnce
        kPlaybackLoop
'''
        def __init__(self):
            pass

    def setMaxTime(self, newMaxTime): 
        '''setMaxTime(self, newMaxTime)
Arguments:
	[in]	newMaxTime = MTime


Set the value of the last frame of the current playback time range.'''
        pass

    def isPlaying(self): 
        '''isPlaying(self) -> bool


Return a value indicating whether Maya is currently playing the animation.'''
        pass

    def setGlobalInTangentType(self, tangentType): 
        '''setGlobalInTangentType(self, tangentType)
Arguments:
	[in]	tangentType = MFnAnimCurve.TangentType


Set the current global in tangent type.'''
        pass

    def setWeightedTangents(self, weightState): 
        '''setWeightedTangents(self, weightState)
Arguments:
	[in]	weightState = bool


Sets whether or not the tangents on the Anim Curve are weighted. Note: switching a curve from weightedTangents true to false and back to true again will not preserve fixed tangents properly. Use undo instead.'''
        pass

    def currentTime(self): 
        '''currentTime(self) -> MTime


Return an  MTime  instance containing the current animation frame.'''
        pass

    def autoKeyMode(self): 
        '''autoKeyMode(self) -> bool


Return the autoKeyMode.'''
        pass

    def setAnimationStartTime(self, newStartTime): 
        '''setAnimationStartTime(self, newStartTime)
Arguments:
	[in]	newStartTime = MTime


Set the value of the first frame in the animation.'''
        pass

    def viewMode(self): 
        '''viewMode(self) -> MAnimControl.PlaybackViewMode


Return the viewing mode currently in effect.'''
        pass

    def playbackMode(self): 
        '''playbackMode(self) -> MAnimControl.PlaybackMode


Return the playback mode currently in effect.'''
        pass

    def playForward(self): 
        '''playForward(self)

Start playing the current animation forwards.'''
        pass

    def setAnimationEndTime(self, newEndTime): 
        '''setAnimationEndTime(self, newEndTime)
Arguments:
	[in]	newEndTime = MTime


Set the value of the last frame in the animation.'''
        pass

class MAnimCurveChange:
    '''Anim Curve Change Cache. Caching of the undo and redo information in a Anim Curve Change cache is required primarily to support interactive editing of Anim Curves in the UI.Anim Curve Change caches are used as persistent storage for information concerning changes to Anim Curve Nodes.When invoked with a valid Anim Curve change parameter, the remove keyframe and add keyframe methods of the Anim Curve Function Set (MFnAnimCurve::remove() and MFnAnimCurve::addKeyframe(), respectively) cache the change information in the Anim Curve Change cache so that the caller can undo and redo the changes as required.If the same cache is used for a series of Anim Curve edit operations, then the cache maintains an undo/redo queue which allows all changes in the series to be undone or redone. If selective undo/redo is required, then a different Anim Curve Change cache is required for each edit.Use Anim Curve Change caches in conjunction with the Anim Curve Function Set (MFnAnimCurve) to perform undoable and redoable edits on Anim Curves. '''
    def __init__(self):
        pass


    def redoIt(self): 
        '''redoIt(self)

Redoes all of the Anim Curve edits that this cache previously undid. It is only valid to invoke this method after an undo on this cache.'''
        pass

    def undoIt(self): 
        '''undoIt(self)

Undoes all of the Anim Curve edits that have been given to this cache.'''
        pass

class MAnimCurveClipboard:
    '''Control over the animation clipboard. The clipboard is a list of MAnimCurveClipboardItems (i.e. an MAnimCurveClipboardItemArray). All of the data stored on a clipboard remains static; that is, it will persist as long as the application remains running.The items on the clipboard must be ordered. In the case where the clipboard info represents animation of a hierarchy, the order in which items appear in the clipboard is reliant on a depth-first-iteration from the root or the hierarchy. This ordering, is essential to properly match up hierarchies of objectsAs an example, consider that animation from the following hierarchy is placed into the clipboard. Slanted Dag Objects are animated.In this example, the object labelled "C" has translate{X,Y,Z} animated, while all the others only have one animated attribute (excluding objects B and F, which have no animated attributes).Using notation where A(r,c,a) represents the animCurve driving object "A", which is at row "r" in its subhierarchy, has "c" children, and "a" animated attributes these items would appear in the clipboard in this order (i.e. depth-first with each object's attributes explicitly indexed before continuing down the hierarchy):For example C(2,1,2) would mean that the object C resides on the second level of the subhierarchy and has one child. The last "2" is simply used as an index to count the number of animated attributes on this object.Multiple objects can be represented on the clipboard in this manner. In the example above, if we had a separate second object with no children, "J", it would appear at the end of the array as J(0,0,0).Note that although B and F contain no animation data themselves, they must still be placed on the clipboard as placeholders to preserve the hierarchy information. A placeholder object is defined by a NULL value for the MAnimCurveClipboardItem's animCurve.There is a special clipboard that remains static. It can be accessed by MAnimCurveClipboard::theAPIClipboard(). '''
    def __init__(self):
        pass


    def MAnimCurveClipboardItemArray(self): 
        '''MAnimCurveClipboardItemArray(self) -> const
Returns: The item array currently on this clipboard.


Returns the contents of the clipboard.'''
        pass

    def set(self, clipboardItemArray, startTime, endTime, startUnitlessInput, endUnitlessInput): 
        '''set(self, clipboardItemArray, startTime, endTime, startUnitlessInput, endUnitlessInput)
Arguments:
	[in]	clipboardItemArray = MAnimCurveClipboardItemArray
	[in]	startTime = MTime
	[in]	endTime = MTime
	[out]	startUnitlessInput = float
	[out]	endUnitlessInput = float


Sets the contents of the clipboard.'''
        pass

    def clear(self): 
        '''clear(self)

This method empties the clipboard.'''
        pass

    def startUnitlessInput(self): 
        '''startUnitlessInput(self) -> float
Returns: The start unitless input of the clipboard.


Returns the start unitless input of the clipboard.'''
        pass

    def isEmpty(self): 
        '''isEmpty(self) -> bool
Returns: true the current clipboard is empty 
false the current clipboard is not empty

Status Code


Determines if the clipboard is empty.'''
        pass

    def startTime(self): 
        '''startTime(self) -> MTime
Returns: The start time of the clipboard.


Returns the start time of the clipboard.'''
        pass

    def theAPIClipboard(self): 
        '''theAPIClipboard(self) -> MAnimCurveClipboard


Returns the static API clipboard. 
  Reprocessed example  
 Examples: 
 
   
 animFileUtils.cpp , and  animImportExport.cpp . 
 
'''
        pass

    def endUnitlessInput(self): 
        '''endUnitlessInput(self) -> float
Returns: The end unitless input of the clipboard.


Returns the end unitless input of the clipboard.'''
        pass

    def endTime(self): 
        '''endTime(self) -> MTime
Returns: The end time of the clipboard.


Returns the end time of the clipboard.'''
        pass

class MAnimCurveClipboardItem:
    '''Wrapper for a clipboard item. This class provides a wrapper for a clipboard item. Common convenience functions are available, and the implementation is compatible with the internal Maya implementation so that it can be passed efficiently between plugins and internal maya data structures. '''
    def __init__(self):
        pass


    def MString(self): 
        '''MString(self) -> const
Returns: The node name.


Returns the node name'''
        pass

    def setNameInfo(self, nodeName, fullName, leafName): 
        '''setNameInfo(self, nodeName, fullName, leafName)
Arguments:
	[in]	nodeName = MString
	[in]	fullName = MString
	[in]	leafName = MString


Sets the clipboard item's name info'''
        pass

    def setAddressingInfo(self, rowCount, childCount, attributeCount): 
        '''setAddressingInfo(self, rowCount, childCount, attributeCount)
Arguments:
	[in]	rowCount = int
	[in]	childCount = int
	[in]	attributeCount = int


Sets the clipboard item's addressing info'''
        pass

    def setAnimCurve(self, curve): 
        '''setAnimCurve(self, curve)
Arguments:
	[in]	curve = MObject


Sets the clipboard item's animCurve'''
        pass

    def getAddressingInfo(self, rowCount, childCount, attributeCount): 
        '''getAddressingInfo(self, rowCount, childCount, attributeCount)
Arguments:
	[out]	rowCount = int
	[out]	childCount = int
	[out]	attributeCount = int


Returns the addressing information for this clipboard item,'''
        pass

    def animCurveType(self): 
        '''animCurveType(self) -> MFnAnimCurve.AnimCurveType
Returns: The animCurve type.


Returns the animCurve type'''
        pass

    def MObject(self): 
        '''MObject(self) -> const
Returns: An MObject for the animCurve. On failure, the MObject will be NULL. Be aware that the clipboard may be holding onto NULL animCurves (which are placeholder objects).


Returns the animCurve held by this clipboard item as an  MObject . Note that the returned  MObject  is const because you must not modify the animCurve referenced by this  MObject .'''
        pass

    def __eq__(self, rhs): 
        '''__eq__(self, rhs) -> bool
Returns: true the MAnimCurveClipboard items are equal 
false the MAnimCurveClipboard items are not equal 

Arguments:
	[in]	rhs = MAnimCurveClipboardItem


Compare the individual members for equality.'''
        pass

class MAnimCurveClipboardItemArray:
    '''Array of MAnimCurveClipboardItem data type. This class implements an array of MAnimCurveClipboardItems. Common convenience functions are available, and the implementation is compatible with the internal Maya implementation so that it can be passed efficiently between plugins and internal maya data structures. '''
    def __init__(self):
        pass


    def insert(self, element, index): 
        '''insert(self, element, index)
Arguments:
	[in]	element = MAnimCurveClipboardItem
	[in]	index = int


Inserts a new value into the array at the given index. The initial element at that index, and all following elements, are shifted towards the last. If the array cannot be expanded in size by 1 element, then the insert will fail and the existing array will remain unchanged.'''
        pass

    def set(self, element, index): 
        '''set(self, element, index)
Arguments:
	[in]	element = MAnimCurveClipboardItem
	[in]	index = int


Sets the value of the indicated element to the indicated  MAnimCurveClipboardItem  value.'''
        pass

    def isValid(self, failedIndex): 
        '''isValid(self, failedIndex) -> bool
Returns: true if the clipboard item array is valid, and false otherwise 

Arguments:
	[out]	failedIndex = int


Ensures that the  MAnimCurveClipboard  items in the array make sense.'''
        pass

    def clear(self): 
        '''clear(self)

Clear the contents of the array. After this operation the length method will return 0. This does not change the amount of memory allocated to the array, only the number of valid elements in it.'''
        pass

    def sizeIncrement(self): 
        '''sizeIncrement(self) -> int


Return the size by which the array will be expanded whenever expansion is necessary.'''
        pass

    def MAnimCurveClipboardItem(self, index): 
        '''MAnimCurveClipboardItem(self, index) -> const
Returns: A reference to the indicated element 

Arguments:
	[in]	index = int


Index operator. Returns the value of the element at the given index. No range checking is done - valid indices are 0 to  length() -1.'''
        pass

    def remove(self, index): 
        '''remove(self, index)
Arguments:
	[in]	index = int


Remove the array element at the given index. All array elements following the removed element are shifted toward the first element.'''
        pass

    def length(self): 
        '''length(self) -> int


Returns the number of elements in the instance.'''
        pass

    def setSizeIncrement(self, newIncrement): 
        '''setSizeIncrement(self, newIncrement)
Arguments:
	[in]	newIncrement = int


Set the size by which the array will be expanded whenever expansion is necessary.'''
        pass

    def append(self, element): 
        '''append(self, element)
Arguments:
	[in]	element = MAnimCurveClipboardItem


Adds a new element to the end of the array. If the array cannot be expanded in size by 1 element, then the append will fail and the existing array will remain unchanged.'''
        pass

class MAnimMessage:
    '''Animation messages. This class is used to register callbacks for animation messages.To remove a callback use MMessage::removeCallback. All callbacks that are registered by a plug-in must be removed by that plug-in when it is unloaded. Failure to do so will result in a fatal error. '''
    def __init__(self):
        pass


    def addNodeAnimKeyframeEditedCallback(self, animNode, func, clientData): 
        '''addNodeAnimKeyframeEditedCallback(self, animNode, func, clientData) -> MCallbackId

Arguments:
	[in]	animNode = MObject
	[in]	func = MMessage.MNodeObjArray
	[in]	clientData = void


AnimCurve keyframe edited callback. 
'''
        pass

    def addAnimCurveEditedCallback(self, func, clientData): 
        '''addAnimCurveEditedCallback(self, func, clientData) -> MCallbackId

Arguments:
	[in]	func = MMessage.MObjArray
	[in]	clientData = void


AnimCurve edited callback. 
'''
        pass

    def addAnimKeyframeEditCheckCallback(self, func, clientData): 
        '''addAnimKeyframeEditCheckCallback(self, func, clientData) -> MCallbackId
Returns: Identifier used for removing the callback.

Arguments:
	[in]	func = MMessage.MCheckPlugFunction
	[in]	clientData = void


AnimCurve keyframe edit check callback. 
'''
        pass

    def addAnimKeyframeEditedCallback(self, func, clientData): 
        '''addAnimKeyframeEditedCallback(self, func, clientData) -> MCallbackId

Arguments:
	[in]	func = MMessage.MObjArray
	[in]	clientData = void


AnimCurve keyframe edited callback. 
'''
        pass

    def flushAnimKeyframeEditedCallbacks(self): 
        '''flushAnimKeyframeEditedCallbacks(self)
'''
        pass

class MAnimUtil:
    '''Static class providing common animation helper methods. MAnimUtil is a static class which provides methods which determine if an object is being animated, which attributes are animated for a given object and which animation curves are used to animate a given attribute.Note: for purposes of this helper class, "animation" refers to attributes animated by animCurves (i.e. by setting keys). It does not include any animation through expressions or dynamics or timer node connections.Some helper methods may examine different types of objects. Depending upon how the object is represented, the same object may be examined differently.If the object is specified as an , then all of its attributes are examined. If the MObject is a hierarchical object (such as a dag node) and you specify that the objects parents should be examined, then all the parents of an instanced object will be examined.If the object is specified as an , then all of its attributes are examined. If you specify that the objects parents should be examined, then only the specified path of the instanced object will be examined.If the object is specifed as an  and no attribute has been set, then the method will behave as if it was called with an MObject. Otherwise only the specified attribute will be examined. For example, a compound attribute will not have its child attributes examined (i.e. if you specify node.translate, node.translateX will not be examined).If the object is specified through an , it can also have multiple representations. If the object was added to the MSelectionList as an MObject, then it will be examined as an MObject. If the object was added to the MSelectionList as an MDagPath, then it will be examined as an MDagPath. If the object was added to the MSelectionList as either a component or an MPlug, it will be examined as an MPlug with additional expansion of compound attributes into their child attributes (for example, if specify node.translate is specified, node.translateX will be examined. More importantly, if you specify poly.f[4] then xValue, yValue and zValue will be examined for each vertex).Below is a summary of how the same object will be examined by MAnimUtil::isAnimated depending upon how it has been represented. If we have the following hierarchical layout:The MAnimUtil::isAnimated will respond as follows: => false => true => false => false => false => true => false => true => false => trueThe following list assumes that MAnimUtil is called with an MSelectionList named list, and shows the response depending upon how the object has been added to list: => false => true => false => false => false => true => true => true => true => true '''
    def __init__(self):
        pass


    def isAnimated(self, selectionList, checkParent): 
        '''isAnimated(self, selectionList, checkParent) -> bool
Returns: true The MSelectionList has atleast one animated member. 
false No member of the MSelectionList is animated. 

Arguments:
	[in]	selectionList = MSelectionList
	[in]	checkParent = bool


Determine whether or not any member of an  MSelectionList  is animated. This is intended to work with an  MSelectionList  with a single entry since that provides the most useful information.'''
        pass

    def findAnimatedPlugs(self, selectionList, animatedPlugs, checkParent): 
        '''findAnimatedPlugs(self, selectionList, animatedPlugs, checkParent) -> bool
Returns: true The MSelectionList has atleast one animated member. 
false No member of the MSelectionList is animated. 

Arguments:
	[in]	selectionList = MSelectionList
	[in]	animatedPlugs = MPlugArray
	[in]	checkParent = bool


Find the list of attributes (MPlugs) on any member of an  MSelectionList  that is animated. This is intended to work with an  MSelectionList  with a single entry since that provides the most useful information.'''
        pass

    def findAnimation(self, plug, animation): 
        '''findAnimation(self, plug, animation) -> bool
Returns: true The MPlug is animated. 
false The MPlug is not animated. 

Arguments:
	[in]	plug = MPlug
	[in]	animation = MObjectArray


Find the animCurve(s) that are animating a given attribute ( MPlug ). In most cases an attribute is animated by a single animCurve and so just that animCurve will be returned. It is possible to setup a series of connections where an attribute is animated by more than one animCurve, although Maya does not currently offer a UI to do so. Compound attributes are not expanded to include any child attributes.'''
        pass

class MFnAnimCurve:
    '''Anim Curve Function Set. Create, query and edit Anim Curve Nodes and the keys internal to those Nodes.Create an Anim Curve Node and connect its output to any animatable attribute on another Node.Evaluate an Anim Curve at a particular time.Determine the number of keys held by an Anim Curve.Determine the time and value of individual keys, as well as the (angle,weight) or (x,y) values and type of key tangents. The in-tangent refers to the tangent entering the key. The out-tangent refers to the tangent leaving the key.Find the index of the key at, or closest to a particular time.Set the time and value of individual keys, as well as the type of the tangent to the curve entering (in-tangent) and leaving (out-tangent) the key, specify the tangent as either (angle,weight) or (x,y).Add and remove keys from an Anim Curve. Anim Curves are implemented as Dependency Graph (DG) Nodes. Each Node can have indexed keys.There are eight different types of Anim Curve nodes:Specifying the correct AnimCurveType during creation will avoid implicit unit conversion nodes.Use the Anim Curve Function Set to create Anim Curve Nodes and connect them to animatable attributes on DG Nodes, as well as to query and edit an Anim Curve Node and its keys.On creation, an Anim Curve Function Set may be attached to a given Anim Curve or it may be unattached. The Function Set may be attached to a different Anim Curve Node using the setObject() methods inherited from the Base Function Set (MFnBase) or with the create() methods.Use the create() methods of an Anim Curve Function Set to create a new Anim Curve Node, attach the Function Set to the new Node and connect the output of the Node to a specific animatable Attribute or Plug of another Node. Additionally, the output of an Anim Curve Node may be attached to an Attribute or Plug of another DG Node using the DG Modifier method MDGModifier::connect().Use the evaluate() methods to determine the value of an Anim Curve at a particular time or a given unitless input.Use the addKey() and remove() methods to add and remove keys to and from an Anim Curve.The query and edit methods of the Anim Curve Function Set act on keys at a specific 0-based index. [Note that the numKeys() method returns a 1-based value]. Keys can be accessed either randomly (via a 0-based index) or serially (using the find() and findClosest() methods).Use the find() or findClosest() methods to determine the index of a key at or closest to a specific time respectively.Use the specific query methods to determine the time, value and tangent information for a key at a given index.Use the specific edit methods to set the time, value and tangent information for a key at a given index.There are methods for setting the x,y values for the in- and out-tangents, as well as setting their angles and weights.Setting the time of a key will fail if the new time would require a re-ordering of the keys. Use the remove() and addKey() methods to re-order the keys. Or use the keyframe command from mel.The Maya developer's kit ships with example code (animDemo) which demonstrates how to evaluate a Maya animation curve independent from Maya. The animation parameter curves in Maya are defined by a restricted set of cubic two-dimensional Bezier curves. It is defined by four points. P1 = (x1, y1) is the (key,value) pair for the first key. P2 = (x2, y2) is a point which defines the outgoing tangent direction at P1. P4 = (x4, y4) defines the second key and P3 = (x3, y3) is a point which defines the incoming tangent direction at P4. There are some basic restrictions for the x coordinates of these points: x1 <= x2 <= x3 <= x4.The 2-dimensional Bezier curve is defined asF(u) yields a vector of two cubic polynomials [ Fx(u) Fy(u) ] which define an (x, y) position on the parameter curve for some u in the range [0,1].For an animation parameter curve, we are given the x position and want to know its corresponding y position. To do this we use x = Fx(u) and solve for u. Fx(u) is cubic and the restrictions on valid values for x2 and x3 guarantee there will be only one real root value for u. Once we know u, we can plug it into Fy(u) to get the y value.One important note is how the outgoing and incoming tangents directions for a key are saved internally and in the Maya Ascii file format. Instead of being specified as points, the tangent directions are specified as vectors. The outgoing tangent direction at P1 is specified and saved as the vector 3*(P2 - P1) and the incoming tangent direction is specified and saved as the vector 3*(P4 - P3).An animation curve is basically a restricted form of a bezier curve for which the keys serve as the control points and have tangent information embedded within them. There are two different methods for converting tangent information into the control points of the bezier hull and we have taken to calling the two methods weighted and non-weighted tangents.The animation curve is evaluated in a piecewise manner, which means that each segment between two keys is evaluated on its own, without regards to any other segment. The only time keys outside of a segment are considered is when tangent values are calculated for the spline, clamped and plateau tangent types.When evaluating an animation curve, a two stage process is used: Animation curves may have either weighted or non-weighted tangents. With non-weighted tangents, tangents are implemented as vectors and P2 and P3 are internally adjusted to account for the time difference between P1 and P4.When evaluating a time within a segment, the following algortithms are used:'''
    def __init__(self):
        pass


    def isWeighted(self): 
        '''isWeighted(self) -> bool
Returns: Boolean value: true if the curve has weighted tangents, false otherwise.


Determines whether or not the curve has weighted tangents.'''
        pass

    def getTangent(self, index, inTangent, angle, weight): 
        '''getTangent(self, index, inTangent, angle, weight)
Arguments:
	[in]	index = int
	[out]	angle = MAngle
	[out]	weight = double
	[in]	inTangent = bool


Determines the angle and weight of the in- or out-tangent to the curve for the key at the specified index.'''
        pass

    def setTangentsLocked(self, index, locked, change): 
        '''setTangentsLocked(self, index, locked, change)
Arguments:
	[in]	index = int
	[in]	locked = bool
	[in]	change = MAnimCurveChange


Lock or unlock the tangents at the given key.'''
        pass

    def timedAnimCurveTypeForPlug(self, plug): 
        '''timedAnimCurveTypeForPlug(self, plug) -> MFnAnimCurve.AnimCurveType
Returns: The animCurve type.

Arguments:
	[in]	plug = MPlug


Returns the timed animCurve type appropriate for the specified plug.'''
        pass

    def kTangentGlobal(self):
        '''This is an enum of TangentType.
Description: Global.
Value: 0'''
        pass

    def kTangentFast(self):
        '''This is an enum of TangentType.
Description: OBSOLETE kTangentFast should not be used. Using this tangent type may produce unwanted and unexpected results.
Value: 7'''
        pass

    def kTangentPlateau(self):
        '''This is an enum of TangentType.
Description: Plateau.
Value: 9'''
        pass

    def kTangentFixed(self):
        '''This is an enum of TangentType.
Description: Fixed.
Value: 1'''
        pass

    def kTangentSmooth(self):
        '''This is an enum of TangentType.
Description: Smooth.
Value: 4'''
        pass

    def kTangentStepNext(self):
        '''This is an enum of TangentType.
Description: StepNext.
Value: 10'''
        pass

    def kTangentStep(self):
        '''This is an enum of TangentType.
Description: Step.
Value: 5'''
        pass

    def kTangentClamped(self):
        '''This is an enum of TangentType.
Description: Clamped.
Value: 8'''
        pass

    def kTangentFlat(self):
        '''This is an enum of TangentType.
Description: Flag.
Value: 3'''
        pass

    def kTangentSlow(self):
        '''This is an enum of TangentType.
Description: OBSOLETE kTangentSlow should not be used. Using this tangent type may produce unwanted and unexpected results.
Value: 6'''
        pass

    def kTangentLinear(self):
        '''This is an enum of TangentType.
Description: Linear.
Value: 2'''
        pass

    class TangentType:
        '''Non-functional class.  Values for this enum:
        kTangentGlobal
        kTangentFast
        kTangentPlateau
        kTangentFixed
        kTangentSmooth
        kTangentStepNext
        kTangentStep
        kTangentClamped
        kTangentFlat
        kTangentSlow
        kTangentLinear
'''
        def __init__(self):
            pass

    def addKeyframe(self, time, value, tangentInType, tangentOutType, change): 
        '''addKeyframe(self, time, value, tangentInType, tangentOutType, change)
Arguments:
	[in]	time = MTime
	[in]	value = double
	[in]	tangentInType = MFnAnimCurve.TangentType
	[in]	tangentOutType = MFnAnimCurve.TangentType
	[in]	change = MAnimCurveChange


Adds a new key with the given value and tangent types at the specified time.'''
        pass

    def value(self, index): 
        '''value(self, index) -> double
Returns: Value of the key

Arguments:
	[in]	index = int


Determines the value of the key at the specified index. This method should only be used on Anim Curves of type kAnimCurve*A, kAnimCurve*L or kAnimCurve*U.'''
        pass

    def animCurveType(self): 
        '''animCurveType(self) -> MFnAnimCurve.AnimCurveType
Returns: The animCurve type.


Returns the animCurve type'''
        pass

    def findClosest(self, unitlessInput): 
        '''findClosest(self, unitlessInput) -> int
Returns: Key index closest to the specified time

Arguments:
	[in]	unitlessInput = double


Determines the index of the key which is set at the time closest to the specified unitless input value.'''
        pass

    def find(self, unitlessInput, index): 
        '''find(self, unitlessInput, index) -> bool
Returns: Boolean value: true if the index is found false otherwise

Arguments:
	[in]	unitlessInput = double
	[out]	index = int


Determines the index of the key which is set at the specified unitless input value.'''
        pass

    def setIsWeighted(self, isWeighted, change): 
        '''setIsWeighted(self, isWeighted, change)
Arguments:
	[in]	isWeighted = bool
	[in]	change = MAnimCurveChange


Sets whether or not the curve has weighted tangents.'''
        pass

    def kCycle(self):
        '''This is an enum of InfinityType.
Description: Cycle.
Value: 3'''
        pass

    def kConstant(self):
        '''This is an enum of InfinityType.
Description: Constant.
Value: 0'''
        pass

    def kLinear(self):
        '''This is an enum of InfinityType.
Description: Linear.
Value: 1'''
        pass

    def kOscillate(self):
        '''This is an enum of InfinityType.
Description: Oscillate.
Value: 5'''
        pass

    def kCycleRelative(self):
        '''This is an enum of InfinityType.
Description: Cycle relative.
Value: 4'''
        pass

    class InfinityType:
        '''Non-functional class.  Values for this enum:
        kCycle
        kConstant
        kLinear
        kOscillate
        kCycleRelative
'''
        def __init__(self):
            pass

    def create(self, animCurveType, modifier): 
        '''create(self, animCurveType, modifier) -> MObject
Returns: The new Anim Curve Node

Arguments:
	[in]	animCurveType = MFnAnimCurve.AnimCurveType
	[in]	modifier = MDGModifier


Creates a new Anim Curve Node, attaches the Function Set to the new Node (detaching from the current Node) but does not attempt to connect the new Anim Curve Node.'''
        pass

    def unitlessAnimCurveTypeForPlug(self, plug): 
        '''unitlessAnimCurveTypeForPlug(self, plug) -> MFnAnimCurve.AnimCurveType
Returns: The animCurve type.

Arguments:
	[in]	plug = MPlug


Returns the unitless animCurve type appropriate for the specified plug.'''
        pass

    def setPostInfinityType(self, infinityType, change): 
        '''setPostInfinityType(self, infinityType, change)
Arguments:
	[in]	infinityType = MFnAnimCurve.InfinityType
	[in]	change = MAnimCurveChange


Set the behaviour of the curve for the range occurring after the last key.'''
        pass

    def setInTangentType(self, index, tangentType, change): 
        '''setInTangentType(self, index, tangentType, change)
Arguments:
	[in]	index = int
	[in]	tangentType = MFnAnimCurve.TangentType
	[in]	change = MAnimCurveChange


Sets the type of the tangent to the curve entering the key at the specified index.'''
        pass

    def setPreInfinityType(self, infinityType, change): 
        '''setPreInfinityType(self, infinityType, change)
Arguments:
	[in]	infinityType = MFnAnimCurve.InfinityType
	[in]	change = MAnimCurveChange


Set the behaviour of the curve for the range occurring before the first key.'''
        pass

    def inTangentType(self, index): 
        '''inTangentType(self, index) -> MFnAnimCurve.TangentType
Returns: Type of the tangent

Arguments:
	[in]	index = int


Determines the type of the tangent to the curve entering the current key.'''
        pass

    def addKey(self, unitlessInput, timeValue, tangentInType, tangentOutType, change): 
        '''addKey(self, unitlessInput, timeValue, tangentInType, tangentOutType, change) -> int
Returns: Index of added key

Arguments:
	[in]	unitlessInput = double
	[in]	timeValue = MTime
	[in]	tangentInType = MFnAnimCurve.TangentType
	[in]	tangentOutType = MFnAnimCurve.TangentType
	[in]	change = MAnimCurveChange


Adds a new key with the given output time value and tangent types at the specified unitless input for curves of type kAnimCurveUT.'''
        pass

    def setTangent(self, index, angle, weight, inTangent, change, convertUnits): 
        '''setTangent(self, index, angle, weight, inTangent, change, convertUnits)
Arguments:
	[in]	index = int
	[in]	angle = MAngle
	[in]	weight = double
	[in]	inTangent = bool
	[in]	change = MAnimCurveChange
	[in]	convertUnits = bool


Sets the tangent for the key at the specified index. If convertUnits is true (the default) the x value will be scaled by the current UI time units and the y value will be scaled by the relevant UI units for the output type of the animation curve (i.e. linear units for a curve that outputs linear data, and so on).'''
        pass

    def numKeys(self): 
        '''numKeys(self) -> int
Returns: Number of keys on the Anim Curve Node


Determines the number of keys on the Anim Curve Node.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def setOutTangentType(self, index, tangentType, change): 
        '''setOutTangentType(self, index, tangentType, change)
Arguments:
	[in]	index = int
	[in]	tangentType = MFnAnimCurve.TangentType
	[in]	change = MAnimCurveChange


Sets the type of the tangent to the curve leaving the key at the specified index.'''
        pass

    def isUnitlessInput(self): 
        '''isUnitlessInput(self) -> bool
Returns: Boolean value: true if the curve takes a unitless value as input, false otherwise.


Determines the input type of the animCurve.'''
        pass

    def outTangentType(self, index): 
        '''outTangentType(self, index) -> MFnAnimCurve.TangentType
Returns: Type of the tangent

Arguments:
	[in]	index = int


Determines the type of the tangent to the curve leaving the current key.'''
        pass

    def isStatic(self): 
        '''isStatic(self) -> bool
Returns: Boolean value: true if the curve is static, false otherwise


Determines whether or not the animCurve is static. The animCurve is considered to be static if it would return the same value regardless of the evaluation time. This basically means that the values of all the keys are the same and the y component of all the tangents is 0.'''
        pass

    def setValue(self, index, value, change): 
        '''setValue(self, index, value, change)
Arguments:
	[in]	index = int
	[in]	value = double
	[in]	change = MAnimCurveChange


Sets the value of the key at the specified index. This method should only be used on Anim Curves of type kAnimCurve*A, kAnimCurve*L or kAnimCurve*U.'''
        pass

    def isTimeInput(self): 
        '''isTimeInput(self) -> bool
Returns: Boolean value: true if the curve takes time as input false otherwise.


Determines the input type of the animCurve.'''
        pass

    def preInfinityType(self): 
        '''preInfinityType(self) -> MFnAnimCurve.InfinityType
Returns: The current preInfinityType for the curve


Determines the behaviour of the curve for the range occurring before the first key.'''
        pass

    def evaluate(self, atUnitlessInput, timeValue): 
        '''evaluate(self, atUnitlessInput, timeValue)
Arguments:
	[out]	atUnitlessInput = double
	[out]	timeValue = MTime


Determines the interpolated output value of Anim Curves of type kAnimCurveUT at the specified unitless input.'''
        pass

    def addKeys(self, timeArray, valueArray, tangentInType, tangentOutType, keepExistingKeys, change): 
        '''addKeys(self, timeArray, valueArray, tangentInType, tangentOutType, keepExistingKeys, change)
Arguments:
	[in]	timeArray = MTimeArray
	[in]	valueArray = MDoubleArray
	[in]	tangentInType = MFnAnimCurve.TangentType
	[in]	tangentOutType = MFnAnimCurve.TangentType
	[in]	keepExistingKeys = bool
	[in]	change = MAnimCurveChange


Add a set of new keys with the given corresponding values and tangent types at the specified times. This method only works for Anim Curves of type kAnimCurveTA, kAnimCurveTL and kAnimCurveTU.'''
        pass

    def setAngle(self, index, angle, inTangent, change): 
        '''setAngle(self, index, angle, inTangent, change)
Arguments:
	[in]	index = int
	[in]	angle = MAngle
	[in]	inTangent = bool
	[in]	change = MAnimCurveChange


Set the in- or out-angle of the tangent for the key at the given index'''
        pass

    def setTime(self, index, time, change): 
        '''setTime(self, index, time, change)
Arguments:
	[in]	index = int
	[in]	time = MTime
	[in]	change = MAnimCurveChange


Sets the time of the key at the specified index. This will fail if setting the time would require re-ordering of the keys. This method should only be used on Anim Curves of type kAnimCurveT*.'''
        pass

    def setUnitlessInput(self, index, unitlessInput, change): 
        '''setUnitlessInput(self, index, unitlessInput, change)
Arguments:
	[in]	index = int
	[in]	unitlessInput = double
	[in]	change = MAnimCurveChange


Sets the value of the unitless input of the key at the specified index. This will fail if setting the value would require re-ordering of the keys. This methid should only be used on Anim Curves of type kAnimCurveU*.'''
        pass

    def isBreakdown(self, index): 
        '''isBreakdown(self, index) -> bool
Returns: Boolean value: true if the key is a breakdown, false otherwise.

Arguments:
	[in]	index = int


Determines whether or not a key is a breakdown.'''
        pass

    def weightsLocked(self, index): 
        '''weightsLocked(self, index) -> bool
Returns: Boolean value: true if the weights are locked, false otherwise.

Arguments:
	[in]	index = int


Determines whether the weights are locked at the given key.'''
        pass

    def setWeight(self, index, weight, inTangent, change): 
        '''setWeight(self, index, weight, inTangent, change)
Arguments:
	[in]	index = int
	[in]	weight = double
	[in]	inTangent = bool
	[in]	change = MAnimCurveChange


Set the in- or out-weight of the tangent for the key at the given index'''
        pass

    def setWeightsLocked(self, index, locked, change): 
        '''setWeightsLocked(self, index, locked, change)
Arguments:
	[in]	index = int
	[in]	locked = bool
	[in]	change = MAnimCurveChange


Lock or unlock the weights at the given key.'''
        pass

    def remove(self, index, change): 
        '''remove(self, index, change)
Arguments:
	[in]	index = int
	[in]	change = MAnimCurveChange


Removes the key at the specified index.'''
        pass

    def postInfinityType(self): 
        '''postInfinityType(self) -> MFnAnimCurve.InfinityType
Returns: The current postInfinityType for the curve


Determines the behaviour of the curve for the range occurring after the last key.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def tangentsLocked(self, index): 
        '''tangentsLocked(self, index) -> bool
Returns: Boolean value: true if the tangents are locked, false otherwise.

Arguments:
	[in]	index = int


Determines whether the tangents are locked at the given key.'''
        pass

    def time(self, index): 
        '''time(self, index) -> MTime
Returns: Time (in seconds) of the key

Arguments:
	[in]	index = int


Determines the time of the key at the specified index.'''
        pass

    def kAnimCurveTU(self):
        '''This is an enum of AnimCurveType.
Description: Time to Unitless.
Value: 3'''
        pass

    def kAnimCurveTT(self):
        '''This is an enum of AnimCurveType.
Description: Time to Time.
Value: 2'''
        pass

    def kAnimCurveUnknown(self):
        '''This is an enum of AnimCurveType.
Description: Unknown type.
Value: 8'''
        pass

    def kAnimCurveUT(self):
        '''This is an enum of AnimCurveType.
Description: Unitless to Time.
Value: 6'''
        pass

    def kAnimCurveUU(self):
        '''This is an enum of AnimCurveType.
Description: Unitless to Unitless.
Value: 7'''
        pass

    def kAnimCurveTA(self):
        '''This is an enum of AnimCurveType.
Description: Time to Angular.
Value: 0'''
        pass

    def kAnimCurveUL(self):
        '''This is an enum of AnimCurveType.
Description: Unitless to Linear.
Value: 5'''
        pass

    def kAnimCurveTL(self):
        '''This is an enum of AnimCurveType.
Description: Time to Linear.
Value: 1'''
        pass

    def kAnimCurveUA(self):
        '''This is an enum of AnimCurveType.
Description: Unitless to Angular.
Value: 4'''
        pass

    class AnimCurveType:
        '''Non-functional class.  Values for this enum:
        kAnimCurveTU
        kAnimCurveTT
        kAnimCurveUnknown
        kAnimCurveUT
        kAnimCurveUU
        kAnimCurveTA
        kAnimCurveUL
        kAnimCurveTL
        kAnimCurveUA
'''
        def __init__(self):
            pass

    def unitlessInput(self, index): 
        '''unitlessInput(self, index) -> double
Returns: Input value at which the key is set

Arguments:
	[in]	index = int


Determines the unitless input value of the key at the specified index. This method should only be used on Anim Curves of type kAnimCurveU*.'''
        pass

    def setIsBreakdown(self, index, isBreakdown, change): 
        '''setIsBreakdown(self, index, isBreakdown, change)
Arguments:
	[in]	index = int
	[in]	isBreakdown = bool
	[in]	change = MAnimCurveChange


Sets the breakdown state of a key at a given index.'''
        pass

class MFnBlendShapeDeformer:
    '''blend shape deformer function set MFnBlendShapeDeformer is the function set for blend shape deformers. A blend shape deformer takes a base shape (polygonal surface, curve, surface, or lattice) and blends it with other target shapes based on weight values.The blend shape deformer is actually a small network of dependency nodes in the dependency graph. This function set is provided to make manipulation of the network easier. The main deformer node should be given to this function set as its object.There are three parts to a blend shape deformer. There are the base objects, the target objects, and the weight values.The base objects are the shapes that are to be deformed. There must be at least one base object. The base objects will change form as the targets and deformation parameters are modified.Each base object has a list of target objects that affect its shape. Each target is associated with one of the the deformer's weight values. When the weight value increases, the target has more influence on the base shape.There is just one array of weight values between all of the base objects and targets. So, it is possible for targets of different base objects to share the same weight index. When the weight value changes, it will affect all of the base objects that have targets using that weight value.It is also possible to chain together target shapes so that a base object will deform through each shape one at a time as the weight value increases. This is done by adding multiple targets to a base shape using the same weight index for all of them. When each target is added, a weight value is specified at which that target will be in full effect. Give each target a different full weight value.For example, one could take a sphere and make it blend into a cone and then into a cylinder. One way to do this is to make sphere the base shape. Then, add the cone as a target for the sphere at weight index 0 with a full effect weight of 0.5. Next, add the cylinder as a second target for the sphere also at weight index 0, but with a full effect weight of 1.0. Now, as the weight goes from 0 to 1, the base shape will start as a sphere, morph into a cone, and then into a cylinder.It is not necessary for the base shape and its targets to have identical vertex/CV counts, but the blend will be more effective if they do. '''
    def __init__(self):
        pass


    def kLocalOrigin(self):
        '''This is an enum of Origin.
Description: 
Value: 0'''
        pass

    def kWorldOrigin(self):
        '''This is an enum of Origin.
Description: 
Value: 1'''
        pass

    class Origin:
        '''Non-functional class.  Values for this enum:
        kLocalOrigin
        kWorldOrigin
'''
        def __init__(self):
            pass

    def origin(self): 
        '''origin(self) -> MFnBlendShapeDeformer.Origin
Returns: The origin space


Gets the origin space. It defines the point around which the differences in the geometry are calculated.'''
        pass

    def addBaseObject(self, object): 
        '''addBaseObject(self, object)
Arguments:
	[in]	object = MObject


Adds a new base object to the deformer. This object will be deformed as targets are added for it and the deformation parameters change.'''
        pass

    def addTarget(self, baseObject, weightIndex, newTarget, fullWeight): 
        '''addTarget(self, baseObject, weightIndex, newTarget, fullWeight)
Arguments:
	[in]	baseObject = MObject
	[in]	weightIndex = int
	[in]	newTarget = MObject
	[in]	fullWeight = double


Adds a new target object for the given base object. The weight index says which of the deformer's weight values will control this target's affects on the base object. The full weight argument determines at what weight the target is in full effect. If a base object has no other targets and the weight is set to the 'full weight', then the base object will look just like the target object.'''
        pass

    def weight(self, index): 
        '''weight(self, index) -> float
Returns: The weight value

Arguments:
	[in]	index = int


Get the weight value at the given index. To be valid, a weight value should only be requested at index values returned by  MFnBlendShapeDeformer::weightIndexList .'''
        pass

    def removeTarget(self, baseObject, weightIndex, target, fullWeight): 
        '''removeTarget(self, baseObject, weightIndex, target, fullWeight)
Arguments:
	[in]	baseObject = MObject
	[in]	weightIndex = int
	[in]	target = MObject
	[in]	fullWeight = double


Remove a target object for the given base object. The weight index specifies the index at which target is connected. The full weight argument specifies at what weight the target is in full effect.'''
        pass

    def numWeights(self): 
        '''numWeights(self) -> int
Returns: The number of weight indices


Return the number of weight values that this blend shape deformer has. The number of weight values is equal to the number of targets. Targets are either shapes in the dag or baked data on the blendShape node (when a target shape is deleted).'''
        pass

    def kNormal(self):
        '''This is an enum of HistoryLocation.
Description: 
Value: 1'''
        pass

    def kFrontOfChain(self):
        '''This is an enum of HistoryLocation.
Description: 
Value: 0'''
        pass

    class HistoryLocation:
        '''Non-functional class.  Values for this enum:
        kNormal
        kFrontOfChain
'''
        def __init__(self):
            pass

    def getTargets(self, baseObject, weightIndex, targetObjects): 
        '''getTargets(self, baseObject, weightIndex, targetObjects)
Arguments:
	[in]	baseObject = MObject
	[in]	weightIndex = int
	[out]	targetObjects = MObjectArray


Get a list of all of the target objects for the given base object that affect it based on the given weight index.'''
        pass

    def setEnvelope(self, envelope): 
        '''setEnvelope(self, envelope)
Arguments:
	[in]	envelope = float


Sets the envelope value of the deformer.'''
        pass

    def setOrigin(self, space): 
        '''setOrigin(self, space)
Arguments:
	[in]	space = MFnBlendShapeDeformer.Origin


Sets the origin space. It defines the point around which the differences in the geometry are calculated.'''
        pass

    def weightIndexList(self, indexList): 
        '''weightIndexList(self, indexList)
Arguments:
	[out]	indexList = MIntArray


Return the array index numbers corresponding to the targets. The resulting index list will be the length of MFnBlendShape::numWeights. This method exists because the indices of the targets can be sparse. For example, if a target has been removed using Deform -> Edit BlendShape -> Remove.'''
        pass

    def targetItemIndexList(self, targetIndex, baseObject, inbetweens): 
        '''targetItemIndexList(self, targetIndex, baseObject, inbetweens)
Arguments:
	[in]	targetIndex = int
	[in]	baseObject = MObject
	[in]	inbetweens = MIntArray


Return the "inputTargetItem" array indices for the specified target. The "inputTargetItem" array indices correspond to the weight where the targets take affect according to the formula: index = wt * 1000 + 5000. For example, if you have only a single target, and no in-betweens, the index will typically be 6000 since the default weight for the initial target is 1.0.'''
        pass

    def setWeight(self, index, weight): 
        '''setWeight(self, index, weight)
Arguments:
	[in]	index = int
	[in]	weight = float


Set the weight value at the given index.'''
        pass

    def envelope(self): 
        '''envelope(self) -> float
Returns: Envelope value


Gets the envelope value of the deformer.'''
        pass

    def getBaseObjects(self, objects): 
        '''getBaseObjects(self, objects)
Arguments:
	[out]	objects = MObjectArray


Get a list of all of the base objects for this deformer. The objects returned will be the deformed versions of the base objects.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def create(self, baseObjects, originSpace, historyLoc): 
        '''create(self, baseObjects, originSpace, historyLoc) -> MObject
Returns: A handle to the new deformer

Arguments:
	[in]	baseObjects = MObjectArray
	[in]	originSpace = MFnBlendShapeDeformer.Origin
	[in]	historyLoc = MFnBlendShapeDeformer.HistoryLocation


Creates a new blend shape deformer in the dependency graph. This method differs from the other  MFnBlendShapeDeformer::create  in that it allows multiple base shapes to be supplied at create time and it allows the use of the front-of-chain history location, which puts the blendShape ahead of other deformers such as skinning deformers.'''
        pass

class MFnCharacter:
    '''Function Set for Characters. Maya offers "character" nodes to simplify the setting of keyframes on collections of attributes. The implementation of the "character" is a sub-class of MFnSet taking advantage of the fact that attributes can be represented as MObjects and can be made members of a set. The fact that sets also derive from MObject means that characters may have other character sets as members thus establishing a hierarchy. Only attributes and characters can be members of a character set. The character node will disallow the addition of other objects to its set.Character sets are also part of a partition, meaning that membership of character sets cannot overlap with other character sets. Thus, when an attribute already in a character is added to another character it must be removed from the original character.Characters are integral to Maya's nonlinear animation system, "Trax". Trax allows the user to create "animation clips", which bundle a set of animation curves so that they can be reused multiple times, with different timing then the original clip. When a clip is created, Maya finds the the animation curves that are attached to the attributes in the character set and moves those animation curves into the newly created clip. The MFnClip function set is the Maya function set for clips.Clips in maya can be of two types: source clips and scheduled clips. In the Maya UI, source clips are visible in the Visor while scheduled clips are visible in Trax. A source clip contains the animation curves for the clip. An scheduled clip contains data about the placement of an instance of a source clip in the Maya timeline. In this context, an "instance" means that the animation curves from the source clip are shared by the scheduled clip. Scheduled clips never contain their own animation curves, they always refer to a source clip's curves.For example, if you create a clip called "run" in maya that lasts from frames 1-20, a source clip node will be created with a start of 1, a duration of 19, and dependency graph connections to all of the animation curves that make up the "run". If you then place an instance of the run clip at frame 5 and another instance of the run clip at frame 20, you have 2 scheduled clips: one with a start frame of 5 and one with a start frame of 20. As mentioned in the previous paragraph, only a single set of animation curves exist for the run regardless of the number of times the run is scheduled.Trax also allows you to create "blends" between clips, which enable you to control the transition between the clips. A blend is represented in the dependency graph by an "animBlendInOut" node, which uses an animation curve to determine the transition type.In the dependency graph, when a character has animation clips, the character node will always be connected to a "clipLibrary" node and a "clipScheduler" node. The clipLibrary node is connected to all of the source clips and their animation curves. The clipScheduler node is connected to the scheduled clips and blends. It is the clipScheduler that computes the final animation by looking at the placement and overlap of the clips and feeding the attribute data back into the character set. '''
    def __init__(self):
        pass


    def getBlend(self, index): 
        '''getBlend(self, index) -> MObject

Arguments:
	[in]	index = int


Return the animBlendInOut node corresponding to the specified index.'''
        pass

    def getSourceClip(self, index): 
        '''getSourceClip(self, index) -> MObject

Arguments:
	[in]	index = int


Return the animClip node corresponding to the specified index. The animClip node will be a source clip node. The specified index should range from 0 to clipCount-1 where clipCount is the value returned by  MFnCharacter::getSourceClipCount .'''
        pass

    def blendExists(self, instancedClip1, instancedClip2, blendResult): 
        '''blendExists(self, instancedClip1, instancedClip2, blendResult) -> bool
Returns: true, if a blend was found between the two clips

Arguments:
	[in]	instancedClip1 = MObject
	[in]	instancedClip2 = MObject
	[in]	blendResult = MObject


Return true if a blend exists between the two instanced clips on the character. If a blend exists, the animBlend node related to the blend is also returned.'''
        pass

    def attachInstanceToCharacter(self, instanceClip, dgMod): 
        '''attachInstanceToCharacter(self, instanceClip, dgMod)
Arguments:
	[in]	instanceClip = MObject
	[in]	dgMod = MDGModifier


Attaches an instance of a clip to the character. If the source clip related to the clip instance is not already attached to the character, it will be attached as well.'''
        pass

    def getScheduledClipCount(self): 
        '''getScheduledClipCount(self) -> int
Returns: Number of clips scheduled on this character


Return the number of clips that have been scheduled on this character.'''
        pass

    def getSubCharacters(self, result): 
        '''getSubCharacters(self, result)
Arguments:
	[out]	result = MSelectionList


Get a list of the subcharacters that are members of the character set.'''
        pass

    def attachSourceToCharacter(self, sourceClip, dgMod): 
        '''attachSourceToCharacter(self, sourceClip, dgMod)
Arguments:
	[in]	sourceClip = MObject
	[in]	dgMod = MDGModifier


Attaches a given source clip node (created using  MFnClip::createSourceClip ) to the character's clipLibrary. Attaches a clipLibrary and clipScheduler to the character if they are not attached already.'''
        pass

    def getClipScheduler(self): 
        '''getClipScheduler(self) -> MObject
Returns: MObject containing a clipScheduler node


Get the clipScheduler node that manages the playback of clips on this character. If no clips have been created for this character, this method will return an empty  MObject .'''
        pass

    def getBlendCount(self): 
        '''getBlendCount(self) -> int
Returns: Number of blends on clips in this character


Return the number of blends that have been added to clips on this character.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getScheduledClip(self, index): 
        '''getScheduledClip(self, index) -> MObject

Arguments:
	[in]	index = int


Return the scheduled animClip node corresponding to the specified index. The specified index should range from 0 to clipCount-1 where clipCount is the value returned by  MFnCharacter::getScheduledClipCount .'''
        pass

    def addCurveToClip(self, curve, sourceClip, plug, dgMod): 
        '''addCurveToClip(self, curve, sourceClip, plug, dgMod)
Arguments:
	[in]	curve = MObject
	[in]	sourceClip = MObject
	[in]	plug = MPlug
	[in]	dgMod = MDGModifier


Adds an animation curve to a clip. The user must provide the animation curve, and the related source clip node (typically created using MFnCharacter::createSourceClip). The user must also specify the plug that the clip will drive. The plug must be a member of the character managed by this  MFnCharacter .'''
        pass

    def createBlend(self, instancedClip1, instancedClip2, blendAnimCurve, dgMod): 
        '''createBlend(self, instancedClip1, instancedClip2, blendAnimCurve, dgMod) -> MObject
Returns: The resulting animBlend node

Arguments:
	[in]	instancedClip1 = MObject
	[in]	instancedClip2 = MObject
	[in]	blendAnimCurve = MObject
	[in]	dgMod = MDGModifier


Creates a blend between two instanced clips on the character. The blend is defined by a specified paramCurve, which should be keyed between times of 0 and 1. Time 0 corresponds to the start time of the blend. Time 1 corresponds to the end time of the blend. The blend will be performed on the clips according to the keyed value of the blend curve, using the equation: (value)*clip1 + (1-value)*clip2. For example, let's say the blend curve goes from a value of (0,0) to (1,1). At the start of the blend you will have 100% of clip1, and 0% of clip2. At the end of the blend you will have 0% of clip1, and 100% of clip2.'''
        pass

    def getBlendClips(self, index, clip1, clip2): 
        '''getBlendClips(self, index, clip1, clip2)
Arguments:
	[in]	index = int
	[out]	clip1 = MObject
	[out]	clip2 = MObject


Returns the clip nodes that are blended by the blend node corresponding to the specified index.'''
        pass

    def getSourceClipCount(self): 
        '''getSourceClipCount(self) -> int
Returns: Number of source clips owned by the library on this character


Return the number of source clips managed by the clipLibrary node of this character. For more information on source clips, refer to the description of the  MFnCharacter  node.'''
        pass

    def getCharacterThatOwnsPlug(self, plug, result): 
        '''getCharacterThatOwnsPlug(self, plug, result) -> bool
Returns: true, if the plug is in a character 

Arguments:
	[in]	plug = MPlug
	[in]	result = MObject


Given a plug, test the plug to see if it is owned by a character. If a character controls this plug, the character will be returned'''
        pass

    def removeBlend(self, instancedClip1, instancedClip2, dgMod): 
        '''removeBlend(self, instancedClip1, instancedClip2, dgMod) -> bool
Returns: true, if a blend was found and deleted 

Arguments:
	[in]	instancedClip1 = MObject
	[in]	instancedClip2 = MObject
	[in]	dgMod = MDGModifier


Remove the blend between the two instanced clips on the character. If a blend exists and was deleted, returns true. If a blend did not exist, returns false.'''
        pass

    def getMemberPlugs(self, result): 
        '''getMemberPlugs(self, result)
Arguments:
	[out]	result = MPlugArray


Get the members of the character set that are attributes. Return them as a plug array. A character set can contain only attributes and subcharacters. To get all of the members of the character, use  MFnSet::getMembers . To get the subcharacters, use MFnCharacter::getSubcharacters.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnClip:
    '''clip function set Maya uses animation clips as the building block of its nonlinear animation system, "Trax". An animation clip allows the user to bundle a set of animation curves independent of time so that they can be reused multiple times, with different timing then the original clip.Character sets (MFnCharacter) are integral to Maya's clip architecture, since a clip contains whatever attributes of the character were animated when the clip was created. For more information on character sets, refer to the MFnCharacter documentation.Clips in maya can be of two types: source clips and scheduled clips. In the Maya UI, source clips are visible in the Visor while scheduled clips are visible in Trax. A source clip contains the animation curves for the clip. A scheduled clip contains data about the placement of an instance of a source clip in the Maya timeline. In this context, an "instance" means that the animation curves from the source clip are shared by the scheduled clip. Scheduled clips never contain their own animation curves, they always refer to a source clip's curves.For example, if you create a clip called "run" in maya that lasts from frames 1-20, a source clip node will be created with a start of 1, a duration of 19, and dependency graph connections to all of the animation curves that make up the "run". If you then place an instance of the run clip at frame 5 and another instance of the run clip at frame 20, you have 2 scheduled clips: one with a start frame of 5 and one with a start frame of 20. As mentioned in the previous paragraph, only a single set of animation curves exist for the run regardless of the number of times the run is scheduled.Trax also allows you to create "blends" between clips, which enable you to control the transition between the clips. A blend is represented in the dependency graph by an "animBlendInOut" node, which uses an animation curve to determine the transition type.In the dependency graph, when a character has animation clips, the character node will always be connected to a "clipLibrary" node and a "clipScheduler" node. The clipLibrary node is connected to all of the source clips and their animation curves. The clipScheduler node is connected to the scheduled clips and blends. It is the clipScheduler that computes the final animation by looking at the placement and overlap of the clips and feeding the attribute data back into the character set.To create a source clip, the typical steps are:To create a scheduled clip so that it appears in the Trax Editor, the typical steps are:'''
    def __init__(self):
        pass


    def setPreCycle(self, cycle, mod): 
        '''setPreCycle(self, cycle, mod)
Arguments:
	[in]	cycle = double
	[in]	mod = MDGModifier


Specify the pre cycle value for the clip.'''
        pass

    def createInstancedClip(self, sourceClip, start, dgMod, absolute, postCycle, weight, scale, preCycle): 
        '''createInstancedClip(self, sourceClip, start, dgMod, absolute, postCycle, weight, scale, preCycle) -> MObject
Returns: The newly created clip.

Arguments:
	[in]	sourceClip = MObject
	[in]	start = MTime
	[in]	dgMod = MDGModifier
	[in]	absolute = bool
	[in]	postCycle = double
	[in]	weight = double
	[in]	scale = double
	[in]	preCycle = double


Creates an instance of a clip that will be viewable in the Trax editor.'''
        pass

    def getTrack(self): 
        '''getTrack(self) -> int
Returns: The index of this clip's track


Return the track number for the clip. Track indices are one-based. If a track index of zero is returned, it indicates that a track has not yet been assigned to the clip.'''
        pass

    def setPoseClip(self, state, mod): 
        '''setPoseClip(self, state, mod)
Arguments:
	[in]	state = bool
	[in]	mod = MDGModifier


Specify whether or not this clip node should be tagged as a pose rather than a clip. By default, clip nodes are not poses.'''
        pass

    def setScale(self, scale, mod): 
        '''setScale(self, scale, mod)
Arguments:
	[in]	scale = double
	[in]	mod = MDGModifier


Specify a scale value for the clip.'''
        pass

    def setPostCycle(self, cycle, mod): 
        '''setPostCycle(self, cycle, mod)
Arguments:
	[in]	cycle = double
	[in]	mod = MDGModifier


Specify the post cycle value for the clip.'''
        pass

    def getAbsoluteChannelSettings(self, absoluteChannels): 
        '''getAbsoluteChannelSettings(self, absoluteChannels)
Arguments:
	[out]	absoluteChannels = MIntArray


Return an array indicating which channels of the clip are absolute and which are relative. The length of the array is equal to the members in the character. A value of one in the array indicates absolute and a value of 0 indicates relative.'''
        pass

    def setSourceData(self, start, duration, mod): 
        '''setSourceData(self, start, duration, mod)
Arguments:
	[in]	start = MTime
	[in]	duration = MTime
	[in]	mod = MDGModifier


Specify the start frame and duration for the source clip associated with this clip.'''
        pass

    def isPose(self): 
        '''isPose(self) -> bool
Returns: True or false as to whether the clip is a pose.


Return true or false as to whether the clip node represents a pose.'''
        pass

    def getStartFrame(self): 
        '''getStartFrame(self) -> MTime
Returns: The value of this clip's start frame.


Return the value of this clip's start frame'''
        pass

    def sourceClip(self): 
        '''sourceClip(self) -> MObject
Returns: MObject containing the associated source clip.


Return the source clip associated with the MFnClip's clip'''
        pass

    def createSourceClip(self, sourceStart, sourceDuration, dgMod): 
        '''createSourceClip(self, sourceStart, sourceDuration, dgMod) -> MObject
Returns: The newly created clip.

Arguments:
	[in]	sourceStart = MTime
	[in]	sourceDuration = MTime
	[in]	dgMod = MDGModifier


Creates a source clip node and associates it with this function set. Each animation clip has a single source clip, which defines the startFrame and duration of the clip's animation curves. The startFrame and duration act as a window onto the animation curves, defining the range of animation that is considered part of the clip. After a source clip node is created, it can be passed to a  MFnCharacter  along with the clip animCurves in order to associate the clip with the character.'''
        pass

    def getSourceDuration(self): 
        '''getSourceDuration(self) -> MTime
Returns: The value of this clip's source duration.


Return the value of the start frame of this clip's source duration. The sourceStart and sourceDuration define the region of the animCurve that is treated as the clip.'''
        pass

    def setAbsoluteChannelSettings(self, absoluteChannels, mod): 
        '''setAbsoluteChannelSettings(self, absoluteChannels, mod)
Arguments:
	[in]	absoluteChannels = MIntArray
	[in]	mod = MDGModifier


Set which channels of the clip are absolute and which are relative. The length of the specified array should be equal to the number of members in the character. A value of one in the array indicates absolute and a value of 0 indicates relative.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getWeight(self): 
        '''getWeight(self) -> double
Returns: The value of this clip's weight attribute.


Return the value of this clip's weight attribute'''
        pass

    def setEnabled(self, val, mod): 
        '''setEnabled(self, val, mod)
Arguments:
	[in]	val = bool
	[in]	mod = MDGModifier


Specify whether or not the clip is enabled. Note: should not be called for source clips since the enabled attribute is ignored on source clips.'''
        pass

    def getPostCycle(self): 
        '''getPostCycle(self) -> double
Returns: The value of this clip's post cycle attribute.


Return the value of this clip's post cycle attribute'''
        pass

    def getMemberAnimCurves(self, curves, associatedAttrs): 
        '''getMemberAnimCurves(self, curves, associatedAttrs)
Arguments:
	[out]	curves = MObjectArray
	[out]	associatedAttrs = MPlugArray


Return two arrays: the first contains the animCurves associated with this clip. The second contains the character member that is driven by this animCurve.'''
        pass

    def getScale(self): 
        '''getScale(self) -> double
Returns: The value of this clip's scale attribute.


Return the value of this clip's scale attribute'''
        pass

    def setTrack(self, trackIndex, mod): 
        '''setTrack(self, trackIndex, mod)
Arguments:
	[in]	trackIndex = int
	[in]	mod = MDGModifier


Specify the one-based track number for the clip.'''
        pass

    def getPreCycle(self): 
        '''getPreCycle(self) -> double
Returns: The value of this clip's pre cycle attribute.


Return the value of this clip's pre cycle attribute'''
        pass

    def isInstancedClip(self): 
        '''isInstancedClip(self) -> bool
Returns: True or false as to whether the clip is an instanced clip.


Return true or false as to whether the clip node represents the source clip or an instanced clip. All clips maintained by the clipScheduler node and visible in the TraX editor are instanced clips. All clips maintained by the clipLibrary node and visible in the Visor are non-instanced clips, also called "Source Clips". Each instanced clip has a corresponding source clip.'''
        pass

    def setWeight(self, wt, mod): 
        '''setWeight(self, wt, mod)
Arguments:
	[in]	wt = double
	[in]	mod = MDGModifier


Specify a weight value for the clip.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getEnabled(self): 
        '''getEnabled(self) -> bool
Returns: The value of this clip's enable attribute.


Return the value of this clip's enable attribute'''
        pass

    def getSourceStart(self): 
        '''getSourceStart(self) -> MTime
Returns: The value of this clip's source start frame.


Return the value of the start frame of this clip's source clip. The sourceStart and sourceDuration define the region of the animCurve that is treated as the clip.'''
        pass

    def setStartFrame(self, start, mod): 
        '''setStartFrame(self, start, mod)
Arguments:
	[in]	start = MTime
	[in]	mod = MDGModifier


Specify the start frame for the instanced clip. Note: should not be called for source clips since the start frame attribute is ignored on source clips.'''
        pass

class MFnGeometryFilter:
    '''geometry filter function set MFnGeometryFilter is the function set for geometry filters, the node that is the base class for deformers. Geometry filter nodes include clusters, ffds, nonlinears, user-defined deformers, sculpts, wires and blendShapes. The purpose of the geometry filter is to connect to the geometry that is deformed. The geometry filter is independent of any algorithm that calculates the deformation.This function set provides methods for finding out which geometries are connected to geometry filter nodes. '''
    def __init__(self):
        pass


    def getInputGeometry(self, geomList): 
        '''getInputGeometry(self, geomList)
Arguments:
	[out]	geomList = MObjectArray


This method returns the input geometry for the deformer by traversing the graph to find upstream shape nodes. It is possible for there to be nodes in between the shape and the deformer so that the returned shape may have a different topology or tweaks then the input data to the deformer. If the actual input geometry data for the deformer is required, this information can be accessed by using  MPlug::getValue()  to query the inputGeometry attribute on the deformer.'''
        pass

    def indexForGroupId(self, groupId): 
        '''indexForGroupId(self, groupId) -> int
Returns: The plug index corresponding to the groupId

Arguments:
	[in]	groupId = int


Returns the plug index corresponding to the groupId.'''
        pass

    def groupIdAtIndex(self, index): 
        '''groupIdAtIndex(self, index) -> int
Returns: The groupId at the specified index

Arguments:
	[in]	index = int


Returns the groupId at the specified plug index.'''
        pass

    def indexForOutputConnection(self, connectionIndex): 
        '''indexForOutputConnection(self, connectionIndex) -> int
Returns: The plug index corresponding to the connection index

Arguments:
	[in]	connectionIndex = int


Returns the plug index corresponding to the connection index. The connection index is the index specifying the nth output connection. The plug index (logical index) is the sparse array index used by many of MFnGeometryFilter's methods and in MEL scripts. The connection index is 0-based, hence, the maximum value of the connection index is numOutputs - 1.'''
        pass

    def outputShapeAtIndex(self, index): 
        '''outputShapeAtIndex(self, index) -> MObject
Returns: The output shape corresponding to the plug index

Arguments:
	[in]	index = int


Returns the output shape corresponding to the plug index'''
        pass

    def envelope(self): 
        '''envelope(self) -> float
Returns: The envelope value


Returns the envelope value.'''
        pass

    def getOutputGeometry(self, geomList): 
        '''getOutputGeometry(self, geomList)
Arguments:
	[out]	geomList = MObjectArray


The output geometry is packed into the provided list of MObjects. Each of the MObjects will be a DAG node.'''
        pass

    def setEnvelope(self, envelope): 
        '''setEnvelope(self, envelope)
Arguments:
	[in]	envelope = float


Sets the envelope value.'''
        pass

    def inputShapeAtIndex(self, index): 
        '''inputShapeAtIndex(self, index) -> MObject
Returns: The input shape corresponding to the plug index

Arguments:
	[in]	index = int


Returns the input shape corresponding to the plug index.'''
        pass

    def numOutputConnections(self): 
        '''numOutputConnections(self) -> int
Returns: The number of outputs


Returns the number of output geometries connected to this node. This is typically equal to the number of input geometries unless an input or output geometry has been deleted, or a connection to an input or output geometry has been broken.'''
        pass

    def getPathAtIndex(self, index, dagPath): 
        '''getPathAtIndex(self, index, dagPath)
Arguments:
	[in]	index = int
	[out]	dagPath = MDagPath


The DAG path of the output geometry at the specified plug index is put in the dagPath argument.'''
        pass

    def indexForOutputShape(self, shape): 
        '''indexForOutputShape(self, shape) -> int
Returns: The plug index leading to the specified shape

Arguments:
	[in]	shape = MObject


Returns the plug index for the specified output shape.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def deformerSet(self): 
        '''deformerSet(self) -> MObject
Returns: The set containing the objects that are deformed


Returns the set containing the objects that are deformed. Adding new components to the deformer set will cause them to be deformed. Removing components from the deformer set will prevent them from being influenced by the deformer.'''
        pass

class MFnHikEffector:
    '''Full Body IK end effector function set. MFnHikEffector is the function set for full body ik effectors. An Full Body IK (FBIK/HIK) effector is a special transform that allows users to manipulate a Full Body IK system.The methods of the parent class MFnTransform used to position the end effector. '''
    def __init__(self):
        pass


    def getAuxiliaryEffectors(self, effs): 
        '''getAuxiliaryEffectors(self, effs)
Arguments:
	[out]	effs = MObjectArray


Returns an array of the auxiliary effectors associated with this effector. Auxiliary effectors are used by humanIK to act as additional pivots.'''
        pass

    def setEffColor(self, color): 
        '''setEffColor(self, color)
Arguments:
	[in]	color = MColor


Set the humanIK color for this effector.'''
        pass

    def create(self, parent): 
        '''create(self, parent) -> MObject
Returns: A handle to the new object

Arguments:
	[in]	parent = MObject


Creates a new fbik effector.'''
        pass

    def getEffColor(self): 
        '''getEffColor(self) -> MColor
Returns: Pivot offset vector.


Retrieve the cached humanIK color of this effector.'''
        pass

    def getPivotOffset(self): 
        '''getPivotOffset(self) -> MVector
Returns: Pivot offset vector.


Retrieve the pivot offset of this effector.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def setPivotOffset(self, vector): 
        '''setPivotOffset(self, vector)
Arguments:
	[in]	vector = MVector


Set the pivot offset for this effector.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnIkEffector:
    '''Inverse kinematics end effector function set. MFnIkEffector is the function set for inverse kinematic end effectors. An end effector is a point on the skeleton, usually the last bone. When an IK system solves, it is trying to calculate the rotations on the joints necessary to get the end effector to the target point.The methods of the parent class MFnTransform used to position the end effector. '''
    def __init__(self):
        pass


    def className(self): 
        '''className(self) -> char*

'''
        pass

    def create(self, parent): 
        '''create(self, parent) -> MObject
Returns: A handle to the new object

Arguments:
	[in]	parent = MObject


Creates a new end effector. For the effector to work properly, it should be given a joint as the parent. It should be given the joint before the last bone.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnIkHandle:
    '''Function set for inverse kinematics (IK) handles. This is the function set for inverse kinematics (IK) handles. An ik handle specifies the joints in a skeleton that are effected by an attached ik solver. '''
    def __init__(self):
        pass


    def priority(self): 
        '''priority(self) -> int
Returns: The priority of this handle


Get the priority of this handle in case a solution is affected by more than one handle.'''
        pass

    def stickiness(self): 
        '''stickiness(self) -> MFnIkHandle.Stickiness
Returns: The stickiness value for this handle.


Get the stickiness of this handle.'''
        pass

    def weight(self): 
        '''weight(self) -> double
Returns: The weight value for this handle


Get the handles weight in error calculations. The weight only applies when handle goals are in conflict and cannot be solved simultaneously. When this happens, a solution is computed that weights the "distance" from each goal to the solution by the handle's weight and attempts to minimize this value. The weight must be >= 0.'''
        pass

    def getEffector(self, effectorPath): 
        '''getEffector(self, effectorPath)
Arguments:
	[out]	effectorPath = MDagPath


Get a dag path to the end-effector of the handle's joint chain.'''
        pass

    def setPriority(self, priority): 
        '''setPriority(self, priority)
Arguments:
	[in]	priority = int


Set the priority of this handle in case a solution is affected by more than one handle'''
        pass

    def setWeight(self, weight): 
        '''setWeight(self, weight)
Arguments:
	[in]	weight = double


Specifies the handles weight in error calculations. The weight only applies when handle goals are in conflict and cannot be solved simultaneously. When this happens, a solution is computed that weights the "distance" from each goal to the solution by the handle's weight and attempts to minimize this value. The weight must be >= 0.'''
        pass

    def create(self, startJoint, effector): 
        '''create(self, startJoint, effector) -> MObject

Arguments:
	[in]	startJoint = MDagPath
	[in]	effector = MDagPath


Creates a new ik handle. The effector and startJoint specify the joint chain controlled by this handle. The effector is the joint that is moved by the handle forcing the solver to recalculate the joint chain.'''
        pass

    def solver(self): 
        '''solver(self) -> MObject
Returns: The solver associated with this handle


Returns the solver attached to this handle.'''
        pass

    def setStartJointAndEffector(self, jointPath, effectorPath): 
        '''setStartJointAndEffector(self, jointPath, effectorPath)
Arguments:
	[in]	jointPath = MDagPath
	[in]	effectorPath = MDagPath


This method will set the dag path for the starting joint and the end-effector of the handle's joint chain. This method must be used when setting the joints for a handle that are in a different skeletal chain then the current one.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def setSolver(self, solverName): 
        '''setSolver(self, solverName)
Arguments:
	[in]	solverName = MString


Set the solver associated with this handle by name.'''
        pass

    def setEffector(self, effectorPath): 
        '''setEffector(self, effectorPath)
Arguments:
	[in]	effectorPath = MDagPath


Set the dag path to the end-effector of the handle's joint chain. The end-effector/joint must be on the same skeletal chain as the start joint or this method will fail.'''
        pass

    def setStartJoint(self, jointPath): 
        '''setStartJoint(self, jointPath)
Arguments:
	[in]	jointPath = MDagPath


This method will set the dag path for the starting joint of the handle's joint chain. The start joint must be on the same skeletal chain as the end effector or this method will fail.'''
        pass

    def poWeight(self): 
        '''poWeight(self) -> double
Returns: The position/orientation weight


Gets the position/orientation weight of a handle. This is used to compute the "distance" between the goal position and the end-effector position.'''
        pass

    def setStickiness(self, stickiness): 
        '''setStickiness(self, stickiness)
Arguments:
	[in]	stickiness = MFnIkHandle.Stickiness


Set the stickiness of this handle. Sticky handles are solved when the skeleton is being manipulated interactively. If a character has sticky feet, the solver will attempt to keep them in the same position as the user moves the character's root. If they were not sticky, they would move along with the root.'''
        pass

    def getStartJoint(self, jointPath): 
        '''getStartJoint(self, jointPath)
Arguments:
	[out]	jointPath = MDagPath


This method will get a dag path to the starting joint of the handle's joint chain.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def kStickyOff(self):
        '''This is an enum of Stickiness.
Description: Handle will move with skeleton's root.
Value: 0'''
        pass

    def kStickyOn(self):
        '''This is an enum of Stickiness.
Description: Handle will try to stay where it is.
Value: 1'''
        pass

    def kSuperSticky(self):
        '''This is an enum of Stickiness.
Description: Not used.
Value: 2'''
        pass

    class Stickiness:
        '''Non-functional class.  Values for this enum:
        kStickyOff
        kStickyOn
        kSuperSticky
'''
        def __init__(self):
            pass

    def setPOWeight(self, poWeight): 
        '''setPOWeight(self, poWeight)
Arguments:
	[in]	poWeight = double


Sets the position/orientation weight of a handle. This is used to compute the "distance" between the goal position and the end-effector position.'''
        pass

class MFnIkJoint:
    '''Function set for joints. This is the function set for joints.The transformation matrix for a joint node is below.(where '*' denotes matrix multiplication).These matrices are defined as follows:The methods to get the value of these matrices are:'''
    def __init__(self):
        pass


    def maxRotateDampXStrength(self): 
        '''maxRotateDampXStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def maxRotateDampYStrength(self): 
        '''maxRotateDampYStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def setMaxRotateDampYRange(self, angle): 
        '''setMaxRotateDampYRange(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping range in Y'''
        pass

    def maxRotateDampZRange(self): 
        '''maxRotateDampZRange(self) -> double
Returns: The maximum of the damping range in Z


Get the maximum of the damping range in Z. This corresponds to the maxRotateDampZRange attribute on the joint.'''
        pass

    def getOrientation(self, rotation, order): 
        '''getOrientation(self, rotation, order)
Arguments:
	[out]	rotation = double3
	[out]	order = MTransformationMatrix.RotationOrder


Get the orientation of the coordinate axes.'''
        pass

    def setMinRotateDampXStrength(self, angle): 
        '''setMinRotateDampXStrength(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping strength in Z.'''
        pass

    def setMinRotateDampYRange(self, angle): 
        '''setMinRotateDampYRange(self, angle)
Arguments:
	[in]	angle = double


Set the minimum of the damping range in Y'''
        pass

    def setMinRotateDampZRange(self, angle): 
        '''setMinRotateDampZRange(self, angle)
Arguments:
	[in]	angle = double


Set the minimum of the damping range in Z'''
        pass

    def setPreferedAngle(self, rotation): 
        '''setPreferedAngle(self, rotation)
Arguments:
	[in]	rotation = double3


Set the preferred orientation for this joint (in XYZ order)'''
        pass

    def maxRotateDampZStrength(self): 
        '''maxRotateDampZStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def setMinRotateDampZStrength(self, angle): 
        '''setMinRotateDampZStrength(self, angle)
Arguments:
	[in]	angle = double


Set the minimum of the damping strength in Z.'''
        pass

    def create(self, parent): 
        '''create(self, parent) -> MObject
Returns: The parent transform of the new joint

Arguments:
	[in]	parent = MObject


Create a new joint in a skeleton. In maya, skeletons are defined entirely by DAG hierarchy. So, giving the joint you want to attach to as a parent will add this joint to that skeleton.'''
        pass

    def minRotateDampXStrength(self): 
        '''minRotateDampXStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def getSegmentScale(self, scale): 
        '''getSegmentScale(self, scale)
Arguments:
	[out]	scale = double3


Get the local space scale values for the joint segment (bone). This is equivalent to calling  MFnTransform::getScale .'''
        pass

    def getPreferedAngle(self, rotation): 
        '''getPreferedAngle(self, rotation)
Arguments:
	[out]	rotation = double3


Get the preferred orientation for this joint (in XYZ order)'''
        pass

    def minRotateDampZRange(self): 
        '''minRotateDampZRange(self) -> double
Returns: The minimum damping range in Z


Get the minimum of the damping range in Z. This corresponds to the minRotateDampZRange attribute on the joint.'''
        pass

    def setMinRotateDampYStrength(self, angle): 
        '''setMinRotateDampYStrength(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping strength in Y.'''
        pass

    def minRotateDampYRange(self): 
        '''minRotateDampYRange(self) -> double
Returns: The minimum damping range in Y


Get the minimum of the damping range in Y. This corresponds to the minRotateDampYRange attribute on the joint.'''
        pass

    def setMaxRotateDampZStrength(self, angle): 
        '''setMaxRotateDampZStrength(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping strength in Z.'''
        pass

    def setMinRotateDampXRange(self, angle): 
        '''setMinRotateDampXRange(self, angle)
Arguments:
	[in]	angle = double


Set the minimum of the damping range in X'''
        pass

    def minRotateDampZStrength(self): 
        '''minRotateDampZStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def maxRotateDampYRange(self): 
        '''maxRotateDampYRange(self) -> double
Returns: The maximum of the damping range in Y


Get the maximum of the damping range in Y. This corresponds to the maxRotateDampYRange attribute on the joint.'''
        pass

    def getStiffness(self, stiffness): 
        '''getStiffness(self, stiffness)
Arguments:
	[out]	stiffness = double3


Get the stiffness (from 0 to 100.0) for the joint. The stiffness attribute is used by ik solvers to generate a resistance to a joint motion. The higher the stiffness the less it will rotate. Stiffness works in relative sense: it determines the willingness of this joint to rotate with respect to the other joint in the ik chain.'''
        pass

    def setStiffness(self, stiffness): 
        '''setStiffness(self, stiffness)
Arguments:
	[in]	stiffness = double3


Set the stiffness (from 0 to 100.0) for the joint. The stiffness attribute is used by ik solvers to generate a resistance to a joint motion. The higher the stiffness the less it will rotate. Stiffness works in relative sense: it determines the willingness of this joint to rotate with respect to the other joint in the ik chain.'''
        pass

    def setMaxRotateDampXRange(self, angle): 
        '''setMaxRotateDampXRange(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping range in X'''
        pass

    def minRotateDampYStrength(self): 
        '''minRotateDampYStrength(self) -> double
Returns: Status code (see below)


Get the minimum of the damping strength in X.'''
        pass

    def setSegmentScale(self, scale): 
        '''setSegmentScale(self, scale)
Arguments:
	[in]	scale = double3


Set the local space scale values for the joint segment (bone). This is equivalent to calling Ttransform::setScale.'''
        pass

    def setDegreesOfFreedom(self, freeInX, freeInY, freeInZ): 
        '''setDegreesOfFreedom(self, freeInX, freeInY, freeInZ)
Arguments:
	[in]	freeInX = bool
	[in]	freeInY = bool
	[in]	freeInZ = bool


Set the degrees of freedom of this joint by specifying which axes are allowed to rotate.'''
        pass

    def setOrientation(self, rotation, order): 
        '''setOrientation(self, rotation, order)
Arguments:
	[in]	rotation = double3
	[in]	order = MTransformationMatrix.RotationOrder


Set the orientation of the coordinate axes.'''
        pass

    def getDegreesOfFreedom(self, freeInX, freeInY, freeInZ): 
        '''getDegreesOfFreedom(self, freeInX, freeInY, freeInZ)
Arguments:
	[out]	freeInX = bool
	[out]	freeInY = bool
	[out]	freeInZ = bool


Get degrees of freedom of this joint'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getScaleOrientation(self, rotation, order): 
        '''getScaleOrientation(self, rotation, order)
Arguments:
	[out]	rotation = double3
	[out]	order = MTransformationMatrix.RotationOrder


Get the orientation of the coordinate axes for rotation. This is equivalent to calling the  MFnTransform::rotateOrientation  method but returns the Euler rotation rather than the quaternion rotation. The matrix equations used to combine the rotateAxis with the other transformation attributes of the joint are described in the description for the  MFnIkJoint  class.'''
        pass

    def setMaxRotateDampYStrength(self, angle): 
        '''setMaxRotateDampYStrength(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping strength in Y.'''
        pass

    def setMaxRotateDampXStrength(self, angle): 
        '''setMaxRotateDampXStrength(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping strength in X.'''
        pass

    def setMaxRotateDampZRange(self, angle): 
        '''setMaxRotateDampZRange(self, angle)
Arguments:
	[in]	angle = double


Set the maximum of the damping range in Z'''
        pass

    def setScaleOrientation(self, rotation, order): 
        '''setScaleOrientation(self, rotation, order)
Arguments:
	[in]	rotation = double3
	[in]	order = MTransformationMatrix.RotationOrder


Set the orientation of the coordinate axes for rotation. This is equivalent to calling the  MFnTransform::setRotateOrientation  method, and corresponds to the rotateAxis attribute on the joint node. The matrix equations used to combine the rotateAxis with the other transformation attributes of the joint are described in the description for the  MFnIkJoint  class.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def maxRotateDampXRange(self): 
        '''maxRotateDampXRange(self) -> double
Returns: The maximum of the damping range in X


Get the maximum of the damping range in X. This corresponds to the maxRotateDampXRange attribute on the joint.'''
        pass

    def minRotateDampXRange(self): 
        '''minRotateDampXRange(self) -> double
Returns: The minimum damping range in X


Get the minimum of the damping range in X. This corresponds to the minRotateDampXRange attribute on the joint.'''
        pass

    def hikJointName(self): 
        '''hikJointName(self) -> MString
Returns: The name used to identify this joint for HumanIK


Get the name that the HumanIK solver uses to identify this joint.'''
        pass

class MFnIkSolver:
    '''Function set for inverse kinematics (IK) solvers. This is the function set for inverse kinematics (IK) solvers. This function set is used for setting and querying attached ik solvers. '''
    def __init__(self):
        pass


    def maxIterations(self): 
        '''maxIterations(self) -> int
Returns: The maximum number of iterations used by this solver when solving


Returns the maximum number of iterations used when solving.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def setTolerance(self, tolerance): 
        '''setTolerance(self, tolerance)
Arguments:
	[in]	tolerance = double


Sets the tolerance used when solving.'''
        pass

    def tolerance(self): 
        '''tolerance(self) -> double
Returns: The tolerance value for this solver


Returns the tolerance used when solving.'''
        pass

    def setMaxIterations(self, maxIters): 
        '''setMaxIterations(self, maxIters)
Arguments:
	[in]	maxIters = int


Sets the maximum number of iterations used when solving.'''
        pass

class MFnKeyframeDelta:
    '''Base function set for keyframe deltas. Keyframe delta objects are returned via the MAnimMessage::animKeyframeEditedCallback( ... ). They describe atomic changes to keyframes as a result of a curve edit operation. Refer to the documentation in MAnimMessage class for further information.Base function set for all keyframe delta objects. A keyframe delta object is generated from the MAnimMessage::addAnimKeyframeEditedCallback. '''
    def __init__(self):
        pass


    def paramCurve(self): 
        '''paramCurve(self) -> MObject
Returns: A MObject, readable by MFnAnimCurve.


Return the Animation Curve  MObject  that this key belongs to.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def keyIndex(self): 
        '''keyIndex(self) -> int
Returns: An unsigned int representing the position of the key on the curve.


The index of this key on the animation curve.'''
        pass

class MFnKeyframeDeltaAddRemove:
    '''Function set for the addition or removal keys on a curve. Captures the addition or removal of key on a curve. keyIndex(...) will return the index of the key that was added or removed. '''
    def __init__(self):
        pass


    def kReplaced(self):
        '''This is an enum of DeltaType.
Description: Key replaced.
Value: 2'''
        pass

    def kAdded(self):
        '''This is an enum of DeltaType.
Description: Key added.
Value: 0'''
        pass

    def kRemoved(self):
        '''This is an enum of DeltaType.
Description: Key removed.
Value: 1'''
        pass

    class DeltaType:
        '''Non-functional class.  Values for this enum:
        kReplaced
        kAdded
        kRemoved
'''
        def __init__(self):
            pass

    def deltaType(self): 
        '''deltaType(self) -> MFnKeyframeDeltaAddRemove.DeltaType


Indicates the type of change that this class instance represents.'''
        pass

    def value(self): 
        '''value(self) -> double
Returns: A double value


The value of the key that was added or removed.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def replacedValue(self): 
        '''replacedValue(self) -> double
Returns: A double value


The value of the key that was replaced. This method is only applicable to the kReplaced operation. Otherwise it will return 0.'''
        pass

    def time(self): 
        '''time(self) -> MTime
Returns: A MTime value of the added/removed key.


The time value of the key that was added or removed.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def keyIndex(self): 
        '''keyIndex(self) -> int
Returns: An unsigned int representing the position of the key on the curve.


The index of this key on the animation curve.'''
        pass

class MFnKeyframeDeltaBlockAddRemove:
    '''Function set for block add or removal of keys. Certain keyframe editing operations work on group of keys rather than an single key. These operations require this function set to retrieve changes.Function set for reading a block of keyframe changes. They are used internally to set a large group of keys quickly. Because changes occur in groups using base class keyframe methods on this derived class do not make sense. Therefore, methods describing where the block of keys were added or removed are available though methods on this class. '''
    def __init__(self):
        pass


    def numKeys(self): 
        '''numKeys(self) -> int


Total number of keys involved in this add or remove operation.'''
        pass

    def kAdded(self):
        '''This is an enum of DeltaType.
Description: Keys were added.
Value: 0'''
        pass

    def kRemoved(self):
        '''This is an enum of DeltaType.
Description: Keys were removed.
Value: 1'''
        pass

    class DeltaType:
        '''Non-functional class.  Values for this enum:
        kAdded
        kRemoved
'''
        def __init__(self):
            pass

    def getTimes(self, times): 
        '''getTimes(self, times)
Arguments:
	[out]	times = MTimeArray


Returns the times of all keys involved in the group add or remove.'''
        pass

    def deltaType(self): 
        '''deltaType(self) -> MFnKeyframeDeltaBlockAddRemove.DeltaType
Returns: kAdded - a block of keys were added. 
kRemoved - a block of keys were removed.


Indicates the type of change, i.e. keys added or removed, that this class instance represents.'''
        pass

    def getValues(self, values): 
        '''getValues(self, values)
Arguments:
	[out]	values = MDoubleArray


Returns the values of all keys involved in the group add or remove.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def startTime(self): 
        '''startTime(self) -> MTime
Returns: An MTime value.


An  MTime  value indicating the start time of the add/remove.'''
        pass

    def endTime(self): 
        '''endTime(self) -> MTime
Returns: An MTime value indicating the end of the add/remove.


Returns an  MTime  value indicating the endTime of the add/remove.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnKeyframeDeltaBreakdown:
    '''Function set for changes in a key's breakdown state. Delta keyframe object for changes in breakdown state of a key. '''
    def __init__(self):
        pass


    def className(self): 
        '''className(self) -> char*

'''
        pass

    def wasBreakdown(self): 
        '''wasBreakdown(self) -> bool
Returns: true or false depending on the key's breakdown state.


Returns the previous breakdown state of the key. It will return false if the key was converted to a breakdown key.'''
        pass

    def isBreakdown(self): 
        '''isBreakdown(self) -> bool
Returns: true or false depending on the key's breakdown state.


Returns the current breakdown state of the key. It will return true if the key was converted to a breakdown key.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnKeyframeDeltaInfType:
    '''Function set for changes in pre or post infinity type. This delta object represents changes in the pre-infinity or post-infinity type of the animation curve. Pre-infinity and post-infinity types are specific to animation curves and do not have a corresponding key associated with them. It is, therefore, invalid to have a keyframe associated with a MFnKeyframeDeltaInfType. To determine if this class represents a change to pre or post infinity use the method isPreInfinity on this class. '''
    def __init__(self):
        pass


    def className(self): 
        '''className(self) -> char*

'''
        pass

    def currentInfinityType(self): 
        '''currentInfinityType(self) -> MFnAnimCurve.InfinityType
Returns: The current InfinityType for the curve


The current infinity type.'''
        pass

    def isPreInfinity(self): 
        '''isPreInfinity(self) -> bool
Returns: true if this class encapsulates changes to the pre-infinity type.


This class can describe changes to both the pre-infinity and post-infinity this method allows the API user to figure out which type this class represents.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def previousInfinityType(self): 
        '''previousInfinityType(self) -> MFnAnimCurve.InfinityType
Returns: The previous infinityType for the curve.


The previous infinity type.'''
        pass

class MFnKeyframeDeltaMove:
    '''Function set for change in keyframe value or time. This function set is used for keyframe deltas of type MFn::kKeyframeDeltaMove. These keyframe deltas are generated from 'move' events. For example, the user drags or scales a key from one position to another. '''
    def __init__(self):
        pass


    def previousTime(self): 
        '''previousTime(self) -> MTime
Returns: A MTime containing the previous time of this key.


The previous time value of this key.'''
        pass

    def currentValue(self): 
        '''currentValue(self) -> double
Returns: A double representing the current value of the key.


The current value of the key. The value corresponds to the units of the animation curve.'''
        pass

    def previousValue(self): 
        '''previousValue(self) -> double
Returns: A double representing the previous value of the key.


The previous value of the key prior to the change. The value corresponds to the units of the animation curve.'''
        pass

    def currentTime(self): 
        '''currentTime(self) -> MTime
Returns: A MTime containing the current time of this key.


The current/current time value.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def previousIndex(self): 
        '''previousIndex(self) -> int
Returns: An unsigned value representing the previous index of this key on the curve.


The previous index value of this key. If a key has been moved over another key then you can use this previous index to figure out where the key was moved from.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def keyIndex(self): 
        '''keyIndex(self) -> int
Returns: An unsigned value representing the current index of this key on the curve.


The current index value of this key.'''
        pass

class MFnKeyframeDeltaScale:
    '''Function set for scaling in time. This function set is used for keyframe deltas of type MFn::kKeyframeDeltaScale. These deltas are generated from scaling events. Particularly scaling on the time axis. Changes in value are recorded as a MFnKeyframeDeltaMove. '''
    def __init__(self):
        pass


    def pivotTime(self): 
        '''pivotTime(self) -> MTime
Returns: An MTime value


The pivot point of the scale (in time).'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def startTime(self): 
        '''startTime(self) -> MTime
Returns: An MTime value


The start time of the scaling block.'''
        pass

    def currentEndTime(self): 
        '''currentEndTime(self) -> MTime
Returns: An MTime value


The current end time.'''
        pass

    def currentStartTime(self): 
        '''currentStartTime(self) -> MTime
Returns: An MTime value


The current scale time (after scaling has been performed).'''
        pass

    def endTime(self): 
        '''endTime(self) -> MTime
Returns: An MTime value


The end time of the scaling block.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnKeyframeDeltaTangent:
    '''Function set for changes to a key's tangent. A MFnKeyframeDeltaTangent function allows API programmers to read changes in keyframe tangent values. It captures changes in tangent type, as well as, changes in tangent time/value pair.MFnKeyframeDeltaTangents are generated by a MAnimMessage::addAnimKeyframeEditedCallback. Because a key's tangent may be unbroken. It is possible to receive to MFnKeyframeDeltaTangent values per key -- one for the incoming tangent and one for the outgoing tangent. The API programmer should use the isInTangent method to determine if the tangent change affects the in-bound tangent or out-bound tangent. '''
    def __init__(self):
        pass


    def getPreviousPosition(self, x, y): 
        '''getPreviousPosition(self, x, y)
Arguments:
	[out]	x = float
	[out]	y = float


Get the values of the previous time/value position of the tangent for this key.'''
        pass

    def getCurrentPosition(self, x, y): 
        '''getCurrentPosition(self, x, y)
Arguments:
	[out]	x = float
	[out]	y = float


Get the values of the current time/value position of the tangent for this key.'''
        pass

    def isInTangent(self): 
        '''isInTangent(self) -> bool
Returns: true if the incoming tangent was modified. 
false if the outgoing tangent was modified.


Key's have two tangents, in-bound and out-bound. A MFnKeyframeTangent object can created once for each tangent. Use this method to determine which tangent was modified.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def currentTangentType(self): 
        '''currentTangentType(self) -> MFnAnimCurve.TangentType
Returns: The current tangent type.


Returns the current tangent type that the key represents.'''
        pass

    def previousTangentType(self): 
        '''previousTangentType(self) -> MFnAnimCurve.TangentType
Returns: The previous tangent type.


Returns the previous tangent type.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnKeyframeDeltaWeighted:
    '''Function set for changes in a key's weighted state. Delta keyframe object for changes in weighted state of a key. '''
    def __init__(self):
        pass


    def className(self): 
        '''className(self) -> char*

'''
        pass

    def wasWeighted(self): 
        '''wasWeighted(self) -> bool
Returns: true or false depending on the key's weight status.


Returns true if the key had weighted tangent, but it is not currently.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnLattice:
    '''Lattice function set. MFnLattice is the function set for lattice shapes and lattice geometry. It can be used on lattices in the DAG or on lattice geometry from a dependency node attribute.Lattices are most commonly used for specifying FFDs (free-form deformations). See MFnLatticeDeformer for more information on those.MFnLatticeData can be used to create new lattice data objects for use with dependency node attributes. '''
    def __init__(self):
        pass


    def reset(self, sSize, tSize, uSize): 
        '''reset(self, sSize, tSize, uSize)
Arguments:
	[in]	sSize = double
	[in]	tSize = double
	[in]	uSize = double


Reset the lattice points to a uniform parallelipiped shape with the specified dimensions: sSize x tSize x uSize'''
        pass

    def setDivisions(self, s, t, u): 
        '''setDivisions(self, s, t, u)
Arguments:
	[in]	s = int
	[in]	t = int
	[in]	u = int


Set the number of divisions in the lattice'''
        pass

    def point(self, s, t, u): 
        '''point(self, s, t, u) -> MPoint
Returns: The point

Arguments:
	[in]	s = int
	[in]	t = int
	[in]	u = int


Returns the point in the lattice that is at the given indices'''
        pass

    def getDivisions(self, s, t, u): 
        '''getDivisions(self, s, t, u)
Arguments:
	[out]	s = int
	[out]	t = int
	[out]	u = int


Get the number of divisions in the lattice'''
        pass

    def create(self, xDiv, yDiv, zDiv, parentOrOwner): 
        '''create(self, xDiv, yDiv, zDiv, parentOrOwner) -> MObject

Arguments:
	[in]	xDiv = int
	[in]	yDiv = int
	[in]	zDiv = int
	[in]	parentOrOwner = MObject


Create a new lattice. This can be used to create either a new lattice shape in the DAG, or to place new lattice geometry into a dependency graph lattice data object. Lattice data objects can be created with  MFnLatticeData  or can be obtained from an  MDataHandle  in the compute method of a dependency node.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnLatticeDeformer:
    '''FFD lattice deformer function set. MFnLatticeDeformer is the function set for lattice deformers. Lattice deformers use FFDs to deform geometry.The lattice deformer is actually a small network of dependency nodes in the dependency graph. This function set is provided to make manipulation of the network easier. The main deformer node should be given to this function set as its object.There are two lattices associated with a lattice deformer. There is a base lattice that defines the start position for the lattice. The second lattice is the version that is modified to deform the geometry. The difference between the two lattices defines the deformation that is applied to the geometry.The base lattice is a very simple shape that only defines a box in space. The base lattice should be modified by using the standard DAG transformation support. The second deformable lattice has geometry that can be modified using the MFnLattice function set.For a piece of geometry to be modified by this deformer, the geometry must be attached to the deformer (use addGeometry method) and the geometry must be contained within the base lattice. The resetLattice method can be used to make the lattice resize to the bounding box of the attached geometry. '''
    def __init__(self):
        pass


    def setDivisions(self, x, y, z): 
        '''setDivisions(self, x, y, z)
Arguments:
	[in]	x = int
	[in]	y = int
	[in]	z = int


Set the number of divisions in each of the X, Y, and Z directions. The number of divisions specifies the resolution of the lattice.'''
        pass

    def deformLattice(self): 
        '''deformLattice(self) -> MObject
Returns: Handle for the deformed lattice shape


This returns the deformed version of the lattice. The deformed lattice is a shape in the DAG and should be modified using the  MFnLattice  function set.'''
        pass

    def getDivisions(self, x, y, z): 
        '''getDivisions(self, x, y, z)
Arguments:
	[out]	x = int
	[out]	y = int
	[out]	z = int


Retrieve the number of divisions in each of the X, Y, and Z directions. The number of divisions specifies the resolution of the lattice.'''
        pass

    def create(self, xDiv, yDiv, zDiv): 
        '''create(self, xDiv, yDiv, zDiv) -> MObject
Returns: Returns a handle to the new deformer

Arguments:
	[in]	xDiv = int
	[in]	yDiv = int
	[in]	zDiv = int


Creates a new lattice deformer with the given number of divisions. This function set's object is set to be the new lattice node.'''
        pass

    def baseLattice(self): 
        '''baseLattice(self) -> MObject
Returns: Handle for the base lattice shape


This returns the base version of the lattice that describes the region of space deformed by the lattice. The returned base lattice is a shape in the DAG and can be accessed using the  MFnDagNode  function set.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def resetLattice(self, centerLattice): 
        '''resetLattice(self, centerLattice)
Arguments:
	[in]	centerLattice = bool


This method resets the deformed lattice to match the base lattice.'''
        pass

    def addGeometry(self, object): 
        '''addGeometry(self, object)
Arguments:
	[in]	object = MObject


Adds a piece of geometry to the deformation.'''
        pass

    def getAffectedGeometry(self, objects): 
        '''getAffectedGeometry(self, objects)
Arguments:
	[out]	objects = MObjectArray


The geometry affected by this deformer is packed into the provided list of MObjects. Each of the MObjects will be a DAG node that has geometry.'''
        pass

    def removeGeometry(self, object): 
        '''removeGeometry(self, object)
Arguments:
	[in]	object = MObject


Removes a piece of geometry from the deformation.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

class MFnMotionPath:
    '''Motion path animation function set. This class is used for constructing and manipulating motion path animation.Motion path animation requires a curve (or surface) and one or more other objects. During the animation, the objects will be moved along the curve.Setting "follow" for the motion path aligns the object(s) local axis to the tangent of the motion path. Banking can also be applied to objects.Motion path markers are points along the path where the orientation and position for the object(s) travelling along the path can be specified. '''
    def __init__(self):
        pass


    def numPositionMarkers(self): 
        '''numPositionMarkers(self) -> int
Returns: The number of markers


Returns the number of position markers on this motion path.'''
        pass

    def upAxis(self): 
        '''upAxis(self) -> MFnMotionPath.Axis
Returns: The up-axis for this motion path


Return the up-axis for this motion path.'''
        pass

    def pathObject(self): 
        '''pathObject(self) -> MDagPath
Returns: The dag path of the motion path object


Return a dag path to the motion path object. The motion path object is the curve/surface that animated objects of this node will move along.'''
        pass

    def setUTimeStart(self, start): 
        '''setUTimeStart(self, start)
Arguments:
	[in]	start = MTime


Sets the starting time of the animation for the u parameter.'''
        pass

    def inverseNormal(self): 
        '''inverseNormal(self) -> bool
Returns: true Inverse normal vector is used for object alignment. 
false Inverse normal vector is not used for object alignment.


Determines whether the up-axis of the animated object for this motion path is aligned to the opposite direction of the normal vector of the path geometry.'''
        pass

    def getOrientationMarker(self, markerNum): 
        '''getOrientationMarker(self, markerNum) -> MObject
Returns: The orientation marker

Arguments:
	[in]	markerNum = int


Gets the orientation marker where markerNum is the order in which the marker was created.'''
        pass

    def follow(self): 
        '''follow(self) -> bool
Returns: true Follow is turned on 
false Follow is turned off


Determines whether follow is set for this motion path node.'''
        pass

    def setUStart(self, start): 
        '''setUStart(self, start)
Arguments:
	[in]	start = double


Sets the starting value of the u parameterization for the animation.'''
        pass

    def uTimeStart(self): 
        '''uTimeStart(self) -> MTime
Returns: The starting time


Returns the start time of the animation for the u parameter.'''
        pass

    def setPathObject(self, pathObject, modifier): 
        '''setPathObject(self, pathObject, modifier)
Arguments:
	[in]	pathObject = MDagPath
	[in]	modifier = MDGModifier


Set the curve or surface for this motion path. All animated objects for this motion path will follow the new path that is specified.'''
        pass

    def create(self, pathObject, objectToAnimate, timeStart, timeEnd, modifier): 
        '''create(self, pathObject, objectToAnimate, timeStart, timeEnd, modifier) -> MObject
Returns: The new motion path node

Arguments:
	[in]	pathObject = MDagPath
	[in]	objectToAnimate = MDagPath
	[in]	timeStart = MTime
	[in]	timeEnd = MTime
	[in]	modifier = MDGModifier


Create a new motion path dependency node. When a motion path node is created, the following defaults are set:'''
        pass

    def setUpAxis(self, axis): 
        '''setUpAxis(self, axis)
Arguments:
	[in]	axis = MFnMotionPath.Axis


Set the up-axis for this motion path.'''
        pass

    def getPositionMarker(self, markerNum): 
        '''getPositionMarker(self, markerNum) -> MObject
Returns: The position marker

Arguments:
	[in]	markerNum = int


Gets the position marker where markerNum is the order in which the marker was created.'''
        pass

    def bankThreshold(self): 
        '''bankThreshold(self) -> double
Returns: The bank threshold.


Return the bank threshold for this motion path. The bank threshold is used to specify the maximum bank angle. The default value is 90 degrees.'''
        pass

    def numOrientationMarkers(self): 
        '''numOrientationMarkers(self) -> int
Returns: The number of markers


Returns the number of orientation markers on this motion path.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def bankScale(self): 
        '''bankScale(self) -> double
Returns: The bank scale.


Return the bank scale for this motion path.'''
        pass

    def followAxis(self): 
        '''followAxis(self) -> MFnMotionPath.Axis
Returns: The follow axis.


Return the follow axis for this motion path.'''
        pass

    def setInverseNormal(self, invert): 
        '''setInverseNormal(self, invert)
Arguments:
	[in]	invert = bool


If  true , enable alignment of the up axis of the moving object(s) to the opposite direction of the normal vector of the path geometry.'''
        pass

    def uEnd(self): 
        '''uEnd(self) -> double
Returns: The end value


Returns the end value of the u parameterization for the animation.'''
        pass

    def setUTimeEnd(self, end): 
        '''setUTimeEnd(self, end)
Arguments:
	[in]	end = MTime


Sets the end time of the animation for the u parameter.'''
        pass

    def getAnimatedObjects(self, array): 
        '''getAnimatedObjects(self, array)
Arguments:
	[out]	array = MDagPathArray


Returns an array of dag paths to the animated objects for this motion path.'''
        pass

    def useNormal(self): 
        '''useNormal(self) -> bool
Returns: true Normal vector is used for object alignment. 
false Normal vector is not used for object alignment.


Determines whether the up-axis of the animated object for this motion path is aligned with the normal vector of the path geometry.'''
        pass

    def setUEnd(self, end): 
        '''setUEnd(self, end)
Arguments:
	[in]	end = double


Sets the end value of the u parameterization for the animation.'''
        pass

    def setBankScale(self, bankScale): 
        '''setBankScale(self, bankScale)
Arguments:
	[in]	bankScale = double


Set the bank scale for this motion path. If the computed bank angles are not large enough, the user can specify the bankScale to amplify them. The default value is 1.'''
        pass

    def setFollowAxis(self, axis): 
        '''setFollowAxis(self, axis)
Arguments:
	[in]	axis = MFnMotionPath.Axis


Sets the axis of the animated object that will follow the motion path. Possible alignment parameters are  kXaxis ,  kYaxiz , or  kZaxis .'''
        pass

    def bank(self): 
        '''bank(self) -> bool
Returns: true Bank is enabled 
false Bank is disabled


Determines whether bank has been enabled for this motion path.'''
        pass

    def uTimeEnd(self): 
        '''uTimeEnd(self) -> MTime
Returns: The end time


Returns the end time of the animation for the u parameter.'''
        pass

    def setBankThreshold(self, bankThreshold): 
        '''setBankThreshold(self, bankThreshold)
Arguments:
	[in]	bankThreshold = double


Set the bank threshold for this motion path. The bank threshold is used to specify the maximum bank angle. The default value is 90 degrees.'''
        pass

    def setUseNormal(self, use): 
        '''setUseNormal(self, use)
Arguments:
	[in]	use = bool


If  true , enables alignment of the up axis of the animated object to the normal vector of the path geometry.'''
        pass

    def setBank(self, bank): 
        '''setBank(self, bank)
Arguments:
	[in]	bank = bool


 Parameters: 
 
 [in]   bank   Specifies whether bank is turned on 
 
 
 Returns: Status Code 
 Status Codes: 
 MS::kSuccess  Member was successful  
 MS::kFailure  An object error has occurred  
 
 
'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def uStart(self): 
        '''uStart(self) -> double
Returns: The starting value


Returns the starting value of the u parameterization for the animation.'''
        pass

    def addAnimatedObject(self, objectToAnimate, modifier): 
        '''addAnimatedObject(self, objectToAnimate, modifier)
Arguments:
	[in]	objectToAnimate = MDagPath
	[in]	modifier = MDGModifier


Add an object to be animated along this motion path.'''
        pass

    def setFollow(self, on, modifier): 
        '''setFollow(self, on, modifier)
Arguments:
	[in]	on = bool
	[in]	modifier = MDGModifier


Setting follow on will cause the animated object(s) local axis to be aligned with the tangent of the motion path. The default alignment axis is Y.'''
        pass

    def kXaxis(self):
        '''This is an enum of Axis.
Description: 
Value: 0'''
        pass

    def kYaxis(self):
        '''This is an enum of Axis.
Description: 
Value: 1'''
        pass

    def kZaxis(self):
        '''This is an enum of Axis.
Description: 
Value: 2'''
        pass

    class Axis:
        '''Non-functional class.  Values for this enum:
        kXaxis
        kYaxis
        kZaxis
'''
        def __init__(self):
            pass

class MFnSkinCluster:
    '''skinCluster function set MFnSkinCluster is the function set for skinClusters. SkinCluster nodes are created during a smooth bindSkin. The purpose of the skinCluster is to store a weight per influence object for each component of each geometry that is deformed. Influence objects can be joints or any transform.Note that unlike most deformers, a skinCluster node can deform only a single geometry. Therefore, if additional geometries are added to the skinCluster set, they will be ignored.This function set provides methods for getting and setting weights on skin cluster nodes. It parent class, MFnGeometryFilter provides methods for accessing the skin cluster's input and output geometry. '''
    def __init__(self):
        pass


    def getWeights(self, path, components, weights, influenceCount): 
        '''getWeights(self, path, components, weights, influenceCount)
Arguments:
	[in]	path = MDagPath
	[in]	components = MObject
	[out]	weights = MFloatArray
	[out]	influenceCount = int


This method is obsolete. Maya's skinCluster nodes store their weights as doubles. This method has been replaced by one which uses doubles instead of floats. This method only exists for backwards-compilability of old plug-in code.'''
        pass

    def getPointsAffectedByInfluence(self, path, result, weights): 
        '''getPointsAffectedByInfluence(self, path, result, weights)
Arguments:
	[in]	path = MDagPath
	[out]	result = MSelectionList
	[out]	weights = MFloatArray


This method is obsolete. Maya's skinCluster nodes store their weights as doubles. This method has been replaced by one which uses doubles instead of floats. This method only exists for backwards-compilability of old plug-in code.'''
        pass

    def indexForInfluenceObject(self, mpath): 
        '''indexForInfluenceObject(self, mpath) -> int
Returns: The logical index of the influence object

Arguments:
	[in]	mpath = MDagPath


Returns the logical index of the matrix array attribute where the specified influence object is attached.'''
        pass

    def setWeights(self, path, components, influenceIndices, values, normalize, oldValues): 
        '''setWeights(self, path, components, influenceIndices, values, normalize, oldValues)
Arguments:
	[in]	path = MDagPath
	[in]	components = MObject
	[in]	influenceIndices = MIntArray
	[in]	values = MFloatArray
	[in]	normalize = bool
	[in]	oldValues = MFloatArray


This method is obsolete. Maya's skinCluster nodes store their weights as doubles. This method has been replaced by one which uses doubles instead of floats. This method only exists for backwards-compilability of old plug-in code.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def influenceObjects(self, paths): 
        '''influenceObjects(self, paths) -> int
Returns: The number of influence objects

Arguments:
	[in]	paths = MDagPathArray


Returns an array of paths to the influence objects for the skinCluster.'''
        pass

class MFnWeightGeometryFilter:
    '''Weight geometry filter function set. MFnWeightGeometryFilter is the function set for weight geometry filters. Weight geometry filter nodes include clusters, cluster flexors, and user-defined deformers derived from MPxDeformerNode. The purpose of the weight geometry filter is to store the weights for each component of each geometry that is deformed. The weight geometry filter is independent of any algorithm that calculates a deformation based on the component weight values. Clusters, cluster flexors, and user-defined deformers each have their own algorithm to determine the deformation based on the component weights.This function set provides methods for getting and setting weights on weight geometry filter nodes. In addition to getting and settings weights on components, this class provides methods for accessing the weight geometry filter's input and output geometry through its parent class, MFnGeometryFilter.When getting and setting weights on components, it is more efficient to use the methods that take a plug index. The plug index is a sparse array index, and is the same index used in MEL scripts to index into an array of plugs. '''
    def __init__(self):
        pass


    def setWeight(self, path, components, values): 
        '''setWeight(self, path, components, values)
Arguments:
	[in]	path = MDagPath
	[in]	components = MObject
	[in]	values = MFloatArray


Sets the weights of the specified components of the object whose DAG path is specified.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def getWeights(self, path, components, weights): 
        '''getWeights(self, path, components, weights)
Arguments:
	[in]	path = MDagPath
	[in]	components = MObject
	[out]	weights = MFloatArray


Gets the weights of the components that correspond to the geometry whose DAG path is specified.'''
        pass

    def getWeightPlugStrings(self, list, plugStringArray): 
        '''getWeightPlugStrings(self, list, plugStringArray)
Arguments:
	[in]	list = MSelectionList
	[out]	plugStringArray = MStringArray


Set the plugStringArray argument to contain the names of the plugs on this node that correspond to the components in the selection list. The operation will fail if none of the items in the selection list correspond to components weighted by this cluster.'''
        pass

    def weightPlugStrings(self, list): 
        '''weightPlugStrings(self, list) -> MString
Returns: A string containing the names of the plugs on this node that correspond to the components in the selection list

Arguments:
	[in]	list = MSelectionList


Sets the plugStrings argument to be a string (separated by spaces) containing the names of the plugs on this node that correspond to the components in the selection list. The method can be useful in conjunction with setting keys on a number of plugs. The operation will fail if none of the items in the selection list correspond to components weighted by this cluster.'''
        pass

class MFnWireDeformer:
    '''wire deformer function set MFnWireDeformer is the function set for wire deformers. Wire deformers modify geometry based on its proximity to controlling wire curves. As the wire curves are modified, the parts of the geometry close to the curve will follow.The wire deformer is actually a small network of dependency nodes in the dependency graph. This function set is provided to make manipulation of the network easier. The main deformer node should be given to this function set as its object. '''
    def __init__(self):
        pass


    def wireDropOffDistance(self, wireIndex): 
        '''wireDropOffDistance(self, wireIndex) -> float
Returns: The drop off distance

Arguments:
	[in]	wireIndex = int


Return the drop off distance of the wire at the given index. Increasing this value will give the wire a greater area of influence.'''
        pass

    def setCrossingEffect(self, crossingEffect): 
        '''setCrossingEffect(self, crossingEffect)
Arguments:
	[in]	crossingEffect = float


Sets the local intensity for this wire deformer.'''
        pass

    def localIntensity(self): 
        '''localIntensity(self) -> float
Returns: The local intensity value


Returns the local intensity for this wire deformer.'''
        pass

    def holdingShape(self, wireIndex): 
        '''holdingShape(self, wireIndex) -> MObject
Returns: Return status

Arguments:
	[in]	wireIndex = int


Returns the holding shape for the given wire. The holding shape may be a nurbs curve or a nurbs surface. If the given wire does not have a holding shape, then a null  MObject  handle will be returned.'''
        pass

    def wireScale(self, wireIndex): 
        '''wireScale(self, wireIndex) -> float
Returns: The radial scale value

Arguments:
	[in]	wireIndex = int


Return the radial scale of the wire at the given index. The scale value affects how the wire modifies the geometry in its area of influence. A value of between 0.0 and 1.0 causes the wire to pull the surrounding geometry points towards itself. A value of greater than one causes the wire to repulse the geometry points around it. A value of exactly 1.0 causes the wire to neither pull nor push the points around it.'''
        pass

    def wire(self, wireIndex): 
        '''wire(self, wireIndex) -> MObject
Returns: A handle to the given wire curve

Arguments:
	[in]	wireIndex = int


Return the wire at the given index. The returned object will be a nurbs curve shape suitable for use with the  MFnNurbsCurve  function set.'''
        pass

    def getDropoffLocator(self, wireIndex, locatorIndex, param, percentage): 
        '''getDropoffLocator(self, wireIndex, locatorIndex, param, percentage)
Arguments:
	[in]	wireIndex = int
	[in]	locatorIndex = int
	[out]	param = float
	[out]	percentage = float


Gets the parameters of a drop off locator.'''
        pass

    def setLocalIntensity(self, localIntensity): 
        '''setLocalIntensity(self, localIntensity)
Arguments:
	[in]	localIntensity = float


Sets the local intensity for this wire deformer.'''
        pass

    def create(self): 
        '''create(self) -> MObject
Returns: Returns a handle to the new deformer


Creates a new wire deformer. This function set's object is set to be the new wire deformer node.'''
        pass

    def setWireDropOffDistance(self, wireIndex, dropOff): 
        '''setWireDropOffDistance(self, wireIndex, dropOff)
Arguments:
	[in]	wireIndex = int
	[in]	dropOff = float


Sets the drop off distance of the wire at the given index. Increasing this value will give the wire a greater area of influence.'''
        pass

    def setEnvelope(self, envelope): 
        '''setEnvelope(self, envelope)
Arguments:
	[in]	envelope = float


Sets the envelope for this deformer.'''
        pass

    def removeGeometry(self, object): 
        '''removeGeometry(self, object)
Arguments:
	[in]	object = MObject


Removes a piece of geometry from the deformation.'''
        pass

    def setRotation(self, rotation): 
        '''setRotation(self, rotation)
Arguments:
	[in]	rotation = float


Sets the rotation value for this deformer.'''
        pass

    def setHoldingShape(self, wireIndex, holdingShape): 
        '''setHoldingShape(self, wireIndex, holdingShape)
Arguments:
	[in]	wireIndex = int
	[in]	holdingShape = MObject


Sets the holding shape for the given wire. The holding shape may be a nurbs curve or a nurbs surface.'''
        pass

    def type(self): 
        '''type(self) -> MFn.Type

'''
        pass

    def crossingEffect(self): 
        '''crossingEffect(self) -> float
Returns: The crossing effect value


Returns the crossing effect for this wire deformer.'''
        pass

    def setWireScale(self, wireIndex, scale): 
        '''setWireScale(self, wireIndex, scale)
Arguments:
	[in]	wireIndex = int
	[in]	scale = float


Sets the radial scale value of the wire at the given index. The scale value affects how the wire modifies the geometry in its area of influence. A value of between 0.0 and 1.0 causes the wire to pull the surrounding geometry points towards itself. A value of greater than one causes the wire to repulse the geometry points around it. A value of exactly 1.0 causes the wire to neither pull nor push the points around it.'''
        pass

    def setDropoffLocator(self, wireIndex, locatorIndex, param, percentage): 
        '''setDropoffLocator(self, wireIndex, locatorIndex, param, percentage)
Arguments:
	[in]	wireIndex = int
	[in]	locatorIndex = int
	[in]	param = float
	[in]	percentage = float


Sets the parameters of a drop off locator.'''
        pass

    def envelope(self): 
        '''envelope(self) -> float
Returns: The envelope value


Returns the envelope for this deformer.'''
        pass

    def addGeometry(self, object): 
        '''addGeometry(self, object)
Arguments:
	[in]	object = MObject


Adds a piece of geometry to the deformation.'''
        pass

    def numDropoffLocators(self, wireIndex): 
        '''numDropoffLocators(self, wireIndex) -> int
Returns: The number of drop off locators for the given curve

Arguments:
	[in]	wireIndex = int


Returns the number of drop off locators.'''
        pass

    def rotation(self): 
        '''rotation(self) -> float
Returns: The rotation value


Returns the rotation value for this deformer.'''
        pass

    def className(self): 
        '''className(self) -> char*

'''
        pass

    def getAffectedGeometry(self, objects): 
        '''getAffectedGeometry(self, objects)
Arguments:
	[out]	objects = MObjectArray


The geometry affected by this deformer is packed into the provided list of MObjects. Each of the MObjects will be a DAG node that has geometry.'''
        pass

    def addWire(self, object): 
        '''addWire(self, object)
Arguments:
	[in]	object = MObject


Adds a new wire curve to the deformation.'''
        pass

    def numWires(self): 
        '''numWires(self) -> int
Returns: The number of wires


returns the number of wire curves connected to this deformer.'''
        pass

class MIkHandleGroup:
    '''IK handle groups. Group class for ik handles. Each group has an associated solver and priority. A single chain solver handle group has only one handle in its group. '''
    def __init__(self):
        pass


    def handle(self, ith): 
        '''handle(self, ith) -> MObject
Returns: An MObject for the handle

Arguments:
	[in]	ith = int


Return the ith handle in the handle list for this group.'''
        pass

    def checkEffectorAtGoal(self): 
        '''checkEffectorAtGoal(self) -> bool
Returns: true The end-effector is at the goal location 
false The end-effector is not at the goal location


Determines whether the end-effector at the handle(goal) location.'''
        pass

    def solverPriority(self): 
        '''solverPriority(self) -> int
Returns: The solver priority


return the priority of the solver used by this handle group.'''
        pass

    def handleCount(self): 
        '''handleCount(self) -> int
Returns: The number of handles


Return the number of handles in the handle list for this group.'''
        pass

    def priority(self): 
        '''priority(self) -> int
Returns: The priority


Return the priority value of this handle group.'''
        pass

    def setSolverID(self, id): 
        '''setSolverID(self, id)
Arguments:
	[in]	id = int


Set the solver id for this handle group.'''
        pass

    def solverID(self): 
        '''solverID(self) -> int
Returns: The solver id for this group


Return the solver id used by this handle group.'''
        pass

    def setPriority(self, priority): 
        '''setPriority(self, priority)
Arguments:
	[in]	priority = int


Set the priority of this handle group.'''
        pass

    def solve(self): 
        '''solve(self)

Do all ik solving steps for this group.'''
        pass

    def dofCount(self): 
        '''dofCount(self) -> int
Returns: The total number of dofs


Return the total number of degrees of freedom of this handle group.'''
        pass

class MIkSystem:
    '''Inverse kinematics (IK) system classThis class provides an interface to the inverse kinematics (IK) system. The ik system is used to set/query the global snapping flag for handles, set/query the global solve flag for solvers, and to find the ik solvers available in maya. '''
    def __init__(self):
        pass


    def getSolvers(self, names): 
        '''getSolvers(self, names)
Arguments:
	[out]	names = MStringArray


Get a list of the names for the solvers that are available in the system.'''
        pass

    def isGlobalSolve(self): 
        '''isGlobalSolve(self) -> bool


Determines whether global solving is on.'''
        pass

    def findSolver(self, name): 
        '''findSolver(self, name) -> MObject
Returns: The ik solver matching the given name

Arguments:
	[in]	name = MString


Returns the ik solver with the given name. If the solver cannot be found then a a null  MObject  and an error is returned.'''
        pass

    def setGlobalSolve(self, isSolve): 
        '''setGlobalSolve(self, isSolve)
Arguments:
	[in]	isSolve = bool


Turns global solving on or off.'''
        pass

    def isGlobalSnap(self): 
        '''isGlobalSnap(self) -> bool
Returns: true global snapping is on 
false global snapping is off


Determines whether global snapping is on. Turning on global snapping will turn on snapping for all ik handles.'''
        pass

    def setGlobalSnap(self, isSnap): 
        '''setGlobalSnap(self, isSnap)
Arguments:
	[in]	isSnap = bool


Turns global snapping on or off. Turning on global snapping will turn on snapping for all ik handles.'''
        pass

class MItKeyframe:
    '''Keyframe Iterator. Iterate over the keyframes of a particular Anim Curve Node, and query and edit the keyframe to which the iterator points.Determine the time and value of the keyframe, as well as the x,y values and type of the tangent to the curve entering (in tangent) and leaving (out tangent) the keyframe.Set the time and value of the keyframe, and the type of the tangents.Anim Curves are implemented as Dependency Graph (DG) Nodes. Each Node has multiple ordered and indexed keyframes.Use the Keyframe Iterator to systematically visit, and query and/or edit the keyframes of a Anim Curve Node.Use the Keyframe Iterator in conjunction with the Anim Curve Function Set (MFnAnimCurve) to edit Anim Curve Nodes.On creation the iterator is attached to a Anim Curve Node. The iterator may be detached from its current Node and attached to another Anim Curve Node using the reset() method.Though keyframes within a Node are ordered and indexed, the iterator maintains the index of the current Node internally and does not export it. Use the Anim Curve Function Set to access the index for a keyframe. The index is zero-based. When an iterator is first attached to a Node, either on creation or reset, the index is set to zero. There is an overloaded version of the reset() method which does not cause the iterator to change Nodes, but merely resets the index.Use the next(), reset() and isDone() methods to perform iterations.Use the specific query methods to determine the time, value and tangent information for the keyframe under the iterator.Use specific edit methods to set the time and value , as well as the incoming and outgoing tangent type (MItKeyframe::TangentType) of the keyframe under the iterator.There is no method for setting the x,y value of either of the tangents.Setting the time of a keyframe will fail if the new time would require a re-ordering of the keyframes. Use the Anim Curve Functiion Set methods MFnAnimCurve::remove() and MFnAnimCurve::addKeyFrame() to re-order the keyframes. '''
    def __init__(self):
        pass


    def reset(self): 
        '''reset(self)

Resets the keyframe index to 0 (first keyframe) on the Anim Curve Node to which the iterator is attached.'''
        pass

    def outTangentType(self): 
        '''outTangentType(self) -> MItKeyframe.TangentType
Returns: Type of the tangent


Determines the type of the tangent to the curve leaving the current keyframe.'''
        pass

    def setValue(self, value): 
        '''setValue(self, value)
Arguments:
	[in]	value = double


Sets the value of the current keyframe.'''
        pass

    def getTangentOut(self, x, y): 
        '''getTangentOut(self, x, y)
Arguments:
	[out]	x = float
	[out]	y = float


Determines the x,y value of the tangent to the curve leaving the current keyframe.'''
        pass

    def setTangentsLocked(self, locked): 
        '''setTangentsLocked(self, locked)
Arguments:
	[in]	locked = bool


Lock or unlock the tangents at this keyframe.'''
        pass

    def inTangentType(self): 
        '''inTangentType(self) -> MItKeyframe.TangentType
Returns: Type of the tangent


Determines the type of the tangent to the curve entering the current keyframe.'''
        pass

    def value(self): 
        '''value(self) -> double
Returns: Value of the current keyframe


Determines the value of the current keyframe.'''
        pass

    def next(self): 
        '''next(self)

Moves to the next keyframe on the Anim Curve Node to which the iterator is attached.'''
        pass

    def kTangentGlobal(self):
        '''This is an enum of TangentType.
Description: 
Value: 0'''
        pass

    def kTangentFast(self):
        '''This is an enum of TangentType.
Description: Fast tangent.
Value: 7'''
        pass

    def kTangentPlateau(self):
        '''This is an enum of TangentType.
Description: Similar to smooth except that minima and maxima between keyframes are flattened, if necessary, to prevent them overshooting their keys.
Value: 9'''
        pass

    def kTangentFixed(self):
        '''This is an enum of TangentType.
Description: Normally, if a key is moved tangent values will be adjusted to maintain their relationships to the surrounding keys (linear, smooth, etc).
Value: 1'''
        pass

    def kTangentSmooth(self):
        '''This is an enum of TangentType.
Description: The in and out tangents are colinear and set to provide a smooth transition from the key before to the key after.
Value: 4'''
        pass

    def kTangentStepNext(self):
        '''This is an enum of TangentType.
Description: Upon leaving the keyframe the value immediately jumps to that of the next keyframe and stays there.
Value: 10'''
        pass

    def kTangentStep(self):
        '''This is an enum of TangentType.
Description: The key's value is maintained until the next key is reached whereupon it immediately jumps to the new key's value.
Value: 5'''
        pass

    def kTangentClamped(self):
        '''This is an enum of TangentType.
Description: Same as smooth except when two keys are very close together in which case the tangents between them are treated as linear. This corrects for slippage which is sometimes seen when spline tangents are used on keyframes which are close together.
Value: 8'''
        pass

    def kTangentFlat(self):
        '''This is an enum of TangentType.
Description: The tangent is horizontal.
Value: 3'''
        pass

    def kTangentSlow(self):
        '''This is an enum of TangentType.
Description: Slow tangent.
Value: 6'''
        pass

    def kTangentLinear(self):
        '''This is an enum of TangentType.
Description: For an in tangent this sets it to point directly at the previous key. For an out tangent it points directly to the next key. This is used to create straight lines between keys.
Value: 2'''
        pass

    class TangentType:
        '''Non-functional class.  Values for this enum:
        kTangentGlobal
        kTangentFast
        kTangentPlateau
        kTangentFixed
        kTangentSmooth
        kTangentStepNext
        kTangentStep
        kTangentClamped
        kTangentFlat
        kTangentSlow
        kTangentLinear
'''
        def __init__(self):
            pass

    def getTangentIn(self, x, y): 
        '''getTangentIn(self, x, y)
Arguments:
	[out]	x = float
	[out]	y = float


Determines the x,y value of the tangent to the curve entering the current keyframe.'''
        pass

    def setTime(self, time): 
        '''setTime(self, time)
Arguments:
	[in]	time = MTime


Sets the time of the current keyframe. This will fail if setting the time would require re-ordering of the keyframes.'''
        pass

    def setOutTangentType(self, tangentType): 
        '''setOutTangentType(self, tangentType)
Arguments:
	[in]	tangentType = MItKeyframe.TangentType


Sets the type of the tangent to the curve entering the current keyframe.'''
        pass

    def time(self): 
        '''time(self) -> MTime
Returns: Time (in seconds) of the current keyframe


Determines the time of the current keyframe.'''
        pass

    def setInTangentType(self, tangentType): 
        '''setInTangentType(self, tangentType)
Arguments:
	[in]	tangentType = MItKeyframe.TangentType


Sets the type of the tangent to the curve entering the current keyframe.'''
        pass

    def tangentsLocked(self): 
        '''tangentsLocked(self) -> bool
Returns: true if the tangents are locked 
false if the tangents are not locked


Determines whether the tangents are locked at this keyframe.'''
        pass

    def isDone(self): 
        '''isDone(self) -> bool
Returns: true Done 
false Not done


Indicates that the iterator is at the last keyframe on the Anim Curve Node to which the iterator is attached (index = number of keyframes - 1).'''
        pass

