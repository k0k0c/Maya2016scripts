

##################################
Maya 2009 Python API Stub Files
for use with
Eclipse

##################################

Use these files to enable autocompletion
functionality in Eclipse when programming
with Maya 2009 Python API.

See tutorial on Highend3d.com


v. 01 - Dec 2008 - First release