
'''
Stub class file for:
OpenMayaCloth

Maya2009 Python API stub file
Generated from original Maya documentation.
Autodesk Maya 2009  c1997-2008 Autodesk, Inc. All rights reserved. 
'''




class MClothConstraint:
    '''Interface for cloth solver constraint system. This class provides interface for cloth constraint system. '''
    def __init__(self):
        pass


    def getParticle(self): 
        '''getParticle(self) -> MClothParticle
Returns: MClothParticle* MClothParticle* object. 


This method returns cloth particle this constraint is associated with.'''
        pass

    def execute(self): 
        '''execute(self)

Override this method to have custom constraint execute behavior.'''
        pass

    def userDefined(self): 
        '''userDefined(self) -> bool


Check for user defined constraint.'''
        pass

class MClothConstraintBridge:
    '''Interface for cloth solver constraint command bridge. Interface that must be implemented by solver writers to override custom behavior for various constraints. '''
    def __init__(self):
        pass


    def execute(self, particle, soft, shear, damp): 
        '''execute(self, particle, soft, shear, damp)
Arguments:
	[in]	particle = MClothParticle
	[in]	soft = bool
	[in]	shear = double
	[in]	damp = double


Execute this cloth constraint.'''
        pass

class MClothConstraintCmd:
    '''Interface for cloth solver constraint command. Interface that must be implemented by solver writers to override custom behavior for various constraints. MayaCloth plugin implements MClothConstraintCmd in plugin (PinConstraint, TransformConstraint).Solver should provide MClothConstraintBridge object to override custom behavior during constraint evaluation. MClothConstraintBridge object should get set in addCommand method of MClothSystem implementation. '''
    def __init__(self):
        pass


    def setStrength(self, shear, damp): 
        '''setStrength(self, shear, damp)
Arguments:
	[in]	shear = double
	[in]	damp = double


Set strength of constraint.'''
        pass

    def getCustomConstraintBehavior(self): 
        '''getCustomConstraintBehavior(self) -> MClothConstraintBridge


Get the custom constraint behavior object.'''
        pass

    def execute(self): 
        '''execute(self)
'''
        pass

    def getDamp(self): 
        '''getDamp(self) -> double


Get damp value associated with this constraint.'''
        pass

    def userDefined(self): 
        '''userDefined(self) -> bool


Check for user defined constraint.'''
        pass

    def desired_position(self, frame): 
        '''desired_position(self, frame) -> MPoint
Returns: MPoint The desired position. 

Arguments:
	[in]	frame = double


This method returns the desired position of constraint at given frame.'''
        pass

    def isSoft(self): 
        '''isSoft(self) -> bool


Check for soft constraint.'''
        pass

    def getShear(self): 
        '''getShear(self) -> double


Get shear value associated with this constraint.'''
        pass

    def setCustomConstraintBehavior(self, bridge): 
        '''setCustomConstraintBehavior(self, bridge)
Arguments:
	[in]	bridge = MClothConstraintBridge


Set the custom constraint behavior object.'''
        pass

    def setSoft(self, soft): 
        '''setSoft(self, soft)
Arguments:
	[in]	soft = bool


Set soft constraint.'''
        pass

class MClothControl:
    '''Access to cloth data. This class provides access to various cloth data. This includes UVs per per cloth, UVs per panel, stitcher node of a cloth, solver node of a cloth, face membership of a panel, etc. '''
    def __init__(self):
        pass


    def externalForces(self, system): 
        '''externalForces(self, system)
Arguments:
	[in]	system = MClothSystem


This will set the accelerations for all constraints, and each particle. Cloth Solver should call this function once per timestep.'''
        pass

    def getUVs(self, cloth, panel, uvs): 
        '''getUVs(self, cloth, panel, uvs)
Arguments:
	[in]	cloth = MString
	[in]	panel = MString
	[out]	uvs = MDoubleArray


Retrieves the UVs of a cloth. If a panel is specified, then this method will return only the UVs of the panel that belongs to that cloth.'''
        pass

    def getPrecedingFrame(self, system, currentTime, precedingTime): 
        '''getPrecedingFrame(self, system, currentTime, precedingTime) -> double
Returns: A double frame value. 

Arguments:
	[in]	system = MClothSystem
	[in]	currentTime = double
	[out]	precedingTime = double


Returns the frame and frame time just preceding the given "currentTime" time.'''
        pass

    def getSucceedingFrame(self, system, currentTime, succeedingTime): 
        '''getSucceedingFrame(self, system, currentTime, succeedingTime) -> double
Returns: A double frame value. 

Arguments:
	[in]	system = MClothSystem
	[in]	currentTime = double
	[out]	succeedingTime = double


Returns the frame and frame time just succeeding the given "currentTime" time.'''
        pass

    def stitcherNode(self, cloth): 
        '''stitcherNode(self, cloth) -> MObject
Returns: An MObject pointer to the stitcher node. 

Arguments:
	[in]	cloth = MString


Returns the stitcher node of the given cloth, if one exists.'''
        pass

    def stepCB(self, cloth, h): 
        '''stepCB(self, cloth, h) -> bool

Arguments:
	[in]	cloth = MClothSystem
	[in]	h = double


This will update the solve status into Maya. Cloth Solver should call this function for adaptive solution notification.'''
        pass

    def collisionCB(self, cloth, ipass, maxp): 
        '''collisionCB(self, cloth, ipass, maxp) -> bool

Arguments:
	[in]	cloth = MClothSystem
	[in]	ipass = int
	[in]	maxp = double


This will update the collision status into Maya. Cloth Solver should call this function for collision notification.'''
        pass

    def pinch(self, system, poly1, triIndex1, poly2, triIndex2): 
        '''pinch(self, system, poly1, triIndex1, poly2, triIndex2) -> int
Returns: If the new triangle has priority (LOW NUMBER) then returns -1, meaning pick the new triangle. If the priority is the same, returns 1, meaning keep the old triangle. 

Arguments:
	[in]	system = MClothSystem
	[in]	poly1 = MClothPolyhedron
	[in]	triIndex1 = unsigned
	[in]	poly2 = MClothPolyhedron
	[in]	triIndex2 = unsigned


Determine which of the two given triangles should be given priority in a rigid body collision.'''
        pass

    def loadFrame(self, rigidBody, frame, cacheNumber): 
        '''loadFrame(self, rigidBody, frame, cacheNumber)
Arguments:
	[in]	rigidBody = MClothPolyhedron
	[in]	frame = double
	[in]	cacheNumber = int


Animates rigid body vertices.'''
        pass

    def getClothFromSolver(self, solverObj, plug, clothObj): 
        '''getClothFromSolver(self, solverObj, plug, clothObj) -> bool
Returns: true if a clothObj was successfully found. 

Arguments:
	[in]	solverObj = MObject
	[in]	plug = int
	[in]	clothObj = MObject


Given a solver node and a plug index to the outMesh on the solver node, walks the DG looking for the cloth that belongs to that pair.'''
        pass

    def getClothSystem(self, node, system): 
        '''getClothSystem(self, node, system)
Arguments:
	[in]	node = MObject
	[out]	system = MClothSystem


Given a solver object, allows the user to find the cloth system pointer.'''
        pass

    def panelFaces(self, panel, faceIds): 
        '''panelFaces(self, panel, faceIds)
Arguments:
	[in]	panel = MString
	[out]	faceIds = MIntArray


Returns the face membership of a given panel via an array of faceIds.'''
        pass

    def dgTimeGivenClothFrame(self, rigidBody, frame): 
        '''dgTimeGivenClothFrame(self, rigidBody, frame) -> double
Returns: A double dependency graph time. 

Arguments:
	[in]	rigidBody = MClothPolyhedron
	[in]	frame = double


Get the dependency graph time for cloth frame.'''
        pass

    def interruptCheckCB(self, cloth): 
        '''interruptCheckCB(self, cloth) -> bool
Returns: true if an interrupt was requested, in which case the current computation in the solver should be aborted. false if no interrupt. 

Arguments:
	[in]	cloth = MClothSystem


The Cloth Solver should call this function to check for user interrupts (e.g. the user pressing the ESC key) during long periods of computation.'''
        pass

    def solveCB(self, cloth, cutoff, current, istep): 
        '''solveCB(self, cloth, cutoff, current, istep) -> bool

Arguments:
	[in]	cloth = MClothSystem
	[in]	cutoff = double
	[in]	current = double
	[in]	istep = int


This will update the solve status into Maya. Cloth Solver should call this function for linear solution notification.'''
        pass

    def panelId(self, panel): 
        '''panelId(self, panel) -> int
Returns: the panel Id of the specified panel, if valid. -1 otherwise. 

Arguments:
	[in]	panel = MString


Returns the panelId of a given panel.'''
        pass

    def solverNode(self, cloth): 
        '''solverNode(self, cloth) -> MObject
Returns: An MObject pointer to the solver node. 

Arguments:
	[in]	cloth = MString


Returns the solver node of the given cloth.'''
        pass

    def currentSolver(self): 
        '''currentSolver(self) -> MObject


Returns the current solver instance as reported in the Maya UI.'''
        pass

class MClothEdge:
    '''Interface for cloth edge. This class provides interface for cloth edge. Cloth solver writers should derive their edge class from this class. Common convenience methods are available. '''
    def __init__(self):
        pass


    def setCreaseAngle(self, theta): 
        '''setCreaseAngle(self, theta)
Arguments:
	[in]	theta = double


This method sets the crease angle for this edge.'''
        pass

    def getParticle(self, index): 
        '''getParticle(self, index) -> MClothParticle
Returns: Cloth Particle.

Arguments:
	[in]	index = int


This method returns particle associated with this edge for a given index.'''
        pass

    def getTriangle(self, index): 
        '''getTriangle(self, index) -> MClothTriangle
Returns: Cloth Triangle.

Arguments:
	[in]	index = int


This method returns triangle associated with this edge for a given index.'''
        pass

    def getCreaseAngle(self): 
        '''getCreaseAngle(self) -> double
Returns: crease angle.


This method returns the crease angle for this edge.'''
        pass

    def equals(self, edge): 
        '''equals(self, edge) -> bool
Returns: A boolean true or false. 

Arguments:
	[in]	edge = MClothEdge


Compares the two cloth edge objects.'''
        pass

class MClothForce:
    '''Interface for creating cloth solver force system. This class provides interface for cloth force system. '''
    def __init__(self):
        pass


    def setStrength(self, shear, damp): 
        '''setStrength(self, shear, damp)
Arguments:
	[in]	shear = double
	[in]	damp = double


This method sets the shear and damp values for this cloth force.'''
        pass

    def setOffset(self, offset): 
        '''setOffset(self, offset)
Arguments:
	[in]	offset = double


This method sets the offset value for this cloth force.'''
        pass

    def getParticle(self, index): 
        '''getParticle(self, index) -> MClothParticle
Returns: Cloth Particle.

Arguments:
	[in]	index = int


This method returns particle for a given index.'''
        pass

class MClothMaterial:
    '''Access to various cloth material properties. This class provides access to various cloth material properties. Cloth solver writers can override this class to get custom material properties. '''
    def __init__(self):
        pass


    def setupRelaxProperty(self): 
        '''setupRelaxProperty(self)
'''
        pass

    def __rmult__(self, value): 
        '''__rmult__(self, value) -> MClothMaterial
Returns: Update cloth material object. 

Arguments:
	[in]	value = double


Multiply each cloth property with constant value.'''
        pass

    def update(self): 
        '''update(self)
'''
        pass

    def equal(self, other): 
        '''equal(self, other) -> bool
Returns: A boolean true or false. 

Arguments:
	[in]	other = MClothMaterial


Check if two cloth material are equal.'''
        pass

    def __radd__(self, other): 
        '''__radd__(self, other) -> MClothMaterial
Returns: MClothMaterial& MClothMaterial object. 

Arguments:
	[in]	other = MClothMaterial


Add two cloth properties.'''
        pass

class MClothParticle:
    '''Interface for cloth particle. This class provides interface for cloth particle system. Cloth solver writers should derive their particle class from this class. Common convenience methods are available. '''
    def __init__(self):
        pass


    def getIndex(self): 
        '''getIndex(self)

This method returns index of this particle per cloth system basis. Cloth System can have multiple cloth objects and this method should return the index of particle considering all the cloth objects.'''
        pass

    def getOriginalMass(self): 
        '''getOriginalMass(self) -> double
Returns: A mass of this particle.


This method returns vertex constant mass of this particle.'''
        pass

    def getAccelaration(self): 
        '''getAccelaration(self) -> MVector
Returns: A MVector instance.


This method returns vertex acceleration of this particle.'''
        pass

    def setForceMultiplier(self, forceMultiplier): 
        '''setForceMultiplier(self, forceMultiplier)
Arguments:
	[in]	forceMultiplier = double


This method sets force multiplier of this particle.'''
        pass

    def getVelocity(self): 
        '''getVelocity(self) -> MVector
Returns: A MVector instance.


This method returns vertex velocity of this particle.'''
        pass

    def ignoreSolid(self, isIgnored): 
        '''ignoreSolid(self, isIgnored)
Arguments:
	[in]	isIgnored = bool


This method sets whether the Cloth to  MClothPolyhedron  collision can be ignored for this particle.'''
        pass

    def ignoreClothCollision(self, isIgnored): 
        '''ignoreClothCollision(self, isIgnored)
Arguments:
	[in]	isIgnored = bool


This method sets whether the Cloth to Cloth collision can be ignored for this particle.'''
        pass

    def getMass(self): 
        '''getMass(self) -> double
Returns: A mass of this particle.


This method returns vertex mass of this particle, which can changed during recoil.'''
        pass

    def getEdge(self, index): 
        '''getEdge(self, index) -> MClothEdge
Returns: Cloth Edge.

Arguments:
	[in]	index = int


This method returns edge associated with this particle for a given index.'''
        pass

    def equals(self, particle): 
        '''equals(self, particle) -> bool
Returns: A boolean true or false. 

Arguments:
	[in]	particle = MClothParticle


Compares the two cloth particle objects.'''
        pass

    def numEdges(self): 
        '''numEdges(self) -> int
Returns: The number of edges associated with this particle.


This method returns number of edges this particle is associated with.'''
        pass

    def collideWithPolyhedron(self, poly): 
        '''collideWithPolyhedron(self, poly) -> bool
Returns: true - if the particle should collide with the specified polyhedron (or all polyhedrons if poly == NULL). 

Arguments:
	[in]	poly = MClothPolyhedron


Particles can be excluded from collisions with other cloth triangles or rigid bodies. You should call this method to find out if this particle has been excluded from the solve.'''
        pass

    def getMaterial(self): 
        '''getMaterial(self) -> MClothMaterial
Returns: Cloth Material.


This method returns the cloth material associated with this particle.'''
        pass

    def setMass(self, mass): 
        '''setMass(self, mass)
Arguments:
	[in]	mass = double


This method sets vertex mass of this particle.'''
        pass

    def setVelocity(self, velocity): 
        '''setVelocity(self, velocity)
Arguments:
	[in]	velocity = MVector


This method sets vertex velocity of this particle.'''
        pass

    def setPosition(self, position): 
        '''setPosition(self, position)
Arguments:
	[in]	position = MPoint


This method sets vertex position of this particle.'''
        pass

    def getPosition(self): 
        '''getPosition(self) -> MPoint
Returns: A MPoint instance.


This method returns vertex position of this particle.'''
        pass

    def setAccelaration(self, acceleration): 
        '''setAccelaration(self, acceleration)
Arguments:
	[in]	acceleration = MVector


This method sets vertex acceleration of this particle.'''
        pass

class MClothPolyhedron:
    '''Interface for cloth solver collision rigid body. This class provides access to various cloth rigid body collisions. '''
    def __init__(self):
        pass


    def updateStaticFrictionMultiplier(self, faces, val): 
        '''updateStaticFrictionMultiplier(self, faces, val)
Arguments:
	[in]	faces = MIntArray
	[in]	val = double


This method updates the rigid body static friction multiplier for a given set of faces.'''
        pass

    def setUserdata(self, userDataPtr): 
        '''setUserdata(self, userDataPtr)
Arguments:
	[in]	userDataPtr = void


 Internal use only  Set user data for CpClothSolver plugin.'''
        pass

    def updateVelocityMultiplier(self, numRampSamples, offsetVelMultiplier, depthVelMultiplier): 
        '''updateVelocityMultiplier(self, numRampSamples, offsetVelMultiplier, depthVelMultiplier)
Arguments:
	[in]	numRampSamples = unsigned
	[in]	offsetVelMultiplier = float
	[in]	depthVelMultiplier = float


This method updates the rigid body offset and depth velocity multiplier values.'''
        pass

    def getUserdata(self): 
        '''getUserdata(self) -> void*


 Internal use only  Return user data to CpClothSolver plugin.'''
        pass

    def disableCollisions(self, faces): 
        '''disableCollisions(self, faces)
Arguments:
	[in]	faces = MIntArray


The MayaCloth plugin allows users to filter faces that are involved in a collision by using cloth sets. This method tells the rigid body to turn off collisions on the specified faces. Override this method you want to support this feature.'''
        pass

    def create(self, nVertices, indices, nTriangles, triDepthMap, triCollisionOffsetMap, name, numRampSamples, offsetVelIncrement, depthVelIncrement, dynFrictionMultiplier, staticFrictionMultiplier, collisionEnable): 
        '''create(self, nVertices, indices, nTriangles, triDepthMap, triCollisionOffsetMap, name, numRampSamples, offsetVelIncrement, depthVelIncrement, dynFrictionMultiplier, staticFrictionMultiplier, collisionEnable)
Arguments:
	[in]	nVertices = int
	[in]	indices = int
	[in]	nTriangles = int
	[in]	triDepthMap = double
	[in]	triCollisionOffsetMap = double
	[in]	name = char
	[in]	numRampSamples = unsigned
	[in]	offsetVelIncrement = float
	[in]	depthVelIncrement = float
	[in]	dynFrictionMultiplier = double
	[in]	staticFrictionMultiplier = double
	[in]	collisionEnable = bool


This method creates a new cloth collision object.'''
        pass

    def numTriangles(self): 
        '''numTriangles(self)

This method returns number of collision object triangles.'''
        pass

    def setCollisionEnable(self, collision): 
        '''setCollisionEnable(self, collision)
Arguments:
	[in]	collision = bool


This method enables cloth collision against collision geometry.'''
        pass

    def updateNormals(self, init): 
        '''updateNormals(self, init)
Arguments:
	[in]	init = bool


This method recalculate the normals for the rigid body.'''
        pass

    def updateCollisionDepth(self, faces, depth): 
        '''updateCollisionDepth(self, faces, depth)
Arguments:
	[in]	faces = MIntArray
	[in]	depth = double


This method sets the collision depth for all the given faces of the collision geometry.'''
        pass

    def numVertices(self): 
        '''numVertices(self)

This method returns number of collision object vertices.'''
        pass

    def updateDynFrictionMultiplier(self, faces, val): 
        '''updateDynFrictionMultiplier(self, faces, val)
Arguments:
	[in]	faces = MIntArray
	[in]	val = double


This method updates the rigid body dynamic friction multiplier for a select set of faces.'''
        pass

    def setPosition(self, index, position, cacheNumber): 
        '''setPosition(self, index, position, cacheNumber)
Arguments:
	[in]	index = int
	[in]	position = MPoint
	[in]	cacheNumber = int


This method sets vertex position for given cloth mesh at given index.'''
        pass

    def updateFromMesh(self, currTime, scale, newMesh): 
        '''updateFromMesh(self, currTime, scale, newMesh)
Arguments:
	[in]	currTime = double
	[in]	scale = double
	[in]	newMesh = MObject


This method updates the rigid body positions from given newMesh.'''
        pass

    def updateCollisionOffset(self, faces, offset): 
        '''updateCollisionOffset(self, faces, offset)
Arguments:
	[in]	faces = MIntArray
	[in]	offset = double


This method sets the collision offset for all the given faces of the collision geometry.'''
        pass

    def getPosition(self, positions): 
        '''getPosition(self, positions)
Arguments:
	[out]	positions = MPointArray


This method returns vertex positions for cloth collision object.'''
        pass

    def resetDisabledCollisions(self): 
        '''resetDisabledCollisions(self)
'''
        pass

class MClothSolverRegister:
    '''Manages cloth solvers. Provides an interface for plugins to register/unregister cloth solver classes with Maya. Whenever a new solver needs to be generated, it checks the classification string of the node for the preferred solver. If a match is found, it creates and manages the solver object (that is it deletes the solver object once the solver is removed from scene). '''
    def __init__(self):
        pass


    def registerClothSolver(self, solverTypeName, fnPtr): 
        '''registerClothSolver(self, solverTypeName, fnPtr)
Arguments:
	[in]	solverTypeName = MString
	[in]	fnPtr = MClothSolverCreatorFnPtr


registers a new cloth solver creation function by name. 
'''
        pass

    def unregisterClothSolver(self, solverTypeName): 
        '''unregisterClothSolver(self, solverTypeName)
Arguments:
	[in]	solverTypeName = MString


removes the previously registered solver 
'''
        pass

class MClothSystem:
    '''Interface for cloth solver system. This class provides interface to cloth system. Cloth solver writers should derive their solver class from this class. Common convenience methods are available. The following terms are used interchangeably:This class provides interface to complete cloth solver system. Cloth solver plugins should override this class and it should get registered through MClothSolverRegister::registerClothSolver.There can be multiple cloth mesh objects attached to one solver. Each cloth mesh can be identified uniquely by MClothHandle in solver.MClothHandle is defined as: MClothHandle is essentilly plugIndex of outMesh attribute for each cloth mesh. CpClothPlugin maintains the list of cloth mesh objects connected with the solver.Typically, solver will represent the different cloth mesh objects as one complete mesh in their internal data structures. This helps in linerly indexing the particle simulation.Some of the simulation related methods for example interpolate, step_forward and restart work independent of MClothHandle.ClothSystem also has interface methods to add/remove Constraint, Forces and Collision objects into solver. '''
    def __init__(self):
        pass


    def setFrameSize(self, frameSize): 
        '''setFrameSize(self, frameSize)
Arguments:
	[in]	frameSize = double


This method sets frame size for simulation.'''
        pass

    def setRecoilDuration(self, duration): 
        '''setRecoilDuration(self, duration)
Arguments:
	[in]	duration = int


This method sets recoil duration value into solver. Recoil scale represents time length until mass is restored after collision.'''
        pass

    def setCurrentTime(self, currTime): 
        '''setCurrentTime(self, currTime)
Arguments:
	[in]	currTime = double


This method sets current time for simulation.'''
        pass

    def findTriangle(self, sp, x, maxd, closestDist): 
        '''findTriangle(self, sp, x, maxd, closestDist) -> int
Returns: Returns index of closest triangle.

Arguments:
	[in]	sp = MClothPolyhedron
	[in]	x = MPoint
	[in]	maxd = double
	[in]	closestDist = double


This method takes a cloth-vertex location, x, and an  MClothPolyhedron , sp, and returns the index of the triangle in sp that is the most suitable place to pin the vertex at x to. If no suitable triangle can be found, findTriangle returns -1.'''
        pass

    def getUserdata(self): 
        '''getUserdata(self) -> void*


 Internal use only  Return user data to MayaCloth plugin.'''
        pass

    def setRecoilWidth(self, width): 
        '''setRecoilWidth(self, width)
Arguments:
	[in]	width = int


This method sets recoil width value into solver. Recoil scale represents number of rows of neighbor particles to dampen.'''
        pass

    def findClosestPolyhedron(self, spAry, spCount, x, maxd): 
        '''findClosestPolyhedron(self, spAry, spCount, x, maxd) -> int
Returns: Returns index of closest collision object.

Arguments:
	[in]	spAry = MClothPolyhedron
	[in]	spCount = int
	[in]	x = MPoint
	[in]	maxd = double


This method returns closest collision object given an array of collision objects ( MClothPolyhedron ) and a cloth point.'''
        pass

    def numTriangles(self): 
        '''numTriangles(self)

This method returns number of cloth triangles in complete cloth system. This is essentially sum all of the triangles for each individual cloth mesh.'''
        pass

    def getRecoilWidth(self): 
        '''getRecoilWidth(self) -> int
Returns: The recoil width value.


This method returns recoil width value from solver. Recoil scale represents number of rows of neighbor particles to dampen.'''
        pass

    def setIgnoreCollisions(self, ignore): 
        '''setIgnoreCollisions(self, ignore)
Arguments:
	[in]	ignore = bool


This method sets whether the Cloth to Cloth collision can be ignored for complete cloth system.'''
        pass

    def setBendingForce(self, handle, triangleNo, edgeNo, theta, weight): 
        '''setBendingForce(self, handle, triangleNo, edgeNo, theta, weight)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	triangleNo = int
	[in]	edgeNo = int
	[in]	theta = double
	[in]	weight = double


This method sets crease angle and updates the values of bend angle for given triangle and edge pair.'''
        pass

    def getClothContacts(self, handle, index, result): 
        '''getClothContacts(self, handle, index, result)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	result = MIntArray
	[in]	index = int


This method returns cloth particle contacts indices.'''
        pass

    def getBendingForce(self, handle, triangleNo, edgeNo): 
        '''getBendingForce(self, handle, triangleNo, edgeNo) -> double
Returns: Crease angle value.

Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	triangleNo = int
	[in]	edgeNo = int


This method gets crease angle for given triangle and edge pair.'''
        pass

    def setPosition(self, handle, position): 
        '''setPosition(self, handle, position)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	position = MPointArray


This method sets vertex positions of all the particles for given cloth mesh.'''
        pass

    def lockParticle(self, particle, poly, triIndex): 
        '''lockParticle(self, particle, poly, triIndex) -> MClothConstraint
Returns: The cloth constraint object.

Arguments:
	[in]	particle = MClothParticle
	[in]	poly = MClothPolyhedron
	[in]	triIndex = int


This method adds and returns a new cloth constraint. The newly created constraint should lock the supplied particle with triangle of a given poly.'''
        pass

    def step_forward(self, stepSize): 
        '''step_forward(self, stepSize) -> double

Arguments:
	[in]	stepSize = double


This method increments the cloth simulation by stepSize.'''
        pass

    def getClothNeighbours(self, handle, index, result): 
        '''getClothNeighbours(self, handle, index, result)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	result = MIntArray
	[in]	index = int


This method returns neighboring cloth particle indices.'''
        pass

    def getVelocity(self, handle, velocity): 
        '''getVelocity(self, handle, velocity)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	velocity = MVectorArray


This method returns vertex velocity of all the particles for given cloth mesh.'''
        pass

    def addSpring(self, particle1, clothTriangle, bary, shear, damp): 
        '''addSpring(self, particle1, clothTriangle, bary, shear, damp) -> MClothForce
Returns: The cloth force constraint object.

Arguments:
	[in]	particle1 = MClothParticle
	[in]	clothTriangle = MClothTriangle
	[in]	bary = MPoint
	[in]	shear = double
	[in]	damp = double


This method adds and returns a new cloth force constraint. The newly created constraint should create a spring force between supplied particles. For example : Cloth Force Constraint.'''
        pass

    def setMaterial(self, handle, material, triIndex): 
        '''setMaterial(self, handle, material, triIndex)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	material = MClothMaterial
	[in]	triIndex = int


This method sets material at given triangle index.'''
        pass

    def addCommand(self, command): 
        '''addCommand(self, command)
Arguments:
	[in]	command = MClothConstraintCmd


This method adds cloth constraint command object. For example : Cloth Pin Constraint.'''
        pass

    def restart(self, frameTime): 
        '''restart(self, frameTime)
Arguments:
	[in]	frameTime = double


This method resets/restarts cloth simulation to given frameTime.'''
        pass

    def setPinchMethod(self, method): 
        '''setPinchMethod(self, method)
Arguments:
	[in]	method = short


This method sets cloth pinch method. Set the pinch method in the solver. The choices are: PinchMethodClosestDistance : When, cloth is pinched by 2 triangles, pick the closer triangle. PinchMethodFirstContact : When, cloth is pinched by 2 triangles, pick the 1st triangle in contact.'''
        pass

    def findClothTriangle(self, clothPositions, x, barycentric): 
        '''findClothTriangle(self, clothPositions, x, barycentric) -> int
Returns: Returns index of closest triangle.

Arguments:
	[in]	clothPositions = MPointArray
	[in]	x = MPoint
	[in]	barycentric = MPoint


This method finds the relative triangle index of the closest triangle to a world space point given all the cloth positions.'''
        pass

    def stepSize(self): 
        '''stepSize(self) -> double
Returns: The step size increment value.


This method returns step size increment value from solver.'''
        pass

    def addRigidbody(self, body): 
        '''addRigidbody(self, body)
Arguments:
	[in]	body = MClothPolyhedron


This method adds cloth collision object.'''
        pass

    def postSolve(self): 
        '''postSolve(self) -> bool


This method is called after the calls to step_forward.'''
        pass

    def setUserdata(self, userDataPtr): 
        '''setUserdata(self, userDataPtr)
Arguments:
	[in]	userDataPtr = void


 Internal use only  Set user data for MayaCloth plugin.'''
        pass

    def updateMaterial(self, handle): 
        '''updateMaterial(self, handle)
Arguments:
	[in]	handle = MClothSystem.MClothHandle


This method updates material in internal data structure by recalculating values of mass from updated and triangular area and density values.'''
        pass

    def removeSpring(self, springForce): 
        '''removeSpring(self, springForce)
Arguments:
	[in]	springForce = MClothForce


This method removes cloth force constraint.'''
        pass

    def preSolve(self): 
        '''preSolve(self) -> bool


This method is called prior to the calls to step_forward.'''
        pass

    def removeCommand(self, command): 
        '''removeCommand(self, command)
Arguments:
	[in]	command = MClothConstraintCmd


This method removes cloth constraint command object.'''
        pass

    def getNewMaterialInstance(self): 
        '''getNewMaterialInstance(self) -> MClothMaterial
Returns: A new cloth material instance.


This method returns a new material instance. Cloth plugin maintains the list of material instance. This method needs to allocate the cloth material object using new and return the pointer. (This is necessary because delete is called on the returned pointer by cloth plugin when work is done.)'''
        pass

    def numParticles(self): 
        '''numParticles(self)

This method returns number of cloth particles in complete cloth system. This is essentially sum all of the particles for each individual cloth mesh.'''
        pass

    def setBendResistance(self, handle, triangleNo, edgeNo, resistance): 
        '''setBendResistance(self, handle, triangleNo, edgeNo, resistance)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	triangleNo = int
	[in]	edgeNo = int
	[in]	resistance = double


This method sets bend resistance for given triangle and edge pair.'''
        pass

    def findNeighborTriangles(self, handle, vertexIndex, neighborhood, neighborTriangles): 
        '''findNeighborTriangles(self, handle, vertexIndex, neighborhood, neighborTriangles)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	vertexIndex = int
	[in]	neighborhood = int
	[in]	neighborTriangles = MIntArray


This method finds the triangle index that are "close" to this vertex given an absolute vertex index of a cloth particle. These vertices will be excluded in the process of making a cloth-to-cloth constraint.'''
        pass

    def setVelocity_CutOff(self, min, max, damping): 
        '''setVelocity_CutOff(self, min, max, damping)
Arguments:
	[in]	min = double
	[in]	max = double
	[in]	damping = double


This method sets minimum, maximum and damping velocity cut off values.'''
        pass

    def interpolate(self, frameTime): 
        '''interpolate(self, frameTime)
Arguments:
	[in]	frameTime = double


This method interpolates cloth at given frameTime.'''
        pass

    def getTriangle(self, handle, index): 
        '''getTriangle(self, handle, index) -> MClothTriangle
Returns: Cloth triangle instance.

Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	index = unsigned


This method returns cloth triangle at given index.'''
        pass

    def getStress_scaled(self, handle, stress): 
        '''getStress_scaled(self, handle, stress)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	stress = double


This method returns scaled vertex stress of particles. This method needs to scale the stress, exaggerating those closer to 1, but keeping them in the 0..1 range before returning the values.'''
        pass

    def getClothForces(self, handle, index, result): 
        '''getClothForces(self, handle, index, result)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	result = MDoubleArray
	[in]	index = int


This method returns cloth particle contact forces.'''
        pass

    def setVelocity(self, handle, velocity): 
        '''setVelocity(self, handle, velocity)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	velocity = MVectorArray


This method sets vertex velocities of all the particles for given cloth mesh.'''
        pass

    def getPosition(self, handle, position): 
        '''getPosition(self, handle, position)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	position = MPointArray


This method returns vertex positions of all the particles for given cloth mesh.'''
        pass

    def getStress(self, handle, index, result): 
        '''getStress(self, handle, index, result)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[out]	result = MDoubleArray
	[in]	index = int


This method returns vertex stress of particle.'''
        pass

    def solverNode(self): 
        '''solverNode(self) -> MObject


Returns an  MObject  which represents the solver node that this cloth system belongs.'''
        pass

    def unlockParticle(self, constraint): 
        '''unlockParticle(self, constraint)
Arguments:
	[in]	constraint = MClothConstraint


This method removes cloth constraint.'''
        pass

    def frameSize(self): 
        '''frameSize(self) -> double
Returns: The framesize value.


This method returns frame size value from solver.'''
        pass

    def currentTime(self): 
        '''currentTime(self) -> double
Returns: The current time value.


This method returns current time value from solver.'''
        pass

    def addCloth(self, handle, nParticles, nTriangles, vertexList, particles, seam, nSeam, uvs): 
        '''addCloth(self, handle, nParticles, nTriangles, vertexList, particles, seam, nSeam, uvs)
Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	nParticles = int
	[in]	nTriangles = int
	[in]	vertexList = int
	[in]	particles = MPointArray
	[in]	seam = MSeamInfo
	[in]	nSeam = int
	[in]	uvs = MPointArray


Add a new cloth object mesh to this solver at given handle.'''
        pass

    def getParticle(self, handle, index): 
        '''getParticle(self, handle, index) -> MClothParticle
Returns: Cloth particle instance.

Arguments:
	[in]	handle = MClothSystem.MClothHandle
	[in]	index = unsigned


This method returns cloth particle at given index.'''
        pass

    def createRigidbody(self, numVertices, indices, numTriangles, triDepthMap, triCollisionOffsetMap, name, numRampSamples, offsetVelIncrement, depthVelIncrement, collisionEnable): 
        '''createRigidbody(self, numVertices, indices, numTriangles, triDepthMap, triCollisionOffsetMap, name, numRampSamples, offsetVelIncrement, depthVelIncrement, collisionEnable) -> MClothPolyhedron
Returns: The cloth polyhedron object.

Arguments:
	[in]	numVertices = int
	[in]	indices = int
	[in]	numTriangles = int
	[in]	triDepthMap = double
	[in]	triCollisionOffsetMap = double
	[in]	name = char
	[in]	numRampSamples = unsigned
	[in]	offsetVelIncrement = float
	[in]	depthVelIncrement = float
	[in]	collisionEnable = bool


This method creates and returns a new cloth collision object. Note: This method should not automatically add the newly created collision object.'''
        pass

    def getRecoilDuration(self): 
        '''getRecoilDuration(self) -> int
Returns: The recoil duration value.


This method returns recoil duration value from solver. Recoil scale represents time length until mass is restored after collision.'''
        pass

    def removeCloth(self, handle): 
        '''removeCloth(self, handle)
Arguments:
	[in]	handle = MClothSystem.MClothHandle


Remove a seamed cloth mesh from this solver.'''
        pass

    def removeRigidbody(self, body): 
        '''removeRigidbody(self, body)
Arguments:
	[in]	body = MClothPolyhedron


This method removes cloth collision object.'''
        pass

    def lastTime(self): 
        '''lastTime(self) -> double
Returns: The last time value.


This method returns last time value from solver.'''
        pass

class MClothTriangle:
    '''Interface for cloth triangle. This class provides interface for cloth triangle. Cloth solver writers should derive their triangle class from this class. Common convenience methods are available. '''
    def __init__(self):
        pass


    def getUVs(self, uArray, vArray): 
        '''getUVs(self, uArray, vArray)
Arguments:
	[out]	uArray = MDoubleArray
	[out]	vArray = MDoubleArray


This method copies the texture coordinate list for this triangle into the given uv arrays.'''
        pass

    def getEdge(self, index): 
        '''getEdge(self, index) -> MClothEdge
Returns: Cloth Edge.

Arguments:
	[in]	index = int


This method returns edge associated with this triangle for a given index.'''
        pass

    def contains(self, particle): 
        '''contains(self, particle) -> bool
Returns: A boolean true or false. 

Arguments:
	[in]	particle = MClothParticle


Check if given cloth particle is contained in this triangle.'''
        pass

    def getMaterial(self): 
        '''getMaterial(self) -> MClothMaterial
Returns: Cloth Material.


This method returns the cloth material associated with this triangle.'''
        pass

    def equals(self, triangle): 
        '''equals(self, triangle) -> bool
Returns: A boolean true or false. 

Arguments:
	[in]	triangle = MClothTriangle


Compares the two cloth triangle objects.'''
        pass

    def getParticle(self, index): 
        '''getParticle(self, index) -> MClothParticle
Returns: Cloth Particle.

Arguments:
	[in]	index = int


This method returns particle associated with this triangle for a given index.'''
        pass

    def getUV(self, vertexIndex, u, v): 
        '''getUV(self, vertexIndex, u, v)
Arguments:
	[in]	vertexIndex = int
	[out]	u = double
	[out]	v = double


Get the value of the specified texture coordinate from this triangle's uv list. The vertexIndex is the element in the uv list that will be retrieved.'''
        pass

