import maya.cmds as cmds
import re
def ml_removeUnusedNodes():
	print "\n\n\n"
	m_default = [ "time1", "sequenceManager1", "renderPartition", "renderGlobalsList1", "mtorPartition", "defaultLightList1", "defaultShaderList1", "postProcessList1", "defaultRenderUtilityList1", "defaultRenderingList1", "lightList1", "defaultTextureList1", "lambert1", "particleCloud1", "initialShadingGroup", "initialParticleSE", "initialMaterialInfo", "shaderGlow1", "dof1", "defaultRenderGlobals", "defaultRenderQuality", "defaultResolution", "defaultLightSet", "defaultObjectSet", "defaultViewColorManager", "hardwareRenderGlobals", "hardwareRenderingGlobals", "characterPartition", "defaultHardwareRenderGlobals", "ikSystem", "hyperGraphInfo", "hyperGraphLayout", "globalCacheControl", "dynController1", "strokeGlobals", "lightLinker1", "layerManager", "defaultLayer", "renderLayerManager", "defaultRenderLayer" ]
	m_cameras = cmds.ls( cmds.listCameras(), dag=True, long=True )
	m_cameras = [ m_cameras[i] for i in range( 0, len( m_cameras )) if cmds.camera( m_cameras[i], query=True, startupCamera=True ) or re.findall( "ep[0-9]+sc[0-9]+", m_cameras[i] ) ]
	[ m_default.append( m_cameras[i] ) for i in range( 0, len( m_cameras )) ]
	m_items = []
	m_nodes = cmds.ls( long=True )
	m_shaders = cmds.ls( materials=True, long=True )
	for i in range( 0, len( m_nodes )):
		if cmds.objExists( m_nodes[i] ) and m_nodes[i] not in m_default and not cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ):
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List not used filters, renderman nodes, gpu caches, shading engines, rib archives...
			m_law = False
			if cmds.nodeType( m_nodes[i] ) in [ "objectTypeFilter", "shadingEngine", "lookAt", "nodeEditorPanel", "file", "place2dTexture", "animCurveTA", "animCurveTL", "animCurveTU", "objectNameFilter", "groupId", "lambert", "materialInfo", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter", "RenderManArchive", "gpuCache", "RenderMan", "renderLayer", "displayLayer", "animLayer", "pointLight", "volumeLight", "areaLight", "spotLight", "directionalLight", "ambientLight", "RMSLightBlocker", "RMSAreaLight", "RMSEnvLight", "RMSGILight", "RMSCausticLight", "RMSGIPtcLight", "RMSGeoAreaLight", "RMSGeoLightBlocker", "RMSPointLight", "camera" ] or m_nodes[i] in m_shaders:
				if m_nodes[i] not in m_items and m_nodes[i] not in m_default:
					#GroupID.
					if cmds.nodeType( m_nodes[i] ) == "groupId":
						if not cmds.listConnections( m_nodes[i], type="groupParts" ) and not cmds.listConnections( m_nodes[i], type="mesh" ):
							m_law = True
					#Animation curves.
					elif cmds.nodeType( m_nodes[i] ) in [ "animCurveTA", "animCurveTL", "animCurveTU" ]:
						if not cmds.listConnections( m_nodes[i], type="nurbsCurve" ) and not cmds.listConnections( m_nodes[i], type="mesh" ) and not cmds.listConnections( m_nodes[i], type="blendShape" ):
							m_connections = cmds.listConnections( m_nodes[i] )
							m_connections = cmds.ls( m_connections, dag=True, shapes=True )
							m_used = False
							for n in range( 0, len( m_connections )):
								if cmds.nodeType( m_connections[n] ) in [ "camera", "stereoRigCamera" ]:
									m_used = True
									break
							if m_used is True:
								m_law = True
					#Shading engines.
					elif cmds.nodeType( m_nodes[i] ) == "shadingEngine":
						if not cmds.listConnections( m_nodes[i], type="mesh" ):
							m_law = True
					#Shaders.
					elif m_nodes[i] in m_shaders:
						m_shadingEngine = cmds.listConnections( m_nodes[i], type="shadingEngine" )
						if m_shadingEngine:
							if not cmds.listConnections( m_shadingEngine, type="mesh" ):
								m_law = True
							else:
								m_images = cmds.listConnections( m_nodes[i], type="file" )
								if not m_images:
									m_law = True
								else:
									for n in range( 0, len( m_images )):
										m_shader_texture = cmds.getAttr( "%s.fileTextureName" % m_images[n] )
										if not m_shader_texture or not re.findall( "/anm|\\anm|/textures|\\textures", m_shader_texture ):
											m_law = True
						else:
							m_law = True
					#Textures.
					elif cmds.nodeType( m_nodes[i] ) in [ "file", "place2dTexture", "materialInfo" ]:
						m_connections = cmds.listHistory( m_nodes[i] )
						if m_connections:
							m_connections = cmds.ls( cmds.listConnections( m_connections ), long=True )
							if not cmds.listConnections( m_connections, type="mesh" ) and "lambert1" in cmds.listConnections( m_connections ):
								m_law = True
						else:
							m_law = True
					else:
						m_law = True
					if m_law is True:
						if m_nodes[i] not in m_items:
							m_items.append( m_nodes[i] )
							print "Found not used node: %s" % m_nodes[i]
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List empty groups.
			elif cmds.nodeType( m_nodes[i] ) in [ "transform" ]:
				m_law = True
				m_temp = cmds.ls( m_nodes[i], dag=True, noIntermediate=True, long=True )
				for n in range( 0, len( m_temp )):
					m_connections = cmds.listConnections( m_temp[n] )
					if cmds.nodeType( m_temp[n] ) != "transform":
						m_law = False
						break
					else:
						if m_connections:
							m_law = False
							break
				if m_law is True:
					if m_nodes[i] not in m_items and m_nodes[i] not in m_default:
						m_items.append( m_nodes[i] )
						print "Found not used or empty transform: %s" % m_nodes[i]
						continue
					continue
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List hidden and not used nodes.
			if cmds.ls( m_nodes[i], dag=True, long=True ) and not cmds.listConnections( cmds.ls( m_nodes[i], dag=True, long=True )) and ((( cmds.attributeQuery( "intermediateObject", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.intermediateObject" % m_nodes[i] )) or ( cmds.attributeQuery( "visibility", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.visibility" % m_nodes[i] ) == 0 ))):
				if m_nodes[i] not in m_items and m_nodes[i] not in m_default:
					m_items.append( m_nodes[i] )
					print "Found not used node and hidden node: %s" % m_nodes[i]
					continue
	if m_items:
		cmds.delete( m_items, hi=True )
	return m_items