'''
import sys
sys.path.append( 'C:/Users/guzha_k/Desktop' )
import ml_cleanup_interface
reload( ml_cleanup_interface )
ml_cleanup_interface.main()	
'''

import maya.cmds as cmds
import maya.mel as mel
import os
import sys
import re
import ml_slim
import ml_cleanup
if cmds.about( b=True ) is False:
	import maya.OpenMayaUI
	from PyQt4 import QtCore, QtGui, Qt
	import sip

def ml_maya_app():
	m_app = maya.OpenMayaUI.MQtUtil.mainWindow()
	return sip.wrapinstance( long( m_app ), QtCore.QObject )
	
class Window( QtGui.QDialog ):
	def __init__( self, parent=ml_maya_app()):
		super( Window, self ).__init__( parent )
		#main layout.
		self.m_main_layout = QtGui.QHBoxLayout()
		self.m_main_layout.setSpacing( 0 )
		self.m_main_layout.setContentsMargins( 3, 3, 3, 3 )
		#manager layout.
		self.m_manager_layout = QtGui.QVBoxLayout()
		self.m_managerView_layout = QtGui.QVBoxLayout()
		self.m_managerActions_layout = QtGui.QHBoxLayout()
		self.m_manager_groupbox = QtGui.QGroupBox( " Setup manager: " )
		self.m_managerView_groupbox = QtGui.QGroupBox( "" )
		self.m_managerActions_groupbox = QtGui.QGroupBox( "" )
		self.m_managerActions_groupbox.setMaximumHeight( 50 )
		self.m_managerView_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_managerActions_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_manager_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_managerView_groupbox.setLayout( self.m_managerView_layout )
		self.m_managerActions_groupbox.setLayout( self.m_managerActions_layout )
		self.m_manager_treeview = WidgetTree()
		#self.m_action01 = QtGui.QAction( self )
		#self.m_manager_treeview.addAction( self.m_action01 )
		self.m_manager_treeview.ml_setColumns( [ "Active", "Name" ] )
		self.m_manager_treeview.setAlternatingRowColors( True )
		self.m_manager_treeview.setSelectionMode( QtGui.QAbstractItemView.ExtendedSelection )
		self.m_manager_treeview.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
		self.m_manager_treeview.setHeaderHidden(True)
		self.m_manager_treeview.customContextMenuRequested.connect( self.ml_openContextMenu )
		self.m_manager_treeview.doubleClicked.connect( self.ml_changeActive )
		self.m_managerView_layout.addWidget( self.m_manager_treeview )
		self.m_splitter_01 = QtGui.QSplitter( self )
		self.m_splitter_01.setOrientation( QtCore.Qt.Vertical )
		self.m_splitter_01.addWidget( self.m_managerView_groupbox )
		self.m_splitter_01.addWidget( self.m_managerActions_groupbox )
		self.m_manager_layout.addWidget( self.m_splitter_01 )
		self.m_manager_groupbox.setLayout( self.m_manager_layout )
		#manager content.
		self.m_progress = QtGui.QProgressBar()
		self.m_progress.setRange( 0, 100 )
		self.m_progress.setValue( 0 )
		self.m_progress.setTextVisible( True )
		self.m_close_button = QtGui.QPushButton( "Close" )
		self.m_setup_button = QtGui.QPushButton( "Setup" )
		self.m_close_button.released.connect( self.close )
		self.m_setup_button.released.connect( self.ml_setup )
		self.m_managerActions_layout.addWidget( self.m_close_button )
		self.m_managerActions_layout.addWidget( self.m_setup_button )
		self.m_managerActions_layout.addWidget( self.m_progress )
		#self.m_manager_treeview.addTopLevelItem( self.m_item )
		#settings layout.
		self.m_settings_layout = QtGui.QVBoxLayout()
		self.m_settingsView_layout = QtGui.QVBoxLayout()
		self.m_settingsActions_layout = QtGui.QHBoxLayout()
		self.m_settings_groupbox = QtGui.QGroupBox( " Settings: " )
		self.m_settingsView_groupbox = QtGui.QGroupBox( "" )
		self.m_settingsActions_groupbox = QtGui.QGroupBox( "" )
		self.m_settings_groupbox.setMaximumWidth( 300 )
		self.m_settings_groupbox.setMinimumWidth( 256 )
		self.m_settingsActions_groupbox.setMaximumHeight( 50 )
		self.m_settingsView_area = QtGui.QScrollArea()
		self.m_settingsView_area.setWidget( self.m_settingsView_groupbox )
		self.m_settingsView_area.setWidgetResizable( True )
		self.m_settingsView_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_settingsActions_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_settings_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_settingsView_groupbox.setLayout( self.m_settingsView_layout )
		self.m_settingsActions_groupbox.setLayout( self.m_settingsActions_layout )
		self.m_splitter_02 = QtGui.QSplitter( self )
		self.m_splitter_02.setOrientation( QtCore.Qt.Vertical )
		self.m_splitter_02.addWidget( self.m_settingsView_area )
		self.m_splitter_02.addWidget( self.m_settingsActions_groupbox )
		self.m_settings_layout.addWidget( self.m_splitter_02 )
		self.m_setupTypeModeling_layout = QtGui.QVBoxLayout()
		self.m_setupTypeModeling_groupbox = QtGui.QGroupBox( " Modelling options: " )
		self.m_setupTypeModeling_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_setupTypeModeling_groupbox.setLayout( self.m_setupTypeModeling_layout )
		self.m_setupTypeTexture_layout = QtGui.QVBoxLayout()
		self.m_setupTypeTexture_groupbox = QtGui.QGroupBox( " Texturing options: " )
		self.m_setupTypeTexture_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_setupTypeTexture_groupbox.setLayout( self.m_setupTypeTexture_layout )
		self.m_setupTypeSlim_layout = QtGui.QVBoxLayout()
		self.m_setupTypeSlim_groupbox = QtGui.QGroupBox( " Slim options: " )
		self.m_setupTypeSlim_groupbox.setStyleSheet( "QGroupBox{ font-weight: bold; font-size: 10px; }" )
		self.m_setupTypeSlim_groupbox.setLayout( self.m_setupTypeSlim_layout )
		self.m_settingsView_layout.addWidget( self.m_setupTypeModeling_groupbox )
		self.m_settingsView_layout.addWidget( self.m_setupTypeTexture_groupbox )
		self.m_settingsView_layout.addWidget( self.m_setupTypeSlim_groupbox )
		self.m_settings_groupbox.setLayout( self.m_settings_layout )
		#settings content.
		self.m_setup_mayaNames_checkbox = QtGui.QCheckBox( "Incorrect maya names" )
		self.m_setup_mayaNames_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_mayaNames_checkbox.setMinimumHeight( 15 )
		self.m_setup_mayaNames_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_mayaNames_checkbox )
		self.m_setup_slimSetup_checkbox = QtGui.QCheckBox( "Slim nodes hierarchy" )
		self.m_setup_slimSetup_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_slimSetup_checkbox.setMinimumHeight( 15 )
		self.m_setup_slimSetup_checkbox.setChecked( True )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_slimSetup_checkbox )
		self.m_setup_slimSetupNames_checkbox = QtGui.QCheckBox( "Slim synchronise names with maya" )
		self.m_setup_slimSetupNames_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_slimSetupNames_checkbox.setMinimumHeight( 15 )
		self.m_setup_slimSetupNames_checkbox.setChecked( True )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_slimSetupNames_checkbox )
		self.m_setup_slimUniqueify_checkbox = QtGui.QCheckBox( "Uniqueify scene slim id" )
		self.m_setup_slimUniqueify_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_slimUniqueify_checkbox.setMinimumHeight( 15 )
		self.m_setup_slimUniqueify_checkbox.setChecked( True )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_slimUniqueify_checkbox )
		self.m_setup_hierarchy_checkbox = QtGui.QCheckBox( "Maya nodes hierarchy ( bugs )" )
		self.m_setup_hierarchy_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_hierarchy_checkbox.setMinimumHeight( 15 )
		self.m_setup_hierarchy_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_hierarchy_checkbox )
		self.m_setup_history_checkbox = QtGui.QCheckBox( "History" )
		self.m_setup_history_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_history_checkbox.setMinimumHeight( 15 )
		self.m_setup_history_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_history_checkbox )
		self.m_setup_unused_checkbox = QtGui.QCheckBox( "Unused maya nodes" )
		self.m_setup_unused_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_unused_checkbox.setMinimumHeight( 15 )
		self.m_setup_unused_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_unused_checkbox )
		self.m_setup_freezeSetup_checkbox = QtGui.QCheckBox( "Need to freeze transforms" )
		self.m_setup_freezeSetup_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_freezeSetup_checkbox.setMinimumHeight( 15 )
		self.m_setup_freezeSetup_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_freezeSetup_checkbox )
		self.m_setup_combine_checkbox = QtGui.QCheckBox( "Combine similar nodes ( info )" )
		self.m_setup_combine_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_combine_checkbox.setMinimumHeight( 15 )
		self.m_setup_combine_checkbox.setChecked( True )
		self.m_setupTypeTexture_layout.addWidget( self.m_setup_combine_checkbox )
		self.m_setup_attrSetup_checkbox = QtGui.QCheckBox( "Maya node attributes" )
		self.m_setup_attrSetup_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_attrSetup_checkbox.setMinimumHeight( 15 )
		self.m_setup_attrSetup_checkbox.setChecked( True )
		self.m_setupTypeTexture_layout.addWidget( self.m_setup_attrSetup_checkbox )
		self.m_setup_material_checkbox = QtGui.QCheckBox( "Need slim assignment" )
		self.m_setup_material_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_material_checkbox.setMinimumHeight( 15 )
		self.m_setup_material_checkbox.setChecked( True )
		self.m_setupTypeTexture_layout.addWidget( self.m_setup_material_checkbox )
		self.m_setup_nonManifold_checkbox = QtGui.QCheckBox( "Non-manifold geometry" )
		self.m_setup_nonManifold_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_nonManifold_checkbox.setMinimumHeight( 15 )
		self.m_setup_nonManifold_checkbox.setChecked( True )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_nonManifold_checkbox )
		self.m_setup_unusedSlim_checkbox = QtGui.QCheckBox( "Unused slim nodes" )
		self.m_setup_unusedSlim_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_unusedSlim_checkbox.setMinimumHeight( 15 )
		self.m_setup_unusedSlim_checkbox.setChecked( True )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_unusedSlim_checkbox )
		self.m_setup_normals_checkbox = QtGui.QCheckBox( "Normals direction" )
		self.m_setup_normals_checkbox.setStyleSheet("QCheckBox{color: rgb(180, 50, 50);}")
		self.m_setup_normals_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_normals_checkbox.setMinimumHeight( 15 )
		self.m_setup_normals_checkbox.setChecked( False )
		self.m_setupTypeModeling_layout.addWidget( self.m_setup_normals_checkbox )
		self.m_setup_mask_checkbox = QtGui.QCheckBox( "Mask" )
		self.m_setup_mask_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_mask_checkbox.setMinimumHeight( 15 )
		self.m_setup_mask_checkbox.setChecked( True )
		self.m_setupTypeTexture_layout.addWidget( self.m_setup_mask_checkbox )
		self.m_setup_shading_checkbox = QtGui.QCheckBox( "Default shading" )
		self.m_setup_shading_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_shading_checkbox.setMinimumHeight( 15 )
		self.m_setup_shading_checkbox.setChecked( True )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_shading_checkbox )
		self.m_setup_bound_checkbox = QtGui.QCheckBox( "Displacement bound ( warning )" )
		self.m_setup_bound_checkbox.setStyleSheet("QCheckBox{color: rgb(180, 50, 50)}")
		self.m_setup_bound_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_bound_checkbox.setMinimumHeight( 15 )
		self.m_setup_bound_checkbox.setChecked( False )
		self.m_setupTypeTexture_layout.addWidget( self.m_setup_bound_checkbox )
		self.m_setup_bake_checkbox = QtGui.QCheckBox( "Bake slim to color ( not available )" )
		self.m_setup_bake_checkbox.setStyleSheet("QCheckBox{color: rgb(180, 50, 50)}")
		self.m_setup_bake_checkbox.setSizePolicy( QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum )
		self.m_setup_bake_checkbox.setMinimumHeight( 15 )
		self.m_setup_bake_checkbox.setChecked( False )
		self.m_setupTypeSlim_layout.addWidget( self.m_setup_bake_checkbox )
		self.m_update_button = QtGui.QPushButton( "Update" )
		self.m_update_button.released.connect( self.ml_update )
		self.m_settingsActions_layout.addWidget( self.m_update_button )
		#window.
		self.m_splitter_03 = QtGui.QSplitter( self )
		self.m_splitter_03.addWidget( self.m_manager_groupbox )
		self.m_splitter_03.addWidget( self.m_settings_groupbox )
		self.m_main_layout.addWidget( self.m_splitter_03 )
		self.setMinimumWidth( 750 )
		self.setMinimumHeight( 450 )
		self.setLayout( self.m_main_layout )
		self.setWindowTitle( "Cleanup settings ( contain %s nodes )" % len( cmds.ls()) )
	def ml_getActiveTreeChildrens( self ):
		def ml_getActiveTreeChildrens_exec( m_item, m_parent=None ):
			if m_item.m_active is False:
				pass
			else:
				m_childrens = m_item.m_childrens
				if len( m_childrens ) != len( m_item.ml_getChildrens()):
					m_temp = {}
				else:
					m_temp = []
				if m_parent is None:
					m_result.update( { m_item.m_name:m_temp } )
				else:
					if type( m_parent ) is dict:
						m_parent.update( { m_item.m_name:m_temp } )
					else:
						m_parent.append( m_item.m_name )
				for i in range( 0, len( m_childrens )):
					ml_getActiveTreeChildrens_exec( m_childrens[i], m_parent=m_temp )
		m_result = {}
		m_items = self.m_manager_treeview.m_childrens
		for i in range( 0, len( m_items )):
			ml_getActiveTreeChildrens_exec( m_items[i] )
		return m_result
	def ml_changeActive( self ):
		m_selected = self.m_manager_treeview.ml_getSelected()
		if m_selected:
			m_selected[-1].m_elements[ 0 ].m_widget.setCheckState( not m_selected[-1].m_elements[ 0 ].m_widget.checkState() and True )
			m_selected[-1].m_elements[ 0 ].m_widget.ml_changeActive()
	def ml_select( self ):
		cmds.select( clear=True )
		m_selected = self.m_manager_treeview.ml_getSelected()
		for i in range( 0, len( m_selected )):
			m_childs = m_selected[i].ml_getChildrens()
			for n in range( 0, len( m_childs )):
				if m_childs[n].m_type not in [ "python", "slim", "group" ]:
					cmds.select( m_childs[n].m_name, add=True )
				elif m_childs[n].m_type in [ "slim" ]:
					ml_cleanup.ml_slimCmd( "select_shader %s" % m_childs[n].m_name, debug=False )
			if m_selected[i].m_type not in  [ "python", "slim", "group" ]:
				cmds.select( m_selected[i].m_name, add=True )
			elif m_selected[i].m_type in [ "slim" ]:
					ml_cleanup.ml_slimCmd( "select_shader %s" % m_selected[i].m_name, debug=False )
	def ml_openContextMenu( self, position ):
		self.m_menu = QtGui.QMenu()
		m_selectAction = QtGui.QAction( "Select", self )
		m_selectAction.triggered.connect( self.ml_select )
		m_setActiveAction = QtGui.QAction( "Set active", self )
		m_setActiveAction.triggered.connect( self.ml_changeActive )
		m_updateAction = QtGui.QAction( "Update", self )
		m_updateAction.triggered.connect( self.ml_update )
		self.m_menu.addAction( m_selectAction )
		self.m_menu.addSeparator()
		self.m_menu.addAction( m_setActiveAction )
		self.m_menu.addAction( m_updateAction )
		self.m_menu.exec_( self.m_manager_treeview.viewport().mapToGlobal( position ) )
	def ml_content_update( self ):
		reload( ml_cleanup )
		m_result = ml_cleanup.ml_setup(
		scenePath = "",
		query = True,
		debug = False,
		mayaUnusedNodes = self.m_setup_unused_checkbox.checkState() and True or False,
		mayaRenameNodes = self.m_setup_mayaNames_checkbox.checkState() and True or False,
		mayaHierarchySetup = self.m_setup_hierarchy_checkbox.checkState() and True or False,
		mayaRenderStats = self.m_setup_attrSetup_checkbox.checkState() and True or False,
		mayaNonManifoldGeometry = self.m_setup_nonManifold_checkbox.checkState() and True or False,
		mayaReAttachSlimNodes = self.m_setup_material_checkbox.checkState() and True or False,
		slimRenameNodes = self.m_setup_slimSetupNames_checkbox.checkState() and True or False,
		slimHierarchySetup = self.m_setup_slimSetup_checkbox.checkState() and True or False,
		slimUnusedNodes = self.m_setup_unusedSlim_checkbox.checkState() and True or False,
		mayaZeroTranslate = self.m_setup_freezeSetup_checkbox.checkState() and True or False,
		mayaSetDisplacementBoundForSlim = self.m_setup_bound_checkbox.checkState() and True or False,
		mayaNormalDirection = self.m_setup_normals_checkbox.checkState() and True or False,
		mayaShadingNode = self.m_setup_shading_checkbox.checkState() and True or False,
		mayaBakeColorsFromSlim = self.m_setup_bake_checkbox.checkState() and True or False,
		mayaCombine = self.m_setup_combine_checkbox.checkState() and True or False,
		slimUniqueifyNodes = self.m_setup_slimUniqueify_checkbox.checkState() and True or False,
		mayaDeleteHistoryNodes = self.m_setup_history_checkbox.checkState() and True or False,
		slimMask = self.m_setup_mask_checkbox.checkState() and True or False, 
		mayaSaveScene = False,
		mayaMakeProxy = False,
		)
		return m_result
	def ml_update( self ):
		self.setWindowTitle( "Cleanup settings ( contain %s nodes )" % len( cmds.ls()) )
		self.m_items = []
		def ml_update_exec( m_current_variable, m_current_parent=None, m_current_parent_variable=None ):
			if type( m_current_variable ) is dict:
				m_current_item_keys = m_current_variable.keys()
				for i in range( 0, len( m_current_item_keys ) ):
					#
					m_current_item = WidgetItem( self.m_manager_treeview, "" )
					if m_current_parent:
						m_current_parent.ml_addChild( m_current_item )
						m_current_item.setSizeHint( QtCore.QSize( 22, 22 ) )
						m_type = re.findall( "slim", m_current_parent_variable, re.IGNORECASE ) and "slim" or "group"
						m_current_item.ml_setType( m_type )
					else:
						self.m_manager_treeview.ml_addChild( m_current_item )
						m_current_item.ml_setType( "python" )
						m_current_item.setSizeHint( QtCore.QSize( 28, 28 ) )
					m_itemWidget_checkbox = WidgetItemCheckbox( m_current_item, "" )
					m_current_item.ml_setName( m_current_item_keys[i] )
					m_itemWidget_label = QtGui.QLabel( m_current_item_keys[i].split( "|" )[-1] )
					m_itemWidget_label.setStyleSheet( "QLabel{ font-weight: bold; font-size: 10px; }" )
					if re.findall( "displacement|bake|normals", m_current_item_keys[i], re.IGNORECASE ):
						m_itemWidget_label.setStyleSheet("QLabel{ font-weight: bold; font-size: 10px; color: rgb(180, 50, 50); }")
					m_current_item.ml_setWidget( 1, m_itemWidget_checkbox )
					m_current_item.ml_setWidget( 2, m_itemWidget_label )
					m_current_item.ml_color()
					self.m_items.append( m_current_item )
					#
					ml_update_exec( m_current_variable[ m_current_item_keys[i] ], m_current_parent=m_current_item, m_current_parent_variable=m_current_item_keys[i] )
			elif type( m_current_variable ) is list:
				for i in range( 0, len( m_current_variable ) ):
					ml_update_exec( m_current_variable[i], m_current_parent=m_current_parent, m_current_parent_variable=m_current_parent_variable )
			else:
				m_current_item = WidgetItem( self.m_manager_treeview, "" )
				if m_current_parent:
					m_current_parent.ml_addChild( m_current_item )
					m_current_item.setSizeHint( QtCore.QSize( 22, 22 ) )
					m_type = cmds.objExists( m_current_variable ) and cmds.nodeType( m_current_variable ) or ( re.findall( "slim",  m_current_parent_variable, re.IGNORECASE ) and "slim" or "group" )
					m_current_item.ml_setType( m_type )
				else:
					self.m_manager_treeview.ml_addChild( m_current_item )
					m_current_item.ml_setType( "python" )
					m_current_item.setSizeHint( QtCore.QSize( 28, 28 ) )
				m_itemWidget_checkbox = WidgetItemCheckbox( m_current_item, "" )
				m_current_item.ml_setName( m_current_variable )
				m_itemWidget_label = QtGui.QLabel( m_current_variable.split( "|" )[-1] )
				m_itemWidget_label.setStyleSheet( "QLabel{ font-weight: bold; font-size: 10px; }" )
				if re.findall( "^displacement|^bake|^normals", m_current_variable, re.IGNORECASE ):
					m_itemWidget_label.setStyleSheet("QLabel{ font-weight: bold; font-size: 10px; color: rgb(180, 50, 50); }")
				if re.findall( "^rman|^renderman", m_current_variable, re.IGNORECASE ):
					m_itemWidget_label.setStyleSheet("QLabel{ font-weight: bold; font-size: 10px; color: rgb(200, 150, 50); }")
				m_current_item.ml_setWidget( 1, m_itemWidget_checkbox )
				m_current_item.ml_setWidget( 2, m_itemWidget_label )
				m_current_item.ml_color()
				self.m_items.append( m_current_item )
				self.m_iterator = self.m_iterator + 1
				if self.m_iterator > self.m_load_step:
					self.m_iterator = 0
					self.m_progress.setValue( self.m_progress.value() + 1 )
		self.m_manager_treeview.m_model.clear()
		self.m_manager_treeview.ml_clear()
		self.m_manager_treeview.ml_setColumns( [ "Active", "Name" ] )
		self.m_content = self.ml_content_update()
		self.m_load = ml_lenght( self.m_content, content=False )
		self.m_load = self.m_load and self.m_load or 0.0
		self.m_load_step = self.m_load / 100.0
		self.m_iterator = 0
		self.m_progress.setValue( 0 )
		ml_update_exec( self.m_content )
		self.m_progress.setValue( 0 )
		#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
		# self.m_content = self.ml_content_update()
		# self.m_content_keys = self.m_content.keys()
		# self.m_loading = 0
		# for i in range( 0, len( self.m_content_keys )):
			# self.m_loading = self.m_loading + len( self.m_content[self.m_content_keys[i]] )
		# self.m_step = self.m_loading / 100.0
		# self.m_currentValue = 0.0
		# self.m_progress.setValue( 0 )
		# for i in range( 0, len( self.m_content_keys )):
			# self.m_item = WidgetItem( self.m_manager_treeview, "" )
			# self.m_manager_treeview.ml_addChild( self.m_item )
			# m_itemWidget_checkbox = WidgetItemCheckbox( self.m_item, "" )
			# m_itemWidget_label = QtGui.QLabel( self.m_content_keys[i].split( "|" )[-1] )
			# self.m_item.ml_setName( self.m_content_keys[i] )
			# m_itemWidget_label.setStyleSheet( "QLabel{ font-weight: bold; font-size: 10px; }" )
			# self.m_item.ml_setWidget( 1, m_itemWidget_checkbox )
			# self.m_item.ml_setWidget( 2, m_itemWidget_label )
			# self.m_item.ml_color()
			# self.m_item.ml_setType( "python" )
			# self.m_item.setSizeHint( QtCore.QSize( 28, 28 ) )
			# for n in range( 0, len( self.m_content[self.m_content_keys[i]] )):
				# self.m_item_child = WidgetItem( self.m_manager_treeview, "" )
				# self.m_item.ml_addChild( self.m_item_child )
				# m_itemWidget_checkbox = WidgetItemCheckbox( self.m_item_child, "" )
				# m_type = cmds.objExists( self.m_content[self.m_content_keys[i]][n] ) and cmds.nodeType( self.m_content[self.m_content_keys[i]][n] ) or ( re.findall( "slim",  self.m_content_keys[i], re.IGNORECASE ) and "slim" or "group" )
				# self.m_item_child.ml_setType( m_type )
				# self.m_item_child.ml_setName( self.m_content[self.m_content_keys[i]][n] )
				# m_itemWidget_label = QtGui.QLabel( self.m_content[self.m_content_keys[i]][n].split( "|" )[-1] )
				# m_itemWidget_label.setStyleSheet( "QLabel{ font-weight: bold; font-size: 10px; }" )
				# self.m_item_child.ml_setWidget( 1, m_itemWidget_checkbox )
				# self.m_item_child.ml_setWidget( 2, m_itemWidget_label )
				# self.m_item_child.setSizeHint( QtCore.QSize( 22, 22 ) )
				# self.m_item_child.ml_color()
				# self.m_currentValue = self.m_currentValue + 1.0
				# if self.m_currentValue > self.m_step:
					# self.m_currentValue = 0
					# self.m_progress.setValue( self.m_progress.value() + 1 )
		# self.m_progress.setValue( 0 )
	def ml_setup( self ):
		reload( ml_cleanup )
		m_content = self.ml_getActiveTreeChildrens()
		m_content_keys = m_content.keys()
		ml_cleanup.ml_setup(
		scenePath = "",
		query = False,
		debug = False,
		mayaUnusedNodes = "Unused maya nodes" in m_content_keys and m_content[ "Unused maya nodes" ] or False,
		mayaRenameNodes = "Incorrect maya names" in m_content_keys and m_content[ "Incorrect maya names" ] or False,
		mayaHierarchySetup = "Maya nodes hierarchy" in m_content_keys and m_content[ "Maya nodes hierarchy" ] or False,
		mayaRenderStats = "Maya node attributes" in m_content_keys and m_content[ "Maya node attributes" ] or False,
		mayaNonManifoldGeometry = "Non-manifold geometry" in m_content_keys and m_content[ "Non-manifold geometry" ] or False,
		mayaZeroTranslate = "Need to freeze transforms" in m_content_keys and m_content[ "Need to freeze transforms" ] or False,
		mayaReAttachSlimNodes = "Need slim assignment" in m_content_keys and m_content[ "Need slim assignment" ] or False,
		slimRenameNodes = "Slim synchronise names with maya" in m_content_keys and m_content[ "Slim synchronise names with maya" ] or False,
		slimHierarchySetup = "Slim nodes hierarchy" in m_content_keys and m_content[ "Slim nodes hierarchy" ] or False,
		slimUnusedNodes = "Slim unused nodes" in m_content_keys and m_content[ "Slim unused nodes" ] or False,
		mayaSetDisplacementBoundForSlim = "Displacement bound" in m_content_keys and m_content[ "Displacement bound" ] or False,
		mayaNormalDirection = "Normals direction" in m_content_keys and m_content[ "Normals direction" ] or False,
		mayaShadingNode = "Default shading" in m_content_keys and m_content[ "Default shading" ] or False,
		mayaBakeColorsFromSlim = "Bake slim to color" in m_content_keys or False,
		mayaCombine = "Combine similar nodes" in m_content_keys and m_content[ "Combine similar nodes" ] or False,
		slimUniqueifyNodes = "Uniqueify scene slim id" in m_content_keys or False,
		mayaDeleteHistoryNodes = "History" in m_content_keys and m_content[ "History" ] or False,
		slimMask = "" in m_content_keys and m_content[ "" ] or False,
		mayaSaveScene = False,
		mayaMakeProxy = False,
		)
		self.setWindowTitle( "Cleanup settings ( contain %s nodes )" % len( cmds.ls()) )
		
def ml_maya_app():
	m_app = maya.OpenMayaUI.MQtUtil.mainWindow()
	return sip.wrapinstance( long( m_app ), QtCore.QObject )

class WidgetItemCheckbox( QtGui.QCheckBox )	:
	def __init__( self, m_item, parent=None ):
		super( WidgetItemCheckbox, self ).__init__( parent )
		self.setCheckState( True )
		self.m_item = m_item
		self.released.connect( self.ml_changeActive )
	def ml_setActiveChildrens( self, m_item, m_bool ):
		m_childrens = m_item.m_childrens
		for i in range( 0, len( m_childrens )):
			if m_childrens[i].m_elements[ 0 ].m_widget != self:
				m_childrens[i].ml_setActive( m_bool )
				m_childrens[i].m_elements[ 0 ].m_widget.setCheckState( m_bool )
				if m_childrens[i].hasChildren():
					self.ml_setActiveChildrens( m_childrens[i], m_bool )
	def ml_setActiveParents( self, m_item, m_bool ):
		if m_item.m_parent is not None and not m_item.m_parent.m_active and m_item.m_parent.m_elements[ 0 ].m_widget != self:
			m_item.m_parent.ml_setActive( m_bool )
			m_item.m_parent.m_elements[ 0 ].m_widget.setCheckState( m_bool )
			self.ml_setActiveParents( m_item.m_parent, m_bool )
	def ml_changeActive( self ):
		#m_temp = self.m_item.m_treeview.ml_getSelected()
		m_bool = self.checkState() and True or False
		m_selected = self.m_item.m_treeview.ml_getSelected()
		if len( m_selected ) > 0:
			for i in range( 0, len( m_selected )):
				if m_selected[i].m_elements[ 0 ].m_widget != self:
					m_selected[i].ml_setActive( m_bool )
					m_selected[i].m_elements[ 0 ].m_widget.setCheckState( m_bool )
					if m_selected[i].hasChildren():
						self.ml_setActiveChildrens( m_selected[i], m_bool )
		if self.m_item.hasChildren():
			self.ml_setActiveChildrens( self.m_item, m_bool )
		self.ml_setActiveParents( self.m_item, m_bool )
		self.m_item.ml_setActive( m_bool )
	
class WidgetItemElement( QtGui.QStandardItem ):
	def __init__( self, m_treeview, parent=None ):
		super( WidgetItemElement, self ).__init__( parent )
		self.m_name = None
		self.m_widget = None
		self.m_index = None
		self.m_parent = None
		self.m_treeview = m_treeview
	def ml_setWidget( self, m_widget ):
		self.m_widget = m_widget
		self.m_index = self.m_treeview.m_model.indexFromItem( self )
		self.m_treeview.setIndexWidget( self.m_index, self.m_widget )
	def ml_setIndex( self, m_index ):
		self.m_index = m_index
	def ml_setParent( self, m_parent ):
		self.m_parent = m_parent
	
class WidgetItem( QtGui.QStandardItem ):
	def __init__( self, m_treeview, parent=None ):
		super( WidgetItem, self ).__init__( parent )
		self.m_parent = None
		self.m_long = None
		self.m_name = None
		self.m_index = None
		self.m_widget = None
		self.m_type = None
		self.m_active = True
		self.m_visibility = True
		self.m_treeview = m_treeview
		self.m_childrens = []
		self.m_elements = [ self ]
		for i in range( self.m_treeview.m_columnsCount - 1 ):
			m_element = WidgetItemElement( self.m_treeview, "" )
			self.m_elements.append( m_element )
			m_element.ml_setParent( self )
		#self.m_treeview.setFirstColumnSpanned( self.row(), self.m_treeview.m_model.indexFromItem( self ), True )
	def ml_color( self ):
		self.m_palette = QtGui.QApplication.palette()
		self.m_gradient = QtGui.QLinearGradient( 0, 0, 0, 40 )
		self.m_gradient.setColorAt( 0.05, self.m_palette.base().color())
		self.m_gradient.setColorAt( 0.051, self.m_palette.window().color())
		self.m_gradient.setColorAt( 0.95, self.m_palette.window().color())
		self.m_gradient.setColorAt( 0.951, self.m_palette.base().color())
		self.m_brush = QtGui.QBrush( self.m_gradient )
		for i in range( 0, len( self.m_elements )):
			self.m_elements[i].setBackground( self.m_brush )
	def ml_getChildrens( self ):
		def ml_getChildrensDepth( m_temp ):
			for i in range( 0, len( m_temp.m_childrens )):
				m_result.append( m_temp.m_childrens[i] )
				ml_getChildrensDepth( m_temp.m_childrens[i] )
		m_result = []
		for i in range( 0, len( self.m_childrens )):
			m_result.append( self.m_childrens[i] )
			ml_getChildrensDepth( self.m_childrens[i] )
		return m_result
	def ml_setSelectable( self, m_bool ):
		for i in range( 0, len( self.m_elements )):
			self.m_elements[i].setSelectable( m_bool )
	def ml_setEditable( self, m_bool ):
		for i in range( 0, len( self.m_elements )):
			self.m_elements[i].setEnabled( m_bool )
	def ml_setLong( self, m_string ):
		self.m_long = m_string
	def ml_setName( self, m_string ):
		self.m_name = m_string
	def ml_setType( self, m_string ):
		self.m_type = m_string
	def ml_setActive( self, m_bool ):
		self.m_active = m_bool
	def ml_setVisibility( self, m_bool ):
		self.m_visibility = m_bool
	def ml_setSelectableWidget( self, m_column, m_bool ):
		self.m_elements[ m_column - 1 ].setSelectable( m_bool )
	def ml_setWidget( self, m_column, m_widget ):
		if m_column != 1:
			self.m_elements[ m_column - 1 ].ml_setWidget( m_widget )
		else:
			self.m_widget = m_widget
			self.m_index = self.m_treeview.m_model.indexFromItem( self )
			self.m_treeview.setIndexWidget( self.m_index, self.m_widget )
	def ml_setParent( self, m_parent ):
		self.m_parent = m_parent
	def ml_addChild( self, m_child ):
		m_child.ml_setParent( self )
		self.m_childrens.append( m_child )
		self.appendRow( m_child.m_elements )

class WidgetTree( QtGui.QTreeView ):
	def __init__( self, parent=None ):
		super( WidgetTree, self ).__init__( parent )
		self.m_childrens = []
		self.m_columnsCount = 1
		self.m_model = QtGui.QStandardItemModel()
		self.setModel( self.m_model )
		self.setContextMenuPolicy( QtCore.Qt.CustomContextMenu )
	def ml_setColumns( self, m_array ):
		self.m_model.setHorizontalHeaderLabels( m_array )
		self.m_columnsCount = len( m_array )
	def ml_addChild( self, m_child ):
		self.m_childrens.append( m_child )
		self.m_model.appendRow( m_child.m_elements )
		m_child.ml_setParent( None )
	def ml_getSelected( self ):
		m_result = []
		m_rows = self.selectionModel().selectedRows()
		for i in range( 0, len( m_rows )):
			m_result.append( self.m_model.itemFromIndex( m_rows[i] ) )
		return m_result
	def ml_clear( self ):
		self.m_childrens[:] = []
		

def ml_lenght( m_list, content=True ):
    m_result = []
    def ml_len_exec( m_current_item ):
        if type( m_current_item ) is dict:
            m_current_item_keys = m_current_item.keys()
            for i in range( 0, len( m_current_item_keys ) ):
                ml_len_exec( m_current_item[ m_current_item_keys[i] ] )
        elif type( m_current_item ) is list:
            for i in range( 0, len( m_current_item ) ):
                ml_len_exec( m_current_item[i])
        else:
            if m_current_item not in m_result:
                m_result.append( m_current_item )
    ml_len_exec( m_list )
    return( content is True and m_result or len( m_result ))
		
def main():
	if cmds.about( b=True ) is False:
		m_window = Window()
		m_window.show()
		
	