import rfm.passes
import maya.cmds as cmds		
		
def ml_makeRmanShadowPass( lights, resolution ):
    m_result = []
    lights = type( lights ) is list and lights or [ lights ]
    for i in range( 0, len( lights )):
        transform = ""
        nodeType = cmds.nodeType( lights[i] )
        if nodeType in [ "RMSGeoAreaLight", "RMSAreaLight", "RMSPointLight" ]:
            transform = cmds.listRelatives( lights[i], parent=True, fullPath=True )
        elif nodeType == "RMSEnvLight":
            cameras = cmds.ls( type="camera" )
            for n in range( 0, len( cameras )):
                if cmds.getAttr( "%s.renderable" % cameras[n] ):
                    transform = cmds.listRelatives( cameras[n], parent=True, fullPath=True )
                    break
        if transform:
            cameraShadow = cmds.camera( hfa=1, vfa=1, n=( lights[i] + "_SHADOW" ))[0]
            cameraShadow=cmds.parent( cameraShadow, transform )[0]
            cmds.setAttr( cameraShadow + ".translate", 0, 0, 1 )
            cmds.setAttr( cameraShadow + ".rotate", 0, 0, 0 )
            cmds.setAttr( cameraShadow + ".scale", 1, 1, 1 )
            cmds.setAttr( cameraShadow + ".shear", 0, 0, 0 )
            cmds.setAttr( cameraShadow + ".visibility", 0 )	
            cmds.setAttr( lights[i] + ".traceShadows", 0 )
            rfm.passes.Update()
            currentShadowPass = ""
            shadowPassList = rfm.passes.GetPasses( "AreaShadow" )
            for s in range( 0, len( shadowPassList )):
                if shadowPassList[s].GetID() == "AreaShadoW" + lights[i]:
                    currentShadowPass = shadowPassList[s]
                    break
            if currentShadowPass == "":
                currentShadowPass = rfm.passes.CreatePass( "AreaShadow" )
                currentShadowPass.Rename( lights[i] + "_AreaShadoW" )
            currentShadowPass.SetAttr( "rman__riopt__Format_resolution", "{0} {0}".format( resolution ))
            shadowPass = currentShadowPass.GetID()
            cameraShape = cmds.ls( cameraShadow, dag=True, type="camera" )[0]
            if not cmds.isConnected( cameraShape + ".message", shadowPass + ".rman__torattr___camera" ):
                cmds.connectAttr( cameraShape + ".message", shadowPass + ".rman__torattr___camera", f=True )
            if not cmds.isConnected( shadowPass + ".message", lights[i] + ".shadowname" ):
                cmds.connectAttr( shadowPass + ".message", lights[i] + ".shadowname", f=True )
            m_result.append( lights[i] )
    return m_result