import maya.cmds as cmds
import maya.mel as mel

for i in range(10,99):
    if cmds.commandPort(':77'+str(i), q=True) !=1:
        mel.eval("print(\"set port: 77"+str(i)+"\")")
        cmds.commandPort(n=':77'+str(i), eo = False, nr = True)
        break