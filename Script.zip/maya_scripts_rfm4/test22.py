def uniqueTransforms( reference, hasMesh=False, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True, fullPath=False ):
    import maya.cmds as cmds
    result = []
    uniqueTransforms = []
    if hasMesh is True:
        parted = referenceIsParted( reference )
    else:
        parted = False
    nodes = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    if ignoreShapes is True:
        transforms = cmds.ls( nodes, dag=True, type="transform", long=True, ni=ni )
    else:
        transforms = cmds.ls( nodes, dag=True, long=True, ni=ni )
    for transform in transforms:
        unique = True
        if ignoreShapes is True:
            childs = cmds.ls( transform, dag=True, type="transform", long=True, ni=ni )
        else:
            childs = cmds.ls( transform, dag=True, ni=ni )
        if childs:
            for child in childs:
                if hasMesh is True and parted is True and cmds.ls( child, dag=True, type="mesh" ) or hasMesh is False:
                    if cmds.referenceQuery( child, isNodeReferenced=True ):
                        filename = cmds.referenceQuery( child, filename=True )
                        if reference != filename:
                            unique = False
                            break
                    else:
                        if ignoreDeformers is True:
                            history = cmds.listHistory( child )    
                            for part in history:
                                if cmds.referenceQuery( part, isNodeReferenced=True ):
                                    filename = cmds.referenceQuery( part, filename=True )
                                    if reference != filename:
                                        unique = False
                                        break
                            if unique is False:
                                break
                        else:
                            unique = False
                        if unique is False:
                            break
                else:
                    unique = False
                    break
        else:
            if empty is False:
                unique = False
        if unique is True:
            uniqueTransforms.append( transform )
    for uniqueTransform in uniqueTransforms:
        parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
        if fullPath is False:
            uniqueTransform = cmds.ls( uniqueTransform )
            if uniqueTransform:
                uniqueTransform = uniqueTransform[-1]
        if parent:
            parent = parent[0]
            if parent not in uniqueTransforms:
                result.append( uniqueTransform )
        else:
            result.append( uniqueTransform )
    return result
    
def listUniqueTransforms( references=[], hasMesh=False, empty=False, ni=True, ignoreShapes=False, ignoreDeformers=True, fullPath=False ):
    import maya.cmds as cmds
    import main
    result = {}
    uniqueTransforms = {}
    partedReferences = {}
    keys = []
    rkeys = []
    pkeys = []
    transforms = main.nodeIterator( references=references, attributes=[], namespaces=[], canBeSaved=False, ni=ni, canNotSaved=False, hasNotUniqueName=False, referenced=True, imported=False, default=False, nonDefault=False, locked=False, nonLocked=False, shared=False, notShared=False, dag=True, dg=False, types=[], fullPath=True, returnMFnDependencyNode=False, returnMObject=False )
    for transform in transforms:
        reference = cmds.referenceQuery( transform, filename=True )
        if hasMesh is True:
            if reference not in pkeys:
                pkeys.append( reference )
                partedReferences.update( { reference:referenceIsParted( reference ) } )
        else:
            partedReferences.update( { reference:False } )
        unique = True
        if ignoreShapes is True:
            childs = cmds.ls( transform, dag=True, ni=ni, type="transform" )
        else:
            childs = cmds.ls( transform, dag=True, ni=ni )
        if childs:
            for child in childs:
                if hasMesh is True and partedReferences[reference] is True and cmds.ls( child, dag=True, type="mesh" ) or hasMesh is False or partedReferences[reference] is False:
                    if cmds.referenceQuery( child, isNodeReferenced=True ):
                        filename = cmds.referenceQuery( child, filename=True )
                        if reference != filename:
                            unique = False
                            break
                    else:
                        if ignoreDeformers is True:
                            history = cmds.listHistory( child )    
                            for part in history:
                                if cmds.referenceQuery( part, isNodeReferenced=True ):
                                    filename = cmds.referenceQuery( part, filename=True )
                                    if reference != filename:
                                        unique = False
                                        break
                            if unique is False:
                                break
                        else:
                            unique = False
                        if unique is False:
                            break
                else:
                    unique = False
                    break
        else:
            if empty is False:
                unique = False
        if unique is True:
            if reference not in keys:
                keys.append( reference )
                uniqueTransforms.update( { reference:[ transform ] } )
            else:
                uniqueTransforms[ reference ].append( transform )
    for key in keys:
        for uniqueTransform in uniqueTransforms[key]:
            parent = cmds.listRelatives( uniqueTransform, parent=True, fullPath=True )
            if fullPath is False:
                uniqueTransform = cmds.ls( uniqueTransform )
                if uniqueTransform:
                    uniqueTransform = uniqueTransform[-1]
            if parent:
                parent = parent[0]
                if parent not in uniqueTransforms[key]:
                    if key not in rkeys:
                        rkeys.append( key )
                        result.update( { key:[ uniqueTransform ] } )
                    else:
                        result[ key ].append( uniqueTransform )
            else:
                if key not in rkeys:
                    rkeys.append( key )
                    result.update( { key:[ uniqueTransform ] } )
                else:
                    result[ key ].append( uniqueTransform )
    return result     
    
def referenceIsParted( reference ):
    import maya.cmds as cmds
    assemblies = 0
    transforms = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    transforms = cmds.ls( transforms, type="transform", long=True )
    for transform in transforms:
        parent = cmds.listRelatives( transform, parent=True, fullPath=True )
        if parent:
            parent = parent[0]
            if parent not in transforms:
                if cmds.referenceQuery( parent, isNodeReferenced=True ):
                    filename = cmds.referenceQuery( parent, filename=True )
                    if filename != reference:
                        assemblies += 1
                else:
                    assemblies += 1
        else:
            assemblies += 1
    return ( assemblies > 1 )
    
    
    
    
