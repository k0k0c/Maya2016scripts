import maya.mel as mel
import maya.cmds as cmds
import advslim
import rfm.passes
import os
import xml.etree.ElementTree
reload( advslim )

def statistic( nodes, path='', all=False, debug=False, defaultCamera=True ):
    m_target_for_hide = cmds.ls( type=[ "mesh", "nurbsCurve", "nurbsSurface" ] )
    if path == '':
        statistic_name = mel.eval( 'rman stringinterpolate "${STAGE}"' ) + '.string'
        statistic_dir = ( mel.eval( 'rman stringinterpolate "${RMSPROJ}"' ) or mel.eval( 'rman stringinterpolate "${RMSPROD}"' ))
        statistic_path = os.path.join( statistic_dir, statistic_name )
    else:
        statistic_path = path
        statistic_dir = '/'.join( path.split( '/' )[:-1] )
        statistic_name = path.split( '/' )[-1]
    if debug is True:
        print 'statistic: %s' % statistic_path
    globalsSettings = rfm.passes.GetGlobals()
    mel.eval( 'setCurrentRenderer renderMan;' )
    mel.eval( 'rmanChangeRendererUpdate;' )
    finalPass = rfm.passes.GetPassDefaults( "Final" )
    if not finalPass:
        finalPass = rfm.passes.CreatePass( "Final" )
    finalPassDefaultsDisplay = finalPass.GetPrimaryDisplay()
    globalsSettings.SetAttr( "rman__riopt__statistics_endofframe", 1 )
    globalsSettings.SetAttr( "rman__riopt__statistics_filename", "stdout" )
    globalsSettings.SetAttr( "rman__riopt__statistics_xmlfilename", statistic_path )
    globalsSettings.SetAttr( "rman__riattr___ShadingRate", 1 )
    globalsSettings.SetAttr( "rman__riattr__volume_depthrelativeshadingrate", 1 )
    globalsSettings.SetAttr( "rman__riopt__limits_vprelativeshadingrate", 1 )
    globalsSettings.SetAttr( "rman__riattr___FocusFactor", 1 )
    globalsSettings.SetAttr( "rman__riattr___MotionFactor", 1 )
    globalsSettings.SetAttr( "rman__riopt__shading_directlightingsamples", 1 )
    globalsSettings.SetAttr( "rman__riopt___PixelSamples0", 1 )
    globalsSettings.SetAttr( "rman__riopt___PixelSamples1", 1 )
    finalPassDefaultsDisplay.SetAttr( "rman__riopt__Display_filterwidth0", 2 )
    finalPassDefaultsDisplay.SetAttr( "rman__riopt__Display_filterwidth1", 2 )
    cmds.setAttr( "defaultResolution.width", 2048 )
    cmds.setAttr( "defaultResolution.height", 2048 )
    cmds.setAttr( "defaultRenderGlobals.startFrame", 1 )
    cmds.setAttr( "defaultRenderGlobals.endFrame", 1 )
    cmds.setAttr( "defaultRenderGlobals.byFrameStep", 1 )
    m_final = cmds.ls( "rmanFinalGlobals" )
    if not m_final:
        m_final = mel.eval("rmanCreateGlobals()")
        m_final = cmds.ls( "rmanFinalGlobals" )[0]
    else:
        m_final = m_final[0]
    mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_backfacing", "%s" )' % ( m_final, 0 ))
    mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_hidden", "%s" )' % ( m_final, 0 ))
    if defaultCamera is True:
        camera = cmds.camera()
        transform = camera[0]
        camera = camera[-1]
        cameraList = cmds.ls( type='camera' )
        [ cmds.setAttr( "%s.renderable" % cameraList[i], 0 ) for i in range( 0, len( cameraList )) ]
        cmds.setAttr( "%s.renderable" % camera, 1 )
        cmds.setAttr( '%s.rotate' % transform, -45, 45, 0 )
        hidden = []
    if all is False:
        if defaultCamera is True:
            cmds.viewFit( camera )
        cmds.select( cmds.ls( nodes, long=True ))
        hidden = cmds.hide( m_target_for_hide, returnHidden=True )
        cmds.showHidden( nodes )
    else:
        cmds.select( clear=True )
        cmds.viewFit( camera )
    mel.eval( 'rman render;' )
    if hidden:
        cmds.showHidden( hidden )
    if defaultCamera is True:
        cmds.delete( transform )
    return statistic_path

def displacementBound( query=False, debug=True, defaultCamera=False ):
    advslim.loadSlim()
    idScene = advslim.listMayaID()
    for i in range( 0, len( idScene )):
        value = advslim.getSlimAttribute( idScene[i], "enableDisplacement" )[-1]
        if value == "0":
            nodes = advslim.findNode( idScene[i], ensemble=True )
            advslim.setSlimAttribute( idScene[i], "displacementbound", 0, byClass="::Slim::Attribute" )
            if nodes:
                for n in range( 0, len( nodes )):
                    fullname = "_db_".join( nodes[n].split( "|" ))
                    if not cmds.referenceQuery( nodes[n], isNodeReferenced=True ):
                        nodes[n] = cmds.rename( nodes[n], fullname )
                        if not cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=nodes[n], exists=True ):
                            mel.eval( "rmanAddAttr( \"%s\", \"rman__riattr__displacementbound_sphere\", \"%s\" )" % ( nodes[n], 0 ))
                        if cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=nodes[n], exists=True ):
                            cmds.setAttr( "%s.rman__riattr__displacementbound_sphere" % nodes[n], 0 )
                if query is False:
                    xmlFile = statistic( nodes, debug=debug, defaultCamera=defaultCamera )
                    xmlString = file( xmlFile, "r" ).read()
                    xmlRoot = xml.etree.ElementTree.fromstring( xmlString )
                    xmlTopLevel = xmlRoot.findall( "*//stats" )
                    if debug is True:
                        print xmlFile
                    for n in range( 0, len( nodes )):
                        bound = []
                        for f in range( 0, len( xmlTopLevel )):
                            if xmlTopLevel[f].get( "name" ) == "dispBound":
                                valid = False
                                boundInfo = xmlTopLevel[f].findall( "*" )
                                for b in range( 0, len( boundInfo )):
                                    if boundInfo[b].get( "name" ) == "objectName":
                                        if boundInfo[b].text == nodes[n]:
                                            valid = True
                                            continue
                                    if valid is True:
                                        if boundInfo[b].get( "name" ) == "displacement":
                                            bound.append( float( boundInfo[b].text ))
                                            print boundInfo[b].text
                                            break
                        if bound:
                            bound = sum( bound ) * 1.3
                            if not cmds.attributeQuery( "rman__riattr__displacementbound_coordinatesystem", n=nodes[n], exists=True ):
                                mel.eval( "rmanAddAttr( \"%s\", \"rman__riattr__displacementbound_coordinatesystem\", \"shader\" )" % nodes[n] )
                            else:
                                cmds.setAttr( "%s.rman__riattr__displacementbound_coordinatesystem" % nodes[n], "shader", type="string" )
                            cmds.setAttr( "%s.rman__riattr__displacementbound_sphere" % nodes[n], bound )
                        fullname = nodes[n].split( "_db_" )[-1]
                        if not cmds.referenceQuery( nodes[n], isNodeReferenced=True ):
                            nodes[n] = cmds.rename( nodes[n], fullname )
                    renderTrash = cmds.ls( type="RenderMan" )
                    if renderTrash:
                        cmds.delete( renderTrash )