import sys
import os
import re
import maya.OpenMayaUI as mui
import sip
import maya.cmds as cmds
if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
	import rfm.rlf2maya as rlf2maya
	import rfm.passes
from PyQt4 import QtCore, QtGui
global OSTYPE
OSTYPE = "//Server-3d/Project"
if sys.platform != "win32":
		OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/SSM/python')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/SSM/ui')
import ui_render;reload(ui_render)
import ui_scene;reload(ui_scene)
import ui_modeling;reload(ui_modeling)
import ui_reference;reload(ui_reference)
import ui_shablon;reload(ui_shablon)
import ui_data;reload(ui_data)

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )

class dockWindow(QtGui.QDockWidget):
    def __init__( self,parent=getMayaWindow()):
        super(dockWindow, self).__init__(parent)
        print "dockWindow(1/10)"
        self.findingCBLE=self.parent().findChildren((QtGui.QDockWidget),"dockControl1")
        self.loaded=[]
        self.sceneChanged=0
        self.mainWidget = QtGui.QWidget()
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins(0,0,0,0)
        self.mainWidget.setLayout(self.mainLayout)
        self.setWindowTitle("Yashka Return(CIT)")
        self.setObjectName("Yashka Return(CIT)")
        self.tabWidget= QtGui.QTabWidget()
        self.tabWidget.tabBar().currentChanged.connect(self.currentWidgetSlot)        
        self.tabWidget.setStyleSheet('QTabWidget{background: rgb(68,68,68);}')
        self.mainLayout.addWidget(self.tabWidget)
        print "dockWindow(2/10)"
        self.renderUI = ui_render.Window()
        self.tabWidget.addTab(self.renderUI,"Render")
        print "dockWindow(3/10)"
        self.sceneUI = ui_scene.Window()
        self.tabWidget.addTab(self.sceneUI,"Scene")
        #-command ("import sys;sys.path.append('//server-3d/Project/lib/setup/maya/maya_scripts_rfm3');import mayaOpenDialog;import melnik_setup;reload(mayaOpenDialog);melnik_setup.mOd = mayaOpenDialog.Window(); melnik_setup.mOd.exec_();")
        print "dockWindow(4/10)"
        self.modelingUI = ui_modeling.Window()
        self.tabWidget.addTab(self.modelingUI,"Modeling")
        print "dockWindow(5/10)"
        self.referenceUI = ui_reference.Window()
        self.tabWidget.addTab(self.referenceUI,"Reference")
        self.dataUI = ui_data.Window()
        self.tabWidget.addTab(self.dataUI,"Data")
        print "dockWindow(7/10)"
        self.shablonUI = ui_shablon.Window()
        self.tabWidget.addTab(self.shablonUI,"Shablon")
        self.readSettings()
        self.setWidget(self.mainWidget)
        QtCore.QCoreApplication.instance().aboutToQuit.connect(self.quittt)
        print "dockWindow(8/10)"

    def quittt(self):
        self.writeSettings()
                        
    def currentWidgetSlot(self,wi):
        #print "currentWidgetSlot SSM:" + str(wi)
        if wi not in self.loaded:
            self.tabWidget.widget(wi).load()
            self.loaded.append(wi)
        
    def closeEvent(self, event):
        self.writeSettings()
        event.accept()

    def readSettings(self):
        print "SSM readSettings"
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("SSM")        
        pos = settings.value("tabWidget", "0").toInt()
        self.tabWidget.setCurrentIndex(pos[0])

        if settings.value("isFloating", False).toBool():
            self.setFloating(True)    
        else:
            self.setFloating(False)
                  
        posArea = settings.value("dockWidgetArea", "2").toInt()
        self.parent().addDockWidget(posArea[0],self)

        posTabifi = settings.value("tabifiedDockWidgets", "1").toInt()
        if posTabifi: self.parent().tabifyDockWidget(self.findingCBLE[0],self)
        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        settings.endGroup()
    
    def writeSettings(self):
        print "SSM writeSettings"
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("SSM")
        settings.setValue("tabWidget", self.tabWidget.currentIndex())
        settings.setValue("dockWidgetArea", self.parent().dockWidgetArea(self))
        settings.setValue("isFloating", self.isFloating()) 
        settings.setValue("tabifiedDockWidgets", len(self.parent().tabifiedDockWidgets(self))) 
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.endGroup()              
        for i in range(0,self.tabWidget.count()):
            if hasattr(self.tabWidget.widget(i), 'writeSettings'):
                self.tabWidget.widget(i).writeSettings()



SSM = getMayaWindow().findChildren((QtGui.QDockWidget),"Yashka Return(CIT)")
def load(index=""):
    SSM = getMayaWindow().findChildren((QtGui.QDockWidget),"Yashka Return(CIT)")
    print "SSM(1/10)"
    if SSM:
        print "SSM(2/10)"
        SSM=SSM[0]
        if getMayaWindow().tabifiedDockWidgets(SSM): getMayaWindow().tabifyDockWidget(getMayaWindow().tabifiedDockWidgets(SSM)[0],SSM)
        SSM.show()
        print "SSM(3/10)"
        SSM.writeSettings()
        SSM.deleteLater()
        #SSM = dockWindow()
    #else:
    print "SSM(4/10)"
    print "create"
    SSM = dockWindow()
    
    if SSM:
        print "SSM(5/10)"
        pathSplitted=index.split("|")
        pointer=SSM.tabWidget
        print "SSM(6/10)"
        for i in range(0,len(pathSplitted)):
            for ii in range(0,pointer.count()):
                if pathSplitted[i] == pointer.widget(ii).property("index").toString():
                    print pathSplitted[i]
                    pointer.setCurrentIndex(ii)            
                    if i< len(pathSplitted)-1: pointer=pointer.widget(ii).tabWidget
                    break        
        print "SSM(7/10)"
