print '\nSTART'
import sys; print 'import sys -OK'
import os; print 'import os -OK'
import maya.cmds as cmds; print 'import maya.cmds -OK'
import maya.mel as mel





def referenceAndSaveSceneForShablon(ep_number, scene_number, scene_type):
	new_name="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/"+scene_type+"/ep"+ep_number+"sc"+scene_number+"_"+scene_type+".mb"#Path to new file
	ref_path01="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/anm/ep"+ep_number+"sc"+scene_number+"_anm.mb"
	ref_path02="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/anm/ep"+ep_number+"sc"+scene_number+"_anm.ma"
	print 'new name:', new_name
	print 'check name:', ref_path01
	print 'check name:', ref_path02
	if os.path.exists(ref_path01):
		ref_path=ref_path01
		print 'Path exists.'
		print ref_path
	elif os.path.exists(ref_path02):
		print 'Path exists.'
		ref_path=ref_path02
		print ref_path
	ref_namespace="ep"+ep_number+"sc"+scene_number+"_anm"
	print 'namespace:', ref_namespace
	cmds.file(ref_path, loadReferenceDepth='none', open=True)
	print 'start loading animation scene.'
	start_time=cmds.playbackOptions(query=True, animationStartTime=True)
	end_time=cmds.playbackOptions(query=True, animationEndTime=True)
	print start_time, '\n', end_time
	
	cmds.file(new=True, force=True)
	print 'create new file.'
	cmds.playbackOptions(minTime=start_time, animationStartTime=start_time)
	cmds.playbackOptions(maxTime=end_time, animationEndTime=end_time)
	cmds.file(ref_path, reference=True, mergeNamespacesOnClash=False, namespace=ref_namespace)
	print 'reference animation scene'
	mel.eval('file -type "mayaBinary";')
	cmds.file(rename=new_name)
	cmds.file(force=True, save=True, type='mayaBinary')
	print 'scene save.'

def referenceAndSaveSceneForShablon_Exec():
	attributtes=(str('{0}'.format(sys.argv[4]))).split(' ')
	episode=attributtes[0]; print 'Episode number: ',episode
	scene=attributtes[1]; print 'Scene number: ',scene
	type=attributtes[2]; print 'Scene type: ',type
	print '\n//Begin create scene.'
	referenceAndSaveSceneForShablon(episode,scene,type)
	print '\n//Scene was saved.'

referenceAndSaveSceneForShablon_Exec()
print '\nEND'