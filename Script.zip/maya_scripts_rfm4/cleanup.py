import maya.cmds as cmds
import maya.mel as mel
import re
import linecache
import sys
import advslim
import main
import ml_reference
import maya.OpenMaya as om
import os
import glob

def exception():
    extype, exobj, traceback = sys.exc_info()
    lineno = traceback.tb_lineno
    nfile = traceback.tb_frame
    filename = nfile.f_code.co_filename
    linecache.checkcache( filename )
    line = linecache.getline( filename, lineno, nfile.f_globals )
    linestp = line.strip()
    linestp = linestp and linestp or "<module>"
    result = "# Error: {3}# Traceback (most recent call last):\n# \tFile {0}, line {1}, in {2}\n# {4}: {3}".format( filename, lineno, linestp, exobj, extype.__name__ )
    print result
    return result

def sceneType( filename="" ):
    if filename == "":
        filename = cmds.file( query=True, sceneName=True )
    if filename != "":
        if re.findall( "/mod/", filename ):
            return "mod"
        elif re.findall( "/anm/", filename ):
            return "anm"
        elif re.findall( "/light/", filename ):
            return "light"
        elif re.findall( "/tmplate/", filename ):
            return "tmplate"
        elif re.findall( "/dyn/", filename ):
            return "dyn"
        elif re.findall( "/map/", filename ):
            return "map"
        elif re.findall( "/rig/", filename ):
            return "rig"
        elif re.findall( "/shd/", filename ):
            return "shd"
        elif re.findall( "/tex/", filename ):
            return "tex"
        else:
            return "root"
    return "none"

def checkUnusedSlimMaterials( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        result = advslim.listAttachments( notAttached=True )
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            advslim.removeMaterial( result[i] )
    return result

def checkUnusedSlimShaders( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        result = advslim.unusedPalettes()
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            advslim.removePalette( result[i] )
    return result

def checkNonManifoldCameras( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        default = [ "|front|frontShape", "|persp|perspShape", "|side|sideShape", "|top|topShape" ]
        nodes = cmds.ls( type="camera", long=True )
        for node in nodes:
            if node not in default:
                isLocked = cmds.camera( node, query=True, startupCamera=True )
                if isLocked is True:
                    result.append( node ) 
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            cmds.camera( result[i], edit=True, startupCamera=False )
    return result

def checkUnusedNodes( nodes=[], query=True, debug=False ):
    result = []
    #sets
    #color sets
    #deformers
    #lights
    #cameras
    #layers
    #empty groupId
    #empty abc
    #empty rib
    #not connected to mesh materials
    if not nodes:
        st = sceneType()
        if st in [ "light" ]:
            nodes = cmds.ls( type=[ "objectTypeFilter", "objectNameFilter", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter" ], long=True )
        else:
            nodes = cmds.ls( type=[ "objectTypeFilter", "objectNameFilter", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter", "RenderMan" ], long=True )
        for i in range( 0, len( nodes )):
            if re.findall( "[0-9]", nodes[i] ):
                if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                    result.append( nodes[i] )
                    if debug is True:
                        print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i]
            if cmds.objExists( node ):
                if not cmds.referenceQuery( node, isNodeReferenced=True ):
                    cmds.delete( node )
    return result

def checkTransformTranslations( nodes=[], query=True, debug=False ):
    result = []
    if not nodes:
        if cmds.ls( "|root", assemblies=True ):
            nodes = cmds.ls( "|root", dag=True, type="transform", long=True )
            for i in range( 0, len( nodes )):
                if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                    if cmds.ls( nodes[i], dag=True, type="mesh" ) and not cmds.ls( nodes[i], dag=True, type="nurbsCurve" ):
                        translate = cmds.getAttr( "%s.t" % nodes[i] )[0]
                        if ( round( translate[0], 2 ) != 0.0 or round( translate[1], 2 ) != 0.0 or round( translate[-1], 2 ) != 0.0 ):
                            boolean = True
                            dag = cmds.ls( nodes[i], dag=True )
                            if cmds.listConnections( dag, type="blendShape" ):
                                boolean = False
                                continue
                            if cmds.listConnections( dag, type="skinCluster" ):
                                boolean = False
                                continue
                            if cmds.listConnections( dag, type="transform" ):
                                boolean = False
                                continue 
                            childs = cmds.ls( nodes[i], dag=True, type="transform", long=True )
                            for c in range( 0, len( childs )):
                                if boolean is False:
                                    break
                                attributes = [ "%s.t" % childs[c], "%s.tx" % childs[c], "%s.ty" % childs[c], "%s.tz" % childs[c], "%s.t" % childs[c] ]
                                for a in range( 0, len( attributes )):
                                    if cmds.getAttr( attributes[a], lock=True ) or cmds.listConnections( attributes[a] ):
                                        boolean = False
                                        break
                            if boolean is True:
                                result.append( nodes[i] )
                                if debug is True:
                                    print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i]
            if cmds.objExists( node ):
                if not cmds.referenceQuery( node, isNodeReferenced=True ):
                    cmds.makeIdentity( node, translate=True, apply=True )
    return result

def checkSlimAttachements( debug=False ):
    avalaible = advslim.listSlimID()
    result = []
    nodes = cmds.ls( type=[ "transform", "mesh", "nurbsSurface", "nurbsCurve" ], long=True )
    for n in range( 0, len( nodes )):
        value = advslim.getMayaID( nodes[n], ensemble=True )
        if value:
            for v in range( 0, len( value )):
                if nodes[n] not in result:
                    boolean = False
                    if cmds.nodeType( nodes[n] ) in [ "transform", "mesh" ]: 
                        if value[v] not in avalaible:
                            boolean = True
                            result.append( "%s has attached to not existing id" % nodes[n] )
                    else:
                        if value[v] not in avalaible:
                            boolean = True
                            result.append( "%s is not valid and has attached to not existing id" % nodes[n] )
                        else:
                            boolean = True
                            result.append( "%s is not valid" % nodes[n] )
                    if boolean is True:
                        if debug is True:
                            print result[-1]
    return result

def checkNonManifoldMeshes( debug=False ):
    result = []
    nodes = cmds.ls( type=[ "mesh", "nurbsCurve" ] )
    for i in range( 0, len( nodes )):
        if cmds.nodeType( nodes[i] ) == "mesh":
            if cmds.polyEvaluate( nodes[i], vertex=True ) >= 2:
                component = cmds.ls( cmds.polyInfo( nodes[i], laminaFaces=True, nonManifoldEdges=True, nonManifoldVertices=True ), fl=True, long=True )
                if component:
                    result = result + component
                    if debug is True:
                        print "%s is non-manifold" % component
            else:
                result.append( "%s has non-manifold geometry" % nodes[i] )
                if debug is True:
                    print result[-1]
        #else:
            #if cmds.attributeQuery( "spans", n=nodes[i], exists=True ) and cmds.getAttr( "%s.spans" % nodes[i] ) < 2 and nodes[i] not in result:
                #result.append( "%s has non-manifold spans" % nodes[i] )
                #if debug is True:
                    #print result[-1]
    return result

def checkNonManifoldVertex( nodes=[], ignoreSkinned=True, query=False, debug=False ):
    result = []
    if not nodes:
        nodes = cmds.ls( dag=True, type="mesh", long=True )
        for i in range( 0, len( nodes )):
            skinned = False
            if ignoreSkinned is True and skinned == False:
                history = cmds.listHistory( nodes[i] )
                for h in range( 0, len( history )):
                    if cmds.nodeType( history[h] ) == "skinCluster":
                        skinned = True
                        break
            selectionList = om.MSelectionList()
            selectionList.add( nodes[i] )
            dagPath = om.MDagPath()
            selectionList.getDagPath( 0, dagPath )
            try:
                mfnMesh = om.MFnMesh( dagPath )
                vertices = mfnMesh.numVertices()
                if vertices > 0:
                    iterator = om.MItMeshVertex( dagPath )
                    while not iterator.isDone():
                        array = om.MIntArray()
                        iterator.getConnectedEdges( array )
                        vtx = iterator.index()
                        if array.length() < 1:
                            if skinned is False and ignoreSkinned is True or ignoreSkinned is False: 
                                result.append( "%s.vtx[%s]" % ( nodes[i], vtx ))
                                if debug is True:
                                    print result[-1]
                        iterator.next()
            except:
                print "Error: %s" % nodes[i]
                exception()
    else:
        result = nodes
    if query is False:
        if result:
            for i in range( 0, len( result )):
                node = result[i]
                if not cmds.referenceQuery( node, isNodeReferenced=True ):
                    cmds.polyDelVertex( node, constructionHistory=False )
    return result

def checkNonManifoldNormals( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        nodes = cmds.ls( dag=True, type="mesh", ni=True, long=True )
        for i in range( 0, len( nodes )):
            if not cmds.referenceQuery( nodes[i], isNodeReferenced=True ):
                components = cmds.polyInfo( nodes[i], nonManifoldVertices=True )
                if components:
                    components = cmds.ls( components, fl=True, long=True )
                    for n in range( 0, len( components )):
                        if len( cmds.ls( cmds.polyListComponentConversion( components[n], fromVertex=True, toEdge=True ), fl=True, long=True )) == len( cmds.ls( cmds.polyListComponentConversion( components[n], fromVertex=True, toFace=True ), fl=True, long=True )) and nodes[i] not in result: 
                            result.append( nodes[i] )
                            if debug is True:
                                print result[-1]
                            break
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i]
            if cmds.objExists( node ) and not cmds.referenceQuery( node, isNodeReferenced=True ):
                cmds.polyNormal( node, normalMode=2, userNormalMode=1 )
    return result

def checkUniqueNames( nodes=[], query=False, debug=False ):
    result = []
    sceneName = cmds.file( query=True, sceneName=True ).split( "/" )[-1].split( "." )[0]
    sceneName = sceneName != "" and sceneName or "untitled"
    notValid = re.compile( "pPipe|pPlane|polySurface|pCylinder|pTorus|pPyramid|pCone|pCube|pSphere|nurbsPlan|nurbsTorus|nurbsCone|nurbsCylinder|nurbsCube|nurbsSphere|root[A-z0-9_|]+root", re.IGNORECASE )
    if not nodes:
        nodes = cmds.ls( dag=True, long=True, type="transform" )
        for node in nodes:
            boolean = 0
            nodeName = node.split( "|" )[-1]
            if notValid.findall( node ):
                boolean = 1
            elif len( cmds.ls( nodeName )) > 1:
                boolean = 2
            if boolean > 0:
                result.append( node )
                if debug is True:
                    print result[-1]
    else:
        result = nodes
    if query is False:
        pass
    return result

def listTree( node ):
    result = []
    connections = cmds.listConnections( node, destination=False )
    if connections:
        for connection in connections:
            if connection not in result and connection != node:
                result.append( connection )
                mconnections = listTree( connection )
                for mconnection in mconnections:
                    if mconnection not in result:
                        result.append( mconnection )
    return result

def checkMayaShaders( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        unusedshadingEngines = []
        materials = cmds.ls( materials=True )
        shadingEngines = cmds.ls( type="shadingEngine" )
        connectedShadingEngines = []
        #Not valid material.
        if materials:
            for material in materials:
                boolean = False
                if material != "lambert1" and material != "particleCloud1":
                    isFind = False 
                    connections = listTree( material )
                    if connections:
                        for connection in connections:
                            if cmds.nodeType( connection ) == "file":
                                isFind = True
                                filename = cmds.getAttr( "%s.fileTextureName" % connection )
                                if not re.findall( "/anm/|/textures/", filename, re.IGNORECASE ) or not re.findall( "[\\/]+server-3d[\\/]+|p:[\\/]+|[\\/]+renderserver[\\/]+", filename, re.IGNORECASE ):
                                    boolean = True
                                    break
                    if isFind is False:
                        boolean = True
                    temps = cmds.listConnections( material, type="shadingEngine" )
                    if temps:
                        for temp in temps:
                            if temp not in connectedShadingEngines:
                                connectedShadingEngines.append( temp )
                                if boolean is True:
                                    unusedshadingEngines.append( temp )
                                    result.append( "%s remove shading engine" % temp )
                                    if debug is True:
                                        print result[-1]
                elif material == "lambert1":
                    connections = listTree( material )
                    if connections:
                        result.append( "%s remove input connections" % material )
                        if debug is True:
                            print result[-1]
                if boolean is True:
                    result.append( "%s remove material" % material )
                    if debug is True:
                        print result[-1]
        #Empty shading engine.
        if shadingEngines:
            for shadingEngine in shadingEngines:
                if shadingEngine != "initialShadingGroup" and shadingEngine !=  "initialParticleSE":
                    if shadingEngine not in connectedShadingEngines:
                        unusedshadingEngines.append( shadingEngine )
                        result.append( "%s remove shading engine" % shadingEngine )
                        if debug is True:
                            print result[-1]
        nodes = cmds.ls( type="mesh", ni=True, visible=True, long=True )
        if nodes:
            for node in nodes:
                replace = False
                connectedShadingEngines = cmds.listConnections( node, type="shadingEngine" )
                if connectedShadingEngines:
                    for connectedShadingEngine in connectedShadingEngines:
                        if connectedShadingEngine != "initialShadingGroup" and connectedShadingEngine in unusedshadingEngines:
                            replace =True
                            break
                if not connectedShadingEngines or replace is True:
                    result.append( "%s assign %s" % ( node, "lambert1" ))
                    if debug is True:
                        print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            if "assign" in result[i]:
                buffer = result[i].split( " " )
                node = buffer[0]
                material = buffer[-1]
                try:
                    if not cmds.referenceQuery( node, isNodeReferenced=True ):
                        cmds.hyperShade( node, assign=material )
                except:
                    print "Failed to assign material", node
            elif "remove material" in result[i]:
                buffer = result[i].split( " " )
                node = buffer[0]
                connections = listTree( node )
                connections.append( node )
                try:
                    if not cmds.referenceQuery( node, isNodeReferenced=True ):
                        cmds.delete( connections )
                except:
                    print "Failed to remove material", connections
            elif "remove input connections" in result[i]:
                buffer = result[i].split( " " )
                node = buffer[0]
                connections = listTree( node )
                try:
                    if not cmds.referenceQuery( node, isNodeReferenced=True ):
                        cmds.delete( connections )
                except:
                    print "Failed to remove input connections", connections 
            elif "remove shading engine" in result[i]:
                buffer = result[i].split( " " )
                node = buffer[0]
                try:
                    if not cmds.referenceQuery( node, isNodeReferenced=True ):
                        cmds.delete( node )
                except:
                    print "Failed to remove shading engine", node  
    return result

def checkCompileSlim( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        server = sys.platform == "win32" and "//server-3d/" or "/server-3d/"
        nfiles = []
        times = [ 0 ]
        rfiles = glob.glob( server + "Project/lib/setup/rfm180/*.slim" )
        if rfiles:
            nfiles = nfiles + rfiles
        hfiles = glob.glob( server + "Project/lib/setup/rfm180/customNodes/*.h" )
        if hfiles:
            nfiles = nfiles + hfiles
        sfiles = glob.glob( server + "Project/lib/setup/rfm180/customNodes/*.slim" )
        if sfiles:
            nfiles = nfiles + sfiles
        if nfiles:
            for temp in nfiles:
                times.append( os.path.getmtime( temp ))
        lastDate = max( times )
        directory = advslim.getProjectDir( directory="slimShaders" )
        if directory:
            directory = directory[0]
            slfiles = glob.glob( directory + "/*.sl")
            slofiles = glob.glob( directory + "/*.slo")
            if os.path.isdir( directory + "/tmp" ):
                temp = glob.glob( directory + "/tmp/*.sl")
                if temp:
                    slfiles = slfiles + temp
                temp = glob.glob( directory + "/tmp/*.slo")
                if temp:
                    slofiles = slofiles + temp
            slfiles = slfiles + slofiles
            palettes = advslim.listSlimPalettes()
            if palettes: 
                nodes = advslim.listShaders( palettes=palettes, name=True, namespace=True, full=True )
                if nodes:
                    for node in nodes:
                        name = node.split( "|" )
                        longname = name[0]
                        name = name[-1]
                        isExists = False
                        isOld = False
                        if slfiles:
                            for slfile in slfiles:
                                slfile = os.path.normpath( slfile )
                                slfile = slfile.replace('\\', '/')
                                if re.findall( "/%s." % name, slfile ):
                                    isExists = True
                                    date = os.path.getmtime( slfile ) 
                                    if date < lastDate:
                                        result.append( "%s is old and can be removed" % slfile )
                                        if debug is True:
                                            print result[-1]
                                        isOld = True
                        if isExists is False:
                            result.append( "%s - %s is not compiled for current scene" % ( longname, name ))
                            if debug is True:
                                print result[-1]
                        elif isOld is True:
                            result.append( "%s - %s need to recompile" % ( longname, name ))
                            if debug is True:
                                print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            target = result[i].split( " " )[0]
            if "is old and can be removed" in result[i]:
                if os.path.isfile( target ):
                    os.remove( target )
            elif "need to recompile" in result[i] or "is not compiled for current scene" in result[i]:
                advslim.buildShaders( [ target ] )
    return result

def checkSlimShaders( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        root = sys.platform == "win32" and "//server-3d/" or "/server-3d/"
        advslim.sendToSlim( "source " + root + "/Project/lib/setup/rfm180/setupSlim.tcl" )
        slimResult = advslim.sendToSlim( "setup 1" )
        if slimResult:
            result = slimResult[0].split( ";" )
            if result:
                if debug is True:
                    for string in result:
                        print string
    else:
        result = nodes
    if query is False:
        value = ";".join( result )
        advslim.sendToSlim( "setup 0 {%s}" % value )
    return result

def checkUnusedUv( nodes=[], query=True, debug=False ):
    result = []
    if not nodes:
        nodes = cmds.ls( type="mesh", long=True, ni=True )
        materials = cmds.ls( materials=True )
        if nodes:
            for node in nodes:
                uvsets = cmds.polyUVSet( node, query=True, allUVSets=True )
                if uvsets:
                    vertex = cmds.polyEvaluate( node, vertex=True )
                    mapped = cmds.polyListComponentConversion( "%s.vtx[0:%s]" % ( node, vertex ), fromVertex=True, toUV=True )
                    if mapped:
                        if cmds.attributeQuery( "rman__torattr___ptexFaceOffset", n=node, exists=True ):
                            result.append( "%s has ptex texture, all uv sets can be deleted" % node )
                            if debug is True:
                                print result[-1]
                        elif not cmds.attributeQuery( "rman__torattr___slimShader", n=node, exists=True ) and not cmds.attributeQuery( "rman__torattr___slimSurface", n=node, exists=True ) and not cmds.attributeQuery( "rman__torattr___slimEnsemble", n=node, exists=True ):
                            shadingEngines = cmds.listConnections( node, type="shadingEngine" )
                            if shadingEngines:
                                if "initialShadingGroup" in shadingEngines:
                                    result.append( "%s has attached only to lambert1, all uv sets can be deleted" % node )
                                    if debug is True:
                                        print result[-1]
                                else:
                                    for shadingEngine in shadingEngines:
                                        connections = cmds.listConnections( shadingEngine, destination=False )
                                        if connections:
                                            isFindMaterial = False
                                            for connection in connections:
                                                boolean = False
                                                if connection in materials:
                                                    isFindMaterial = True
                                                    isFindTexture = False 
                                                    inputs = listTree( connection )
                                                    if inputs:
                                                        for input in inputs:
                                                            if cmds.nodeType( input ) == "file":
                                                                isFindTexture = True
                                                                filename = cmds.getAttr( "%s.fileTextureName" % input )
                                                                if not re.findall( "/anm/|/textures/", filename, re.IGNORECASE ) or not re.findall( "[\\/]+server-3d[\\/]+|p:[\\/]+|[\\/]+renderserver[\\/]+", filename, re.IGNORECASE ):
                                                                    boolean = True
                                                                    break
                                                    if isFindTexture is False:
                                                        boolean = True
                                                if boolean is True:
                                                    result.append( "%s has attached to not used shader, all uv sets can be deleted" % node )
                                                    if debug is True:
                                                        print result[-1]
                                            if isFindMaterial is False:
                                                result.append( "%s has not attached to any material, all uv sets can be deleted" % node )
                                                if debug is True:
                                                    print result[-1]
                                        else:
                                            result.append( "%s has not attached to any material, all uv sets can be deleted" % node )
                                            if debug is True:
                                                print result[-1]
                            else:
                                result.append( "%s has not attached to any shading engine, all uv sets can be deleted" % node )
                                if debug is True:
                                    print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " " )[0]
            if not cmds.referenceQuery( node, isNodeReferenced=True ):
                uvsets = cmds.polyUVSet( node, query=True, allUVSets=True )
                if uvsets:
                    for uvset in uvsets:
                        if uvset != "map1":
                            try:
                                if not cmds.referenceQuery( node, isNodeReferenced=True ):
                                    cmds.polyUVSet( node, delete=True, uvSet=uvset )
                            except:
                                print "Failed to remove uv set from", node
                        else:
                            try:
                                if not cmds.referenceQuery( node, isNodeReferenced=True ):
                                    cmds.polyMapDel( node, constructionHistory=False )
                            except:
                                print "Failed to remove uv map from", node 
    return result

def checkHistory( nodes=[], query=True, debug=False ):
    result = []
    ignore = [ "objectTypeFilter", "transform", "decomposeMatrix", "plusMinusAverage", "pointOnCurveInfo", "groupId", "mesh", "nurbsCurve", "nurbsSurface", "objectSet", "defaultRenderUtilityList", "displayLayer", "partition", "objectNameFilter", "objectMultiFilter", "hyperGraphInfo", "defaultRenderingList", "renderLayer", "hyperView", "hyperLayout", "objectScriptFilter", "RenderMan", "defaultShaderList", "materialInfo", "proxyManager", "deleteColorSet", "shadingEngine", "lightLinker" ]
    if not nodes:
        nodes = cmds.ls(geometry=True, ni=True)
        if nodes:
            for node in nodes:
                connections = cmds.listHistory( node )
                future = cmds.listHistory( node, future=True )
                cache = []
                for part in connections:
                    if cmds.nodeType(part) not in ignore:
                        if part != node:
                            cache.append( part )
                connections = cache
                nodeList = [] 
                if connections:
                    nodeList = connections
                    if future:
                        nodeList = nodeList + future 
                    if not cmds.ls( nodeList, type=[ "skinCluster", "time", "file", "place3dTexture", "place2dTexture", "shaveHair", "joint", "animCurveTU", "animCurveTT", "animCurveUU", "animCurveUL", "animCurveUA", "animCurveUT", "animCurveTL", "animCurveTA" ] ):
                        result.append( { node:connections } )
                        if debug is True:
                            print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            if type( result[i] ) is dict:
                nodes = result[i].keys()
                for node in nodes:
                    if not cmds.referenceQuery( node, isNodeReferenced=True ):
                        cmds.delete( node, ch=True )
                        cmds.bakePartialHistory( node, preDeformers=True )
    return result

def checkAttributes( nodes=[], query=False, debug=False ):
    result = []
    renderman = cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True )
    if not nodes:
        nodes = nodes and ( type( nodes ) is list and nodes or [ nodes ] ) or cmds.ls( type=[ "transform", "mesh", "nurbsCurve" ], long=True, ni=True )
        for i in range( 0, len( nodes )):
            info = ""
            if cmds.nodeType( nodes[i] ) == "mesh":
                if renderman:
                    name = "%s.rman__torattr___subdivScheme" % nodes[i] 
                    if not cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ):
                        info = info + " -add rman__torattr___subdivScheme;"
                    name = "%s.rman__torattr___subdivScheme" % nodes[i] 
                    if not cmds.attributeQuery( "rman__torattr___subdivFacevaryingInterp", n=nodes[i], exists=True ):
                        info = info + " -add rman__torattr___subdivFacevaryingInterp; -set rman__torattr___subdivFacevaryingInterp -int 3;"
                    name = "%s.rman__torattr___invis" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___invis;"
                name = "%s.castsShadows" % nodes[i]
                if cmds.attributeQuery( "castsShadows", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set castsShadows -int 1;"
                name = "%s.receiveShadows" % nodes[i]
                if cmds.attributeQuery( "receiveShadows", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set receiveShadows -int 1;"
                name = "%s.primaryVisibility" % nodes[i]
                if cmds.attributeQuery( "primaryVisibility", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set primaryVisibility -int 1;"
                name = "%s.motionBlur" % nodes[i]
                if cmds.attributeQuery( "motionBlur", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set motionBlur -int 1;"
                name = "%s.visibleInReflections" % nodes[i]
                if cmds.attributeQuery( "visibleInReflections", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set visibleInReflections -int 1;"
                name = "%s.visibleInRefractions" % nodes[i]
                if cmds.attributeQuery( "visibleInRefractions", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set visibleInRefractions -int 1;"
                name = "%s.doubleSided" % nodes[i]
                if cmds.attributeQuery( "doubleSided", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set doubleSided -int 0;"
                name = "%s.opposite" % nodes[i]
                if cmds.attributeQuery( "opposite", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set opposite -int 0;"
                name = "%s.displaySmoothMesh" % nodes[i]
                if cmds.attributeQuery( "displaySmoothMesh", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 0:
                    info = info + " -set displaySmoothMesh -int 0;"
                name = "%s.smoothShading" % nodes[i]
                if cmds.attributeQuery( "smoothShading", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and cmds.getAttr( name ) != 1:
                    info = info + " -set smoothShading -int 1;"
            elif cmds.nodeType( nodes[i] ) == "transform":
                if renderman:
                    name = "%s.rman__torattr___invis" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___invis;"
                    name = "%s.rman__torattr___subdivScheme" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___subdivScheme;"
            elif cmds.nodeType( nodes[i] ) == "nurbsCurve":
                if renderman:
                    #name = "%s.rman__torattr___invis" % nodes[i]
                    #if not cmds.attributeQuery( "rman__torattr___invis", n=nodes[i], exists=True ):
                        #info = info + " -add rman__torattr___invis;"
                    name = "%s.rman__torattr___subdivScheme" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___subdivScheme", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___subdivScheme;"
                    name = "%s.rman__torattr___slimShader" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimShader", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimShader;"
                    name = "%s.rman__torattr___slimSurface" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimSurface", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimSurface;"
                    name = "%s.rman__torattr___slimEnsemble" % nodes[i]
                    if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.listConnections( name ):
                        info = info + " -remove rman__torattr___slimEnsemble;"
            if renderman:
                name = "%s.rman__torattr___slimEnsemble" % nodes[i]
                if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimEnsemble;"
                name = "%s.rman__torattr___slimShader" % nodes[i]
                if cmds.attributeQuery( "rman__torattr___slimShader", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimShader;"
                name = "%s.rman__torattr___slimSurface" % nodes[i]        
                if cmds.attributeQuery( "rman__torattr___slimSurface", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimSurface;"
                name = "%s.rman__torattr___slimEnsemble" % nodes[i]        
                if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___slimEnsemble;"
                name = "%s.rman__torattr___postShapeScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___postShapeScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___postShapeScript;"
                name = "%s.rman__torattr___postTransformScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___postTransformScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___postTransformScript;"
                name = "%s.rman__torattr___preShapeScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___preShapeScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___preShapeScript;"
                name = "%s.rman__torattr___transformBeginScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___transformBeginScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___transformBeginScript;"
                name = "%s.rman__torattr___transformEndScript" % nodes[i]    
                if cmds.attributeQuery( "rman__torattr___transformEndScript", n=nodes[i], exists=True ) and not cmds.listConnections( name ) and not cmds.getAttr( name ):
                    info = info + " -remove rman__torattr___transformEndScript;"
            if info:
                result.append( "%s%s" % ( nodes[i], info ))
                if debug is True:
                    print result[-1]
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            node = result[i].split( " " )[0]
            args = result[i].split( "%s " % node )[-1]
            args = args.split( ";" )
            if cmds.objExists( node ) and not cmds.referenceQuery( node, isNodeReferenced=True ):
                for n in range( 0, len( args )):
                    if "-remove" in args[n]:
                        target = args[n].split( "-remove " )[-1]
                        if cmds.attributeQuery( target, n=node, exists=True ):
                            cmds.deleteAttr( "%s.%s" % ( node, target ) )
                    if "-add" in args[n]:
                        target = args[n].split( "-add " )[-1]
                        mel.eval( "rmanAddAttr( \"%s\", \"%s\", \"\" )" % ( node, target ))
                    if "-set" in args[n]:
                        target = ( args[n].split( "-set " )[-1] ).split( " -" )[0]
                        if "-int" in args[n]:
                            value = int( args[n].split( "-int " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value )
                        elif "-float" in args[n]:
                            value = float( args[n].split( "-float " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value )
                        elif "-str" in args[n]:
                            value = str( args[n].split( "-str " )[-1])
                            cmds.setAttr( "%s.%s" % ( node, target ), value, type="string" )
    return result

def checkHierarchy( nodes=[], query=False, debug=True ):
    """
    Build or repair hierarchy for all transforms nodes with dag childrens from current opened maya scene.
    """
    result = []
    references = ml_reference.listReferenceContentAssemblies()
    if references:
        sceneName = cmds.file( query=True, sceneName=True )
        keys = references.keys()
        cameras = cmds.listCameras()
        cameras = "|".join(( "\|".join(("<>".join( cameras )).split( "|" ))).split( "<>" ))
        if not nodes:
            if keys:
                ignoreScene = False
                if len( keys ) > 1:
                    ignoreScene = True
                for key in keys:
                    if ignoreScene is True and sceneName != key or ignoreScene is False:
                        if not re.findall( "proxy.mb|proxy.ma", key, re.IGNORECASE ):    
                            transforms = references[ key ]
                            if transforms:
                                transforms = [ transform for transform in transforms if not re.findall( cameras, transform ) ]
                            if transforms:
                                root = ""
                                geometry = ""
                                rig = ""
                                rigExists = False
                                for transform in transforms:
                                    if re.findall( "root$", transform ):
                                        root = transform
                                        break
                                if root:
                                    childs = cmds.listRelatives( root, children=True, fullPath=True )
                                    childs = childs and childs or []
                                    if childs:
                                        for child in childs:
                                            if re.findall( "geo_normal$|geometry$|geometry_grp$", child, re.IGNORECASE ):
                                                geometry = child
                                                break
                                    if geometry == "":
                                        geometry = "%s|geo_normal" % root
                                    if childs:
                                        for child in childs:
                                            if re.findall( "rig", child, re.IGNORECASE ):
                                                rig = child
                                                rigExists = True
                                                break
                                    if rig == "":
                                        rig = "%s|rig" % root
                                    if childs:
                                        for child in childs:
                                            if not cmds.ls( child, dag=True, type="nurbsCurve" ):
                                                if child != rig and child != geometry:
                                                    action = ( "%s parent to %s" % ( child, geometry)) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                                    if action not in result:
                                                        result.append( action )
                                                        if debug is True:
                                                            print result[-1]
                                                            print "Founded unknown transforms in root directory: %s" % child
                                    for transform in transforms:
                                        if transform != root and not re.findall( "^\%s" % root, transform ):
                                            action = ( "%s parent to %s" % ( transform, geometry )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                            if action not in result:
                                                result.append( action )
                                                if debug is True:
                                                    print result[-1]
                                                    print "Founded unknown transforms: %s" % transform
                                else:
                                    root = "|root"
                                    geometry = "|root|geo_normal"
                                    rig = "|root|rig"
                                    for transform in transforms:
                                        action = ( "%s parent to %s" % ( transform, geometry )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                        if action not in result:
                                            result.append( action )
                                            if debug is True:
                                                print result[-1]
                                                print "Failed to find root directory: %s" % transform
                                if rigExists is False:
                                    action = ( "%s create base rig %s|rig" % ( geometry, root )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                    if action not in result:
                                        result.append( action )
                                        if debug is True:
                                            print result[-1]
                                            print "Failed to find controls for: %s" % root
                                else:
                                    if cmds.ls( rig, dag=True, type="nurbsCurve" ):
                                        if not cmds.listConnections( cmds.ls( rig, dag=True, type="transform", long=True ), source=False, destination=True ):
                                            action = ( "%s can be deleted" % rig ) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                            if action not in result:
                                                result.append( action )
                                                if debug is True:
                                                    print result[-1]
                                                    print "Founded not used rig: %s" % rig
                                            action = ( "%s create base rig %s" % ( geometry, rig )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                            if action not in result:
                                                result.append( action )
                                        else:
                                            childs = cmds.listRelatives( rig, children=True, fullPath=True )
                                            if len( childs ) == 1 and cmds.listConnections( childs[0] ):
                                                action = ( "%s create parent rig %s" % ( childs[0] , rig + "|general_CT" )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                                if action not in result:
                                                    result.append( action )
                                                    if debug is True:
                                                        print result[-1]
                                                        print "Failed to find parent control: %s" % childs[0]
                                    else:
                                        action = ( "%s create base rig %s" % ( geometry, rig )) + ( ignoreScene is True and ( " from file " + key ) or "" )
                                        if action not in result:
                                            result.append( action )
                                            if debug is True:
                                                print result[-1]
                                                print "Failed to find controls: %s" % rig
        else:
            result = nodes
    if query is False:
        for i in range( 0, len( result )):
            buffer = result[i].split( " " )
            node = buffer[0]
            if cmds.objExists( node ) and not cmds.referenceQuery( node, isNodeReferenced=True ):
                if "from file" not in result[i]:
                    if "parent to" in result[i]:
                        target = buffer[-1]
                        if cmds.objExists( target ):
                            cmds.parent( node, target )
                        else:
                            makeTransform( target )
                            cmds.parent( node, target )
                    elif "create base rig" in result[i]:
                        target = buffer[-1]
                        rig = target.split( " " )[-1]
                        makeTransform( rig )
                        generalCT_offset = createCurveControl( name='general_offset_CT', parent=rig, size=node, target=node, constraint=True, debug=debug )
                        createCurveControl( name='general_CT', parent="root|rig", size=generalCT_offset, target=generalCT_offset, constraint=False, debug=debug )
                    elif "create constraint rig" in result[i]:
                        target = buffer[-1]
                        rig = makeTransform( "|".join( target.split( "|" )[:-1]))
                        controlName = target.split( "|" )[-1]
                        createCurveControl( name=controlName, parent=rig, size=node, target=node, constraint=True, debug=debug )
                    elif "create parent rig" in result[i]:
                        target = buffer[-1]
                        rig = makeTransform( "|".join( target.split( "|" )[:-1]))
                        controlName = target.split( "|" )[-1]
                        createCurveControl( name=controlName, parent=rig, size=node, target=node, constraint=False, debug=debug )
                    elif "can be deleted" in result[i]:
                        try:
                            cmds.delete( node )
                            if debug is True:
                                print "Delete: %s" % node
                        except:
                            print "Failed to delete %s" % node
            else:
                print "Node is not exists or referenced", node
    return result

def makeTransform( path ):
    result = []
    if not cmds.objExists( path ):
        groups = path.split( "|" )
        for i in range( 0, len( groups )):
            if groups[i]:
                if not cmds.objExists( "|".join(groups[:i+1] )):
                    if i == 0:
                        transform = cmds.createNode( "transform", name=groups[i] )
                        result.append( transform )
                    else:
                        transform = cmds.createNode( "transform", name=groups[i], parent="|".join( groups[:i] ))
                        result.append( "|".join( result ) + "|" + transform )
    else:
        result = path
    return result

def getBoundingBoxLength( node ):
    """
    Get max bounding box length for current node.
    """
    bb = { "min":cmds.getAttr( node + ".boundingBoxMin" )[0], "max":cmds.getAttr( node + ".boundingBoxMax" )[0] }
    zyx = { "x":bb["max"][0] - bb["min"][0], "y":bb["max"][1] - bb["min"][1], "z":bb["max"][2] - bb["min"][2] }
    key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx["x"] and zyx["y"] >= zyx["z"]:"y", zyx["z"] >= zyx["x"] and zyx["z"] >= zyx["y"]:"z" }
    return zyx[ key[ True ] ]

def createCurveControl( name="", parent="", size="", target="", constraint=True, debug=False ):
    """
    Create curve base rig control for maya nodes in current opened scene.
    """
    curveMel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
    curve = mel.eval( curveMel )
    length = getBoundingBoxLength( size )
    if name != "":
        targetShort = target.split( "|" )[-1]
        if name != targetShort:
            curve = cmds.rename( curve, name )
        else:
            temp = targetShort.split( "_" )
            if len( temp ) > 1:
                target = cmds.rename( target, "_offset_".join( temp ))
            else:
                target = cmds.rename( target, temp[0] + "_offset" )
            curve = cmds.rename( curve, name )
        if debug is True:
            print "rename %s %s" % ( curve, name )
    cmds.scale( 1.2 * length, 1.2 * length, 1.2 * length, curve )
    cmds.makeIdentity( curve, translate=True, rotate=True, scale=True, apply=True )
    if target != "":
        if constraint is True:
            cmds.parentConstraint( curve, target, maintainOffset=True, weight=1 )
            cmds.scaleConstraint( curve, target, maintainOffset=True, weight=1 )
            if debug is True:
                print "parentConstraint %s -maintainOffset %s" % ( curve, target )
                print "scaleConstraint %s -maintainOffset %s" % ( curve, target )
        else:
            cmds.parent( target, curve )
            if debug is True:
                print "parent %s %s" % ( target, curve )
    if parent != "":
        cmds.parent( curve, parent )
        curve = ( type( parent ) is list and parent[0] or parent ) + "|" + ( type( curve ) is list and curve[0] or curve )
        if debug is True:
            print "parent %s %s" % ( curve, parent )
    return curve

def checkReferenceParts( nodes=[], query=False, debug=False ):
    result = []
    if not nodes:
        references = main.listReferences( characters=False, onlyLoaded=False, rfn=False, fullHierarchy=False )
        for reference in references:
            assemblies = referenceParted( reference )
            if assemblies: 
                result.append( { reference:assemblies } )
                if debug is True:
                    print reference
    if query is False:
        pass
    return result

def checkPartitions( nodes=[], query=True, debug=False ):
    if not nodes:
        result = []
        boolean = False
        partitions = cmds.ls( type="partition" )
        for partition in partitions:
            if not cmds.referenceQuery( partition, isNodeReferenced=True ):
                if partition != "mtorPartition" and cmds.attributeQuery( "slimData", n=partition, exists=True ):
                    result.append( partition )
    else:
        result = nodes
    if query is False:
        if result:
            cmds.delete( result )
    return result

def checkUnusedSlimPalettes( nodes=[], query=False, debug=False ):
    import advslim 
    if not nodes:
        result = []
        palettes = advslim.unusedPalettes( returnName=True )
        if palettes:
            for palette in palettes:
                result.append( palette )
    else:
        result = nodes
    if query is False:
        for i in range( 0, len( result )):
            palette = result[i].split( "," )[0]
            advslim.removePalette( palette )
    return result

def referenceParted( reference ):
    import maya.cmds as cmds
    checked = []
    assemblies = []
    parentReference = cmds.referenceQuery( reference, parent=True, filename=True )
    transforms = cmds.referenceQuery( reference, nodes=True, dagPath=True )
    transforms = cmds.ls( transforms, type="transform", long=True ) 
    for transform in transforms:
        parent = cmds.listRelatives( transform, parent=True, fullPath=True )
        if parent:
            parent = parent[0]
            if parent not in transforms:
                if cmds.referenceQuery( parent, isNodeReferenced=True ):
                    filename = cmds.referenceQuery( parent, filename=True )
                    if filename != reference and filename != parentReference:
                        if filename not in checked: 
                            checked.append( filename )
                        assemblies.append( transform )
                else:
                    if "local" not in checked: 
                        checked.append( "local" )
                    assemblies.append( transform )
        else:
            if "world" not in checked: 
                checked.append( "world" )
            assemblies.append( transform )
    if len( checked ) > 1:
        return assemblies
    else:
        return []
    
def checkReferenceConnections( nodes=[], query=True, debug=False ):
    result = []
    if not nodes:
        references = main.listReferences( characters=False, onlyLoaded=True, rfn=True, fullHierarchy=True )
        for reference in references:
            connections = cmds.listConnections( reference, plugs=True, source=False )
            if connections:
                geometry = []
                for connection in connections:
                    if "inputGeometry" in  connection or "inMesh" in  connection:
                        geometry.append( connection )
                if geometry:
                    result.append( { reference:geometry } )
                    if debug is True:
                        print reference
    if query is False:
        pass
    return result

def checkProxies( nodes=[], query=True, debug=False ):
    if not nodes:
        result = []
        proxies = cmds.ls( type="proxyManager" )
        for proxy in proxies:
            parents = []
            references = cmds.listConnections( proxy, type="reference", source=False )
            if references:
                cache = []
                for reference in references:
                    if reference not in cache:
                        if cmds.listConnections( "%s.%s" % ( reference, "proxyMsg" ), type="proxyManager" ):
                            cache.append( reference )
                        else:
                            if reference not in result:
                                result.append( reference )
                references = cache
                print references
                if len( references ) > 1:
                    for reference in references:
                        try:
                            parent = cmds.referenceQuery( reference, parent=True, filename=True )            
                            if parent not in parents:
                                parents.append( parent )
                        except:
                            result.append( proxy )
            if len( parents ) != 1:
                result.append( proxy )
    else:
        result = nodes
    if query is False:
        pass
    return result

def checkReferenceNamespace( nodes=[], query=True, debug=False ):
    if not nodes:
        result = []
        cache = []
        references = cmds.file( query=True, reference=True )
        while references:
            nested = []
            namespaces = []
            for reference in references:
                rfn = cmds.file( reference, query=True, rfn=True )
                if rfn not in cache: 
                    cache.append( rfn )
                    pm = cmds.listConnections( rfn, type="proxyManager" )
                    if pm:
                        proxies = cmds.listConnections( pm, type="reference" )
                        if proxies:
                            for proxy in proxies:
                                if proxy not in cache:
                                    cache.append( proxy )
                    namespace = cmds.file( reference, query=True, renamingPrefix=True )    
                    if namespace not in namespaces:
                        namespaces.append( namespace )
                    else:
                        result.append( rfn )
                    childs = cmds.file( reference, query=True, reference=True )
                    if childs:
                        nested += childs
            references = nested
    else:
        result = nodes
    if query is False:
        pass
    return result
        
def listReferences( references=[], characters=False, onlyLoaded=False, rfn=False, fullHierarchy=False ):
    """
    Iterate all references from current scene.
    """
    import maya.cmds as cmds
    import re
    if not references:
        rn = cmds.file( query=True, reference=True )
    else:
        rn = type( references ) is list and references or [ references ]
    while rn:
        cache = []
        if rn:
            for reference in rn:
                child = cmds.file( reference, query=True, reference=True )
                if child:
                    cache += child
                    if fullHierarchy is True:
                        if rfn is True:
                            rfNode = cmds.file( reference, query=True, rfn=True )
                            yield rfNode
                        else:
                            yield reference
                else:
                    if onlyLoaded is True and cmds.referenceQuery( reference, isLoaded=True ) or onlyLoaded is False:
                        if characters is True and re.findall( "/chars/", reference ) or characters is False:
                            if rfn is True:
                                rfNode = cmds.file( reference, query=True, rfn=True )
                                yield rfNode
                            else:
                                yield reference
        rn = cache    
    