import maya.cmds as cmds
import maya.mel as mel
import re
import os
import sys

def batchPlayblast( source=[], width=2048, height=858, destination="", start=0, end=0, step=1, output="", imagePlane=0, debug=True ):
    cmds.file( new=True, force=True )
    destination = server3d( destination )
    output = server3d( output )
    referenceTimeline = []
    for i in range( 0, len( source )):
        source[i] = server3d( source[i] )
        mayatype = re.findall( "\.ma", source[i] ) and "mayaAscii" or re.findall( "\.mb", source[i] ) and "mayaBinary" or ""
        if debug is True:
            print i 
            print "file:", source[i]
            print "type:", mayatype 
        cmds.file( source[i], open=True, force=True, options="v=0", ignoreVersion=True, loadReferenceDepth="none", type=mayatype )
        referenceTimeline.append( cmds.playbackOptions( query=True, minTime=True )) 
        referenceTimeline.append( cmds.playbackOptions( query=True, maxTime=True ))
        if debug is True:
            print "timeline: %s-%s" % ( referenceTimeline[-2], referenceTimeline[-1] )  
    cmds.file( new=True, force=True )
    for i in range( 0, len( source )):
        cmds.file( source[i], reference=True, namespace=source[i].split( "/" )[-1].split( "." )[0] )
    sound = cmds.ls(type="audio")
    if sound:
        sound = sound[-1]
    else:
        sound = ""
    cameras = cmds.listCameras()
    camera = cameras[-1]
    for i in range( 0, len( cameras )):
        if re.findall( "ep[0-9]+sc[0-9]+", cameras[i], re.IGNORECASE ):
            camera = cameras[i]
            break
    timeline = []
    shots = cmds.ls( type="shot" )
    if shots:
        for i in range( 0, len( shots )):
            timeline.append( cmds.getAttr( "%s.sequenceStartFrame" % shots[i] ))
            timeline.append( cmds.getAttr( "%s.sequenceEndFrame" % shots[i] ))
        if debug is True:
            print "sequence timeline: %s-%s" % ( timeline[-2], timeline[-1] )
    if start == 0:
        if timeline:
            start = min( timeline )
        else:
            if source:
                start = min( referenceTimeline )
            else:
                start = cmds.playbackOptions( query=True, minTime=True ) 
    if end == 0:
        if timeline:
            end = max( timeline )
        else:
            if source:
                end = max( referenceTimeline )
            else:
                end = cmds.playbackOptions( query=True, maxTime=True )
    cmds.playbackOptions( min=start, ast=start, max=end, aet=end ) 
    if debug is True:
        print "concat:", source
        print "filename:", destination
        print "output:", output
        print "camera:", camera
        print "start frame:", start
        print "end frame:", end
    cmds.file( rename=destination )
    cmds.file( type="mayaAscii", save=True )
    rendermanPlayblast( camera, start=start, end=end, step=1, width=2048, height=858, output=output, imagePlane=imagePlane, debug=debug )
    
def rendermanPlayblast( camera, start=1, end=24, step=1, width=2048, height=858, pixelAspect=1.0, output="", imagePlane=True, debug=True ):
    mel.eval( 'setCurrentRenderer renderMan;' )
    cmds.setAttr( "defaultRenderGlobals.imageFormat", 23 )
    cmds.setAttr( "defaultRenderGlobals.animation", 1 )
    cmds.setAttr( "defaultRenderGlobals.animationRange", 0 )
    cmds.setAttr( "defaultRenderGlobals.startFrame", start )
    cmds.setAttr( "defaultRenderGlobals.endFrame", end )
    cmds.setAttr( "defaultRenderGlobals.byFrameStep", step )
    cmds.setAttr( "defaultResolution.width", width )
    cmds.setAttr( "defaultResolution.height", height )
    cmds.setAttr( "defaultRenderGlobals.imageFilePrefix", ".".join( output.split( "." )[:-1]), type="string" )
    cmds.setAttr( "hardwareRenderingGlobals.objectTypeFilterValueArray", [ 0, 0, 1, 1, 1, 1, imagePlane, 0, 1, 0, 0, 0, 0, 0, 0, 0 ], type="Int32Array" )
    cmds.setAttr( "defaultResolution.pixelAspect", pixelAspect )
    deviceAspect = ( float( width ) / float( height )) * float( pixelAspect )
    cmds.setAttr( "defaultResolution.deviceAspectRatio", deviceAspect )
    cameras = cmds.listCameras()
    for i in range( 0, len( cameras )):
        if camera != cameras[i]:
            cmds.setAttr( "%s.renderable" % cameras[i], 0 )
        else:
            cmds.setAttr( "%s.renderable" % cameras[i], 1 )
    import sendToRender
    reload(sendToRender)
    sendToRender.rmanSpoolRemoteRIBRemoteRender("","",1400,"playblast","","rms-18.0-maya-2013 prman-18.0","","","","","",5,False,False,0.0,0.0,0.0,0.0,0,False,True,True,False,True,False,False,True,2,True,2,False,False,1.0,1.0,1.0,False,False,True,True,True,True,True,True,True,True,True,True,80.0,"subframe","frameOpen",0.35,0.65,False,False,5.0,5.6,1.0,True,1.0,True,3.0,True,3.0,True,9,9,False,4.0,4.0,"gaussian",False,"binary","gzip",False,False,False,False,0)
                                    
def server3d( path ):
    server = sys.platform != "win32" and "/Server-3d/" or "//Server-3d/"
    expression = re.compile( "/Server-3d/|//Server-3d/|P:/", re.IGNORECASE )
    return expression.sub( server, path )

#batchPlayblast( source=[ "//Server-3d/Project/UrfinJuse/assets/props/BankaBumazhnayaKryshkaIzumrudnyiGorod/maya/bankaBumazhnayaKryshkaIzumrudnyiGorod.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaIzumrudnyiGorod/maya/bankaIzumrudnyiGorod.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaKarandasheiElli/maya/bankaKarandasheiElli.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaUrfina/maya/bankaUrfina.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaUrfinaShipastayaKryshka/maya/bankaUrfinaShipastayaKryshka.mb" ], width=2048, height=858, destination="D:/testAvi.ma", start=0, end=0, step=1, output="D:/test12.avi", debug=True )
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop01/anm/ep07sc30dop01_anm.ma", "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop02/anm/ep07sc30dop02_anm.mb" ], width=2048, height=858, destination="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var01.ma", start=0, end=0, step=1, output="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var01.avi", debug=True )")
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop01/anm/ep07sc30dop01_anm.ma", "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop02/anm/ep07sc30dop02_anm.mb" ], width=2048, height=858, destination="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var02.ma", start=0, end=0, step=1, output="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var02.avi", debug=True )")
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop01/anm/ep07sc30dop01_anm.ma", "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop02/anm/ep07sc30dop02_anm.mb" ], width=2048, height=858, destination="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var03.ma", start=0, end=0, step=1, output="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var03.avi", debug=True )")
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop01/anm/ep07sc30dop01_anm.ma", "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop02/anm/ep07sc30dop02_anm.mb" ], width=2048, height=858, destination="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var04.ma", start=0, end=0, step=1, output="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var04.avi", debug=True )")
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop01/anm/ep07sc30dop01_anm.ma", "/Server-3d/Project/UrfinJuse/scenes/ep07/ep07sc30dop02/anm/ep07sc30dop02_anm.mb" ], width=2048, height=858, destination="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var05.ma", start=0, end=0, step=1, output="/Server-3d/Project/UrfinJuse/person_files/Guzha/ep07sc30_var05.avi", debug=True )")
#python("import batchPlayblast; batchPlayblast.batchPlayblast( source=[ "//Server-3d/Project/UrfinJuse/assets/props/BankaBumazhnayaKryshkaIzumrudnyiGorod/maya/bankaBumazhnayaKryshkaIzumrudnyiGorod.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaIzumrudnyiGorod/maya/bankaIzumrudnyiGorod.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaKarandasheiElli/maya/bankaKarandasheiElli.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaUrfina/maya/bankaUrfina.mb","//Server-3d/Project/UrfinJuse/assets/props/BankaUrfinaShipastayaKryshka/maya/bankaUrfinaShipastayaKryshka.mb" ], width=2048, height=858, destination="D:/testAvi.ma", start=0, end=0, step=1, output="D:/test12.avi", debug=True )")