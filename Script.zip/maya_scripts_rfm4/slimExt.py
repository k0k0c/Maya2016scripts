'''
import slimExt
reload(slimExt)

slimExt.slimInitialize() - Load renderman plugin and run slim.
slimExt.slimReAttachMaterial( oldID='', newID='', selected=False ) - Reattach shaders by index.
slimExt.slimLocalize( selected=False ) - Create instances for materials and reattach shaders.
slimExt.slimBackUpID( selected=False ) - Backup materials index.
slimExt.slimRestoreBackupID( selected=False, read=False ) - Restore index from backup.
slimExt.slimListAttachedID( shape='', selected=False ) - List all materials id attached to objects.
slimExt.slimCreateInstance( node, parent='' ) - Create instance for slim node.
slimExt.slimCreatePalette( name='' ) - Create new pallete.
slimExt.slimGetShadedObjects( selected=False ) - List all objects with slim materials.
slimExt.slimGetNodes( palettes='', type='' ) - List slim nodes.
slimExt.slimDeleteUnusedGpSurface() - Delete all non attached materias.
slimExt.slimGetNonAttached() -List all non attached materias.
slimExt.slimDeleteNode( arg, *args ) - Delete slim node.
slimExt.slimDeleteEmptyPalette() - Delete empty palette.
slimExt.slimCreateDynamicRule( attribute='', value='' , selected=False) - Create dynamic rule.
slimExt.slimDeleteDynamicRule( selected=False ) - Delete dynamic rule.
slimExt.slimFindNodeByValue( attribute='', value='' ) - Find slim node by attribute value.
slimExt.slimDeleteAllNodes( selected=False ) - Delete all slim nodes.
slimExt.slimSelectObjectByID( id='' ) - Select objects by id.
slimExt.slimCreateSubPalette( name, parent='' ) - Create subpalette.
slimExt.slimFindMaterialByID( id='' ) - Find slim node by id.
'''

import maya.cmds as cmds
import maya.mel as mel
import sys
import os
import re

OSTYPE = sys.platform
if OSTYPE == "win32":
	OSTYPE="//Server-3d/Project"
else:
	OSTYPE="/Server-3d/Project"

tcl = '''/lib/setup/rfm180/slimArchiCmd.tcl'''

def slimInitialize():

	try:
		cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True and cmds.loadPlugin("RenderMan_for_Maya")
		mel.eval('rman slim isconnected') != 1 and mel.eval('rman slim start')
		procs = tcl.split('\n')
		for i in range( 0, len( procs ) ):
			mel.eval('rman slim command "source ' + OSTYPE + procs[i] + '"')
		return True
	except:
		return False

def slimReAttachMaterial( src, dst, selected=False, ignoreBackup=False ):

	print '\tReAttach %s to %s\n' % ( src, dst )
	objects = slimGetShadedObjects( selected=selected )
	attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	attributesExists = []
	attributesBackup = 'slimShaderBackup'
	try:
		for i in range( 0, len( objects ) ):
			attributesExists = []
			attributesExists = [ attributes[p] for p in range( 0, len( attributes ) ) if cmds.attributeQuery( attributes[p], n=objects[i], exists=True ) ]
			if cmds.attributeQuery( attributesBackup, n=objects[i], exists=True ) is True and ignoreBackup is False:
				backUpValue = cmds.getAttr( objects[i] + '.' + attributesBackup ).split(',')
				for n in range( 0, len( backUpValue ) ):
					backUpValueCurrent = backUpValue[ n ].split('/')
					if backUpValueCurrent[-1] in attributesExists:
						if backUpValueCurrent[0] == src:
							value = cmds.getAttr( objects[i] + '.' + backUpValueCurrent[-1] )
							value = value.replace( backUpValueCurrent[ 1 ], dst )
							backUpValue[n] = backUpValueCurrent[ 0 ] + '/' + dst + '/' + backUpValueCurrent[ -1 ]
							cmds.setAttr( objects[i] + '.' + attributesBackup, ','.join( backUpValue ), type='string' )
							cmds.setAttr( objects[i] + '.' + backUpValueCurrent[-1], value, type='string' )
							break
			else:
				for p in range( 0, len( attributes ) ):
					if attributes[p] in attributesExists:
						value = cmds.getAttr( objects[i] + '.' + attributes[p] )
						if src in value:
							value = value.replace( src, dst )
							cmds.setAttr( objects[i] + '.' + attributes[p], value, type='string' )
		return True
	except:
		return False

def slimRestoreBackupID( selected=True, read=False ):

	result = []
	objects = slimGetShadedObjects( selected=selected )
	attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	attributesExists = []
	attributesBackup = 'slimShaderBackup'
	for i in range( 0, len( objects ) ):
		attributesExists = []
		attributesExists = [ attributes[p] for p in range( 0, len( attributes ) ) if cmds.attributeQuery( attributes[p], n=objects[i], exists=True ) ]
		if read is False:
		    [ cmds.setAttr( objects[i] + '.' + attributesExists[p], '', type='string' ) for p in range( 0, len( attributesExists ) ) ]
		if cmds.attributeQuery( attributesBackup, n=objects[i], exists=True ):
			backupID = cmds.getAttr( objects[i] + '.' + attributesBackup ).split(',')
			for n in range( 0, len( backupID ) ):
				original = backupID[n].split('/')[0]
				replaced = backupID[n].split('/')[1]
				attribute = backupID[n].split('/')[-1]
				if attribute in attributesExists:
					if read is False:
						newBackup = cmds.getAttr( objects[i] + '.' + attributesBackup )
						newBackup = newBackup.replace( replaced, original )
						cmds.setAttr( objects[i] + '.' + attributesBackup, newBackup, type='string' )
						attributeValue = cmds.getAttr( objects[i] + '.' + attribute )
						if attributeValue == '':
							cmds.setAttr( objects[i] + '.' + attribute, original, type='string' )
						else:
							cmds.setAttr( objects[i] + '.' + attribute, attributeValue + ',' + original, type='string' )
					if original not in result:
						result.append( original )
	return result   	
	
def slimBackUpID( selected=False, force=False ):

	result = []
	objects = slimGetShadedObjects( selected=selected )
	attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	attributesBackup = 'slimShaderBackup'
	for i in range( 0, len( objects ) ):
		backupID = ''
		if cmds.attributeQuery( attributesBackup, n=objects[i], exists=True ) is False or force is True:
			for p in range( 0, len( attributes ) ):
				if cmds.attributeQuery( attributes[p], n=objects[i], exists=True ):
					id = cmds.getAttr( objects[i] + '.' + attributes[p] ).split(',')
					if cmds.attributeQuery( attributesBackup, n=objects[i], exists=True ) is False:
						cmds.addAttr( objects[i], longName=attributesBackup, hidden=False, dataType='string' )
					if force is True:
						cmds.setAttr( objects[i] + '.' + attributesBackup, '', type='string' )
					for n in range( 0, len( id ) ):
						if id[n] not in backupID:
							if backupID != '':
								backupID = backupID + ',' + id[n] + '/' + id[n] + '/' + attributes[p]
							else:
								backupID = id[n] + '/' + id[n] + '/' + attributes[p]
			attributeValue = cmds.getAttr( objects[i] + '.' + attributesBackup )
			if attributeValue:
				backupID = attributeValue + ',' + backupID		
			cmds.setAttr( objects[i] + '.' + attributesBackup, backupID, type='string' )
		backupID = cmds.getAttr( objects[i] + '.' + attributesBackup ).split(',')
		for n in range( 0, len( backupID ) ):
			backupID_temp = backupID[n].split('/')[0]
			if backupID_temp not in result:
				result.append( backupID_temp )
	return result   

def slimListAttachedID( shape=None, selected=False ):
    
	result = []
	if shape == '':
		objects = slimGetShadedObjects( selected=selected )
	else:
		objects = [ shape ]	
	for i in range( 0, len( objects ) ):
		if cmds.attributeQuery( 'rman__torattr___slimShader', n=objects[i], exists=True ):
			coid = cmds.getAttr( objects[i] + '.rman__torattr___slimShader' ).split(',')
			for n in range( 0, len( coid ) ):
				if coid[n] not in result:
					result.append( coid[n] )
		id = cmds.getAttr( objects[i] + '.rman__torattr___slimSurface' )
		if id not in result:
			result.append( id )
	return result
		
def slimCreateInstance( node, parent='' ):

	result = mel.eval( 'rman slim command "createInstance ' + node + ' ' + parent + '"' )
	print '\t\tCreate instance : %s : for : %s : in : %s' % ( result, node, parent )
	return result

def slimCreatePalette( name='' ):

	result = mel.eval( 'rman slim command "createPalette ' + name + '"' )
	return result

def slimCreateSubPalette( name, parent='' ):

	result = mel.eval( 'rman slim command "createPalette ' + name + ' ' + parent + '"' )
	print '\t\tCreate subpalette : %s' % ( result ) 
	return result
	
def slimGetShadedObjects( selected=False ):

	result = []
	selection = { False:'ls -dag -shapes -noIntermediate;', True:'ls -sl -dag -shapes -noIntermediate;' }
	temp = mel.eval( selection[ selected ] )
	if temp:	
		for i in range( 0, len( temp ) ):
			if cmds.attributeQuery( 'rman__torattr___slimSurface', n=temp[i], exists=True ) or cmds.attributeQuery( 'rman__torattr___slimShader', n=temp[i], exists=True ):
				if temp[i] not in result:
					result.append( temp[i] )
	return result
	
def slimGetNodes( type='' ):
	
	result = ( 'rman slim command "listNodes ' + type + '"' ).split(' ')
	return result
	
def slimDeleteUnusedGpSurface():

	result = []
	result = slimGetNonAttached()
	palettes = mel.eval( 'rman slim command "slim GetPalettes"' ).split( ' ' )
	if result:
		command = 'slimDeleteNode( ' + '"' + '", "'.join(result) + '" )'
		exec( command )
	if palettes:
		for i in range( 0, len( palettes ) ):
			subpalettes = mel.eval( 'rman slim command "' + palettes[i] + ' GetDescendents depthFirst"' ).split( ' ' )
			mel.eval( 'rman slim command "' + palettes[i] + ' DeleteDisconnected"' )
	return result
	
def slimGetNonAttached():
	
	result = []
	nodes = slimGetNodes( type='material' )
	id = slimListAttachedID( shape='', selected=False )
	for i in range( 0, len( nodes ) ):
		if mel.eval( 'rman slim command "' + nodes[i] + ' GetID"' ) not in id:
			if nodes[i] not in result:
				result.append( nodes[i] )
	return result
	
def slimDeleteNode( arg, *args ):
	
	result = []
	
	if arg:
		result.append( arg )
		mel.eval( 'rman slim command "' + arg + ' Delete 0"' )
		print '\tDelete : %s' % ( arg ) 
	if args:
		for i in range( 0, len( args ) ):
			result.append( args[i] )
			mel.eval( 'rman slim command "' + args[i] + ' Delete 0"' )
			print '\tDelete : %s' % ( args[i] )
			
	mel.eval( 'rman slim command "update"' )
	mel.eval( 'rman slim command "slim CommitCmds"' )
	return result
	
def slimDeleteEmptyPalette():
	
	result = ''
	
def slimCreateDynamicRule( attribute='', value='' , selected=False):
	
	result = []
	return result
	
def slimDeleteDynamicRule( selected=False ):

	result = []
	return result
	
def slimFindNodeByValue( attribute='', value='' ):

	result = []
	return result
	
def slimDeleteAllNodes( selected=False ):

	result = []
	return result	

def slimSelectObjectByID( id='' ):
	
	result = []
	objects = slimGetShadedObjects( selected=False )
	attributes = [ 'slimShaderBackup', 'rman__torattr___slimShader', 'rman__torattr___slimSurface' ]
	for i in range( 0, len( objects ) ):
		for p in range( 0, len( attributes ) ):
			if cmds.attributeQuery( attributes[p], n=objects[i], exists=True ):
				objectID = cmds.getAttr( objects[i] + '.' + attributes[p] )
				if id in objectID:
					if objects[i] not in result:
						result.append( objects[i] )
	cmds.select( cl=True )
	if result:
		cmds.select( result )
	return result
				
def slimFindMaterialByID( id='' ):

	result = mel.eval( 'rman slim command "ls -id ' + id + '"' )
	return result
	
def slimExternalize():
	slimInitialize()
	dir = slimGetPaletteProject( clear=True )
	mel.eval( 'rman slim command "externalizeScene ' + dir + '"' )
	return dir	
	
def slimInternalize():
	slimInitialize()
	dir = slimGetPaletteProject()
	mel.eval( 'rman slim command "clearScene"' )
	mel.eval( 'rman slim message "externalizeScene ' + dir + ' -load"' )
	return dir
	
def slimUniqialize():
	pass

def slimGetPaletteProject( clear=False ):
	folder = (cmds.file( query=True, sceneName=True ).split('/')[-1]).split('.')[0]
	folder = ( folder ) and folder or 'untitled'
	directory = cmds.workspace( query=True, rootDirectory=True ) + 'slim/palettes/' + folder
	if os.path.isdir( directory + '/work' ) is False:
		os.makedirs( directory + '/work' )
	if os.path.isdir( directory ) is False:
		os.makedirs( directory )
		os.makedirs( directory + '/work' )
	if clear is True:
		files = os.listdir( directory )
		files = [ files[i] for i in range( 0, len( files ) ) if re.findall( '.splt$', files[i] ) ]
		if files:
			for i in range( 0, len( files ) ):
				if re.findall( '.splt$', files[i] ):
					palette = directory + '/' + files[i]
					paletteRen = directory + '/work/' + files[i]
					if os.path.isfile( paletteRen ):
						os.remove( paletteRen )
					os.rename( palette, paletteRen )
	return directory
	
def slimLocalize( selected=False ):
	
	if slimInitialize():
		'continue'
	else:	
		cmds.error( 'Renderman plugin initialization failed.' )
	mel.eval( 'rman slim command "update"' )
	mel.eval( 'rman slim command "slim CommitCmds"' )
	
	root = ( cmds.file( query=True, sceneName=True ).split( '/' )[-1] ).split( '.' )[0] + { False:'', True:'_selected' }[ selected ]
	root = slimCreatePalette( name=root )
	
	palettes = mel.eval( 'rman slim command "slim GetPalettes"' ).split( ' ' )
	palettes = [ palettes[i] for i in range( 0, len( palettes ) ) if palettes[i] != root ]
	
	id = slimBackUpID( selected=selected )
	materials = [ slimFindMaterialByID( id=id[i] ) for i in range( 0, len( id ) ) ]
	materials = [ materials[i] for i in range( 0, len( materials ) ) if mel.eval( 'rman slim command "' + materials[i] + ' GetParent"' ) == mel.eval( 'rman slim command "' + materials[i] + ' GetRoot"' ) ]
	print '\n\t_ _ _ _ _Start._ _ _ _ _\n\n\n\tRoot : %s\n\tID : %s\n\tMaterials : %s' % ( root, ', '.join(id), ', '.join(materials) )
	
	manual = len( materials )
	for i in range( 0, len( materials ) ):
		index = mel.eval( 'rman slim command "InstanceAdv ' + materials[i] + ' ' + root + '"' )
		index = index.split( ' ' )
		print '\n\t( %s \\ %s )\n\tinstance material : %s to %s' % ( i + 1, manual, index[ 0 ], index[ -1 ] )
		slimReAttachMaterial( index[ 0 ], index[ -1 ], selected=selected )
	mel.eval( 'rman slim command "update"' )
	mel.eval( 'rman slim command "slim CommitCmds"' )
	print '\n\n\t_ _ _ _ _Stop._ _ _ _ _\n'