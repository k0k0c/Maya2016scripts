import maya.cmds as cmds
import maya.mel as mel
import sip
import re
import os
import sys
from PyQt4 import QtCore, QtGui
import maya.OpenMayaUI as mui
import maya.OpenMaya as om
import ml_reference

def getMayaWindow():
    m_app = mui.MQtUtil.mainWindow()
    return sip.wrapinstance( long( m_app ), QtCore.QObject )

class ReferenceEditor( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( ReferenceEditor, self ).__init__( parent )
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setSpacing( 0 )
        self.mainlayout.setContentsMargins( 3,3,3,3 )
        self.setLayout( self.mainlayout )
        self.isLoad=False
        
    def load( self ):
        self.m_fileOptionsWidget = QtGui.QWidget()
        self.m_fileOptionsLayout = QtGui.QGridLayout()
        self.m_fileOptionsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_fileOptionsWidget.setLayout( self.m_fileOptionsLayout )
        self.mainlayout.addWidget( self.m_fileOptionsWidget )
        
        self.mainMenuBar = QtGui.QMenuBar( self )
        
        self.m_fileOptionsMenu = QtGui.QMenu( "File" )
        self.m_fileOptionsMenu.setTearOffEnabled( True )
        self.m_fileOptionsMenu.setTitle( "File" )
        
        self.m_addReferenceActions = QtGui.QAction( "Create reference", self )
        self.m_fileOptionsMenu.addAction( self.m_addReferenceActions )
        self.m_fileOptionsMenu.addSeparator()
        self.m_removeReferenceActions = QtGui.QAction( "Remove reference", self )
        self.m_fileOptionsMenu.addAction( self.m_removeReferenceActions )
        self.m_importActions = QtGui.QAction( "Import reference", self )
        self.m_fileOptionsMenu.addAction( self.m_importActions )
        self.m_fileOptionsMenu.addSeparator()
        self.m_saveReferenceStateActions = QtGui.QAction( "Save reference tree", self )
        self.m_fileOptionsMenu.addAction( self.m_saveReferenceStateActions )
        self.m_loadReferenceStateActions = QtGui.QAction( "Load reference tree", self )
        self.m_fileOptionsMenu.addAction( self.m_loadReferenceStateActions )
        self.m_fileOptionsMenu.addSeparator()
        self.m_exportSelectedStateActions = QtGui.QAction( "Export selected references", self )
        self.m_fileOptionsMenu.addAction( self.m_exportSelectedStateActions )
        
        self.mainMenuBar.addMenu( self.m_fileOptionsMenu )
        
        self.m_referenceOptionsMenu = QtGui.QMenu( "Reference" )
        self.m_referenceOptionsMenu.setTearOffEnabled( True )
        self.m_referenceOptionsMenu.setTitle( "Reference" )
        
        
        self.m_reloadReferenceActions = QtGui.QAction( "Reload reference", self )
        self.m_referenceOptionsMenu.addAction( self.m_reloadReferenceActions )
        self.m_unloadReferenceActions = QtGui.QAction( "Unload reference", self )
        self.m_referenceOptionsMenu.addAction( self.m_unloadReferenceActions )
        self.m_referenceOptionsMenu.addSeparator()
        self.m_duplicateReferenceActions = QtGui.QAction( "Duplicate reference", self )
        self.m_referenceOptionsMenu.addAction( self.m_duplicateReferenceActions )
        self.m_replaceReferenceActions = QtGui.QAction( "Replace reference", self )
        self.m_referenceOptionsMenu.addAction( self.m_replaceReferenceActions )
        self.m_lockReferenceActions = QtGui.QAction( "Lock reference", self )
        self.m_referenceOptionsMenu.addAction( self.m_lockReferenceActions )
        self.m_referenceOptionsMenu.addSeparator()
        self.m_selectFileContentsActions = QtGui.QAction( "Select file contents", self )
        self.m_referenceOptionsMenu.addAction( self.m_selectFileContentsActions )
        
        self.mainMenuBar.addMenu( self.m_referenceOptionsMenu )
        
        self.m_proxyOptionsMenu = QtGui.QMenu( "Proxy" )
        self.m_proxyOptionsMenu.setTearOffEnabled( True )
        self.m_proxyOptionsMenu.setTitle( "Proxy" )
        self.m_addProxyActions = QtGui.QAction( "Add proxy to reference", self )
        self.m_proxyOptionsMenu.addAction( self.m_addProxyActions )
        self.m_proxyOptionsMenu.addSeparator()
        self.m_switchToOriginalActions = QtGui.QAction( "Switch references to original", self )
        self.m_proxyOptionsMenu.addAction( self.m_switchToOriginalActions )
        self.m_switchToProxyActions = QtGui.QAction( "Switch references to proxy", self )
        self.m_proxyOptionsMenu.addAction( self.m_switchToProxyActions )
        self.m_proxyOptionsMenu.addSeparator()
        self.m_switchToNextProxyActions = QtGui.QAction( "Switch references to next proxy", self )
        self.m_proxyOptionsMenu.addAction( self.m_switchToNextProxyActions )
        self.m_proxyOptionsMenu.addSeparator()
        self.m_loadAsAllProxyActions = QtGui.QAction( "Load reference container as original", self )
        self.m_proxyOptionsMenu.addAction( self.m_loadAsAllProxyActions )
        self.m_loadAsAllOriginalActions = QtGui.QAction( "Load reference container as proxy", self )
        self.m_proxyOptionsMenu.addAction( self.m_loadAsAllOriginalActions )
        
        self.mainMenuBar.addMenu( self.m_proxyOptionsMenu )
        
        self.m_selectionOptionsMenu = QtGui.QMenu( "Selection" )
        self.m_selectionOptionsMenu.setTearOffEnabled( True )
        self.m_selectionOptionsMenu.setTitle( "Selection" )
        
        self.m_selectFromOutLinerAction = QtGui.QAction( "Select references from outliner", self )
        self.m_selectionOptionsMenu.addAction( self.m_selectFromOutLinerAction )
        self.m_selectFromViewAction = QtGui.QAction( "Select references from viewport", self )
        self.m_selectionOptionsMenu.addAction( self.m_selectFromViewAction )
        self.m_selectFromViewWithAnimationAction = QtGui.QAction( "Select references from viewport with animation", self )
        self.m_selectionOptionsMenu.addAction( self.m_selectFromViewWithAnimationAction )
        self.m_selectionOptionsMenu.addSeparator()
        self.m_invertSelectionAction = QtGui.QAction( "Invert references selection", self )
        self.m_selectionOptionsMenu.addAction( self.m_invertSelectionAction )
        
        self.mainMenuBar.addMenu( self.m_selectionOptionsMenu )
        self.m_viewOptionsMenu = QtGui.QMenu( "View" )
        self.m_viewOptionsMenu.setTearOffEnabled( True )
        self.m_viewOptionsMenu.setTitle( "View" )
        
        self.m_viewAllAction = QtGui.QAction( "Show all", self )
        self.m_viewOptionsMenu.addAction( self.m_viewAllAction )
        self.m_viewOptionsMenu.addSeparator()
        self.m_viewOnlyLoadedAction = QtGui.QAction( "View only loaded references", self )
        self.m_viewOptionsMenu.addAction( self.m_viewOnlyLoadedAction )
        self.m_viewOnlyUnloadedAction = QtGui.QAction( "View only unloaded references", self )
        self.m_viewOptionsMenu.addAction( self.m_viewOnlyUnloadedAction )
        self.m_viewOptionsMenu.addSeparator()
        self.m_viewOnlySelectedAction = QtGui.QAction( "View only selected reference", self )
        self.m_viewOptionsMenu.addAction( self.m_viewOnlySelectedAction )
        self.m_viewOnlySelOutlinerAction = QtGui.QAction( "View reference only selected from outliner", self )
        self.m_viewOptionsMenu.addAction( self.m_viewOnlySelOutlinerAction )
        self.m_viewOptionsMenu.addSeparator()
        self.m_refreshViewAction = QtGui.QAction( "Refresh view", self )
        self.m_viewOptionsMenu.addAction( self.m_refreshViewAction )
        
        self.mainMenuBar.addMenu( self.m_viewOptionsMenu )
        self.m_helpOptionsMenu = QtGui.QMenu( "Help" )
        self.m_helpOptionsMenu.setTearOffEnabled( True )
        self.m_helpOptionsMenu.setTitle( "Help" )
        
        self.m_viewInfoAction = QtGui.QAction( "Information", self )
        self.m_helpOptionsMenu.addAction( self.m_viewInfoAction )
        
        self.mainMenuBar.addMenu( self.m_helpOptionsMenu )
        self.m_fileOptionsLayout.addWidget( self.mainMenuBar, 0, 0 )
        
        self.mainsplitter = QtGui.QSplitter()
        self.mainsplitter.setOrientation( QtCore.Qt.Vertical )
        self.mainlayout.addWidget( self.mainsplitter )
        
        self.m_actionGroupBox = QtGui.QGroupBox( "" )
        self.m_actionLayout = QtGui.QGridLayout()
        self.m_actionLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionGroupBox.setLayout( self.m_actionLayout )
        self.mainsplitter.addWidget( self.m_actionGroupBox )
        
        self.m_loadButton = QtGui.QPushButton( "Load reference" )
        self.m_actionLayout.addWidget( self.m_loadButton, 0, 0 )
        
        self.m_selectFromOutlinerButton = QtGui.QPushButton( "Select from outliner" )
        self.m_actionLayout.addWidget( self.m_selectFromOutlinerButton, 0, 1 )
        
        self.m_selectReferenceContentsButton = QtGui.QPushButton( "Select reference contents" )
        self.m_actionLayout.addWidget( self.m_selectReferenceContentsButton, 0, 2 )
        
        self.m_otherSplitter = QtGui.QSplitter()
        self.m_otherSplitter.setOrientation( QtCore.Qt.Vertical )
        self.m_referenceSettingsSplitter = QtGui.QSplitter()
        self.mainsplitter.addWidget( self.m_otherSplitter )
        
        self.m_referenceListGroupBox = QtGui.QGroupBox( "" )
        self.m_referenceListLayout = QtGui.QVBoxLayout()
        self.m_referenceListLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_referenceListGroupBox.setLayout( self.m_referenceListLayout )
        self.m_referenceSettingsSplitter.addWidget( self.m_referenceListGroupBox )
        
        #Reference list view.
        self.m_referenceFilterWidget = QtGui.QWidget()
        self.m_referenceFilterLayout = QtGui.QGridLayout()
        self.m_referenceFilterLayout.setContentsMargins( 0,0,0,0 )
        self.m_referenceFilterWidget.setLayout( self.m_referenceFilterLayout )
        self.m_referenceListLayout.addWidget( self.m_referenceFilterWidget )
        self.m_referenceListTree = QtGui.QTreeView()
        self.referenceDelegate = listDelegate()
        self.m_referenceListTree.setItemDelegate( self.referenceDelegate )
        self.m_referenceListTree.setAlternatingRowColors( True )
        self.m_referenceListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_referenceListTree.setIndentation( 0 )
        self.m_referenceListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_referenceListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_referenceListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_referenceListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_referenceListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_referenceListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_referenceListModelProxy = QtGui.QSortFilterProxyModel()
        self.m_referenceListListModel = QtGui.QStandardItemModel()
        self.m_referenceListModelProxy.setSourceModel( self.m_referenceListListModel )
        self.m_referenceListTree.setModel( self.m_referenceListModelProxy )
        self.m_referenceListTree.setHeaderHidden( True )
        self.m_referenceListLayout.addWidget( self.m_referenceListTree )
        self.m_actionReferenceWidget = QtGui.QWidget()
        self.m_actionReferenceLayout = QtGui.QGridLayout()
        self.m_actionReferenceLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_actionReferenceWidget.setLayout( self.m_actionReferenceLayout )
        self.m_referenceListLayout.addWidget( self.m_actionReferenceWidget )

        self.m_findReferenceTextField = QtGui.QLineEdit( "" )
        self.m_findReferenceTextField.setToolTip( "Regular expression field." )
        self.m_referenceFilterLayout.addWidget( self.m_findReferenceTextField, 0, 0 )
        self.m_findReferenceButton = QtGui.QPushButton( "Filter" )
        self.m_findReferenceButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 70, 70, 70 ); }")
        self.m_findReferenceButton.setToolTip( "Filter reference by user specified regular expression." )
        self.m_referenceFilterLayout.addWidget( self.m_findReferenceButton, 0, 1 )
        self.m_refreshCurrentReferencesButton = QtGui.QPushButton( "Refresh" )
        self.m_refreshCurrentReferencesButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 70, 70, 70 ); }")
        self.m_refreshCurrentReferencesButton.setToolTip( "Refresh reference list." )
        self.m_referenceFilterLayout.addWidget( self.m_refreshCurrentReferencesButton, 0, 2 )
        
        self.m_preloadGroupBox = QtGui.QGroupBox( "" )
        self.m_preloadLayout = QtGui.QVBoxLayout()
        self.m_preloadLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_preloadGroupBox.setLayout( self.m_preloadLayout )
        self.m_referenceSettingsSplitter.addWidget( self.m_preloadGroupBox )
        self.m_preloadManagerWidget = PreLoadManager()
        self.m_preloadLayout.addWidget( self.m_preloadManagerWidget )
        
        self.m_otherSplitter.addWidget( self.m_referenceSettingsSplitter )
        
        self.m_editsGroupBox = QtGui.QGroupBox( "" )
        self.m_editsLayout = QtGui.QVBoxLayout()
        self.m_editsLayout.setContentsMargins( 0, 0, 0, 0 )
        self.m_editsGroupBox.setLayout( self.m_editsLayout )
        self.m_otherSplitter.addWidget( self.m_editsGroupBox )
        self.m_referenceEditsWidget = ReferenceEditsEditor()
        self.m_editsLayout.addWidget( self.m_referenceEditsWidget )

        self.setWindowTitle( "Reference editor" )
        
    def updateTreeFromScene( self ):
        pass
    
    def updateTreeFromFile( self ):
        pass
    
class PreLoadManager( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( PreLoadManager, self ).__init__( parent )
        self.m_referenceNodes = []
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setContentsMargins( 0,0,0,0 )
        self.setLayout( self.mainlayout )
        self.m_splitter = QtGui.QSplitter()
        self.mainlayout.addWidget( self.m_splitter )
        self.m_editsListGroupBox = QtGui.QWidget()
        self.m_editsListLayout = QtGui.QVBoxLayout()
        self.m_editsListLayout.setContentsMargins( 0,0,0,0 )
        self.m_editsListGroupBox.setLayout( self.m_editsListLayout )
        self.m_splitter.addWidget( self.m_editsListGroupBox )
        self.m_filterWidget = QtGui.QWidget()
        self.m_filterLayout = QtGui.QGridLayout()
        self.m_filterLayout.setContentsMargins( 0,0,0,0 )
        self.m_filterWidget.setLayout( self.m_filterLayout )
        self.m_editsListLayout.addWidget( self.m_filterWidget )
        
        self.m_preloadWidget = QtGui.QWidget()
        self.m_preloadLayout = QtGui.QGridLayout()
        self.m_preloadLayout.setContentsMargins( 0,0,0,0 )
        self.m_preloadWidget.setLayout( self.m_preloadLayout )
        self.m_editsListLayout.addWidget( self.m_preloadWidget )
        
        self.preloadMenuBar = QtGui.QMenuBar( self.m_preloadWidget )
        self.m_preloadPresetsMenu = QtGui.QMenu( "Preload settings" )
        self.m_preloadPresetsMenu.setTearOffEnabled( True )
        self.m_preloadPresetsMenu.setTitle( "Preload settings" )
        
        self.m_editPresetAction = QtGui.QAction( "Edit current reference tree", self )
        self.m_preloadPresetsMenu.addAction( self.m_editPresetAction )
        self.m_preloadPresetsMenu.addSeparator()
        self.m_customPresetAction = QtGui.QAction( "Load reference tree", self )
        self.m_preloadPresetsMenu.addAction( self.m_customPresetAction )
        self.m_saveCustomPresetAction = QtGui.QAction( "Save reference tree", self )
        self.m_preloadPresetsMenu.addAction( self.m_saveCustomPresetAction )
        self.m_preloadPresetsMenu.addSeparator()
        self.m_presetListMenu = QtGui.QMenu( "Available reference tree" )
        self.m_presetListMenu.setTearOffEnabled( True )
        self.m_preloadPresetsMenu.addMenu( self.m_presetListMenu )
        self.m_preloadPresetsMenu.addSeparator()
        self.m_fastLoadAction = QtGui.QAction( "Ignore already loaded", self )
        self.m_fastLoadAction.setCheckable( True )
        self.m_preloadPresetsMenu.addAction( self.m_fastLoadAction )
        
        
        self.preloadMenuBar.addMenu( self.m_preloadPresetsMenu )
        self.m_preloadLayout.addWidget( self.preloadMenuBar, 0, 0 )
        
        self.m_loadButton = QtGui.QPushButton( "Load" )
        self.m_loadButton.setMaximumWidth( 45 )
        self.m_preloadLayout.addWidget( self.m_loadButton, 0, 1 )
        
        self.m_selectionListTree = QtGui.QTreeView()
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListModelProxy = QtGui.QSortFilterProxyModel()
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListModelProxy.setSourceModel( self.m_selectionListModel )
        self.m_selectionListTree.setModel( self.m_selectionListModelProxy )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_editsListLayout.addWidget( self.m_selectionListTree )
        self.m_actionEditsWidget = QtGui.QWidget()
        self.setWindowTitle( "Reference edits editor" )
        
    def setReferences( self, referenceNodes ):
        self.m_referenceNodes = referenceNodes
        self.ml_removeAllContent()
        for i in range( 0, len( self.m_referenceNodes )):
            if cmds.objExists( self.m_referenceNodes[i] ) and cmds.nodeType( self.m_referenceNodes[i] ) == "reference" or cmds.referenceQuery( self.m_referenceNodes[i], isNodeReferenced=True ):
                self.ml_addContent( self.m_referenceNodes[i] )
    
    def ml_addContent( self, reference ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_edits = ml_reference.listReferenceEdits( reference )
        m_referenceFile = cmds.referenceQuery( reference, filename=True ) 
        for i in range( 0, len( m_edits )):
            #[ m_reference, m_content[c], m_levels[l][-1], m_levels[l][0], m_edits[e].split( " " )[0], m_edits[e] ]
            m_item = QtGui.QStandardItem( m_edits[i][-1] )
            m_item.setData( "", QtCore.Qt.UserRole + 1 )
            m_item.setData( m_edits[i][4], QtCore.Qt.UserRole + 2 )
            m_item.setData( m_edits[i][1].split( "|" )[-1], QtCore.Qt.UserRole + 3 )
            m_item.setData( "", QtCore.Qt.UserRole + 4 )
            m_item.setData( m_edits[i][2], QtCore.Qt.UserRole + 5 )
            m_item.setData( m_edits[i][1], QtCore.Qt.UserRole + 6 )
            m_item.setData( m_edits[i][0], QtCore.Qt.UserRole + 7 )
            m_item.setData( m_referenceFile, QtCore.Qt.UserRole + 8 )
            m_item.setData( m_edits[i][-1], QtCore.Qt.UserRole + 9 )
            m_list.appendRow( m_item )
    
    def ml_getSelected( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            m_temp = m_indexes[i].data().toString()
            m_temp = str( m_temp )
            if m_temp not in m_result:
                m_result.append( m_temp )
        return m_result
    
    def ml_refresh( self ):
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeEdits( self ):
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        m_strings = {}
        for i in range( 0, len( m_indexes )):
            m_keys = m_strings.keys()
            m_string = m_indexes[i].data( QtCore.Qt.UserRole + 9 ).toString()
            rfn = m_indexes[i].data( QtCore.Qt.UserRole + 7 ).toString()
            if rfn not in m_keys:
                m_strings.update( { rfn:[ m_string ] } )
            else:
                m_array = m_strings[rfn]
                m_array.append( m_string )
                m_strings.update( { rfn:m_array } )
        m_keys = m_strings.keys()
        for i in range( 0, len( m_keys )):
            m_array = m_strings[ m_keys[i] ]
            print "\nreference: %s\nremove: %s" % ( m_keys[i], m_array )
            ml_reference.removeEdits( m_keys[i], m_array )
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            self.m_selectionListModel.removeRow( m_selected[i].row() )
       
    def ml_findReferenceEdits( self ):
        self.m_selectionListModelProxy.setFilterRegExp( self.m_findEditsTextField.text())
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
    
class ReferenceEditsEditor( QtGui.QDialog ):
    
    def __init__( self, parent=getMayaWindow()):
        super( ReferenceEditsEditor, self ).__init__( parent )
        self.m_referenceNodes = []
        self.mainlayout = QtGui.QVBoxLayout()
        self.mainlayout.setContentsMargins( 0,0,0,0 )
        self.setLayout( self.mainlayout )
        self.m_splitter = QtGui.QSplitter()
        self.mainlayout.addWidget( self.m_splitter )
        self.m_editsListGroupBox = QtGui.QWidget()
        self.m_editsListLayout = QtGui.QVBoxLayout()
        self.m_editsListLayout.setContentsMargins( 0,0,0,0 )
        self.m_editsListGroupBox.setLayout( self.m_editsListLayout )
        self.m_splitter.addWidget( self.m_editsListGroupBox )
        self.m_filterWidget = QtGui.QWidget()
        self.m_filterLayout = QtGui.QGridLayout()
        self.m_filterLayout.setContentsMargins( 0,0,0,0 )
        self.m_filterWidget.setLayout( self.m_filterLayout )
        self.m_editsListLayout.addWidget( self.m_filterWidget )
        self.m_findEditsTextField = QtGui.QLineEdit( "" )
        self.m_findEditsTextField.setToolTip( "Regular expression field." )
        self.m_filterLayout.addWidget( self.m_findEditsTextField, 0, 0 )
        self.m_findEditsButton = QtGui.QPushButton( "Filter" )
        self.m_findEditsButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 70, 70, 70 ); }")
        self.m_findEditsButton.setToolTip( "Filter edits by user specified regular expression." )
        self.m_findEditsButton.released.connect( self.ml_findReferenceEdits )
        self.m_filterLayout.addWidget( self.m_findEditsButton, 0, 1 )
        self.m_refreshCurrentEditsButton = QtGui.QPushButton( "Refresh" )
        self.m_refreshCurrentEditsButton.setStyleSheet("QPushButton{ font-weight: bold; font-size: 10px; color: rgb( 0, 0, 0 ); background-color: rgb( 70, 70, 70 ); }")
        self.m_refreshCurrentEditsButton.setToolTip( "Refresh edits." )
        self.m_refreshCurrentEditsButton.released.connect( self.ml_refresh )
        self.m_filterLayout.addWidget( self.m_refreshCurrentEditsButton, 0, 2 )
        self.m_selectionListTree = QtGui.QTreeView()
        self.m_selectionListTree.setContextMenuPolicy( QtCore.Qt.CustomContextMenu )
        self.m_selectionListTree.customContextMenuRequested.connect( self.ml_openContextMenu )
        self.delegate = listDelegate()
        self.m_selectionListTree.setItemDelegate(self.delegate)
        self.m_selectionListTree.setAlternatingRowColors( True )
        self.m_selectionListTree.setEditTriggers( QtGui.QAbstractItemView.NoEditTriggers )
        self.m_selectionListTree.setIndentation( 0 )
        self.m_selectionListTree.setSelectionMode( QtGui.QTreeView.ExtendedSelection )
        self.m_selectionListTree.setHorizontalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel )
        self.m_selectionListTree.setVerticalScrollMode( QtGui.QAbstractItemView.ScrollPerPixel ) 
        self.m_selectionListTree.setSelectionBehavior( QtGui.QTreeView.SelectRows )
        self.m_selectionListTree.setFocusPolicy( QtCore.Qt.NoFocus )
        self.m_selectionListTree.setSelectionBehavior( QtGui.QAbstractItemView.SelectRows )
        self.m_selectionListModelProxy = QtGui.QSortFilterProxyModel()
        self.m_selectionListModel = QtGui.QStandardItemModel()
        self.m_selectionListModelProxy.setSourceModel( self.m_selectionListModel )
        self.m_selectionListTree.setModel( self.m_selectionListModelProxy )
        self.m_selectionListTree.setHeaderHidden( True )
        self.m_editsListLayout.addWidget( self.m_selectionListTree )
        self.m_actionEditsWidget = QtGui.QWidget()
        self.setWindowTitle( "Reference edits editor" )
        
    def setReferences( self, referenceNodes ):
        self.m_referenceNodes = referenceNodes
        self.ml_removeAllContent()
        for i in range( 0, len( self.m_referenceNodes )):
            if cmds.objExists( self.m_referenceNodes[i] ) and cmds.nodeType( self.m_referenceNodes[i] ) == "reference" or cmds.referenceQuery( self.m_referenceNodes[i], isNodeReferenced=True ):
                self.ml_addContent( self.m_referenceNodes[i] )
    
    def ml_addContent( self, reference ):
        m_list = self.m_selectionListModel.invisibleRootItem()
        m_edits = ml_reference.listReferenceEdits( reference )
        m_referenceFile = cmds.referenceQuery( reference, filename=True ) 
        for i in range( 0, len( m_edits )):
            #[ m_reference, m_content[c], m_levels[l][-1], m_levels[l][0], m_edits[e].split( " " )[0], m_edits[e] ]
            m_item = QtGui.QStandardItem( m_edits[i][-1] )
            m_item.setData( "", QtCore.Qt.UserRole + 1 )
            m_item.setData( m_edits[i][4], QtCore.Qt.UserRole + 2 )
            m_item.setData( m_edits[i][1].split( "|" )[-1], QtCore.Qt.UserRole + 3 )
            m_item.setData( "", QtCore.Qt.UserRole + 4 )
            m_item.setData( m_edits[i][2], QtCore.Qt.UserRole + 5 )
            m_item.setData( m_edits[i][1], QtCore.Qt.UserRole + 6 )
            m_item.setData( m_edits[i][0], QtCore.Qt.UserRole + 7 )
            m_item.setData( m_referenceFile, QtCore.Qt.UserRole + 8 )
            m_item.setData( m_edits[i][-1], QtCore.Qt.UserRole + 9 )
            m_list.appendRow( m_item )
    
    def ml_getSelected( self ):
        m_result = []
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( 0, len( m_indexes )):
            m_temp = m_indexes[i].data().toString()
            m_temp = str( m_temp )
            if m_temp not in m_result:
                m_result.append( m_temp )
        return m_result
    
    def ml_refresh( self ):
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeEdits( self ):
        m_indexes = self.m_selectionListTree.selectionModel().selectedIndexes()
        m_strings = {}
        for i in range( 0, len( m_indexes )):
            m_keys = m_strings.keys()
            m_string = m_indexes[i].data( QtCore.Qt.UserRole + 9 ).toString()
            rfn = m_indexes[i].data( QtCore.Qt.UserRole + 7 ).toString()
            if rfn not in m_keys:
                m_strings.update( { rfn:[ m_string ] } )
            else:
                m_array = m_strings[rfn]
                m_array.append( m_string )
                m_strings.update( { rfn:m_array } )
        m_keys = m_strings.keys()
        for i in range( 0, len( m_keys )):
            m_array = m_strings[ m_keys[i] ]
            print "\nreference: %s\nremove: %s" % ( m_keys[i], m_array )
            ml_reference.removeEdits( m_keys[i], m_array )
        if self.m_referenceNodes:
            self.setReferences( self.m_referenceNodes )
    
    def ml_removeContent( self ):
        m_selected = self.m_selectionListTree.selectionModel().selectedIndexes()
        for i in range( len( m_selected )-1, -1, -1):
            self.m_selectionListModel.removeRow( m_selected[i].row() )
       
    def ml_findReferenceEdits( self ):
        self.m_selectionListModelProxy.setFilterRegExp( self.m_findEditsTextField.text())
            
    def ml_removeAllContent( self ):
        self.m_selectionListModel.removeRows( 0, self.m_selectionListModel.rowCount())
        
    def ml_openContextMenu( self, position ):
        self.m_menu = QtGui.QMenu()
        m_removeAction = QtGui.QAction( "Remove selected edits", self )
        m_removeAllAction = QtGui.QAction( "Remove all edits from current scene", self )
        m_refreshAction = QtGui.QAction( "Refresh edits", self )
        m_exportAction = QtGui.QAction( "Export selected edits", self )
        m_exportAllAction = QtGui.QAction( "Export all edits", self )
        m_importAction = QtGui.QAction( "Import edits", self )
        self.m_menu.addAction( m_refreshAction )
        self.m_menu.addSeparator()
        self.m_menu.addAction( m_removeAction )
        self.m_menu.addAction( m_removeAllAction )
        self.m_menu.addSeparator()
        self.m_menu.addAction( m_exportAction )
        self.m_menu.addAction( m_exportAllAction )
        self.m_menu.addSeparator()
        self.m_menu.addAction( m_importAction )
        self.m_menu.exec_( self.m_selectionListTree.viewport().mapToGlobal( position ))
    
class confirmLoop( QtGui.QDialog ):
    def __init__(self, parent=None):
        super(confirmLoop, self).__init__(parent)
        
    def load( self, label="", text="" ):
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins( 2,2,2,2 )        
        self.setWindowTitle( label )
        self.label=QtGui.QLabel( text )
        self.HLayout = QtGui.QHBoxLayout()
        self.executeButton = QtGui.QPushButton( "Yes" )
        self.executeButton.released.connect( self.executeSlot )
        self.continueButton = QtGui.QPushButton( "No" )
        self.continueButton.released.connect( self.continueSlot )  
        self.breakButton = QtGui.QPushButton( "Cancel" )
        self.breakButton.released.connect( self.breakSlot )
        self.HLayout.addWidget( self.executeButton )
        self.HLayout.addWidget( self.continueButton )
        self.HLayout.addWidget( self.breakButton )
        self.mainLayout.addWidget(self.label)
        self.mainLayout.addLayout(self.HLayout)
        self.setLayout(self.mainLayout)
        
    def executeSlot( self ):
        self.done(1)
        
    def continueSlot( self ):
        self.done(2)

    def breakSlot( self ):
        self.done(3)

class listDelegate( QtGui.QItemDelegate ):
    
    def __init__( self, parent=None ):
        super(listDelegate, self).__init__( parent )
        self.mult = 1
                            
    def createEditor( self, parent, option, index ):
        editor = QtGui.QSpinBox( parent )
        editor.setMinimum( 0 )
        editor.setMaximum( 100 )
        return editor
    
    def setEditorData( self, spinBox, index ):
        value = index.model().data( index, QtCore.Qt.EditRole )
        spinBox.setValue(value)
        
    def setModelData( self, spinBox, model, index ):
        spinBox.interpretText()
        value = spinBox.value()
        model.setData( index, value, QtCore.Qt.EditRole )
        
    def updateEditorGeometry( self, editor, option, index ):
        editor.setGeometry( option.rect )
        
    def sizeHint( self, option, index ):
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize( 11 )
        myFontMetrics = QtGui.QFontMetrics( myFont )
        mySize = myFontMetrics.boundingRect( 0,0, 260, 0,( QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft ), index.data( QtCore.Qt.DisplayRole ).toString() )     
        return QtCore.QSize( mySize.width(), mySize.height() + 40 )
    
    def paint( self, painter, option, index ):
        painter.save()
        painter.setRenderHint( QtGui.QPainter.Antialiasing )
        newMetr = QtGui.QFontMetrics( painter.font() )
        heit = newMetr.height() + 2   
        gradient = QtGui.QLinearGradient( option.rect.x() + option.rect.width() / 2, option.rect.y(), option.rect.x() + option.rect.width() / 2, option.rect.y() + option.rect.height() )
        gradient.setColorAt( 0.01, option.palette.base().color() )
        gradient.setColorAt( 0.02, option.palette.window().color() )
        gradient.setColorAt( 0.98,option.palette.window().color() )
        gradient.setColorAt( 0.99, option.palette.base().color() )
        brush = QtGui.QBrush( gradient )
        painter.fillRect( option.rect,brush )
        if sys.platform == "win32":
            painter.setCompositionMode( QtGui.QPainter.CompositionMode_Multiply )
            gradient2 = QtGui.QLinearGradient( option.rect.x(), option.rect.y(), option.rect.width(), option.rect.height() )
            gradient2.setColorAt( 0, QtGui.QColor(255,255,255))
            gradient2.setColorAt( 1, QtGui.QColor(200,200,200))
            brush2 = QtGui.QBrush( gradient2 )
            painter.fillRect( option.rect,brush2 )
            painter.setCompositionMode(QtGui.QPainter.CompositionMode_Overlay)
            gradient3 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient3.setColorAt(1,QtGui.QColor(0,0,0,100))
            gradient3.setColorAt(0,QtGui.QColor(255,255,255,100))
            brush3 = QtGui.QBrush(gradient3)
            painter.fillRect(option.rect.x()+2,option.rect.y()+2,option.rect.width()/2,heit,brush3)
            gradient4 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
            gradient4.setColorAt(0,QtGui.QColor(0,0,0,100))
            gradient4.setColorAt(1,QtGui.QColor(255,255,255,100))
            brush4 = QtGui.QBrush(gradient4)
            painter.fillRect(option.rect.x()+option.rect.width()/2,option.rect.y()+option.rect.height()-heit,option.rect.width()/2,heit,brush4)
        gradient5 = QtGui.QLinearGradient(option.rect.x(), option.rect.y(), option.rect.x()+option.rect.width(), option.rect.y()+option.rect.height())
        gradient5.setColorAt(1,QtGui.QColor(100,100,100,155))
        gradient5.setColorAt(0,QtGui.QColor(255,255,255,155))
        brush5 = QtGui.QBrush(gradient5)
        painter.fillRect(option.rect.x()+2,option.rect.y()+heit,option.rect.width(),1,brush5)
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        textNickname = index.data(QtCore.Qt.UserRole+3).toString()
        painter.drawText( option.rect.x()+4,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textNickname)
        textSize = index.data(QtCore.Qt.UserRole+5).toString()
        one_widthSize = painter.fontMetrics().width(textSize)
        painter.drawText( option.rect.x()+option.rect.width()-one_widthSize-2,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textSize)
        textDateTyme = index.data(QtCore.Qt.UserRole+2).toString()
        one_width = painter.fontMetrics().width(textDateTyme)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-2,option.rect.y()+2,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textDateTyme)
        textPath = index.data(QtCore.Qt.UserRole+4).toString()
        textPathElide = painter.fontMetrics().elidedText(textPath, QtCore.Qt.ElideLeft, option.rect.width()-5)
        one_width = painter.fontMetrics().width(textPathElide)
        painter.drawText( option.rect.x()+option.rect.width()-one_width-6-one_widthSize,option.rect.y()+option.rect.height()-heit,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWrapAnywhere|QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), textPathElide)
        text = index.data(QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+heit+5,option.rect.width(),option.rect.height()-heit, (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)   
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore()    
        
s = ReferenceEditor()
s.show()
s.load()        