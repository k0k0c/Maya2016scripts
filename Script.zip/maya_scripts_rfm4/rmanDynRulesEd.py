import maya.cmds as cmds
import maya.mel as mel
import rfm.rlf as rlf
import rfm.rlf2maya as rlf2maya
import re

def launchSlim():
	try:
		run = mel.eval('rman slim isconnected') != 1 and cmds.confirmDialog(title='Please launch slim', message='Slim is not running, please run slim.', button=['Apply', 'Close'], defaultButton='Apply', cancelButton='Close', dismissString='Close') or 'Close'
		run == 'Apply' and mel.eval('rman slim start')
		return True
	except:
		print '\n\t\tRenderMan plugin is not loaded.'
		
def slimCommand(command=''):
	launchSlim()
	try:
		result = command != '' and ('[' in str(command) and [mel.eval('rman slim command "'+command[i]+'"') for i in range(0, len(command))] or mel.eval('rman slim command "'+command+'"'))
		if result: return result
	except:
		print '\n\t\tErrors expected while executing script.', command, '\n'

def listAllShaderAttributesByType(types=['string', 'float', 'color', 'vector']):
	launchSlim()
	shaders = slimCommand('getShaders')
	attributes = []
	if shaders:
		shaders = shaders.split('|')[0:-1]
		for i in range(0, len(shaders)):
			attributesList = slimCommand(command=shaders[i]+' GetProperties -access input -class ::Slim::Parameter')
			if attributesList:
				attributesList = attributesList.split(' ')
				for n in range(0, len(attributesList)):
					attributeProperties = slimCommand(command=attributesList[n]+' GetName')+' ('+slimCommand(command=attributesList[n]+' GetType')+')'
					if attributeProperties not in attributes:
						attributes.append(attributeProperties)
	return attributes

def refreshShadersSettings(attribute='', mode=''):
	trash = []
	def createShadersOptions(attributeInfo, color=''):
		color = color == 0.25 and 0.2
		shaderID =''.join( attributeInfo.split('|')[0].split('"'))
		shaderName = ''.join(attributeInfo.split('|')[1].split('"'))
		attrName = ''.join(attributeInfo.split('|')[2].split('"'))
		attrLongName = ''.join(attributeInfo.split('|')[3].split('"'))
		attrRange = ''.join(attributeInfo.split('|')[5].split('"'))
		attrValue = ''.join(attributeInfo.split('|')[4].split('"'))
		cmds.text(attrLongName+'TEXT', label='\t'+shaderName+' ('+attrLongName+')\t', parent='shadersListAttr', bgc=[color, color, color+0.05])
		createShaderControlByType(attributeName=attrLongName, attributeType=attributeType, attributeRange=attrRange, attributeValue=attrValue, colorMenu=color)
		cmds.button(attrLongName+'ATTRcreate', label='Create rule', parent='shadersListAttr', bgc=[color, color+0.1, color])
		cmds.button(attrLongName+'ATTRdelete', label='Delete rule', parent='shadersListAttr', bgc=[color+0.1, color, color])
		cmds.button(shaderID+'ATTRSelect', label='Select attached', parent='shadersListAttr', bgc=[color+0.1, color+0.1, color], c='rmanDynRulesEd.selectAttachedByID(shaderID="'+shaderID+'")')
		cmds.textField(shaderID+'ATTRCheckRule', text='no rule created', enable=False, parent='shadersListAttr', bgc=[color, color+0.1, color])
		[cmds.separator(style='in', parent='shadersListAttr') for n in range(0, 6)]
	def getSearchValue():
		result = cmds.textField('attrSearchCtrl', query=True, text=True)
		return result
	launchSlim()
	if cmds.textField('attrSearchCtrl', exists=True) is False:
		cmds.text(label='Value:', parent='attrSearchField', font='tinyBoldLabelFont', align='left')
		cmds.separator(style='in', p="attrSearchField")
		cmds.textField('attrSearchCtrl', p="attrSearchField")
	attributeType = attribute.split('_')[-1]
	allAttributes = cmds.getAttr('slimCachePartition.'+attribute)
	allAttributes = allAttributes.split(';')
	cmds.rowColumnLayout('shadersListAttr', query=True, exists=True) and cmds.deleteUI('shadersListAttr', layout=True)
	cmds.rowColumnLayout('shadersListAttr', numberOfColumns=6, rowSpacing=[5, 5], columnWidth=[50, 50], parent='slimEditorScrollLayout')
	for i in range(0, (len(allAttributes)-1)):
		if mode == '':
			createShadersOptions(allAttributes[i], color=0.25)
		elif mode == "value":
			searchValue = ''.join((getSearchValue()).split(' '))
			attributeValue = allAttributes[i].split('|')[4]
			shaderName = allAttributes[i].split('|')[1]
			attributeValue = ''.join((str(attributeValue)).split(' '))
			if re.findall(searchValue, str(attributeValue)) or re.findall(searchValue, str(shaderName)):
				createShadersOptions(allAttributes[i], color=0.25)
		elif mode == "object":
			idChecker = allAttributes[i].split('|')[0]
			objects = cmds.ls(sl=True, dag=True, type=['mesh', 'nurbsCurve'])
			attributesID = [cmds.getAttr(objects[n]+'.rman__torattr___slimSurface') for n in range(0, len(objects)) if cmds.attributeQuery('rman__torattr___slimSurface', n=objects[n], exists=True)]
			if idChecker in attributesID and idChecker not in trash:
				trash.append(idChecker)
				createShadersOptions(allAttributes[i], color=0.25)

def createShaderControlByType(attributeName='', attributeType='', attributeRange='', attributeValue='', colorMenu=''):
	types = ['string', 'float', 'color', 'vector', 'normal']
	attributeValue = attributeValue and attributeValue or ''
	attributeRange = attributeRange and attributeRange or ''
	if attributeType == 'string':
		cmds.textField((attributeName+'VALUE'), parent='shadersListAttr', text=attributeValue, w=240, bgc=[colorMenu, colorMenu+0.05, colorMenu])
	elif attributeType == 'float':
		rangedValue = re.compile('[A-z,0-9.\-)(." ]+')
		attributeRange = attributeRange.split(' ')
		attributeRangeTEMP = [attributeRange[i] for i in range(0, len(attributeRange)) if rangedValue.findall(attributeRange[i])]
		attributeRangeTEMP = ''.join((' '.join(attributeRangeTEMP)).split('\n'))
		options = re.findall('[0-9.]+', attributeRangeTEMP)
		if not options:
			cmds.floatSliderGrp((attributeName+'VALUE'), parent='shadersListAttr', v=float(attributeValue), w=240, field=True, fmn=-1000000, fmx=1000000, bgc=[colorMenu, colorMenu+0.05, colorMenu])
		else:
			options = [options[i] for i in range(0, len(options)) if options[i]]
			selected = [options[i] for i in range(0, len(options)) if re.findall(attributeValue, options[i])]
			optionsMenuAdv(name=(attributeName+'VALUE'), label='', parent='shadersListAttr', options=options)
			cmds.optionMenu((attributeName+'VALUE'), edit=True, v=''.join((selected[0]).split('"')), ann=''.join(attributeRange))
	elif attributeType == 'color':
		value = attributeValue.split(' ')
		cmds.colorSliderGrp((attributeName+'VALUE'), parent='shadersListAttr', w=240, bgc=[colorMenu, colorMenu+0.05, colorMenu])
		cmds.colorSliderGrp((attributeName+'VALUE'), edit=True, rgb=[float(value[0]), float(value[1]), float(value[2])])
	elif attributeType == 'vector' or attributeType == 'normal':
		value = attributeValue.split(' ')
		cmds.floatFieldGrp((attributeName+'VALUE'), numberOfFields=3, v1=float(value[0]), v2=float(value[1]), v3=float(value[2]), w=240, bgc=[colorMenu, colorMenu+0.05, colorMenu], parent='shadersListAttr')    
	else:
		cmds.text((attributeName+'VALUE'), align='center', label='\t'+attributeValue+'\t', parent='shadersListAttr', w=240, bgc=[colorMenu, colorMenu+0.05, colorMenu])

def optionsMenuAdv(name='', label='', parent='', options=''):
	mel.eval('optionMenu -label "' + label + '" -w 240 -parent "' + parent + '" "' + name + '";')
	options and [mel.eval('menuItem -label "' + str(''.join(options[i].split('"'))) + '" -parent "' + name + '";') for i in range(0, len(options))]
	return name

def getValueFromConrolAdv(name=''):
	pass
	
def formLayoutAdv(name='' ,content='', parent='', height=50, offset=0):
	position=[(100/(len(content)))+offset]
	[position.append(position[-1]+position[0]-offset) for i in range(0,len(content)-1)]
	cmds.formLayout(name, exists=True) and cmds.deleteUI(name, layout=True)
	cmds.formLayout(name, numberOfDivisions=100, parent=parent, height=height)
	for i in range(0,len(content)):
		content[i] = content[i].split('|')[-1]
		if content[i] in cmds.lsUI(controls=True):
			cmds.control(content[i], edit=True, parent=name)
		elif content[i] in cmds.lsUI(controlLayouts=True):
			cmds.layout(content[i], edit=True, parent=name)
	script = ' -attachForm "'+content[0]+'" "top" 0 -attachForm "'+content[0]+'" "left" 0 -attachForm "'+content[0]+'" "bottom" 0 -attachPosition "'+content[0]+'" "right" (4/2) '+str(position[0])
	if len(content)>2:
		for i in range(1,(len(content)-1)):
			script = script+(' -attachForm "'+content[i]+'" "top" 0 -attachPosition "'+content[i]+'" "left" (4/2) '+str(position[i-1])+' -attachForm "'+content[i]+'" "bottom" 0 -attachPosition "'+content[i]+'" "right" (4/2) '+str(position[i]))
	if len(content)>1:
	    script = script+(' -attachForm "'+content[-1]+'" "top" 0 -attachPosition "'+content[-1]+'" "left" (4/2) '+str(position[-2])+' -attachForm "'+content[-1]+'" "bottom" 0 -attachForm "'+content[-1]+'" "right" 0' )
	mel.eval("formLayout -edit "+script+" "+name)

def selectAttachedByID(shaderID=''):
	objects = cmds.ls(type=['mesh', 'nurbsCurve'])
	result = []
	cmds.select(cl=True)
	[result.append(objects[i]) for i in range(0, len(objects)) if cmds.attributeQuery('rman__torattr___slimSurface', n=objects[i], exists=True) and cmds.getAttr(objects[i]+'.rman__torattr___slimSurface') == shaderID]
	result and cmds.select(result)	
	return result

def createShaderListNode():
	rangedValue = re.compile('[A-z)(."]+[\s]+[0-9.]+')
	slimCommand(command='source //SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm4/getShaders.tcl')
	types = ['string', 'float', 'color', 'vector', 'normal']
	if cmds.objExists('slimCachePartition') is True:
		cmds.delete('slimCachePartition')
	cmds.createNode('partition', n='slimCachePartition')
	shaders = slimCommand('getShaders')
	shaders = shaders and shaders.split('|')[0:-1]
	for i in range(0, len(shaders)):
		shaderName = slimCommand(command=shaders[i]+' GetName')
		shaderID = slimCommand(command=shaders[i]+' GetID')
		attributes = slimCommand(command=shaders[i]+' GetProperties -access input -class ::Slim::Parameter')
		attributes = attributes and attributes.split(' ')
		for n in range(0, len(attributes)):
			attrType = slimCommand(command=attributes[n]+' GetType')
			if attrType in types:
				attrName = slimCommand(command=attributes[n]+' GetName')
				attrName = attrName and attrName or ''
				attrRange = slimCommand(command=attributes[n]+' GetRange')
				attrRange = attrRange and attrRange or ''
				attrValue = slimCommand(command=attributes[n]+' GetValue')
				attrValue = attrValue and attrValue or ''
				ranged = rangedValue.findall(attrRange) and '_ranged' or ''
				attrRange = ranged == '_ranged' and attrRange or ''
				attributeFullName = attrName+'_'+attrType
				newValue = shaderID+'|'+shaderName+'|'+attrName+'|'+attributes[n]+'|'+attrValue+'|'+attrRange+';'
				if cmds.attributeQuery(attributeFullName, n='slimCachePartition', exists=True) is False:
					cmds.addAttr('slimCachePartition', longName=attributeFullName, hidden=False, dataType='string')
				oldValue = cmds.getAttr('slimCachePartition.'+attributeFullName)
				oldValue = oldValue and oldValue or ''					
				if newValue not in oldValue:
				    cmds.setAttr('slimCachePartition.'+attributeFullName, (oldValue+newValue), type='string')
			else:
				continue

def compileShaders():
	mel.eval('rman slim command ("slim ReloadExtensions cmd")')
	mel.eval('rman slim command ("slim BuildShaders")')
	
def openEditor():
	#setup slim
	launchSlim()
	createShaderListNode()
	#main interface
	cmds.window("slimEditorWindow", exists=True) and cmds.deleteUI("slimEditorWindow", window=True)
	cmds.window("slimEditorWindow", menuBar=True, title="Slim editor",height=250,width=250)
	cmds.columnLayout("slimEditorColumnLayout", h=60, adjustableColumn=True, parent="slimEditorWindow")
	cmds.frameLayout("slimEditorLayout", parent="slimEditorWindow", borderStyle="etchedOut", labelVisible=False)
	cmds.separator(style='in', parent='slimEditorLayout')
	cmds.frameLayout('slimEditorAttributeListLayout', parent='slimEditorWindow', borderStyle="etchedOut", labelVisible=False)
	cmds.frameLayout('slimEditorAttributeValueLayout', parent='slimEditorWindow', borderStyle="etchedOut", labelVisible=False)
	formLayoutAdv(name='slimEditorAttributeEditorLayout' ,content=['slimEditorAttributeListLayout', 'slimEditorAttributeValueLayout'], parent='slimEditorColumnLayout')
	cmds.frameLayout("attrSearchField", parent="slimEditorAttributeValueLayout", labelVisible=False)
	cmds.columnLayout('slimEditorAttributeValueLayoutButton', parent='slimEditorAttributeValueLayout', adjustableColumn=True)
	cmds.button('searchButton', label='Search by value', parent='slimEditorAttributeValueLayoutButton', h=16.6, bgc=[0.56, 0.61, 0.63], ann='List all shaders by value in target attribute.', c='rmanDynRulesEd.refreshShadersSettings(attribute=cmds.optionMenu("attributeListMenu", query=True, value=True), mode="value")')
	cmds.button('listAllBySelectedButton', label='Search by object', parent='slimEditorAttributeValueLayoutButton', h=16.6, bgc=[0.56, 0.61, 0.63], ann='List all shaders with target attribute connected to selected object.', c='rmanDynRulesEd.refreshShadersSettings(attribute=cmds.optionMenu("attributeListMenu", query=True, value=True), mode="object")')
	cmds.button('listAllButton', label='Clear', parent='slimEditorAttributeValueLayoutButton', h=16.6, bgc=[0.65, 0.6, 0.55], ann='List all shaders by attribute.', c='rmanDynRulesEd.refreshShadersSettings(attribute=cmds.optionMenu("attributeListMenu", query=True, value=True))')
	formLayoutAdv(name='slimEditorAttributeEditorLayoutValues' ,content=['attrSearchField', 'slimEditorAttributeValueLayoutButton'], parent='slimEditorAttributeValueLayout', offset=15)
	cmds.text(label='Attribute:', parent='slimEditorAttributeListLayout', font='tinyBoldLabelFont', align='left')
	cmds.separator(style='in', parent='slimEditorAttributeListLayout')
	attibuteList = cmds.listAttr('slimCachePartition', userDefined=True)
	attibuteList = [attibuteList[i] for i in range(0, len(attibuteList))]
	optionsMenuAdv(name='attributeListMenu', label='', parent='slimEditorAttributeListLayout', options=attibuteList)
	cmds.separator(style='in', parent='slimEditorLayout')
	cmds.text(label='Shaders list:', parent='slimEditorLayout', font='tinyBoldLabelFont')
	cmds.separator(style='in', parent='slimEditorLayout')
	cmds.scrollLayout("slimEditorScrollLayoutBase", parent="slimEditorLayout", childResizable=True)
	cmds.frameLayout("slimEditorScrollLayout", parent="slimEditorScrollLayoutBase", borderStyle="etchedOut", labelVisible=False)
	cmds.separator(style='in', parent='slimEditorLayout')
	cmds.button('recompileAllShadersButton', label='Compile', p='slimEditorLayout', c='rmanDynRulesEd.compileShaders()', h=32, bgc=[0.24, 0.27, 0.2])
	#refresh settings
	cmds.optionMenu('attributeListMenu', edit=True, cc='rmanDynRulesEd.refreshShadersSettings(attribute=cmds.optionMenu("attributeListMenu", query=True, value=True))', ann='List all attributes from shaders used in scene.')
	cmds.showWindow("slimEditorWindow")
	refreshShadersSettings(attribute=cmds.optionMenu("attributeListMenu", query=True, value=True))
