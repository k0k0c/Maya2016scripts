import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os

#CREATE INTERFACE
def CUTool_interface():
	#create main window
	if cmds.window("CUTool_window_00", exists=True):
		cmds.deleteUI("CUTool_window_00", window=True)
	cmds.window("CUTool_window_00", menuBar=True, title="SCENE SETUP",height=250,width=250)
	cmds.menu("CUTool_menu_00", label="File", parent="CUTool_window_00")
	cmds.menuItem(divider=True, parent="CUTool_menu_00") 
	cmds.menuItem(label="Refresh", command='CUTool_interface()', parent="CUTool_menu_00") 
	cmds.menuItem(divider=True, parent="CUTool_menu_00") 
	cmds.menuItem(label="Settings", parent="CUTool_menu_00") 
	cmds.menuItem(label="Help", parent="CUTool_menu_00")
	#create and print text info about scene
	cmds.columnLayout("CUTool_info_layout00",adjustableColumn=True,parent="CUTool_window_00")
	cmds.text("CUTool_info_text00",label="INFO",backgroundColor=[0.18,0.18,0.18],parent="CUTool_info_layout00")
	cmds.text("CUTool_info_text01", font="boldLabelFont", label="Text",backgroundColor=[0.15,0.15,0.15],parent="CUTool_info_layout00")
	cmds.frameLayout("CUTool_frame_layout00_base_00", parent="CUTool_window_00",borderStyle="etchedOut",labelVisible=False)
	cmds.scrollLayout("CUTool_scroll_layout00", parent="CUTool_frame_layout00_base_00",childResizable=True)
	CUTool_updateInfo()
	#create tabs
	id_tabs,id_frame,tabs_names=CUTool_tabsLayout("CUTool_tabsLayout_00","CUTool_scroll_layout00",['Animatic setup','Shablon setup','Light setup'])	   
	#frames setup for animatik
	cmds.frameLayout("CUTool_Animatic_setup_00",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 1) Clean setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic setup')]))
	cmds.frameLayout("CUTool_Animatic_setup_01",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 2) Animation setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic setup')]))
	cmds.frameLayout("CUTool_Animatic_setup_02",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 3) Cameras setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic setup')]))
	cmds.frameLayout("CUTool_Animatic_setup_03",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 4) Template setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic setup')]))	  
	#frames setup for shablon
	cmds.frameLayout("CUTool_Shablon_setup_00",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 1) Camera setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon setup')]))
	cmds.frameLayout("CUTool_Shablon_setup_01",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 2) Template setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon setup')]))
	cmds.frameLayout("CUTool_Shablon_setup_04",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 3) Characters setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon setup')]))
	cmds.frameLayout("CUTool_Shablon_setup_02",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 4) Animation setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon setup')]))
	cmds.frameLayout("CUTool_Shablon_setup_03",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 5) Reference setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon setup')]))
	#Directory buttons
	cmds.intFieldGrp("CUTool_Shablon_setup_animation_field",extraLabel=":  Start/End animation range",numberOfFields=2,value1=(cmds.playbackOptions(query=True,animationStartTime=True)),value2=(cmds.playbackOptions(query=True,animationEndTime=True)),parent="CUTool_Shablon_setup_02")	
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_02",['CUTool_Shablon_setup_animation_button_UpdateFrames'],"CUTool_Shablon_setup_02",26)
	CUTool_changeDirectory_button("CUTool_changeCameraDirectory", "CUTool_Shablon_setup_00",CUTool_findCams_File(),1,1)
	cmds.text("CUTool_UsedCameraInfo",align="left", label=("Used camera: "+(CUTool_findUsedCamera())), parent="CUTool_Shablon_setup_00") 
	CUTool_changeDirectory_button("CUTool_changeTemplateDirectory", "CUTool_Shablon_setup_01",CUTool_findTemplate_File(),1,1)
	cmds.text("CUTool_UsedReferenceInfo",align="left", label=("Template statement: "+(CUTool_checkTmplateIsLoaded())), parent="CUTool_Shablon_setup_01")
	CUTool_changeDirectory_button("CUTool_changeAnimationileDirectory", "CUTool_Shablon_setup_02",CUTool_findAnimation_File(),0,1) 
	CUTool_changeDirectory_button("CUTool_changeAnimationileDirectoryForSave", "CUTool_Animatic_setup_01",CUTool_findAnimation_File(),0,0)
	CUTool_changeDirectory_button("CUTool_changeCameraExportDirectory", "CUTool_Animatic_setup_02",CUTool_PathToCamera_File(),1,0)
	CUTool_changeDirectory_button("CUTool_changeTemplateExportDirectory", "CUTool_Animatic_setup_03",CUTool_PathToTemplate_File(),1,0)
	#layouts setup	
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_00",['CUTool_Shablon_setup_cameras_button_Import','CUTool_Shablon_setup_cameras_button_Clean','CUTool_Shablon_setup_cameras_button_Setup'],"CUTool_Shablon_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_01",['CUTool_Shablon_setup_template_button_Reference',],"CUTool_Shablon_setup_01",26)
	cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list", height=200, allowMultiSelection=True, parent="CUTool_Shablon_setup_04")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_09",['CUTool_Shablon_setup_animation_button_referenceChar'],"CUTool_Shablon_setup_04",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_04",['CUTool_Shablon_setup_animation_button_UpdateFramesFromFiles','CUTool_Shablon_setup_animation_button_GetCharsFromFile','CUTool_Shablon_setup_animation_button_Import'],"CUTool_Shablon_setup_02",26)
	cmds.textScrollList("CUTool_Shablon_setup_references_list", height=200, allowMultiSelection=True, parent="CUTool_Shablon_setup_03")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_05",['CUTool_Shablon_setup_reference_button_Add','CUTool_Shablon_setup_reference_button_Remove','CUTool_Shablon_setup_reference_button_Clear','CUTool_Shablon_setup_reference_button_Select','CUTool_Shablon_setup_reference_button_All'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_06",['CUTool_Shablon_setup_reference_button_FromView','CUTool_Shablon_setup_reference_button_FromViewWithAnim'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_07",['CUTool_Shablon_setup_reference_button_UnloadList','CUTool_Shablon_setup_reference_button_UnloadSelectedInList','CUTool_Shablon_setup_reference_button_UnloadNotInList'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_08",['CUTool_Shablon_setup_reference_button_AutoUnload','CUTool_Shablon_setup_reference_button_SwitchProxy'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_00",['CUTool_Animatic_setup_animation_button_Save','CUTool_Animatik_setup_button_delete_animation'],"CUTool_Animatic_setup_01",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_01",['CUTool_Animatic_setup_camera_button_Export'],"CUTool_Animatic_setup_02",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_02",['CUTool_Animatic_setup_tmplate_button_Export'],"CUTool_Animatic_setup_03",26)
	#buttons setup
	cmds.button("CUTool_Shablon_setup_animation_button_Import", edit=True, label="Get coordinates", command="CUTool_loadFromFileCoordinates()")
	cmds.button("CUTool_Shablon_setup_animation_button_UpdateFramesFromFiles", edit=True, label="Get ranges", command="CUTool_setup_ranges_from_file()")
	cmds.button("CUTool_Shablon_setup_cameras_button_Setup", edit=True, command="CUTool_setupUsedCamera()")
	cmds.button("CUTool_Shablon_setup_template_button_Reference", edit=True, command="CUTool_importTmplateFile()")	
	cmds.button("CUTool_Shablon_setup_cameras_button_Clean", edit=True, command="CUTool_deleteAllUnusedCams()")	  
	cmds.button("CUTool_Shablon_setup_cameras_button_Import", edit=True, command="CUTool_importCamerasFile()") 
	cmds.button("CUTool_Shablon_setup_reference_button_Add", edit=True, label="Add to list", command="CUTool_add_reference_to_list()")	
	cmds.button("CUTool_Shablon_setup_reference_button_Remove", edit=True, label="Remove from list", command="CUTool_remove_reference_from_list()")
	cmds.button("CUTool_Shablon_setup_reference_button_Clear", edit=True, label="Clear list", command="CUTool_clear_all_reference_from_list()")
	cmds.button("CUTool_Shablon_setup_reference_button_Select", edit=True, label="Select from list", command='CUTool_select_reference_from_list("Selected")')
	cmds.button("CUTool_Shablon_setup_reference_button_All", edit=True, label="Select all from list", command='CUTool_select_reference_from_list("All")')
	cmds.button("CUTool_Shablon_setup_reference_button_FromView", edit=True, label="Add from viewport", command="CUTool_Get_references_from_viewport_with_animation(0)")
	cmds.button("CUTool_Shablon_setup_reference_button_FromViewWithAnim", edit=True, label="Add from viewport with animation", command="CUTool_Get_references_from_viewport_with_animation(1)")
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadNotInList", edit=True, label="Unload not in list", command="CUTool_referenceUnloadNotInList()")
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadList", edit=True, label="Unload alll from list", command='CUTool_referenceUnloadSelection("All")')
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadSelectedInList", edit=True, label="Unload selected from list", command='CUTool_referenceUnloadSelection("Selected")')
	cmds.button("CUTool_Shablon_setup_reference_button_AutoUnload", edit=True, label="Automatic setup references", command='CUTool_select_reference_from_list("All")')
	cmds.button("CUTool_Shablon_setup_animation_button_UpdateFrames", edit=True, label="Edit range", command='CUTool_select_update_animation_frames()')
	cmds.button("CUTool_Shablon_setup_animation_button_referenceChar", edit=True, label="Reference selected character", command='CUTool_referenceCharacterFromList()')
	cmds.button("CUTool_Shablon_setup_animation_button_GetCharsFromFile", edit=True, label="Get characters")
	cmds.button("CUTool_Animatic_setup_animation_button_Save", edit=True, label="Save animation settings", command='CUTool_SaveAnimationCoordinates()')
	cmds.button("CUTool_Animatic_setup_camera_button_Export", edit=True, label="Export cameras", command='CUTool_ExportCamerasFromAnimatik(cmds.textField("CUTool_changeCameraExportDirectory_textField", query=True, text=True))')
	cmds.button("CUTool_Animatik_setup_button_delete_animation", edit=True, label="Delete animation from scene", command='CUTool_deleteAnimationFromScene()')
	cmds.button("CUTool_Animatic_setup_tmplate_button_Export", edit=True, label="Export all referenced props as tmplate", command='CUTool_ExportTemplateFromAnimatik(cmds.textField("CUTool_changeTemplateExportDirectory_textField", query=True, text=True))')
	cmds.button("CUTool_Shablon_setup_reference_button_SwitchProxy", edit=True, label="Switch proxy", command='CUTool_ProxySwitch()')
	#show window
	CUTool_getCharactersInlist()
	cmds.showWindow("CUTool_window_00")
	if cmds.dockControl("CUTool_dockControl_layout_00",exists=True):
	    cmds.deleteUI("CUTool_dockControl_layout_00", control=True)
	cmds.dockControl("CUTool_dockControl_layout_00",label="SCENE SETUP",area='left', content="CUTool_window_00", allowedArea=['right', 'left'], width=500)
	
#CREATE FAST FORM LAYOUTS 	PROCEDURE	
def CUTool_formLayout_buttons(form_name,form_buttons,form_parent,form_buttons_height):
	"""
	#EXAMPLE: formLayout_buttons("Layout name",['Button name_Label name', ...],"Name of the parent layout", "Button height")
	#RESULT: button name equal to 'Button name_Label name'
	"""
	buttons_position=[(100/(len(form_buttons)))]  
	if len(form_buttons)>1:
		if cmds.formLayout(form_name, exists=True):
			cmds.deleteUI(form_name, layout=True)	  
		cmds.formLayout(form_name, numberOfDivisions=100, parent=form_parent)
		for i in range(0,len(form_buttons)-1):
			buttons_position.append(buttons_position[-1]+(100/(len(form_buttons))))	  
		for i in range(0,len(form_buttons)):
			if cmds.button(form_buttons[i], exists=True):
				cmds.deleteUI(form_buttons[i], control=True)
			cmds.button(form_buttons[i], label=(re.findall("[A-Z, a-z, 0-9]+$",form_buttons[i])[-1]), height=form_buttons_height)	  
		for i in range(0,len(form_buttons)):
			cmds.button(form_buttons[i],edit=True,parent=form_name) 
		formSettings=((' -attachForm ')+('"')+(form_buttons[0])+('"')+(' "top" 0 ')+('-attachForm ')+('"')+(form_buttons[0])+('"')+(' "left" 0 ')+('-attachForm ')+('"')+(form_buttons[0])+('"')+(' "bottom" 0 ')+('-attachPosition ')+('"')+(form_buttons[0])+('"')+(' "right" (')+('($buttons_space/2)')+(') ')+str(buttons_position[0]))	 
		if len(form_buttons)>2:
			for i in range(1,(len(form_buttons)-1)):  
				formSettings=formSettings+((' -attachForm ')+('"')+(form_buttons[i])+('"')+(' "top" 0 ')+('-attachPosition ')+('"')+(form_buttons[i])+('"')+(' "left" (')+('($buttons_space/2)')+(') ')+str(buttons_position[i-1])+(' -attachForm ')+('"')+(form_buttons[i])+('"')+(' "bottom" 0 ')+('-attachPosition ')+('"')+form_buttons[i]+('"')+(' "right" (')+('($buttons_space/2)')+(') ')+str(buttons_position[i]))
		formSettings=formSettings+(' -attachForm '+'"'+form_buttons[-1]+'"'+' "top" 0 '+'-attachPosition '+'"'+form_buttons[-1]+'"'+' "left" ('+'($buttons_space/2)'+') '+str(buttons_position[-2])+' -attachForm '+'"'+form_buttons[-1]+'"'+' "bottom" 0 '+'-attachForm '+'"'+form_buttons[-1]+'"'+' "right" 0' ) 
		mel.eval("int $buttons_space=4;formLayout -edit "+formSettings+" "+form_name)
	else:
		if cmds.button(form_buttons[0], exists=True):
				cmds.deleteUI(form_buttons[0], control=True)
		cmds.button(form_buttons[0], label=(re.findall("[A-Z, a-z, 0-9]+$",form_buttons[0])[-1]), height=form_buttons_height)
		cmds.button(form_buttons[0],edit=True,parent=form_parent)
		
#CREATE TABS FOR MENU PROCEDURE
def CUTool_tabsLayout(tabLayout_name,tabLayout_parent,tabs_names):
	"""
	#EXAMPLE: id_tabs,id_frame=CUTool_tabsLayout("TabLayout name","TabLayout parent","Tabs names")
	#RESULT: tab name equal to (id_frame[tabs_names.index('Tab name')])
	"""
	id_tabs=[]
	id_frame=[]
	if cmds.tabLayout(tabLayout_name, exists=True):
		cmds.deleteUI(tabLayout_name, layout=True)
	cmds.tabLayout(tabLayout_name, parent=tabLayout_parent)
	for i in range(0,len(tabs_names)):
		id_tabs.append(tabLayout_name+'_Tab_0'+str(i))
		id_frame.append(tabLayout_name+'_FrameLayout_0'+str(i))
		cmds.columnLayout(id_tabs[i],adjustableColumn=True,parent=(tabLayout_name))
		cmds.frameLayout(id_frame[i], labelVisible=False,backgroundColor=[0.2,0.2,0.2],borderStyle="etchedOut",parent=(id_tabs[i]))
		cmds.tabLayout(tabLayout_name, edit=True, tabLabel=(id_tabs[i], tabs_names[i]))
	return(id_tabs,id_frame,tabs_names)		
	
#CREATE TEXT FIELD AND CONNECTED TO FIELD BUTTON FOR DIRECTORY SETUP PROCEDURE
def CUTool_changeDirectory_button(button_name, parent_name,result_from_proc,mode,fileMode_int):
	"""
	#EXAMPLE: CUTool_changeDirectory_button("Button name for change directory", "Name of parent","Procedure with return result")
	#RESULT: Button name equal to "Button name for change directory", and textField name equal to "Button name for change directory"+"_textField"
	"""
	if cmds.rowLayout(str(button_name+"_rowLayout"), exists=True):
		cmds.deleteUI(str(button_name+"_rowLayout"), layout=True)
	cmds.rowLayout(str(button_name+"_rowLayout"), numberOfColumns=2,adjustableColumn=1,parent=parent_name)
	cmds.textField(str(button_name+"_textField"),text=result_from_proc,parent=(str(button_name+"_rowLayout")))
	command_for_button=('CUTool_changeDirectory('+'"'+str(button_name)+'"'+","+str(mode)+','+str(fileMode_int)+')')
	cmds.symbolButton(str(button_name+"_symbolButton"),image="navButtonBrowse.png",parent=str(button_name+"_rowLayout"), command=command_for_button)
	
#BUTTON PROCEDURE TO CHANGE DIRECTORY FOR BUTTON CONNECTED TEXT FIELD PROCEDURE
def CUTool_changeDirectory(button_name,mode,fileMode_int):
	Filefilter=["txt files (*.txt)", "Maya files(*.ma)"]
	result=cmds.fileDialog2(caption="Please select target",fileFilter=Filefilter[mode], startingDirectory=(cmds.textField((button_name+"_textField"),query=True,text=True)),fileMode=fileMode_int)
	if result:	
		cmds.textField((button_name+"_textField"),edit=True, text=str(result[0]))
	return result
	
#GET PATH TO CAMERAS FOLDER	
def CUTool_PathToCamera_File():
    var=(("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma"))	
    return (var) and var or "C:/"	

#GET PATH TO TEMPLATE FOLDER	
def CUTool_PathToTemplate_File():
    var=(("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))
    return (var) and var or "C:/"

#EXPORT CAMERAS FROM ANIMATIK TO NEW FILE
def CUTool_ExportCamerasFromAnimatik(path):
	cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)

#EXPORT TEMPLATE FROM ANIMATIK TO NEW FILE WITH ONLY REFERENCED OBJECTS
def CUTool_ExportTemplateFromAnimatik(path):
    var_01=cmds.ls(type='reference')
    if len(var_01)>0:
        for i in range(0,len(var_01)):
            if(re.findall('chars',(cmds.referenceQuery(var_01[i], filename=True)))):
                continue
            else:   
                temp=cmds.ls(cmds.referenceQuery(var_01[i], nodes=True), type='transform')         
                if len(temp)>0:
                    cmds.select(temp,add=True)
        cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)
	
#GET PATH TO CAMERAS FILE FOR CURRENT SCENE
def CUTool_findCams_File():
	if(CUTool_CheckFileExists() is True):
		temp=("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma")
		return(CUTool_checkTargetFileExists(temp)is True and ("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma")or"File not find")
	else:
		return("Scene not saved")
		
#GET PATH TO TEMPLATE FILE FOR CURRENT SCENE		
def CUTool_findTemplate_File():
	if(CUTool_CheckFileExists() is True):
		temp=(("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))
		return(CUTool_checkTargetFileExists(temp)is True and (("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))or"File not find")
	else:
		return("Scene not saved")
		
#GET PATH TO TXT FILE WITH ANIMATION SETTINGS OR FOLDER		
def CUTool_findAnimation_File():   
    if(CUTool_CheckFileExists() is True):
    	temp=(("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_anim.txt"))
    	return(CUTool_checkTargetFileExists(temp)is True and (("//SERVER-3D/Project/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_anim.txt"))or"File not find")
    else:
    	return("Scene not saved")
			
#GET NAME OF USED CAMERA IN CURRENT SCENE			
def CUTool_findUsedCamera():
    var_00=listTransformsCameras() 
    var_01=(re.findall(str(CUTool_GetInfoAboutScene('episode')+CUTool_GetInfoAboutScene('scene')),str((cmds.listCameras())))) and (re.findall(str(CUTool_GetInfoAboutScene('episode')+CUTool_GetInfoAboutScene('scene')),str((cmds.listCameras()))))[0] or ("Camera not find")
    var_02=[i for i, item in enumerate(var_00) if re.search(var_01, item)]
    return (var_02) and (var_00[var_02[0]]) or ('Camera not find')

#GET INFO ABOUT SCENE EXP 
def CUTool_GetInfoAboutScene(mode):
	if mode=='project':
		if len(re.findall('[A-Z,a-z,0-9]+',(cmds.file(query=True, location=True))))>2:
			return (str(re.findall('[A-Z,a-z,0-9]+',(cmds.file(query=True, location=True)))[3]))
		else: return("")	
	if mode=='episode':
		return(re.findall("ep[0-9]+",(cmds.file(query=True, location=True))) and (re.findall("ep[0-9]+",(cmds.file(query=True, location=True)))[0]) or "")
	if mode=='scene':
		if re.findall("]*sc[0-9]*_dop*",(cmds.file(query=True, location=True))):
			return(re.findall("]*sc[0-9]*_dop*",(cmds.file(query=True, location=True)))[0])
		elif re.findall("sc[0-9]+",(cmds.file(query=True, location=True))):
			return(re.findall("sc[0-9]+",(cmds.file(query=True, location=True)))[0])
		else:
			return("")
		
#GET PATH OF CURRENT SCNE IF SCENE SAVED		
def CUTool_GetFilePath():
	result=(cmds.file(query=True, location=True)).split("/")
	return(("/".join(result[0:-2]))+"/")
	
#CHECK CURRENT SCENE IS SAVED IN SCENE FOLDER	
def CUTool_CheckLocation():
	return((re.findall("scenes",(cmds.file(query=True, location=True)))) and True or False)
		
#CHECK CURRENT SCENE IS SAVED		
def CUTool_CheckFileExists():
	result=cmds.file(query=True, exists=True)
	return result 
	
#CHECK FILE EXISTS	
def CUTool_checkTargetFileExists(path):
	path=path.replace("/","\\")
	return((os.path.exists(path)) is True and True or False)
	
#CHECK TEMPLATE IS LOADED	
def CUTool_checkTmplateIsLoaded():
	array=cmds.ls(references=True)
	result=''
	for i in range(len(cmds.ls(references=True))):
		result=re.findall('[A-Z,a-z,0-9]*tmplate[A-Z,a-z,0-9]*',array[i])
		if(re.findall('[A-Z,a-z,0-9]*tmplate[A-Z,a-z,0-9]*',array[i])): 
			break 
	return(len(result)>0 and "is loaded" or "is not loaded") 
	
#GET REFERENCES LIST WITH CONTAINING SHAPES 	
def CUTool_getReferenceTransformsWithShapes():
	result=[]
	transforms_list=cmds.ls(transforms=True, readOnly=True, long=True)
	for i in range(0,len(transforms_list)):
		if(cmds.listRelatives(transforms_list[i],children=True,fullPath=True)):
			children_list=cmds.listRelatives(transforms_list[i],children=True,fullPath=True)
			for children_i in range(0,len(children_list)):
				if(cmds.ls(children_list[children_i],shapes=True)):
					result.append(transforms_list[i])
	return result
	
#GET CHARACTERS CONTAINING IN ROOT DIRECTORY //SERVER-3D/Project/UrfinJuse/assets/chars/ WITHOUT RENDER VERSION	
def CUTool_getCharactersInlist():
	characters=[]
	root='//SERVER-3D/Project/UrfinJuse/assets/'
	file_filter=['ma','mb']
	pattern_rem='render'
	file_dir=os.path.join(root,'chars/')
	file_contain=os.listdir(file_dir)
	for folder_i in range(0,len(file_contain)):
		if(re.findall('\.',file_contain[folder_i])):
			file_contain[folder_i]=None		 
	file_contain=[x for x in file_contain if x!=None]		   
	for folder_i in range(0,len(file_contain)):
		if os.path.exists(('/'.join((os.path.join(file_dir,(file_contain[folder_i]+'/'),'maya')).split('\\')))):
			file_contain_temp=os.listdir(('/'.join((os.path.join(file_dir,(file_contain[folder_i]+'/'),'maya')).split('\\'))))
			for file_i in range(len(file_contain_temp)):
				if((file_contain_temp[file_i][-2]+file_contain_temp[file_i][-1])) in file_filter and pattern_rem not in file_contain_temp[file_i]:
					characters.append((os.path.join(os.path.join(file_dir,file_contain[folder_i]),'maya',file_contain_temp[file_i])))
		else: continue		   
	for i in range(len(characters)):
		characters[i]='/'.join((characters[i]).split("\\"))
		cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list", edit=True, append=characters[i])	 
		
#SETUP RANGES FROM SETTINGS FIELD 
def CUTool_select_update_animation_frames():
	cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True)  
	cmds.playbackOptions(minTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True),animationStartTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True))				 
	cmds.playbackOptions(maxTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value2=True),animationEndTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value2=True))
	 
#EXPORT CAMERAS  
def CUTool_exportCamerasFromAnimatik(path):
    cmds.select(cmds.ls(type='sequencer'))
    cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)
	
#SETUP CAMERA FOR ANIMATION  
def CUTool_setupUsedCamera():
	cmds.undoInfo(state=1)
	if(cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True): cmds.loadPlugin("RenderMan_for_Maya")
	cmds.pluginInfo("C:/Program Files/Pixar/RenderManStudio-4.0-maya2013/plug-ins/RenderMan_for_Maya.mll", edit=True, autoload=True)
	list_settings=['"defaultRenderGlobals.currentRenderer" -type "string" "renderMan"','"defaultResolution.width" 2048','"defaultResolution.height" 858','"defaultRenderGlobals.animation" 1','"defaultRenderGlobals.pff" 1','"defaultRenderGlobals.peie" 1','"defaultRenderGlobals.animationRange" 0','"defaultRenderGlobals.extensionPadding" 4','"defaultResolution.lockDeviceAspectRatio" 0','"defaultRenderGlobals.imageFormat" 3','"defaultResolution.deviceAspectRatio" 2.387','"defaultResolution.pixelAspect" 1','-l false "defaultRenderGlobals.startFrame"','"defaultRenderGlobals.startFrame" `playbackOptions -q -ast`','-l false "defaultRenderGlobals.endFrame"','"defaultRenderGlobals.endFrame" `playbackOptions -q -aet`']
	for i in range(0,(len(list_settings)-1)):
		mel.eval("setAttr "+list_settings[i])
	if(CUTool_findUsedCamera()!="Camera not find"): 
		cmds.setAttr((CUTool_findUsedCamera()+".renderable"),1)
		if(cmds.listRelatives(CUTool_findUsedCamera(),allParents=True)):
			cmds.parent(CUTool_findUsedCamera(), world=True)
		cmds.lookThru(CUTool_findUsedCamera())
		
#DELETE UNUSED CAMERAS IN CURRENT SCENE	
def CUTool_deleteAllUnusedCams(): 
	var_01=listTransformsCameras()
	var_02=[i for i, item in enumerate(var_01) if re.search(CUTool_findUsedCamera(), item)]
	if var_02:
		for i in range(0,len(var_02)):
			var_01.pop(var_02[i])
	cmds.delete(var_01)	
	
#IMPORT CAMERAS FOR CURRENT SCENE
def CUTool_importCamerasFile():
	path=cmds.textField("CUTool_changeCameraDirectory_textField", query=True, text=True)
	cmds.file(path, i=True, type="mayaAscii", renameAll=True,mergeNamespacesOnClash=False,renamingPrefix=(CUTool_GetInfoAboutScene('episode')+"_cams"),preserveReferences=True)
	
#REFERENCE TEMPLATE FOR CURENNT SCENE
def CUTool_importTmplateFile():
	path=cmds.textField("CUTool_changeTemplateDirectory_textField", query=True, text=True)
	cmds.file(path,reference=True,namespace=(CUTool_GetInfoAboutScene('episode')+"_tmplate"),referenceNode=(CUTool_GetInfoAboutScene('episode')+"_tmplateRN"))
	
#ADD SELECTED TO LIST OF REFENCES
def CUTool_add_reference_to_list():
    selected=cmds.ls(sl=True, readOnly=True)
    references=[]
    temp=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
    if temp is None:
        temp=['.'] 
    for i in range(0,len(selected)):
        references.append(cmds.referenceQuery(selected[i],filename=True))
    references=list(set(references))
    for i in range(0,len(references)): 
        if references[i] not in temp:
            cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, append=references[i])
		
#REMOVE SELECTED FROM LIST OF REFERENCES
def CUTool_remove_reference_from_list():
	selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, selectItem=True)
	for i in range(0,len(selected)):
		cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, removeItem=selected[i])
		
#REMOVE ALL REFERENCES FROM LIST OF REFERENCES		
def CUTool_clear_all_reference_from_list():
	selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	for i in range(0,len(selected)):
		cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, removeItem=selected[i]) 
		
#SELECT REFERENCE FROM LIST OF REFERENCES		   
def CUTool_select_reference_from_list(input):
	for_select=[]
	if input=='Selected':
		selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, selectItem=True)
	if input=='All':
		selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	for i in range(0,len(selected)):
		if selected[i]:
			for_select=for_select+(cmds.referenceQuery(selected[i],nodes=True, dagPath=True))
			
	cmds.select(for_select)		
#GET REFERENCES FROM VIEWPORT
def CUTool_Get_references_from_viewport_with_animation(input):
    CUTool_setupUsedCamera()
    references=[]
    temp=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
    if temp is None:
        temp=['.']
    if(input==1):
        cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
        cmds.select(clear=True) 
        for frame in range(int(cmds.playbackOptions(query=True,minTime=True)),int(cmds.playbackOptions(query=True,maxTime=True))+1):
            cmds.currentTime(frame)
            om.MGlobal.selectFromScreen(((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth())), (omUI.M3dView.active3dView()).portWidth()/30, ((omUI.M3dView.active3dView()).portWidth()-((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth()))), ((omUI.M3dView.active3dView()).portHeight())-((omUI.M3dView.active3dView()).portWidth()/30), om.MGlobal.kAddToList)
        transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
        cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
        cmds.select(clear=True)
    if(input==0):
        cmds.select(clear=True)		
        om.MGlobal.selectFromScreen(((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth())), (omUI.M3dView.active3dView()).portWidth()/30, ((omUI.M3dView.active3dView()).portWidth()-((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth()))), ((omUI.M3dView.active3dView()).portHeight())-((omUI.M3dView.active3dView()).portWidth()/30), om.MGlobal.kAddToList)
        transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
        cmds.select(clear=True)
    for i in range(0,len(transform_list)):
        references.append(cmds.referenceQuery(transform_list[i],filename=True))
    references=list(set(references))
    for i in range(0,len(references)):
        if references[i] not in temp:
            cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, append=references[i])
		
#REFERENCE CHARACTERS FROM LIST OF CHARACTERS		
def CUTool_referenceCharacterFromList():
	reference_path=cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list",query=True,selectItem=True)
	for i in range(0,len(reference_path)):
		cmds.file(reference_path[i],reference=True,mergeNamespacesOnClash=False)
		
#UNLOAD SELECTED REFERENCES IN LIST OF REFERENCES
def CUTool_referenceUnloadSelection(input):
    if(input=="Selected"):
        references_list=cmds.textScrollList("CUTool_Shablon_setup_references_list",query=True,selectItem=True)
    if(input=="All"):
        references_list=cmds.textScrollList("CUTool_Shablon_setup_references_list",query=True,allItems=True)
    for i in range(0,len(references_list)):
        if CUTool_checkReferenceExists(references_list[i]) is True:
            cmds.file(cmds.referenceQuery(references_list[i],filename=True),unloadReference=True)
		
#UNLOAD REFERENCES NOT IN LIST OF REFERENCES
def CUTool_referenceUnloadNotInList():
	reference_in_list=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	reference_used=[]		 
	references_all=CUTool_getReferenceTransformsWithShapes()
	for reference_i in range(0,len(references_all)):
		 reference_used.append(cmds.referenceQuery(references_all[reference_i],filename=True))
	reference_used=list(set(reference_used))
	reference_used=[x for x in reference_used if x not in reference_in_list]
	for reference_i in range(0,len(reference_used)):
	    if CUTool_checkReferenceExists(reference_used[reference_i]) is True:
    		cmds.file(cmds.referenceQuery(reference_used[reference_i],filename=True),unloadReference=True)
		
#GET ANIMATION RANGES FROM FILE FOR CURRENT SCENE
def CUTool_setup_ranges_from_file():
	if(CUTool_findUsedCamera())!="Camera not find":
		command_string=((open(cmds.textField("CUTool_changeAnimationileDirectory", query=True, text=True),"r")).read()).split("\n")
		for i in range(0,len(command_string)):
			if re.findall(CUTool_findUsedCamera(), command_string[i]):
				cmds.playbackOptions(minTime=((command_string[i+1]).split('= '))[1])
				cmds.playbackOptions(maxTime=((command_string[i+2]).split('= '))[1])
	else: 
		cmds.error("THIS SCENE IS NOT SHABLON")	
		
#PRINT INFO ABOUT SCENE
def CUTool_updateInfo():
	if(CUTool_CheckFileExists() is True)&(CUTool_CheckLocation() is True):
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\nFile name: "+(cmds.file(query=True, sceneName=True, shortName=True))+"\nFile location"+(cmds.file(query=True, location=True))+"\nEpisode: "+CUTool_GetInfoAboutScene('episode')+"\nScene number: "+CUTool_GetInfoAboutScene('scene')+"\n\nOK\n"),backgroundColor=[0.15,0.25,0.15])
	elif(CUTool_CheckFileExists() is True)&(CUTool_CheckLocation()is False):
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\nFile name: "+(cmds.file(query=True, sceneName=True, shortName=True))+"\nFile location"+(cmds.file(query=True, location=True))+"\nEpisode: "+CUTool_GetInfoAboutScene('episode')+"\nScene number: "+CUTool_GetInfoAboutScene('scene')+"\n\nINVALID LOCATION!!!\n"),backgroundColor=[0.25,0.25,0.15])
	else:
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\n\nSCENE NOT SAVED!!!\n"),backgroundColor=[0.3,0.15,0.15])	

#SAVE ANIMATION COORDINATES, RANGES, CHARACTERS
def CUTool_SaveAnimationCoordinates():
	#time range
	if(cmds.ls(type="shot")):
		shot_list=cmds.ls(type="shot")
		shot_for_save=""
		for shot_i in range(0,len(shot_list)):
			shot_for_save+="\nSHOTNAME_T= "+str(shot_list[shot_i])[0]
			shot_for_save+="\nCAMERA_T= "+str((cmds.listRelatives((cmds.shot(shot_list[shot_i],query=True,currentCamera=True)),parent=True))[0])
			shot_for_save+="\nSTART_T= "+str(cmds.shot(shot_list[shot_i],query=True,startTime=True))
			shot_for_save+="\nEND_T= "+str(cmds.shot(shot_list[shot_i],query=True,endTime=True)) 
	else:
		shot_for_save=""		
	#get animated objects
	anim_curves=(cmds.ls(type=("animCurveTU", "animCurveTA", "animCurveTL")))
	if(cmds.listConnections(anim_curves,type="camera")):
		anim_curves_cameras=(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTU"))+(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTA"))+(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTL"))
	else:
		anim_curves_cameras=""	  
	anim_objects=[]
	info_for_save="";
	for i in range(0,len(anim_curves)):
		if cmds.ls(anim_curves[i],readOnly=True)is not True:
			if anim_curves[i] not in anim_curves_cameras:
				if(cmds.listConnections(anim_curves[i], type="transform"))is not None: 
					anim_objects+=(cmds.listConnections(anim_curves[i], type="transform"))
	anim_objects=list(set(anim_objects))
	typeSetArray(anim_objects,"transform")
	#get info for save
	for i in range(0,len(anim_objects)):
		character_type=1
		if(cmds.referenceQuery(anim_objects[i], isNodeReferenced=True)):
			if(re.findall('props',(cmds.referenceQuery(anim_objects[i], filename=True)))):
				character_type=0
		anim_curves=getConnectionsByType(anim_objects[i],['animCurveTU','animCurveTA','animCurveTL'])
		info_for_save+=("\nObject_settings\nOBJECT_T "+str(anim_objects[i])+"\nCHARACTER_T "+str(character_type))
		for anim_i in range(0,len(anim_curves)):
			if cmds.nodeType((cmds.listConnections(anim_curves[anim_i],plugs=True)[0]).split('.')[0])=='transform':
				info_for_save+=("\nCurve\nCURVE_T "+str(anim_curves[anim_i])+"\nNODE_T "+str(cmds.nodeType(anim_curves[anim_i]))+"\nATTRIBUTE_T "+str(((cmds.listConnections(anim_curves[anim_i],plugs=True)[0]).split('.'))[1]))
				anim_objects_keys=cmds.keyframe(anim_curves[anim_i],query=True,timeChange=True)
				info_for_save+="\nKEYTYPE_T "
				if anim_objects_keys:
					for key_i in range(0,len(anim_objects_keys)):
						if cmds.keyframe(anim_curves[anim_i],query=True,time=(anim_objects_keys[key_i],anim_objects_keys[key_i]),breakdown=True):
							info_for_save+=("B"+" ")
						else:	 
							info_for_save+=("K"+" ")
					info_for_save+="\nKEYTIME_T "	
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(anim_objects_keys[key_i])+" ")
					info_for_save+="\nKEYVALUE_T "	
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(cmds.keyframe(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), valueChange=True)[0])+" ")
					info_for_save+="\nINTANGTYPE_T "	
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), inTangentType=True)[0])+" ")
					info_for_save+="\nOUTTANGTYPE_T "
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), outTangentType=True)[0])+" ")	
					info_for_save+="\nINTANGANGLE_T "
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), inAngle=True)[0])+" ")		
					info_for_save+="\nOUTTANGANGLE_T "
					for key_i in range(0,len(anim_objects_keys)):	
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), outAngle=True)[0])+" ")	
					info_for_save+="\n"	   
	file=open(((cmds.textField("CUTool_changeAnimationileDirectoryForSave_textField", query=True, text=True))),"w")	
	file.write(" Copyright (c) Melnitsa Studio.\n"+str(cmds.about(cd=True))+"\n This file contains information on animaton curves for Maya\n")
	file.write(shot_for_save)
	file.write("\nCoordinates\n")
	file.write(info_for_save)
	file.close()
	
#LOAD COORDINATES FROM FILE
def CUTool_loadFromFileCoordinates():
    current_time=(cmds.currentTime(query=True))
    if(os.path.isfile(cmds.textField("CUTool_changeAnimationileDirectory_textField", query=True, text=True))):
        command_string=(open(cmds.textField("CUTool_changeAnimationileDirectory_textField", query=True, text=True),"r").readlines())
        for line_i in range(0,len(command_string)):
            command_string[line_i]=command_string[line_i].strip("\n")
        command_string=((" ".join(command_string)).split("Coordinates")[1]).split("Object_settings")  
        for obj_i in range(1,len(command_string)):
            command_target=""+command_string[obj_i].split(" ")[(command_string[obj_i].split(" ")).index("OBJECT_T")+1]
            command_target_type=command_string[obj_i].split(" ")[(command_string[obj_i].split(" ")).index("CHARACTER_T")+1]
            if (int(command_target_type)==0): 
                command_target=(CUTool_GetInfoAboutScene('episode')+"_tmplate:"+command_target)
            command_buffer=command_string[obj_i].split(" Curve ")               
            if(cmds.objExists(command_target)):
                for crv_i in range(1,len(command_buffer)):
                    key_name=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("CURVE_T")+1:(command_buffer[crv_i].split(" ")).index("NODE_T")]
                    key_node=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("NODE_T")+1:(command_buffer[crv_i].split(" ")).index("ATTRIBUTE_T")]
                    key_attr=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("ATTRIBUTE_T")+1:(command_buffer[crv_i].split(" ")).index("KEYTYPE_T")]
                    key_attr_type=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("KEYTIME_T")-1]
                    key_attr_time=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYTIME_T")+1:(command_buffer[crv_i].split(" ")).index("KEYVALUE_T")-1]
                    key_attr_value=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYVALUE_T")+1:(command_buffer[crv_i].split(" ")).index("INTANGTYPE_T")-1]
                    key_attr_inType=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("INTANGTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("OUTTANGTYPE_T")-1]
                    key_attr_outType=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("OUTTANGTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("INTANGANGLE_T")-1]
                    key_attr_inAngle=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("INTANGANGLE_T")+1:(command_buffer[crv_i].split(" ")).index("OUTTANGANGLE_T")-1]
                    key_attr_outAngle=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("OUTTANGANGLE_T")+1:]
                    key_size=len(key_attr_value)
                    if(key_node,key_attr,key_name,key_attr_type,key_attr_time,key_attr_value,key_attr_inAngle,key_attr_outAngle,key_attr_inType,key_attr_outType,key_size):
                        key_node=cmds.createNode(key_node[0], name=key_name[0])
                        for key_i in range(key_size):
                            key_breakdown=(key_attr_type[key_i]=="B")
                            cmds.setKeyframe(key_node, time=key_attr_time[key_i], value=float(key_attr_value[key_i]), breakdown=key_breakdown)
                            cmds.keyTangent(key_node, inAngle=key_attr_inAngle[key_i], outAngle=key_attr_outAngle[key_i], inTangentType='flat', outTangentType='flat')  
                            cmds.keyTangent(key_node, inTangentType=key_attr_inType[key_i], outTangentType=key_attr_outType[key_i])
                        cmds.setKeyframe(key_node, breakdown=0, hierarchy=0, controlPoints=0, shape=0)
                        key_attr_change=cmds.keyframe(key_node, time=(current_time,current_time), query=True, valueChange=True) 
                        if mel.eval("attributeExists "+'"'+key_attr[0]+'" '+command_target):
                            cmds.setAttr((command_target+"."+key_attr[0]), key_attr_change[0])
                            cmds.delete(key_node)
                        else:
                            cmds.delete(key_node)
							
#GET LIST OF CHARACTERS FROM VIEWPORT WITH ANIMATION							
def getCharsFromCameraList():
	characters=[]
	selectionMask_cr(["Joint","Deformer","Dynamic","Rendering","Other","Marker"],"false")
	cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
	cmds.select(clear=True) 
	for frame in range(int(cmds.playbackOptions(query=True,minTime=True)),int(cmds.playbackOptions(query=True,maxTime=True))+1,100):
		cmds.currentTime(frame)
		om.MGlobal.selectFromScreen(((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth())), (omUI.M3dView.active3dView()).portWidth()/30, ((omUI.M3dView.active3dView()).portWidth()-((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth()))), ((omUI.M3dView.active3dView()).portHeight())-((omUI.M3dView.active3dView()).portWidth()/30), om.MGlobal.kAddToList)
	transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
	cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
	cmds.select(clear=True)
	for i in range(0,len(transform_list)):
		if  re.findall('chars',(cmds.referenceQuery(transform_list[i], filename=True))):
			characters.append(cmds.referenceQuery(transform_list[i],filename=True))
	characters=list(set(characters))
	return characters					

def CUTool_ProxySwitch():
	#Get object for proxy
    target_obj=cmds.ls(sl=True, readOnly=True)[0]
    target_path=(cmds.referenceQuery(target_obj,filename=True)).split('/')
    target_namespace=cmds.referenceQuery(target_obj,referenceNode=True)
    target_proxy=[(((target_path[-1]).split('.'))[0]+'_proxy.mb'),(((target_path[-1]).split('.'))[0]+'_proxy.ma')]
    proxy_check=[os.path.exists(('\\'.join(target_path[0:-1]))+'\\'+target_proxy[0]),os.path.exists(('\\'.join(target_path[0:-1]))+'\\'+target_proxy[1])]
    if True in proxy_check:
        proxy_i=proxy_check.index(True)
    else: proxy_i=-1
	#Create proxy if not exist
    if '_proxy' not in target_path[-1]:
        if True not in proxy_check:
            #Get bounding box max lenght
            bbox_min=cmds.getAttr(target_obj+'.boundingBoxMin')
            bbox_max=cmds.getAttr(target_obj+'.boundingBoxMax')
            x_Len=bbox_max[0][0]-bbox_min[0][0]
            y_Len=bbox_max[0][1]-bbox_min[0][1]
            z_Len=bbox_max[0][2]-bbox_min[0][2]
            if (x_Len>=y_Len, x_Len>=z_Len):
                bb_len=x_Len
            if (y_Len>=x_Len, y_Len>=z_Len):
                bb_len=y_Len
            if (z_Len>=x_Len, z_Len>=y_Len):
                bb_len=z_Len	
    		#Get coordinates for mesh
            bb_v=[-5.0184211730000001, 0.0, 5.0184211730000001, 5.0184211730000001, 0.0, 5.0184211730000001, -5.0184211730000001, 10.036842346, 5.0184211730000001, 5.0184211730000001, 10.036842346, 5.0184211730000001, -5.0184211730000001, 10.036842346, -5.0184211730000001, 5.0184211730000001, 10.036842346, -5.0184211730000001, -5.0184211730000001, 0.0, -5.0184211730000001, 5.0184211730000001, 0.0, -5.0184211730000001]
    		#Get coordinates for rig
            rig_v=[-0.268644, -0.00173434, -0.465283, -0.109172, -0.00173434, -0.465283, -0.0605789, 0.0138506, -0.442918, 0.060579, 0.0138506, -0.442918, 0.109172, -0.00173434, -0.465283, 0.268644, -0.00173434, -0.465283, 0.34838, -0.00173434, -0.327176, 0.353308, 0.0138506, -0.27391, 0.413887, 0.0138506, -0.168985, 0.457553, -0.00173434, -0.138084, 0.537288, -0.00173434, 2.27005e-005, 0.457552, -0.00173434, 0.138129, 0.413887, 0.0138506, 0.16903, 0.353308, 0.0138506, 0.273956, 0.34838, -0.00173434, 0.327221, 0.268644, -0.00173434, 0.465328, 0.109172, -0.00173434, 0.465328, 0.0605789, 0.0138506, 0.442963, -0.0605789, 0.0138506, 0.442963, -0.109172, -0.00173434, 0.465328, -0.268644, -0.00173434, 0.465328, -0.34838, -0.00173434, 0.327221, -0.353308, 0.0138506, 0.273956, -0.413887, 0.0138506, 0.16903, -0.457552, -0.00173434, 0.138129, -0.537288, -0.00173434, 2.26111e-005, -0.457552, -0.00173434, -0.138084, -0.413887, 0.0138506, -0.168985, -0.353308, 0.0138506, -0.27391, -0.34838, -0.00173434, -0.327176, -0.268644, -0.00173434, -0.465283]
            rig_scale=1.2*bb_len
            for i in range(0,len(rig_v)):
                rig_v[i]=rig_v[i]*rig_scale
    		#Save proxy to file
            proxy_srting='//Maya ASCII 2013 scene\n//Name: proxy.ma\n//Last modified: Mon, Jan 20, 2014 10:17:54 AM\n//Codeset: 1251\nrequires maya "2013";\ncurrentUnit -l centimeter -a degree -t film;\nfileInfo "application" "maya";\nfileInfo "product" "Maya 2013";\nfileInfo "version" "2013 x64";\nfileInfo "cutIdentifier" "201209210409-845513";\nfileInfo "osv" "Microsoft Windows 7 Business Edition, 64-bit Windows 7 Service Pack 1 (Build 7601)\\n";\n//Proxy creation\ncreateNode transform -n "root";\ncreateNode transform -n "rig" -p "root";\ncreateNode transform -n "general_CT" -p "rig";\ncreateNode mesh -n "general_CTShape" -p "general_CT";\n//Mesh creation\nsetAttr -s 8 ".vt[0:7]" \n'
            for i in range(0,len(bb_v)):
                proxy_srting=proxy_srting+str(bb_v[i])+' '
            proxy_srting=proxy_srting+';\nsetAttr -s 12 ".ed[0:11]"  0 1 0 2 3 0 4 5 0 6 7 0 0 2 0 1 3 0 2 4 0 3 5 0 4 6 0 5 7 0 6 0 0 7 1 0;\nsetAttr -s 6 -ch 24 ".fc[0:5]" -type "polyFaces" f 4 0 5 -2 -5 mu 0 4 0 1 2 13 f 4 1 7 -3 -7 mu 0 4 14 3 4 15 f 4 2 9 -4 -9 mu 0 4 16 5 6 17 f 4 3 11 -1 -11 mu 0 4 18 7 8 19 f 4 -12 -10 -8 -6 mu 0 4 1 9 10 3 f 4 10 4 6 8 mu 0 4 11 0 20 12;\ncreateNode nurbsCurve -n "general_CurveShape" -p "general_CT";\nsetAttr -k off ".v";\nsetAttr ".cc" -type "nurbsCurve" \n1 30 0 no 3 31 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31\n'	
            for i in range(0,len(rig_v)):
                proxy_srting=proxy_srting+str(rig_v[i])+' '
            proxy_srting=proxy_srting+str(';\n// End of proxy.ma')
    		#Save string to proxy
            file=open((('\\'.join(target_path[0:-1]))+'\\'+target_proxy[-1]).replace('\\','/'),"w")	
            file.write(proxy_srting)
            file.close()
    if True in proxy_check:
        pass
    if (cmds.listConnections(target_namespace,type="proxyManager")) is None:
        mel.eval('proxyAdd "'+target_namespace+'" "'+(('\\'.join(target_path[0:-1]))+'\\'+target_proxy[proxy_i]).replace('\\','/')+'" "";')
    target_toSwitch=cmds.listConnections((cmds.listConnections(target_namespace,type="proxyManager")[0]),type="reference")
    for i in range(0,len(target_toSwitch)):
        if (target_toSwitch[i] != target_namespace): 
            mel.eval('proxySwitch ("'+target_toSwitch[i]+'")')
            break
			
	
#LIST CAMERA TRANSFORMS                           
def listTransformsCameras():
    return cmds.listRelatives(cmds.ls(cameras=True),parent=True)
	
#GET CONNECTIONS LIST BY NODE TYPE                            
def getConnectionsByType(var01,var02):
	result=[]
	for i in range(0,len(var02)):
		if cmds.listConnections(var01, type=var02[i]) is not None:
		    if len(cmds.listConnections(var01, type=var02[i]))!=0:
			    result+=(cmds.listConnections(var01, type=var02[i]))		
	return result		
	
#ARRAY REMOVE FROM ARRAY				
def arrayRemoveFromArray(var01,var02):
    for i in range(0,len(var02)):
        if var02[i] in var01:
            var01.pop(var01.index(var02[i]))
            arrayRemoveFromArray(var01,var02)
            break
			
#SORT LIST BY NODE TYPE           
def typeSetArray(var01,var02):
		for i in range(0,len(var01)):
			if cmds.nodeType(var01[i])==var02: continue
			else:	
				var01.pop(i)
				typeSetArray(var01,var02)
				break  
				
#SELECTION MASK STATEMENT				
def selectionMask_cr(var_01,var_02):
    for i in range(0,len(var_01)):
        mel.eval('setObjectPickMask '+var_01[i]+' '+var_02)	

#DELETE ANIMATION CURVES		
def CUTool_deleteAnimationFromScene():
    var=(cmds.ls(type=("animCurveTU", "animCurveTA", "animCurveTL")))
    if len(var):
        cmds.delete(var)

#CHECK REFERENCE FOR EXISTS
def CUTool_checkReferenceExists(input):
    try:
        if cmds.referenceQuery(input,isLoaded=True) is True:
            return True
    except:
        return False        		
#______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
#IN FUTURE__________________________________________________________________________________________		
#-SHABLON
#Save characters list from animatik to txt file
#Load characters list from txt file

#-ANIMATIK
#Export cameras with animation in process
#Check geometry is not referenced
#Replace not referenced geometry to referenced geometry from props with animation saved
#Export all geometry to template
#Check and clean animatik

#SOMETHING__________________________________________________________________________________________
#remake all

#Automatik setup all

#Automatik all with closed maya
#______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________

#Save and export position
#Save list of loaded references and export list to scene for loaded exists references
#Restore references



#TEMP:
def CUTool_exportCamerasFromAnimatik(path):
    cmds.select(cmds.ls(type='sequencer'))
    cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)