import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
import subprocess
import sys
import ast
if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
	import rfm.slim
	import rfm.rlf2maya as rlf2maya
	import rfm.passes
import shutil
import math
import time
import ml_makeProxy
import xml.etree.ElementTree
if cmds.about( b=True ) is False:
	import melnik_setup
	
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
#Assembly procedures.
#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _

def ml_loadSlim( wait=1 ):
	#__________________________________________________________________________________________________________________________________________
	#Run renderman slim.
	cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ) is not True and cmds.loadPlugin( "RenderMan_for_Maya" )
	m_result = mel.eval( "rman slim isconnected" ) and True or False
	m_break = time.time() + ( 60 * wait )
	m_batch = cmds.about( b=True ) and " -gui 0 -edit 0" or ""
	if m_result is False:
		mel.eval( "rman slim start" + m_batch )
		while True:
			if mel.eval( "rman slim isconnected" ) and mel.eval( "rman slim command \"slim GetSlimStatus\"" ):
				m_result = True
				break
			if time.time() > m_break:
				break
	return m_result

def ml_loadPlugins( plugins='' ):
	#__________________________________________________________________________________________________________________________________________
	#Load maya plugins.
	m_result = []
	m_plugins = plugins == '' and [ 'RenderMan_for_Maya', 'AbcExport' ] or ( 'list' in str( type( plugins )) and plugins or [ plugins ] )
	for i in range( 0, len( m_plugins )):
		if not cmds.pluginInfo( m_plugins[i], query=True, loaded=True ):
			m_result.append( m_plugins[i] )
			try:
				cmds.loadPlugin( m_plugins[i] )
			except:
				cmds.warning( 'Errors expected while initialize plugin: %s.' % str( m_plugins[i] ))
	return m_result

def ml_slimCmd( command, debug=False, message=False ):
	#__________________________________________________________________________________________________________________________________________
	#Send to renderman slim command or message.
	m_result = []
	m_slim = rfm.slim.GetSlim()
	if not m_slim:
		ml_loadSlim( wait=1, debug=debug )
	m_command = command == '' and [] or ( 'list' in str( type( command )) and command or [ command ] )
	for i in range( 0, len( m_command )):
		m_temp = ""
		if message is False:
			m_temp = m_slim.Cmd( '"' + m_command[i] + '"' )
		else:
			m_temp = m_slim.Msg( '"' + m_command[i] + '"' )
			m_wait = 0
			while True:
				m_wait = m_wait + 1
				if mel.eval( 'rman slim isconnected' ):
					break
				elif m_wait > 1000000000:
					break
		if debug is True:
			print 'rman slim command "%s" Result: %s' % ( m_command[i], ( m_temp and m_temp or [] ))
		m_temp and m_result.append( m_temp )
	return m_result
	
def ml_statistic( ml_node, path='', all=False, debug=False ):
	#__________________________________________________________________________________________________________________________________________
	#Generate statistic file.
	m_target_for_hide = cmds.ls( type=[ "mesh", "nurbsCurve", "nurbsSurface" ] )
	if path == '':
		statistic_name = mel.eval( 'rman stringinterpolate "${STAGE}"' ) + '.string'
		statistic_dir = ( mel.eval( 'rman stringinterpolate "${RMSPROJ}"' ) or mel.eval( 'rman stringinterpolate "${RMSPROD}"' ))
		statistic_path = os.path.join( statistic_dir, statistic_name )
	else:
		statistic_path = path
		statistic_dir = '/'.join( path.split( '/' )[:-1] )
		statistic_name = path.split( '/' )[-1]
	if debug is True:
		print 'statistic: %s' % statistic_path
	#Render settings.
	m_globalsSettings = rfm.passes.GetGlobals()
	m_finalPassDefaultsDisplay = rfm.passes.GetPassDefaults( "Final" ).GetPrimaryDisplay()
	mel.eval( 'setCurrentRenderer renderMan;' )
	mel.eval( 'rmanChangeRendererUpdate;' )
	m_globalsSettings.SetAttr( "rman__riopt__statistics_endofframe", 1 )
	m_globalsSettings.SetAttr( "rman__riopt__statistics_filename", "stdout" )
	m_globalsSettings.SetAttr( "rman__riopt__statistics_xmlfilename", statistic_path )
	m_globalsSettings.SetAttr( "rman__riattr___ShadingRate", 1 )
	m_globalsSettings.SetAttr( "rman__riattr__volume_depthrelativeshadingrate", 1 )
	m_globalsSettings.SetAttr( "rman__riopt__limits_vprelativeshadingrate", 1 )
	m_globalsSettings.SetAttr( "rman__riattr___FocusFactor", 1 )
	m_globalsSettings.SetAttr( "rman__riattr___MotionFactor", 1 )
	m_globalsSettings.SetAttr( "rman__riopt__shading_directlightingsamples", 1 )
	m_globalsSettings.SetAttr( "rman__riopt___PixelSamples0", 1 )
	m_globalsSettings.SetAttr( "rman__riopt___PixelSamples1", 1 )
	m_finalPassDefaultsDisplay.SetAttr( "rman__riopt__Display_filterwidth0", 2 )
	m_finalPassDefaultsDisplay.SetAttr( "rman__riopt__Display_filterwidth1", 2 )
	cmds.setAttr( "defaultResolution.width", 2048 )
	cmds.setAttr( "defaultResolution.height", 2048 )
	cmds.setAttr( "defaultRenderGlobals.startFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.endFrame", 1 )
	cmds.setAttr( "defaultRenderGlobals.byFrameStep", 1 )
	m_final = cmds.ls( "rmanFinalGlobals" )
	#Final pass settings.
	if not m_final:
		#m_final = mel.eval( "rmanCreatePass \"rmanFinalGlobals\"" ) #check
		m_final = mel.eval("rmanCreateGlobals()")
		m_final = cmds.ls( "rmanFinalGlobals" )[0]
	else:
		m_final = m_final[0]
	AddAttr
	mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_backfacing", "%s" )' % ( m_final, 0 ))
	mel.eval( 'rmanAddAttr( "%s", "rman__riattr__cull_hidden", "%s" )' % ( m_final, 0 ))
	#Create statistic camera.
	ml_camera = cmds.camera()
	ml_transform = ml_camera[0]
	ml_camera = ml_camera[-1]
	m_cameras_list = cmds.ls( type='camera' )
	[ cmds.setAttr( "%s.renderable" % m_cameras_list[i], 0 ) for i in range( 0, len( m_cameras_list )) ]
	cmds.setAttr( "%s.renderable" % ml_camera, 1 )
	#cmds.renderSettings( camera=ml_camera ) #check
	cmds.setAttr( '%s.rotate' % ml_transform, -45, 45, 0 )
	m_hidden = []
	if all is False:
		cmds.select( cmds.ls( ml_node, long=True ))
		cmds.viewFit( ml_camera )
		m_hidden = cmds.hide( m_target_for_hide, returnHidden=True )
		cmds.showHidden( ml_node )
	else:
		cmds.select( clear=True )
		cmds.viewFit( ml_camera )
	#Batch render.
	mel.eval( 'rman render;' )
	if m_hidden:
		cmds.showHidden( m_hidden )
	cmds.delete( ml_transform )
	#Render
	return statistic_path

def ml_txmake( input='', output='' ):
	#__________________________________________________________________________________________________________________________________________
	#Convert tiff texture in tex.
	import subprocess
	import os
	import re
	mg_output = ''
	mg_txmake = os.path.join( 'rmantree/bin/txmake.exe', mel.eval( 'rman stringinterpolate "${RMSTREE}"' ))
	not os.path.isfile( mg_txmake ) and cmds.error( 'Failed to find txmake.' )
	mg_input = input != '' and input or cmds.error( 'Please specify path to image source file.' )
	mg_output = output != '' and output or cmds.error( 'Please specify path to image output file.' )
	os.path.isfile( mg_output ) and os.remove( mg_output )
	if re.findall( '.tif$', mg_input ) and re.findall( '.tex$', mg_output ):
		mg_command = [ mg_txmake, '-verbose', '-smode', 'clamp', '-tmode', 'clamp', '-resize', 'up-', mg_input, mg_output ]
	if re.findall( '.tex$', mg_input ) and re.findall( '.tif$', mg_output ):
		mg_command = [ mg_txmake, '-format', 'tiff' , mg_input, mg_output ]
	else:
		cmds.error( 'Please specify tif and tex image files for input and output variables.' )
	if mg_command:
		mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
		mg_output = '\n'.join( mg_process.communicate() )
		return mg_output
	else:
		return False
	
def ml_listAttached( m_objects, debug=True ):
	#__________________________________________________________________________________________________________________________________________
	#List nodes attached to slim id.
	def ml_listAttached_exec( m_identificator, m_node ):
		if m_identificator not in m_result_keys:
			m_result.update( { m_identificator:[ m_node ] } )
		else:
			m_content = m_result[ m_identificator ]
			if m_node not in m_content:
				m_content.append( m_node )
				m_result.update( { m_identificator:m_content } )
	m_result = {}
	m_objects = cmds.ls( m_objects, long=True )
	m_attributes = [ "rman__torattr___slimShader", "rman__torattr___slimEnsemble", "rman__torattr___slimSurface" ]
	for i in range( 0, len( m_objects )):
		m_attached = False
		m_result_keys = m_result.keys()
		for n in range( 0, len( m_attributes )):
			#Get node attachments.
			if cmds.attributeQuery( m_attributes[n], n=m_objects[i], exists=True ):
				m_temp = cmds.getAttr( "%s.%s" % ( m_objects[i], m_attributes[n] ))
				if m_temp:
					m_attached = True
					m_temp = m_temp.split( "," )
					for s in range( 0, len( m_temp )):
						if m_attributes[n] != "rman__torattr___slimEnsemble":
							ml_listAttached_exec( m_temp[s], m_objects[i] )
						else:
							#Material ensemble split.
							m_ensemble = ml_slimCmd( "tc_ensembleProperty -id %s" % m_temp[s], debug=debug)
							if m_ensemble:
								m_ensemble = m_ensemble[0].split( " " )
								for f in range( 0, len( m_ensemble )):
									ml_listAttached_exec( m_ensemble[f], m_objects[i] )
							else:
								ml_listAttached_exec( m_temp[s], m_objects[i] )
		if m_attached is False:
			if debug is True:
				print "Node is not attached to any slim nodes. ( %s )" % m_objects[i]
	return m_result

def ml_createCurveControl( name='', parent='', size='', target='', constraint=True, debug=False ):
	#__________________________________________________________________________________________________________________________________________
	#Create curve control for user specified node.
	def getLenght( node ):
		if node != '':
			bb = { 'min':cmds.getAttr( node + '.boundingBoxMin' )[0], 'max':cmds.getAttr( node + '.boundingBoxMax' )[0] }
			zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
			key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
			return zyx[ key[ True ] ]
		else:
			return 1
	#Make new nurbs curve.
	ml_curve_mel = "curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;"
	ml_curve = mel.eval( ml_curve_mel )
	if debug is True:
		print ml_curve_mel
	#Resize curve.
	ml_length = getLenght( size )
	#Make hierarchy for curve.
	if name != '':
		m_target_short = target.split( "|" )[-1]
		if name != m_target_short:
			ml_curve = cmds.rename( ml_curve, name )
		else:
			m_temp = m_target_short.split( "_" )
			if len( m_temp ) > 1:
				target = cmds.rename( target, "_offset_".join( m_temp ))
			else:
				target = cmds.rename( target, m_temp[0] + "_offset" )
			ml_curve = cmds.rename( ml_curve, name )
		if debug is True:
			print 'rename %s %s' % ( ml_curve, name )
	cmds.scale( 1.2 * ml_length, 1.2 * ml_length, 1.2 * ml_length, ml_curve )
	cmds.makeIdentity( ml_curve, translate=True, rotate=True, scale=True, apply=True )
	#Connect curves to target nodes.
	if target != '':
		if constraint is True:
			cmds.parentConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			cmds.scaleConstraint( ml_curve, target, maintainOffset=True, weight=1 )
			if debug is True:
				print 'parentConstraint %s -maintainOffset %s' % ( ml_curve, target )
				print 'scaleConstraint %s -maintainOffset %s' % ( ml_curve, target )
		else:
			cmds.parent( target, ml_curve )
			if debug is True:
				print 'parent %s %s' % ( target, ml_curve )
	if parent != '':
		cmds.parent( ml_curve, parent )
		if debug is True:
			print 'parent %s %s' % ( ml_curve, parent )
	return ml_curve
	
def ml_setAttr( m_node, m_value, debug=False, force=False, query=False ):
	#__________________________________________________________________________________________________________________________________________
	#Set attribute value.
	m_result = []
	m_temp = cmds.ls( m_node, long=True )
	for i in range( 0, len( m_temp )):
		m_connections = cmds.listConnections( m_temp[i], plugs=True )
		if cmds.attributeQuery( m_temp[i].split( '.' )[-1], n=m_temp[i].split( '.' )[0], exists=True ) and ( force is True or not m_connections ):
			if cmds.getAttr( m_temp[i] ) != m_value:
				m_result.append( m_temp[i] )
				if query is False:
					if force is True and m_connections:
						if cmds.connectionInfo( m_connections[0], destinationFromSource=True ):
							cmds.disconnectAttr( m_connections[0], m_temp[i] )
						else:
							cmds.disconnectAttr( m_temp[i], m_connections[0] )
						print "Disconnect attributes: %s %s" % ( m_temp[i], m_connections[0] )
					cmds.setAttr( m_temp[i], m_value )
					if debug is True:
						print "setAttr %s %s;" % ( m_temp[i], m_value )
				else:
					if debug is True:
						print "%s not equal %s;" % ( m_temp[i], m_value )
	return m_result

def ml_deleteNode( ml_objects, debug=False, query=False ):
	#__________________________________________________________________________________________________________________________________________
	#Remove node.
	m_result = []
	m_ignore = [ "time1", "sequenceManager1", "renderPartition", "renderGlobalsList1", "defaultLightList1", "defaultShaderList1", "postProcessList1", "defaultRenderUtilityList1", "defaultRenderingList1", "lightList1", "defaultTextureList1", "lambert1", "particleCloud1", "initialShadingGroup", "initialParticleSE", "initialMaterialInfo", "shaderGlow1", "dof1", "defaultRenderGlobals", "defaultRenderQuality", "defaultResolution", "defaultLightSet", "defaultObjectSet", "defaultViewColorManager", "hardwareRenderGlobals", "hardwareRenderingGlobals", "characterPartition", "defaultHardwareRenderGlobals", "ikSystem", "hyperGraphInfo", "hyperGraphLayout", "globalCacheControl", "dynController1", "strokeGlobals", "lightLinker1", "layerManager", "defaultLayer", "renderLayerManager", "defaultRenderLayer" ]
	m_temp = cmds.ls( ml_objects, long=True )
	if m_temp:
		for i in range( 0, len( m_temp )):
			if m_temp[i] not in m_ignore:
				m_result.append( m_temp[i] )
		if m_result:
			for i in range( 0, len( m_temp )):
				if query is False:
					try:
						cmds.delete( m_result[i] )
					except:
						print "Failed to delete node: %s" % m_result[i]
				if debug is True:
					print 'Delete %s;' % m_result[i]
	return m_result

def ml_deleteAttr( m_node, debug=False, force=False, query=False, empty=False ):
	#__________________________________________________________________________________________________________________________________________
	#Remove node attribute.
	if cmds.attributeQuery( m_node.split( '.' )[-1], n=m_node.split( '.' )[0], exists=True ) and ( force is True or not cmds.listConnections( m_node )) and (( empty is True and not cmds.getAttr( m_node )) or empty is False ):
		if query is False:
			try:
				cmds.deleteAttr( m_node )
			except:
				print "Failed to delete attribute: %s" % m_node
		if debug is True:
			print 'deleteAttr %s;' % m_node
	return m_node.split( '.' )[0]

def ml_addRmanAttr( m_node, m_attribute, m_value, debug=False, query=False ):
	#__________________________________________________________________________________________________________________________________________
	#Add rman attribute to node.
	if not cmds.attributeQuery( m_attribute, n=m_node, exists=True ):
		if query is False:
			mel.eval( 'rmanAddAttr( "%s", "%s", "%s" )' % ( m_node, m_attribute, m_value ) )
		if debug is True:
			print 'rmanAddAttr( "%s", "%s", "%s" )' % ( m_node, m_attribute, m_value )
	return m_node

def ml_flatRmanAttr( ml_object, ml_attribute, debug=False ):
	#__________________________________________________________________________________________________________________________________________
	#Rebind to shapes rman attributes.
	def ml_flatRmanAttr_depth( ml_node, ml_attribute ):
		ml_childrens = cmds.listRelatives( ml_node, children=True, ni=True, fullPath=True )
		if cmds.attributeQuery( ml_attribute, n=ml_node, exists=True ):
			ml_value = cmds.getAttr( '%s.%s' % ( ml_node, ml_attribute ))
			if ml_childrens:
				ml_deleteAttr( '%s.%s' % ( ml_node, ml_attribute ), debug=debug )
				for i in range( 0, len( ml_childrens )):
					ml_addRmanAttr( ml_childrens[i], ml_attribute, ml_value, debug=debug )
					ml_flatRmanAttr_depth( ml_childrens[i], ml_attribute )
			ml_result.append( ml_node )
	ml_result = []
	ml_flatRmanAttr_depth( ml_object, ml_attribute )
	return ml_result		
	
def ml_topReferencedNodes( m_path ):
	#__________________________________________________________________________________________________________________________________________
	#List top level transforms in current reference.
    m_transforms = []
    m_nodes = cmds.ls( cmds.referenceQuery( m_path, nodes=True, dagPath=True ), long=True, type="transform", ni=True )
    for n in range( 0, len( m_nodes )):
        m_parent = cmds.listRelatives( m_nodes[n], parent=True, fullPath=True )
        if ( m_parent and ( cmds.referenceQuery( m_parent, isNodeReferenced=True ) and cmds.referenceQuery( m_parent, filename=True ) != m_path ) or not cmds.referenceQuery( m_parent, isNodeReferenced=True )) or not m_parent:
            m_transforms.append( m_nodes[n] )
    return m_transforms

def ml_getNamespace( m_path ):
	#__________________________________________________________________________________________________________________________________________
	#Get namespace for current reference.
    m_current = cmds.file( m_path, query=True, namespace=True )
    m_parent = cmds.file( m_path, query=True, parentNamespace=True )[0]
    m_parent = m_parent and "%s:" % m_parent
    return "%s%s" % ( m_parent, m_current )
			
def ml_listPalettes():
	#__________________________________________________________________________________________________________________________________________
	#List sorted by filenames slim palettes.
	def ml_listPalettes_exec( m_key, m_node ):
		#Append to result palette.
		m_result_keys = m_result.keys()
		if m_key in m_result_keys:
			m_content = m_result[ m_key ]
			if m_node not in m_content:
				m_content.append( m_node )
			m_result.update( { m_key:m_content } )
		else:
			m_result.update( { m_key:[ m_node ] } )
	m_result = {}
	m_references = listReferences( unique=True )
	m_references = dict(( ml_getNamespace( m_references[i] ), m_references[i] ) for i in range( 0, len( m_references )))
	m_references_keys = m_references.keys()
	m_palettes = ml_slimCmd( "tc_list -type palette -hidden 0", debug=False )
	if m_palettes:
		m_palettes = m_palettes[0].split( " " )
		m_namespaces = cmds.namespaceInfo( listOnlyNamespaces=True, recurse=True )
		for i in range( 0, len( m_palettes )):
			m_maya_namespace = ""
			m_palette_namespace = ml_slimCmd( "%s GetNamespace" % m_palettes[i], debug=False )
			m_palette_id = ml_slimCmd( "%s GetID" % m_palettes[i], debug=False )
			m_palette_id = m_palette_id and m_palette_id[0]
			#Find current namespace.
			if m_palette_namespace:
				m_palette_namespace = m_palette_namespace[0]
				for n in range( 0, len( m_references_keys )):
					if m_palette_namespace == "_".join( m_references_keys[n].split( ":" )):
						m_maya_namespace = m_references_keys[n]
						break
			#Append to result palette.
			if m_maya_namespace != "":
				m_filename = m_references[ m_maya_namespace ]
			else:
				m_filename = cmds.file( query=True, sceneName=True )
				m_filename = m_filename != "" and m_filename or "untitled"
			ml_listPalettes_exec( m_filename, m_palette_id )
	return m_result
			
def ml_attachRmanQuery( m_node ):
	#__________________________________________________________________________________________________________________________________________
	#List slim attachments to maya node.
	m_result = []
	m_objects = cmds.ls( m_node )
	m_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
	for i in range( 0, len( m_objects )):
		for n in range( 0, len( m_attributes )):
			if cmds.attributeQuery( m_attributes[n], n=m_objects[i], exists=True ) is True:
				ml_value = cmds.getAttr( '%s.%s' % ( m_objects[i], m_attributes[n] ))
				if ml_value:
					ml_value = ml_value.split( ',' )
					for v in range( 0, len( ml_value )):
						m_result.append( ml_value[v] )
	return m_result	
	
def ml_listConnections( m_nodes, debug=False, source=True, destination=True, type='' ):
	#__________________________________________________________________________________________________________________________________________
	#List all connections for current node.
	def ml_listConnections_exec( m_temp ):
		m_temp = cmds.ls( m_temp )
		m_connections = cmds.listConnections( m_temp, source=source, destination=destination )
		if m_connections:
			for i in range( 0, len( m_connections )):
				if m_connections[i] not in m_result and m_connections[i] not in m_cache and m_connections[i] not in m_nodes:
					m_cache.append( m_connections[i] )
					if cmds.nodeType( m_connections[i] ) in m_type or type == '':
						m_result.append( m_connections[i] )
					if debug is True:
						print 'next connection( %s ).' % m_connections[i]
					ml_listConnections_exec( m_connections[i] )
	m_result = []
	m_cache = []
	m_type = type
	m_nodes = cmds.ls( m_nodes )
	ml_listConnections_exec( m_nodes )
	return m_result	

def searchNode( m_string, m_type="" ):
	#__________________________________________________________________________________________________________________________________________
	#Find node by string, if ls mel function not working.
	m_result = []
	m_nodes = cmds.ls( long=True )
	for i in range( 0, len( m_nodes )):
		if m_string == m_nodes[i].split( "|" )[-1]:
			if m_type == "" or cmds.nodeType( m_nodes[i] ) == m_type:
				m_result.append( m_nodes[i] )
	return m_result

def generateName( m_node, names="", shablon="" ):
	#__________________________________________________________________________________________________________________________________________
	#Generate new unique node name.
	if shablon == "":
		if not cmds.referenceQuery( m_node, isNodeReferenced=True ):
			m_shablon = ( cmds.file( query=True, sceneName=True ).split( "/" )[-1]).split( "." )[0] or "untitled"
		else:
			m_shablon = ( cmds.referenceQuery( m_node, filename=True ).split( "/" )[-1]).split( "." )[0]
	else:
		m_shablon = shablon
	m_type = cmds.nodeType( m_node )
	m_type = ( m_type == "mesh" and "_geo" ) or ( m_type == "transform" and "_grp" ) or ""
	m_number = 1
	m_result = ""
	while True:
		m_result = "%s%s%s" % ( m_shablon, m_number, m_type )
		if cmds.objExists( m_result ) or m_result in names:
			m_number += 1
			continue
		else:
			break
	return m_result

def makeTransform( m_path ):
	#__________________________________________________________________________________________________________________________________________
	#Make transforms hierarchy.
	m_groups = m_path.split( "|" )
	for i in range( 0, len( m_groups )):
		if m_groups[i]:
			if not cmds.objExists( "|".join(m_groups[:i+1] )):
				if i == 0:
					cmds.createNode( "transform", name=m_groups[i] )
				else:
					cmds.createNode( "transform", name=m_groups[i], parent="|".join( m_groups[:i] ))
	return m_path

def ml_assemblies():
	def ml_assemblyTransforms_exec( m_reference ):
		m_reference_short = m_reference.split( "{" )[0]
		m_transforms = []
		if m_reference == m_sceneName:
			m_nodes = cmds.ls( long=True, type="transform", assemblies=True )
			if m_nodes:
				for i in range( 0, len( m_nodes )):
					if not cmds.referenceQuery( m_nodes[i], isNodeReferenced=True ):
						m_transforms.append( m_nodes[i] )
		else:
			m_nodes = cmds.ls( cmds.referenceQuery( m_reference, nodes=True, dagPath=True ), long=True, type="transform", ni=True )
			for i in range( 0, len( m_nodes )):
				m_parent = cmds.listRelatives( m_nodes[i], parent=True, fullPath=True )
				if ( m_parent and ( cmds.referenceQuery( m_parent, isNodeReferenced=True ) and cmds.referenceQuery( m_parent, filename=True ) != m_reference ) or ( m_parent and not cmds.referenceQuery( m_parent, isNodeReferenced=True ))) or not m_parent:
					m_transforms.append( m_nodes[i] )
		m_result_keys = m_result.keys()
		if m_reference_short not in m_result_keys:
			m_result.update( { m_reference_short:m_transforms } )
	m_result = {}
	m_sceneName = cmds.file( query=True, sceneName=True )
	m_references = listReferences( unique=True )
	m_references.append( m_sceneName )
	for i in range( 0, len( m_references )):
		ml_assemblyTransforms_exec( m_references[i] )
	return m_result

def ml_getDescendents( m_transform ):
	m_result = []
	m_filename = cmds.file( query=True, sceneName=True )
	m_reference = cmds.referenceQuery( m_transform, isNodeReferenced=True ) and cmds.referenceQuery( m_transform, filename=True ) or m_filename
	m_descendents = cmds.listRelatives( m_transform, allDescendents=True, type="transform", fullPath=True )
	if m_descendents:
		for i in range( 0, len( m_descendents )):
			m_state = cmds.referenceQuery( m_descendents[i], isNodeReferenced=True )
			if m_state and cmds.referenceQuery( m_descendents[i], filename=True ) == m_reference or m_state is False and m_reference == m_filename:
				if m_descendents[i] not in m_result:
					m_result.append( m_descendents[i] )
	return m_result
	
def listReferences( unique=False ):
	#__________________________________________________________________________________________________________________________________________
	#List all loaded references.
	def listReferences_exec( m_current ):
		m_references_current = cmds.file( m_current, query=True, reference=True )
		if m_references_current:
			for i in range( 0, len( m_references_current )):
				m_temp = m_references_current[i]
				if unique is True:
					m_temp = m_temp.split( "{" )[0]
				if m_temp not in m_result:
					m_result.append( m_temp )
					listReferences_exec( m_references_current[i] )
	m_result = []
	m_references = cmds.file( query=True, reference=True )
	for i in range( 0, len( m_references )):
		listReferences_exec( m_references[i] )
		m_temp = m_references[i]
		if unique is True:
			m_temp = m_temp.split( "{" )[0]
		if m_temp not in m_result:
			m_result.append( m_temp )
	return m_result 	
	
def ml_replace( m_dst, m_src, m_variable, expression="" ):
	#__________________________________________________________________________________________________________________________________________
	#Replace values in dict and list variables.
	def ml_replace_exec( m_temp, parent=None, index=None ):
		if type( m_temp ) is dict:
			m_value_keys = m_temp.keys()
			for i in range( 0, len( m_value_keys )):
				ml_replace_exec( m_temp[ m_value_keys[i] ], parent=m_temp, index=m_value_keys[i] )
		elif type( m_temp ) is list:
			for i in range( 0, len( m_temp )):
				ml_replace_exec( m_temp[i], parent=m_temp, index=i )
		elif type( m_temp ) is str or type( m_temp ) is unicode:
			if re_expression.findall( m_temp ):
				re_sub = re.compile( "{0}\||{0}$".format( "\|".join( m_src.split( "|" ))))
				m_temp = re_sub.sub( m_temp, m_dst )
				if type( parent ) is dict:
					parent.update( { index:m_temp } )
				elif type( parent ) is list:
					parent[index] = m_temp
	re_expression =  expression == "" and re.compile( "^\|{0}|^{0}".format( "\|".join( m_src.split( "|" ))), re.IGNORECASE ) or expression
	ml_replace_exec( m_variable )
	return m_variable
	
def cleanup(
	query = True,
	debug = True,
	uniqueifySlim = False,
	unusedMayaNodes = True,
	slim = False, #IN WORK.
	geometry = False,
	freeze = False,
	attributes = False,
	combine = False,
	combineSlim = False,
	normals = False,
	displacement = False,
	shading = False,
	colors = False, #NOT AVALAIBLE.
	masks = False, #NOT AVALAIBLE.
	slimNames = False,
	mayaNames = False,
	hierarchy = False,
	history = False,
	):
	def ml_update_content( m_dst, m_src ):
		ml_replace( m_dst, m_src, unusedMayaNodes )
		ml_replace( m_dst, m_src, mayaNames )
		ml_replace( m_dst, m_src, hierarchy )
		ml_replace( m_dst, m_src, attributes )
		ml_replace( m_dst, m_src, geometry )
		ml_replace( m_dst, m_src, displacement )
		ml_replace( m_dst, m_src, normals )
		ml_replace( m_dst, m_src, shading )
		ml_replace( m_dst, m_src, combine )
		ml_replace( m_dst, m_src, history )
	m_result = {}
	m_arguments = [ uniqueifySlim, unusedMayaNodes, slim, geometry, freeze, attributes, combine, normals, displacement, shading, colors, masks, slimNames, mayaNames, hierarchy, history, combineSlim ]
	m_arguments = [ m_arguments[i] for i in range( 0, len( m_arguments )) if m_arguments[i] is not False ]
	m_arguments = len( m_arguments )
	m_step = 0
	#__________________________________________________________________________________________________________________________________________
	#Get default and not deletable nodes.
	m_default = [ "rmanFinalGlobals", "rmanPreviewGlobals", "rmanRerenderGlobals", "rmanReyesRerenderGlobals", "rmanDeepShadowGlobals", "rmanAreaShadowGlobals", "rmanShadowGlobals", "rmanBakeGlobals", "rmanBakeRenderGlobals", "rmanSSMakeBrickmapGlobals", "rmanSSDiffuseGlobals", "rmanSSRenderGlobals", "rmanSBMakeBrickmapGlobals", "rmanSBRenderGlobals", "rmanRenderCausticGlobals", "rmanTxMakeGlobals", "rmanMakeApproxGlobalDiffuseGlobals", "rmanRenderApproxGlobalDiffuseGlobals", "rmanRenderRadiosityGlobals", "rmanMakeFilterApproxGlobalDiffuseGlobals", "rmanFilterApproxGlobalDiffuseGlobals", "rmanMinMaxShadowGlobals", "rmanMakeGlobalDiffuse3dGlobals", "rmanRenderGlobalDiffuse3dGlobals", "rmanReferenceGlobals", "rmanReferenceRenderGlobals", "rmanVolumeScatterGlobals", "rmanScatterVolumeRenderGlobals", "renderManGlobals", "animLayersFilter", "notAnimLayersFilter", "CustomGPUCacheFilter", "layersFilter", "defaultRenderLayerFilter", "renderLayerFilter", "renderingSetsFilter", "relationshipPanel1RightAttrFilter", "relationshipPanel1LeftAttrFilter", "time1", "sequenceManager1", "renderPartition", "renderGlobalsList1", "mtorPartition", "defaultLightList1", "defaultShaderList1", "postProcessList1", "defaultRenderUtilityList1", "defaultRenderingList1", "lightList1", "defaultTextureList1", "lambert1", "particleCloud1", "initialShadingGroup", "initialParticleSE", "initialMaterialInfo", "shaderGlow1", "dof1", "defaultRenderGlobals", "defaultRenderQuality", "defaultResolution", "defaultLightSet", "defaultObjectSet", "defaultViewColorManager", "hardwareRenderGlobals", "hardwareRenderingGlobals", "characterPartition", "defaultHardwareRenderGlobals", "ikSystem", "hyperGraphInfo", "hyperGraphLayout", "globalCacheControl", "dynController1", "strokeGlobals", "lightLinker1", "layerManager", "defaultLayer", "renderLayerManager", "defaultRenderLayer" ]
	m_cameras = cmds.ls( type="camera", long=True )
	m_cameras = [ m_cameras[i] for i in range( 0, len( m_cameras )) if cmds.camera( m_cameras[i], query=True, startupCamera=True ) or re.findall( "[Ee][Pp][0-9]+\w+[Ss][Cc]\w+[0-9]+", m_cameras[i] ) ]
	[ m_default.append( m_cameras[i] ) for i in range( 0, len( m_cameras ))]
	#__________________________________________________________________________________________________________________________________________
	#Load requested plugins and scripts.
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Get file information.
	m_file = cmds.file( query=True, sceneName=True )
	m_file = m_file != "" and m_file or "untitled"
	m_scene = ( m_file.split( "/" )[-1] ).split( "." )[0]
	m_names = []
	#Delete unused nodes.
	#Modelling setup 6, 9, 10, Texture setup 5, 12, 7, 8.
	if unusedMayaNodes is not False:
		m_argument = "Unused maya nodes"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if unusedMayaNodes is True:
			m_nodes = cmds.ls( long=True )
			for i in range( 0, len( m_nodes )):
				m_law = False
				m_type = cmds.nodeType( m_nodes[i] )
				m_dag = cmds.ls( m_nodes[i], dag=True )
				m_reference = cmds.referenceQuery( m_nodes[i], isNodeReferenced=True )
				m_connections = cmds.listConnections( m_nodes[i], type="reference" )
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List not used filters, renderman nodes, gpu caches, shading engines, rib archives...
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				if m_nodes[i] not in m_default and m_reference is False and not m_connections:
					if not m_dag:
						if m_type in [ "nodeEditorPanel", "objectTypeFilter", "objectNameFilter", "objectMultiFilter", "hyperGraphInfo", "hyperView", "hyperLayout", "objectScriptFilter", "RenderMan" ]:
							m_law = True
					else:
						if m_type in [ "groupId" ]:
							if not cmds.listConnections( "%s.groupId" % m_nodes[i] ):
								m_law = True
						elif m_type in [ "gpuCache" ]:
							if not cmds.getAttr( "%s.cacheFileName" % m_nodes[i] ):
								m_law = True
						elif m_type in [ "RenderManArchive" ]:
							if not cmds.getAttr( "%s.filename" % m_nodes[i] ):
								m_law = True
						elif m_type in [ "transform" ]:
							m_childrens_dag = len( m_dag )
							m_childrens_transform = len( cmds.ls( m_dag, type="transform" ))
							if m_childrens_dag == m_childrens_transform and not cmds.listConnections( m_dag ):
								m_law = True
						elif m_type in cmds.listNodeTypes( "shader" ):
							m_shadingEngine = cmds.listConnections( m_nodes[i], type="shadingEngine" )
							if not m_shadingEngine:
								m_law = True
							else:
								m_images = cmds.listConnections( m_nodes[i], type="file" )
								for n in range( 0, len( m_images )):
									m_shader_texture = cmds.getAttr( "%s.fileTextureName" % m_images[n] )
									if not m_shader_texture or not re.findall( "/anm|\\anm|/textures|\\textures", m_shader_texture ) or not os.path.isfile( m_shader_texture ):
										m_law = True
										break
						elif m_type in [ "file", "place2dTexture", "materialInfo" ]:
							m_connections = cmds.listHistory( m_nodes[i] )
							m_connections = cmds.listConnections( m_connections )
							if "lambert1" in m_connections:
								m_law = True
						else:
							pass
				if m_law is True:
					if m_nodes[i] not in m_items:
						m_items.append( m_nodes[i] )
						if debug is True:
							print "Found not used node: %s - %s" % ( m_type, m_nodes[i] )
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = unusedMayaNodes
		if m_items:
			m_result.update( { m_argument:m_items } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						try:
							cmds.delete( m_items[i] )
							if debug is True:
								print "Delete: %s" % m_items[i]
						except:
							if debug is True:
								print "Failed to delete: %s" % m_items[i]
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#List all non-manifold nodes.
	#Modelling setup 0.
	if geometry is not False:
		m_argument = "Non-manifold geometry"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = {}
		if geometry is True:
			m_nodes = cmds.ls( type=[ "mesh", "nurbsCurve" ], ni=True, visible=True, long=True )
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_default:
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
					#List all non-manifold geometry.
					if cmds.nodeType( m_nodes[i] ) == "mesh":
						if cmds.polyEvaluate( m_nodes[i], vertex=True ) >= 2:
							m_temp = []
							m_component = cmds.ls( cmds.polyInfo( m_nodes[i], laminaFaces=True, nonManifoldEdges=True, nonManifoldVertices=True ), fl=True, long=True )
							if m_component:
								m_temp = m_temp + m_component
							if m_temp:
								m_items.update( { m_nodes[i]:m_temp } )
								if debug is True:
									print "Found non-manifold components: %s" % m_nodes[i]
						else:
							m_items.update( { m_nodes[i]:[] } )
							if debug is True:
								print "Found non-manifold components: %s" % m_nodes[i]
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
					#List curves with zero spans.
					else:
						if cmds.attributeQuery( "spans", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.spans" % m_nodes[i] ) < 2 and m_nodes[i] not in m_items:
							m_items.update( { m_nodes[i]:[] } )
							if debug is True:
								print "Found non-manifold components: %s" % m_nodes[i]
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = geometry
		if m_items:
			m_result.update( { m_argument:m_items } )
			if query is False:
				for i in range( 0, len( m_items )):
					pass
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#List all can be combined geometry nodes.
	#Texture setup 3.
	if combine is not False:
		m_argument = "Combine similar nodes"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = {}
		if combine is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List can be combined groups.
			m_combine = []
			m_nodes = cmds.ls( type="mesh", ni=True, visible=True, long=True )
			if m_nodes:
				for i in range( 0, len( m_nodes )):
					m_current = m_nodes[i]
					m_group = ""
					while True:
						m_parent = cmds.listRelatives( m_current, parent=True, fullPath=True )
						if m_parent:
							if not cmds.listConnections( m_parent ) and ( m_current == m_nodes[i] or not cmds.listConnections( m_current, source=True, destination=False )):
								m_current = m_parent[0]
								continue
							else:
								m_group = m_parent[0]
								break
						else:
							m_group = m_current
							break
					if m_group != "" and m_group not in m_combine:
						m_combine.append( m_group )
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List can be combined nodes.
			m_cache = []
			if m_combine:
				m_groups = {}
				#List nodes for current group and ignore all other groups content.
				for i in range( 0, len( m_combine )):
					m_nodes = cmds.ls( m_combine[i], dag=True, type="mesh", ni=True, visible=True, long=True )
					m_nodes_cache = []
					for n in range( 0, len( m_nodes )):
						m_bool = True
						for f in range( 0, len( m_combine )):
							if f != i and re.findall( "^" + "\|".join( m_combine[f].split( "|" )) + "\|", m_nodes[n] ) and not re.findall( "^" + "\|".join( m_combine[f].split( "|" )) + "\|", m_combine[i] ):
								m_bool = False
								break
						if m_bool is True:
							m_nodes_cache.append( m_nodes[n] )
					m_groups.update( { m_combine[i]:m_nodes_cache } )
				#Check similar slim attachments mesh count.
				for i in range( 0, len( m_combine )):
					m_temp = m_groups[ m_combine[i] ]
					m_combine_exec = []
					m_cache_names = []
					if m_temp and len( m_temp ) > 1:
						for n in range( 0, len( m_temp )):
							if m_temp[n] not in str( m_combine_exec ) and not cmds.listConnections( m_temp[n], destination=False, source=True ):
								m_combine_cache = []
								if m_temp[n] not in m_cache:
									m_attachedID = ml_attachRmanQuery( m_temp[n] )
									for f in range( 0, len( m_temp )):
										m_law = True
										m_attachedID_temp = ml_attachRmanQuery( m_temp[f] )
										for s in range( 0, len( m_attachedID )):
											if m_attachedID[s] not in m_attachedID_temp:
												m_law = False
												break
										for s in range( 0, len( m_attachedID_temp )):
											if m_attachedID_temp[s] not in m_attachedID:
												m_law = False
												break
										if m_law is True and m_temp[f] not in m_combine_cache:
											m_combine_cache.append( m_temp[f] )
											m_cache.append( m_temp[f] )
								if m_combine_cache:
									m_combine_exec.append( m_combine_cache )
					if m_combine_exec:
						for n in range( 0, len( m_combine_exec )):
							if len( m_combine_exec[n] ) > 1:
								m_name = "%s_%s" % ( m_combine[i], len( m_cache_names ))
								m_items.update( { m_name : m_combine_exec[n] } )
								m_cache_names.append( m_name )
								if debug is True:
									print "Founded can be combined nodes: %s" % str( m_combine_exec[n] )
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = combine
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				m_items_keys = m_items.keys()
				for i in range( 0, len( m_items_keys )):
					if debug is True:
						pass
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Delete not used history.
	#Modelling setup 4.
	if history is not False:
		m_argument = "History"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		m_ignore = []
		if history is True:
			m_nodes = cmds.ls( dag=True, type=[ "mesh" ], long=True, ni=True, visible=True )
			for i in range( 0, len( m_nodes )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List all not used in rig nodes with history.
				if m_nodes[i] not in m_default:
					ml_connections = ml_listConnections( m_nodes[i], debug=False, source=True, destination=True, type=[ "nurbsCurve", "blendShape", "animCurveUU", "animCurveUA", "animCurveUL" ] )
					if ml_connections:
						continue
				m_shortName = cmds.ls( m_nodes[i] )[0]
				m_cache = cmds.bakePartialHistory( m_nodes[i], preDeformers=True, preCache=True, query=True )
				m_history = cmds.listHistory( m_nodes[i] )
				if m_history:
					m_history = [ m_history[n] for n in range( 0, len( m_history )) if m_history[n] != "initialShadingGroup" and m_history[n] != m_shortName ]
				m_connections = cmds.listConnections( m_nodes[i], source=True, destination=False )
				if m_connections:
					m_connections = [ m_connections[n] for n in range( 0, len( m_connections )) if m_connections[n] != "initialShadingGroup" and m_connections[n] != m_shortName ]
				if m_history and len( m_history ) >= 1 or m_cache and m_connections and m_nodes[i] not in m_items:
					m_items.append( m_nodes[i] )
					if debug is True:
						print "Founded node with not used history: %s" % m_nodes[i]
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = history
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						cmds.bakePartialHistory( m_items[i], preDeformers=True, preCache=True )
						cmds.delete( m_items[i], constructionHistory=True )
						if debug is True:
							print "Delete history from %s;" % m_items[i]
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Attach default material to all not attached geometry nodes.
	#Texture setup 0.
	if shading is not False:
		m_argument = "Default shading"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if shading is True:
			m_nodes = cmds.ls( type="mesh", long=True, ni=True )
			for i in range( 0, len( m_nodes )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List all nodes with not attached default material or has bad attachments to lambert.
				if m_nodes[i] not in m_default:
					m_connections = cmds.listConnections( m_nodes[i], plugs=True, connections=True, destination=True )
					m_law = True
					m_texure = True
					m_shading = cmds.listConnections( m_nodes[i], type="shadingEngine" )
					m_defaultShading = m_shading and ( "initialShadingGroup" in m_shading and True or False ) or False
					m_shader = m_shading and cmds.listConnections( m_shading ) or []
					#Check textures.
					if m_shader:
						m_images = cmds.listConnections( m_shader, type="file" )
						if not m_images:
							m_texure = True
						else:
							for n in range( 0, len( m_images )):
								m_shader_texture = cmds.getAttr( "%s.fileTextureName" % m_images[n] )
								if not m_shader_texture or not re.findall( "/anm|\\anm|/textures|\\textures", m_shader_texture ) or not os.path.isfile( m_shader_texture ):
									m_texure = False
					#Check usability.
					for n in range( 0, len( m_connections )):
						if m_defaultShading is True and re.findall( "%s.instObjGroups$" % m_nodes[i].split( "|" )[-1], m_connections[n] ) and "initialShadingGroup" in cmds.listConnections( "%s.instObjGroups" % m_nodes[i] ) or m_texure is True:
							m_law = False
							break
					if m_law is True:
						if m_nodes[i] not in m_items:
							m_items.append( m_nodes[i] )
							if debug is True:
								print "Founded node with not attached default shading engine: %s" % m_nodes[i]
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = shading
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				m_lambertSettings = ['not cmds.getAttr( "lambert1.caching", lock=True ) and cmds.setAttr( "lambert1.caching", False )', 'not cmds.getAttr( "lambert1.isHistoricallyInteresting", lock=True ) and cmds.setAttr( "lambert1.isHistoricallyInteresting", 2 )', 'not cmds.getAttr( "lambert1.nodeState", lock=True ) and cmds.setAttr( "lambert1.nodeState", 0 )', 'not cmds.getAttr( "lambert1.binMembership", lock=True ) and cmds.setAttr( "lambert1.binMembership", None )', 'not cmds.getAttr( "lambert1.refractionLimit", lock=True ) and cmds.setAttr( "lambert1.refractionLimit", 6 )', 'not cmds.getAttr( "lambert1.refractiveIndex", lock=True ) and cmds.setAttr( "lambert1.refractiveIndex", 1.0 )', 'not cmds.getAttr( "lambert1.refractions", lock=True ) and cmds.setAttr( "lambert1.refractions", False )', 'not cmds.getAttr( "lambert1.diffuse", lock=True ) and cmds.setAttr( "lambert1.diffuse", 0.800000011921 )', 'not cmds.getAttr( "lambert1.color", lock=True ) and cmds.setAttr( "lambert1.color", 0.5, 0.5, 0.5 )', 'not cmds.getAttr( "lambert1.colorR", lock=True ) and cmds.setAttr( "lambert1.colorR", 0.5 )', 'not cmds.getAttr( "lambert1.colorG", lock=True ) and cmds.setAttr( "lambert1.colorG", 0.5 )', 'not cmds.getAttr( "lambert1.colorB", lock=True ) and cmds.setAttr( "lambert1.colorB", 0.5 )', 'not cmds.getAttr( "lambert1.transparency", lock=True ) and cmds.setAttr( "lambert1.transparency", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.transparencyR", lock=True ) and cmds.setAttr( "lambert1.transparencyR", 0.0 )', 'not cmds.getAttr( "lambert1.transparencyG", lock=True ) and cmds.setAttr( "lambert1.transparencyG", 0.0 )', 'not cmds.getAttr( "lambert1.transparencyB", lock=True ) and cmds.setAttr( "lambert1.transparencyB", 0.0 )', 'not cmds.getAttr( "lambert1.ambientColor", lock=True ) and cmds.setAttr( "lambert1.ambientColor", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.ambientColorR", lock=True ) and cmds.setAttr( "lambert1.ambientColorR", 0.0 )', 'not cmds.getAttr( "lambert1.ambientColorG", lock=True ) and cmds.setAttr( "lambert1.ambientColorG", 0.0 )', 'not cmds.getAttr( "lambert1.ambientColorB", lock=True ) and cmds.setAttr( "lambert1.ambientColorB", 0.0 )', 'not cmds.getAttr( "lambert1.incandescence", lock=True ) and cmds.setAttr( "lambert1.incandescence", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.incandescenceR", lock=True ) and cmds.setAttr( "lambert1.incandescenceR", 0.0 )', 'not cmds.getAttr( "lambert1.incandescenceG", lock=True ) and cmds.setAttr( "lambert1.incandescenceG", 0.0 )', 'not cmds.getAttr( "lambert1.incandescenceB", lock=True ) and cmds.setAttr( "lambert1.incandescenceB", 0.0 )', 'not cmds.getAttr( "lambert1.translucence", lock=True ) and cmds.setAttr( "lambert1.translucence", 0.0 )', 'not cmds.getAttr( "lambert1.translucenceFocus", lock=True ) and cmds.setAttr( "lambert1.translucenceFocus", 0.5 )', 'not cmds.getAttr( "lambert1.translucenceDepth", lock=True ) and cmds.setAttr( "lambert1.translucenceDepth", 0.5 )', 'not cmds.getAttr( "lambert1.opacityDepth", lock=True ) and cmds.setAttr( "lambert1.opacityDepth", 0.0 )', 'not cmds.getAttr( "lambert1.glowIntensity", lock=True ) and cmds.setAttr( "lambert1.glowIntensity", 0.0 )', 'not cmds.getAttr( "lambert1.vrOverwriteDefaults", lock=True ) and cmds.setAttr( "lambert1.vrOverwriteDefaults", False )', 'not cmds.getAttr( "lambert1.vrFillObject", lock=True ) and cmds.setAttr( "lambert1.vrFillObject", 0 )', 'not cmds.getAttr( "lambert1.vrEdgeWeight", lock=True ) and cmds.setAttr( "lambert1.vrEdgeWeight", 0.0 )', 'not cmds.getAttr( "lambert1.vrEdgeColor", lock=True ) and cmds.setAttr( "lambert1.vrEdgeColor", 0.5, 0.5, 0.5 )', 'not cmds.getAttr( "lambert1.vrEdgeColorR", lock=True ) and cmds.setAttr( "lambert1.vrEdgeColorR", 0.5 )', 'not cmds.getAttr( "lambert1.vrEdgeColorG", lock=True ) and cmds.setAttr( "lambert1.vrEdgeColorG", 0.5 )', 'not cmds.getAttr( "lambert1.vrEdgeColorB", lock=True ) and cmds.setAttr( "lambert1.vrEdgeColorB", 0.5 )', 'not cmds.getAttr( "lambert1.vrEdgeStyle", lock=True ) and cmds.setAttr( "lambert1.vrEdgeStyle", 0 )', 'not cmds.getAttr( "lambert1.vrEdgePriority", lock=True ) and cmds.setAttr( "lambert1.vrEdgePriority", 0 )', 'not cmds.getAttr( "lambert1.vrHiddenEdges", lock=True ) and cmds.setAttr( "lambert1.vrHiddenEdges", False )', 'not cmds.getAttr( "lambert1.vrHiddenEdgesOnTransparent", lock=True ) and cmds.setAttr( "lambert1.vrHiddenEdgesOnTransparent", False )', 'not cmds.getAttr( "lambert1.vrOutlinesAtIntersections", lock=True ) and cmds.setAttr( "lambert1.vrOutlinesAtIntersections", True )', 'not cmds.getAttr( "lambert1.materialAlphaGain", lock=True ) and cmds.setAttr( "lambert1.materialAlphaGain", 1.0 )', 'not cmds.getAttr( "lambert1.hideSource", lock=True ) and cmds.setAttr( "lambert1.hideSource", False )', 'not cmds.getAttr( "lambert1.surfaceThickness", lock=True ) and cmds.setAttr( "lambert1.surfaceThickness", 0.0 )', 'not cmds.getAttr( "lambert1.shadowAttenuation", lock=True ) and cmds.setAttr( "lambert1.shadowAttenuation", 0.5 )', 'not cmds.getAttr( "lambert1.transparencyDepth", lock=True ) and cmds.setAttr( "lambert1.transparencyDepth", 0.0 )', 'not cmds.getAttr( "lambert1.lightAbsorbance", lock=True ) and cmds.setAttr( "lambert1.lightAbsorbance", 0.0 )', 'not cmds.getAttr( "lambert1.chromaticAberration", lock=True ) and cmds.setAttr( "lambert1.chromaticAberration", False )', 'not cmds.getAttr( "lambert1.outColor", lock=True ) and cmds.setAttr( "lambert1.outColor", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.outColorR", lock=True ) and cmds.setAttr( "lambert1.outColorR", 0.0 )', 'not cmds.getAttr( "lambert1.outColorG", lock=True ) and cmds.setAttr( "lambert1.outColorG", 0.0 )', 'not cmds.getAttr( "lambert1.outColorB", lock=True ) and cmds.setAttr( "lambert1.outColorB", 0.0 )', 'not cmds.getAttr( "lambert1.outTransparency", lock=True ) and cmds.setAttr( "lambert1.outTransparency", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.outTransparencyR", lock=True ) and cmds.setAttr( "lambert1.outTransparencyR", 0.0 )', 'not cmds.getAttr( "lambert1.outTransparencyG", lock=True ) and cmds.setAttr( "lambert1.outTransparencyG", 0.0 )', 'not cmds.getAttr( "lambert1.outTransparencyB", lock=True ) and cmds.setAttr( "lambert1.outTransparencyB", 0.0 )', 'not cmds.getAttr( "lambert1.outGlowColor", lock=True ) and cmds.setAttr( "lambert1.outGlowColor", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.outGlowColorR", lock=True ) and cmds.setAttr( "lambert1.outGlowColorR", 0.0 )', 'not cmds.getAttr( "lambert1.outGlowColorG", lock=True ) and cmds.setAttr( "lambert1.outGlowColorG", 0.0 )', 'not cmds.getAttr( "lambert1.outGlowColorB", lock=True ) and cmds.setAttr( "lambert1.outGlowColorB", 0.0 )', 'not cmds.getAttr( "lambert1.pointCamera", lock=True ) and cmds.setAttr( "lambert1.pointCamera", 1.0, 1.0, 1.0 )', 'not cmds.getAttr( "lambert1.pointCameraX", lock=True ) and cmds.setAttr( "lambert1.pointCameraX", 1.0 )', 'not cmds.getAttr( "lambert1.pointCameraY", lock=True ) and cmds.setAttr( "lambert1.pointCameraY", 1.0 )', 'not cmds.getAttr( "lambert1.pointCameraZ", lock=True ) and cmds.setAttr( "lambert1.pointCameraZ", 1.0 )', 'not cmds.getAttr( "lambert1.normalCamera", lock=True ) and cmds.setAttr( "lambert1.normalCamera", 1.0, 1.0, 1.0 )', 'not cmds.getAttr( "lambert1.normalCameraX", lock=True ) and cmds.setAttr( "lambert1.normalCameraX", 1.0 )', 'not cmds.getAttr( "lambert1.normalCameraY", lock=True ) and cmds.setAttr( "lambert1.normalCameraY", 1.0 )', 'not cmds.getAttr( "lambert1.normalCameraZ", lock=True ) and cmds.setAttr( "lambert1.normalCameraZ", 1.0 )', 'not cmds.getAttr( "lambert1.matteOpacityMode", lock=True ) and cmds.setAttr( "lambert1.matteOpacityMode", 2 )', 'not cmds.getAttr( "lambert1.matteOpacity", lock=True ) and cmds.setAttr( "lambert1.matteOpacity", 1.0 )', 'not cmds.getAttr( "lambert1.outMatteOpacity", lock=True ) and cmds.setAttr( "lambert1.outMatteOpacity", 1.0, 1.0, 1.0 )', 'not cmds.getAttr( "lambert1.outMatteOpacityR", lock=True ) and cmds.setAttr( "lambert1.outMatteOpacityR", 1.0 )', 'not cmds.getAttr( "lambert1.outMatteOpacityG", lock=True ) and cmds.setAttr( "lambert1.outMatteOpacityG", 1.0 )', 'not cmds.getAttr( "lambert1.outMatteOpacityB", lock=True ) and cmds.setAttr( "lambert1.outMatteOpacityB", 1.0 )', 'not cmds.getAttr( "lambert1.hardwareShader", lock=True ) and cmds.setAttr( "lambert1.hardwareShader", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.hardwareShaderR", lock=True ) and cmds.setAttr( "lambert1.hardwareShaderR", 0.0 )', 'not cmds.getAttr( "lambert1.hardwareShaderG", lock=True ) and cmds.setAttr( "lambert1.hardwareShaderG", 0.0 )', 'not cmds.getAttr( "lambert1.hardwareShaderB", lock=True ) and cmds.setAttr( "lambert1.hardwareShaderB", 0.0 )', 'not cmds.getAttr( "lambert1.miRefractionBlur", lock=True ) and cmds.setAttr( "lambert1.miRefractionBlur", 0.0 )', 'not cmds.getAttr( "lambert1.miRefractionRays", lock=True ) and cmds.setAttr( "lambert1.miRefractionRays", 1 )', 'not cmds.getAttr( "lambert1.miIrradiance", lock=True ) and cmds.setAttr( "lambert1.miIrradiance", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.miIrradianceR", lock=True ) and cmds.setAttr( "lambert1.miIrradianceR", 0.0 )', 'not cmds.getAttr( "lambert1.miIrradianceG", lock=True ) and cmds.setAttr( "lambert1.miIrradianceG", 0.0 )', 'not cmds.getAttr( "lambert1.miIrradianceB", lock=True ) and cmds.setAttr( "lambert1.miIrradianceB", 0.0 )', 'not cmds.getAttr( "lambert1.miIrradianceColor", lock=True ) and cmds.setAttr( "lambert1.miIrradianceColor", 1.0, 1.0, 1.0 )', 'not cmds.getAttr( "lambert1.miIrradianceColorR", lock=True ) and cmds.setAttr( "lambert1.miIrradianceColorR", 1.0 )', 'not cmds.getAttr( "lambert1.miIrradianceColorG", lock=True ) and cmds.setAttr( "lambert1.miIrradianceColorG", 1.0 )', 'not cmds.getAttr( "lambert1.miIrradianceColorB", lock=True ) and cmds.setAttr( "lambert1.miIrradianceColorB", 1.0 )', 'not cmds.getAttr( "lambert1.miDeriveFromMaya", lock=True ) and cmds.setAttr( "lambert1.miDeriveFromMaya", True )', 'not cmds.getAttr( "lambert1.miRefractiveIndex", lock=True ) and cmds.setAttr( "lambert1.miRefractiveIndex", 1.0 )', 'not cmds.getAttr( "lambert1.miRefractions", lock=True ) and cmds.setAttr( "lambert1.miRefractions", True )', 'not cmds.getAttr( "lambert1.miAbsorbs", lock=True ) and cmds.setAttr( "lambert1.miAbsorbs", True )', 'not cmds.getAttr( "lambert1.miDiffuse", lock=True ) and cmds.setAttr( "lambert1.miDiffuse", 0.800000011921 )', 'not cmds.getAttr( "lambert1.miColor", lock=True ) and cmds.setAttr( "lambert1.miColor", 0.5, 0.5, 0.5 )', 'not cmds.getAttr( "lambert1.miColorR", lock=True ) and cmds.setAttr( "lambert1.miColorR", 0.5 )', 'not cmds.getAttr( "lambert1.miColorG", lock=True ) and cmds.setAttr( "lambert1.miColorG", 0.5 )', 'not cmds.getAttr( "lambert1.miColorB", lock=True ) and cmds.setAttr( "lambert1.miColorB", 0.5 )', 'not cmds.getAttr( "lambert1.miTransparency", lock=True ) and cmds.setAttr( "lambert1.miTransparency", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.miTransparencyR", lock=True ) and cmds.setAttr( "lambert1.miTransparencyR", 0.0 )', 'not cmds.getAttr( "lambert1.miTransparencyG", lock=True ) and cmds.setAttr( "lambert1.miTransparencyG", 0.0 )', 'not cmds.getAttr( "lambert1.miTransparencyB", lock=True ) and cmds.setAttr( "lambert1.miTransparencyB", 0.0 )', 'not cmds.getAttr( "lambert1.miTranslucence", lock=True ) and cmds.setAttr( "lambert1.miTranslucence", 0.0 )', 'not cmds.getAttr( "lambert1.miTranslucenceFocus", lock=True ) and cmds.setAttr( "lambert1.miTranslucenceFocus", 0.5 )', 'not cmds.getAttr( "lambert1.miNormalCamera", lock=True ) and cmds.setAttr( "lambert1.miNormalCamera", 0.0, 0.0, 0.0 )', 'not cmds.getAttr( "lambert1.miNormalCameraX", lock=True ) and cmds.setAttr( "lambert1.miNormalCameraX", 0.0 )', 'not cmds.getAttr( "lambert1.miNormalCameraY", lock=True ) and cmds.setAttr( "lambert1.miNormalCameraY", 0.0 )', 'not cmds.getAttr( "lambert1.miNormalCameraZ", lock=True ) and cmds.setAttr( "lambert1.miNormalCameraZ", 0.0 )', 'not cmds.getAttr( "lambert1.miFrameBufferWriteOperation", lock=True ) and cmds.setAttr( "lambert1.miFrameBufferWriteOperation", 1 )', 'not cmds.getAttr( "lambert1.miFrameBufferWriteFlags", lock=True ) and cmds.setAttr( "lambert1.miFrameBufferWriteFlags", 0 )', 'not cmds.getAttr( "lambert1.miFrameBufferWriteFactor", lock=True ) and cmds.setAttr( "lambert1.miFrameBufferWriteFactor", 1.0 )', 'not cmds.getAttr( "lambert1.miRefractionBlurLimit", lock=True ) and cmds.setAttr( "lambert1.miRefractionBlurLimit", 1 )', 'not cmds.getAttr( "lambert1.miScatterRadius", lock=True ) and cmds.setAttr( "lambert1.miScatterRadius", 0.0 )', 'not cmds.getAttr( "lambert1.miScatterColor", lock=True ) and cmds.setAttr( "lambert1.miScatterColor", 0.5, 0.5, 0.5 )', 'not cmds.getAttr( "lambert1.miScatterColorR", lock=True ) and cmds.setAttr( "lambert1.miScatterColorR", 0.5 )', 'not cmds.getAttr( "lambert1.miScatterColorG", lock=True ) and cmds.setAttr( "lambert1.miScatterColorG", 0.5 )', 'not cmds.getAttr( "lambert1.miScatterColorB", lock=True ) and cmds.setAttr( "lambert1.miScatterColorB", 0.5 )', 'not cmds.getAttr( "lambert1.miScatterAccuracy", lock=True ) and cmds.setAttr( "lambert1.miScatterAccuracy", 97 )', 'not cmds.getAttr( "lambert1.miScatterFalloff", lock=True ) and cmds.setAttr( "lambert1.miScatterFalloff", 0 )', 'not cmds.getAttr( "lambert1.miScatterLimit", lock=True ) and cmds.setAttr( "lambert1.miScatterLimit", 1 )', 'not cmds.getAttr( "lambert1.miScatterCache", lock=True ) and cmds.setAttr( "lambert1.miScatterCache", 0 )']
				for i in range( 0, len( m_lambertSettings )):
					try:
						eval( m_lambertSettings[i] )
					except:
						pass
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						cmds.hyperShade( m_items[i], assign="lambert1" )
						cmds.sets( m_items[i], edit=True, forceElement="initialShadingGroup" )
						if debug is True:
							print "Attach default material to %s" % str( m_items[i] )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#List all geometry node with non-manifold normals.
	#Modelling setup 8.
	if normals is not False:
		m_argument = "Normals direction"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if normals is True:
			m_nodes = cmds.ls( type="mesh", dag=True, ni=True, long=True )
			for i in range( 0, len( m_nodes )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List non manifold geometry normals.
				if m_nodes[i] not in m_default:
					m_solution = ""
					m_components = cmds.polyInfo( m_nodes[i], nonManifoldVertices=True )
					if m_components:
						m_components = cmds.ls( m_components, fl=True, long=True )
						for n in range( 0, len( m_components )):
							if len( cmds.ls( cmds.polyListComponentConversion( m_components[n], fromVertex=True, toEdge=True ), fl=True, long=True )) == len( cmds.ls( cmds.polyListComponentConversion( m_components[n], fromVertex=True, toFace=True ), fl=True, long=True )) and m_nodes[i] not in m_items:
								m_solution = m_solution + " -conform"
								break
					if m_solution:
						m_items.append( "%s %s" % ( m_nodes[i], m_solution ))
						if debug is True:
							print "Founded mesh with non-manifold normals: %s" % m_nodes[i]
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = normals
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						if "-conform" in m_items[i]:
							cmds.polyNormal( m_items[i].split( " -" )[0], normalMode=2, userNormalMode=1 )
						if "-reverse" in m_items[i]:
							cmds.polyNormal( m_items[i].split( " -" )[0], normalMode=0, userNormalMode=1 )
						if debug is True:
							print "Set normals direction for %s" % str( m_items[i] )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Freeze all transforms.
	#Modelling setup 0.
	if freeze is not False:
		m_argument = "Need to freeze transforms"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if freeze is True:
			m_transforms_cache = []
			m_transforms = cmds.ls( dag=True, type="transform", long=True, ni=True )
			for i in range( 0, len( m_transforms )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List transforms with non zero translates and without connections.
				if m_transforms[i] not in m_default and m_transforms[i] not in m_items and m_transforms[i] not in m_transforms_cache:
					m_transforms_cache.append( m_transforms[i] )
					m_type = cmds.nodeType( m_transforms[i] )
					m_camera = cmds.ls( m_transforms[i], dag=True, cameras=True )
					if m_type == "transform" and not m_camera:
						m_translate = cmds.getAttr( "%s.t" % m_transforms[i] )[0]
						if ( round( m_translate[0], 2 ) != 0.0 or round( m_translate[1], 2 ) != 0.0 or round( m_translate[-1], 2 ) != 0.0 ):
							#Current transform connections and lock statement.
							m_bool = True
							m_shapes = cmds.ls( m_transforms[i], dag=True, long=True )
							if cmds.listConnections( m_shapes, type="blendShape" ):
								m_bool = False
							if cmds.listConnections( m_shapes, type="skinCluster" ):
								m_bool = False
							if cmds.nodeType( m_transforms[i] ) != "transform":
								m_bool = False
							if m_bool is True:
								m_childrens = cmds.ls( m_transforms[i], dag=True, type="transform", long=True )
								for n in range( 0, len( m_childrens )):
									m_attributes = [ "%s.t" % m_childrens[n], "%s.tx" % m_childrens[n], "%s.ty" % m_childrens[n], "%s.tz" % m_childrens[n] ]
									for s in range( 0, len( m_attributes )):
										if cmds.getAttr( m_attributes[s], lock=True ) or cmds.listConnections( m_attributes[s] ):
											m_bool = False
											break
									if m_bool is False:
										break
							if m_bool is True:
								m_items.append( m_transforms[i] )
								if debug is True:
									print "Founded transform with non zero translates: %s" % m_transforms[i]
								continue
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = freeze
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						cmds.makeIdentity( m_items[i], translate=True, apply=True )
						if re.findall( "^general_CT$", m_items[i] ):
							cmds.move( 0, 0, 0, m_items[i], rotatePivotRelative=True )
							cmds.makeIdentity( m_items[i], translate=True, apply=True )
							if debug is True:
								print "Make zero translate: %s" % m_items[i]
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Setup displacement bound for geometry with enabled displacement.
	#Texture setup 8.
	if displacement is not False:
		ml_loadPlugins()
		ml_loadSlim()
		ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim2.tcl", debug=debug )
		m_argument = "Displacement bound"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if displacement is True:
			m_slim_nodes = ml_slimCmd( "tc_findNodeByAttr enableDisplacement 0 id", debug=debug )
			if m_slim_nodes:
				m_slim_nodes = m_slim_nodes[0].split( " " )
				m_nodes = ml_listAttached( cmds.ls( dag=True, long=True, type="mesh", visible=True, ni=True ), debug=False )
				m_nodes_keys = m_nodes.keys()
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List nodes with displacement.
				for i in range( 0, len( m_slim_nodes )):
					if m_slim_nodes[i] in m_nodes_keys:
						m_temp = m_nodes[ m_slim_nodes[i] ]
						for n in range( 0, len( m_temp )):
							if m_temp[n] not in m_items:
								m_items.append( m_temp[n] )
								if debug is True:
									print "Founded node with enabled displacement: %s" % m_temp[n]
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = displacement
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				m_items = [ m_items[i] for i in range( 0, len( m_items )) if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ) ]
				#Turn off displacement bound. 
				m_slim_nodes = ml_slimCmd( "tc_findNodeByAttr enableDisplacement 0 id", debug=debug )
				if m_slim_nodes:
					m_slim_nodes = m_slim_nodes[0].split( " " )
					for i in range( 0, len( m_slim_nodes )):
						m_func = ml_slimCmd( "tc_list -id %s" % m_slim_nodes[i], debug=debug )
						if m_func:
							m_parm = ml_slimCmd( "tc_listAttr %s ^displacementbound$" % m_func[0], debug=debug )
							if m_parm:
								ml_slimCmd( "%s SetValue 0" % m_parm[0], debug=debug )
				#Rename nodes to temp name.
				m_nodes = []
				for i in range( 0, len( m_items )):
					if cmds.objExists( m_items[i] ) and not cmds.referenceQuery( m_items[i], isNodeReferenced=True ):
						m_fullname = "_db_".join( m_items[i].split( "|" ))
						m_items[i] = cmds.rename( m_items[i], m_fullname )
						m_nodes.append( m_items[i] )
						if cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=m_items[i], exists=True ):
							ml_setAttr( "%s.rman__riattr__displacementbound_sphere" % m_items[i], 0, debug=debug )
				#Get statistic.
				if m_nodes:
					m_xml_file = ml_statistic( m_nodes, debug=debug )
					m_xml_string = file( m_xml_file, "r" ).read()
					m_xml = xml.etree.ElementTree.fromstring( m_xml_string )
					m_top_lvl = m_xml.findall( "*//stats" )
					#Add displacement bound attribute to mesh.
					if debug is True:
						print m_xml_file
					for i in range( 0, len( m_nodes )):
						#Read statistic.
						ml_bound = []
						for f in range( 0, len( m_top_lvl )):
							if m_top_lvl[f].get( "name" ) == "dispBound":
								m_law = False
								m_bound_info = m_top_lvl[f].findall( "*" )
								for n in range( 0, len( m_bound_info )):
									if m_bound_info[n].get( "name" ) == "objectName":
										if m_bound_info[n].text == m_nodes[i]:
											m_law = True
											continue
									if m_law is True:
										if m_bound_info[n].get( "name" ) == "displacement":
											ml_bound.append( float( m_bound_info[n].text ))
											print m_bound_info[n].text
											break
						#Set displacement bound attribute.
						if ml_bound:
							ml_bound = sum( ml_bound ) * 1.5
							if not cmds.attributeQuery( "rman__riattr__displacementbound_sphere", n=m_nodes[i], exists=True ):
								ml_addRmanAttr( m_nodes[i], "rman__riattr__displacementbound_sphere", ml_bound, debug=debug )
							else:
								ml_setAttr( "%s.rman__riattr__displacementbound_sphere" % m_nodes[i], ml_bound, debug=debug )
							if not cmds.attributeQuery( "rman__riattr__displacementbound_coordinatesystem", n=m_nodes[i], exists=True ):
								ml_addRmanAttr( m_nodes[i], "rman__riattr__displacementbound_coordinatesystem", "shader", debug=debug )
							else:
								cmds.setAttr( "%s.rman__riattr__displacementbound_coordinatesystem" % m_nodes[i], "shader", type="string" )
					#Remove renderman trash.
					m_render_trash = cmds.ls( type="RenderMan" )
					if m_render_trash:
						cmds.delete( m_render_trash )
					#Rename nodes to original name.
					for i in range( 0, len( m_items )):
						m_fullname = m_items[i].split( "_db_" )[-1]
						m_items[i] = cmds.rename( m_items[i], m_fullname )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
		#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Setup attributes in all nodes.
	#Texture setup 1, 1, 6, 9, 10, 11
	#Modelling setup 5, 11				
	if attributes is not False:
		m_argument = "Maya node attributes"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if attributes is True:
			m_nodes = cmds.ls( type=[ "transform", "mesh", "nurbsCurve" ], long=True, ni=True )
			for i in range( 0, len( m_nodes )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#List nodes with non-manifold attributes.
				m_info = ""
				if cmds.nodeType( m_nodes[i] ) == "mesh":
					if not cmds.attributeQuery( "rman__torattr___subdivScheme", n=m_nodes[i], exists=True ):
						m_info = m_info + " -add rman__torattr___subdivScheme;"
					if cmds.attributeQuery( "rman__torattr___invis", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___invis" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___invis;"
					if cmds.attributeQuery( "castsShadows", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.castsShadows" % m_nodes[i] ) and cmds.getAttr( "%s.castsShadows" % m_nodes[i] ) != 1:
						m_info = m_info + " -set castsShadows -int 1;"
					if cmds.attributeQuery( "receiveShadows", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.receiveShadows" % m_nodes[i] ) and cmds.getAttr( "%s.receiveShadows" % m_nodes[i] ) != 1:
						m_info = m_info + " -set receiveShadows -int 1;"
					if cmds.attributeQuery( "primaryVisibility", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.primaryVisibility" % m_nodes[i] ) and cmds.getAttr( "%s.primaryVisibility" % m_nodes[i] ) != 1:
						m_info = m_info + " -set primaryVisibility -int 1;"
					if cmds.attributeQuery( "motionBlur", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.motionBlur" % m_nodes[i] ) and cmds.getAttr( "%s.motionBlur" % m_nodes[i] ) != 1:
						m_info = m_info + " -set motionBlur -int 1;"
					if cmds.attributeQuery( "visibleInReflections", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.visibleInReflections" % m_nodes[i] ) and cmds.getAttr( "%s.visibleInReflections" % m_nodes[i] ) != 1:
						m_info = m_info + " -set visibleInReflections -int 1;"
					if cmds.attributeQuery( "visibleInRefractions", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.visibleInRefractions" % m_nodes[i] ) and cmds.getAttr( "%s.visibleInRefractions" % m_nodes[i] ) != 1:
						m_info = m_info + " -set visibleInRefractions -int 1;"
					if cmds.attributeQuery( "doubleSided", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.doubleSided" % m_nodes[i] ) and cmds.getAttr( "%s.doubleSided" % m_nodes[i] ) != 0:
						m_info = m_info + " -set doubleSided -int 0;"
					if cmds.attributeQuery( "opposite", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.opposite" % m_nodes[i] ) and cmds.getAttr( "%s.opposite" % m_nodes[i] ) != 0:
						m_info = m_info + " -set opposite -int 0;"
					if cmds.attributeQuery( "displaySmoothMesh", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.displaySmoothMesh" % m_nodes[i] ) and cmds.getAttr( "%s.displaySmoothMesh" % m_nodes[i] ) != 0:
						m_info = m_info + " -set displaySmoothMesh -int 0;"
					if cmds.attributeQuery( "smoothShading", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.smoothShading" % m_nodes[i] ) and cmds.getAttr( "%s.smoothShading" % m_nodes[i] ) != 1:
						m_info = m_info + " -set smoothShading -int 1;"
					if cmds.attributeQuery( "castsShadows", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.castsShadows" % m_nodes[i] ) and cmds.getAttr( "%s.castsShadows" % m_nodes[i] ) != 1:
						m_info = m_info + " -set castsShadows -int 1;"
				elif cmds.nodeType( m_nodes[i] ) == "transform":
					if cmds.attributeQuery( "rman__torattr___invis", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___invis" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___invis;"
					if cmds.attributeQuery( "rman__torattr___subdivScheme", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___subdivScheme" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___subdivSchem;e"
					if cmds.attributeQuery( "rman__torattr___slimShader", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.rman__torattr___slimShader" % m_nodes[i] ):
						m_info = m_info + " -rebind rman__torattr___slimShader;"
					if cmds.attributeQuery( "rman__torattr___slimSurface", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.rman__torattr___slimSurface" % m_nodes[i] ):
						m_info = m_info + " -rebind rman__torattr___slimSurface;"
				elif cmds.nodeType( m_nodes[i] ) == "nurbsCurve":
					if not cmds.attributeQuery( "rman__torattr___invis", n=m_nodes[i], exists=True ):
						m_info = m_info + " -add rman__torattr___invis;"
					if cmds.attributeQuery( "rman__torattr___subdivScheme", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___subdivScheme" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___subdivScheme;"
					if cmds.attributeQuery( "rman__torattr___slimShader", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimShader" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___slimShader;"
					if cmds.attributeQuery( "rman__torattr___slimSurface", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimSurface" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___slimSurface;"
					if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimEnsemble" % m_nodes[i] ):
						m_info = m_info + " -remove rman__torattr___slimEnsemble;"
				if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=m_nodes[i], exists=True ) and cmds.getAttr( "%s.rman__torattr___slimEnsemble" % m_nodes[i] ):
					m_info = m_info + " -ensemble;"
					m_info = m_info + " -rebind;"
				if cmds.attributeQuery( "rman__torattr___slimShader", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimShader" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___slimShader" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___slimShader;"		
				if cmds.attributeQuery( "rman__torattr___slimSurface", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimSurface" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___slimSurface" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___slimSurface;"		
				if cmds.attributeQuery( "rman__torattr___slimEnsemble", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___slimEnsemble" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___slimEnsemble" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___slimEnsemble;"	
				if cmds.attributeQuery( "rman__torattr___postShapeScript", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___postShapeScript" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___postShapeScript" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___postShapeScript;"	
				if cmds.attributeQuery( "rman__torattr___postTransformScript", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___postTransformScript" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___postTransformScript" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___postTransformScript;"	
				if cmds.attributeQuery( "rman__torattr___preShapeScript", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___preShapeScript" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___preShapeScript" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___preShapeScript;"	
				if cmds.attributeQuery( "rman__torattr___transformBeginScript", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___transformBeginScript" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___transformBeginScript" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___transformBeginScript;"	
				if cmds.attributeQuery( "rman__torattr___transformEndScript", n=m_nodes[i], exists=True ) and not cmds.listConnections( "%s.rman__torattr___transformEndScript" % m_nodes[i] ) and not cmds.getAttr( "%s.rman__torattr___transformEndScript" % m_nodes[i] ):
					m_info = m_info + " -remove rman__torattr___transformEndScript;"
				if m_info:
					m_items.append( "%s%s" % ( m_nodes[i], m_info ))
					if debug is True:
						if m_items:
							print "Founded non-manifold attributes: %s" % m_items[-1]
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = attributes
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					m_node = m_items[i].split( " " )[0]
					m_args = m_items[i].split( "%s " % m_node )[-1]
					m_args = m_args.split( ";" )
					if cmds.objExists( m_node ) and not cmds.referenceQuery( m_node, isNodeReferenced=True ):
						for n in range( 0, len( m_args )):
							if "-remove" in m_args[n]:
								m_target = m_args[n].split( "-remove " )[-1]
								ml_deleteAttr( '%s.%s' % ( m_node, m_target ), debug=debug )
							if "-add" in m_args[n]:
								m_target = m_args[n].split( "-add " )[-1]
								ml_addRmanAttr( m_node, m_target, "", debug=debug )
							if "-set" in m_args[n]:
								m_target = ( m_args[n].split( "-set " )[-1] ).split( " -" )[0]
								if "-int" in m_args[n]:
									m_value = int( m_args[n].split( "-int " )[-1])
								elif "-float" in m_args[n]:
									m_value = float( m_args[n].split( "-float " )[-1])
								elif "-str" in m_args[n]:
									m_value = str( m_args[n].split( "-str " )[-1])
								ml_setAttr( "%s.%s" % ( m_node, m_target ), m_value, debug=debug )
							if "-ensemble" in m_args[n]:
								if cmds.attributeQuery( 'rman__torattr___slimEnsemble', n=m_node, exists=True ):
									m_ensemble = cmds.getAttr( '%s.rman__torattr___slimEnsemble' % m_node )
									m_materials = ml_slimCmd( 'tc_ensembleProperty -id %s' % m_ensemble, debug=debug)
									if m_materials:
										m_materials = m_materials[0].split( ' ' )
										ml_deleteAttr( '%s.rman__torattr___slimEnsemble' % m_node, debug=debug )
										ml_addRmanAttr( m_node, 'rman__torattr___slimSurface', m_materials[0], debug=debug )
										if m_materials[1:]:
											ml_addRmanAttr( m_node, 'rman__torattr___slimShader', ','.join( m_materials[1:] ), debug=debug )
							if "-rebind" in m_args[n]:
								m_attributes = [ 'rman__torattr___slimShader', 'rman__torattr___slimSurface', 'rman__torattr___slimEnsemble' ]
								for n in range( 0, len( m_attributes )):
									ml_flatRmanAttr( m_node, m_attributes[n], debug=debug )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Make masks.
	#Texture setup 0.
	if masks is not False:
		m_argument = "Make masks"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if masks is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#Get slim nodes needed to create mask.
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			pass
		else:
			m_items = masks
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				pass
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Setup slim nodes attributes and hierarchy.
	#Slim setup 1, 2, 3, 7, 8, 10, 11, 12, 13, 14, 15, 16.
	if slim is not False:
		ml_loadPlugins()
		ml_loadSlim()
		ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim2.tcl", debug=debug )
		m_argument = "Slim nodes hierarchy"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if slim is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List all can be repaired slim nodes.
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			m_palettes = ml_listPalettes()
			m_palettes_keys = m_palettes.keys()
			for i in range( 0, len( m_palettes_keys )):
				for s in range( 0, len( m_palettes[ m_palettes_keys[i] ] )):
					m_nodes = ml_slimCmd( "[ tc_list -id %s] GetAppearances" % m_palettes[ m_palettes_keys[i] ][s], debug=debug )
					m_nodes = m_nodes and m_nodes[0].split( " " ) or []
					for n in range( 0, len( m_nodes )):
						m_action = ml_slimCmd( "tc_cleanup [ %s GetID ] -query" % m_nodes[n], debug=debug )
						m_action = m_action and m_action[0] or []
						if m_action and m_action not in m_items:
							m_action_len = len( m_action.split( " " ) )
							if m_action_len > 1:
								m_items.append( "%s %s" % ( m_action, "-file %s" % m_palettes_keys[i].split( "{" )[0] ))
		else:
			m_items = slim
		if m_items:
			m_result.update( { m_argument:m_items } )
			if query is False:
				for i in range( 0, len( m_items )):
					m_reference = m_items[i].split( " -file " )[-1]
					m_action = m_items[i].split( " -file " )[0]
					if m_file == m_reference:
						ml_slimCmd( "tc_cleanup %s" % m_action, debug=debug )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Rename slim nodes.
	#Slim setup 4.
	if slimNames is not False:
		ml_loadPlugins()
		ml_loadSlim()
		ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim2.tcl", debug=debug )
		m_argument = "Slim synchronise names with maya"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if slimNames is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List nodes.
			m_nodes = {}
			m_references = listReferences()
			if m_references:
				for i in range( 0, len( m_references )):
					m_content = cmds.ls( cmds.referenceQuery( m_references[i], nodes=True, dagPath=True ), long=True, type=[ "mesh" ] )
					m_nodes.update( { m_references[i]:m_content } )
			else:
				m_nodes.update( { m_file:cmds.ls( long=True, type=[ "mesh" ] ) } )
			m_nodes_keys = m_nodes.keys()
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#List all can be renamed slim nodes.
			for s in range( 0, len( m_nodes_keys )):
				m_temp = ml_listAttached( m_nodes[m_nodes_keys[s]], debug=debug )
				m_temp_keys = m_temp.keys()
				m_temp_count = len( m_temp_keys )
				for i in range( 0, len( m_temp_keys )):
					if m_temp_count > 1:
						m_shablon = cmds.referenceQuery( m_temp[ m_temp_keys[i] ][0], isNodeReferenced=True ) and cmds.referenceQuery( m_temp[ m_temp_keys[i] ][0], filename=True ).split( "/" )[-1] or m_file.split( "/" )[-1] or "untitled"
						m_shablon = m_shablon.split( "." )[0]
					else:
						m_shablon = "root"
					m_reference = m_nodes_keys[s]
					m_bool = ml_slimCmd( "tc_renameHierarchy %s -id %s -query" % ( m_shablon, m_temp_keys[i] ), debug=debug )
					m_bool = m_bool and m_bool[0] or False
					if m_bool != "True":
						m_action = "%s -rename %s -file %s" % ( m_temp_keys[i], m_shablon, m_reference )
						if m_action not in m_items:
							m_items.append( m_action )
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = slimNames
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					m_id = m_items[i].split( " -" )[0]
					m_reference = m_items[i].split( "-file " )[-1]
					m_shablon = ( m_items[i].split( "-rename " )[-1]).split( " -file" )[0]
					if m_file == m_reference:
						ml_slimCmd( "tc_renameHierarchy %s -id %s" % ( m_shablon, m_id ), debug=debug )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Bake slim color to geometry.
	#Texture setup 0.
	if colors is not False:
		m_argument = "Bake colors"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if colors is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#Get geometry nodes needed to bake colors.
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			pass
		else:
			m_items = colors
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				pass
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Make unique slim id.
	#Texture setup 0.
	if uniqueifySlim is not False:
		m_argument = "Uniqueify scene slim id"
		m_step = m_step + 1
		ml_loadPlugins()
		ml_loadSlim()
		ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim2.tcl", debug=debug )
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if uniqueifySlim is True:
			m_references = listReferences( unique=True )
			m_ids = []
			for i in range( 0, len( m_references )):
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
				#Get references with similar id.
				m_reference_path = m_references[i].split( "{" )[0]
				m_content = cmds.ls( cmds.referenceQuery( m_references[i], nodes=True, dagPath=True ), long=True, type="mesh", ni=True )
				m_content = ml_listAttached( m_content, debug=False )
				m_content = m_content.keys()
				if m_content:
					for n in range( 0, len( m_content )):
						if m_content[n] not in m_ids:
							m_ids.append( m_content[n] )
						else:
							m_items.append( m_reference_path )
							if debug is True:
								print "Founded not unique slim id: %s" % m_reference_path
							break
				#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				if m_file in m_items:
					ml_slimCmd( "tc_uniqueifyAll", debug=debug, message=True )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Combine all slim palettes in one palette.
	#Slim setup 0.
	if combineSlim is not False:
		m_argument = "Combine slim palettes"
		ml_loadPlugins()
		ml_loadSlim()
		ml_slimCmd( "source " + ( sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project" ) + "/lib/setup/rfm180/tc_slim2.tcl", debug=debug )
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if combineSlim is True:
			m_palettes = ml_listPalettes()
			m_palettes_keys = m_palettes.keys()
			for i in range( 0, len( m_palettes_keys )):
				if len( m_palettes[ m_palettes_keys[i] ] ) > 1:
					m_items.append( m_palettes_keys[i].split( "{" )[0] )
		else:
			m_items = combineSlim
		if m_items:
			m_result.update( { m_argument:m_items } )
			if query is False:
				for i in range( 0, len( m_items )):
					if m_file == m_items[i]:
						ml_slimCmd( "tc_combinePalettes %s" % m_scene, debug=debug, message=True )
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Rename all non-manifold named nodes.
	#Modelling setup 2.
	if mayaNames is not False:
		m_argument = "Incorrect maya names"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if mayaNames is True:
			m_nodes = cmds.ls( dag=True, long=True, ni=True, shapes=True )
			for i in range( 0, len( m_nodes )):
				if m_nodes[i] not in m_default:
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
					#List all non-manifold named nodes.
					m_rec = re.compile( "pPipe|pPlane|polySurface|pCylinder|pTorus|pPyramid|pCone|pCube|pSphere|nurbsPlan|nurbsTorus|nurbsCone|nurbsCylinder|nurbsCube|nurbsSphere|root[A-z0-9_|]+root", re.IGNORECASE )
					m_parent = cmds.listRelatives( m_nodes[i], parent=True, fullPath=True )
					if m_parent:
						m_parent = m_parent[0]
						if ( m_rec.findall( m_nodes[i] ) and m_nodes[i] not in m_items ) or ( m_rec.findall( m_parent ) and m_parent not in m_items ):
							m_name = generateName( m_nodes[i], names=m_names )
							m_names.append( m_name )
							m_items.append( "%s -rename %s" % ( m_parent, m_name ))
							if debug is True:
								print "Founded non-manifold name: %s" % m_nodes[i]
						elif len( searchNode( m_nodes[i].split( "|" )[-1] )) > 1:
							m_shablon = (m_parent.split( "|" )[-1])
							if "_" in m_shablon:
								m_shablon = m_shablon.split( "_" )[0]
							m_name = generateName( m_nodes[i], names=m_names, shablon=m_shablon )
							m_name = m_name.split( ":" )[-1]
							m_names.append( m_name )
							m_items.append( "%s -rename %s" % ( m_parent, m_name ))
							if debug is True:
								print "Founded not unique name: %s" % m_nodes[i]
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = mayaNames
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					m_node = m_items[i].split( "-rename " )[0]
					m_name = m_items[i].split( "-rename " )[-1]
					if cmds.objExists( m_node ) and not cmds.referenceQuery( m_node, isNodeReferenced=True ):
						if "-rename" in m_items[i]:
							if cmds.objExists( m_node ):
								if debug is True:
									print "Rename: %s to %s" % ( m_node, m_name )
								m_node = cmds.rename( m_node, m_name )
								m_temp = m_items[i].replace( m_items[i].split( "|" )[-1], m_node )
								ml_update_content( m_temp, m_items[i] )
								m_shape = cmds.listRelatives( m_node, children=True, shapes=True, fullPath=True )
								for n in range( 0, len( m_shape )):
									m_temp = cmds.rename( m_shape[n], "%sShape" % m_node )
									m_temp = m_shape[n].replace( m_shape[n].split( "|" )[-1], m_node )
									ml_update_content( m_temp, m_shape[n] )
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	#____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	#Parent to root group all transforms.
	#Modelling setup 1, 3, 7, 12
	if hierarchy is not False:
		m_argument = "Maya nodes hierarchy"
		m_step = m_step + 1
		print ""
		print "( %s\\%s ) %s " % ( m_step, m_arguments, m_argument )
		print "__________________________________________________________________________________________________________________________________________"
		m_items = []
		if hierarchy is True:
			#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
			#Get top level transforms from current referenced objects.
			m_references = ml_assemblies()
			m_references_keys = m_references.keys()
			m_cameras = cmds.listCameras()
			m_cameras = "|".join(( "\|".join(("<>".join( m_cameras )).split( "|" ))).split( "<>" ))
			for i in range( 0, len( m_references_keys )):
				if not re.findall( "proxy.mb|proxy.ma", m_references_keys[i], re.IGNORECASE ):
					#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _	
					#Get info about hierarchy.
					m_transforms = m_references[ m_references_keys[i] ]
					m_transforms = [ m_transforms[n] for n in range( 0, len( m_transforms )) if not re.findall( m_cameras, m_transforms[n] ) ]
					if m_transforms:
						m_root = ""
						m_geometry = ""
						m_rig = ""
						m_controls = False
						#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
						#Root exists.
						for s in range( 0, len( m_transforms )):
							if re.findall( "root$", m_transforms[s] ) and m_transforms[s] not in m_default:
								m_root = m_transforms[s]
								break
						if m_root:
							m_childs = cmds.listRelatives( m_root, children=True, fullPath=True )
							m_childs = m_childs and m_childs or []
							#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
							#Geometry group exists.
							for s in range( 0, len( m_childs )):
								if re.findall( "geo_normal$|geometry$|geometry_grp$", m_childs[s], re.IGNORECASE ):
									m_geometry = m_childs[s]
									break
							if m_geometry == "":
								m_geometry = "%s|geo_normal" % m_root
							#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
							#Rigging group exists.
							for s in range( 0, len( m_childs )):
								if re.findall( "rig", m_childs[s], re.IGNORECASE ):
									m_rig = m_childs[s]
									m_controls = True
									break
							if m_rig == "":
								m_rig = "%s|rig" % m_root
							#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
							#Unknown groups exists.
							for s in range( 0, len( m_childs )):
								if not cmds.ls( m_childs[s], dag=True, type="nurbsCurve" ):
									if m_childs[s] != m_rig and m_childs[s] != m_geometry:
										m_action = "%s -parent %s" % ( m_childs[s], m_geometry)
										if m_action not in m_items:
											m_items.append( m_action )
											if debug is True:
												print "Founded unknown transforms in root directory: %s" % m_childs[s]
							for s in range( 0, len( m_transforms )):
								if m_transforms[s] != m_root and m_transforms[s] not in m_default and not re.findall( "^\%s" % m_root, m_transforms[s] ):
									m_action = "%s -parent %s" % ( m_transforms[s], m_geometry )
									if m_action not in m_items:
										m_items.append( m_action )
										if debug is True:
											print "Founded unknown transforms: %s" % m_transforms[s]
						else:
							m_root = "|root"
							m_geometry = "|root|geo_normal"
							m_rig = "|root|rig"
							for s in range( 0, len( m_transforms )):
								if m_transforms[s] not in m_default:
									m_action = "%s -parent %s" % ( m_transforms[s], m_geometry )
									if m_action not in m_items:
										m_items.append( m_action )
										if debug is True:
											print "Failed to find root directory: %s" % m_transforms[s]
						#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _	
						#Root another names exists.
						for n in range( 0, len( m_transforms )):
							if m_transforms[n] not in m_default:
								m_content = ml_getDescendents( m_transforms[n] )
								if m_content:
									for s in range( 0, len( m_content )):
										if re.findall( "root$", m_content[s] ) and m_content[s] != m_root:
											m_name = generateName( m_content[s], names=m_names )
											m_names.append( m_name )
											m_action = "%s -rename %s" % ( m_content[s], m_name )
											if m_action not in m_items:
												m_items.append( m_action )
												if debug is True:
													print "Founded unknown root transform: %s" % m_content[s]
						#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _	
						#Controls exists.
						if m_controls is False:
							m_action = "%s -control full %s|rig" % ( m_geometry, m_root )
							if m_action not in m_items:
								m_items.append( m_action )
								if debug is True:
									print "Failed to find controls for: %s" % m_root
						else:
							if cmds.ls( m_rig, dag=True, type="nurbsCurve" ):
								if not cmds.listConnections( cmds.ls( m_rig, dag=True, type="transform", long=True ), source=False, destination=True ):
									m_action = "%s -delete" % m_rig
									if m_action not in m_items:
										m_items.append( m_action )
										if debug is True:
											print "Founded not used rig: %s" % m_rig
									m_action = "%s -control full %s" % ( m_geometry, m_rig )
									if m_action not in m_items:
										m_items.append( m_action )
								else:
									m_childs = cmds.listRelatives( m_rig, children=True, fullPath=True )
									if len( m_childs ) == 1 and cmds.listConnections( m_childs[0] ):
										m_action = "%s -control parent %s" % ( m_childs[0] , m_rig + "|general_CT")
										if m_action not in m_items:
											m_items.append( m_action )
											if debug is True:
												print "Failed to find parent control: %s" % m_childs[0]
							else:
								m_action = "%s -control full %s" % ( m_geometry, m_rig )
								if m_action not in m_items:
									m_items.append( m_action )
									if debug is True:
										print "Failed to find controls: %s" % m_rig
						#_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
		else:
			m_items = hierarchy
		if m_items:
			m_result.update( { m_argument:m_items  } )
			if query is False:
				for i in range( 0, len( m_items )):
					m_node = m_items[i].split( " -" )[0]
					if cmds.objExists( m_node ) and not cmds.referenceQuery( m_node, isNodeReferenced=True ):
						m_action = "-" + m_items[i].split( "%s -" % m_node )[-1]
						if "-parent" in m_action:
							m_target = m_action.split( "-parent " )[-1]
							if cmds.objExists( m_target ):
								cmds.parent( m_node, m_target )
								ml_replace( m_target + m_node, m_node, m_items )
								ml_update_content( m_target + m_node, m_node )
							else:
								makeTransform( m_target )
								cmds.parent( m_node, m_target )
								ml_replace( m_target + m_node, m_node, m_items )
								ml_update_content( m_target + m_node, m_node )
							if debug is True:
								print "Parent: %s to %s" % ( m_node, m_target )
						elif "-control" in m_action:
							m_target = m_action.split( "-control " )[-1]
							if "full" in m_target:
								m_rig = m_target.split( "full " )[-1]
								makeTransform( m_rig )
								m_generalCT_offset = ml_createCurveControl( name='general_offset_CT', parent=m_rig, size=m_node, target=m_node, constraint=True, debug=debug )
								m_generalCT = ml_createCurveControl( name='general_CT', parent="root|rig", size=m_generalCT_offset, target=m_generalCT_offset, constraint=False, debug=debug )
							elif "constraint" in m_target:
								m_target = m_target.split( "constraint " )[-1]
								m_rig = makeTransform( "|".join( m_target.split( "|" )[:-1]))
								m_control_name = m_target.split( "|" )[-1]
								ml_createCurveControl( name=m_control_name, parent=m_rig, size=m_node, target=m_node, constraint=True, debug=debug )
							elif "parent" in m_target:
								m_target = m_target.split( "parent " )[-1]
								m_rig = makeTransform( "|".join( m_target.split( "|" )[:-1]))
								m_control_name = m_target.split( "|" )[-1]
								ml_createCurveControl( name=m_control_name, parent=m_rig, size=m_node, target=m_node, constraint=False, debug=debug )
						elif "-delete" in m_action:
							try:
								cmds.delete( m_node )
								if debug is True:
									print "Delete: %s" % m_node
							except:
								print "Failed to delete %s" % m_node
						elif "-rename" in m_action:
							m_target = m_action.split( "rename " )[-1]
							try:
								cmds.rename( m_node, m_target )
								if debug is True:
									print "Rename: %s" % ( m_node, m_target )
								ml_replace( m_target, m_node, m_items )
								ml_update_content( m_target, m_node )
							except:
								print "Failed to rename %s" % m_node
		print "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _"
	return m_result
