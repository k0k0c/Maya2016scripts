def saveMayaNode( nodes, name='', directory='', manual=False ):
    
    def flattenList( src ):
    
        def flattenList_proc( var ):
        
            isinstance( var, ( list, tuple )) and [ [ ( yield element ) for element in flattenList( object ) ] for object in var ] or ( yield var )
    
        return list( flattenList_proc( src ))
    
	
    file = open( directory + name + '.pynode', "w" )                   
    file.write( '' )
    file.close()
    result = ''
    nodes = 'list' in str( type( nodes )) and nodes or [ nodes ]
    name = name != '' and name or ( cmds.file( query=True, sceneName=True ).split( '/' )[-1] ).split('.')[0] or 'untitled'
    types = [ 'float', 'long', 'double', 'enum', 'byte', 'short2', 'short3', 'long2', 'long3', 'float2', 'float3', 'double2', 'vectorArray', 'doubleAngle', 'doubleLinear', 'double3', 'stringArray', 'string','Int32Array', 'doubleArray', 'pointArray', 'vectorArray', 'bool' ]
    
    nodes_temp = []
    for i in range( 0, len( nodes )):
        node_ch = cmds.ls( nodes[i], dag=True )
        if nodes[i] not in nodes_temp:
            nodes_temp.append( nodes[i])
        for n in range( 0, len( node_ch )):
            if node_ch[n] not in nodes_temp:
                nodes_temp.append( node_ch[n])
    nodes = nodes_temp	
    if manual is False:
        for i in range( 0, len( nodes )):
            nodes_con = cmds.listConnections( nodes[i] )
            if nodes_con:
                for n in range( 0, len( nodes_con )):
                    if 'dagNode' not in cmds.nodeType( nodes_con[n], inherited=True):
                        if nodes_con[n] not in nodes:
                            nodes.append( nodes_con[n] )		
    saveInfo = len( nodes )
    saveState = 0
    for i in range( 0, len( nodes )):
	
        result = ''
        saveState += 1
        print 'saving ( %s\\%s )' % ( str( saveState ), str( saveInfo ))
        result = result + '@NODE:'
        n_type = cmds.nodeType( nodes[i] )
        n_tag = 'transform' in cmds.nodeType( nodes[i], inherited=True) and 'transform' or 'shape'
        n_parent = ''
        n_parent = cmds.listRelatives( nodes[i], parent=True )
        n_attributes = cmds.listAttr( nodes[i], connectable=True, settable=True, hasData=True, read=True )
        if cmds.attributeQuery( 'message', n=nodes[i], exists=True ):
            n_attributes.append( 'message' )
           
        result = result + '\n\t$n_type = ' + n_type + ';'
        result = result + '\n\t$n_tag = ' + n_tag + ';'
        result = result + '\n\t$n_name = ' + nodes[i] + ';'
        if n_parent and 'dagNode' in cmds.nodeType( nodes[i], inherited=True):
            result = result + '\n\t$n_par = ' + n_parent[0] + ';'
        
        result = result + '\n'    
        if n_attributes:
            for n in range( 0, len( n_attributes )):
                if cmds.attributeQuery( n_attributes[n], n=nodes[i], exists=True):
                    result = result + '\n\t@ATTR:'
                    at_lock = cmds.getAttr( nodes[i] + '.' + n_attributes[n], lock=True ) is True and 1 or 0
                    at_type = cmds.getAttr( nodes[i] + '.' + n_attributes[n], type=True )
                    at_size = cmds.getAttr( nodes[i] + '.' + n_attributes[n], size=True )
                    at_settable = cmds.getAttr( nodes[i] + '.' + n_attributes[n], settable=True ) is True and 1 or 0
                    result = result + '\n\t\t$a_name = ' + str( n_attributes[n] ) + ';\n\t\t$a_lc = ' + str( at_lock ) + ';\n\t\t$a_tp = ' + str( at_type ) + ';\n\t\t$a_sz = ' + str( at_size ) + ';\n\t\t$a_st = ' + str( at_settable ) + ';'
                    if not cmds.listConnections( nodes[i] + '.' + n_attributes[n], plugs=True ) and at_type in types:
                        at_value = cmds.getAttr( nodes[i] + '.' + n_attributes[n], silent=True )
                        if at_value or at_value is False or at_value == 0:
                            bool_r = {True:1, False:0}
                            at_value = at_value not in bool_r.keys() and at_value or bool_r[at_value]
                            at_value = flattenList( at_value )
                            at_value = [ str( at_value[f]) for f in range( 0, len( at_value )) ]
                            at_value = ', '.join( at_value )
                            result = result + '\n\t\t$a_val = ' + str( at_value ) + ';'
                    else:
                        n_connections = cmds.listConnections( nodes[i] + '.' + n_attributes[n], plugs=True, connections=True )
                        if n_connections:
                            iter_attr = range( 0, len( n_connections ))
                            iter_attr = [ iter_attr[f] for f in range( 0, len( iter_attr )) if iter_attr[f] % 2 == 0 ]
                            for f in iter_attr:
                                if cmds.connectionInfo( n_connections[f], isExactSource=True ):
                                    src_connection = n_connections[f]
                                    dst_connection = n_connections[f+1]
                                else:
                                    src_connection = n_connections[f+1]
                                    dst_connection = n_connections[f]
                                result = result + '\n\t\t$a_con = ' + src_connection + ' to ' + dst_connection + ';'
        result = result + '\n\n'      
        file = open( directory + name + '.pynode', "a" )                   
        file.write( result )
        file.close()

def loadMayaNode( directory='' ):
    
    def clearConnections( node_current ):
            
        cur_attributes = cmds.listAttr( node_current, connectable=True, multi=True )
        for i in range( 0, len( cur_attributes )):
            if cmds.attributeQuery( cur_attributes[i], n=node_current, exists=True):
                cur_connections = cmds.listConnections( node_current + '.' + cur_attributes[i], plugs=True )
                if cur_connections:
                    for n in range( 0, len( cur_connections )):
                        if cmds.connectionInfo( cur_connections[n], isSource=True ):
                            src_connection = cur_connections[n]
                            dst_connection = node_current + '.' + cur_attributes[i]
                        else:
                            src_connection = node_current + '.' + cur_attributes[i] 
                            dst_connection = cur_connections[n]
                        cmds.disconnectAttr( src_connection, dst_connection )
                        
    def convertValue( value, attrType ):
            
            result_conv = ''
            defaultTypes = [ 'float', 'long', 'double', 'enum', 'byte', 'None', 'bool', 'doubleAngle', 'doubleLinear' ]
            stringTypes = [ 'string' ]
            stringArrays = [ 'stringArray' ]
            booleanType = [ 'bool' ]
            doubleTypes = [ 'short2', 'short3', 'long2', 'long3', 'float2', 'float3', 'double2', 'double3' ]
            arrayTypes = [ 'Int32Array', 'doubleArray', 'pointArray', 'matrix', 'vectorArray', 'vectorArray' ]
            if attrType in defaultTypes:
                result_conv = value
            elif attrType in stringTypes:
                result_conv = '"' + ( value is not None and value or '' ) + '", type="' + attrType + '"'
            elif attrType in stringArrays:
                result_conv = value.split(', ')
                result_convSize = str( len( result_conv ))
                result_conv = result_convSize + ', ' + ( '", "'.join( result_conv )) + ', type="' + attrType + '"'
            elif attrType in doubleTypes:
                result_conv = value + ', type="' + attrType + '"'
            elif attrType in arrayTypes:
                temp = value.split(', ')
                result_conv = str( len( temp )) + ', ' + value + ', type="' + attrType + '"'
            else:
                result_conv = value
            return result_conv  
    
    result = ''
    attr_types = { 'dt':'stringArray,string,short2,short3,spectrumRGB,long2,reflectance,long3,float2,float3,double2,double3,doubleArray,Int32Array,vectorArray,nurbsCurve,nurbsSurface,mesh,lattice,pointArray', 'at':'bool,long,short,byte,char,enum ,float,double,doubleAngle,spectrum,doubleLinear,compound,message,time,fltMatrix,spectrum,' }
    file = open( directory, 'r' )
    file = file.read()
    file = file.split( '@NODE:' )[1:]
    
    saveInfo = len( file )
    saveState = 0
    for i in range( 0, len( file )):
        result = ''
        saveState += 1
        print 'loading ( %s\\%s )' % ( str( saveState ), str( saveInfo ))
        node_name = '$n_name = ' in file[i] and ( file[i].split( '$n_name = ' )[-1] ).split(';', 1)[0] or ''
        node_type = '$n_type = ' in file[i] and ( file[i].split( '$n_type = ' )[-1] ).split(';', 1)[0] or ''
        node_tag = '$n_tag = ' in file[i] and ( file[i].split( '$n_tag = ' )[-1] ).split(';', 1)[0] or ''
        node_parent = '$n_par = ' in file[i] and ( file[i].split( '$n_par = ' )[-1] ).split(';', 1)[0] or ''
        node_str = '@ATTR:' in file[i] and file[i].split( '@ATTR:' )[1:] or ''
		
        if cmds.objExists( node_name ) and cmds.nodeType( node_name ) == node_type:
            node_current = node_name
            clearConnections( node_current )
        else:
            node_current = cmds.createNode( node_type, n=node_name + '_restored' )
            node_current = cmds.rename( node_current, node_current.split( '_restored' )[0] )
		
        if node_parent:
            if cmds.objExists( node_parent ):
                if node_tag == 'transform':
                    cmds.parent( node_current, node_parent )
                else:
                    old_parent = cmds.listRelatives( node_current, parent=True )[0]
                    cmds.parent( node_current, node_parent, relative=True, shape=True )
                    cmds.delete( old_parent )
        
        for n in range( 0, len( node_str )):
            attr_name = '$a_name = ' in node_str[n] and ( node_str[n].split( '$a_name = ' )[-1] ).split(';', 1)[0] or ''
            attr_lock = '$a_lc = ' in node_str[n] and ( node_str[n].split( '$a_lc = ' )[-1] ).split(';', 1)[0] or ''
            attr_type = '$a_tp = ' in node_str[n] and ( node_str[n].split( '$a_tp = ' )[-1] ).split(';', 1)[0] or ''
            attr_size = '$a_sz = ' in node_str[n] and ( node_str[n].split( '$a_sz = ' )[-1] ).split(';', 1)[0] or ''
            attr_settable = '$a_st = ' in node_str[n] and ( node_str[n].split( '$a_st = ' )[-1] ).split(';', 1)[0] or ''
            attr_value = '$a_val = ' in node_str[n] and ( node_str[n].split( '$a_val = ' )[-1] ).split(';', 1)[0] or ''
            attr_connected = '$a_con = ' in node_str[n] and ( node_str[n].split( '$a_con = ' )[1:] ) or ''
            
            if attr_name:
                if attr_type:
                    cmds.setAttr( node_current + '.' + attr_name, lock=0 )
                    if cmds.attributeQuery( attr_name, n=node_current, exists=True) is False:
                        if attr_type in attr_types['dt']:
                            cmds.addAttr( node_current, longName=attr_name, dataType=attr_type )
                        else:
                            cmds.addAttr( node_current, longName=attr_name, attributeType=attr_type )
                    if attr_size != '0' and attr_size != '1':
                        cmds.setAttr( node_current + '.' + attr_name, size=int( attr_size ) )
                    if attr_settable == '1':
                        if attr_value:
                            attr_value = convertValue( attr_value, attr_type )
                            cmds_setAttr = str( 'cmds.setAttr( "' + node_current + '.' + attr_name + '",' + attr_value + ' )' )
                            eval( cmds_setAttr )
                    if attr_connected:
                        for f in range( 0, len( attr_connected )):
                            attr_connected_temp = attr_connected[f].split(';', 1)[0]
                            attr_connected_temp = attr_connected_temp.replace( node_name, node_current )
                            if cmds.objExists( ( attr_connected_temp.split(' to ')[1]).split('.')[0] ) and cmds.objExists( ( attr_connected_temp.split(' to ')[0]).split('.')[0] ) and not cmds.isConnected( attr_connected_temp.split(' to ')[0], attr_connected_temp.split(' to ')[1] ):
                                cmds.connectAttr( attr_connected_temp.split(' to ')[0], attr_connected_temp.split(' to ')[1], force=True )
                    if attr_lock:
                        cmds.setAttr( node_current + '.' + attr_name, lock=int( attr_lock ) )
