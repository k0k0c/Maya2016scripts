#Last update:
#1646 ChangeReferenceToRenderVersion

import maya.cmds as cmds
import maya.mel as mel
import maya.OpenMaya as om
import maya.OpenMayaUI as omUI
import re
import os
import subprocess
import sys
import ast
import shutil
import math
import ml_removeUnusedNodes
import ml_transferAttributes
import ml_shadingRateFinal
import glob
reload( ml_transferAttributes )
reload( ml_removeUnusedNodes )
reload( ml_shadingRateFinal )
if cmds.pluginInfo('AbcExport',query=True, loaded=True) is False:
    try:
        cmds.loadPlugin('AbcExport')
    except:
        print 'Failed to load AbcExport'
OSTYPE = sys.platform
if OSTYPE == "win32":
    OSTYPE="//Server-3d/Project"
else:
    OSTYPE="/Server-3d/Project"

#CREATE INTERFACE


def CUTool_interface():
	#create main window
	if cmds.window("CUTool_window_00", exists=True):
		cmds.deleteUI("CUTool_window_00", window=True)
	cmds.window("CUTool_window_00", menuBar=True, title="SCENE SETUP",height=250,width=250)
	cmds.menu("CUTool_menu_00", label="File", parent="CUTool_window_00")
	cmds.menuItem(divider=True, parent="CUTool_menu_00")
	cmds.menuItem(label="Refresh", command='CUToolSetup.CUTool_interface()', parent="CUTool_menu_00")
	cmds.menuItem(divider=True, parent="CUTool_menu_00")
	cmds.menuItem(label="Settings", parent="CUTool_menu_00")
	cmds.menuItem(label="Help", parent="CUTool_menu_00")
	#create and print text info about scene
	cmds.columnLayout("CUTool_info_layout00",adjustableColumn=True,parent="CUTool_window_00")
	cmds.frameLayout("CUTool_info_layout00Frame",collapse=True,backgroundColor=[0.2,0.2,0.2],label="FILE INFO",borderStyle="etchedOut",collapsable=1,parent='CUTool_info_layout00')
	cmds.text("CUTool_info_text01", font="boldLabelFont", label="Text",backgroundColor=[0.15,0.15,0.15], align='left', wordWrap=True, parent="CUTool_info_layout00Frame")
	cmds.frameLayout("CUTool_frame_layout00_base_00", parent="CUTool_window_00",borderStyle="etchedOut",labelVisible=False)
	cmds.scrollLayout("CUTool_scroll_layout00", parent="CUTool_frame_layout00_base_00",childResizable=True)
	CUTool_updateInfo()
	#create tabs
	id_tabs,id_frame,tabs_names=CUTool_tabsLayout("CUTool_tabsLayout_00","CUTool_scroll_layout00",['Animatic','Shablon','Animation','Scene','Light', 'Modeling'])
	#frames setup for animatik
	cmds.frameLayout("CUTool_Animatic_setup_00",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 1) Clean setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic')]))
	cmds.frameLayout("CUTool_Animatic_setup_01",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 2) Animation setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic')]))
	cmds.frameLayout("CUTool_Animatic_setup_02",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 3) Cameras setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic')]))
	cmds.frameLayout("CUTool_Animatic_setup_03",collapse=True,backgroundColor=[0.3,0.3,0.2],label="(Step 4) Template setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic')]))
	cmds.frameLayout("CUTool_Animatic_setup_04",collapse=True,backgroundColor=[0.2,0.3,0.2],label="Offset animation",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animatic')]))
	#frames setup for shablon
	cmds.frameLayout("CUTool_Shablon_setup_00",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 1) Camera setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_01",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 2) Template setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_04",collapse=True,backgroundColor=[0.31,0.1,0.09],label="(Step 3) Characters setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_02",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 4) Animation setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_03",collapse=True,backgroundColor=[0.3,0.2,0.3],label="(Step 5) Reference setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_07",collapse=True,backgroundColor=[0.2,0.25,0.2],label="RIB setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_06",collapse=True,backgroundColor=[0.2,0.25,0.2],label="Dynamic and light shablon setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	cmds.frameLayout("CUTool_Shablon_setup_05",collapse=True,backgroundColor=[0.2,0.25,0.2],label="Transfer transform attributes",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Shablon')]))
	#animation setup
	cmds.frameLayout("CUTool_Animation_setup_00",collapse=True,backgroundColor=[0.25,0.35,0.3],label="Save loaded references statement",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animation')]))
	cmds.frameLayout("CUTool_Animation_setup_01",collapse=True,backgroundColor=[0.25,0.35,0.3],label="Animation ranges",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animation')]))
	cmds.frameLayout("CUTool_Animation_setup_02",collapse=True,backgroundColor=[0.25,0.35,0.3],label="Playblast",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animation')]))
	cmds.frameLayout("CUTool_Animation_setup_03",collapse=True,backgroundColor=[0.25,0.35,0.3],label="Sound",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animation')]))

	#cmds.frameLayout("CUTool_Animation_setup_02",collapse=True,backgroundColor=[0.25,0.35,0.3],label="Cache characters",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Animation')]))
	#frames setup for shablon
	cmds.frameLayout("CUTool_Scene_setup_00",collapse=True,backgroundColor=[0.2,0.2,0.3],label="Alembic setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Scene')]))
	cmds.frameLayout("CUTool_Scene_setup_01",collapse=True,backgroundColor=[0.24,0.24,0.34],label="Alembic setup PRO",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Scene')]))
	#frames setup for shablon
	cmds.frameLayout("CUTool_Light_setup_00",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Density",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_01",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Shading rate",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_12",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Final pass shading rate",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_13",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Shading rate custom pass options",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_02",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Light linking ",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_03",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Reference edits ",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_04",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Render preview ",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_05",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Bake brickmap",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_06",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Projections",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_07",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Hair display",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_08",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Spotlight to RMSGeoAreaLight",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_09",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Per frame batch render",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_10",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Dynamic rules manager",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	cmds.frameLayout("CUTool_Light_setup_11",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Slim shader instancer",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Light')]))
	#frames setup for modeling
	cmds.frameLayout("CUTool_modeling_setup_00",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Proxy setup",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Modeling')]))
	cmds.frameLayout("CUTool_modeling_setup_01",collapse=True,backgroundColor=[0.3,0.2,0.4],label="Transfer attributes",borderStyle="etchedOut",collapsable=1,parent=(id_frame[tabs_names.index('Modeling')]))
	#Directory buttons
	cmds.intFieldGrp("CUTool_Shablon_setup_animation_field",extraLabel=":  Start/End animation range",numberOfFields=2,value1=(cmds.playbackOptions(query=True,animationStartTime=True)),value2=(cmds.playbackOptions(query=True,animationEndTime=True)),parent="CUTool_Shablon_setup_02")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_02",['CUTool_Shablon_setup_animation_button_UpdateFrames'],"CUTool_Shablon_setup_02",26)
	CUTool_changeDirectory_button("CUTool_changeCameraDirectory", "CUTool_Shablon_setup_00",CUTool_findCams_File(),1,1)
	cmds.text("CUTool_UsedCameraInfo",align="left", label=("Used camera: "+(CUTool_findUsedCamera())), parent="CUTool_Shablon_setup_00")
	CUTool_changeDirectory_button("CUTool_changeTemplateDirectory", "CUTool_Shablon_setup_01",CUTool_findTemplate_File(),1,1)
	cmds.text("CUTool_UsedReferenceInfo",align="left", label=("Template statement: "+(CUTool_checkTmplateIsLoaded())), parent="CUTool_Shablon_setup_01")
	CUTool_changeDirectory_button("CUTool_changeAnimationileDirectory", "CUTool_Shablon_setup_02",CUTool_findAnimation_File(),0,1)
	CUTool_changeDirectory_button("CUTool_changeAnimationileDirectoryForSave", "CUTool_Animatic_setup_01",CUTool_findAnimation_File(),0,0)
	CUTool_changeDirectory_button("CUTool_changeCameraExportDirectory", "CUTool_Animatic_setup_02",CUTool_PathToCamera_File(),1,0)
	CUTool_changeDirectory_button("CUTool_changeTemplateExportDirectory", "CUTool_Animatic_setup_03",CUTool_PathToTemplate_File(),1,0)
	cmds.text(label="Path to cache folder:", align="left", parent="CUTool_Scene_setup_00")
	CUTool_changeDirectory_button("CUTool_changeABCExportDirectory", "CUTool_Scene_setup_00", FindAlembicSceneFolder(), 2, 3)
	cmds.textFieldGrp( "exportCacheDopName", label="Cache dop name:", columnAlign=[ 1, "left" ], parent="CUTool_Scene_setup_00" )
	cmds.text("CUTool_UsedDirecotryForSceneInfo",align="left", label="Path to target scene: ", parent="CUTool_Scene_setup_01")
	CUTool_changeDirectory_button("CUTool_changeABCExportDirectoryScenePRO", "CUTool_Scene_setup_01", OSTYPE+"/default", 1, 1)
	cmds.text("CUTool_UsedDirecotryForAlembicInfo",align="left", label="Custom directory for export cache: ", parent="CUTool_Scene_setup_01")
	CUTool_changeDirectory_button("CUTool_changeABCExportDirectoryAlembicPRO", "CUTool_Scene_setup_01", OSTYPE+"/default", 2, 3)
	cmds.checkBoxGrp('CUTool_ABCcheck_useCustomDirectory', v1=0, l="Use custom directory: ", parent='CUTool_Scene_setup_01', ann="Export alembic cache to custom directory.", cc='CUToolSetup.CUTool_blockCustomDirectory("CUTool_ABCcheck_useCustomDirectory", "CUTool_changeABCExportDirectoryAlembicPRO_textField")')
	cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelection', label='Export mode: ', labelArray2=['All','Chars'], numberOfRadioButtons=2, select=2, editable=True, parent='CUTool_Scene_setup_01')
	cmds.frameLayout("CUTool_frame_layout00_Scene_setup_01_00", parent="CUTool_Scene_setup_01",borderStyle="etchedOut",labelVisible=False)
	cmds.text("CUTool_UsedDirecotryForAlembicExportTypeInfo",align="left", label="Export from: ", parent="CUTool_frame_layout00_Scene_setup_01_00")
	cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelectionGRP', labelArray4=['Dynamic set','Render set','Geometry_grp', 'Geo_normal'], numberOfRadioButtons=4, select=3, editable=True, vertical=True, parent='CUTool_frame_layout00_Scene_setup_01_00')
	cmds.text(label="\n\n", parent="CUTool_frame_layout00_Scene_setup_01_00")
	cmds.textField("CUTool_changeABCExportDirectoryAlembicPRO_textField", edit=True, editable=True)
	cmds.text(label='Custom rib archive name: ', parent='CUTool_Shablon_setup_07', align="left")
	cmds.textField('CUTool_RibSetupNewNameArchive', parent='CUTool_Shablon_setup_07', text='')
	cmds.checkBoxGrp('CUTool_RibArchive_useCustomName', v1=0, l="Use custom name: ", parent='CUTool_Shablon_setup_07', ann="Create custom rib archive.", cc='CUToolSetup.CUTool_blockCustomDirectory("CUTool_RibArchive_useCustomName", "CUTool_RibSetupNewNameArchive")')
	cmds.checkBoxGrp('CUTool_RibArchive_useUpdateRootProxy', v1=1, l="Update proxy: ", parent='CUTool_Shablon_setup_07', ann="Add to proxy rib archive in root directory.")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_07_form_00",['CUTool_Shablon_setup_rib_button_createForSelected', 'CUTool_Shablon_setup_rib_button_ROOT'],"CUTool_Shablon_setup_07",26)
	cmds.text("CUTool_UsedDirecotryForProxyInfotxt",align="left", label="Proxy: ", parent="CUTool_modeling_setup_00")
	CUTool_changeDirectory_button("CUTool_changeProxyExportDirectory", "CUTool_modeling_setup_00", createPathToProxy(), 1, 0)
	cmds.checkBoxGrp('CUTool_modeling_proxy_OptimizeGeometry', v1=1, l="Optimize geometry: ", parent='CUTool_modeling_setup_00', ann="Reduce polygons.", cc='CUToolSetup.changeBlockUI(uiName="CUTool_modeling_proxy_OptimizeGeometryPercent")')
	cmds.intSliderGrp('CUTool_modeling_proxy_OptimizeGeometryPercent', field=True, label='Reduce by (%): ', minValue=0, maxValue=100, fieldMinValue=0, fieldMaxValue=100, value=75, parent='CUTool_modeling_setup_00')
	cmds.checkBoxGrp('CUTool_modeling_proxy_useGpuCache', v1=1, l="Gpu cache: ", parent='CUTool_modeling_setup_00', ann="Create proxy with gpu cache.", cc='CUToolSetup.changeBlockUI(uiName="CUTool_modeling_setup_00_optimizeGpuCacheVertices")')
	cmds.intFieldGrp('CUTool_modeling_setup_00_optimizeGpuCacheVertices', numberOfFields=1, label='Optimization Theshold: ', extraLabel='vertices', value1=40000, parent='CUTool_modeling_setup_00')
	cmds.checkBoxGrp('CUTool_modeling_proxy_createControls', v1=1, l="Create controls: ", parent='CUTool_modeling_setup_00', ann="Create controls for proxy.")
	CUTool_changeDirectory_button("CUTool_getVideoFile", "CUTool_Animation_setup_03",'',3,1)
	cmds.button('saveAviToFile', label='Export sound', parent='CUTool_Animation_setup_03', c='CUToolSetup.exportSoundFromAvi()')
	cmds.button('TransferAttrsButton', label='Transfer', parent='CUTool_modeling_setup_01', c='CUToolSetup.ml_transferAttributes.ml_transferAttributes()')


	#layouts setup
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_00",['CUTool_Shablon_setup_cameras_button_Import','CUTool_Shablon_setup_cameras_button_Clean','CUTool_Shablon_setup_cameras_button_Setup'],"CUTool_Shablon_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_01dop",['CUTool_Shablon_setup_cameras_button_UnlockCameras','CUTool_Shablon_setup_cameras_button_LockCameras', 'CUTool_Shablon_setup_cameras_button_RegisterCameras'],"CUTool_Shablon_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_01",['CUTool_Shablon_setup_template_button_Reference', 'DeleteUnusedNodes_button','DeleteUnusedAdvanced'],"CUTool_Shablon_setup_01",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_02dop",['CUTool_Animatic_setup_OffsetAnimation_button_CUTanimation',],"CUTool_Shablon_setup_00",26)
	cmds.text(label="Camera clipplane expression", parent="CUTool_Shablon_setup_00")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_03dop",['CreateCamClipPlaneExpression', 'RemoveCamClipPlaneExpression'],"CUTool_Shablon_setup_00",26)
	cmds.text(label="Setup camera", parent="CUTool_Shablon_setup_00")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_04dop",['SetCamButton'],"CUTool_Shablon_setup_00",26)
	cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list", height=200, allowMultiSelection=True, parent="CUTool_Shablon_setup_04")
	cmds.checkBoxGrp('CUTool_loadManuallyChars_control', v1=0, l="load manual reference: ", parent='CUTool_Shablon_setup_04', ann="Only add reference name to current scene.")
	cmds.intFieldGrp('CUTool_Shablon_setup_charsCount_int', v1=1, label='number of references: ', parent='CUTool_Shablon_setup_04')
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_09",['CUTool_Shablon_setup_animation_button_referenceChar'],"CUTool_Shablon_setup_04",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_04",['CUTool_Shablon_setup_animation_button_UpdateFramesFromFiles','CUTool_Shablon_setup_animation_button_GetCharsFromFile','CUTool_Shablon_setup_animation_button_Import'],"CUTool_Shablon_setup_02",26)
	cmds.rowColumnLayout("CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight", parent='CUTool_Shablon_setup_06')
	cmds.intFieldGrp('CUTool_Shablon_setup_EpisodeNumber_int', v1=0, label='Episode number: ', parent='CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight')
	cmds.intFieldGrp('CUTool_Shablon_setup_SceneNumber_int', v1=0, label='Episode number: ', parent='CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight')
	cmds.intFieldGrp('CUTool_Shablon_setup_SceneNumberDop_int', v1=0, label='dop number: ', parent='CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight')
	cmds.checkBoxGrp('CUTool_Shablon_setup_SceneDopControl', v1=0, l="dop scene: ", h=25, parent='CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight', ann="Create scene for dop scene.", cc='CUToolSetup.CUTool_blockCustomDirectory("CUTool_Shablon_setup_SceneDopControl", "CUTool_Shablon_setup_SceneNumberDop_int")')
	optionsMenuCreateByArray(name='CUTool_Shablon_setup_SceneType_text', label='\tScene type: ', parent='CUTool_Shablon_setup_DynLightShablon_ColumnCreateDynLight', menuArray=['light', 'dyn'])
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_11",['CUTool_Shablon_setup_DynLightShablon_button_Create', 'CUToolExperementShablon','CUTool_Shablon_setup_DynLightShablon_button_Install','CUTool_Shablon_setup_DynLightShablon_button_Delete'],"CUTool_Shablon_setup_06",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_10",['CUTool_Shablon_setup_animation_button_SaveControl','CUTool_Shablon_setup_animation_button_LoadControl'],"CUTool_Shablon_setup_05",26)
	cmds.textScrollList("CUTool_Shablon_setup_references_list", height=200, allowMultiSelection=True, parent="CUTool_Shablon_setup_03")
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_05",['CUTool_Shablon_setup_reference_button_Add','CUTool_Shablon_setup_reference_button_Remove','CUTool_Shablon_setup_reference_button_Clear','CUTool_Shablon_setup_reference_button_Select','CUTool_Shablon_setup_reference_button_All'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_06",['CUTool_Shablon_setup_reference_button_FromView','CUTool_Shablon_setup_reference_button_FromViewWithAnim'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_07",['CUTool_Shablon_setup_reference_button_UnloadList','CUTool_Shablon_setup_reference_button_UnloadSelectedInList','CUTool_Shablon_setup_reference_button_UnloadNotInList'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_08",['CUTool_Shablon_setup_reference_button_AutoUnload', 'CUTool_Shablon_referenceReload','CUTool_Shablon_setup_reference_button_ReferenceEdits','CUTool_Shablon_setup_reference_button_ImportReferences'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Shablon_setup_00_form_12",['CUTool_Shablon_setup_reference_button_SwitchProxy','CUTool_Shablon_setup_reference_button_AddProxy', 'CUTool_Shablon_setup_reference_button_Open', 'CUTool_modeling_setup_ListUniqueReferences', 'selectAllLoadedProxy'],"CUTool_Shablon_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_00",['CUTool_Animatic_setup_animation_button_Save','CUTool_Animatik_setup_button_delete_animation'],"CUTool_Animatic_setup_01",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_01",['CUTool_Animatic_setup_camera_button_Export'],"CUTool_Animatic_setup_02",26)
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_02",['CUTool_Animatic_setup_tmplate_button_Export'],"CUTool_Animatic_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_00",['CUTool_light_setup_density_button_plus','CUTool_light_setup_density_button_minus','CUTool_light_setup_density_button_remove'],"CUTool_Light_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_01",['CUTool_light_setup_shadingRate_button_plus','CUTool_light_setup_shadingRate_button_minus','CUTool_light_setup_shadingRate_button_remove'],"CUTool_Light_setup_01",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_02",['CUTool_light_setup_Illumination_button_plus', 'CUTool_light_setup_Illumination_button_minus', 'CUTool_light_setup_Illumination_button_remove','CUTool_light_setup_Illumination_button_removeAll'],"CUTool_Light_setup_02",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_12",["addLightUserCategory", "removeLightUserCategory"],"CUTool_Light_setup_02",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_03",['CUTool_light_setup_RefEdits_button_RemoveSlimEditsSur', 'CUTool_light_setup_RefEdits_button_RemoveSlimEditsEns'],"CUTool_Light_setup_03",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_04",['CUTool_light_setup_shadingRate_button_setBake','CUTool_light_setup_shadingRate_button_delBake'],"CUTool_Light_setup_05",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Light_00_form_04",['CUTool_light_setup_shadingRate_button_addConnectionProjections'],"CUTool_Light_setup_06",26)
	CUTool_formLayout_buttons("CUTool_Animatic_Anim_00_form_05",['CUTool_light_setup_createPlayblast', 'CUTool_light_setup_createPlayblastCustom'],"CUTool_Animation_setup_02",26)

	cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', label='Selection list:                         ', backgroundColor=[0.3,0.3,0.1], parent='CUTool_Scene_setup_00')
	cmds.menuItem('CUToolABC_ExlmModeExportOptionsItem03', label='All from selection list')
	cmds.menuItem('CUToolABC_ExlmModeExportOptionsItem01', label='Select from outliner or viewport')
	cmds.menuItem('CUToolABC_ExlmModeExportOptionsItem02', label='Selected from selection list')
	if cmds.attributeQuery('renderPreviewCamera', node='perspShape', exists=True):
		cmds.deleteAttr('perspShape.renderPreviewCamera')
	if cmds.attributeQuery('renderPreviewCamera', node='perspShape', exists=True) is False:
		cmds.addAttr('perspShape', longName='renderPreviewCamera', hidden=True, dataType="string")
	if cmds.attributeQuery('renderPreviewCameraInt', node='perspShape', exists=True) is False:
		cmds.addAttr('perspShape', longName='renderPreviewCameraInt', hidden=True, dataType="string")
	if cmds.attributeQuery('renderPreviewResolutionInt', node='perspShape', exists=True) is False:
		cmds.addAttr('perspShape', longName='renderPreviewResolutionInt', hidden=True, dataType="string")
	cmds.attrEnumOptionMenuGrp('CUTool_renderPreviewResolutionMenu00', label='resolution: ', ei=[(0, '1024x429'), (1, '2048x858'), (2, '2048x2048'), (3, '1024x1024'), (4, '512x512'), (5, '640x480'), (6, '320x240'), (7, '320x480'), (8, '2100x858')], attribute="perspShape.renderPreviewResolutionInt", parent='CUTool_Light_setup_04')
	camerasAll = cmds.ls(cameras=True)
	camerasList = [('('+str(i)+', "'+camerasAll[i]+'")') for i in range(0, len(camerasAll))]
	menuItemsCameras = 'cmds.attrEnumOptionMenuGrp("CUTool_renderPreviewCameraMenu00", label="camera: ", ei=['
	for i in range(0, len(camerasList)):
		oldAttr = cmds.getAttr('perspShape.renderPreviewCamera')
		cmds.setAttr('perspShape.renderPreviewCamera', str(oldAttr)+' '+camerasAll[i], type='string')
		if i != (len(camerasList)-1):
			menuItemsCameras = menuItemsCameras + camerasList[i] + ','
		else:
			menuItemsCameras = menuItemsCameras + camerasList[i]
	menuItemsCameras = menuItemsCameras + '], parent="CUTool_Light_setup_04", attribute="perspShape.renderPreviewCameraInt")'
	exec(menuItemsCameras)

	CUTool_formLayout_buttons("CUTool_Animatic_Light_04_form_01",['CUTool_light_setup_PreviewRender', 'CUTool_light_setup_PreviewSetup'],"CUTool_Light_setup_04",26)

	cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', parent='CUTool_Scene_setup_00', h=200, allowMultiSelection=True)
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_00",['CUTool_Scene_setup_ABCrefreshList_button_RefreshList','CUTool_Scene_setup_ABCaddToList_button_AddToList','CUTool_Scene_setup_ABCremoveFromList_button_removeFromList','CUTool_Scene_setup_ABCclearList_button_ClearList','CUTool_Scene_setup_ABCselectFromList_button_selectFromList'],"CUTool_Scene_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_01",['CUTool_Scene_setup_ABCblendshapes_button_CreateBlendshapes'],"CUTool_Scene_setup_00",26)
	cmds.intFieldGrp('CUTool_ABCstartFrame', label="Start Frame: ", value1=cmds.playbackOptions(query=True, animationStartTime=True), parent='CUTool_Scene_setup_00')
	cmds.intFieldGrp('CUTool_ABCendFrame', label="End Frame: ", value1=cmds.playbackOptions(query=True, animationEndTime=True), parent='CUTool_Scene_setup_00')
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_02",['CUTool_Scene_setup_ABCframesRenges_button_Update'],"CUTool_Scene_setup_00",26)
	cmds.separator(parent='CUTool_Scene_setup_00')
	cmds.checkBoxGrp('CUTool_ABCcheck_visible_control', v1=1, l="Write Visibility: ", parent='CUTool_Scene_setup_00', ann="Write visibility attribute.")
	cmds.checkBoxGrp('CUTool_ABCcheck_renderable_control', v1=1, l="Renderable only: ", parent='CUTool_Scene_setup_00', ann="Write only visible or renderable objects.")
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_03",['CUTool_Scene_setup_ABCExport_button_ExportABC'],"CUTool_Scene_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Scene_setup_01_form_04",['CUTool_Scene_setup_ExportFrom', 'CUTool_Scene_setup_ExportImportCache'],"CUTool_Scene_setup_01",26)
	cmds.separator(parent='CUTool_Scene_setup_00')
	cmds.checkBoxGrp('ABC_check_Imp_fitTimeRange_control', v1=1, l="Fit time range: ", parent='CUTool_Scene_setup_00', ann="Set time range to alembic settings when import.")
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_04",['CUTool_Scene_setup_ABCimport_button_ImportABC', "CUTool_Scene_setup_ABCimport_button_ImportABC2"],"CUTool_Scene_setup_00",26)
	cmds.separator(parent='CUTool_Scene_setup_00')
	cmds.checkBoxGrp('ABC_check_Imp_Exp_control', v1=0, l="Import/Export changed: ", parent='CUTool_Scene_setup_00', ann="Export from original then import ABC to changed version.")
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_05",['CUTool_Scene_setup_ABCimport_button_ChangeToRenderVersion'],"CUTool_Scene_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Scene_setup_00_form_06",['CUTool_Scene_setup_ABCimport_button_ChangeToDynamicVersion'],"CUTool_Scene_setup_00",26)
	cmds.intFieldGrp('CUTool_animatikSetup_StartFrameOffset', numberOfFields=1, label='Start frame: ', value1=0, parent='CUTool_Animatic_setup_04')
	cmds.intFieldGrp('CUTool_animatikSetup_StepFrameOffset', numberOfFields=1, label='Offset by step: ', value1=0, parent='CUTool_Animatic_setup_04')
	CUTool_formLayout_buttons("CUTool_Animatic_setup_00_form_04",['CUTool_Animatic_setup_OffsetAnimation_button_OffsetPlus','CUTool_Animatic_setup_OffsetAnimation_button_OffsetMinus', 'CUToolButton_RelativeOffset'],"CUTool_Animatic_setup_04",26)
	CUTool_formLayout_buttons("CUTool_Animation_setup_00_form_00",['CUTool_Animation_setup_SaveReferenceState','CUTool_Animation_setup_LoadReferenceState'],"CUTool_Animation_setup_00",26)
	CUTool_formLayout_buttons("CUTool_Animation_setup_00_form_01",['CUTool_Animation_setup_exportRanges','CUTool_Animation_setup_exportRange'],"CUTool_Animation_setup_01",26)

	cmds.rowColumnLayout("CUTool_Animation_setup_SaveReferenceState_ColumnSave", numberOfRows=1, columnSpacing=(1,60), parent='CUTool_Animation_setup_00')
	cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxSave', label='Save scene: ', value1=0, parent='CUTool_Animation_setup_SaveReferenceState_ColumnSave')
	cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxLoad', label='Save enable:', value1=0, parent='CUTool_Animation_setup_SaveReferenceState_ColumnSave', changeCommand='CUToolSetup.CUTool_refenceSaveStatement_checkButton("CUTool_Animation_setup_SaveReferenceState_checkBoxLoad")')
	cmds.textFieldGrp('CUTool_NewVersionName', label='dop name:', parent='CUTool_Animation_setup_00', text='')
	cmds.textScrollList('CUTool_ABC_ExIm_VersionList_references', parent='CUTool_Animation_setup_00', h=200, allowMultiSelection=False, selectCommand="cmds.button('CUTool_Animation_setup_LoadReferenceState', edit=True, backgroundColor=[0.1,0.3,0.1], enable=True)")
	CUTool_formLayout_buttons("CUTool_modeling_setup_00_form_00",['CUTool_modeling_setup_CreateProxy'],"CUTool_modeling_setup_00",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_07_form_01",['CUTool_light_switchHairDisplaysToOff'],"CUTool_Light_setup_07",26)
	cmds.floatFieldGrp('CUTool_asaveIntensityDistance_intField', numberOfFields=1, label='save intensity distance: ', value1=10.0, parent='CUTool_Light_setup_08')
	CUTool_formLayout_buttons("CUTool_mlight_setup_08_form_01",['Convert_selected_spotLight'],"CUTool_Light_setup_08",26)
	cmds.textFieldGrp('CUTool_framesTextFieldForBatchRender', label='frames:', parent='CUTool_Light_setup_09', text='')
	optionsMenuCreateByArray(name='cameraMenuItemsForBatch', label='\t      camera: ', parent='CUTool_Light_setup_09', menuArray=cmds.listCameras())
	CUTool_formLayout_buttons("CUTool_mlight_setup_09_form_01",['Batch_render_frames'],"CUTool_Light_setup_09",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_10_form_01",['OpenDynamicRulesEditor'],"CUTool_Light_setup_10",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_11_form_01",['slimInstanceAll', 'slimInstanceSelected'],"CUTool_Light_setup_11",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_11_form_02",['slimInstanceRestoreAll', 'slimInstanceRestoreSelected'],"CUTool_Light_setup_11",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_11_form_03",['slimInstanceBackUpAll', 'slimInstanceBackUpSelected'],"CUTool_Light_setup_11",26)
	CUTool_formLayout_buttons("CUTool_mlight_setup_12_form_01",[ "FinalShadingRateAddButton", "FinalShadingRateRemoveButton", "FinalShadingRateDeleteButton" ],"CUTool_Light_setup_12",26)
	try:
		if(cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True):
			cmds.loadPlugin("RenderMan_for_Maya")
			m_passClasses = mel.eval( "rmanGetPassClasses" )
		else:
			m_passClasses = mel.eval( "rmanGetPassClasses" )
	except:
		m_passClasses = [ "" ]
		print "Renderman is not loaded!!!"
	optionsMenuCreateByArray(name="shadingRateCustomPassPassNameTextField", label="pass: ", parent="CUTool_Light_setup_13", menuArray=m_passClasses )
	cmds.rowLayout( "shadingRateCustomLayout", numberOfColumns=2, adjustableColumn=2, parent="CUTool_Light_setup_13")
	cmds.floatFieldGrp( "shadingRateCustomPassValueFloatField", parent="shadingRateCustomLayout", value1=1.0 )
	cmds.button("shadingRateCustomPassSetButton", label="Shading rate set", backgroundColor=[0.4,0.4,0.4], parent="shadingRateCustomLayout", command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( CUToolSetup.cmds.optionMenu("shadingRateCustomPassPassNameTextField", query=True, v=True ), set=CUToolSetup.cmds.floatFieldGrp( "shadingRateCustomPassValueFloatField", query=True, value1=True ) )')
	CUTool_formLayout_buttons("CUTool_mlight_setup_13_form_01",[ "shadingRateCustomPassAddButton", "shadingRateCustomPassRemoveButton", "shadingRateCustomPassDeleteButton" ],"CUTool_Light_setup_13",26)
	try:
		cmds.optionMenu('shadingRateCustomPassPassNameTextField', edit=True, value="Final" )
	except:
		pass
	
	#attrFieldGrp(attribute='|persp.referenceList', parent="CUTool_Animation_setup_00")
	#buttons setup
	cmds.button("CUTool_Shablon_setup_animation_button_Import", edit=True, label="Get coordinates", ann='Load coordinates from text file', backgroundColor=[0.4,0.4,0.4], command="CUToolSetup.CUTool_loadFromFileCoordinates()")
	cmds.button("CUTool_Shablon_setup_animation_button_UpdateFramesFromFiles", edit=True, label="Get ranges", ann='Set ranges for current scene from text file', backgroundColor=[0.3,0.3,0.15], command="CUToolSetup.CUTool_setup_ranges_from_file()")
	cmds.button("CUTool_Shablon_setup_cameras_button_Setup", edit=True, backgroundColor=[0.15,0.3,0.15], ann='Setup used camera in current scene', command="CUToolSetup.CUTool_setupUsedCamera()")
	cmds.button("CUTool_Shablon_setup_template_button_Reference", edit=True, backgroundColor=[0.4,0.4,0.4], ann='Reference template file in current scene', command="CUToolSetup.CUTool_importTmplateFile()")
	cmds.button("DeleteUnusedNodes_button", edit=True, label="Delete unused nodes", backgroundColor=[0.4,0.4,0.4], ann='Remove all unused nodes from current scene', command="CUToolSetup.emoe()")
	cmds.button("DeleteUnusedAdvanced", edit=True, label="Delete unused nodes advanced", backgroundColor=[0.4,0.4,0.4], ann='Remove all unused nodes from current scene', command="CUToolSetup.ml_removeUnusedNodes.ml_removeUnusedNodes()")
	cmds.button("CUTool_Shablon_setup_cameras_button_Clean", edit=True, backgroundColor=[0.4,0.4,0.4], ann='Delete all unused cameras', command="CUToolSetup.CUTool_deleteAllUnusedCams()")
	cmds.button("CUTool_Shablon_setup_cameras_button_Import", edit=True, backgroundColor=[0.4,0.4,0.4], ann='Import cameras for current scene', command="CUToolSetup.CUTool_importCamerasFile()")
	cmds.button("CUTool_Shablon_setup_reference_button_Add", edit=True, backgroundColor=[0.4,0.4,0.4], label="Add to list", ann='Add selected referenced object to list', command="CUToolSetup.CUTool_add_reference_to_list()")
	cmds.button("CUTool_Shablon_setup_reference_button_Remove", edit=True, backgroundColor=[0.4,0.4,0.4], label="Remove from list", ann='Remove selected item from list', command="CUToolSetup.CUTool_remove_reference_from_list()")
	cmds.button("CUTool_Shablon_setup_reference_button_Clear", edit=True, backgroundColor=[0.4,0.4,0.4], label="Clear list", ann='Clear list', command="CUToolSetup.CUTool_clear_all_reference_from_list()")
	cmds.button("CUTool_Shablon_setup_reference_button_Select", edit=True, backgroundColor=[0.4,0.4,0.4], label="Select from list", ann='Select reference content from list', command='CUToolSetup.CUTool_select_reference_from_list("Selected")')
	cmds.button("CUTool_Shablon_setup_reference_button_All", edit=True, backgroundColor=[0.4,0.4,0.4], label="Select all from list", ann='Select all reference content from list', command='CUToolSetup.CUTool_select_reference_from_list("All")')
	cmds.button("CUTool_Shablon_setup_reference_button_FromView", edit=True, backgroundColor=[0.4,0.4,0.4], label="Add from viewport", ann='Add to list all referenced object from viewport', command="CUToolSetup.CUTool_Get_references_from_viewport_with_animation(0)")
	cmds.button("CUTool_Shablon_setup_reference_button_FromViewWithAnim", edit=True, backgroundColor=[0.4,0.4,0.4], label="Add from viewport with animation", ann='Add to list all referenced object from viewport with animation', command="CUToolSetup.CUTool_Get_references_from_viewport_with_animation(1)")
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadNotInList", edit=True, backgroundColor=[0.4,0.4,0.4], label="Unload not in list", ann='Unload all references not in list', command="CUToolSetup.CUTool_referenceUnloadNotInList()")
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadList", edit=True, backgroundColor=[0.4,0.4,0.4], label="Unload alll from list", ann='Unload all references from list', command='CUToolSetup.CUTool_referenceUnloadSelection("All")')
	cmds.button("CUTool_Shablon_setup_reference_button_UnloadSelectedInList", backgroundColor=[0.4,0.4,0.4], edit=True, label="Unload selected from list", ann='Unload selected in list reference', command='CUToolSetup.CUTool_referenceUnloadSelection("Selected")')
	cmds.button("CUTool_Shablon_setup_reference_button_AutoUnload", edit=True, backgroundColor=[0.4,0.4,0.4], label="Automatic setup references", ann='Not working', command='CUToolSetup.CUTool_select_reference_from_list("All")')
	cmds.button("CUTool_Shablon_setup_reference_button_ImportReferences", edit=True, backgroundColor=[0.3,0.4,0.4], label="Import references", ann='Import all loaded references', command='CUToolSetup.CUTool_importReferences()')
	cmds.button("CUTool_Shablon_setup_animation_button_UpdateFrames", edit=True, backgroundColor=[0.4,0.4,0.4], label="Edit range", ann='Setup ranges from settings', command='CUToolSetup.CUTool_select_update_animation_frames()')
	cmds.button("CUTool_Shablon_setup_animation_button_referenceChar", edit=True, backgroundColor=[0.27,0.08,0.07], label="Reference selected character", ann='Reference selected item from list', command='CUToolSetup.CUTool_referenceCharacterFromList()')
	cmds.button("CUTool_Shablon_setup_animation_button_GetCharsFromFile", edit=True, backgroundColor=[0.4,0.4,0.4], ann='Not working', label="Get characters")
	cmds.button("CUTool_Shablon_setup_animation_button_SaveControl", edit=True, backgroundColor=[0.2,0.3,0.2], ann='Save for selected object transfrom attributes', label="Save transform", command='CUToolSetup.copyPasteTransformAttributes(save=True)')
	cmds.button("CUTool_Shablon_setup_animation_button_LoadControl", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Load from file transform attributes for similiar objects', label="Load transform", command='CUToolSetup.copyPasteTransformAttributes(load=True)')
	cmds.button("CUTool_Shablon_setup_DynLightShablon_button_Create", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Create dyn or light scene for shablon', label="Create scene", command='CUToolSetup.callToMayaPyForSaveShablonDynOrLight()')
	cmds.button("CUToolExperementShablon", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Create dyn or light scene for shablon', label="Create scene beta", command='CUToolSetup.callToMayaPyForSaveShablonDynOrLight( experiment=True )')
	cmds.button("CUTool_Shablon_setup_DynLightShablon_button_Install", edit=True, backgroundColor=[0.2,0.2,0.3], ann='install used in this operation script to desktop', label="Install script", command='CUToolSetup.CUTool_installBatchScriptForDynLightSetup()')
	cmds.button("CUTool_Shablon_setup_DynLightShablon_button_Delete", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Load from file transform attributes for similiar objects', label="Delete script")
	cmds.button("CUTool_Shablon_setup_cameras_button_UnlockCameras", edit=True, backgroundColor=[0.2,0.35,0.2], label="Unlock cameras", ann='Unlock all selected and non referenced cameras in scene', command='CUToolSetup.CUTool_LockCameras("unlock")')
	cmds.button("CUTool_Shablon_setup_cameras_button_LockCameras", edit=True, backgroundColor=[0.3,0.2,0.2], label="Lock cameras", ann='Lock all non referenced and non startup cameras', command='CUToolSetup.CUTool_LockCameras("lock")')

	cmds.button("CUTool_Shablon_setup_rib_button_createForSelected", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Update rib archive for selected referenced objects', label="Update selected reference", command='CUToolSetup.CUTool_BatchExportRib()')
	#cmds.button("CUTool_Shablon_setup_rib_button_editSelected", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Load from file transform attributes for similiar objects', label="Edit")
	cmds.button("CUTool_Shablon_setup_rib_button_ROOT", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Update rib archive for selected transform in current scene, in current project folder', label='Update selected', command='CUToolSetup.createRibArchive( addPathToProxy=CUToolSetup.addPathToProxyState())')

	cmds.button("CUTool_Animation_setup_SaveReferenceState", edit=True, label="Save references statement", backgroundColor=[0.1,0.3,0.1], ann='Save all loaded references statement', command='CUToolSetup.referenceLoadStatementSet(load=False)')
	cmds.button("CUTool_Animation_setup_LoadReferenceState", edit=True, label="Load references statement", backgroundColor=[0.1,0.3,0.1], ann='Restore all loaded references statement', command='CUToolSetup.referenceLoadStatementSet(load=True)')
	CUTool_refenceSaveStatement_checkButton(None)
	CUTool_refenceSaveStatement_checkButton("CUTool_Animation_setup_SaveReferenceState_checkBoxLoad")
	cmds.button("CUTool_Animation_setup_exportRanges", edit=True, label="Export ranges", backgroundColor=[0.1,0.3,0.1], ann='Save animation ranges', command='CUToolSetup.rangesCache(exportRange=True)')
	cmds.button("CUTool_Animation_setup_exportRange", edit=True, label="Import ranges", backgroundColor=[0.1,0.3,0.1], ann='Load animation ranges', command='CUToolSetup.rangesCache(importRanges=True, backUp=False)')

	cmds.button("CUTool_Animatic_setup_animation_button_Save", edit=True, label="Save animation settings", backgroundColor=[0.1,0.3,0.1], ann='Save animation curves and ranges to text file', command='CUToolSetup.CUTool_SaveAnimationCoordinates()')
	cmds.button("CUTool_Animatic_setup_camera_button_Export", edit=True, label="Export cameras", backgroundColor=[0.1,0.3,0.1], ann='Export all cameras', command='CUToolSetup.CUTool_ExportCamerasFromAnimatik(cmds.textField("CUTool_changeCameraExportDirectory_textField", query=True, text=True))')
	cmds.button("CUTool_Animatik_setup_button_delete_animation", edit=True, label="Delete animation from scene", backgroundColor=[0.3,0.15,0.15], ann='Delete all animation curves', command='CUToolSetup.CUTool_deleteAnimationFromScene()')
	cmds.button("CUTool_Animatic_setup_tmplate_button_Export", edit=True, label="Export all referenced props as tmplate", ann='Export all references to file', backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.CUTool_ExportTemplateFromAnimatik(cmds.textField("CUTool_changeTemplateExportDirectory_textField", query=True, text=True))')
	cmds.button("CUTool_Shablon_setup_reference_button_SwitchProxy", edit=True, label="Switch proxy", ann='Switch selected reference to proxy', backgroundColor=[0.35,0.35,0.15], command='CUToolSetup.addProxyToSelected(switch=True)')
	cmds.button("CUTool_Shablon_setup_reference_button_AddProxy", edit=True, label="Add proxy", ann='Switch selected reference to proxy', backgroundColor=[0.30,0.35,0.15], command='CUToolSetup.addProxyToSelected(switch=False)')
	cmds.button("selectAllLoadedProxy", edit=True, label="Select all proxy", ann='Select all loaded proxy', backgroundColor=[0.30,0.35,0.15], command='CUToolSetup.selectProxy()')
	cmds.button("CUTool_Shablon_setup_reference_button_Open", edit=True, label="Open", ann='Open reference in new default maya', backgroundColor=[0.25,0.35,0.15], command='CUToolSetup.CUTool_OpenSelectedReference()')
	cmds.button("CUTool_Shablon_setup_reference_button_ReferenceEdits", edit=True, label="Edit Edits", ann='Open editor of edits for selected referenced object', backgroundColor=[0.3,0.2,0.15], command='CUToolSetup.CUTool_getReferenceEdits()')
	cmds.button("CUTool_Animatic_setup_OffsetAnimation_button_OffsetPlus", edit=True, label='Offset plus', backgroundColor=[0.3,0.2,0.15], command='CUToolSetup.CUToolOffsetProcedure_exec("plus")')
	cmds.button("CUTool_Animatic_setup_OffsetAnimation_button_OffsetMinus", edit=True, label='Offset minus', backgroundColor=[0.3,0.2,0.15], command='CUToolSetup.CUToolOffsetProcedure_exec("minus")')
	cmds.button("CUTool_Animatic_setup_OffsetAnimation_button_CUTanimation", edit=True, label='Cut selected animation', ann='Cut animation by animation start and end frames for selected objects and they childrens.', backgroundColor=[0.3,0.2,0.15], command='CUToolSetup.cutAnimation( descendents=True )')
	cmds.button('CUToolButton_RelativeOffset', edit=True, label='Relative offset', command=("CUToolSetup.CUTool_ShotAnimationOffsetSecond()"))

	cmds.button("CUTool_Scene_setup_ABCblendshapes_button_CreateBlendshapes", edit=True, label="Create blendshapes", backgroundColor=[0.45,0.4,0.4], ann='Create blendshapes for selected object or item in list', command='CUToolSetup.createBlendShapesNode()')
	cmds.button("CUTool_Scene_setup_ABCrefreshList_button_RefreshList", edit=True, label="Refresh", ann='Refresh list and add all geometry_gr', backgroundColor=[0.25,0.35,0.25], command='CUToolSetup.CUTool_ABCRefreshList()')
	cmds.button("CUTool_Scene_setup_ABCaddToList_button_AddToList", edit=True, label="Add", ann='Add selected object to list', backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.CUTool_ABCAddSelectedToList()')
	cmds.button("CUTool_Scene_setup_ABCremoveFromList_button_removeFromList", edit=True, label="Remove", backgroundColor=[0.4,0.4,0.4], ann='Remove selected item from list', command='CUToolSetup.CUTool_ABCRemoveSelectedFromList("selected")')
	cmds.button("CUTool_Scene_setup_ABCclearList_button_ClearList", edit=True, label="Clear", ann='Clear list', backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.CUTool_ABCRemoveSelectedFromList("all")')
	cmds.button("CUTool_Scene_setup_ABCselectFromList_button_selectFromList", edit=True, label="Select", backgroundColor=[0.4,0.4,0.4], ann='Select object from list', command='CUToolSetup.CUTool_ABCSelectItemFromList()')
	cmds.button("CUTool_Scene_setup_ABCframesRenges_button_Update", edit=True, label="Update ranges", backgroundColor=[0.35,0.35,0.35], ann='Get ranges of start and end animation', command='CUToolSetup.CUTool_ABCupdateRanges()')
	cmds.button("CUTool_Scene_setup_ABCExport_button_ExportABC", edit=True, label="Export cache", backgroundColor=[0.4,0.4,0.45], ann='Export alembic cache', command='CUToolSetup.exportAlembic("default")')
	cmds.button("CUTool_Scene_setup_ABCimport_button_ImportABC", edit=True, label="Import cache", backgroundColor=[0.4,0.4,0.45], ann='Import alembic cache', command='CUToolSetup.importAlembic("default", "None")')
	cmds.button("CUTool_Scene_setup_ABCimport_button_ImportABC2", edit=True, label="Import cache with references", backgroundColor=[0.4,0.4,0.45], ann='Import alembic cache', command='import exportAlembic; exportAlembic.alembicSetup( connectVisibility=True, connectTransforms=True, fitTimeRange=True )')
	cmds.button("CUTool_Scene_setup_ABCimport_button_ChangeToRenderVersion", edit=True, label="Change to render version", ann='Change referenced character to render version', backgroundColor=[0.3,0.2,0.2], command='CUToolSetup.CUTool_changeToRenderVersion("_render")')
	cmds.button("CUTool_Scene_setup_ABCimport_button_ChangeToDynamicVersion", edit=True, label="Change to dynamic version", ann='Change referenced character to render version', backgroundColor=[0.3,0.2,0.2], command='CUToolSetup.CUTool_changeToRenderVersion("_dyn")')
	cmds.button("CUTool_Scene_setup_ExportFrom", edit=True, label="Batch export", ann='Export alembic cache from file', backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.CUTool_BatchExportAlembic()')
	cmds.button('CUTool_Shablon_referenceReload', edit=True, label="Reload", ann='Reload selected reference', backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.reloadReference()')

	cmds.button("CUTool_light_setup_density_button_plus", edit=True, label="Density up", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "RenderRadiosity", add=True )')
	cmds.button("CUTool_light_setup_density_button_minus", edit=True, label="Density down", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "RenderRadiosity", remove=True )')
	cmds.button("CUTool_light_setup_density_button_remove", edit=True, label="Remove density", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "RenderRadiosity", delete=True )')

	cmds.button("CUTool_light_setup_shadingRate_button_plus", edit=True, label="Shading rate up", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.shadingRateSetup("plus","all")')
	cmds.button("CUTool_light_setup_shadingRate_button_minus", edit=True, label="Shading rate down", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.shadingRateSetup("minus","all")')
	cmds.button("CUTool_light_setup_shadingRate_button_remove", edit=True, label="Shading rate default", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.shadingRateSetup("remove","all")')

	cmds.button("CUTool_light_setup_Illumination_button_plus", edit=True, label="Make light link", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.illuminateSetup("plus","selected")')
	cmds.button("CUTool_light_setup_Illumination_button_minus", edit=True, label="Break light link", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.illuminateSetup("minus","selected")')
	cmds.button("CUTool_light_setup_Illumination_button_remove", edit=True, label="Remove links", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.illuminateSetup("remove","all")')
	cmds.button("CUTool_light_setup_Illumination_button_removeAll", edit=True, label="Remove all links", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.illuminateSetup("removeAll","all")')
	cmds.button("CUTool_Shablon_setup_cameras_button_RegisterCameras", edit=True, label="Register cameras", backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.registerAllCams()')
	cmds.button("removeLightUserCategory", edit=True, label="Remove category", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.categoryLink( remove=True )')
	cmds.button("addLightUserCategory", edit=True, label="Add category", backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.categoryLink()')


	cmds.button("CUTool_light_setup_shadingRate_button_setBake", edit=True, label="Setup Bake", backgroundColor=[0.4,0.4,0.4], command='import bakeBKM;reload(bakeBKM);bakeBKM.setupBake()')
	cmds.button("CUTool_light_setup_shadingRate_button_delBake", edit=True, label="Delete Bake", backgroundColor=[0.4,0.4,0.4], command='import bakeBKM;reload(bakeBKM);bakeBKM.deleteBake()')

	cmds.button("CUTool_light_setup_shadingRate_button_addConnectionProjections", edit=True, label="Set projection", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.setProjection()')
	cmds.button("CUTool_light_switchHairDisplaysToOff", edit=True, label="switch hair display", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.hairDisplayAsSwitch()')
	cmds.button("Convert_selected_spotLight", edit=True, label="Convert selected spotLight", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.convertSpotLightToRMSGeoAreaLight(target="", distance=cmds.floatFieldGrp("CUTool_asaveIntensityDistance_intField", query=True, value1=True))')
	cmds.button("Batch_render_frames", edit=True, label="Launch batch render", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.perFrameBatchRender(frames=cmds.textFieldGrp("CUTool_framesTextFieldForBatchRender", query=True, text=True), camera=cmds.optionMenu("cameraMenuItemsForBatch", query=True, value=True))')
	cmds.button("OpenDynamicRulesEditor", edit=True, label="Open editor", backgroundColor=[0.4,0.4,0.4], command='import rmanDynRulesEd;reload(rmanDynRulesEd);rmanDynRulesEd.openEditor()')
	
	cmds.button("slimInstanceAll", edit=True, label="Instance All", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimLocalize( selected=False )')
	cmds.button("slimInstanceSelected", edit=True, label="Instance Selected", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimLocalize( selected=True )')
	cmds.button("slimInstanceRestoreAll", edit=True, label="Restore All", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimRestoreBackupID( selected=False )')
	cmds.button("slimInstanceRestoreSelected", edit=True, label="Restore Selected", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimRestoreBackupID( selected=True )')
	cmds.button("slimInstanceBackUpAll", edit=True, label="Backup All", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimBackUpID( selected=False, force=True )')
	cmds.button("slimInstanceBackUpSelected", edit=True, label="Backup Selected", backgroundColor=[0.4,0.4,0.4], command='import slimExt;reload(slimExt);slimExt.slimBackUpID( selected=True, force=True )')
	
	cmds.button("CreateCamClipPlaneExpression", edit=True, label="Create", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.nearClipPlaneExpression( create=True )')
	cmds.button("RemoveCamClipPlaneExpression", edit=True, label="Remove", backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.nearClipPlaneExpression()')
	cmds.button("SetCamButton", edit=True, label="SetCam", backgroundColor=[0.3,0.4,0.4], command='CUToolSetup.SetCam()')

	#Yago
	#checkValue = cmds.optionVar(q="localSave")
	#cmds.checkBoxGrp('CUTool_Animation_setup_LoadFromLocalCheckbox', label='Load from local: ', value1=checkValue, parent='CUTool_Animation_setup_02', changeCommand='CUToolSetup.checkLocal()')
	#CUTool_formLayout_buttons("CUTool_Animation_setup_00_form_03",['CUTool_cacheCurrentScene', 'CUTool_CacheButtonChars'],"CUTool_Animation_setup_02",26)
	#cmds.button("CUTool_CacheButtonChars", edit=True, label="Cache all chars", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.cacheChars()')
	#button for cache scene
	#cmds.button('CUTool_cacheCurrentScene', edit=True, label='Cache current scene', ann='Cache current scene', command='CUToolSetup.cacheScene()')

	cmds.button("CUTool_light_setup_RefEdits_button_RemoveSlimEditsSur", edit=True, label="Remove slim surface", backgroundColor=[0.4,0.4,0.4], ann='Remove slim surface shader edits for selected referenced object', command='CUToolSetup.CUTool_removeSlimEdits("rman__torattr___slimSurface","setAttr")')
	cmds.button("CUTool_light_setup_RefEdits_button_RemoveSlimEditsEns", edit=True, label="Remove slim ensemble", backgroundColor=[0.4,0.4,0.4], ann='Remove slim ensemble shader edits for selected referenced object', command='CUToolSetup.CUTool_removeSlimEdits("rman__torattr___slimEnsemble","setAttr")')
	cmds.button("CUTool_light_setup_PreviewRender", edit=True, label="Preview render", backgroundColor=[0.4,0.4,0.4], ann='start render preview', command='CUToolSetup.CUTool_renderPreview()')
	cmds.button("CUTool_light_setup_PreviewSetup", edit=True, label="Setup render", backgroundColor=[0.4,0.4,0.4], ann='fast setup render', command='print "nothing selected";')
	#cmds.button("FinalShadingRateButton", label="Shading rate down", parent="CUTool_Light_setup_12", backgroundColor=[0.4,0.4,0.4], ann='Down shading rate for selected objects.', command='CUToolSetup.ml_shadingRateFinal.ml_shadingRateFinal()')
	cmds.button("FinalShadingRateAddButton", edit=True, label="Shading rate up", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "Final", add=True )')
	cmds.button("FinalShadingRateRemoveButton", edit=True, label="Shading rate down", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "Final", remove=True )')
	cmds.button("FinalShadingRateDeleteButton", edit=True, label="Remove Shading rate", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( "Final", delete=True )')
	
	cmds.button("shadingRateCustomPassAddButton", edit=True, label="Shading rate up", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( CUToolSetup.cmds.optionMenu("shadingRateCustomPassPassNameTextField", query=True, v=True ), add=True )')
	cmds.button("shadingRateCustomPassRemoveButton", edit=True, label="Shading rate down", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( CUToolSetup.cmds.optionMenu("shadingRateCustomPassPassNameTextField", query=True, v=True ), remove=True )')
	cmds.button("shadingRateCustomPassDeleteButton", edit=True, label="Remove Shading rate", backgroundColor=[0.4,0.4,0.4], command='CUToolSetup.ml_shadingRateFinal.ml_shadingRatePass( CUToolSetup.cmds.optionMenu("shadingRateCustomPassPassNameTextField", query=True, v=True ), delete=True )')

	cmds.button("CUTool_modeling_setup_CreateProxy", edit=True, backgroundColor=[0.2,0.2,0.3], ann='Create new proxy for this scene', label="Create proxy", command='CUToolSetup.CUTool_BatchCreateProxy()')
	cmds.button("CUTool_modeling_setup_ListUniqueReferences", edit=True, backgroundColor=[0.2,0.2,0.3], ann='list references used in this scene', label="List used references", command='CUToolSetup.getUniqueRefeferencesUI()')
	cmds.button('CUTool_light_setup_createPlayblast', edit=True, label='Playblast', bgc=[0.1, 0.25, 0.1], command="CUToolSetup.createAvi(customPath=False)")
	cmds.button('CUTool_light_setup_createPlayblastCustom', edit=True, label='Custom directory playblast', bgc=[0.1, 0.25, 0.1], command="CUToolSetup.createAvi(customPath=True)")
	cmds.text('textFieldProjectDefaultDirectory', bgc=[0.2, 0.22, 0.2], align='left', font='boldLabelFont', label=('\n   directory: "//SERVER-3D/Project/UrfinJuse/Playblast/'+getClearSceneName().split('sc')[0]+'/"'+'\n\n   default name: "'+getClearSceneName()+'.avi"\n'), parent='CUTool_Animation_setup_02')
	cmds.separator(style='in', parent='CUTool_Animation_setup_02')
	cmds.checkBoxGrp('rootCheckbox', label='save to root folder', v1=False, parent='CUTool_Animation_setup_02')
	cmds.checkBoxGrp('SaveNewVersionCheckbox', label='camera changed', v1=False, parent='CUTool_Animation_setup_02')
	cmds.checkBoxGrp('viewPlayblastCheckbox', label='view', v1=False, parent='CUTool_Animation_setup_02')
	cmds.checkBoxGrp('finalPlayblastCheckbox', label='final', v1=False, parent='CUTool_Animation_setup_02', onCommand1="CUToolSetup.finalVersionActivated()")
	cmds.separator(style='in', parent='CUTool_Animation_setup_02')
	#cmds.checkBoxGrp('readyCheckbox', label='Save to ready folder', v1=False, visible=False, parent='CUTool_Animation_setup_02')
	optionsMenuCreateByArray(name='cameraMenuItems', label=' used camera: ', parent='CUTool_Animation_setup_02', menuArray=cmds.listCameras())
	optionsMenuCreateByArray(name='soundMenuItems', label=' used sounds: ', parent='CUTool_Animation_setup_02', menuArray=(cmds.ls(type='audio')+['NO SOUND']))
	cmds.textFieldGrp('sceneNamePlayblast', label=' scene name:', text=getClearSceneName(), ann="scene and file name", parent='CUTool_Animation_setup_02')
	cmds.textFieldGrp('dopNamePlayblast', label=' dop name:', ann="file dop name", parent='CUTool_Animation_setup_02')
	cmds.rowLayout( "CUTool_Animation_setup_02_resolution", numberOfColumns=3, parent="CUTool_Animation_setup_02" )
	cmds.checkBox( "customResolutonForPlayblastEnable", label="Resolution:", cc="cmds.intFieldGrp( \"customResolutonForPlayblast\", edit=True, enable=( cmds.checkBox( \"customResolutonForPlayblastEnable\", query=True, value=True )))", parent="CUTool_Animation_setup_02_resolution" )
	cmds.intFieldGrp( "customResolutonForPlayblast", numberOfFields=2, value1=2048, value2=858, enable=False, parent="CUTool_Animation_setup_02_resolution" )
	cmds.checkBox( "ImagePlanesForPlayblastEnable", label="Image planes:", parent="CUTool_Animation_setup_02" )
	
	cmds.button( "renderPlayblastButton", label="Render playblast", command="CUToolSetup.renderPlayblast()", parent='CUTool_Animation_setup_02' )
	try:
		cmds.optionMenu('cameraMenuItems', edit=True, value=getCameraByFilename())
		cmds.optionMenu('cameraMenuItemsForBatch', edit=True, value=getCameraByFilename())
	except:
		print 'Camera error.'
	#show window
	CUTool_ABCRefreshList()
	CUTool_getCharactersInlist()
	refreshReferenceBackupList()
	CUTool_updatePathForBatchExportAlembicScene()
	CUTool_blockCustomDirectory("CUTool_RibArchive_useCustomName", "CUTool_RibSetupNewNameArchive")
	cmds.showWindow("CUTool_window_00")
	if cmds.dockControl("CUTool_dockControl_layout_00",exists=True):
	    cmds.deleteUI("CUTool_dockControl_layout_00", control=True)
	cmds.dockControl("CUTool_dockControl_layout_00",label="SCENE SETUP",area='left', content="CUTool_window_00", allowedArea=['right', 'left'], width=500)
	CUTool_blockCustomDirectory("CUTool_ABCcheck_useCustomDirectory", "CUTool_changeABCExportDirectoryAlembicPRO_textField")
	CUTool_blockCustomDirectory("CUTool_RibArchive_useCustomName", "CUTool_RibSetupNewNameArchive")
	CUTool_blockCustomDirectory("CUTool_Shablon_setup_SceneDopControl", "CUTool_Shablon_setup_SceneNumberDop_int")

#CREATE FAST FORM LAYOUTS 	PROCEDURE
def CUTool_formLayout_buttons(form_name,form_buttons,form_parent,form_buttons_height):
	"""
	#EXAMPLE: formLayout_buttons("Layout name",['Button name_Label name', ...],"Name of the parent layout", "Button height")
	#RESULT: button name equal to 'Button name_Label name'
	"""
	buttons_position=[(100/(len(form_buttons)))]
	if len(form_buttons)>1:
		if cmds.formLayout(form_name, exists=True):
			cmds.deleteUI(form_name, layout=True)
		cmds.formLayout(form_name, numberOfDivisions=100, parent=form_parent)
		for i in range(0,len(form_buttons)-1):
			buttons_position.append(buttons_position[-1]+(100/(len(form_buttons))))
		for i in range(0,len(form_buttons)):
			if cmds.button(form_buttons[i], exists=True):
				cmds.deleteUI(form_buttons[i], control=True)
			cmds.button(form_buttons[i], label=(re.findall("[A-Z, a-z, 0-9]+$",form_buttons[i])[-1]), height=form_buttons_height)
		for i in range(0,len(form_buttons)):
			cmds.button(form_buttons[i],edit=True,parent=form_name)
		formSettings=((' -attachForm ')+('"')+(form_buttons[0])+('"')+(' "top" 0 ')+('-attachForm ')+('"')+(form_buttons[0])+('"')+(' "left" 0 ')+('-attachForm ')+('"')+(form_buttons[0])+('"')+(' "bottom" 0 ')+('-attachPosition ')+('"')+(form_buttons[0])+('"')+(' "right" (')+('($buttons_space/2)')+(') ')+str(buttons_position[0]))
		if len(form_buttons)>2:
			for i in range(1,(len(form_buttons)-1)):
				formSettings=formSettings+((' -attachForm ')+('"')+(form_buttons[i])+('"')+(' "top" 0 ')+('-attachPosition ')+('"')+(form_buttons[i])+('"')+(' "left" (')+('($buttons_space/2)')+(') ')+str(buttons_position[i-1])+(' -attachForm ')+('"')+(form_buttons[i])+('"')+(' "bottom" 0 ')+('-attachPosition ')+('"')+form_buttons[i]+('"')+(' "right" (')+('($buttons_space/2)')+(') ')+str(buttons_position[i]))
		formSettings=formSettings+(' -attachForm '+'"'+form_buttons[-1]+'"'+' "top" 0 '+'-attachPosition '+'"'+form_buttons[-1]+'"'+' "left" ('+'($buttons_space/2)'+') '+str(buttons_position[-2])+' -attachForm '+'"'+form_buttons[-1]+'"'+' "bottom" 0 '+'-attachForm '+'"'+form_buttons[-1]+'"'+' "right" 0' )
		mel.eval("int $buttons_space=4;formLayout -edit "+formSettings+" "+form_name)
	else:
		if cmds.button(form_buttons[0], exists=True):
				cmds.deleteUI(form_buttons[0], control=True)
		cmds.button(form_buttons[0], label=(re.findall("[A-Z, a-z, 0-9]+$",form_buttons[0])[-1]), height=form_buttons_height)
		cmds.button(form_buttons[0],edit=True,parent=form_parent)

def addPathToProxyState():
	return cmds.checkBoxGrp("CUTool_RibArchive_useUpdateRootProxy", query=True, v1=True)
		
def optionsMenuCreateByArray(name='', label='', parent='', menuArray=''):
    '''
    This procedure create options menu
    name - name of the control
    label - visible label of the control
    parent - parent layout name
    menu - menu array
    '''
    mel.eval('optionMenu -label "' + label + '" -parent "' + parent + '" "' + name + '";')
    if menuArray:
        for i in range(0, len(menuArray)):
            mel.eval('menuItem -label "' + str(menuArray[i]) + '" -parent "' + name + '";')
    return name		
		
#CREATE TABS FOR MENU PROCEDURE
def CUTool_tabsLayout(tabLayout_name,tabLayout_parent,tabs_names):
	"""
	#EXAMPLE: id_tabs,id_frame=CUTool_tabsLayout("TabLayout name","TabLayout parent","Tabs names")
	#RESULT: tab name equal to (id_frame[tabs_names.index('Tab name')])
	"""
	id_tabs=[]
	id_frame=[]
	if cmds.tabLayout(tabLayout_name, exists=True):
		cmds.deleteUI(tabLayout_name, layout=True)
	cmds.tabLayout(tabLayout_name, parent=tabLayout_parent)
	for i in range(0,len(tabs_names)):
		id_tabs.append(tabLayout_name+'_Tab_0'+str(i))
		id_frame.append(tabLayout_name+'_FrameLayout_0'+str(i))
		cmds.columnLayout(id_tabs[i],adjustableColumn=True,parent=(tabLayout_name))
		cmds.frameLayout(id_frame[i], labelVisible=False,backgroundColor=[0.2,0.2,0.2],borderStyle="etchedOut",parent=(id_tabs[i]))
		cmds.tabLayout(tabLayout_name, edit=True, tabLabel=(id_tabs[i], tabs_names[i]))
	return(id_tabs,id_frame,tabs_names)

#CREATE TEXT FIELD AND CONNECTED TO FIELD BUTTON FOR DIRECTORY SETUP PROCEDURE
def CUTool_changeDirectory_button(button_name, parent_name,result_from_proc,mode,fileMode_int):
	"""
	#EXAMPLE: CUTool_changeDirectory_button("Button name for change directory", "Name of parent","Procedure with return result")
	#RESULT: Button name equal to "Button name for change directory", and textField name equal to "Button name for change directory"+"_textField"
	"""
	if cmds.rowLayout(str(button_name+"_rowLayout"), exists=True):
		cmds.deleteUI(str(button_name+"_rowLayout"), layout=True)
	cmds.rowLayout(str(button_name+"_rowLayout"), numberOfColumns=2,adjustableColumn=1,parent=parent_name)
	cmds.textField(str(button_name+"_textField"),text=result_from_proc,parent=(str(button_name+"_rowLayout")))
	command_for_button=('CUToolSetup.CUTool_changeDirectory('+'"'+str(button_name)+'"'+","+str(mode)+','+str(fileMode_int)+')')
	cmds.symbolButton(str(button_name+"_symbolButton"),image="navButtonBrowse.png",parent=str(button_name+"_rowLayout"), command=command_for_button)

#BUTTON PROCEDURE TO CHANGE DIRECTORY FOR BUTTON CONNECTED TEXT FIELD PROCEDURE
def CUTool_changeDirectory(button_name,mode,fileMode_int):
	Filefilter=["txt files (*.txt)", "Maya Binary (*.mb);;Maya ASCII (*.ma)", "Alembic cache (*.abc)", 'Avi (*.avi)']
	result=cmds.fileDialog2(caption="Please select target",fileFilter=Filefilter[mode], startingDirectory=(cmds.textField((button_name+"_textField"),query=True,text=True)),fileMode=fileMode_int)
	if result:
		cmds.textField((button_name+"_textField"),edit=True, text=str(result[0]))
	return result

def CUToolOffsetProcedure_exec(var):
	OffsetStart=cmds.intFieldGrp('CUTool_animatikSetup_StartFrameOffset', query=True, value1=True)
	OffsetStep=cmds.intFieldGrp('CUTool_animatikSetup_StepFrameOffset', query=True, value1=True)
	CUTool_ShotAnimationOffset(OffsetStart, OffsetStep ,var)

def CUTool_ShotAnimationOffset(timeStart, timeStep, var):
	list_shots=cmds.ls(type='shot')
	animCurves=[]
	animCurvesAll=(cmds.ls(type=['animCurveTU','animCurveTL','animCurveUU','animCurveTA','animCurveTT']))
	animCurvesRefs=(cmds.ls(type=['animCurveTU','animCurveTL','animCurveUU','animCurveTA','animCurveTT'], readOnly=True))
	for i in range(0, len(animCurvesAll)):
		if animCurvesAll[i] not in animCurvesRefs:
			animCurves.append(animCurvesAll[i])
	animCurvesSorted=[]
	if var=='plus':
		for i in range(0, len(animCurves)):
			KeyTimes_array=cmds.keyframe(animCurves[i],query=True,timeChange=True)
			if KeyTimes_array is not None:
				for keyTime_index in xrange((len(KeyTimes_array)-1), -1, -1):
					if KeyTimes_array[keyTime_index]>=int(timeStart):
						cmds.keyframe(animCurves[i], absolute=True, option= "move", edit=True, index=(keyTime_index, keyTime_index), timeChange=(int(KeyTimes_array[keyTime_index])+int(timeStep)))
		for i in range(0, len(list_shots)):
			current_shotStartTime=cmds.getAttr(str(list_shots[i])+".sequenceStartFrame")
			current_shotEndTime=cmds.getAttr(str(list_shots[i])+".sequenceEndFrame")
			if current_shotStartTime>=int(timeStart):
				cmds.setAttr(str(list_shots[i])+".sequenceStartFrame", (int(current_shotStartTime)+int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".sequenceEndFrame", (int(current_shotEndTime)+int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".startFrame", (int(current_shotStartTime)+int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".endFrame", (int(current_shotEndTime)+int(timeStep)))
	if var=='minus':
		for i in range(0, len(animCurves)):
			KeyTimes_array=cmds.keyframe(animCurves[i],query=True,timeChange=True)
			if KeyTimes_array is not None:
				for keyTime_index in range(0, len(KeyTimes_array)):
					if KeyTimes_array[keyTime_index]<=int(timeStart):
						cmds.keyframe(animCurves[i], absolute=True, option= "move", edit=True, index=(keyTime_index, keyTime_index), timeChange=(int(KeyTimes_array[keyTime_index])-int(timeStep)))
		for i in xrange((len(list_shots)-1), -1, -1):
			current_shotStartTime=cmds.getAttr(str(list_shots[i])+".sequenceStartFrame")
			current_shotEndTime=cmds.getAttr(str(list_shots[i])+".sequenceEndFrame")
			if current_shotStartTime>=int(timeStart):
				cmds.setAttr(str(list_shots[i])+".sequenceStartFrame", (int(current_shotStartTime)-int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".sequenceEndFrame", (int(current_shotEndTime)-int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".startFrame", (int(current_shotStartTime)-int(timeStep)))
				cmds.setAttr(str(list_shots[i])+".endFrame", (int(current_shotEndTime)-int(timeStep)))

def CUTool_ShotAnimationOffsetSecond(timeStart='', timeStep=''):
    '''
    '''
    if timeStart == '' and timeStep == '':
        timeStart = cmds.intFieldGrp('CUTool_animatikSetup_StartFrameOffset', query=True, value1=True)
        timeStep = cmds.intFieldGrp('CUTool_animatikSetup_StepFrameOffset', query=True, value1=True)
    #get all scene animation curves
    def getAnimationCurves():
        result = []
        curves = cmds.ls(type=['animCurveTU','animCurveTL','animCurveUU','animCurveTA','animCurveTT'])
        rCurves = cmds.ls(type=['animCurveTU','animCurveTL','animCurveUU','animCurveTA','animCurveTT'], readOnly=True)
        curves = [curves[i] for i in range(0, len(curves)) if curves[i] not in rCurves]
        [result.append(curves[i]) for i in range(0, len(curves)) if curves[i] not in result]
        return result
    #offset shots
    def moveShot(shot='', step=''):
        attr = [".sequenceStartFrame", ".endFrame", ".startFrame"]
        for i in range(0, len(attr)):
            cmds.setAttr(shot+attr[i], cmds.getAttr(shot+attr[i])+int(timeStep))
    #offset keys
    def moveKeys(startTime='', step='', curves=''):
        for i in range(0, len(curves)):
            if step > 0:
                keyMessage = 'keyframe -e -iub true -an objects -t "'+str(startTime)+':'+str(cmds.playbackOptions(query=True, animationEndTime=True))+'" -r -o over -tc '+str(step)+' '+curves[i]+'  ;'
                print keyMessage
                mel.eval(keyMessage)
            else:
                keyMessage = 'keyframe -e -iub true -an objects -t "'+str(cmds.playbackOptions(query=True, animationStartTime=True))+':'+str(startTime)+'" -r -o over -tc '+str(step)+' '+curves[i]+'  ;'
                print keyMessage
                mel.eval(keyMessage)
    #procedure
    shots = cmds.ls(type='shot')
    curves = getAnimationCurves()
    moveKeys(startTime=timeStart, step=timeStep, curves=curves)
    for i in range(0, len(shots)):
        start = cmds.getAttr(shots[i]+".sequenceStartFrame")
        if timeStep >= 0:
            if start > timeStart:
                moveShot(shot=shots[i], step=timeStep)
        else:
            if start <= timeStart:
                moveShot(shot=shots[i], step=timeStep)



#GET PATH TO CAMERAS FOLDER
def CUTool_PathToCamera_File():
    var=((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma"))
    return (var) and var or "C:/"

#GET PATH TO TEMPLATE FOLDER
def CUTool_PathToTemplate_File():
    var=((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))
    return (var) and var or "C:/"

#EXPORT CAMERAS FROM ANIMATIK TO NEW FILE
def CUTool_ExportCamerasFromAnimatik(path):
	cmds.select(cmds.ls(type='sequencer'))
	cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)

#EXPORT TEMPLATE FROM ANIMATIK TO NEW FILE WITH ONLY REFERENCED OBJECTS
def CUTool_ExportTemplateFromAnimatik(path):
    var_01=cmds.ls(type='reference')
    if len(var_01)>0:
        for i in range(0,len(var_01)):
            if(re.findall('chars',(cmds.referenceQuery(var_01[i], filename=True)))):
                continue
            else:
                temp=cmds.ls(cmds.referenceQuery(var_01[i], nodes=True), type='transform')
                if len(temp)>0:
                    cmds.select(temp,add=True)
        cmds.file(path, force=True, options='v=0', type='mayaAscii', preserveReferences=True, exportSelected=True)

#GET PATH TO CAMERAS FILE FOR CURRENT SCENE
def CUTool_findCams_File():
	if(CUTool_CheckFileExists() is True):
		temp=(OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma")
		return(CUTool_checkTargetFileExists(temp)is True and (OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_cams.ma")or"File not find")
	else:
		return("Scene not saved")

#GET PATH TO TEMPLATE FILE FOR CURRENT SCENE
def CUTool_findTemplate_File():
	if(CUTool_CheckFileExists() is True):
		temp=((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))
		return(CUTool_checkTargetFileExists(temp)is True and ((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/template/"+CUTool_GetInfoAboutScene('episode')+"_tmplate.ma"))or"File not find")
	else:
		return("Scene not saved")

#GET PATH TO TXT FILE WITH ANIMATION SETTINGS OR FOLDER
def CUTool_findAnimation_File():
    if(CUTool_CheckFileExists() is True):
    	temp=((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_anim.txt"))
    	return(CUTool_checkTargetFileExists(temp)is True and ((OSTYPE+"/"+CUTool_GetInfoAboutScene('project')+"/scenes/"+CUTool_GetInfoAboutScene('episode')+"/shared/"+CUTool_GetInfoAboutScene('episode')+"_anim.txt"))or"File not find")
    else:
    	return("Scene not saved")

#GET NAME OF USED CAMERA IN CURRENT SCENE
def CUTool_findUsedCamera():
    var_00=listTransformsCameras()
    var_01=(re.findall(str(CUTool_GetInfoAboutScene('episode')+CUTool_GetInfoAboutScene('scene')),str((cmds.listCameras())))) and (re.findall(str(CUTool_GetInfoAboutScene('episode')+CUTool_GetInfoAboutScene('scene')),str((cmds.listCameras()))))[0] or ("Camera not find")
    var_02=[i for i, item in enumerate(var_00) if re.search(var_01, item)]
    return (var_02) and (var_00[var_02[0]]) or ('Camera not find')

#GET INFO ABOUT SCENE EXP
def CUTool_GetInfoAboutScene(mode):
	if mode=='project':
		if len(re.findall('[A-Z,a-z,0-9]+',(cmds.file(query=True, location=True))))>3:
			return (str(re.findall('[A-Z,a-z,0-9]+',(cmds.file(query=True, location=True)))[3]))
		else: return("")
	if mode=='episode':
		return(re.findall("ep[0-9]+",(cmds.file(query=True, location=True))) and (re.findall("ep[0-9]+",(cmds.file(query=True, location=True)))[0]) or "")
	if mode=='scene':
		if re.findall("]*sc[0-9]*_dop*",(cmds.file(query=True, location=True))):
			return(re.findall("]*sc[0-9]*_dop*",(cmds.file(query=True, location=True)))[0])
		elif re.findall("sc[0-9]+",(cmds.file(query=True, location=True))):
			return(re.findall("sc[0-9]+",(cmds.file(query=True, location=True)))[0])
		else:
			return("")

#GET PATH OF CURRENT SCNE IF SCENE SAVED
def CUTool_GetFilePath():
	result=(cmds.file(query=True, location=True)).split("/")
	return(("/".join(result[0:-2]))+"/")

#CHECK CURRENT SCENE IS SAVED IN SCENE FOLDER
def CUTool_CheckLocation():
	return((re.findall("scenes",(cmds.file(query=True, location=True)))) and True or False)

#CHECK CURRENT SCENE IS SAVED
def CUTool_CheckFileExists():
	result=cmds.file(query=True, exists=True)
	return result

#CHECK FILE EXISTS
def CUTool_checkTargetFileExists(path):
	path=path.replace("/","\\")
	return((os.path.exists(path)) is True and True or False)

#CHECK TEMPLATE IS LOADED
def CUTool_checkTmplateIsLoaded():
	array=cmds.ls(references=True)
	result=''
	for i in range(len(cmds.ls(references=True))):
		result=re.findall('[A-Z,a-z,0-9]*tmplate[A-Z,a-z,0-9]*',array[i])
		if(re.findall('[A-Z,a-z,0-9]*tmplate[A-Z,a-z,0-9]*',array[i])):
			break
	return(len(result)>0 and "is loaded" or "is not loaded")

#GET REFERENCES LIST WITH CONTAINING SHAPES
def CUTool_getReferenceTransformsWithShapes():
	result=[]
	transforms_list=cmds.ls(transforms=True, readOnly=True, long=True)
	for i in range(0,len(transforms_list)):
		if(cmds.listRelatives(transforms_list[i],children=True,fullPath=True)):
			children_list=cmds.listRelatives(transforms_list[i],children=True,fullPath=True)
			for children_i in range(0,len(children_list)):
				if(cmds.ls(children_list[children_i],shapes=True)):
					result.append(transforms_list[i])
	return result

#GET CHARACTERS CONTAINING IN ROOT DIRECTORY //SERVER-3D/Project/UrfinJuse/assets/chars/ WITHOUT RENDER VERSION
def CUTool_getCharactersInlist():
	characters=[]
	root=OSTYPE+'/UrfinJuse/assets/'
	file_filter=['mb']
	file_dir=os.path.join(root,'chars/')
	file_contain=os.listdir(file_dir)
	for folder_i in range(0,len(file_contain)):
		if(re.findall('\.',file_contain[folder_i])):
			file_contain[folder_i] = None
	file_contain=[x for x in file_contain if x!=None]
	for folder_i in range(0,len(file_contain)):
		if os.path.exists(('/'.join((os.path.join(file_dir,(file_contain[folder_i]+'/'),'maya')).split('\\')))):
			file_contain_temp=os.listdir(('/'.join((os.path.join(file_dir,(file_contain[folder_i]+'/'),'maya')).split('\\'))))
			for file_i in range(len(file_contain_temp)):
				if file_contain_temp[file_i].split('.')[-1] in file_filter and file_contain_temp[file_i] not in characters:
					characters.append(file_contain[folder_i]+' ('+file_contain_temp[file_i].split('.')[0]+')')
		else: continue
	for i in range(len(characters)):
		characters[i]='/'.join((characters[i]).split("\\"))
		cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list", edit=True, append=characters[i])

#SETUP RANGES FROM SETTINGS FIELD
def CUTool_select_update_animation_frames():
	cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True)
	cmds.playbackOptions(minTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True),animationStartTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value1=True))
	cmds.playbackOptions(maxTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value2=True),animationEndTime=cmds.intFieldGrp("CUTool_Shablon_setup_animation_field", query=True, value2=True))


#SETUP CAMERA FOR ANIMATION
def CUTool_setupUsedCamera():
	cmds.undoInfo(state=1)
	try:
		if(cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True):
			cmds.loadPlugin("RenderMan_for_Maya")
	except:
		print 'Failed to load Renderman'
	cmds.pluginInfo("C:/Program Files/Pixar/RenderManStudio-4.0-maya2013/plug-ins/RenderMan_for_Maya.mll", edit=True, autoload=True)
	list_settings=['"defaultRenderGlobals.currentRenderer" -type "string" "renderMan"','"defaultResolution.width" 2048','"defaultResolution.height" 858','"defaultRenderGlobals.animation" 1','"defaultRenderGlobals.pff" 1','"defaultRenderGlobals.peie" 1','"defaultRenderGlobals.animationRange" 0','"defaultRenderGlobals.extensionPadding" 4','"defaultResolution.lockDeviceAspectRatio" 0','"defaultRenderGlobals.imageFormat" 3','"defaultResolution.deviceAspectRatio" 2.387','"defaultResolution.pixelAspect" 1','-l false "defaultRenderGlobals.startFrame"','"defaultRenderGlobals.startFrame" `playbackOptions -q -ast`','-l false "defaultRenderGlobals.endFrame"','"defaultRenderGlobals.endFrame" `playbackOptions -q -aet`']
	for i in range(0,(len(list_settings)-1)):
		mel.eval("setAttr "+list_settings[i])
	if(CUTool_findUsedCamera() != "Camera not find"):
		#camera setup
		try:
			usedCameraTransform = CUTool_findUsedCamera()
			usedCamera = cmds.ls(CUTool_findUsedCamera(), dag=True, leaf=True, cameras=True)
			print 'camera used: ' + str(usedCamera)
			cmds.setAttr(usedCamera[0]+".renderable", 1)
			if cmds.getAttr(usedCamera[0]+'.horizontalFilmAperture', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.horizontalFilmAperture', 1.203)
				cmds.setAttr(usedCamera[0]+'.horizontalFilmAperture', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.horizontalFilmAperture', lock=False)
				cmds.setAttr(usedCamera[0]+'.horizontalFilmAperture', 1.203)
				cmds.setAttr(usedCamera[0]+'.horizontalFilmAperture', lock=True)
			if cmds.getAttr(usedCamera[0]+'.verticalFilmAperture', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.verticalFilmAperture', 0.504)
				cmds.setAttr(usedCamera[0]+'.verticalFilmAperture', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.verticalFilmAperture', lock=False)
				cmds.setAttr(usedCamera[0]+'.verticalFilmAperture', 0.504)
				cmds.setAttr(usedCamera[0]+'.verticalFilmAperture', lock=True)
			if cmds.getAttr(usedCamera[0]+'.lensSqueezeRatio', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.lensSqueezeRatio', 1.000)
				cmds.setAttr(usedCamera[0]+'.lensSqueezeRatio', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.lensSqueezeRatio', lock=False)
				cmds.setAttr(usedCamera[0]+'.lensSqueezeRatio', 1.000)
				cmds.setAttr(usedCamera[0]+'.lensSqueezeRatio', lock=True)
			if cmds.getAttr(usedCamera[0]+'.focalLength', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.focalLength', 75.000)
				cmds.setAttr(usedCamera[0]+'.focalLength', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.focalLength', lock=False)
				cmds.setAttr(usedCamera[0]+'.focalLength', 75.000)
				cmds.setAttr(usedCamera[0]+'.focalLength', lock=True)
			if cmds.getAttr(usedCamera[0]+'.cameraScale', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.cameraScale', 1.000)
				cmds.setAttr(usedCamera[0]+'.cameraScale', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.cameraScale', lock=False)
				cmds.setAttr(usedCamera[0]+'.cameraScale', 1.000)
				cmds.setAttr(usedCamera[0]+'.cameraScale', lock=True)
			if cmds.getAttr(usedCamera[0]+'.nearClipPlane', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.nearClipPlane', 0.1)
				cmds.setAttr(usedCamera[0]+'.nearClipPlane', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.nearClipPlane', lock=False)
				cmds.setAttr(usedCamera[0]+'.nearClipPlane', 0.1)
				cmds.setAttr(usedCamera[0]+'.nearClipPlane', lock=True)
			if cmds.getAttr(usedCamera[0]+'.farClipPlane', lock=True) is False:
				cmds.setAttr(usedCamera[0]+'.farClipPlane', 10000.000)
				cmds.setAttr(usedCamera[0]+'.farClipPlane', lock=True)
			else:
				cmds.setAttr(usedCamera[0]+'.farClipPlane', lock=False)
				cmds.setAttr(usedCamera[0]+'.farClipPlane', 10000.000)
				cmds.setAttr(usedCamera[0]+'.farClipPlane', lock=True)
			cmds.setAttr(usedCamera[0]+'.filmFit', 1)
			cmds.setAttr(usedCameraTransform+'.scale', lock=True)
			cmds.setAttr(usedCameraTransform+'.scaleX', lock=True)
			cmds.setAttr(usedCameraTransform+'.scaleY', lock=True)
			cmds.setAttr(usedCameraTransform+'.scaleZ', lock=True)
			cmds.setAttr(usedCameraTransform+'.translate', lock=True)
			cmds.setAttr(usedCameraTransform+'.translateX', lock=True)
			cmds.setAttr(usedCameraTransform+'.translateY', lock=True)
			cmds.setAttr(usedCameraTransform+'.translateZ', lock=True)
			cmds.setAttr(usedCameraTransform+'.rotate', lock=True)
			cmds.setAttr(usedCameraTransform+'.rotateX', lock=True)
			cmds.setAttr(usedCameraTransform+'.rotateY', lock=True)
			cmds.setAttr(usedCameraTransform+'.rotateZ', lock=True)
			cmds.setAttr(usedCameraTransform+'.visibility', lock=True)
			cmds.lookThru(CUTool_findUsedCamera())
		except:
			cmds.warning('Please check camera: '+usedCamera[0])

#DELETE UNUSED CAMERAS IN CURRENT SCENE
def CUTool_deleteAllUnusedCams():
	var_01=listTransformsCameras()
	var_02=[i for i, item in enumerate(var_01) if re.search(CUTool_findUsedCamera(), item)]
	if var_02:
		for i in range(0,len(var_02)):
			var_01.pop(var_02[i])
	cmds.delete(var_01)

#IMPORT CAMERAS FOR CURRENT SCENE
def CUTool_importCamerasFile():
	path=cmds.textField("CUTool_changeCameraDirectory_textField", query=True, text=True)
	cmds.file(path, i=True, type="mayaAscii", renameAll=True,mergeNamespacesOnClash=False,renamingPrefix=(CUTool_GetInfoAboutScene('episode')+"_cams"),preserveReferences=True)

#REFERENCE TEMPLATE FOR CURENNT SCENE
def CUTool_importTmplateFile():
	path=cmds.textField("CUTool_changeTemplateDirectory_textField", query=True, text=True)
	cmds.file(path,reference=True,namespace=(CUTool_GetInfoAboutScene('episode')+"_tmplate"),referenceNode=(CUTool_GetInfoAboutScene('episode')+"_tmplateRN"))

#ADD SELECTED TO LIST OF REFENCES
def CUTool_add_reference_to_list():
    selected=cmds.ls(sl=True, readOnly=True)
    references=[]
    temp=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
    if temp is None:
        temp=['.']
    for i in range(0,len(selected)):
        references.append(cmds.referenceQuery(selected[i],filename=True))
    references=list(set(references))
    for i in range(0,len(references)):
        if references[i].split('/')[-1]+' --- '+references[i] not in temp:
            cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, append=references[i].split('/')[-1]+' --- '+references[i])

#REMOVE SELECTED FROM LIST OF REFERENCES
def CUTool_remove_reference_from_list():
	selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, selectItem=True)
	for i in range(0,len(selected)):
		cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, removeItem=selected[i])

#REMOVE ALL REFERENCES FROM LIST OF REFERENCES
def CUTool_clear_all_reference_from_list():
	selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	for i in range(0,len(selected)):
		cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, removeItem=selected[i])

#SELECT REFERENCE FROM LIST OF REFERENCES
def CUTool_select_reference_from_list(input):
	for_select=[]
	if input=='Selected':
		selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, selectItem=True)
	elif input=='All':
		selected=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	if selected:
		for i in range(0,len(selected)):
			if (cmds.referenceQuery(selected[i].split(' --- ')[-1],nodes=True, dagPath=True)):
				for_select=for_select+(cmds.referenceQuery(selected[i].split(' --- ')[-1],nodes=True, dagPath=True))
		cmds.select(for_select)

#GET REFERENCES FROM VIEWPORT
def CUTool_Get_references_from_viewport_with_animation(input):
	#CUTool_setupUsedCamera()
	references=[]
	temp=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	transform_list=''
	if temp is None:
		temp=['.']
	if(input==1):
		cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
		cmds.select(clear=True)
		for frame in range(int(cmds.playbackOptions(query=True,minTime=True)),int(cmds.playbackOptions(query=True,maxTime=True))+1):
			cmds.currentTime(frame)
			om.MGlobal.selectFromScreen(0, 0, (omUI.M3dView.active3dView()).portWidth(), (omUI.M3dView.active3dView()).portHeight(), om.MGlobal.kAddToList)
		transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
		cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
		cmds.select(clear=True)
	if(input==0):
		cmds.select(clear=True)
		om.MGlobal.selectFromScreen(0, 0, (omUI.M3dView.active3dView()).portWidth(), (omUI.M3dView.active3dView()).portHeight(), om.MGlobal.kAddToList)
		transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
		cmds.select(clear=True)
	if transform_list!='':
		for i in range(0,len(transform_list)):
			references.append(cmds.referenceQuery(transform_list[i],filename=True))
	if references!=[]:
		for i in range(0,len(references)):
			if references[i] not in temp:
				temp.append(references[i])
				cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, append=references[i].split('/')[-1]+' --- '+references[i])

#REFERENCE CHARACTERS FROM LIST OF CHARACTERS
def CUTool_referenceCharacterFromList():
	reference_path = cmds.textScrollList("CUTool_Shablon_setup_referencesChars_list",query=True,selectItem=True)
	loadManually = cmds.checkBoxGrp('CUTool_loadManuallyChars_control', query=True, v1=True) and 'none' or 'all'
	count = cmds.intFieldGrp('CUTool_Shablon_setup_charsCount_int', query=True, v1=True)
	for i in range(0,len(reference_path)):
		projectChar = reference_path[i].split(' (')[0]
		reference_pathTemp = (reference_path[i].split('(')[-1]).split(')')[0]
		print '\tLoad reference', (OSTYPE+'/UrfinJuse/assets/chars/'+projectChar+'/maya/'+reference_pathTemp+'.mb'), 'x', count, 'references'
		for n in range(0, count):
			cmds.file(OSTYPE+"/UrfinJuse/assets/chars/"+projectChar+"/maya/"+reference_pathTemp+".mb", reference=True, mergeNamespacesOnClash=False, type="mayaBinary", options="v=0;", loadReferenceDepth=loadManually, namespace=reference_pathTemp)
			print '\n\t__________________\n\tcommand for reference : ' + reference_pathTemp + '\n\t_ _ _ _ _ _ _ _ _\n\n\timport maya.cmds as cmds;cmds.file("'+OSTYPE+"/UrfinJuse/assets/chars/"+projectChar+"/maya/"+reference_pathTemp+'.mb", reference=True, mergeNamespacesOnClash=False, type="mayaBinary", options="v=0;", namespace="'+reference_pathTemp+'")\n\n\t__________________\n'

#UNLOAD SELECTED REFERENCES IN LIST OF REFERENCES
def CUTool_referenceUnloadSelection(input):
	if(input=="Selected"):
		references_list=cmds.textScrollList("CUTool_Shablon_setup_references_list",query=True,selectItem=True)
	if(input=="All"):
		references_list=cmds.textScrollList("CUTool_Shablon_setup_references_list",query=True,allItems=True)
	if references_list:
		for i in range(0,len(references_list)):
			if CUTool_checkReferenceExists(references_list[i].split(' --- ')[-1]) is True:
				cmds.file(cmds.referenceQuery(references_list[i].split(' --- ')[-1],filename=True),unloadReference=True)
				cmds.textScrollList("CUTool_Shablon_setup_references_list", edit=True, removeItem=references_list[i])

#UNLOAD REFERENCES NOT IN LIST OF REFERENCES
def CUTool_referenceUnloadNotInList():
	reference_in_list=cmds.textScrollList("CUTool_Shablon_setup_references_list", query=True, allItems=True)
	reference_in_list=[reference_in_list[i].split(' --- ')[-1] for i in range(0, len(reference_in_list))]
	reference_used=[]
	references_all=CUTool_getReferenceTransformsWithShapes()
	for reference_i in range(0,len(references_all)):
		 reference_used.append(cmds.referenceQuery(references_all[reference_i],filename=True))
	reference_used=list(set(reference_used))
	reference_used=[x for x in reference_used if x not in reference_in_list]
	if reference_used:
		for reference_i in range(0,len(reference_used)):
			if CUTool_checkReferenceExists(reference_used[reference_i]) is True:
				try:
					cmds.file(cmds.referenceQuery(reference_used[reference_i],filename=True),unloadReference=True)
				except:
					print 'reference', reference_used[reference_i], 'failed to unload'

#GET ANIMATION RANGES FROM FILE FOR CURRENT SCENE
def CUTool_setup_ranges_from_file():
	if(CUTool_findUsedCamera())!="Camera not find":
		command_string=((((open(cmds.textField("CUTool_changeAnimationileDirectory_textField", query=True, text=True),"r")).read())).split("\nCoordinates")[0]).split("\n")
		for i in range(0,len(command_string)):
			if CUTool_findUsedCamera() in command_string[i]:
				cmds.playbackOptions(minTime=((command_string[i+1]).split('= '))[1], animationStartTime=((command_string[i+1]).split('= '))[1])
				cmds.playbackOptions(maxTime=((command_string[i+2]).split('= '))[1], animationEndTime=((command_string[i+2]).split('= '))[1])
				cmds.currentTime(((command_string[i+1]).split('= '))[1])
				break
	else:
		cmds.error("THIS SCENE IS NOT SHABLON")

#PRINT INFO ABOUT SCENE
def CUTool_updateInfo():
	if(CUTool_CheckFileExists() is True)&(CUTool_CheckLocation() is True):
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\nName: "+(cmds.file(query=True, sceneName=True, shortName=True))+"\nLocation: "+('/ '.join((cmds.file(query=True, location=True)).split('/')))+"\nEpisode: "+CUTool_GetInfoAboutScene('episode')+"\nScene number: "+CUTool_GetInfoAboutScene('scene')+"\n\nOK\n\n\n\n"),backgroundColor=[0.15,0.25,0.15])
	elif(CUTool_CheckFileExists() is True)&(CUTool_CheckLocation()is False):
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\nName: "+(cmds.file(query=True, sceneName=True, shortName=True))+"\nLocation: "+('/ '.join((cmds.file(query=True, location=True)).split('/')))+"\nEpisode: "+CUTool_GetInfoAboutScene('episode')+"\nScene number: "+CUTool_GetInfoAboutScene('scene')+"\n\nINVALID LOCATION!!!\n\n\n\n"),backgroundColor=[0.25,0.25,0.15])
	else:
		cmds.text("CUTool_info_text01", align="left", edit=True, label=("\n\nSCENE NOT SAVED!!!\n\n\n\n"),backgroundColor=[0.3,0.15,0.15])

def CUTool_SaveLoadControlAttrDialogWindow(mode):
	if mode=='save':
		path=cmds.fileDialog2(fileFilter="txt files (*.txt)", dialogStyle=1, fm=0)[0]
		CUTool_copyCoordinatesToFile(path)
	if mode=='load':
		path=cmds.fileDialog2(fileFilter="txt files (*.txt)", dialogStyle=1, fm=1)[0]
		CUTool_loadCoordinatesFromFile(path)

#SAVE CONTROL TRANFORM ATTRIBUTES FOR SELECTED REFERENCED OBJECTS
def CUTool_copyCoordinatesToFile(path):
	transformations_save=''
	selected_Tcontrol_array=[]
	selected_control_array=cmds.ls(sl=True, dag=True, leaf=True, long=True, type='nurbsCurve')
	if selected_control_array:
		if len(selected_control_array)>0:
			for i in range(0, len(selected_control_array)):
					if '|' in selected_control_array[i]:
						selected_Tcontrol_array_TEMP='|'.join(selected_control_array[i].split('|')[0:-1])
						if selected_Tcontrol_array_TEMP:
							selected_Tcontrol_array.append(selected_Tcontrol_array_TEMP)
					else:
						selected_Tcontrol_array.append(selected_control_array[i])
	if selected_Tcontrol_array:
		if len(selected_Tcontrol_array)>0:
			for i in range(0, len(selected_Tcontrol_array)):
				if '|' in selected_Tcontrol_array[i]:
					if ':' in selected_control_array[i]:
						NameForControl=selected_Tcontrol_array[i].split('|')[-1]
						len_namespace=len(NameForControl.split(':'))
						if len_namespace and len_namespace>2:
							NameForControl=':'.join((NameForControl.split(':'))[-2:])
					else:
						NameForControl=selected_Tcontrol_array[i].split('|')[-1]
				else:
					NameForControl=selected_Tcontrol_array[i]
				translateAttr_var=str(cmds.getAttr(selected_Tcontrol_array[i]+'.translate')[0])
				translateAttr_var=(str(translateAttr_var).split('(')[-1]).split(')')[0]
				rotateAttr_var=str(cmds.getAttr(selected_Tcontrol_array[i]+'.rotate')[0])
				rotateAttr_var=(str(rotateAttr_var).split('(')[-1]).split(')')[0]
				scaleAttr_var=str(cmds.getAttr(selected_Tcontrol_array[i]+'.scale')[0])
				scaleAttr_var=(str(scaleAttr_var).split('(')[-1]).split(')')[0]
				transformations_save_TEMP='NAME '+str(NameForControl)+' NAME'
				if translateAttr_var:
					transformations_save_TEMP=transformations_save_TEMP+'\nTRANSLATE '+str(translateAttr_var)+' TRANSLATE'
				else:
					transformations_save_TEMP=transformations_save_TEMP+'\nTRANSLATE NONE TRANSLATE'
				if rotateAttr_var:
					transformations_save_TEMP=transformations_save_TEMP+'\nROTATE '+str(rotateAttr_var)+' ROTATE'
				else:
					transformations_save_TEMP=transformations_save_TEMP+'\nROTATE NONE ROTATE'
				if scaleAttr_var:
					transformations_save_TEMP=transformations_save_TEMP+'\nSCALE '+str(scaleAttr_var)+' SCALE'
				else:
					transformations_save_TEMP=transformations_save_TEMP+'\nSCALE NONE SCALE'
				transformations_save_TEMP=transformations_save_TEMP+'\n\nOBJECT_ATTRIBUTE\n\n'
				if transformations_save_TEMP:
					transformations_save=transformations_save+str(transformations_save_TEMP)
	if transformations_save:
		file=open(path,"w")
		file.write(transformations_save)
		file.close

#LOAD CONTROL TRANFORM ATTRIBUTES FOR ALL SIMILIAR SAVED CONTROLS
def CUTool_loadCoordinatesFromFile(path):
	control_array=cmds.ls(dag=True, leaf=True, long=True, type='nurbsCurve')
	selected_Tcontrol_array=[]
	if control_array:
		if len(control_array)>0:
			for i in range(0, len(control_array)):
				if '|' in control_array[i]:
					selected_Tcontrol_array_TEMP='|'.join(control_array[i].split('|')[0:-1])
					if selected_Tcontrol_array_TEMP:
						selected_Tcontrol_array.append(selected_Tcontrol_array_TEMP)
				else:
					selected_Tcontrol_array.append(control_array[i])
	if (os.path.isfile(path)):
		command_string=(open(path,"r").readlines())
		for line_i in range(0,len(command_string)):
			command_string[line_i]=command_string[line_i].strip("\n")
		command_string=((" ".join(command_string)).split("OBJECT_ATTRIBUTE"))
		for i in range(0,len(command_string)):
			if len(command_string[i])>5:
				NAME_TEMP=(command_string[i].split('NAME')[1]).split(' ')[1]
				TRANSLATE_TEMP=(command_string[i].split('TRANSLATE')[1]).split(', ')
				ROTATE_TEMP=(command_string[i].split('ROTATE')[1]).split(', ')
				SCAlE_TEMP=(command_string[i].split('SCALE')[1]).split(', ')
			for n in range(0, len(selected_Tcontrol_array)):
				if NAME_TEMP and TRANSLATE_TEMP and ROTATE_TEMP and SCAlE_TEMP:
					if NAME_TEMP in selected_Tcontrol_array[n] or selected_Tcontrol_array[n]==NAME_TEMP:
						if 'NONE' not in TRANSLATE_TEMP:
							try:
								cmds.setAttr((selected_Tcontrol_array[n]+'.translate'), float(TRANSLATE_TEMP[0]), float(TRANSLATE_TEMP[1]), float(TRANSLATE_TEMP[2]), type='double3')
							except:
								cmds.warning('Attribute not keyable!')
						if 'NONE' not in ROTATE_TEMP:
							try:
								cmds.setAttr((selected_Tcontrol_array[n]+'.rotate'), float(ROTATE_TEMP[0]), float(ROTATE_TEMP[1]), float(ROTATE_TEMP[2]), type='double3')
							except:
							   cmds.warning('Attribute not keyable!')
						if 'NONE' not in SCAlE_TEMP:
							try:
								cmds.setAttr((selected_Tcontrol_array[n]+'.scale'), float(SCAlE_TEMP[0]), float(SCAlE_TEMP[1]), float(SCAlE_TEMP[2]), type='double3')
							except:
								cmds.warning('Attribute not keyable!')

#SAVE ANIMATION COORDINATES, RANGES, CHARACTERS
def CUTool_SaveAnimationCoordinates():
	#time range
	if(cmds.ls(type="shot")):
		shot_list=cmds.ls(type="shot")
		shot_for_save=""
		for shot_i in range(0,len(shot_list)):
			shot_for_save+="\nSHOTNAME_T= "+str(shot_list[shot_i])[0]
			shot_for_save+="\nCAMERA_T= "+str((cmds.listRelatives((cmds.shot(shot_list[shot_i],query=True,currentCamera=True)),parent=True))[0])
			shot_for_save+="\nSTART_T= "+str(cmds.shot(shot_list[shot_i],query=True,startTime=True))
			shot_for_save+="\nEND_T= "+str(cmds.shot(shot_list[shot_i],query=True,endTime=True))
	else:
		shot_for_save=""
	#get animated objects
	anim_curves=(cmds.ls(type=("animCurveTU", "animCurveTA", "animCurveTL")))
	if(cmds.listConnections(anim_curves,type="camera")):
		anim_curves_cameras=(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTU"))+(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTA"))+(cmds.listConnections((cmds.ls(dag=True, leaf=True,cameras=True)+cmds.listCameras()),type="animCurveTL"))
	else:
		anim_curves_cameras=""
	anim_objects=[]
	info_for_save="";
	for i in range(0,len(anim_curves)):
		if cmds.ls(anim_curves[i],readOnly=True)is not True:
			if anim_curves[i] not in anim_curves_cameras:
				if(cmds.listConnections(anim_curves[i], type="transform"))is not None:
					anim_objects+=(cmds.listConnections(anim_curves[i], type="transform"))
	anim_objects=list(set(anim_objects))
	typeSetArray(anim_objects,"transform")
	#get info for save
	for i in range(0,len(anim_objects)):
		character_type=1
		if(cmds.referenceQuery(anim_objects[i], isNodeReferenced=True)):
			if(re.findall('props',(cmds.referenceQuery(anim_objects[i], filename=True)))):
				character_type=0
		anim_curves=getConnectionsByType(anim_objects[i],['animCurveTU','animCurveTA','animCurveTL'])
		info_for_save+=("\nObject_settings\nOBJECT_T "+str(anim_objects[i])+"\nCHARACTER_T "+str(character_type))
		for anim_i in range(0,len(anim_curves)):
			if cmds.nodeType((cmds.listConnections(anim_curves[anim_i],plugs=True)[0]).split('.')[0])=='transform':
				info_for_save+=("\nCurve\nCURVE_T "+str(anim_curves[anim_i])+"\nNODE_T "+str(cmds.nodeType(anim_curves[anim_i]))+"\nATTRIBUTE_T "+str(((cmds.listConnections(anim_curves[anim_i],plugs=True)[0]).split('.'))[1]))
				anim_objects_keys=cmds.keyframe(anim_curves[anim_i],query=True,timeChange=True)
				info_for_save+="\nKEYTYPE_T "
				if anim_objects_keys:
					for key_i in range(0,len(anim_objects_keys)):
						if cmds.keyframe(anim_curves[anim_i],query=True,time=(anim_objects_keys[key_i],anim_objects_keys[key_i]),breakdown=True):
							info_for_save+=("B"+" ")
						else:
							info_for_save+=("K"+" ")
					info_for_save+="\nKEYTIME_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(anim_objects_keys[key_i])+" ")
					info_for_save+="\nKEYVALUE_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(cmds.keyframe(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), valueChange=True)[0])+" ")
					info_for_save+="\nINTANGTYPE_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), inTangentType=True)[0])+" ")
					info_for_save+="\nOUTTANGTYPE_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), outTangentType=True)[0])+" ")
					info_for_save+="\nINTANGANGLE_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), inAngle=True)[0])+" ")
					info_for_save+="\nOUTTANGANGLE_T "
					for key_i in range(0,len(anim_objects_keys)):
						info_for_save+=(str(cmds.keyTangent(anim_curves[anim_i], query=True, time=(anim_objects_keys[key_i],anim_objects_keys[key_i]), outAngle=True)[0])+" ")
					info_for_save+="\n"
	file=open(((cmds.textField("CUTool_changeAnimationileDirectoryForSave_textField", query=True, text=True))),"w")
	file.write(" Copyright (c) Melnitsa Studio.\n"+str(cmds.about(cd=True))+"\n This file contains information on animaton curves for Maya\n")
	file.write(shot_for_save)
	file.write("\nCoordinates\n")
	file.write(info_for_save)
	file.close()

#LOAD COORDINATES FROM FILE
def CUTool_loadFromFileCoordinates():
    current_time=(cmds.currentTime(query=True))
    if(os.path.isfile(cmds.textField("CUTool_changeAnimationileDirectory_textField", query=True, text=True))):
        command_string=(open(cmds.textField("CUTool_changeAnimationileDirectory_textField", query=True, text=True),"r").readlines())
        for line_i in range(0,len(command_string)):
            command_string[line_i]=command_string[line_i].strip("\n")
        command_string=((" ".join(command_string)).split("Coordinates")[1]).split("Object_settings")
        for obj_i in range(1,len(command_string)):
            command_target=""+command_string[obj_i].split(" ")[(command_string[obj_i].split(" ")).index("OBJECT_T")+1]
            command_target_type=command_string[obj_i].split(" ")[(command_string[obj_i].split(" ")).index("CHARACTER_T")+1]
            if (int(command_target_type)==0):
                command_target=(CUTool_GetInfoAboutScene('episode')+"_tmplate:"+command_target)
            command_buffer=command_string[obj_i].split(" Curve ")
            if(cmds.objExists(command_target)):
                for crv_i in range(1,len(command_buffer)):
                    key_name=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("CURVE_T")+1:(command_buffer[crv_i].split(" ")).index("NODE_T")]
                    key_node=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("NODE_T")+1:(command_buffer[crv_i].split(" ")).index("ATTRIBUTE_T")]
                    key_attr=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("ATTRIBUTE_T")+1:(command_buffer[crv_i].split(" ")).index("KEYTYPE_T")]
                    key_attr_type=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("KEYTIME_T")-1]
                    key_attr_time=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYTIME_T")+1:(command_buffer[crv_i].split(" ")).index("KEYVALUE_T")-1]
                    key_attr_value=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("KEYVALUE_T")+1:(command_buffer[crv_i].split(" ")).index("INTANGTYPE_T")-1]
                    key_attr_inType=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("INTANGTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("OUTTANGTYPE_T")-1]
                    key_attr_outType=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("OUTTANGTYPE_T")+1:(command_buffer[crv_i].split(" ")).index("INTANGANGLE_T")-1]
                    key_attr_inAngle=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("INTANGANGLE_T")+1:(command_buffer[crv_i].split(" ")).index("OUTTANGANGLE_T")-1]
                    key_attr_outAngle=command_buffer[crv_i].split(" ")[(command_buffer[crv_i].split(" ")).index("OUTTANGANGLE_T")+1:]
                    key_size=len(key_attr_value)
                    if(key_node,key_attr,key_name,key_attr_type,key_attr_time,key_attr_value,key_attr_inAngle,key_attr_outAngle,key_attr_inType,key_attr_outType,key_size):
                        key_node=cmds.createNode(key_node[0], name=key_name[0])
                        for key_i in range(key_size):
                            key_breakdown=(key_attr_type[key_i]=="B")
                            cmds.setKeyframe(key_node, time=key_attr_time[key_i], value=float(key_attr_value[key_i]), breakdown=key_breakdown)
                            cmds.keyTangent(key_node, inAngle=key_attr_inAngle[key_i], outAngle=key_attr_outAngle[key_i], inTangentType='flat', outTangentType='flat')
                            cmds.keyTangent(key_node, inTangentType=key_attr_inType[key_i], outTangentType=key_attr_outType[key_i])
                        cmds.setKeyframe(key_node, breakdown=0, hierarchy=0, controlPoints=0, shape=0)
                        key_attr_change=cmds.keyframe(key_node, time=(current_time,current_time), query=True, valueChange=True)
                        if mel.eval("attributeExists "+'"'+key_attr[0]+'" '+command_target):
							try:
								cmds.setAttr((command_target+"."+key_attr[0]), key_attr_change[0])
								cmds.delete(key_node)
							except:
								try:
									cmds.delete(key_node)
								except:
									continue
                        else:
                            cmds.delete(key_node)

#GET LIST OF CHARACTERS FROM VIEWPORT WITH ANIMATION
def getCharsFromCameraList():
	characters=[]
	selectionMask_cr(["Joint","Deformer","Dynamic","Rendering","Other","Marker"],"false")
	cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
	cmds.select(clear=True)
	for frame in range(int(cmds.playbackOptions(query=True,minTime=True)),int(cmds.playbackOptions(query=True,maxTime=True))+1,100):
		cmds.currentTime(frame)
		om.MGlobal.selectFromScreen(((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth())), (omUI.M3dView.active3dView()).portWidth()/30, ((omUI.M3dView.active3dView()).portWidth()-((cmds.getAttr("defaultResolution.width")-(omUI.M3dView.active3dView()).portWidth()))), ((omUI.M3dView.active3dView()).portHeight())-((omUI.M3dView.active3dView()).portWidth()/30), om.MGlobal.kAddToList)
	transform_list=(cmds.ls(sl=True, readOnly=True,long=True))
	cmds.currentTime(cmds.playbackOptions(query=True,minTime=True))
	cmds.select(clear=True)
	for i in range(0,len(transform_list)):
		if  re.findall('chars',(cmds.referenceQuery(transform_list[i], filename=True))):
			characters.append(cmds.referenceQuery(transform_list[i],filename=True))
	characters=list(set(characters))
	return characters

def emoe():	
	import maya.cmds as cmds
	for i in cmds.ls(type=["hyperView","hyperLayout","hyperGraphInfo"]):
		print i
		if not cmds.referenceQuery(i,inr=True) and i!="hyperGraphInfo":
			cmds.delete(i)	
			
def addProxyToSelected(switch=False):
    references = []
    selected = cmds.ls(sl=True, dag=True, readOnly=True)
    for i in range(0 ,len(selected)):
        try:
            node = cmds.referenceQuery(selected[i], referenceNode=True)
            if node not in references:
                references.append(node)
        except:
            print '\tfailed to find reference node for', selected[i]
    for i in range(0, len(references)):
        proxyManager = cmds.listConnections(references[i], type="proxyManager")
        path = cmds.referenceQuery(references[i], unresolvedName=True, filename=True).split('{')[0]
        path = pathToNetwork(path)
        pathProxy = findProxy(path)
        if proxyManager is None:
            if not pathProxy:
                pathProxy = createProxyByPath(original=path)
            addProxyMessage = 'proxyAdd "' + references[i] + '" "' + pathProxy + '" "";'
            print '\t', addProxyMessage
            if ':' not in references[i]:
                mel.eval(addProxyMessage)
            else:
                dialogWindow(label='Add proxy', text=('Do you really want to add proxy for '+references[i]+'???'), command=('mel.eval(\''+addProxyMessage+'\')'))
            proxyManager = cmds.listConnections(references[i], type="proxyManager")
        if switch is True:
            nodeToSwitch = cmds.listConnections(proxyManager, type="reference")
            nodeToSwitch = [nodeToSwitch[n] for n in range(0, len(nodeToSwitch)) if nodeToSwitch[n] != node][0]
            switchProxyMessage = 'proxySwitch '+nodeToSwitch+';'
            print switchProxyMessage
            mel.eval(switchProxyMessage)

#LIST CAMERA TRANSFORMS
def listTransformsCameras():
    return cmds.listRelatives(cmds.ls(cameras=True),parent=True)

#GET CONNECTIONS LIST BY NODE TYPE
def getConnectionsByType(var01,var02):
	result=[]
	for i in range(0,len(var02)):
		if cmds.listConnections(var01, type=var02[i]) is not None:
		    if len(cmds.listConnections(var01, type=var02[i]))!=0:
			    result+=(cmds.listConnections(var01, type=var02[i]))
	return result

#ARRAY REMOVE FROM ARRAY
def arrayRemoveFromArray(var01,var02):
    for i in range(0,len(var02)):
        if var02[i] in var01:
            var01.pop(var01.index(var02[i]))
            arrayRemoveFromArray(var01,var02)
            break

#SORT LIST BY NODE TYPE
def typeSetArray(var01,var02):
		for i in range(0,len(var01)):
			if cmds.nodeType(var01[i])==var02: continue
			else:
				var01.pop(i)
				typeSetArray(var01,var02)
				break

#SELECTION MASK STATEMENT
def selectionMask_cr(var_01,var_02):
    for i in range(0,len(var_01)):
        mel.eval('setObjectPickMask '+var_01[i]+' '+var_02)

#DELETE ANIMATION CURVES
def CUTool_deleteAnimationFromScene():
    var=(cmds.ls(type=("animCurveTU", "animCurveTA", "animCurveTL")))
    if len(var):
        cmds.delete(var)

#CHECK REFERENCE FOR EXISTS
def CUTool_checkReferenceExists(input):
    try:
        if cmds.referenceQuery(input,isLoaded=True) is True:
            return True
    except:
        return False

#OPEN REFERENCE EDITS EDITOR
def CUTool_getReferenceEdits():
	target_ref=(cmds.referenceQuery((cmds.ls(sl=True, readOnly=True)[0]),filename=True))
	mel.eval('referenceEditsWindow "'+str(target_ref)+'" false;')

#REMOVE SLIM EDITS
#REMOVE EDITS
def CUTool_removeSlimEdits(target_edit,target_type):
    target_ref=(cmds.referenceQuery((cmds.ls(sl=True, readOnly=True)[0]),referenceNode=True))
    target_obj=cmds.ls(sl=True, long=True)[0]
    target_edits=cmds.referenceQuery(target_ref, editStrings=True)
    edit_name=[]
    for i in range(0,len(target_edits)):
        if target_obj in target_edits[i]:
            if target_edit in target_edits[i]:
                edit_name.append((target_edits[i]).split(' '))
    for i in range(0,len(edit_name)):
        for edit_i in range(0,len(edit_name[i])):
            if '|' in edit_name[i][edit_i]:
                cmds.referenceEdit(edit_name[i][edit_i], successfulEdits=True, failedEdits=True, editCommand=target_type, removeEdits=True)

#REMOVE SLIM SURFACE SHADER
#CUTool_removeSlimEdits('rman__torattr___slimSurface','setAttr')

#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]
def densitySetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True), type='transform', allDescendents=True, fullPath=True) is None:
			target_obj=cmds.ls(sl=True, long=True)
		else:
			target_obj=cmds.listRelatives(cmds.ls(sl=True, long=True), type='transform', allDescendents=True, fullPath=True)
    if mode=='selected':
	    target_obj=cmds.ls(sl=True)
    for i in range(0,len(target_obj)):
        Attr_check=mel.eval('attributeExists rman__torattr___transformBeginScript '+target_obj[i]+';')
        Attr_rate=0
        if Attr_check==1:
            target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
            if re.findall('RiShadingRate [0-9.]+', target_Attr):
                target_Rate=re.findall('RiShadingRate [0-9.]+', target_Attr)[0]
            else: target_Rate=''
            if re.findall('[0-9.]+', target_Rate):
				Attr_rate=float(re.findall('[0-9.]+', target_Rate)[0])
            else: Attr_rate=5
            if var=='plus':
			    Attr_rate=Attr_rate+1
            if var=='minus':
                Attr_rate=Attr_rate/2
            if var=='fromSetup':
                Attr_rate=cmds.intFieldGrp("CUTool_Light_setup_RiShadingRate_field", query=True, value1=True)
            if var=='remove':
                if '"RenderRadiosity"' in target_Attr:
                    buffer_attr=target_Attr.split('; ');
                    list_attr=''
                    for attr_i in range(0,len(buffer_attr)):
                        if len(buffer_attr[attr_i])>1:
                            if '"RenderRadiosity"' in buffer_attr[attr_i]: pass
                            else: list_attr=list_attr+buffer_attr[attr_i]+'; '
                    cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),list_attr, type='string');
                    if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
                        if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
    							cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
                if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
                    if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
    							cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
            if var!='remove':
				if Attr_rate<0.1:
					Attr_rate=1
				if Attr_rate>10:
					Attr_rate=1
				if target_Rate=='':
					cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+' if(`rman getvar CLASS` == \"RenderRadiosity\") {RiShadingRate 5;}; '), type='string')
				elif (target_Rate!='' and Attr_rate!=0):
					cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'), (re.sub('RiShadingRate [0-9.]+', ('RiShadingRate '+str(Attr_rate)), target_Attr)), type='string')
				else:
					cmds.error('Please check '+target_obj[i]+'!!!\n')
        else:
            mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__torattr___transformBeginScript ("if(`rman getvar CLASS` == \\\"RenderRadiosity\\\") {RiShadingRate 5;}; ");')

#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]
def shadingRateSetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True, long=True), type='mesh', allDescendents=True, fullPath=True) is None:
			target_obj=cmds.ls(sl=True, leaf=True, dagObjects=True, shapes=True, long=True)
		else:
			target_obj=cmds.listRelatives(cmds.ls(sl=True, long=True), type='mesh', allDescendents=True, fullPath=True)
    if mode=='selected':
        target_obj=cmds.ls(sl=True, leaf=True, dagObjects=True, shapes=True, long=True)
    for i in range(0,len(target_obj)):
		Attr_check=mel.eval('attributeExists rman__riattr___ShadingRate '+target_obj[i]+';')
		Attr_rate=0
		if Attr_check==1:
			target_Rate=cmds.getAttr(target_obj[i]+'.rman__riattr___ShadingRate')
			Attr_rate=target_Rate
			if var=='plus':
			    Attr_rate=Attr_rate+((target_Rate<=1.5) and 0.5 or 1.0)
			if var=='minus':
			    Attr_rate=Attr_rate-((target_Rate>=1.5 and target_Rate<=10.0) and 1.0 or ((target_Rate<=1.5) and 0.2 or 0.5))
			if var=='fromSetup':
			    Attr_rate=cmds.intFieldGrp("CUTool_Light_setup_RiShadingRate_field", query=True, value1=True)
			if var=='remove':
			    cmds.deleteAttr((target_obj[i]+'.rman__riattr___ShadingRate'))
			if Attr_rate<0.1:
				Attr_rate=1
			if Attr_rate>10:
			    Attr_rate=1
			if target_Rate=='':
				cmds.setAttr((target_obj[i]+'.rman__riattr___ShadingRate'),Attr_rate)
			elif (target_Rate!='' and Attr_rate!=0):
				cmds.setAttr((target_obj[i]+'.rman__riattr___ShadingRate'),Attr_rate)
			else:
			    cmds.error('Please check '+target_obj[i]+'!!!\n')
		else:
		    if var!='remove':
			    mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__riattr___ShadingRate 1;')



#var= [plus, minus, remove, fromSetup]
#mode= [all, selected]
def illuminateSetup(var,mode):
    if mode=='all':
		if cmds.listRelatives(cmds.ls(sl=True, long=True), type='transform', allDescendents=True, fullPath=True) is None:
			target_obj=cmds.ls(sl=True, long=True)
		else:
			target_obj=cmds.listRelatives(cmds.ls(sl=True, long=True), type='transform', allDescendents=True, fullPath=True)+cmds.ls(sl=True, long=True)
    if mode=='selected':
	    target_obj=cmds.ls(sl=True, long=True)
    target_light=[]
    rms_target_light=[]
    light_array=cmds.listRelatives(cmds.ls(sl=True, long=True), allDescendents=True, path=True)
    for i in range(0, len(light_array)):
        if cmds.nodeType(cmds.ls(light_array[i],leaf=True, dagObjects=True, shapes=True)) in ['pointLight','volumeLight','areaLight','spotLight','directionalLight','ambientLight', 'RMSAreaLight']:#Maya lights
            target_light.append(light_array[i])
        if cmds.nodeType(cmds.ls(light_array[i],leaf=True, dagObjects=True, shapes=True)) in ['RMSLightBlocker','RMSEnvLight','RMSGILight','RMSCausticLight','RMSGIPtcLight','RMSGeoAreaLight','RMSGeoLightBlocker','RMSPointLight']:#Rman light
            rms_target_light.append(light_array[i])
    light_array=rms_target_light+target_light
    for i in range(0, len(light_array)):
        if light_array[i] in target_obj:
            target_obj.remove(light_array[i])
        if cmds.listRelatives(light_array[i], parent=True, fullPath=True):
            if cmds.listRelatives(light_array[i], parent=True, fullPath=True)[0] in target_obj:
				target_obj.remove(cmds.listRelatives(light_array[i], parent=True, fullPath=True)[0])
    for i in range(0,len(target_obj)):
		print 'set %s' % target_obj[i]
		if cmds.nodeType( target_obj[i] ):
			Attr_check = 0
			if cmds.nodeType( target_obj[i] ) != 'shaveHair':
				Attr_check=mel.eval('attributeExists rman__torattr___transformBeginScript '+target_obj[i]+';');
			else:
				Attr_check = 1
			if Attr_check==1:
				for light_i in range(0, len(target_light)):
					target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
					if var=='plus':
						if ('"'+target_light[light_i]+'"') in target_Attr:
							buffer_attr=target_Attr.split('; ')
							list_attr=''
							for attr_i in range(0,len(buffer_attr)):
								if len(buffer_attr[attr_i])>1:
									if ('"'+target_light[light_i]+'" 0') in buffer_attr[attr_i]:
										if (('RiIlluminate "'+target_light[light_i]+'" 1; ')) not in list_attr:
											list_attr=list_attr+(('RiIlluminate "'+target_light[light_i]+'" 1; '))
									elif ('"'+target_light[light_i]+'" 1') in buffer_attr[attr_i]:
										if (('RiIlluminate "'+target_light[light_i]+'" 1; ')) not in list_attr:
											list_attr=list_attr+(('RiIlluminate "'+target_light[light_i]+'" 1; '))
									else:
										list_attr=list_attr+buffer_attr[attr_i]+'; '
							cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')
						else:
							cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 1; '), type='string')
					if var=='minus':
						if ('"'+target_light[light_i]+'"') in target_Attr:
							buffer_attr=target_Attr.split('; ')
							list_attr=''
							for attr_i in range(0,len(buffer_attr)):
								if len(buffer_attr[attr_i])>1:
									if ('"'+target_light[light_i]+'" 1') in buffer_attr[attr_i]:
										if (('RiIlluminate "'+target_light[light_i]+'" 0; ')) not in list_attr:
											list_attr=list_attr+(('RiIlluminate "'+target_light[light_i]+'" 0; '))
									elif ('"'+target_light[light_i]+'" 0') in buffer_attr[attr_i]:
										if (('RiIlluminate "'+target_light[light_i]+'" 0; ')) not in list_attr:
											list_attr=list_attr+(('RiIlluminate "'+target_light[light_i]+'" 0; '))
									else:
										list_attr=list_attr+buffer_attr[attr_i]+'; '
							cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')
						else:
							cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 0; '), type='string')
					if var=='remove':
						target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
						if ('RiIlluminate "'+target_light[light_i]+'"') in target_Attr:
							buffer_attr=target_Attr.split('; ')
							list_attr=''
							for attr_i in range(0,len(buffer_attr)):
								if len(buffer_attr[attr_i])>1:
									if ('RiIlluminate "'+target_light[light_i]+'"') not in buffer_attr[attr_i]:
										list_attr=list_attr+buffer_attr[attr_i]+'; '

							cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')
							if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
								if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
									cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
						if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
							if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
									cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
				if var=='removeAll':
					target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
					if ('RiIlluminate ') in target_Attr:
						buffer_attr=target_Attr.split('; ')
						list_attr=''
						for attr_i in range(0,len(buffer_attr)):
							if len(buffer_attr[attr_i])>1:
								if ('RiIlluminate ') not in buffer_attr[attr_i]:
									list_attr=list_attr+buffer_attr[attr_i]+'; '
						cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')
						if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
							if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
									cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
					if cmds.attributeQuery('rman__torattr___transformBeginScript', node=target_obj[i], exists=True) is True:
						if len(cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript'))<=1:
									cmds.deleteAttr((target_obj[i]+'.rman__torattr___transformBeginScript'))
				for light_i in range(0, len(rms_target_light)):
					ml_quote = False
					if cmds.nodeType( target_obj[i] ) != 'shaveHair':
						ml_attributeRI = 'RiAttribute "user" "string lightcategory"'
						ml_attributeRITarget = 'rman__torattr___transformBeginScript'
						ml_quote = False
					else:
						ml_attributeRI = 'Attribute "user" "string lightcategory"'
						ml_attributeRITarget = 'ribStuff'
						ml_quote = True
					target_Attr=cmds.getAttr(target_obj[i]+'.'+ml_attributeRITarget)
					if var=='plus':
						if (ml_attributeRI in target_Attr):
							if ('-'+rms_target_light[light_i]) in target_Attr:
								buffer_attr=target_Attr.split('; ')
								list_attr=''
								for attr_i in range(0, len(buffer_attr)):
									if len(buffer_attr[attr_i])>1:
										if (ml_attributeRI not in buffer_attr[attr_i]):
											list_attr=list_attr+buffer_attr[attr_i]+'; '
										else:
											list_attr=list_attr+(''.join(buffer_attr[attr_i].split('&-'+rms_target_light[light_i])))+'; '
										if ml_attributeRI+' ' + ( ml_quote is True and '[""]' or '""' ) + ';' in list_attr:
											list_attr = ''.join(list_attr.split(ml_attributeRI + ' ' + ( ml_quote is True and '[""]' or '""' ) + ';'))
								cmds.setAttr((target_obj[i]+'.'+ml_attributeRITarget),(list_attr and list_attr or ''), type='string')
								if cmds.nodeType( target_obj[i] ) != 'shaveHair':
									if not re.findall( '[A-z,0-9\&\$]+', cmds.getAttr(target_obj[i]+'.'+ml_attributeRITarget)):
										cmds.deleteAttr( target_obj[i]+'.'+ml_attributeRITarget )
					if var=='minus':
						if (ml_attributeRI in target_Attr):
							if ('-'+rms_target_light[light_i]) not in target_Attr:
								buffer_attr=target_Attr.split('; ')
								list_attr=''
								for attr_i in range(0, len(buffer_attr)):
									if len(buffer_attr[attr_i])>1:
										if (ml_attributeRI not in buffer_attr[attr_i]):
											list_attr=list_attr+buffer_attr[attr_i]+'; '
										else:
											list_attr=list_attr+(buffer_attr[attr_i].rsplit(( ml_quote is True and '"]' or '"' ), 1))[0]+'&-'+rms_target_light[light_i] + ( ml_quote is True and '"]' or '"' ) +'; '
								cmds.setAttr((target_obj[i]+'.'+ml_attributeRITarget),(list_attr), type='string')
						else:
							cmds.setAttr((target_obj[i]+'.'+ml_attributeRITarget),(target_Attr+(target_Attr != '' and ' ' + ml_attributeRI or ml_attributeRI)+' '+( ml_quote is True and '["' or '"' )+'&-'+rms_target_light[light_i]+( ml_quote is True and '"]' or '"' )+'; '), type='string')
			else:
				if var=='plus':
					mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__torattr___transformBeginScript ("");')
					for light_i in range(0, len(target_light)):
						target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
						cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 1; '), type='string')
				if var=='minus':
					mel.eval('rmanAddAttr "'+target_obj[i]+'" rman__torattr___transformBeginScript ("");')
					for light_i in range(0, len(target_light)):
						target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
						cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(target_Attr+'RiIlluminate "'+target_light[light_i]+'" 0; '), type='string')

def renderPlayblast():
    scriptString="python(\"import sendToRender; reload(sendToRender); sendToRender.rmanSpoolRemoteRIBRemoteRender(\\\\\"\\\\\",\\\\\"\\\\\",1400,\\\\\"playblast\\\\\",\\\\\"\\\\\",\\\\\"rms-18.0-maya-2013 prman-18.0\\\\\",\\\\\"\\\\\",\\\\\"\\\\\",\\\\\"\\\\\",\\\\\"\\\\\",\\\\\"\\\\\",5,False,False,0.0,0.0,0.0,0.0,0,False,True,True,False,True,False,False,True,2,True,2,False,False,1.0,1.0,1.0,False,False,True,True,False,True,True,True,True,True,True,80.0,\\\\\"subframe\\\\\",\\\\\"frameOpen\\\\\",0.35,0.65,False,False,5.0,5.6,1.0,True,1.0,True,9,9,False,4.0,4.0,\\\\\"gaussian\\\\\",False,\\\\\"binary\\\\\",\\\\\"gzip\\\\\",False,False,False)\")"
    import sendToRender;reload(sendToRender);sendToRender.runFunctionFromSelectFiles(["-batch","-proj","","-command","\"%D(script)\"","-file",""],scriptString,"maya2013",1500,"",[cmds.file(query=True, sn=True)],False)								
						
#lightLinkSetup(make or break)
def lightLinkSetup(mode):
    if cmds.listRelatives((cmds.ls(sl=True)), allDescendents=True, type='transform') is not None:
        target_objects=cmds.listRelatives((cmds.ls(sl=True)), allDescendents=True, type='transform')+(cmds.ls(sl=True))
    else: target_objects=cmds.ls(sl=True)
    target_light=[]
    light_array=cmds.ls(sl=True)
    for i in range(0, len(light_array)):
        if re.findall('light', light_array[i], flags=re.IGNORECASE):
            target_light.append(light_array[i])
    for i in range(0, len(target_light)):
        for obj_i in range(0, len(target_objects)):
            if mode=='make':
                cmds.lightlink(light=target_light[i], object=target_objects[obj_i], make=True)
            if mode=='break':
                cmds.lightlink(light=target_light[i], object=target_objects[obj_i], b=True)

#REMOVE SLIM SURFACE SHADER
#CUTool_removeSlimEdits('attribute Name','attribute Type')
def CUTool_removeSlimEdits(target_edit,target_type):
    target_ref=(cmds.referenceQuery((cmds.ls(sl=True, readOnly=True)[0]),referenceNode=True))
    target_obj=cmds.ls(sl=True, long=True)[0]
    target_edits=cmds.referenceQuery(target_ref, editStrings=True)
    edit_name=[]
    for i in range(0,len(target_edits)):
        if target_obj in target_edits[i]:
            if target_edit in target_edits[i]:
                edit_name.append((target_edits[i]).split(' '))
    for i in range(0,len(edit_name)):
        for edit_i in range(0,len(edit_name[i])):
            if '|' in edit_name[i][edit_i]:
                cmds.referenceEdit(edit_name[i][edit_i], successfulEdits=True, failedEdits=True, editCommand=target_type, removeEdits=True)
#EXAMPLE: CUTool_removeSlimEdits('rman__torattr___slimSurface','setAttr') <- remove slim surface shader edits

def CUTool_GetGeometryGrp():
	tr_array=cmds.ls(dag=True, tr=True, long=True)
	result=[]
	if tr_array:
		sort_tr_array=[tr_array[x] for x in range(0, len(tr_array)) if re.search('geometry_grp$', tr_array[x]) and re.search('root', tr_array[x])]
		sort_tr_array=[sort_tr_array[x] for x in range(0, len(sort_tr_array)) if 'cache' not in sort_tr_array[x]]
		for i in range(0, len(sort_tr_array)):
			if cmds.referenceQuery(sort_tr_array[i], inr=True):
				result.append(sort_tr_array[i]+ ' <X> ('+cmds.referenceQuery(sort_tr_array[i], filename=True, shortName=True)+')')
			else:
				result.append(sort_tr_array[i]+ ' <X> (N/A)')
		return result

def CUTool_ABCRefreshList():
	cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, removeAll=True)
	var=CUTool_GetGeometryGrp()
	if var:
		for i in range(0,len(var)):
			cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, append=var[i])
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)==1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='All from selection list')
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)>1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='Selected from selection list')
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)==0:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='Select from outliner or viewport')

def	CUTool_ABCAddSelectedToList():
	selected_obj=cmds.ls(sl=True, long=True)
	for i in range(0, len(selected_obj)):
		if cmds.referenceQuery(selected_obj[i], inr=True):
			current_obj=(selected_obj[i]+ ' <X> ('+cmds.referenceQuery(selected_obj[i], filename=True, shortName=True)+')')
		else:
			current_obj=(selected_obj[i]+ ' <X> (N/A)')
		if current_obj:
			if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, allItems=True):
				if current_obj not in cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, allItems=True):
					cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, append=current_obj)
			else:
				cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, append=current_obj)
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)>1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='Selected from selection list')
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)==1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='All from selection list')

def CUTool_ABCRemoveSelectedFromList(var):
	if var=='all':
		cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, removeAll=True)
	if var=='selected':
		if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, selectItem=True):
			cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', edit=True, removeItem=(cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, selectItem=True)))
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)==0:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='Select from outliner or viewport')
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)==1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='All from selection list')
	if cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, numberOfItems=True)>1:
		cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', edit=True, value='Selected from selection list')


def CUTool_ABCSelectItemFromList():
	var=cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, selectItem=True)
	cmds.select(cl=True)
	for i in range(0,len(var)):
		if (var[i].split(" <X> ")):
			if cmds.objExists((var[i].split(" <X> ")[0])):
				cmds.select((var[i].split(" <X> ")[0]), add=True)

#BLENDSHAPES
#Create blendshapes
def createBlendShapesNode():
	var=cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)
	if 'Select from outliner or viewport' in var:
		lsSelectedObject=cmds.ls(sl=True)
	elif 'Selected from selection list' in var:
		lsSelectedObject=CUTool_ABCGetItemFromList(1)
	elif 'All from selection list' in var:
		lsSelectedObject=CUTool_ABCGetItemFromList(2)
	duplicateObj=cmds.duplicate(lsSelectedObject[0],rr=True,name=lsSelectedObject[0].split("|")[-1]+"_xxx")
	duplicateObj = cmds.ls(duplicateObj,l=True)
	DuplicateShape = cmds.ls(duplicateObj,l=True,dag=True,ni=True,lf=True,type="mesh")
	OriginalShape = cmds.ls(lsSelectedObject[0],l=True,dag=True,ni=True,lf=True,type="mesh")
	for ds in range(0,len(DuplicateShape)):
	        #print DuplicateShape[ds]
	        vis1=-1
	        if cmds.getAttr(DuplicateShape[ds]+".visibility") != True:
	            vis1=0
	            cmds.setAttr(DuplicateShape[ds]+".visibility",True)
	            cmds.setAttr(OriginalShape[ds]+".visibility",True)
	        cmds.blendShape(DuplicateShape[ds],OriginalShape[ds], frontOfChain=True,o="world",w=[0,1])
	        if vis1==0:
	            cmds.setAttr(DuplicateShape[ds]+".visibility",False)
	            cmds.setAttr(OriginalShape[ds]+".visibility",False)
	cmds.delete(duplicateObj)

def FindAlembicSceneFolder():
	sceneNameFilePath=cmds.file(query=True, location=True).split("/")
	if len(sceneNameFilePath)>1:
		sceneNameFileName = (cmds.file(query=True, location=True).split("/")[-1]).split(".")[-2]
	else:
		sceneNameFileName="untitled"
	indexSceneFolder=-2
	if sceneNameFileName!="untitled":
		for sNFP in range (0, len(sceneNameFilePath)):
			m = re.search('^ep\d{2}sc\d{2}', sceneNameFilePath[sNFP],re.IGNORECASE)
			if m is not None:
				indexSceneFolder=sNFP
				break
		pathFolderForCache = "/".join(sceneNameFilePath[0:indexSceneFolder+1])+"/cache/alembic/"
	if sceneNameFileName=="untitled":
		pathFolderForCache=OSTYPE+"/default/scenes/cache/alembic"
	elif sceneNameFileName!="untitled":
		if not os.path.isdir(pathFolderForCache) and pathFolderForCache!="/cache/alembic/":
			try:
				os.makedirs(pathFolderForCache)
			except:
				pathFolderForCache=OSTYPE+"/default/scenes/cache/alembic"
	return pathFolderForCache

def CUTool_ABCupdateRanges():
	cmds.intFieldGrp('CUTool_ABCstartFrame', edit=True, value1=cmds.playbackOptions(query=True, animationStartTime=True))
	cmds.intFieldGrp('CUTool_ABCendFrame', edit=True, value1=cmds.playbackOptions(query=True, animationEndTime=True))

def CUTool_changeToRenderVersion(var_word):
    if cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Select from outliner or viewport':
		lsSelectedObject=cmds.ls(sl=True, long=True)
    elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Selected from selection list':
		lsSelectedObject=CUTool_ABCGetItemFromList(1)
    elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='All from selection list':
		lsSelectedObject=CUTool_ABCGetItemFromList(2)
    ChangeReferenceToRenderVersion(lsSelectedObject,var_word)

def exportAlembic(mode):
    if mode=='default':
        if cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Select from outliner or viewport':
			objects,startFrame,endFrame=getObjectsForExport(1)
        elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Selected from selection list':
			objects,startFrame,endFrame=getObjectsForExport(2)
        elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='All from selection list':
			objects,startFrame,endFrame=getObjectsForExport(3)
    if mode!='default':
        objects,startFrame,endFrame=getObjectsForExport(mode)
    exec_ExportAlembic(objects,[startFrame,endFrame])

def getObjectsForExport(Mode):
	modes = ['Select from outliner or viewport', 'Selected from selection list', 'All from selection list']
	commandsForGetObjects = ['cmds.ls(sl=True, long=True)', 'CUTool_ABCGetItemFromList(1)', 'CUTool_ABCGetItemFromList(2)']
	commandGetObjects = commandsForGetObjects[modes.index(cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True))]
	if Mode == '_dyn':
		lsSelectedObject = CUTool_getSetsForChar('dynCache', eval(commandGetObjects), 'nodes')
	elif Mode == '_render':
		lsSelectedObject = CUTool_getSetsForChar('renderCache', eval(commandGetObjects), 'nodes')
	else:
		lsSelectedObject = eval(commandGetObjects)
	sets_contain = [lsSelectedObject[i] for i in range(0, len(lsSelectedObject)) if cmds.nodeType(lsSelectedObject[i])=='objectSet']
	if sets_contain:
		sets_contain = [cmds.ls(cmds.sets(sets_contain[i], query=True, nodesOnly=True), long=True) for i in range(0, len(sets_contain))]
		sets_contain = re.split('[\[,\],\,,\']', str(sets_contain))
		sets_contain = [sets_contain[i] for i in range(0,len(sets_contain)) if sets_contain[i]!='' and ' ' not in sets_contain[i] and len(sets_contain[i])>1]
		lsSelectedObject = [lsSelectedObject[i] for i in range(0, len(lsSelectedObject)) if cmds.nodeType(lsSelectedObject[i])!='objectSet']+sets_contain
	if lsSelectedObject is None:
		cmds.error("PLEASE SELECT TARGET!!!")
	startFrame = []
	endFrame = []
	if len(lsSelectedObject) > 0:
		for lSO in range(0, len(lsSelectedObject)):
			startFrame.append(cmds.intFieldGrp('CUTool_ABCstartFrame', query=True, value1=True))
			endFrame.append(cmds.intFieldGrp('CUTool_ABCendFrame', query=True, value1=True))
	else:
		cmds.error("PLEASE SELECT TARGET FOR EXPORT!!!")
	return lsSelectedObject, startFrame, endFrame

#Export ABC source
def exec_ExportAlembic(obgects, frameRanges):
	if '/' not in (cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)):
		pathFolderForCache=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)).replace('\\', '/')
	else:
		pathFolderForCache=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True))
	if not os.path.isdir(pathFolderForCache):
		cmds.error("!!!INVALID PATH!!!")
	m_dop = cmds.textFieldGrp( "exportCacheDopName", query=True, text=True )
	nameForAlembic = 'AbcExport'
	for lsS in range (0, len(obgects)):
		nameForAlembicTemp = obgects[lsS].replace(':','_x_')
		nameForAlembicTemp = nameForAlembicTemp.replace('|','_z_')
		if len( nameForAlembicTemp ) > 100:
			nameForAlembicTemp = nameForAlembicTemp[ -100: ]
		nameForAlembic += ' -j "-root ' + obgects[lsS] + ' -fr ' + str(frameRanges[0][lsS]) + ' ' + str(frameRanges[1][lsS]) + ' -noNormals -worldSpace -stripNamespaces'
		if cmds.checkBoxGrp("CUTool_ABCcheck_visible_control", query=True, value1=True) is True:
			nameForAlembic += ' -writeVisibility'
		if cmds.checkBoxGrp("CUTool_ABCcheck_renderable_control", query=True, value1=True) is True:
			nameForAlembic += ' -renderableOnly'
		if m_dop:
			nameForAlembic += ' -file ' + pathFolderForCache + '/' + nameForAlembicTemp + "_XXX_" + m_dop + '.abc"'
		else:
			nameForAlembic += ' -file ' + pathFolderForCache + '/' + nameForAlembicTemp + '.abc"'
	print('\nEXPORT TO ALEMBIC: \n' + nameForAlembic + '\n')
	mel.eval( nameForAlembic )

def ChangeReferenceToRenderVersion(reference_input, var_word):
    #Get reference info
    referenceFiles = []
    [referenceFiles.append(cmds.referenceQuery(reference_input[i], filename=True)) for i in range(0, len(reference_input)) if cmds.referenceQuery(reference_input[i], isNodeReferenced=True)]
    def getNewReferenceName(referenceName):
        shortName = (referenceName.split('/')[-1]).split('.')[0]
        typeReference = var_word.split('_')[-1]
        directory = '/'.join(referenceName.split('/')[0:-1])
        files = os.listdir(directory)
        files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i], re.IGNORECASE)]
        files = [files[i] for i in range(0, len(files)) if re.findall(str(typeReference), files[i], re.IGNORECASE)]
        if '_' in shortName:
            result = [files[i] for i in range(0, len(files)) if re.findall(shortName+'_?'+typeReference+'[.ma|.mb]', files[i], re.IGNORECASE)]
        else:
            result = [files[i] for i in range(0, len(files)) if re.findall(shortName+'_?'+typeReference+'[.ma|.mb]', files[i], re.IGNORECASE)]
        if result:
            result = result[0]
            result = directory+'/'+result
            return result
        else:
            return None
    def replaceReference(referenceName):
        result = getNewReferenceName(referenceName)
        if result:
            cmds.file(referenceName, force=True, unloadReference=True)
            cmds.file(result, reference=True, groupLocator=True, mergeNamespacesOnClash=False, namespace=(result.split('/')[-1]).split('.')[0])
        else:
            cmds.error('File not found!!!')
    #replace reference
    if referenceFiles:
        for i in range(0, len(referenceFiles)):
            if cmds.checkBoxGrp("ABC_check_Imp_Exp_control", query=True, value1=True) is False:
                replaceReference(referenceFiles[i])
            else:
                alembic = CUToolSetup.exportAlembic(var_word)
                #scriptImportABC = ('CUToolSetup.importAlembic("'+str(var_word)+'", '+str(referenceNodes)+')')
                #cmds.scriptJob(runOnce=True, conditionTrue=["readingReferenceFile", scriptImportABC])
                #nodes = replaceReference(referenceFiles[i])

def CUTool_ABCGetItemFromList(var01):
	if var01==1:
		var00=cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, selectItem=True)
	if var01==2:
		var00=cmds.textScrollList('CUTool_ABC_ExIm_Characters_list', query=True, allItems=True)
	var02=[]
	if var00:
	    for i in range(0,len(var00)):
		    if (var00[i].split(" <X> ")):
			    if cmds.objExists((var00[i].split(" <X> ")[0])):
				    var02.append((var00[i].split(" <X> ")[0]))
	return var02


#IMPORT
#Get objects and open dialog for import ABC
def pathResolve(Mode, reference_input):
	if Mode=='_dyn':
		pathsSelection=CUTool_getSetsForChar('dynCache', reference_input, 'nodes')
	elif Mode=='_render':
		pathsSelection=CUTool_getSetsForChar('renderCache', reference_input, 'nodes')
	elif Mode==1:
		pathsSelection=cmds.ls(sl=True, long=True)
	elif Mode==2:
		pathsSelection=CUTool_ABCGetItemFromList(1)
	elif Mode==3:
		pathsSelection=CUTool_ABCGetItemFromList(2)
	else:
		pathsSelection=cmds.ls(sl=True,l=True)
	sets_contain=[pathsSelection[i] for i in range(0, len(pathsSelection)) if cmds.nodeType(pathsSelection[i])=='objectSet']
	if sets_contain:
		sets_contain=[cmds.ls(cmds.sets(sets_contain[i], query=True, nodesOnly=True), long=True) for i in range(0, len(sets_contain))]
		sets_contain=re.split('[\[,\],\,,\']', str(sets_contain))
		sets_contain=[sets_contain[i] for i in range(0,len(sets_contain)) if sets_contain[i]!='' and ' ' not in sets_contain[i] and len(sets_contain[i])>1]
		pathsSelection=[pathsSelection[i] for i in range(0, len(pathsSelection)) if cmds.nodeType(pathsSelection[i])!='objectSet']+sets_contain
	if pathsSelection is None:
		cmds.error("PLEASE SELECT TARGET!!!")
	if '/' not in (cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)):
		pathFolderForCache=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)).replace("\\", "/")
	else:
		pathFolderForCache=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True))
	if not os.path.isdir(pathFolderForCache):
		cmds.error("!!!INVALID PATH!!!")
	path=[]
	nodes=[]
	if len(pathsSelection)==1:
		for lSO in range(0,len(pathsSelection)):
			nodes.append(pathsSelection[lSO])
			singleFilter = "Abc files (*.abc)"
			if os.path.exists((cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True))):
				path.append(cmds.fileDialog2(caption=pathsSelection[lSO], fileFilter=singleFilter, dialogStyle=1, dir=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)), fm=1)[0])
			else:
				path.append(cmds.fileDialog2(caption=pathsSelection[lSO], fileFilter=singleFilter, dialogStyle=1, dir=pathFolderForCache, fm=1)[0])
	elif len(pathsSelection)>1:
		nodes=pathsSelection
		singleFilter = "Abc files (*.abc)"
		if os.path.exists((cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True))):
			filePathTemp=(cmds.fileDialog2(caption='Please select cache', fileFilter=singleFilter, dialogStyle=1, dir=(cmds.textField("CUTool_changeABCExportDirectory_textField", query=True, text=True)), fm=4))
			for i in range(0,len(filePathTemp)):
				path.append('/'.join(filePathTemp[i].split('\\')))
		else:
			filePathTemp=(cmds.fileDialog2(caption='Please select cache', fileFilter=singleFilter, dialogStyle=1, dir=pathFolderForCache, fm=4))
			for i in range(0,len(filePathTemp)):
				path.append('/'.join(filePathTemp[i].split('\\')))
	else:
		cmds.error("PLEASE SELECT TARGET FOR IMPORT!!!")
	print nodes
	return nodes,path
#
def exec_ImportAlembic(path):
	if cmds.ls("|cache") == []:
		cmds.group(em=True, name="cache")
	ChasheRoot = []
	grp_name_array = []
	for p in path:
		p = pathToNetwork(p)
		onlyName = p.split("/")[-1]
		groupName = onlyName.split(".")[0].replace("_z_","__").replace("_x_","_x_")
		if "_XXX_" in groupName:
			m_temp = "_XXX_" + groupName.split( "_XXX_" )[-1]
			groupName = groupName.split( m_temp )[0]
		if groupName[-1] == ':':
			groupName = groupName[0:-1]
		if len(cmds.ls("|cache|" + groupName))>0:
			cmds.rename("|cache|" + groupName, "|cache|" + groupName + 'OldCache')
			groupName=cmds.group(em=True, parent="|cache", name=groupName)
			print '\tgroup name: ', groupName
		elif cmds.ls("|cache|" + groupName) == []:
			groupName = cmds.group(em=True, parent="|cache", name=groupName)
			print '\tgroup name: ', groupName
		fitTimeOption = cmds.checkBoxGrp('ABC_check_Imp_fitTimeRange_control', query=True, v1=True) and ' -fitTimeRange' or ''
		alembicNode = mel.eval("AbcImport" + fitTimeOption + " -rpr " + "|cache|" + groupName + " \"" + p + "\"")
		if len(cmds.ls(groupName, dag=True, l=True)) <= 1:
			cmds.warning('Cache objects is not exists, please check objects in cache')
		elif len(cmds.ls(groupName, dag=True, l=True)) > 1:
			groupNameTemp = cmds.rename(cmds.ls(groupName, dag=True, l=True)[1], re.split('_xxx',(cmds.ls(groupName, dag=True, l=True)[1].split("|")[-1]))[0])
		ChasheRoot.append(cmds.ls(groupNameTemp, dag=True, l=True)[0])
		print "\nTarget: ", groupName, '\nPath: ', ChasheRoot[-1]
		grp_name_array.append(groupName)
	return ChasheRoot, grp_name_array
#
def importAlembic(var_word, reference_input):
	schetchik = 0
	checkedNodes = []
	checkedAlembicPaths = []
	print '________________________________________________________________________________________'
	print '________________________________________________________________________________________'
	print '________________________________________________________________________________________'
	if var_word != 'default':
		nodes,path = pathResolve(var_word, reference_input)
	if var_word == 'default':
		if cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Select from outliner or viewport':
			nodes, path = pathResolve(1, 'T')
		elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='Selected from selection list':
			nodes, path = pathResolve(2, 'T')
		elif cmds.optionMenuGrp('CUTool_ABC_ExlmModeExportOptions', query=True, value=True)=='All from selection list':
			nodes, path = pathResolve(3, 'T')
	Alembic, grp_name_array = exec_ImportAlembic(path)
	originalTransforms = cmds.ls(nodes, dag=True, long=True, type='transform')
	alembicTransforms = cmds.ls(grp_name_array, dag=True, long=True, type='transform')
	if alembicTransforms:
		for i in range(0, len(originalTransforms)):
			for j in range(0, len(alembicTransforms)):
				originalTransformsClean = originalTransforms[i].split('|')
				originalTransformsClean = [originalTransformsClean[s].split(':')[-1] for s in range(0, len(originalTransformsClean))]
				originalTransformsClean = '_x_'.join(originalTransformsClean)
				alembicTransformsClean = alembicTransforms[j].split('|')[3:]
				alembicTransformsClean = [alembicTransformsClean[s].split(':')[-1] for s in range(0, len(alembicTransformsClean))]
				alembicTransformsClean = alembicTransformsClean and '_x_'.join(alembicTransformsClean) or 'UNKNOWN'
				if re.findall('('+alembicTransformsClean+')$', originalTransformsClean) or re.findall('('+originalTransformsClean+')$', alembicTransformsClean):
					try:
						cmds.connectAttr(alembicTransforms[j]+'.t', originalTransforms[i]+'.t', force=True)
						cmds.connectAttr(alembicTransforms[j]+'.r', originalTransforms[i]+'.r', force=True)
						cmds.connectAttr(alembicTransforms[j]+'.s', originalTransforms[i]+'.s', force=True)
					except:
						print 'Attributes is locked: ', originalTransforms[i]
					if cmds.checkBoxGrp("CUTool_ABCcheck_visible_control", query=True, value1=True) is True:
						try:
							cmds.connectAttr(alembicTransforms[j]+'.visibility', originalTransforms[i]+'.visibility', force=True)
						except:
							print 'Failed to connect visibility %s to %s' % ( alembicTransforms[j], originalTransforms[i] )
	for n in range(0,len(nodes)):
		check = False
		nodeShapes = cmds.ls(nodes[n], l=True, dag=True, ni=True, type="mesh")
		nodeShapes = [nodeShapes[indexCheck] for indexCheck in range(0, len(nodeShapes)) if nodeShapes[indexCheck] not in checkedNodes]
		lenNodes=len(nodes[n]); print '\nNodes: ', nodeShapes
		for alembic_index in range(0, len(Alembic)):
			if Alembic[alembic_index] in checkedAlembicPaths:
				continue
			AlembicShapes = cmds.ls(Alembic[alembic_index], l=True, dag=True, ni=True, type="mesh")
			lenAlembic = len(Alembic[alembic_index]); print "Alembic:", Alembic[alembic_index]; print 'Alembic nodes: ',AlembicShapes
			for ns in range(0,len(nodeShapes)):
				nodeShapesDeleteNameSpace = []
				for part in nodeShapes[ns][lenNodes:].split("|"):
					nodeShapesDeleteNameSpace.append(part.split(":")[-1])
				nodeShapesDeleteNameSpace = "|".join(nodeShapesDeleteNameSpace)
				for ass in range(0,len(AlembicShapes)):
					nodeShapesDeleteNameSpaceTMP = nodeShapesDeleteNameSpace
					if 'Deformed' in nodeShapesDeleteNameSpaceTMP:
						nodeShapesDeleteNameSpaceTMP = nodeShapesDeleteNameSpaceTMP[:-(len(nodeShapesDeleteNameSpaceTMP.split('Deformed')[-1])+8)]
					AlembicShapesTMP = AlembicShapes[ass]
					if 'Deformed' in AlembicShapesTMP:
						AlembicShapesTMP = AlembicShapesTMP[:-(len(AlembicShapesTMP.split('Deformed')[-1])+8)]
					if ':' in nodeShapesDeleteNameSpaceTMP:
						nodeShapesDeleteNameSpaceTMP = nodeShapesDeleteNameSpaceTMP.split(':',-1)[-1]
					if ':' in AlembicShapesTMP[lenAlembic:]:
						alembicShapesTMPnoNS = '|' + AlembicShapesTMP[lenAlembic:].split(':',-1)[-1]
					else:
						alembicShapesTMPnoNS = AlembicShapesTMP[lenAlembic:]
					if re.findall( '\|'.join(nodeShapesDeleteNameSpaceTMP.split('|')) + '$', alembicShapesTMPnoNS ) or re.findall( '\|'.join(alembicShapesTMPnoNS.split('|')) + '$', nodeShapesDeleteNameSpaceTMP ):
						print '\n\t\t\tChecked %s ans %s' % (nodeShapesDeleteNameSpaceTMP, alembicShapesTMPnoNS)
						checkedAlembicPaths.append(Alembic[alembic_index])
						check = True
						checkedNodes.append(nodeShapes[ns])
						print '\t\t\tConnect: ',nodeShapes[ns]+' and ' , AlembicShapes[ass]
						schetchik=schetchik+1
						print "\t\t\t\t\tProgress: "+str(n+1)+"("+str(len(nodes))+") shapes "+str(len(nodeShapes))+"("+str(schetchik)+")"
						listNodesToVisibility = nodeShapes[ns].split("|")
						for x in range(1,len(listNodesToVisibility)):
							next = ("|").join(listNodesToVisibility[0:x])
							try:
								cmds.setAttr(next+".visibility",True)
							except:
								'\t\t\t\t\tFailed turn on visibility', next
						try:
							cmds.setAttr(nodeShapes[ns]+".visibility",True)
						except:
							print '\t\t\t\t\tFailed turn on visibility', nodeShapes[ns]
						blNode = CUTool_ListDepencyConnections(nodeShapes[ns], 'inMesh', "blendShape")
						if blNode:
							attribute_oldConnect = cmds.listConnections(blNode[0]+".inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget")
							if attribute_oldConnect:
								cmds.disconnectAttr((attribute_oldConnect[0]+".worldMesh[0]"),(blNode[0]+".inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget"))
								cmds.delete(attribute_oldConnect[0])
							try:
								cmds.connectAttr((AlembicShapes[ass]+".worldMesh[0]"),(blNode[0]+".inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget"), force=True)
							except:
								print '\t\t\t\t\tFailed to connect ', AlembicShapes[ass], 'and', blNode[0]
						else:
							try:
								cmds.blendShape(AlembicShapes[ass], nodeShapes[ns], frontOfChain=True, o="world", w=[0,1])
							except:
								print '\t\t\t\t\tFailed create blendshape ', AlembicShapes[ass], 'and', nodeShapes[ns]
								try:
									cmds.select(cl=True)
									cmds.select(AlembicShapes[ass])
									print "select", AlembicShapes[ass]
									cmds.select(nodeShapes[ns], add=True)
									print "select", nodeShapes[ns]
									cmds.blendShape(frontOfChain=True, o="world", w=[0,1])
									cmds.select(cl=True)
									try:
										cmds.select(cl=True)
										cmds.select(AlembicShapes[ass])
										print "select", AlembicShapes[ass]
										cmds.select(nodeShapes[ns], add=True)
										print "select", nodeShapes[ns]
										mel.eval( "blendShape -frontOfChain -origin world -w 0 1" )
										cmds.select(cl=True)
									except:
										print "Failed"
								except:
									print "\t\t\t\t\tBlendshapes is not created"
						break
			m_parent = cmds.listRelatives( Alembic[alembic_index], parent=True, fullPath=True )
			if m_parent:
				cmds.setAttr(m_parent[0]+".visibility", 0)
			if check is True:
				break
	abcCacheRename(grp_name_array)

def abcCacheRename(input):
	childrens=[]
	childrens=cmds.listRelatives(input, children=True, fullPath=True)
	if len(childrens)>0:
		for index_child in range(0,(len(childrens))):
			shapeTEMP = cmds.ls(childrens[index_child], dag=True, leaf=True, type='shape')
			if shapeTEMP and cmds.nodeType(shapeTEMP[0])=='mesh':
				if 'cache_' not in childrens[index_child]:
					oldName=childrens[index_child]
					newName=(oldName.split("|")[-1]).split(':')
					cmds.rename(oldName,':'.join(newName[0:-1])+':'+'cache_'+newName[-1])
			else:
				childrens_descent=[]
				childrens_descent=cmds.listRelatives(childrens[index_child], allDescendents=True, fullPath=True)
				if len(childrens_descent)>0:
					for index_descent in range(0,(len(childrens_descent))):
						if 'cache_' not in childrens_descent[index_descent]:
							oldName=childrens_descent[index_descent]
							newName=(oldName.split("|")[-1]).split(':')
							cmds.rename(oldName,':'.join(newName[0:-1])+':'+'cache_'+newName[-1])

def CUTool_getSetsForChar(type_set, target, mode):
	result_fin=[]; print '\nType: ',type_set, '\nTarget: ', target
	result_final=[]
	for target_index in range(0,len(target)):
		target_nodes=(cmds.referenceQuery(target[target_index],nodes=True, dagPath=True))
		set_array=[target_nodes[i] for i in range(0, len(target_nodes)) if cmds.nodeType(target_nodes[i])=='objectSet']
		if mode=='sets':
			result=[set_array[i] for i in range(0, len(set_array)) if type_set in set_array[i]]
		if mode=='nodes':
			result=[cmds.sets(set_array[i], query=True, nodesOnly=True) for i in range(0, len(set_array)) if type_set in set_array[i]]
			result=re.split('[\[,\],\,,\']', str(result))
			result=[result[i] for i in range(0,len(result)) if result[i]!='' and ' ' not in result[i] and len(result[i])>1]
			result_fin=result_fin+result
	[result_final.append(result_fin[i]) for i in range(0,len(result_fin)) if result_fin[i] not in result_final]
	result_final=cmds.ls(result_final, long=True)
	print 'Set contain: ',result_final
	return result_final

def exportSoundFromAvi():
	
	src = cmds.textField("CUTool_getVideoFile_textField", query=True, text=True)
	dst = cmds.fileDialog2(caption='Accept', fileFilter="Wave files (*.wav)", dialogStyle=1, dir='/'.join( src.split( '/' )[0:-1] ), fm=0)[0]
	mg_exportSound( input=src, output=dst, bitrate=1536, codec='pcm_s16le', format='wav', executable='' )
	
def mg_exportSound( input='', output='', bitrate=1536, codec='pcm_s16le', format='wav', executable='' ):
    '''
    Export sound from video file.
    -input = Path to video file.
    -output = Path to exported sound.
    -bitrate = Quality of exported sound.
    -codec = Codec name.
	-executable = Path to ffmpeg.exe.
	
	requirements:
	ffmpeg for windows.
	http://ffmpeg.zeranoe.com/builds/
    '''
    import subprocess
    import os
    mg_output = ''
    mg_ffmpeg = executable == '' and '//SERVER-3D/Project/lib/soft/ffmpeg/bin/ffmpeg.exe' or executable
    not os.path.isfile( mg_ffmpeg ) and cmds.error( 'Failed to find ffmpeg.' )
    mg_video = input != '' and input or cmds.error( 'Please specify path to video file.' )
    mg_sound = output != '' and output or cmds.error( 'Please specify path to sound file.' )
    #mg_dir = '/'.join( mg_sound.split('/')[0:-1] )
    #not os.path.isdir( mg_dir ) and os.makedirs( mg_dir )
    os.path.isfile( mg_sound ) and os.remove( mg_sound )
    mg_command = [ mg_ffmpeg, '-i', mg_video, '-ab', ( str( bitrate ) + 'k' ), '-acodec', str( codec ), '-f', str( format ), mg_sound ]
    mg_process = subprocess.Popen( mg_command, stdout=subprocess.PIPE, stdin=None, stderr=subprocess.PIPE )
    mg_output = '\n'.join( mg_process.communicate() )
    return mg_output
	
def CUTool_abcExportGroup(obgects, type, mode, attribute_save):
    selected_ind=(cmds.ls(obgects, dag=True, shapes=True, long=True, readOnly=True))
    selected=[]
    if type=='renderCache':
        nodes_target=CUTool_getSetsForChar('renderCache', selected_ind,'nodes')
    elif type=='dynCache':
        nodes_target=CUTool_getSetsForChar('dynCache', selected_ind,'nodes')
    for i in range(0, len(selected_ind)):
        if selected_ind[i] not in selected:
            if cmds.listConnections(selected_ind[i]) and len(cmds.listConnections(selected_ind[i]))>1:
                selected.append(selected_ind[i])
    node_with_shape=[]
    if mode=='saveAttr':
        for i in range(0, len(selected)):
            node_with_shape.append('|'.join(selected[i].split('|')[0:-1]))
        for i in range(0, len(node_with_shape)):
            attribute_state=cmds.getAttr(node_with_shape[i]+'.visibility') is True and 1 or 0
            if attribute_state is not None:
                try:
                    attribute_save.append('cmds.setAttr("'+str(node_with_shape[i])+'.visibility",'+str(attribute_state)+')')
                except:
                    cmds.warning('attribute '+str(node_with_shape[i])+'.visibility" is not valid')
                try:
                    cmds.setAttr(node_with_shape[i]+'.visibility', 0)
                except:
                    cmds.warning(str(attribute_save[i])+' Not enough data was provided')
        for i in range(0,len(nodes_target)):
            cmds.setAttr(nodes_target[i]+'.visibility', 1)
            childrens=cmds.listRelatives(nodes_target[i],type='transform', allDescendents=True, fullPath=True)
            if childrens:
                for n in range(0, len(childrens)):
                    cmds.setAttr(childrens[n]+'.visibility', 1)
        #CUTool_getSetsForChar(type_set, target, mode)
        return attribute_save
    if mode=='loadAttr':
        for i in range(0, len(attribute_save)):
                try:
                    exec attribute_save[i]; print attribute_save[i]
                except:
                    cmds.warning(str(attribute_save[i])+' Not enough data was provided')

def referenceLoadStatementSet(load=False):
    '''
    '''
    #save reference set
    def listAllReferences():
        referencedPaths = []
        result = []
        def depth(value):
            array = cmds.file(value, query=True, reference=True)
            if value not in referencedPaths:
                referencedPaths.append(value)
            if array:
                for i in range(0, len(array)):
                    depth(array[i])
            else:
                pass        
        references = cmds.file(query=True, reference=True)
        for i in range(0, len(references)):
            depth(references[i])
        for i in range(0, len(referencedPaths)):
            referenceNode = cmds.referenceQuery(referencedPaths[i], referenceNode=True)
            if referenceNode not in result:
                result.append(referenceNode)
        return result
    def saveReferences():
        reference_list=[]
        reference_name=[]
        node_list=cmds.ls(readOnly=True, geometry=True, long=True)
        for i in range(0, len(node_list)):
            ref_name_TEMP=cmds.referenceQuery(node_list[i], referenceNode=True)
            if ref_name_TEMP not in reference_name:
                reference_name.append(ref_name_TEMP)
        for i in range(0, len(reference_name)):
            reference_path=CUTool_referenceOpenHiearchyToRef(reference_name[i])
            reference_list.append(reference_path)
        return reference_list
    #load reference from set
    def loadReferences(attribute=''):
        refences_nodesTEMP = cmds.getAttr('rlhPartition.'+attribute)
        refences_nodesTEMP = re.findall("[A-z, 0-9, _, :]+", str(refences_nodesTEMP))
        allReferencesNodes = listAllReferences()
        for i in range(len(allReferencesNodes)-1, -1, -1):
            if allReferencesNodes[i] not in refences_nodesTEMP:
                if cmds.referenceQuery(allReferencesNodes[i], isLoaded=True) is True: 
                    cmds.file(cmds.referenceQuery(allReferencesNodes[i], filename=True), unloadReference=True); print '\tunload:', allReferencesNodes[i]
        #referencesToUnload = cmds.file(query=True, reference=True)
        #for i in range(0, len(referencesToUnload)):
        #    cmds.file(referencesToUnload[i], unloadReference=True)
        refences_nodes = []
        for i in range(0, len(refences_nodesTEMP)):
            if refences_nodesTEMP[i] not in refences_nodes:
                if not re.findall('\]|\[|\,', refences_nodesTEMP[i]):
                    refences_nodes.append(refences_nodesTEMP[i])
        print 'reference set:', refences_nodes			
        for i in range(0, len(refences_nodes)):
            try:
                filenameReference = cmds.referenceQuery(refences_nodes[i], filename=True)
                if cmds.referenceQuery(filenameReference, isLoaded=True) is False:
                    print '\treference:', refences_nodes[i], filenameReference, '\n\t\tLoad reference:', refences_nodes[i]  
                    ref_filename = cmds.referenceQuery(refences_nodes[i], filename=True)    
                    proxyManagerVar = cmds.listConnections(refences_nodes[i], type="proxyManager")    
                    if proxyManagerVar:
                        connectedReferences = cmds.listConnections(proxyManagerVar, type="reference"); print '\t\t', refences_nodes[i], 'has connected proxy.'
                        if connectedReferences:
                            try:
                                targetReference = [connectedReferences[n] for n in range(0, len(connectedReferences)) if re.findall('\''+connectedReferences[n]+'\'', str(refences_nodes))]
                                if targetReference:    
                                    filename = cmds.referenceQuery(targetReference[0], filename=True)    
                                    print '\t\tLoad from', filename
                                    if cmds.referenceQuery(filename, isLoaded=True) is False:    
                                        mel.eval('proxySwitch ' + targetReference[0] + ';')
                                        print '\t\tLoaded %s' % refences_nodes[i]
                            except:    
                                print '\t\tFailed to load proxy reference %s.' % refences_nodes[i]
                    else:    
                        try:
                            activeProxy = cmds.referenceQuery(refences_nodes[i], filename=True)    
                            if cmds.referenceQuery(activeProxy, isLoaded=True) is False:    
                                cmds.file(loadReference=refences_nodes[i], loadReferenceDepth="topOnly")
                                print '\\ttLoaded %s' % refences_nodes[i]
                        except:    
                            print '\t\tFailed to load original reference %s.' % refences_nodes[i]
            except:
                print '\terrors expected while loadind', refences_nodes[i]
    #procedure
    if not cmds.objExists('rlhPartition'):
        cmds.createNode('partition', n='rlhPartition')
    if load is False:
        attr = cmds.listAttr('rlhPartition')
        attr = [(re.findall('ver[0-9]+', attr[i])[0]).split('ver')[-1] for i in range(0, len(attr)) if re.findall('ver[0-9]+', attr[i])]
        attr = attr and sorted([int(attr[i]) for i in range(0, len(attr))])[-1] or 0
        attr = 'ver'+'0'*(3-len(str(attr+1))) + str(attr+1) + (str(cmds.textFieldGrp('CUTool_NewVersionName', query=True, text=True)) and ('_' + str(cmds.textFieldGrp('CUTool_NewVersionName', query=True, text=True)))); print '\tSave reference statement:', attr
        cmds.addAttr('rlhPartition', longName=attr, hidden=False, dataType='string')
        cmds.setAttr('rlhPartition.'+attr, str(saveReferences()), type='string')
        CUTool_refenceSaveStatement_checkButton(None)
        cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxLoad', edit=True, value1=False)
        CUTool_refenceSaveStatement_checkButton('CUTool_Animation_setup_SaveReferenceState_checkBoxLoad')
        refreshReferenceBackupList()
        if cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxSave', query=True, value1=True) is True:
            dialogWindow(label='Save scene ', text='Do you really want to save this scene???', command='cmds.file(force=True, save=True)')
    elif load is True:
        attr = cmds.textScrollList('CUTool_ABC_ExIm_VersionList_references', query=True, selectItem=True)[0]
        loadReferences(attribute=attr)


def CUTool_referenceOpenHiearchyToRef(reference_target):
	reference_parent=cmds.referenceQuery(reference_target, referenceNode=True, parent=True)
	reference_temp_array=[reference_target]
	if reference_parent:
		reference_temp_array.append(reference_parent)
		while True:
			reference_temp=cmds.referenceQuery(reference_parent, referenceNode=True, parent=True)
			reference_parent=reference_temp
			if reference_parent:
				reference_temp_array.append(reference_temp)
			else:
				break
	if len(reference_temp_array)>0:
		return reference_temp_array

def CUTool_refenceSaveStatement_checkButton(name_button):
	if name_button == None:
		if cmds.objExists('referenceLoadingListNode'):
		    if cmds.attributeQuery('referenceList', node='referenceLoadingListNode', exists=True):
			    cmds.button("CUTool_Animation_setup_LoadReferenceState", edit=True, backgroundColor=[0.1,0.3,0.1], enable=True)
		else:
			cmds.button("CUTool_Animation_setup_LoadReferenceState", edit=True, backgroundColor=[0.3,0.2,0.2], enable=False)
	else:
		state_var=cmds.checkBoxGrp(name_button, query=True, value1=True)
		if state_var is True:
			cmds.button("CUTool_Animation_setup_SaveReferenceState", edit=True, backgroundColor=[0.1,0.3,0.1], enable=True)
			cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxSave', edit=True, enable=True)
			cmds.textFieldGrp('CUTool_NewVersionName', edit=True, enable=True)
		elif state_var is False:
			cmds.button("CUTool_Animation_setup_SaveReferenceState", edit=True, backgroundColor=[0.3,0.2,0.2], enable=False)
			cmds.checkBoxGrp('CUTool_Animation_setup_SaveReferenceState_checkBoxSave', edit=True, enable=False)
			cmds.textFieldGrp('CUTool_NewVersionName', edit=True, enable=False)

def callToMayaPyForSaveShablonDynOrLight( experiment=False ):
	try:
		mayaPy_dir=os.path.join(os.path.split(sys.executable)[0], 'mayapy.exe')
	except:
		mayaPy_dir = 'mayapy.exe'
	episode_number = str(cmds.intFieldGrp('CUTool_Shablon_setup_EpisodeNumber_int', query=True, v1=True))
	episode_number = '0'*(2-len(str(episode_number)))+str(episode_number)
	scene_number = str(cmds.intFieldGrp('CUTool_Shablon_setup_SceneNumber_int', query=True, v1=True))
	scene_number = '0'*(2-len(str(scene_number)))+str(scene_number)
	scene_type = cmds.optionMenu('CUTool_Shablon_setup_SceneType_text', query=True, v=True)
	dopNumber = cmds.intFieldGrp('CUTool_Shablon_setup_SceneNumberDop_int', query=True, v1=True)
	dopNumber = '0'*(2-len(str(dopNumber)))+str(dopNumber)
	enableDop = cmds.checkBoxGrp('CUTool_Shablon_setup_SceneDopControl', query=True, v1=True)
	if enableDop is True:
		scene_number = str(scene_number)+'dop'+str(dopNumber)
	pathCheck = "//SERVER-3D/Project/UrfinJuse/scenes/ep"+episode_number+"/ep"+episode_number+"sc"+scene_number+"/"+scene_type+"/ep"+episode_number+"sc"+scene_number+"_"+scene_type+".mb"
	if experiment is False:
		script_path='//SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm4/CUTool_shablonDynLightBatch.py'#'/'.join(os.environ['USERPROFILE'].split('\\')) + "/Desktop/maya_batch_dylLyghtCreate.py"
	else:
		script_path='//SERVER-3D/Project/lib/setup/maya/maya_scripts_rfm4/CUTool_shablonDynLightBatch2.py'
	arguments=str(episode_number)+' '+str(scene_number)+' '+str(scene_type)
	print '\tCheck file exists:', pathCheck
	if os.path.isfile(pathCheck):
		action = cmds.confirmDialog(title='Warning', message=('File '+pathCheck+' exists. Overwrite???'), button=['yes', 'no'], defaultButton='Yes', cancelButton='No')
		if action == 'yes':
			initScriptBatch(script_path, arguments)
	else:	
		initScriptBatch(script_path, arguments)

def CUTool_installBatchScriptForDynLightSetup():
    script_backup="""
print '\\nSTART'
import sys; print 'import sys -OK'
import os; print 'import os -OK'
import maya.cmds as cmds; print 'import maya.cmds -OK'
import maya.standalone; print 'import maya.standalone -OK'
maya.standalone.initialize(name='python'); print 'initialize import maya.standalone -OK'

def referenceAndSaveSceneForShablon(ep_number, scene_number, scene_type):
	new_name="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/"+scene_type+"/ep"+ep_number+"sc"+scene_number+"_"+scene_type+".mb"#Path to new file
	ref_path01="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/anm/ep"+ep_number+"sc"+scene_number+"_anm.mb"
	ref_path02="//SERVER-3D/Project/UrfinJuse/scenes/ep"+ep_number+"/ep"+ep_number+"sc"+scene_number+"/anm/ep"+ep_number+"sc"+scene_number+"_anm.ma"
	if os.path.exists(ref_path01):
		ref_path=ref_path01
	elif os.path.exists(ref_path02):
		ef_path=ref_path02
	ref_namespace="ep"+ep_number+"sc"+scene_number+"_anm"
	cmds.file(ref_path, loadReferenceDepth='none', open=True)
	start_time=cmds.playbackOptions(query=True, animationStartTime=True)
	end_time=cmds.playbackOptions(query=True, animationEndTime=True)

	cmds.file(new=True, force=True)
	cmds.playbackOptions(minTime=start_time, animationStartTime=start_time)
	cmds.playbackOptions(maxTime=end_time, animationEndTime=end_time)
	cmds.file(ref_path, reference=True, mergeNamespacesOnClash=False, namespace=ref_namespace)
	cmds.file(rename=new_name)
	cmds.file(force=True, save=True, type='mayaBinary')

def referenceAndSaveSceneForShablon_Exec():
	attributtes=(str('{0}'.format(sys.argv[1]))).split(' ')
	episode=attributtes[0]; print 'Episode number: ',episode
	scene=attributtes[1]; print 'Scene number: ',scene
	type=attributtes[2]; print 'Scene type: ',type
	print '\\n//Begin create scene.'
	referenceAndSaveSceneForShablon(episode,scene,type)
	print '\\n//Scene was saved.'

referenceAndSaveSceneForShablon_Exec()
print '\\nEND'
"""

    file=open('/'.join(os.environ['USERPROFILE'].split('\\')) + "/Desktop/maya_batch_dylLyghtCreate.py","w")
    file.write(script_backup)
    file.close()


def CUTool_importReferences():
    #Get all loaded references
    file_name = cmds.file(query = True, sceneName = True) != '' and cmds.file(query = True, sceneName = True) or 'untitled'
    ref_node = cmds.ls(references = True)
    ref_list = []
    ref_list_out = []
    for i in range(0, len(ref_node)):
    	if cmds.referenceQuery(ref_node[i], filename = True) not in ref_list:
    		ref_list.append(cmds.referenceQuery(ref_node[i], filename = True))
    #Get hiearchy
    for i in range(0, len(ref_list)):
    	check_while = 1
    	ref_list_tree = []
    	ref_list_tree.append(ref_list[i])
    	if cmds.referenceQuery(ref_list[i], filename = True, parent = True) and file_name not in cmds.referenceQuery(ref_list[i], filename = True, parent = True):
    		ref_list_tree.append(cmds.referenceQuery(ref_list[i], filename = True, parent = True))
    		while check_while==1:
    			if (cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True)) and file_name not in cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True):
    				ref_list_tree.append(cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True)); print (cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True))
    			else:
    				break
    	for x in range(0, len(ref_list_tree)):
			ref_list_out.append(ref_list_tree[x])
    #Rebuild hiearchy
    ref_list = []
    for i in xrange(len(ref_list_out)-1, -1, -1):
    	if ref_list_out[i] not in ref_list:
    		ref_list.append(ref_list_out[i])
    #Procedure
    for i in range(0, len(ref_list)):
    	if cmds.referenceQuery(ref_list[i], isLoaded = True) is True:
    		cmds.file(ref_list[i], importReference = True)
    	else:
    		cmds.file(ref_list[i], removeReference = True)

def CUTool_OpenSelectedReference(toMayaVer='2013'):
	maya_dir=os.path.join(os.path.split(sys.executable)[0], 'maya')
	mayaVersion = re.findall('[0-9][0-9][0-9][0-9]', maya_dir)[0]
	if mayaVersion != toMayaVer:
		maya_dir = toMayaVer.join(maya_dir.split(mayaVersion))
	file_name = cmds.file(query = True, sceneName = True) != '' and cmds.file(query = True, sceneName = True) or 'untitled'
	#Get path to refence
	path = ('\\'.join((''.join(re.split('_proxy|Proxy', cmds.referenceQuery(cmds.ls(sl=True)[0], filename=True)))).split('/')))
	#Get full path to reference
	check_while = 1
	ref_list_tree = []
	ref_list_tree.append(path)
	path_list=[]
	if cmds.referenceQuery(path, filename = True, parent = True) and file_name not in cmds.referenceQuery(path, filename = True, parent = True):
		ref_list_tree.append(cmds.referenceQuery(path, filename = True, parent = True))
		while check_while==1:
			if (cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True)) and file_name not in cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True):
				ref_list_tree.append(cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True)); print (cmds.referenceQuery(ref_list_tree[-1], filename = True, parent = True))
			else:
				break
	for x in range(0, len(ref_list_tree)):
		path_list.append(ref_list_tree[x])
	subprocess.Popen([maya_dir, path.split('{')[0]])

def CUTool_createBoundingBox(path):
    """
    This script used to get bounding box coordinates and then creating bounding box for select transform node.
    Used by proxy mesh for parse:
    -boundingBox_name
    -boundingBox_size
    """
    #Get 'geo_normal' transform from selected object.
    target_selected = cmds.referenceQuery(cmds.ls(sl=True, readOnly=True)[0], nodes=True, dagPath=True)
    target_selected = [target_selected[i] for i in range(0, len(target_selected)) if 'geo_normal' in target_selected[i] and cmds.nodeType(target_selected[i])=='transform']
    target_selectedCT = [target_selected[i] for i in range(0, len(target_selected)) if 'general_CT' in target_selected[i] and cmds.nodeType(target_selected[i])=='transform']
    #Check target.
    if len(target_selected) and len(target_selected) > 0:
        pass
    else:
        cmds.error('"geo_normal" not found')
    #Create info.
    boundingBox_name = target_selected[0] + '_proxy'
    boundingBox_rotation = cmds.xform(target_selected[0], query=True, ro=True)
    boundingBox_rotationPivot = cmds.xform(target_selected[0], query=True, rp=True)
    #Get bounding box info.
    cmds.xform(target_selected[0], cp=True)
    cmds.xform(target_selected[0], ro=(0, 0, 0))
    bouningBox_info = cmds.xform(target_selected[0], query=True, bb=True)
    #Get sizes for bounding box.
    boundingBox_size = [0, 0, 0]
    boundingBox_size[0] = (bouningBox_info[3] - bouningBox_info[0])
    boundingBox_size[1] = (bouningBox_info[4] - bouningBox_info[1])
    boundingBox_size[2] = (bouningBox_info[5] - bouningBox_info[2])
    #Restore all changes.
    cmds.xform(target_selected[0], ro=(boundingBox_rotation[0], boundingBox_rotation[1], boundingBox_rotation[2]))
    cmds.xform(target_selected[0], rp=(boundingBox_rotationPivot[0], boundingBox_rotationPivot[1], boundingBox_rotationPivot[2]))
    #Create bounding box.
    boundingBox_target = cmds.polyCube(constructionHistory=False, object=True, width=boundingBox_size[0], height=boundingBox_size[1], depth=boundingBox_size[2], name='general_CT')
    cmds.move(0, boundingBox_size[1]/2.0, 0, boundingBox_target, absolute=True)
    cmds.xform(boundingBox_target, ws=True, a=True, rp=(0, 0, 0), sp=(0, 0, 0))
    cmds.makeIdentity(boundingBox_target, apply=True)
    mel.eval('makeProxy()')
    cmds.select('root')
    cmds.file(path, type='mayaBinary', exportSelected=True)
    cmds.delete('root')

#Find connected  nodes
def CUTool_ListDepencyConnections(targetShape, targetAttribute, typeConnection):
	'''
	targetShape = any node
	targetAttribute = any attribute from target node
	typeConnection = find node by this type
	'''
	connectionsToCheck = cmds.listConnections(targetShape+'.'+targetAttribute, shapes=True, skipConversionNodes=True,d=False)
	connectionsType = cmds.listConnections(targetShape,scn=True,d=False,type=typeConnection)
	result = ''
	temp = []
	if connectionsToCheck:
		for i in range(0, len(connectionsToCheck)):
			connectedNode = connectionsToCheck[i]
			while True:
				connectedNode = cmds.listConnections(connectedNode, skipConversionNodes=True,d=False)
				if connectedNode:
					for x in range(0, len(connectedNode)):
						if cmds.nodeType(connectedNode[x]) == typeConnection:
							result = connectedNode
						else:
							continue
					break
				else:
					break
	if connectionsType and result:
		result += connectionsType
	elif connectionsType:
		result = connectionsType
	if result:
		for i in range( 0, len( result )):
			if cmds.nodeType( result[i] ) == typeConnection:
				temp.append( result[i] )
	return temp

def CUTool_blockCustomDirectory(checkBut, name):
	if cmds.checkBoxGrp(checkBut, query=True, v1=True):
		cmds.control(name, edit=True, enable=True)
	else:
		cmds.control(name, edit=True, enable=False)

def CUTool_BatchExportAlembic():
	#mayaPy_dir = 'mayapy.exe'
	script_path = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/CUTool_batchExportCache.py'
	pathToScene = cmds.textField("CUTool_changeABCExportDirectoryScenePRO_textField", query=True, text=True)
	if cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelectionGRP', query=True, select=True) == 1:
		mode = 'dynCache'
	elif cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelectionGRP', query=True, select=True) == 2:
		mode = 'renderCache'
	elif cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelectionGRP', query=True, select=True) == 3:
		mode = 'geometry_grp'
	elif cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelectionGRP', query=True, select=True) == 4:
		mode = 'geo_normal'
	selection = cmds.radioButtonGrp('CUTool_ABCcheck_groupExport_exportModeSelection', query=True, select=True)==1 and 'all' or 'chars'
	arguments = pathToScene + ' ' + mode + ' ' + selection
	if cmds.checkBoxGrp('CUTool_ABCcheck_useCustomDirectory', query=True, v1=True):
		customPath = cmds.textField("CUTool_changeABCExportDirectoryAlembicPRO_textField", query=True, text=True)
		if '/' not in customPath:
			customPath = ('/').join(customPath.split('\\'))+'/'
		arguments += (' customPath'+customPath)
	#args = [mayaPy_dir, script_path, arguments]
	#outputPopen = subprocess.Popen(args, shell=False, stdin=None, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
	#outputPopen, error = outputPopen.communicate()
	initScriptBatch(script_path, arguments)
	#print outputPopen, error

def CUTool_updatePathForBatchExportAlembicScene():
	fileName = cmds.file(query=True, sceneName=True)
	pathToScene = ''
	if re.findall('ep[0-9]+sc[0-9]+', fileName):
		episode = re.findall('ep[0-9]+sc[0-9]+', fileName)[0]
		pathToScene = OSTYPE+'/UrfinJuse/scenes/' + episode.split('sc')[0] + '/' + episode + '/anm/' + episode + '_anm.mb'
		if os.path.isfile(pathToScene) is False:
			pathToScene = OSTYPE+'/UrfinJuse/scenes/' + episode.split('sc')[0] + '/' + episode + '/anm/' + episode + '_anm.ma'
			if os.path.isfile(pathToScene) is False:
				pathToScene = OSTYPE+'/default'
	if pathToScene != '':
		cmds.textField("CUTool_changeABCExportDirectoryScenePRO_textField", edit=True, text=pathToScene)

def CUTool_BatchExportRib(toMayaVer=cmds.about(version=True).split(' ')[0]):
	import maya.cmds as cmds
	targetNodes = cmds.ls(sl=True)
	targetTemp = []
	for i in range(0, len(targetNodes)):
		if ''.join(re.split('proxy|Proxy', cmds.referenceQuery(targetNodes[i], filename=True))) not in targetTemp:
			targetTemp.append(targetNodes[i])
	mayaPy_dir=os.path.join(os.path.split(sys.executable)[0], 'mayapy.exe')
	mayaVersion = re.findall('[0-9][0-9][0-9][0-9]', mayaPy_dir)[0]
	if mayaVersion != toMayaVer:
		mayaPy_dir = toMayaVer.join(mayaPy_dir.split(mayaVersion))
	script_path = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/CUTool_batchCreateRib.py'
	for i in range(0, len(targetTemp)):
		pathToScene = '\\'.join((''.join(re.split('_proxy|Proxy', cmds.referenceQuery(targetTemp[i], filename=True), re.IGNORECASE)).split('{')[0]).split('/')); print pathToScene
		archiveName = cmds.checkBoxGrp('CUTool_RibArchive_useCustomName', query=True, v1=True) and cmds.textField('CUTool_RibSetupNewNameArchive', query=True, text=True) or '"NoName"'
		archiveName = archiveName and archiveName or '"NoName"'; print archiveName
		arguments = pathToScene + ' ' + archiveName + ' ' + str(cmds.checkBoxGrp('CUTool_RibArchive_useUpdateRootProxy', query=True, v1=True))
		#args = [mayaPy_dir, script_path, arguments]
		#outSub = subprocess.call(args, stdin=None, stdout=None, stderr=None, shell=False)
		#outputPopen = subprocess.Popen(args, shell=False, stdin=None, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
		#outputPopen, error = outputPopen.communicate()
		initScriptBatch(script_path, arguments)
		#print outputPopen, error
		if str(cmds.checkBoxGrp('CUTool_RibArchive_useUpdateRootProxy', query=True, v1=True)) == 'True':
			refNamespace = cmds.referenceQuery(targetTemp[i], rfn=True)
			refFile = cmds.referenceQuery(targetTemp[i], filename=True)
			cmds.file(refFile, loadReference='refNamespace')

def reloadReference():
    targetNodes = cmds.ls(sl=True)
    targetTemp = []
    for i in range(0, len(targetNodes)):
        if ''.join(re.split('proxy|Proxy', cmds.referenceQuery(targetNodes[i], filename=True))) not in targetTemp:
            targetTemp.append(targetNodes[i])
    if targetTemp:
        refNamespace = cmds.referenceQuery(targetTemp[i], rfn=True)
        refFile = cmds.referenceQuery(targetTemp[i], filename=True)
        cmds.file(refFile, loadReference=refNamespace)

def SetCam():
	camera = cmds.ls( sl=True, dag=True, type="camera" )
	for i in range( 0, len( camera )):
		print camera[i]
		cmds.setAttr( camera[i] + ".filmFit", 3 )
		cmds.setAttr( camera[i] + ".horizontalFilmAperture", 0.98 )
		cmds.setAttr( camera[i] + ".horizontalFilmAperture", l=True )
		cmds.setAttr( camera[i] + ".verticalFilmAperture", 0.41 )
		cmds.setAttr( camera[i] + ".verticalFilmAperture", l=True )
		cmds.setAttr( camera[i] + ".displayGateMaskOpacity", 0.8 )
		cmds.setAttr( camera[i] + ".displayGateMaskColor", 0.09, 0.09, 0.09, type="double3" )
		cmds.setAttr( camera[i] + ".displayFilmGate", 1 )
		
def createRibArchive(archiveName='rootRibArchiveShape', startTime=1, endTime=1, frequency=0, addPathToProxy=False):
	'''
	This script working only with parented to world 'root' transform node in target object root directory

	archiveName = rib archive project name (default "Current project")
	startTime = rib archive sequence start time (default 1)
	endTime = rib archive sequence end time (default 1)
	frequency = frequency rib arcives per frame (default 0)

	example = createRibArchive(rib.zip, 1, 1, 0)
	createRibArchive('testArchiveForMe')

	path to archive projectDir+'/renderman/ribarchives/'+archiveName.zip
	'''
	#Set project directory
	import maya.cmds as cmds
	archiveName = cmds.checkBoxGrp('CUTool_RibArchive_useCustomName', query=True, v1=True) and cmds.textField('CUTool_RibSetupNewNameArchive', query=True, text=True) or ((cmds.file(query=True, sceneName=True).split('/')[-1]).split('.')[0]+'RibArchive')
	project = re.split('project|Project', cmds.file(query=True, sceneName=True))[-1].split('/')[1]
	filePath = cmds.file(query=True, sceneName=True)
	if re.findall( 'proxy', filePath, re.IGNORECASE ):
		cmds.error( 'Please open original object. Proxy is not supported.' )
	OSTYPE = sys.platform
	curWorkSpace = mel.eval("file -q -loc -sn")
	if re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath):
		projectDir = '/'.join(filePath.split('/')[0:filePath.split('/').index(re.findall('(?<=/)props(?=/)|(?<=/)sets(?=/)|(?<=/)chars(?=/)|(?<=/)scenes(?=/)', filePath)[0])+2])
		if OSTYPE == "win32":
			OSTYPE="//renderServer/Project"
			OSTYPE3D = "//Server-3d/Project"
		else:
			OSTYPE="/renderServer/Project"
			OSTYPE3D = "/Server-3d/Project"
		if OSTYPE:
			projectRoot = OSTYPE+'/'+project+projectDir.split(project)[-1]
			if os.path.isdir( projectRoot ) is False:
				os.makedirs( projectRoot )
			mel.eval("setProject \""+projectRoot+"\";")
			mel.eval("rman subst \"[_handleSyncEvent \\\"file:open\\\" \\\"-origin RfM -proj "+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+" -file "+curWorkSpace+"/ -basepattern {${SCENE}_${DSPYID}} -stagectx {}\\\"]\";")
			mel.eval('rman slim message \"workspace SetProject '+OSTYPE+'/'+project+projectDir.split(project)[-1]+'/'+'"')
		#set project only for files in 'props', 'sets', 'chars', 'scenes' directory
		projectRoot = '/'.join(filePath.split('/')[0:4])
		#mel.eval('rman setvar RMSPROJ "' + projectDir + '/"')
		#mel.eval('rman setvar RMSPROD "' + projectRoot + '"')
		#mel.eval('rman setvar RMSPROD_GLOBAL "' + projectRoot + '"')
		archiveDir = mel.eval('rman workspace GetDir "rfmRIBArchives"')
		#set shaders diretory to rib archive path
		shaderDirArchive = (archiveDir+'/'+archiveName+'/shaders')
		slimDirArchive = (archiveDir+'/'+archiveName+'/slim/shaders')
		mel.eval('rman slim command ("slim ReloadExtensions cmd")')
		mel.eval('rman workspace SetDir "rfmShaders" ("{'+shaderDirArchive+'}");')
		mel.eval('rman workspace SetDir "slimShaders" ("{'+slimDirArchive+'}");')
		mel.eval('rman slim command ("workspace SetDir slimShaders {'+slimDirArchive+'}")')
		mel.eval('rman slim command ("slim BuildShaders")')
	else:
		cmds.warning('File is corrupted, please use project files or files in assets, scenes project directory')
	#Rib node setup
	ribArchiveShapeNode = ''
	rootTr = cmds.ls(sl=True, type='transform')
	if rootTr:
		newRoot = rootTr
	else:
		objects = cmds.ls(transforms=True, long=True)
		upperTransforms = []
		for i in range(0, len(objects)):
			if objects[i].split('|')[1]:
				objectTEMP = objects[i].split('|')[1]
				shapes = cmds.ls(objectTEMP, dag=True, leaf=True, long=True)[0]
				if shapes.split('|') and len(shapes.split('|'))>4:
					if objectTEMP not in upperTransforms:
						upperTransforms.append(objectTEMP)
		newRoot = cmds.createNode('transform', n='root')
		cmds.parent(upperTransforms, newRoot)
	if ribArchiveShapeNode == '':
		newRib = cmds.createNode('transform', n='ribArchive'); print '\tcreate rib:', newRib
		ribArchiveShapeNode = cmds.createNode('RenderManArchive', name=(newRib+'Shape'), parent=newRib)
		try:
			cmds.parent((cmds.listRelatives(ribArchiveShapeNode, parent=True)[0]), newRoot)
		except:
			cmds.warning('root already get archive')
	cmds.setAttr(ribArchiveShapeNode+'.crew', '__siblings', type='string')
	cmds.setAttr(ribArchiveShapeNode+'.startframe', startTime)
	cmds.setAttr(ribArchiveShapeNode+'.endframe', endTime)
	archivePathName = mel.eval('rman getvar RMSPROJ')+mel.eval('rman workspace GetDir "rfmRIBArchives"')+'/'+archiveName+'.zip'
	cmds.setAttr(ribArchiveShapeNode+'.filename', archivePathName, type='string')
	#Export rib
	mel.eval('rman genrib -cacheCrew ("'+ribArchiveShapeNode+'"+",") -updateArchives 1 -s '+str(startTime)+' -e '+str(endTime)+' -updateArchivesPerFrame '+str(frequency)+';')
	cmds.delete(newRib)
	print '\n\n\npath to rib archive:\n', archivePathName, '\n\n\n'
	if addPathToProxy is True:
		mayaPy_dir=os.path.join(os.path.split(sys.executable)[0], 'mayapy.exe')
		mayaVersion = re.findall('[0-9][0-9][0-9][0-9]', mayaPy_dir)[0]
		if mayaVersion != '2013':
			mayaPy_dir = '2013'.join(mayaPy_dir.split(mayaVersion))
		script = OSTYPE3D+'/lib/setup/maya/maya_scripts_rfm4/addRibPathToProxy.py'
		pathToProxy = findProxy(path=cmds.file(query=True, sceneName=True))
		if not pathToProxy:
			pathToProxy = createProxyByPath(original=cmds.file(query=True, sceneName=True))
		pathToRib = archivePathName
		arguments = pathToProxy + ' ' + pathToRib
		initScriptBatch(script, arguments)
	return archivePathName

def getSetContain(inputName='deleteSet', actionWithSet='delete'):
    '''
    inputName = 'target set name'
    actionWithSet
        -'delete' = delete set members
        -'optimize' = optimize geometry for set members
        -'get' = return list set members
    '''
    containerSet = cmds.sets(inputName, query=True, nodesOnly=True)
    if actionWithSet == 'delete':
        for i in range(0, len(containerSet)):
            if objExists(containerSet[i]):
                cmds.delete(containerSet[i])
    if actionWithSet == 'optimize':
       pass
    if actionWithSet == 'get':
        return containerSet

def getGeometryGrp(findGrp='geometry_grp'):
	'''
	findGrp = search name
	'''
	allTr = cmds.ls(transforms=True)
	geoTr = []
	for i in range(0, len(allTr)):
		if findGrp in allTr[i]:
			geoTr.append(allTr[i])
	if geoTr:
		return geoTr


def initScriptBatch(pathToScript, stringVar, block=False):
	'''
	This script run maya in mel batch mode and execute python file scripts
	run this without maya.standalone

	pathToScript = path to .py file
	stringVar = parse variables from python string


	run example:
	initScriptBatch('C:/Users/guzha_k/Desktop/mtoaTest.py', 'Hello')
	example source:
	import sys
	arguments = (str('{0}'.format(sys.argv[4])))
	'''
	import subprocess
	mayaExe = os.path.join(os.path.split(sys.executable)[0], 'maya')
	#string to run maya batch with user settings
	command = mayaExe + ' -batch -command "python(\\"\"execfile(' + "\\'" + pathToScript + "\\'" + ')\"\\")"' + ' "' + stringVar + '"'
	print command
	#run maya batch
	block = block is True and 'call' or 'Popen'
	exec('subprocess.'+block+'(command, stdin=None, stdout=None, stderr=None, shell=False)')


def CUTool_LockCameras(mode='lock'):
	'''
	thsi script lock and unlock cameras

	lock = lock all non referenced user cameras
	unlock = unlock selected non referenced user cameras
	'''
	if mode == 'lock':
		camerasList = cmds.listCameras()
		for i in range(0, len(camerasList)):
			if cmds.referenceQuery(camerasList[i], isNodeReferenced=True) is False:
				if cmds.camera(camerasList[i], query=True, startupCamera=True) is False:
					try:
						cmds.setAttr(camerasList[i]+'.scale', lock=True)
						cmds.setAttr(camerasList[i]+'.scaleX', lock=True)
						cmds.setAttr(camerasList[i]+'.scaleY', lock=True)
						cmds.setAttr(camerasList[i]+'.scaleZ', lock=True)
						cmds.setAttr(camerasList[i]+'.translate', lock=True)
						cmds.setAttr(camerasList[i]+'.translateX', lock=True)
						cmds.setAttr(camerasList[i]+'.translateY', lock=True)
						cmds.setAttr(camerasList[i]+'.translateZ', lock=True)
						cmds.setAttr(camerasList[i]+'.rotate', lock=True)
						cmds.setAttr(camerasList[i]+'.rotateX', lock=True)
						cmds.setAttr(camerasList[i]+'.rotateY', lock=True)
						cmds.setAttr(camerasList[i]+'.rotateZ', lock=True)
					except:
						cmds.warning('current camera '+camerasList[i]+' is corrupted')
	if mode == 'unlock':
		camerasList = cmds.ls(sl=True, dag=True, leaf=True, cameras=True, long=True)
		if camerasList:
			for i in range(0, len(camerasList)):
				try:
					cameraTransform = camerasList[i].split('|')[-2]
					cmds.setAttr(cameraTransform+'.scale', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.scaleX', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.scaleY', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.scaleZ', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.translate', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.translateX', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.translateY', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.translateZ', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.rotate', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.rotateX', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.rotateY', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.rotateZ', lock=False, keyable=True)
					cmds.setAttr(cameraTransform+'.visibility', lock=False, keyable=True)
					print 'unlock camera: '+cameraTransform+'.'
				except:
					cmds.warning('current camera '+camerasList[i]+' is corrupted')

def convertInt(inputChar):
	'''
	this script convert string to int and long to string

	inputChar = string or int
	'''
	BASE = '% _12345!@#$%^&*()+=|}{][6789abcdefghijlkmnopqrstuvwxyzABCDEFGHJLKLMNPQRSTUVWXYZ'
	convertedInt = ''
	if 'str' in str(type(inputChar)):
		for i in inputChar:
			if i in BASE:
				convertedInt += str(BASE.index(i)) + '0'
		return long(convertedInt)
	if 'long' in str(type(inputChar)):
		inputChar = (str(inputChar)).split('0')
		for i in range(0, len(inputChar)-1):
			print inputChar[i]
			convertedInt += BASE[int(inputChar[i])]
		return convertedInt

def CUTool_renderPreview():
	'''
	this script setup render settings

	modeUsed = 'setup' or 'render', default used 'setup' mode
		setup - fast setup render settings
		render - fast setup render setting and start render
	resolutionUsed = resolution gate for render settings, default used 2048x858.
	cameraUsed = used camera for render, default used current camera.

	example: renderSetup('render', '640x480', 'frontShape')
	'''
	#check renderman plugin load
	resolutionGates = ['1024x429', '2048x858', '2100x858', '2048x2048', '1024x1024', '512x512', '640x480', '320x240', '320x480']
	resolutionUsed = int(cmds.getAttr('perspShape.renderPreviewResolutionInt'))
	resolutionUsed = resolutionGates[resolutionUsed]
	cameraAll = cmds.getAttr('perspShape.renderPreviewCamera').split(' ')
	cameraAll = [cameraAll[i] for i in range(0, len(cameraAll)) if 'None' not in cameraAll[i]]
	cameraUsed = int(cmds.getAttr('perspShape.renderPreviewCameraInt'))
	cameraUsed = cameraAll[cameraUsed]
	camerasList = cmds.ls(cameras=True, long=True)
	oldSettings = []
	if cmds.pluginInfo('RenderMan_for_Maya',query=True, loaded=True) is False:
		try:
			cmds.loadPlugin('Renderman_For_Maya')
		except:
			cmds.warning('Renderman plugin was not loaded')
			return False
	#this check options from menu if menu exists
	if cmds.window("CUTool_window_00", exists=True) is False:
		cameraUsed = cmds.ls(cmds.modelPanel(cmds.getPanel(wf=True), q=True, cam=True), dag=True, leaf=True, type='camera', long=True)[0]
		for i in range(0, len(camerasList)):
			if cameraUsed != camerasList[i]:
				oldSettings.append(('cmds.setAttr(camerasList[i]+".renderable", ' + (cmds.getAttr(camerasList[i]+".renderable") is True and '1' or '0') +')'))
				cmds.setAttr(camerasList[i]+".renderable", 0)
		cmds.setAttr(cameraUsed+".renderable", 1)
	else:
		for i in range(0, len(camerasList)):
			if cameraUsed != camerasList[i]:
				oldSettings.append(('cmds.setAttr(camerasList[i]+".renderable", ' + (cmds.getAttr(camerasList[i]+".renderable") is True and '1' or '0') +')'))
				cmds.setAttr(camerasList[i]+".renderable", 0)
		cmds.setAttr(cameraUsed+".renderable", 1)
	#renderman setup
	cmds.setAttr("defaultResolution.width", int(resolutionUsed.split('x')[0]))
	cmds.setAttr("defaultResolution.height", int(resolutionUsed.split('x')[1]))
	mel.eval('loadPreferredRenderGlobalsPreset("renderMan");')
	mel.eval('rmanStartIt;')
	#start render and restore old camera settings
	mel.eval('setCurrentRenderer renderMan; rmanChangeRendererUpdate; rmanRenderPass("Final","");')
	for i in range(0, len(oldSettings)):
	    exec(oldSettings[i])
	return True

def setParentWithTransformation(target=False, instanceShape=False, duplicateShape=False):
    '''
    This script parent first selected object to second selected object with set transformation to destination object

    target = array [first target object, second destination object]
    instanceShape = if True create instance of the second object, default is False

    example:
        setParentWithTransformation()
        setParentWithTransformation(instanceShape=True)
        setParentWithTransformation(duplicateShape=True)
        setParentWithTransformation(['root1', 'pCube2'])
    '''
    if instanceShape == True and duplicateShape == True:
        cmds.error('please specify one flag for instance or duplicate')
    if target is False:
        target=cmds.ls(sl=True)
    if instanceShape == True:
        script = 'cmds.parent(target[0], target[1], relative=True, shape=True, addObject=True)'
    elif duplicateShape == True:
        target[0] = cmds.duplicate(target[0])[0]
        script = 'cmds.parent(target[0], target[1], relative=True, shape=True)'
    else:
        script = 'cmds.parent(target[0], target[1], relative=True, shape=True)'
    if script:
        try:
            cmds.warning(target[0]+' parent to '+target[1]+'.')
            exec(script)
            return True
        except:
            cmds.warning(target[0]+' parent to '+target[1]+' failed.')
            return False
    else:
        cmds.error('Please select target and destination objects!!!')

def ml_cut_animation( objects="", depth=False, startTime="", endTime="", selected=False ):
    '''
	Cut animation curves.
	-objects = Objects list.
	-depth = Include in object list all childrens.
	-selected = Work with selected objects.
	-startTime = start cut time.
	-endTime = end cut time.
    '''
    ml_result = []
    ml_objects = objects =='' and ( selected is False and cmds.ls( dag=True, type='transform' ) or cmds.ls( sl=True, dag=True, type='transform' )) or ( depth is True and cmds.ls( objects, dag=True ) or ( 'list' in str( type( objects )) and objects or [ objects ] ))
    ml_type = [ 'animCurveTA', 'animCurveTU', 'animCurveTL', 'animCurveTT', 'animCurveUA', 'animCurveUL', 'animCurveUT', 'animCurveUU', 'animCurve' ]
    ml_startTime = startTime == '' and cmds.playbackOptions( query=True, animationStartTime=True ) or startTime
    ml_endTime = endTime == '' and cmds.playbackOptions( query=True, animationEndTime=True ) or endTime
    for i in range( 0, len( ml_objects )):
        mlt_curves = []
        for n in range( 0, len( ml_type )):
            mlt_temp = cmds.listConnections( ml_objects[i], type=ml_type[n] )
            if mlt_temp:
                for f in range( 0, len( mlt_temp )):
                    if mlt_temp[f] not in mlt_curves:
                        mlt_curves.append( mlt_temp[f] )
                    if mlt_temp[f] not in ml_result:
                        ml_result.append( mlt_temp[f] )
        if mlt_curves:
            cmds.setKeyframe( mlt_curves, insert=True, time=( ml_startTime, ml_startTime ))
            cmds.setKeyframe( mlt_curves, insert=True, time=( ml_endTime, ml_endTime ))
            if ml_endTime > ml_startTime:
                cmds.cutKey( ml_objects[i], time=( ':' + str( ml_startTime - 1 ), ) , clear=True )
                cmds.cutKey( ml_objects[i], time=( str( ml_endTime + 1 ) + ':', ) , clear=True )
            else:
                cmds.cutKey( ml_objects[i], time=(( ml_endTime + 1 ), ( ml_startTime - 1 )) , clear=True )
    return ml_result
	
def cutAnimation( nodes="", descendents=False, start="", end="" ):
    result = []
    nodes = nodes == "" and cmds.ls( sl=True ) or ( type( nodes ) is list and nodes or [ nodes ] )
    animation = [ "animCurveTA", "animCurveTU", "animCurveTL", "animCurveTT", "animCurveUA", "animCurveUL", "animCurveUT", "animCurveUU", "animCurve" ]
    start = start == '' and cmds.playbackOptions( query=True, animationStartTime=True ) or start
    end = end == '' and cmds.playbackOptions( query=True, animationEndTime=True ) or end
    if descendents is True:
        nodes = cmds.ls( nodes, dag=True )
    for n in range( 0, len( nodes )):
        curves = []
        for t in range( 0, len( animation )):
            connections = cmds.listConnections( nodes[n], type=animation[t] )
            if connections:
                for c in range( 0, len( connections )):
                    if connections[c] not in curves:
                        curves.append( connections[c] )
        if curves:
            for c in range( 0, len( curves )):
                previuos = cmds.findKeyframe( curves[c], time=( "%s:" % start, ), which="previous" )
                first = cmds.findKeyframe( curves[c], time=( start, ), which="next" )
                last = cmds.findKeyframe( curves[c], time=( end, ), which="previous" )
                next = cmds.findKeyframe( curves[c], time=( "%s:" % end, ), which="next" )
                if first > previuos:
                    cmds.setKeyframe( curves[c], insert=True, time=( start, start ))
                if next > last:
                    last_val = cmds.keyframe( curves[c], query=True, time=( last, ), valueChange=True )
                    next_val = cmds.keyframe( curves[c], query=True, time=( next, ), valueChange=True )
                    tangent = cmds.keyTangent( curves[c], time=( last, ), query=True, outTangentType=True )
                    if "step" not in tangent and "stepNext" not in tangent and last_val!=next_val:
                        postInfinity = cmds.getAttr( "%s.postInfinity" % curves[c] )
                        cmds.setAttr( "%s.postInfinity" % curves[c], 1 )
                        cmds.setKeyframe( curves[c], insert=True, time=( end, end+1 ))
                        cmds.setAttr( "%s.postInfinity" % curves[c], postInfinity )
                if end > start:
                    cmds.cutKey( curves[c], time=( ":%s" % ( start - 1 ), ) , clear=True )
                    cmds.cutKey( curves[c], time=( str( end + 2 ) + ':', ) , clear=True )
                else:
                    cmds.cutKey( curves[c], time=(( end + 2 ), ( start - 1 )) , clear=True )
                result.append( curves[c] )
    print result
    return result

def rangesCache(importRanges=False, exportRange=False, backUp=False, backUpAttr=''):
    '''
    importRanges = load animation ranges from attribute
    exportRange = save animation ranges to attribute

    Example:

    #save ranges
    rangesCache(exportRange=True)
    #import original ranges
    rangesCache(importRanges=True, backUp=True)
    #import ranges from backup
    rangesCache(importRanges=True, backUp=False)
    '''
    if importRanges == True and exportRange == True or importRanges == False and exportRange == False:
        cmds.error('Please specify one flag')
    #get info
    filename = cmds.file(query=True, sceneName=True)
    episode = re.findall('ep[0-9]+', filename)
    if episode:
        episode = episode[0]
    scene = re.findall('sc[0-9]+', filename)
    if scene:
        scene = scene[0]
    dop = re.findall('_dop', filename)
    if dop:
        dop = dop[0]
    #get target camera
    cameras = cmds.listCameras()
    for i in range(0, len(cameras)):
        if episode+scene in cameras[i].split(':')[-1] and 'cam' in cameras[i]:
            cameras = cameras[i]
            break
    if exportRange is True:
        #attribute create
        if cmds.attributeQuery('dataAnimationRanges', node=cameras, exists=True) is False:
            cmds.addAttr(cameras, shortName='daranges', longName='dataAnimationRanges', dataType='string')
        if cmds.attributeQuery('dataAnimationRangesBackUp', node=cameras, exists=True) is False:
            cmds.addAttr(cameras, shortName='darangesBp', longName='dataAnimationRangesBackUp', dataType='string')
        #save backup
        if cmds.getAttr(cameras+'.dataAnimationRanges') != None:
            backUpAttr = cmds.getAttr(cameras+'.dataAnimationRanges')
            cmds.setAttr(cameras+'.dataAnimationRangesBackUp', backUpAttr, type='string')
        #save new settings
        startAnim = str(cmds.playbackOptions(query=True, animationStartTime=True))
        endAnim = str(cmds.playbackOptions(query=True, animationEndTime=True))
        cmds.setAttr(cameras+'.dataAnimationRanges', startAnim+' '+endAnim, type='string')
        if backUpAttr != '':
            pass
        else:
            backUpAttr = cmds.getAttr(cameras+'.dataAnimationRanges')
            cmds.setAttr(cameras+'.dataAnimationRangesBackUp', backUpAttr, type='string')
        print 'Original: '+startAnim+' '+endAnim+', Backup: '+backUpAttr
    elif importRanges is True:
        if backUp is True:
            if cmds.attributeQuery('dataAnimationRangesBackUp', node=cameras, exists=True) is False:
                return 'Nothing to import.'
            elif cmds.getAttr(cameras+'.dataAnimationRangesBackUp') ==  None:
                return 'Ranges is not saved.'
            else:
                startTime = cmds.getAttr(cameras+'.dataAnimationRangesBackUp').split(' ')[0]
                endTime = cmds.getAttr(cameras+'.dataAnimationRangesBackUp').split(' ')[-1]
                cmds.playbackOptions(edit=True, animationStartTime=startTime)
                cmds.playbackOptions(edit=True, minTime=startTime)
                cmds.playbackOptions(edit=True, animationEndTime=endTime)
                cmds.playbackOptions(edit=True, maxTime=endTime)
                print 'ranges: ', startTime, endTime
        if backUp is False:
            if cmds.attributeQuery('dataAnimationRanges', node=cameras, exists=True) is False:
                return 'Nothing to import.'
            elif cmds.getAttr(cameras+'.dataAnimationRanges') ==  None:
                return 'Ranges is not saved.'
            else:
                startTime = cmds.getAttr(cameras+'.dataAnimationRanges').split(' ')[0]
                endTime = cmds.getAttr(cameras+'.dataAnimationRanges').split(' ')[-1]
                cmds.playbackOptions(edit=True, animationStartTime=startTime)
                cmds.playbackOptions(edit=True, minTime=startTime)
                cmds.playbackOptions(edit=True, animationEndTime=endTime)
                cmds.playbackOptions(edit=True, maxTime=endTime)
                print 'ranges: ', startTime, endTime


def changeBlockUI(uiName=''):
    '''
    this script block and unblock target ui

    uiName = full ui target name

    Example:
    changeBlockUI(uiName="button_to_foo")
    '''
    if uiName == '':
        return 'Nothing to block.'
    if cmds.control(uiName, query=True, exists=True):
        if cmds.control(uiName, query=True, enable=True):
            cmds.control(uiName, edit=True, enable=False)
        else:
            cmds.control(uiName, edit=True, enable=True)
    else:
        return 'Nothing to block'

def createPathToProxy():
    '''
    This script generate path to proxy version
    '''
    OSTYPE = sys.platform
    if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
    else:
        OSTYPE="/Server-3d/Project"
    scene = cmds.file(query=True, sceneName=True)
    if re.findall('^P\:/', scene, re.IGNORECASE):
        scene = scene.split('P:/')[-1]
        scene = OSTYPE+'/'+scene
    if len(scene.split('/')) == 1:
        return 'Please save scene'
    scene = scene.split('/')
    if '_' in scene[-1]:
        if '_proxy' not in scene[-1] or 'Proxy' not in scene[-1]:
            part01 = scene[-1].split('_')
            part02 = part01[-1]
            part01 = part01[0]
            part03 = 'mb'#part02.split('.')[-1]
            part02 = part02.split('.')[0]
            scene[-1] = part01+'_'+part02+'Proxy.'+part03
            return '/'.join(scene)
    else:
        if '_proxy' not in scene[-1] or 'Proxy' not in scene[-1]:
            part01 = scene[-1].split('.')
            part02 = 'mb'#part01[-1]
            part01 = part01[0]
            scene[-1] = part01+'_proxy.'+part02
            return '/'.join(scene)


def CUTool_BatchCreateProxy():
    '''
    this script  create proxy for selected object
    '''
    #path to script
    script_path = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/CUTool_createProxyBatch.py'
    #create proxy controls
    createControls = str(cmds.checkBoxGrp('CUTool_modeling_proxy_createControls', query=True, v1=True))
    #use gpu cache
    gpuCacheUsage = str(cmds.checkBoxGrp('CUTool_modeling_proxy_useGpuCache', query=True, v1=True))
    gpuCacheTreshold = str(cmds.intFieldGrp('CUTool_modeling_setup_00_optimizeGpuCacheVertices', query=True, value1=True))
    #optimize geometry
    optimizeGeometry = str(cmds.checkBoxGrp('CUTool_modeling_proxy_OptimizeGeometry', query=True, v1=True))
    optimizeGeometryValue = str(cmds.intSliderGrp('CUTool_modeling_proxy_OptimizeGeometryPercent', query=True, value=True))
    #get path to proxy
    pathToProxy = str(cmds.textField('CUTool_changeProxyExportDirectory_textField', query=True, text=True))
    #export to new file selected geometry
    formats = re.findall('.mb$', pathToProxy) and 'mayaBinary' or 'mayaAscii'
    if re.findall('[A-z, 0-9]+/*.mb$|.ma$', pathToProxy):
        cmds.file(pathToProxy, exportSelected=True, preserveReferences=False, type=formats)
        arguments = pathToProxy+' '+createControls+' '+gpuCacheUsage+' '+gpuCacheTreshold+' '+optimizeGeometry+' '+optimizeGeometryValue+' '+str(createRibArchive())
        initScriptBatch(script_path, arguments)
    else:
        cmds.warning('Please specify path to file.')

def getUsedReferenceNodes():
    references = cmds.file(query=True, reference=True)
    referencesNodes = []
    for i in range(0, len(references)):
        referencesNodes.append(cmds.referenceQuery(references[i], referenceNode=True))
    return referencesNodes

def getURefs(mode='all', number=False):
    '''
    return list all used references
    '''
    def getConnectedReferences(var):
        result = []
        for i in range(0, len(var)):
            connections = cmds.listConnections(var[i], type='reference')
            if connections:
                [result.append(connections[j]) for j in range(0, len(connections)) if connections[j] not in result]
        return result
    def getReferenceFilename(var):
        result = []
        for i in range(0, len(var)):
            filename = ''
            try:
                filename = cmds.referenceQuery(var[i], filename=True, withoutCopyNumber=True)
                if filename not in result:
                    result.append(filename)
            except:
                result.append(var[i]+' ---------------FAILED REFERENCE.')
        return result
    def differenceArrays(x, y):
        result = []
        [result.append(x[i]) for i in range(0, len(x)) if x[i] not in y]
        return result
    def addToArray(varOne, varTwo):
        result = []
        if varOne:
            [result.append(varOne[i]) for i in range(0, len(varOne)) if varOne[i] not in result]
        if varTwo:
            [result.append(varTwo[i]) for i in range(0, len(varTwo)) if varTwo[i] not in result]
        return result
    def getCountFailedReference(var):
        result = []
        for i in range(0, len(var)):
            if '---------------FAILED REFERENCE.' in var[i]:
                result.append(var[i])
        return len(result)
    #get references
    proxyConnected = getReferenceFilename(getConnectedReferences(cmds.ls(type='proxyManager')))
    proxyNoConnected = differenceArrays(getReferenceFilename(getUsedReferenceNodes()), proxyConnected)
    #convert to names
    if number is False:
        if mode == 'all':
            return sorted(addToArray(proxyConnected, proxyNoConnected))
        elif mode == 'proxy':
            return sorted([proxyConnected[i] for i in range(0, len(proxyConnected)) if re.findall('proxy', proxyConnected[i], re.IGNORECASE)])
        elif mode == 'original':
            return sorted([proxyConnected[i] for i in range(0, len(proxyConnected)) if not re.findall('proxy', proxyConnected[i], re.IGNORECASE)])
        elif mode == 'noProxy':
            return sorted(proxyNoConnected)
        elif mode == 'failed':
            return getCountFailedReference(addToArray(proxyConnected, proxyNoConnected))
    elif number is True:
        return len(addToArray(proxyConnected, proxyNoConnected))

def getUniqueRefeferencesUI():
    references = getURefs(mode='all')
    if cmds.window("CUTool_ReferenceQueryWindow", exists=True):
        cmds.deleteUI("CUTool_ReferenceQueryWindow", window=True)
    cmds.window("CUTool_ReferenceQueryWindow", title="Used references list",height=250,width=250)
    cmds.frameLayout("CUTool_ReferenceQueryWindow_layout", parent="CUTool_ReferenceQueryWindow", borderStyle="etchedOut", labelVisible=False)
    cmds.text(label='References', parent="CUTool_ReferenceQueryWindow_layout")
    cmds.textScrollList("CUTool_ReferenceQueryWindow_referencesList", height=200, allowMultiSelection=False, font='boldLabelFont', parent="CUTool_ReferenceQueryWindow_layout")
    cmds.text('CUToolSetup_referenceCountInfoText', font='smallPlainLabelFont', parent='CUTool_ReferenceQueryWindow_layout')
    if references:
        for i in range(0, len(references)):
            cmds.textScrollList("CUTool_ReferenceQueryWindow_referencesList", edit=True, append=references[i])
    cmds.radioButtonGrp('CUTool_ReferenceQueryWindow_checkOriginal', label='Selection list: ', labelArray4=['All', 'Proxy', 'Original', 'No proxy'], numberOfRadioButtons=4, select=1, editable=True, parent='CUTool_ReferenceQueryWindow_layout', changeCommand="CUToolSetup.updateList()")
    cmds.button('CUTool_ReferenceQueryWindow_ButtonOpenReference', label="Open selected", ann='Open selected reference in new maya', backgroundColor=[0.4,0.4,0.4], command="CUToolSetup.openTargetMayaFile(ver='2013', fileName=cmds.textScrollList('CUTool_ReferenceQueryWindow_referencesList', query=True, selectItem=True)[0], getOriginal=False)")
    updateList()
    cmds.showWindow("CUTool_ReferenceQueryWindow")

def openTargetMayaFile(ver='2013', fileName='', getOriginal=False):
	directoryExe=os.path.join(os.path.split(sys.executable)[0], 'maya')
	mayaVersion = re.findall('[0-9][0-9][0-9][0-9]', directoryExe)[0]
	if mayaVersion != ver:
		directoryExe = ver.join(directoryExe.split(mayaVersion))
	#Get path to refence
	if getOriginal is True:
	    fileName = ('\\'.join((''.join(re.split('_proxy|Proxy', cmds.referenceQuery(cmds.ls(sl=True)[0], filename=True)))).split('/')))
	#Get full path to reference
	subprocess.Popen([directoryExe, fileName])

def updateList():
    value = cmds.radioButtonGrp('CUTool_ReferenceQueryWindow_checkOriginal', query=True, select=True)
    number = getURefs(number=True)
    if value == 1:
        newList = getURefs(mode='all')
    elif value == 2:
        newList = getURefs(mode='proxy')
    elif value == 3:
	    newList = getURefs(mode='original')
    elif value == 4:
        newList = getURefs(mode='noProxy')
    cmds.textScrollList('CUTool_ReferenceQueryWindow_referencesList', edit=True, removeAll=True)
    cmds.text('CUToolSetup_referenceCountInfoText', edit=True, label=('Total used references in scene: '+str(number))+'\n Total failed references in scene: '+str(getURefs(mode='failed', number=False))+'\n Total unknown reference in scene: '+str(getUnknownReferenceNodes(clean=False, number=True)))
    if newList:
        for i in range(0, len(newList)):
            cmds.textScrollList("CUTool_ReferenceQueryWindow_referencesList", edit=True, append=newList[i])

def getUnknownReferenceNodes(clean=True, number=False):
    '''
    Delete all unknown reference nodes with containing unused edits
    clean = if False, return all unknown reference nodes
    '''
    references = cmds.ls(type='reference')
    unknownReference = []
    for i in range(0, len(references)):
        if re.findall('_UNKNOWN_REF_NODE_', references[i]):
            unknownReference.append(references[i])
    if clean is True:
        for i in range(0, len(unknownReference)):
            try:
                cmds.delete(unknownReference[i])
            except:
                cmds.warning('Cannot delete specified node '+unknownReference[i])
            return unknownReference
    elif clean is False and number is False:
        return unknownReference
    elif number is True:
        return len(unknownReference)

def referencedNodes(filename=False, nodes=True, onlyFirstLevel=False):
    '''
    This procedure get all references in scene if reference exists
    filename = if True return only file names
    nodes = if True return only reference nodes
    '''
    def containerReferences(var):
        contained = cmds.file(var, query=True, reference=True)
        if contained:
            for i in range(0, len(contained)):
                references.append(contained[i])
                containerReferences(contained[i])
    references = cmds.file(query=True, reference=True)
    if onlyFirstLevel is False:
        if references:
            for i in range(0, len(references)):
                containerReferences(references[i])
    #return only references filenames
    if nodes is False and filename is True:
        return references
    #return only references nodes
    elif filename is False and nodes is True:
        nodes = []
        for i in range(0, len(references)):
            try:
                nodes.append(cmds.referenceQuery(references[i], referenceNode=True))
            except:
                pass
        return nodes

def dateCheck(original='', proxy='', magic=0):
    '''
    Return true, if original object created before proxy object
    original = file
    proxy = file
    '''
    return int(os.path.getmtime(original)) < (int(os.path.getmtime(proxy))+magic)

def getConnectedProxy(source='', original=False):
    '''
    Return proxy if reference with proxy
    source = any reference node
    '''
    proxyManager = cmds.listConnections(source, type='proxyManager')
    proxy = []
    if proxyManager:
        connectedProxy = cmds.listConnections(proxyManager, type='reference')
        if original is False:
            if connectedProxy:
                [proxy.append(connectedProxy[i]) for i in range(0, len(connectedProxy)) if re.findall('proxy', cmds.referenceQuery(connectedProxy[i], filename=True), re.IGNORECASE) and connectedProxy[i] not in proxy]
        elif original is True:
            [proxy.append(connectedProxy[i]) for i in range(0, len(connectedProxy)) if not re.findall('proxy', cmds.referenceQuery(connectedProxy[i], filename=True), re.IGNORECASE) and connectedProxy[i] not in proxy]
    return proxy

def categoryLink( nodes="", lights="", remove=False ):
    if nodes == "":
        nodes = cmds.ls( sl=True, dag=True, type=[ "shaveHair", "mesh", "RenderManArchive" ])
    else:
        nodes = cmds.ls( nodes, dag=True, type=[ "shaveHair", "mesh", "RenderManArchive" ] )
    if lights == "":
        lights = cmds.ls( sl=True, dag=True, type=[ "RMSGeoAreaLight", "RMSGeoLightBlocker", "RMSAreaLight", "RMSLightBlocker", "RMSEnvLight", "RMSPointLight" ] )
    else:
        lights = cmds.ls( lights, type=[ "RMSGeoAreaLight", "RMSGeoLightBlocker", "RMSAreaLight", "RMSLightBlocker", "RMSEnvLight", "RMSPointLight" ] )
    shapes = []
    shablon = "RiAttribute \"user\" \"string lightcategory\" "
    for n in range( 0, len( nodes )):
        ntype = cmds.nodeType( nodes[n] )  
        if ntype == "mesh":
            shapes.append( nodes[n] )
        elif ntype == "shaveHair":
            parent = cmds.listRelatives( nodes[n], parent=True )
            shapes.append( parent )
        elif ntype == "RenderManArchive":
            parent = cmds.listRelatives( nodes[n], parent=True )
            shapes.append( parent )
    for l in range( 0, len( lights )):
        category = "%s.__category" % lights[l]
        self_category = "%s_category" % lights[l] 
        cache = cmds.getAttr( category )
        if self_category not in cache:
            cache = cache + "," + self_category
        cmds.setAttr( category, cache, type="string" ) 
        for s in range( 0, len( shapes )):
            stype = cmds.nodeType( shapes[s] )
            if stype == "transform":
                attribute = "%s.rman__torattr___transformBeginScript" % ( shapes[s] )
                if not cmds.attributeQuery( "rman__torattr___transformBeginScript", n=shapes[s], exists=True ):
                    cmds.addAttr( shapes[s], longName="rman__torattr___transformBeginScript", dataType="string" )
            elif stype == "mesh":
                attribute = "%s.rman__torattr___preShapeScript" % ( shapes[s] )
                if not cmds.attributeQuery( "rman__torattr___preShapeScript", n=shapes[s], exists=True ):
                    cmds.addAttr( shapes[s], longName="rman__torattr___preShapeScript", dataType="string" )
            user_mel = cmds.getAttr( attribute )
            user_buffer = user_mel.split( ";" )
            user_category = ""
            for i in range( 0, len( user_buffer )): 
                if re.findall( shablon, user_buffer[i] ):
                    user_category = user_buffer[i]
                    user_buffer.pop( i )
                    break
            user_buffer = [ user_buffer[u] for u in range( 0, len( user_buffer )) if user_buffer[u] ]
            if user_category == "":
                user_category = shablon + "\"\""
            user_lights = user_category.split( " " )[-1]
            if remove is True:
                if self_category in user_lights:
                    user_lights = user_lights.replace( "&-%s" % self_category, "" )
            else:
                if self_category not in user_lights:
                    user_lights = "\"" + user_lights.split( "\"" )[-2] + "&-" + self_category + "\""
            user_buffer.append( shablon + user_lights )
            user_mel = ";".join( user_buffer )
            cmds.setAttr( attribute, user_mel, type="string" )
	
def setPreShapeMel( string ):
    nodes = cmds.ls( sl=True, dag=True, type="mesh" )
    for i in range( 0, len( nodes )):
        attribute = "%s.rman__torattr___preShapeScript" % ( nodes[i] )
        if not cmds.attributeQuery( "rman__torattr___preShapeScript", n=nodes[i], exists=True ):
            cmds.addAttr( nodes[i], longName="rman__torattr___preShapeScript", dataType="string" )
        cmds.setAttr( attribute, string, type="string" )
	
def createNewProxyName(source=''):
    '''
    source = source for create new proxy name
    '''
    fullName = ''
    directory = '/'.join(source.split('/')[0:-1])
    filename = source.split('/')[-1]
    if not re.findall('_[A-z, 0-9]*proxy', filename, re.IGNORECASE):
    	if re.findall('_', filename):
    	    cleanName = filename.split('_')[0]
    	    prefix = (filename.split('_', 1)[1])
    	    if re.findall('_', prefix):
    		prefix = prefix.split('_')[0]
    	    if re.findall('.', prefix):
    		prefix = prefix.split('.')[0]
    	    fullName = directory+ '/' + cleanName + '_' + prefix + 'Proxy.mb'
    	else:
    	    fullName = directory+ '/' + filename.split('.mb')[0] + '_proxy.mb'
        return fullName

def listReferences():
	#__________________________________________________________________________________________________________________________________________
	#List all loaded references.
    def listReferences_exec( m_current ):
        m_references_current = cmds.file( m_current, query=True, reference=True )
        if m_references_current:
            for i in range( 0, len( m_references_current )):
                if m_references_current[i] not in m_result:
                    m_result.append( m_references_current[i] )
                    listReferences_exec( m_references_current[i] )
    m_result = []
    m_references = cmds.file( query=True, reference=True )
    for i in range( 0, len( m_references )):
        listReferences_exec( m_references[i] )
        if m_references[i] not in m_result:
            m_result.append( m_references[i] )
    return m_result

def selectProxy():
    import re
    cmds.select( clear=True )
    m_result = []
    m_references = listReferences()
    for i in range( 0, len( m_references )):
        if re.findall( "proxy.ma$|proxy.mb$", m_references[i], re.IGNORECASE ):
            m_result.append( m_references[i] )
            if cmds.referenceQuery( m_references[i], isLoaded=True ):
                m_content = cmds.referenceQuery( m_references[i], nodes=True )
                if m_content:
                    cmds.select( m_content[0], add=True )
    return m_result
		
def connectProxyToReference(original='', proxy=''):
    '''
    original = original reference node
    proxy = path to proxy for connect to original reference
    '''
    mel.eval('proxyAdd "'+original+'" "'+proxy+'" "";')

def findProxy(path=''):
    '''
    Find proxy for original object if proxy object exists in root directory exists
    '''
    directory = '/'.join(path.split('/')[0:-1])+'/'
    originalName = (path.split('/')[-1]).split('.')[0]
    files = os.listdir(directory)
    if not re.findall('proxy', originalName, re.IGNORECASE):
        if re.findall('_[A-z, 0-9]+', originalName, re.IGNORECASE):
            files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and re.findall('proxy', files[i], re.IGNORECASE) and re.findall(originalName, files[i], re.IGNORECASE)]
        else:
            files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and re.findall('_proxy', files[i], re.IGNORECASE) and re.findall(originalName, files[i], re.IGNORECASE)]
    else:
        proxyPrefix = re.findall('proxy', originalName, re.IGNORECASE)[0]
        originalName = originalName.split(proxyPrefix)[0]
        if re.findall('_$',originalName):
            originalName = originalName.split('_')
            if len(originalName) > 2:
                originalName = '_'.join(originalName[0:2])
            else:
                originalName = originalName[0]
        files = [files[i] for i in range(0, len(files)) if re.findall('.ma$|.mb$', files[i]) and not re.findall('_proxy|proxy', files[i], re.IGNORECASE) and re.findall(originalName+'.', files[i], re.IGNORECASE)]
    if files:
        return directory+files[0]
    else:
        return files

def updateProxy(original='', proxy=''):
    '''
    this script  create proxy for selected object
    '''
    if re.findall('_[A-z, 0-9]proxy', original, re.IGNORECASE):
        proxy = proxy + '>>' + original
        original = proxy.split('>>')[0]
        proxy = proxy.split('>>')[1]
    #export to new file selected geometry
    arguments = original+' '+proxy
    result = initScriptBatch(BATCH_RUSH_ADD_PROXY, arguments, block=True)


def updateGpuProxyScene():
    '''
    '''
    #Get upper reference level
    references = referencedNodes(filename=False, nodes=True, onlyFirstLevel=True)
    #For each reference node get proxy and original reference
    for i in range(0, len(references)):
        proxy = getConnectedProxy(source=references[i], original=False)
        original = getConnectedProxy(source=references[i], original=True)
        #If proxy version exists, check proxy and original last update date
        if proxy and original:
            filenameProxy = cmds.referenceQuery(proxy, filename=True, withoutCopyNumber=True)
            originalName = cmds.referenceQuery(original, filename=True, withoutCopyNumber=True)
            #If proxy last updated before oringinal, make new proxy version
            if dateCheck(original=originalName, proxy=filenameProxy) is False:
                print 'Update connected proxy for: '+originalName+' to '+filenameProxy
                updateProxy(original=originalName, proxy=filenameProxy)#
        #Else proxy is not connected to reference
        else:
            #Check proxy file
            originalName = cmds.referenceQuery(references[i], filename=True, withoutCopyNumber=True)
            filenameProxy = findProxy(originalName)
            #If proxy file exists
            if filenameProxy:
                #Check date last updated proxy, and if proxy updated before original, update proxy and connect to reference
                if dateCheck(original=originalName, proxy=filenameProxy) is False:
                    print 'Update proxy for: '+originalName+' to '+filenameProxy
                    updateProxy(original=originalName, proxy=filenameProxy)#IN WORK
                    connectProxyToReference(original=references[i], proxy=filenameProxy)
                else:
                    #If proxy version actual, connect proxy to reference
                    print 'Connect proxy for: '+originalName+' to '+filenameProxy
                    connectProxyToReference(original=references[i], proxy=filenameProxy)
            else:
                #If proxy is not exists, create new proxy and connect to reference
                filenameProxy = createNewProxyName(source=originalName)
                print 'Create new proxy for: '+originalName+' in '+filenameProxy
                updateProxy(original=originalName, proxy=filenameProxy)#IN WORK
                connectProxyToReference(original=references[i], proxy=filenameProxy)

BATCH_RUSH_ADD_PROXY = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/rushAddProxy.py'

def transferTransformAttr():
    source = cmds.ls(sl=True)[0]; print source
    target = cmds.ls(sl=True)[1]; print target
    cmds.setAttr(target+'.tx', cmds.getAttr(source+'.tx')); print cmds.getAttr(source+'.tx')
    cmds.setAttr(target+'.ty', cmds.getAttr(source+'.ty')); print cmds.getAttr(source+'.ty')
    cmds.setAttr(target+'.tz', cmds.getAttr(source+'.tz')); print cmds.getAttr(source+'.tz')
    cmds.setAttr(target+'.rx', cmds.getAttr(source+'.rx')); print cmds.getAttr(source+'.rx')
    cmds.setAttr(target+'.ry', cmds.getAttr(source+'.ry')); print cmds.getAttr(source+'.ry')
    cmds.setAttr(target+'.rz', cmds.getAttr(source+'.rz')); print cmds.getAttr(source+'.rz')
    cmds.setAttr(target+'.sx', cmds.getAttr(source+'.sx')); print cmds.getAttr(source+'.sx')
    cmds.setAttr(target+'.sy', cmds.getAttr(source+'.sy')); print cmds.getAttr(source+'.sy')
    cmds.setAttr(target+'.sz', cmds.getAttr(source+'.sz')); print cmds.getAttr(source+'.sz')

def copyPasteTransformAttributes(directory='', save=False, load=False):
    '''
    This script save and load to text file transform attributes
    path = path to txt file
    save = if True, save attributes to path
    load = if True, load attributes from path to target object
    '''
    import maya.cmds as cmds
    def writeFile(path='', info=''):
        file = open(path,"w")
        file.write(info)
        file.close()
    if directory == '' and load is False:
        directory = '/'.join(cmds.fileDialog2(caption='please select saved attributes', dialogStyle=1, fm=3)[0].split('\\'))+'/'
        print directory
    if save is False and load is False or save is True and load is True:
        cmds.error('Please specify one flag, load or save')
    transformNode = cmds.ls(sl=True, type='transform')
    if save is True:
        for i in range(0, len(transformNode)):
            tAttr = cmds.xform(transformNode[i], query=True, worldSpace=True, translation=True)
            tAttr = str(tAttr[0])+', '+str(tAttr[1])+', '+str(tAttr[2])
            rAttr = cmds.xform(transformNode[i], query=True, worldSpace=True, rotation=True)
            rAttr = str(rAttr[0])+', '+str(rAttr[1])+', '+str(rAttr[2])
            sAttr = cmds.xform(transformNode[i], query=True, worldSpace=True, scale=True)
            sAttr = str(sAttr[0])+', '+str(sAttr[1])+', '+str(sAttr[2])
            saveInfo = tAttr+'|'+rAttr+'|'+sAttr
            savePath = directory+'_y_'.join(('_x_'.join(transformNode[i].split(':'))).split('|'))+'.attr'
            print saveInfo, savePath
            writeFile(path=savePath, info=saveInfo)
    elif load is True:
        info = []
        files = cmds.fileDialog2(caption='please select saved attributes', fileFilter="Attribute files (*.attr)", dialogStyle=1, dir=directory, fm=4)
        for i in range(0, len(files)):
            file = open(files[i])
            info.append(file.read())
        for i in range(0, len(info)):
            temp = info[i].split('|')
            tempT = temp[0].split(', ')
            tempR = temp[1].split(', ')
            tempS = temp[2].split(', ')
            if i <= len(transformNode):
                cmds.setAttr(transformNode[i]+'.translate', float(tempT[0]), float(tempT[1]), float(tempT[2]))
                cmds.setAttr(transformNode[i]+'.rotate', float(tempR[0]), float(tempR[1]), float(tempR[2]))
                cmds.setAttr(transformNode[i]+'.scale', float(tempS[0]), float(tempS[1]), float(tempS[2]))

#requies:
import re
import maya.cmds as cmds
import maya.mel as mel
import os
import shutil

def sceneCamerasQuery(shapes=False, user='', reference='', animated=''):
    '''
    shapes = if True, return cameras shapes
    user = if True return onlu user defined cameras
    reference = return referenced or non referenced cameras
    animated = return animated or static cameras
    Example: listAllCameras()
    '''
    #list all cameras
    cameraArray = shapes is True and cmds.ls(cameras=True) or cmds.listCameras()
    #if user flag active, list all user defined or startup cameras
    if user is True:
            cameraArray = filter(lambda x: not cmds.camera(x, query=True, startupCamera=True), cameraArray)
    elif user is False:
            cameraArray = filter(lambda x: not cmds.camera(x, query=True, startupCamera=True) is False, cameraArray)
    #if reference flag active, list all referenced or non referenced cameras
    if reference is True:
        cameraArray = filter(lambda x: cmds.referenceQuery(x, isNodeReferenced=True), cameraArray)
    elif reference is False:
        cameraArray = filter(lambda x: not cmds.referenceQuery(x, isNodeReferenced=True), cameraArray)
    #if animated flag active, list all animated or static cameras
    if animated != '':
        def checkConnections(y):
            connections = cmds.listConnections(y) and cmds.listConnections(y) or False
            if connections is not False:
                connections = True in [True for i in range(0, len(connections)) if cmds.nodeType(connections[i]) in ("animCurveTA", "animCurveTU", "animCurveTL")] and True or False
            return connections
        if animated is True:
            cameraArray = filter(lambda x: checkConnections(x), cameraArray)
        elif animated is False:
            cameraArray = filter(lambda x: checkConnections(x) is False, cameraArray)
    #return cameras list
    if cameraArray:
        return cameraArray

def findCamera(word='', shapes=False):
    '''
    shapes = if True, return shapes
    word = any regular expression
    Example: findCamera('$fro[A-z]')
    '''
    if shapes is False:
        return filter(lambda x: re.findall(word, x), cmds.listCameras())
    else:
        transform = filter(lambda x: re.findall(word, x), cmds.listCameras())
        shape = [cmds.ls(transform[i], dag=True, leaf=True, cameras=True)[0] for i in range(0, len(transform))]
        return shape

def getCameraSequencerRange(cameraName):
    '''
    cameraName = camera transform name
    Example: getCameraSequencerRange('cameraShape1') return [(start frame, end frame, sequencer start frame)]
    '''
    cameraName = cmds.ls(cameraName, dag=True, leaf=True, type='camera')
    seqShot = cmds.listConnections(cameraName)
    seqShot = [seqShot[i] for i in range(0, len(seqShot)) if cmds.nodeType(seqShot[i]) == 'shot']
    return [(cmds.getAttr(seqShot[i]+'.startFrame'), cmds.getAttr(seqShot[i]+'.endFrame'), cmds.getAttr(seqShot[i]+'.sequenceStartFrame')) for i in range(0, len(seqShot))]
	
def lockCameraAttr(lock=True, default=True, name=''):
    '''
    lock and setup cameras attributes
    lock = if True, lock cameras attributes, else unlock
    default = if True, setup default attributes settings
    name = target transform camera
    Example: lockCameraAttr(lock=True, default=True, name='camera1')
    '''
    cameraTransform = name
    cameraShape = cmds.ls(cameraTransform, dag=True, leaf=True, cameras=True)[0]
    defaultSettings = ['".horizontalFilmAperture", 1.203', '".horizontalFilmAperture", 1.203', '".verticalFilmAperture", 0.504', '".lensSqueezeRatio", 1.000', '".focalLength", 75.000', '".cameraScale", 1.000', '".nearClipPlane", 0.1', '".farClipPlane", 100000.0', '".filmFit", 1']
    shapeAttr = ['.horizontalFilmAperture', '.horizontalFilmAperture', '.verticalFilmAperture', '.lensSqueezeRatio', '.focalLength', '.cameraScale', '.nearClipPlane', '.farClipPlane', '.filmFit']
    transformAttr = ['.scale', '.scaleX', '.scaleY', '.scaleZ', '.translate', '.translateX', '.translateY', '.translateZ', '.rotate', '.rotateX', '.rotateY', '.rotateZ']
    if default is True:
        for i in range(0, len(shapeAttr)):
            cmds.setAttr(cameraShape+shapeAttr[i], lock=False)
        for i in range(0, len(defaultSettings)):
            exec('cmds.setAttr("'+cameraShape+'"'+defaultSettings[i]+')')
    if lock is True:
        for i in range(0, len(shapeAttr)):
            cmds.setAttr(cameraShape+shapeAttr[i], lock=True)
        for i in range(0, len(transformAttr)):
            cmds.setAttr(cameraTransform+transformAttr[i], lock=True)
    elif lock is False:
        for i in range(0, len(shapeAttr)):
            cmds.setAttr(cameraShape+shapeAttr[i], lock=False)
        for i in range(0, len(transformAttr)):
            cmds.setAttr(cameraTransform+transformAttr[i], lock=False)
    return True

def nearClipPlaneExpression( create=False ):
	m_cams = cmds.ls( sl=True, dag=True, type=["camera", "stereoRigCamera"], long=True )
	for i in range( 0, len( m_cams )):
		m_options = cmds.renderManip( m_cams[i], query=True, cam=True )
		m_connections = cmds.listConnections( "%s.nearClipPlane" % m_cams[i] )
		if m_connections:
			for n in range( 0, len( m_connections )):
				cmds.delete( m_connections[n] )
		cmds.renderManip( m_cams[i], edit=True, cam=[ m_options[0], m_options[1], m_options[2], False, m_options[4] ] )
		cmds.setAttr( "%s.nearClipPlane" % m_cams[i], 0.1 )
		if create is True:
			cmds.expression( s="{0}.nearClipPlane=30*({0}.focalLength/50)*.34".format( m_cams[i] ), o=m_cams[i], ae=1, uc="all")
			cmds.renderManip( m_cams[i], edit=True, cam=[ m_options[0], m_options[1], m_options[2], True, m_options[4] ] )

def getCameraByFilename():
    '''
    get camera name by filename
    '''
    cameras = cmds.listCameras()
    name = cmds.file(query=True, sceneName=True)
    name = (name.split('/')[-1]).split('.')[0]
    if '_' in name and '_dop' not in name:
        name = name.split('_')[0]
    elif '_dop' in name:
		name = (name.split('_dop')[0])+'_dop'
    cameras = [cameras[i] for i in range(0, len(cameras)) if re.findall('^'+name, (cameras[i]).split(':')[-1])]
    if cameras:
        return cameras[0]
    else:
        if cmds.ls('cameras_grp'):
            cameras = []
            contain = cmds.ls('cameras_grp', dag=True)[1:]
            if contain:
                [cameras.append(contain[i]) for i in range(0, len(contain[1:])) if cmds.ls(contain[i], dag=True, leaf=True, type='camera')]
            if cameras:
                return cameras[0]
        else:
            return cmds.listCameras(perspective=True)[0]

def getClearSceneName():
    name = cmds.file(query=True, sceneName=True)
    name = ((name.split(".")[0]).split('/')[-1]).split('_')[0]
    if name:
        return name
    else:
        return 'untitled' 			
			
def registerChanges(name, read='', readAll='', clear=''):
    '''
    name = camera transform
    read = if True, return last modified time
    readAll = if True, return all history
    clear = if True, delete attributes history
    EXAMPLE: registerChanges(cmds.ls(sl=True)[0], read=True)
    '''
    #Get camera shape and transform name
    if cmds.objExists(name):
        nodes = [name, cmds.ls(name, dag=True, leaf=True, type='camera')[0]]
    if read is not True and readAll is not True and clear is not True:
        #Create attribute
        if cmds.attributeQuery('AttributeHistory', node=nodes[-1], exists=True) is False:
            cmds.addAttr(nodes[-1], longName='AttributeHistory', hidden=False, dataType='string')
        #Get old attibute value
        oldAttribute = cmds.getAttr(nodes[-1]+'.AttributeHistory') and cmds.getAttr(nodes[-1]+'.AttributeHistory') or ''
        if 'TIME' in oldAttribute:
            ver = oldAttribute.split('TIME')
            ver = str(len(ver))
        else:
            ver = '1'
        #Get new values
        newAttribute = '_xxx_|\nATTR'
        for l in range(0, len(nodes)):
            attributes = cmds.listAttr(nodes[l], read=True, keyable=True, hasData=True)
            if attributes:
                for i in range(0, len(attributes)):
                    #Check animation
                    connections = cmds.listConnections(nodes[l]+'.'+attributes[i], source=True, destination=False)
                    if connections:
                        if 'animCurve' in  cmds.nodeType(connections[0]):
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, inTangentType=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, outTangentType=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, inAngle=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, outAngle=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, inWeight=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, ix=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, iy=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, outWeight=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, ox=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, oy=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, lock=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, weightLock=True))
                            newAttribute += '\n'+str(cmds.keyTangent(connections[0], query=True, weightedTangents=True))
                        attributesConnected = cmds.listAttr(connections[0], read=True, multi=True, write=True, settable=True, connectable=True, hasData=True)
                        if attributesConnected:
                            for j in range(0, len(attributesConnected)):
                                if not re.findall('output|input', attributesConnected[j], re.IGNORECASE):
                                    try:
                                        newAttribute += '\n'+attributesConnected[j] + ' ' + str(cmds.getAttr(connections[0]+'.'+attributesConnected[j]))
                                    except:
                                        print "failed to get value from attribute"
                    else:
                        attrTemp = str(cmds.getAttr(nodes[l]+'.'+attributes[i], silent=True))
                        newAttribute += '\n'+attributes[i] + ' ' +attrTemp
        if newAttribute.split('_xxx_')[-1] not in oldAttribute.split('_xxx_')[-1]:
            newAttribute += '\nTIME' + cmds.date(format='YYYY-MM-DD hh:mm') + ' version(' + str(ver) + ')'# + ' '+os.getenv('USERNAME')
            oldAttribute += newAttribute
            cmds.setAttr(nodes[-1]+'.AttributeHistory', oldAttribute, type='string')
    elif read is True and readAll is not True and clear is not True:
        if cmds.attributeQuery('AttributeHistory', node=nodes[-1], exists=True):
            attribute = cmds.getAttr(nodes[-1]+'.AttributeHistory') and cmds.getAttr(nodes[-1]+'.AttributeHistory') or ''
            attribute = attribute.split('TIME')[-1]
            return attribute
        else:
            return 'no info.'
    elif readAll is True and read is not True and clear is not True:
        if cmds.attributeQuery('AttributeHistory', node=nodes[-1], exists=True):
            attribute = cmds.getAttr(nodes[-1]+'.AttributeHistory') and cmds.getAttr(nodes[-1]+'.AttributeHistory') or ''
            return attribute
        else:
            return 'No history saved.'
    elif clear is True and read is not True and readAll is not True:
        cmds.deleteAttr(nodes[-1]+'.AttributeHistory')
        return 'Attribute is deleted'

def createAvi(customPath=False):
	'''
	Run playblast with predefined options
	'''
	changedVersion = ''
	saveToReady = False
	saveToRoot = False
	def getCurrentTime(*args):
		startTime = cmds.playbackOptions(query=True, minTime=True)
		endTime = cmds.playbackOptions(query=True, maxTime=True)
		frameCount = endTime - startTime + 1
		frameCount = str(int(frameCount))
		currentFrame = str(int(cmds.currentTime(query=True)+1 - startTime))
		result = ('0'*(len(frameCount) - len(currentFrame))) + currentFrame + '  -  (' + frameCount + ')  -  ' + str(int(cmds.currentTime(query=True)))
		return result
	modelEd = cmds.playblast(activeEditor=True)
	oldCam = cmds.modelEditor(modelEd, query=True, camera=True)
	cam = cmds.optionMenu('cameraMenuItems', query=True, value=True)
	#setupCamera(cam=cam)
	settingModel = modelPanelSaveSettings(name=modelEd)
	if cmds.checkBox( "ImagePlanesForPlayblastEnable", query=True, value=True ) and "2013" in sys.executable:
		cmds.modelEditor(modelEd, edit=True, displayAppearance='smoothShaded', allObjects=True, grid=False, displayLights='default', selectionHiliteDisplay=False, imagePlane=True, nurbsCurves=False, planes=True, lights=False, cameras=True, controlVertices=False, hulls=False, joints=False, ikHandles=False, deformers=False, dynamics=False, fluids=False, hairSystems=False, follicles=False, nRigids=False, dynamicConstraints=False, locators=False, manipulators=False, dimensions=False, handles=False, pivots=False, motionTrails=False, wireframeOnShaded=False, camera=cam, activeView=True)
	else:
		cmds.modelEditor(modelEd, edit=True, displayAppearance='smoothShaded', allObjects=True, grid=False, displayLights='default', selectionHiliteDisplay=False, nurbsCurves=False, planes=False, lights=False, cameras=False, controlVertices=False, hulls=False, joints=False, ikHandles=False, deformers=False, dynamics=False, fluids=False, hairSystems=False, follicles=False, nRigids=False, dynamicConstraints=False, locators=False, manipulators=False, dimensions=False, handles=False, pivots=False, motionTrails=False, wireframeOnShaded=False, camera=cam, activeView=True)
	codec='PVMJPG40'
	if customPath == False:
		if cmds.referenceQuery(cam, isNodeReferenced=True) is False:
			registerChanges(name=cam)
	OSTYPE = sys.platform
	if OSTYPE == 'win32':
		OSTYPE = '//server-3d/'
	else:
		OSTYPE = '/Server-3d/Project'
	if customPath is False:
		sceneName = cmds.textFieldGrp('sceneNamePlayblast', query=True, text=True)
		sceneName = sceneName != "" and sceneName or getClearSceneName()
		if re.findall('ep[0-9]+sc[0-9]+', getClearSceneName()):
			pathPlayblast = OSTYPE+'Project/UrfinJuse/Playblast/'+getClearSceneName().split('sc')[0]+'/Work/'+sceneName+'.avi'
		else:
			pathPlayblast = OSTYPE+'Project/UrfinJuse/Playblast/'+getClearSceneName()+'/Work/'+sceneName+'.avi'
	elif customPath is True:
		pathPlayblast = cmds.fileDialog2(caption='Accept', fileFilter="Movie files (*.avi)", dialogStyle=1, dir=(OSTYPE+'Project/UrfinJuse/Playblast/'), fm=0)[0]
	if cmds.checkBoxGrp('readyCheckbox', query=True, exists=True):
		saveToReady = cmds.checkBoxGrp('readyCheckbox', query=True, v1=True)
	if cmds.checkBoxGrp('rootCheckbox', query=True, exists=True):
		saveToRoot = cmds.checkBoxGrp('rootCheckbox', query=True, v1=True)
	cmds.grid(toggle=False)
	#createHUD('lastChanges')
	huds = cmds.headsUpDisplay(listHeadsUpDisplays=True)
	if huds:
		[cmds.headsUpDisplay(huds[i], remove=True) for i in range(0, len(huds))]
	colors = [cmds.displayColor('headsUpDisplayButtons', query=True), cmds.displayColor('headsUpDisplayLabels', query=True), cmds.displayColor('headsUpDisplayValues', query=True)]
	cmds.displayColor('headsUpDisplayButtons', 12)
	cmds.displayColor('headsUpDisplayLabels', 16)
	cmds.displayColor('headsUpDisplayValues', 16)
	if cmds.headsUpDisplay('hudCameraName', query=True, exists=True):
		cmds.headsUpDisplay('hudCameraName', remove=True)
	cmds.headsUpDisplay('hudCameraName', label=(cmds.textFieldGrp('sceneNamePlayblast', query=True, text=True)), section=5, block=0, ba='left', dw=50, labelFontSize='large', dataFontSize='large', allowOverlap=True, visible=True)
	if cmds.headsUpDisplay('hudCameraHistory', query=True, exists=True):
		cmds.headsUpDisplay('hudCameraHistory', remove=True)
	cmds.headsUpDisplay('hudCameraHistory', label=(str(registerChanges(name=cam, read=True))), section=9, block=0, ba='left', dw=50, labelFontSize='large', dataFontSize='large', allowOverlap=True, visible=True)
	if cmds.headsUpDisplay('hudCurrentFrame', query=True, exists=True):
		cmds.headsUpDisplay('hudCurrentFrame', remove=True)
	cmds.headsUpDisplay('hudCurrentFrame', section=7, block=0, ba='left', dw=50, labelFontSize='large', dataFontSize='large', command=getCurrentTime, attachToRefresh=True, allowOverlap=True, visible=True)
	if cmds.checkBoxGrp('SaveNewVersionCheckbox', query=True, v1=True) is True:
		cmds.hudButton('iconRoundButton', s=4, b=1, vis=1, l='', blockSize="small", bw=20, bsh='roundRectangle')
	if not cmds.checkBoxGrp('finalPlayblastCheckbox', q=True, v1=True):
		if cmds.headsUpDisplay('hudFinalPlayblast', query=True, exists=True):
			cmds.headsUpDisplay('hudFinalPlayblast', remove=True)
		cmds.hudButton('iconRoundButton', s=0, b=1, vis=1, l='', blockSize="small", bw=20, bsh='rectangle')
	mel.eval('camera -e -displayFilmGate off -displayResolution off -overscan 1.0 '+cam+';')
	def renderPlayblastFromView(pathToFile=""):
		selected = cmds.ls(sl=True)
		cmds.select(cl=True)
		#Time settings
		time = [cmds.playbackOptions(query=True, minTime=True), cmds.playbackOptions(query=True, maxTime=True)]
		#Get resolution.
		if cmds.checkBox( "customResolutonForPlayblastEnable", query=True, value=True ):
			res_x = cmds.intFieldGrp( "customResolutonForPlayblast", query=True, value1=True )
			res_y = cmds.intFieldGrp( "customResolutonForPlayblast", query=True, value2=True )
		else:
			res_x = 2048
			res_y = 858
		#Create playblast
		m_soundOptions = cmds.optionMenu('soundMenuItems', q=True, v=True)
		if cmds.checkBox( "ImagePlanesForPlayblastEnable", query=True, value=True ) and "2013" in sys.executable:
			cmds.modelEditor( modelEd, edit=True, planes=True, imagePlane=True, cameras=True )
		if m_soundOptions == "NO SOUND":
			cmds.playblast(filename=pathToFile, format=pathToFile.split('.')[-1], forceOverwrite=True, startTime=time[0], endTime=time[1], clearCache=1, viewer=cmds.checkBoxGrp('viewPlayblastCheckbox', q=True, v1=True), showOrnaments=1, offScreen=True, framePadding=4, percent=100, compression=codec, quality=100, width=res_x, height=res_y, widthHeight=[res_x, res_y])
		else:
			cmds.playblast(filename=pathToFile, format=pathToFile.split('.')[-1], forceOverwrite=True, startTime=time[0], endTime=time[1], sound=( m_soundOptions and m_soundOptions or "" ), clearCache=1, viewer=cmds.checkBoxGrp('viewPlayblastCheckbox', q=True, v1=True), showOrnaments=1, offScreen=True, framePadding=4, percent=100, compression=codec, quality=100, width=res_x, height=res_y, widthHeight=[res_x, res_y])
		print "playblast", pathToFile
		return selected
	selected = renderPlayblastFromView(pathToFile=pathPlayblast)
	versionL = ""
	if customPath is False: 
		if saveToReady is True:
			if not os.path.isdir('/'.join(pathPlayblast.split('/')[0:-1])+'/ready/'):
				os.makedirs('/'.join(pathPlayblast.split('/')[0:-1])+'/ready/')
			shutil.copyfile(pathPlayblast, ('/'.join(pathPlayblast.split('/')[0:-1])+'/ready/'+pathPlayblast.split('/')[-1]))
		if saveToRoot is True:
			m_dir = '/'.join(pathPlayblast.split('/')[0:-2])+'/'+pathPlayblast.split('/')[-1]
			m_rootFile = m_dir + pathPlayblast.split( "/" )[-1]
			if os.path.isfile( m_rootFile ):
				os.remove( m_rootFile )
			shutil.copyfile( pathPlayblast, m_dir )
		versionL = fileVersionControl(directory='/'.join(pathPlayblast.split('/')[0:-1]), filename=pathPlayblast.split('/')[-1])
		print versionL
	cmds.grid(toggle=True)
	huds = cmds.headsUpDisplay(listHeadsUpDisplays=True)
	[cmds.headsUpDisplay(huds[i], remove=True) for i in range(0, len(huds))]
	cmds.modelEditor(modelEd, edit=True, camera=oldCam)
	cmds.modelEditor(modelEd, edit=True, displayAppearance='smoothShaded', allObjects=True, grid=True, displayLights='default', rendererName='base_OpenGL_Renderer', selectionHiliteDisplay=True, nurbsCurves=True, planes=True, lights=True, cameras=True, controlVertices=True, hulls=True, joints=True, ikHandles=True, deformers=True, dynamics=True, fluids=True, hairSystems=True, follicles=True, nRigids=True, dynamicConstraints=True, locators=True, manipulators=True, dimensions=True, handles=True, pivots=True, activeView=True)
	if selected:
		cmds.select(selected)
	modelPanelSaveSettings(name=modelEd, restore=settingModel)
	cmds.displayColor('headsUpDisplayButtons', colors[0])
	cmds.displayColor('headsUpDisplayLabels', colors[1])
	cmds.displayColor('headsUpDisplayValues', colors[2])
	mel.eval(restoreHeadsUpDisplays)
	if cmds.checkBoxGrp('finalPlayblastCheckbox', q=True, v1=True) is True:
		ml_audio = (cmds.optionMenu('soundMenuItems', q=True, v=True) and cmds.optionMenu('soundMenuItems', q=True, v=True) or '')
		if ml_audio and cmds.objExists( ml_audio ):
			ml_sound = cmds.sound( ml_audio, query=True, file=True)
			ml_server = sys.platform == "win32" and "//Server-3d/Project" or "/Server-3d/Project"
			scenePathName = cmds.file( query=True, sceneName=True )
			episode = re.findall( "(ep[0-9]+)sc[0-9]+", scenePathName )
			sceneNumber = re.findall( "ep[0-9]+(sc[0-9]+)", scenePathName )
			dopNumber = re.findall( "ep[0-9]+sc[0-9]+(dop[0-9]+|dop)", scenePathName, re.IGNORECASE )
			if episode and sceneNumber and versionL != "":
				soundPath = ml_server + "/UrfinJuse/sound3d/soundReady/" + episode[-1] + "/"
				soundName = episode[-1] + sceneNumber[-1]
				if dopNumber:
					soundName = soundName + dopNumber[-1]
				soundPathWork = soundPath + "old/"
				if not os.path.isdir( soundPath ):
					os.makedirs( soundPath )
				if not os.path.isdir( soundPathWork ):
					os.makedirs( soundPathWork )
				soundFullPath = soundPath + soundName
				if os.path.isfile( soundFullPath ):
					os.remove( soundFullPath )
				versions = glob.glob( soundPathWork + soundName + "_v*.wav" )
				if not versions:
					lastVersionPath = soundPathWork + soundName + "_v001.wav"
				else:
					lastExisting = max( versions, key=getVersionNumber )
					lastExistingNumber = getVersionNumber( lastExisting ) + 1
					lastExistingNumber = str( lastExistingNumber )
					lastVersionPath = soundPathWork + soundName + "_v" + ( "0" * ( 3-len( lastExistingNumber )) + lastExistingNumber ) + ".wav"
				if os.path.isfile( versionL ):
					print "export sound."
					mg_exportSound( input=versionL, output=soundFullPath + ".wav", bitrate=1536, codec='pcm_s16le', format='wav', executable='' )
					print soundFullPath
					if os.path.isfile( soundFullPath + ".wav" ):
						print lastVersionPath
						shutil.copy( soundFullPath + ".wav", lastVersionPath )
				else:
					print "File not founded."
			else:
				print "Current scene is not valid scene."
		else:
			print "Sound not found."

def getVersionNumber( argument ):
    result = re.findall( "_v([0-9]+)", argument )
    if result:
        return int( result[-1] )
    return 0
			
def finalVersionActivated():
	if cmds.checkBoxGrp('finalPlayblastCheckbox', q=True, v1=True):
		cmds.checkBoxGrp('rootCheckbox', edit=True, v1=True)
			
def fileVersionControl(directory='', filename=''):
    '''
    This procedure check target file and if file exists, move old file to work folder with version
    '''
    fileFormat = '.'+filename.split('.')[-1]
    filename = filename.split('.')[0]
    #create work directory, if not exists
    if not re.findall('work', directory, re.IGNORECASE) and not os.path.isdir(directory+'/work/'):
        copyToWork = True
        os.makedirs(directory+'/work/')
        newDirectory = directory+'/work/'
    else:
        copyToWork = False
        newDirectory = directory
    #check last file version
    def convertToVersion(var):
        if len(str(var)) == 1:
            return '00'+str(var)
        elif len(str(var)) == 2:
            return '0'+str(var)
        else:
            return str(var)
    if os.path.isfile(directory+'/'+filename+fileFormat):
        if not re.findall('work', directory, re.IGNORECASE):
            files = os.listdir(directory+'/work/')
        else:
            files = os.listdir(directory)
        if files:
            version = [re.findall('_v[0-9][0-9][0-9]', files[i])[0] for i in range(0, len(files)) if fileFormat in files[i] and re.findall('_v[0-9][0-9][0-9]', files[i]) and filename in files[i]]
            if version:
                version = [int((version[i].split('_v')[-1]).split('.')[0]) for i in range(0, len(version))]
                version = '_v' + convertToVersion(sorted(version)[-1]+1)
            else:
                version = '_v001'
        else:
            version = '_v001'
        #move files to work directory
        source = directory+'/'+filename+fileFormat
        destination = newDirectory+'/'+filename+version+getDopName()+fileFormat
        if copyToWork is True:
            shutil.copyfile(source, destination)
        else:
            os.rename(source, destination)
        return destination

def getDopName():
    if cmds.textFieldGrp('dopNamePlayblast', query=True, exists=True):
        textDop = cmds.textFieldGrp('dopNamePlayblast', query=True, text=True)
        if textDop:
            if re.findall('[0-9,A-z]', textDop, re.IGNORECASE):
                return '_'+''.join(textDop.split(' '))
            else:
                return ''
        else:
            return ''
    else:
        return ''

def setupCamera(cam=''):
    '''
    setup camera
    '''
    #setup plugins
    cmds.undoInfo(state=1)
    try:
        if(cmds.pluginInfo("RenderMan_for_Maya",query=True,loaded=True) is not True):
            cmds.loadPlugin("RenderMan_for_Maya")
    except:
        print 'Failed to load Renderman'
    cmds.pluginInfo("C:/Program Files/Pixar/RenderManStudio-4.0-maya2013/plug-ins/RenderMan_for_Maya.mll", edit=True, autoload=True)
    #setup render setting
    commands=['"defaultRenderGlobals.currentRenderer" -type "string" "renderMan"','"defaultResolution.width" 2048','"defaultResolution.height" 858','"defaultRenderGlobals.animation" 1','"defaultRenderGlobals.pff" 1','"defaultRenderGlobals.peie" 1','"defaultRenderGlobals.animationRange" 0','"defaultRenderGlobals.extensionPadding" 4','"defaultResolution.lockDeviceAspectRatio" 0','"defaultRenderGlobals.imageFormat" 3','"defaultResolution.deviceAspectRatio" 2.387','"defaultResolution.pixelAspect" 1','-l false "defaultRenderGlobals.startFrame"','"defaultRenderGlobals.startFrame" `playbackOptions -q -ast`','-l false "defaultRenderGlobals.endFrame"','"defaultRenderGlobals.endFrame" `playbackOptions -q -aet`']
    try:
        [mel.eval("setAttr "+commands[i]) for i in range(0,(len(commands)))]
    except:
        print 'locked attributes'
    #setup camera
    transform = cam
    shape = cmds.ls(transform, dag=True, leaf=True, type='camera')[0]
    commandsCamShape = ['"'+shape+'.horizontalFilmAperture" -lock 1;', '"'+shape+'.verticalFilmAperture" -lock 1;', '"'+shape+'.lensSqueezeRatio" -lock 1 1.000;', '"'+shape+'.focalLength" -lock 1;', '"'+shape+'.cameraScale" -lock 1 1.000;', '"'+shape+'.nearClipPlane" -lock 1 0.1;', '"'+shape+'.farClipPlane" -lock 1 10000.0;', '"'+shape+'.filmFit" 1;', '"'+shape+'.displayFilmGate" 0;', '"'+shape+'.overscan" 1.300;', '"'+shape+'.displayResolution" 0;', '"'+shape+'.displayGateMaskColor" -type double3 0 0 0;', '"'+shape+'.displayGateMaskOpacity" 1;', '"'+shape+'.centerOfInterest"  -lock 1;', '"'+shape+'.orthographicWidth"  -lock 1;', '"'+shape+'.displayResolution" 0;', '"'+shape+'.displayFieldChart" 0;', '"'+shape+'.displaySafeAction" 0;', '"'+shape+'.displaySafeTitle" 0;', '"'+shape+'.displayFilmPivot" 0;', '"'+shape+'.displayFilmOrigin" 0;', '"'+shape+'.displayGateMask" 1;', '"'+shape+'.image" 0;']
    commandsCamTransform = ['"'+transform+'.scale" -lock 1', '"'+transform+'.scale" -lock 1', '"'+transform+'.scaleX" -lock 1', '"'+transform+'.scaleY" -lock 1', '"'+transform+'.scaleZ" -lock 1', '"'+transform+'.translate" -lock 1', '"'+transform+'.translateX" -lock 1', '"'+transform+'.translateY" -lock 1', '"'+transform+'.translateZ" -lock 1', '"'+transform+'.rotate" -lock 1', '"'+transform+'.rotateZ" -lock 1', '"'+transform+'.rotateZ" -lock 1', '"'+transform+'.rotateZ" -lock 1']
    for i in range(0, len(commandsCamShape)):
        try:
            if cmds.getAttr((commandsCamShape[i].split(' ')[0]).split('"')[1], lock=True):
                mel.eval('setAttr -lock 0 '+commandsCamShape[i].split(' ')[0]+';')
                mel.eval('setAttr '+commandsCamShape[i])
            else:
                mel.eval('setAttr '+commandsCamShape[i])
        except:
            print 'locked attributes'
    for i in range(0, len(commandsCamTransform)):
        try:
            mel.eval('setAttr '+commandsCamTransform[i])
        except:
            cmds.warning(commandsCamTransform[i].split(' ')[0]+' is already locked.')
    cmds.lookThru(cam)

def sliderConnect(slider='', command=''):
    value = cmds.hudSlider(slider, q=True, v=True)
    mel.eval(command+" "+str(value)+";")
    return True

def getCurrentTime():
    return str(cmds.currentTime(query=True))

def registerAllCams():
    import maya.cmds as cmds
    cams = cmds.listCameras()
    cams = [cams[i] for i in range(0, len(cams)) if not cmds.camera(cams[i], query=True, startupCamera=True)]
    for i in range(0, len(cams)):
        registerChanges(cams[i])
        print '\ncamera: ', cams[i]
        print registerChanges(cams[i], read=True)

def modelPanelSaveSettings(name='', restore=''):
    '''
    Save and restore model panel settings
    '''
    attributes = ['displayAppearance', 'grid', 'displayLights', 'rendererName', 'selectionHiliteDisplay', 'nurbsCurves', 'planes', 'lights',
    'cameras', 'controlVertices', 'hulls', 'joints', 'ikHandles', 'deformers', 'dynamics', 'fluids', 'hairSystems', 'follicles', 'nRigids', 'dynamicConstraints',
    'locators', 'manipulators', 'dimensions', 'handles', 'pivots', 'camera', 'wireframeOnShaded', 'displayAppearance', 'polymeshes', 'subdivSurfaces']
    result = []
    if restore == '':
        for i in range(0, len(attributes)):
            temp = eval('cmds.modelEditor("'+name+'", query=True, '+attributes[i]+'=True)')
            if 'str' not in str(temp.__class__) and 'unicode' not in str(temp.__class__):
                result.append(temp)
            else:
                result.append('"'+temp+'"')
        return result
    else:
        for i in range(0, len(attributes)):
            result.append(eval('cmds.modelEditor("'+name+'", edit=True, '+attributes[i]+'='+str(restore[i])+')'))

def pathToNetwork(path):
    expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
    path = expression.sub("//Server-3d/Project",path)
    return path

def refreshReferenceBackupList():
    cmds.textScrollList('CUTool_ABC_ExIm_VersionList_references', edit=True, removeAll=True)
    if cmds.objExists('rlhPartition'):
        attributeContained = cmds.listAttr('rlhPartition')
        for i in range(0, len(attributeContained)):
            if re.findall('ver[0-9]+', attributeContained[i]):
                cmds.textScrollList('CUTool_ABC_ExIm_VersionList_references', edit=True, append=attributeContained[i])

def dialogWindow(label='', text='', command=''):
    result = cmds.confirmDialog(title=label, message=text, button=['yes', 'no'], defaultButton='Yes', cancelButton='No')
    if result == 'yes':
        exec(command)

def hairDisplayAsSwitch():
    '''
    mode - 
        0, is none
        1, is hairs
        2, is geometry
    '''
    hairs = cmds.ls(type='shaveHair')
    mode = cmds.getAttr((hairs[0] + '.displayAs'))    
    if mode == 1:
        mode = 0
    else:
        mode = 1    
    for i in range(0, len(hairs)):
        cmds.setAttr((hairs[i] + '.displayAs'), int(mode))

def convertSpotLightToRMSGeoAreaLight(target='', distance=''):
    if target == '':
        lights = cmds.ls(sl=True, dag=True, type='transform')
        lights = [lights[i] for i in range(0, len(lights)) if cmds.ls(lights[i], dag=True, leaf=True, type='spotLight')]
    else:
        lights = [target]    
    if lights:
        for i in range(0, len(lights)):
            #get old attributes
            light = lights[i]
            intensity = cmds.getAttr(light + '.intensity')
            decayRate = cmds.getAttr(light + '.decayRate')
            coneAngle = cmds.getAttr(light + '.coneAngle')
            penumbraAngle = cmds.getAttr(light + '.penumbraAngle')
            dropoff = cmds.getAttr(light + '.dropoff')
            emitDiffuse = cmds.getAttr(light + '.emitDiffuse')
            emitSpecular = cmds.getAttr(light + '.emitSpecular')
            color = cmds.getAttr(light + '.color')[0]; print color
            shadowColor = cmds.getAttr(light + '.shadowColor')[0]
            shadowUsed = cmds.getAttr(light + '.useDepthMapShadows')
            targetIntensity = getTargetIntensityByDistance(distance=distance, intensity=intensity, decayRate=decayRate)
            #create new lights
            rmsLight = cmds.duplicate(light)[0]
            cmds.delete(cmds.ls(rmsLight, dag=True, type='spotLight'))
            rmsLight = cmds.rename(rmsLight, (light+'Geo'))
            rmsLightShape = cmds.shadingNode('RMSGeoAreaLight', asLight=True, name=(light+'GeoShape'), parent=rmsLight)
            rmsLightShape = cmds.ls(rmsLightShape, dag=True, type='RMSGeoAreaLight')[0]
            cmds.setAttr((rmsLightShape + '.shape'), 'spot', type='string')
            cmds.setAttr(rmsLightShape + '.coneangle', coneAngle)
            cmds.setAttr(rmsLightShape + '.distributionAngle', coneAngle)
            cmds.setAttr(rmsLightShape + '.penumbraangle', penumbraAngle)
            cmds.setAttr(rmsLightShape + '.areaNormalize', 1)
            cmds.setAttr(rmsLightShape + '.penumbraexponent', dropoff)
            cmds.setAttr(rmsLightShape + '.temperature', -1)
            cmds.setAttr(rmsLightShape + '.lightcolor', color[0], color[1], color[2], type='double3')
            cmds.setAttr(rmsLightShape + '.diffAmount', emitDiffuse, emitDiffuse, emitDiffuse, type='double3')
            cmds.setAttr(rmsLightShape + '.specAmount', emitSpecular, emitSpecular, emitSpecular, type='double3')
            cmds.setAttr(rmsLightShape + '.shadowColor', shadowColor[0], shadowColor[1], shadowColor[2], type='double3')
            cmds.setAttr(rmsLightShape + '.intensity', getBaseIntensityByTargetIntensity(saveDistance=distance, intensity=targetIntensity, decayRate=4))
            toClean = cmds.ls(rmsLight, dag=True)
            toClean = [toClean[i] for i in range(0, len(toClean)) if toClean[i] not in cmds.ls(rmsLight, dag=True, type='RMSGeoAreaLight') and toClean[i] not in rmsLight]
            if toClean:
                cmds.delete(toClean)
            if shadowUsed == 1:
                cmds.setAttr(rmsLightShape + '.traceShadows', 0)
                shadowPass = mel.eval('rmanCreatePass AreaShadow')
                camera = cmds.camera(hfa=1, vfa=1, n=(light+'Cam'))[0]
                cmds.parent(camera, rmsLight)
                cmds.setAttr(camera+'.translate', 0, 0, 1)
                cmds.setAttr(camera+'.rotate', 0, 0, 0)
                cmds.connectAttr(cmds.ls(camera, dag=True, type='camera')[0]+'.message', shadowPass+'.rman__torattr___camera', f=True)
                cmds.connectAttr(shadowPass+'.message', rmsLightShape+'.shadowname', f=True)
            else:
                cmds.setAttr(rmsLightShape + '.traceShadows', 1)
            
def getTargetIntensityByDistance(distance='', intensity='', decayRate=''):
    distance = float(distance)
    intensity = float(intensity)
    decayRate = int(decayRate)
    if decayRate == 0:
        return intensity
    elif decayRate == 1:
        return (intensity/distance)
    elif decayRate == 2:
        return (intensity/(distance**2))  
    elif decayRate == 3:
        return (intensity/(distance**3))
        
def getBaseIntensityByTargetIntensity(saveDistance='', intensity='', decayRate=''):
    saveDistance = float(saveDistance)
    intensity = float(intensity)
    decayRate = int(decayRate)
    if decayRate == 0:
        return value
    elif decayRate == 1:
        return (intensity*saveDistance)
    elif decayRate == 2:
        return (intensity*(saveDistance**2))  
    elif decayRate == 3:
        return (intensity*(saveDistance**3))
    elif decayRate == 4:
        return math.log(intensity*(saveDistance**2), 2)
		
def createProxyByPath(original=''):
    def batchCreateProxy(path=''):
        script = OSTYPE+'/lib/setup/maya/maya_scripts_rfm4/CUTool_createProxyBatch.py'
        arguments = path+' True True 40000 True 75'
        initScriptBatch(script, arguments, block=True)
    #procedure
    pathToProxy = createNewProxyName(source=original)
    shutil.copyfile(original, pathToProxy)
    batchCreateProxy(path=pathToProxy)
    return pathToProxy

restoreHeadsUpDisplays = '''
{
	global string $gMainPane;
	if (`paneLayout -ex $gMainPane`) {
		paneLayout -e -manage true $gMainPane;
	}
	contextInfo -esc "escapeCurrentTool";
	source initHUDScripts.mel;
	headsUpDisplay -s 4
			   -b 0
			   -vis (`optionVar -q objectDetailsVisibility`)
			   -label  (uiRes("m_initAfter.kHUDTitleBackfaces"))
			   -lw 135
			   -dw 75
			   -c "objectDetailsBackfaces()"
			   -ev "SelectionChanged"
			   -nc "attributeChange"
			   HUDObjDetBackfaces;
	headsUpDisplay -s 4
			   -b 1
			   -vis (`optionVar -q objectDetailsVisibility`)
			   -label  (uiRes("m_initAfter.kHUDTitleSmoothness"))
			   -lw 135
			   -dw 75
			   -c "objectDetailsSmoothness()"
			   -ev "SelectionChanged"
			   -nc "attributeChange"
			   HUDObjDetSmoothness;
	headsUpDisplay -s 4
			   -b 2
			   -vis (`optionVar -q objectDetailsVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleInstance"))
			   -lw 135
			   -dw 75
			   -c "objectDetailsInstance()"
			   -ev "SelectionChanged"
			   -nc "instanceChange"
			   HUDObjDetInstance;
	headsUpDisplay -s 4
			   -b 3
			   -vis (`optionVar -q objectDetailsVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleDisplayLayer"))
			   -lw 135
			   -dw 75
			   -c "objectDetailsDisplayLayer()"
			   -ev "SelectionChanged"
			   -nc "connectionChange"
			   HUDObjDetDispLayer;
	headsUpDisplay -s 4
			   -b 4
			   -vis (`optionVar -q objectDetailsVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleDistanceFromCamera"))
			   -lw 135
			   -dw 75
			   -pre "distanceFromCamera"
			   HUDObjDetDistFromCam;
	headsUpDisplay -s 4
				-b 5
				-vis (`optionVar -q objectDetailsVisibility`)
				-label (uiRes("m_initAfter.kHUDTitleSelectedObjects"))
				-lw 135
				-dw 75
				-c "objectDetailsNumberOfSelectedObjects()"
				-ev "SelectionChanged"
				HUDObjDetNumSelObjs;
	headsUpDisplay -s 0
			   -b 0
			   -vis (`optionVar -q polyCountVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleVerts"))
			   -lw 50
			   -dw 65
			   -da "right"
			   -pre "polyVerts"
			   HUDPolyCountVerts;
	headsUpDisplay -s 0
			   -b 1
			   -vis (`optionVar -q polyCountVisibility`)
			    -label (uiRes("m_initAfter.kHUDTitleEdges"))
			   -lw 50
			   -dw 65
			   -da "right"
			   -pre "polyEdges"
			   HUDPolyCountEdges;
	headsUpDisplay -s 0
			   -b 2
			   -vis (`optionVar -q polyCountVisibility`)
			  -label (uiRes("m_initAfter.kHUDTitleFaces"))
			   -lw 50
			   -dw 65
			   -da "right"
			   -pre "polyFaces"
			   HUDPolyCountFaces;
	headsUpDisplay -s 0
			   -b 3
			   -vis (`optionVar -q polyCountVisibility`)
			    -label (uiRes("m_initAfter.kHUDTitleTris"))
			   -lw 50
			   -dw 65
			   -da "right"
			   -pre "polyTriangles"
			   HUDPolyCountTriangles;
	headsUpDisplay -s 0
			   -b 4
			   -vis (`optionVar -q polyCountVisibility`)
			    -label (uiRes("m_initAfter.kHUDTitleUVs"))
			   -lw 50
			   -dw 65
			   -da "right"
			   -pre "polyUVs"
			   HUDPolyCountUVs;
	headsUpDisplay -s 0
			   -b 5
			   -vis (`optionVar -q subdDetailsVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleSubdivCurrentLevel"))
			   -lw 135
			   -dw 30
				-c "subdDetailsCurrentLevel()"
			   -ev "SelectionChanged"
			   -nc "attributeChange"
			   HUDSubdLevel;
	headsUpDisplay -s 0
			   -b 6
			   -vis (`optionVar -q subdDetailsVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleSubdivMode"))
			   -lw 135
			   -dw 30
				-c "subdDetailsCurrentMode()"
			   -ev "SelectionChanged"
			   HUDSubdMode;
	headsUpDisplay -s 0
			   -b 7
			   -vis (`optionVar -q particleCountVisibility`)
			   -label (uiRes("m_initAfter.kHUDTitleParticleCount"))
			   -lw 50
			   -dw 130
			   -da "right"
				-c "getParticleCount()"
			   -atr
			   HUDParticleCount;
	headsUpDisplay -s 7
			   -b 0
			   -vis (`optionVar -q cameraNamesVisibility`)
			   -ao true
			   -ba center
			   -pre "cameraNames"
			   HUDCameraNames;
	headsUpDisplay -s 2
		   -b 1
		   -vis (`optionVar -q cameraNamesVisibility`)
		   -ba center
		   -label (uiRes("m_initAfter.kHUDTitleCameraName"))
		   -pre "renderQuality"
		   HUDHQCameraNames;
	string $titleIKBlend = (uiRes("m_initAfter.kHUDTitleIKBlend")) ;
	string $titleCurrentCharacter = (uiRes("m_initAfter.kHUDTitleCurrentCharacter")) ;
	string $titlePlaybackSpeed =  (uiRes("m_initAfter.kHUDTitlePlaybackSpeed")) ;
	string $titleFbikKeyType = (uiRes("m_initAfter.kHUDFbikKeyType")) ;
	string $titleHikKeyingMode = (uiRes("m_initAfter.kHUDHikKeyingMode")) ;
	string $titleCurrentFrame = (uiRes("m_initAfter.kHUDCurrentFrameLabel"));
	string $titleSceneTimecode = (uiRes("m_initAfter.kHUDSceneTimecodeLabel"));
	int $section = 9;
	int $lblWidth = 115;
	if(`about -ev`)
	{
		$section = 3;
		$lblWidth = 135;
	}
	headsUpDisplay -s $section
		   -b 0
		   -vis (`optionVar -q frameRateVisibility`)
		   -ba right
		   -dfs large
		   -da right
		   -dp 1
		   -pre "frameRate"
		   HUDFrameRate;
	headsUpDisplay
			-section			$section
			-block				1
			-blockSize			"small"
			-label				$titleCurrentFrame
			-labelWidth			$lblWidth
			-dataWidth			75
			-labelFontSize		"small"
			-dataFontSize		"small"
			-allowOverlap		true
			-blockAlignment		"center"
			-preset				"currentFrame"
			-vis (`optionVar -q currentFrameVisibility`)
		HUDCurrentFrame;
	headsUpDisplay -s $section
		   -b 2
		  -label $titleIKBlend
		   -dp 1
		   -dfs "small"
		   -lw $lblWidth
		   -dw 75
		   -c "animationDetailsIKFK()"
		   -ev "SelectionChanged"
		   -nc "attributeChange"
		   HUDIKSolverState;
	headsUpDisplay -s $section
		   -b 3
		   -label $titleCurrentCharacter
		   -dp 1
		   -dfs "small"
		   -lw $lblWidth
		   -dw 75
		   -c "animationDetailsCurrentCharacter()"
		   -ev "NewSceneOpened"
		   HUDCurrentCharacter;
	headsUpDisplay -s $section
		   -b 4
		   -label $titlePlaybackSpeed
		   -dp 1
		   -dfs "small"
		   -lw $lblWidth
		   -dw 75
		   -c "animationDetailsPlaybackSpeed()"
		   -ev "timeUnitChanged"
		   HUDPlaybackSpeed;
    headsUpDisplay -s $section
		   -b 5
		   -label $titleHikKeyingMode
		   -dp 1
		   -dfs "small"
		   -lw $lblWidth
		   -dw 75
		   -c "hikDetailsKeyingMode()"
		   -ev "SelectionChanged"
		   HUDHikKeyingMode;
    headsUpDisplay -s $section
		   -b 6
		   -label $titleFbikKeyType
		   -dp 1
		   -dfs "small"
		   -lw $lblWidth
		   -dw 75
		   -c "fbikDetailsKeyType()"
		   -ev "SelectionChanged"
		   HUDFbikKeyType;
	headsUpDisplay -section $section
			   -block 7
			   -vis (`optionVar -q selectDetailsVisibility`)
			   -lw $lblWidth
			   -preset "softSelect"
			   HUDSoftSelectState;
	headsUpDisplay -section $section
			   -block 8
			   -vis (`optionVar -q selectDetailsVisibility`)
			   -preset "reflection"
			   -lw $lblWidth
			   HUDReflectionState;
	string $titleCurrentContainer = (uiRes("m_initAfter.kHUDCurrentContainerLabel"));
	headsUpDisplay
			-section			$section
			-block				9
			-blockSize			"small"
			-label				$titleCurrentContainer
			-labelWidth			$lblWidth
			-labelFontSize		"small"
			-dataFontSize		"small"
		    -command			"getCurrentContainer"
			-event				"currentContainerChange"
			-vis (`optionVar -q currentContainerVisibility`)
		HUDCurrentContainer;
	setAnimationDetailsVisibility(`optionVar -q animationDetailsVisibility`);
	setFbikDetailsVisibility(`optionVar -q fbikDetailsVisibility`);
	setHikDetailsVisibility(`optionVar -q hikDetailsVisibility`);
	headsUpDisplay -section $section
			   -block 10
			   -vis (`optionVar -q focalLengthVisibility`)
			   -preset "focalLength"
			   -lw $lblWidth
			   HUDFocalLength;
	headsUpDisplay
			-section			$section
			-block				11
			-blockSize			"small"
			-label				$titleSceneTimecode
			-labelWidth			$lblWidth
			-dataWidth			75
			-labelFontSize		"small"
			-dataFontSize		"small"
			-allowOverlap		true
			-blockAlignment		"center"
			-preset				"sceneTimecode"
			-vis (`optionVar -q sceneTimecodeVisibility`)
		HUDSceneTimecode;
	headsUpDisplay -s 5
			   -b 0
			   -vis (`optionVar -q viewAxisVisibility`)
			   -pre "viewAxis"
			   HUDViewAxis;
    evalDeferred -lowestPriority "setupRendererSceneOpenedCallback";
	linearPrecision 3;
	commandEcho -filter {"setLastFocusedCommand", "buildScriptEditor", "handleScriptEditorAction", "verifyCommandPopupMenus"};
	source fileDialogFilterTypes;
}
global proc fileCmdCallback () {
	global string $gCurrentSacredTool;
	global string $gSelect;
	global string $gPreFileCmdCallbackTool;
	$gCurrentSacredTool = $gSelect;
	$gPreFileCmdCallbackTool = `currentCtx`;
	escapeCurrentTool;

	global int $gPreFileCmdCallbackPlayState;
	if (`exists play`) {
		$gPreFileCmdCallbackPlayState = `play -query -state`;
		if ( $gPreFileCmdCallbackPlayState ) {
			play -state off;
		}
	}
}
global proc fileCmdRestoreCallback () {
	global string $gPreFileCmdCallbackTool;
	global int $gPreFileCmdCallbackPlayState;
	if ( size($gPreFileCmdCallbackTool) )
	{
		setToolTo $gPreFileCmdCallbackTool;
	}
	if ( `exists play` && $gPreFileCmdCallbackPlayState )
	{
		play -state $gPreFileCmdCallbackPlayState;
	}
}
file -c "fileCmdCallback" "fileCmdRestoreCallback";
'''
def setProjection():
    '''
    This procedure connect projections to selected objects.
    '''
    #get projections
    projections = cmds.ls(sl=True, dag=True, type='place3dTexture')
    #get selected objects
    objects = cmds.ls(sl=True, dag=True, type='shape')
    objects = [objects[i] for i in range(0, len(objects)) if objects[i] not in projections]
    if not objects:
        cmds.error('Please select transform nodes to connect projections.')
    for i in range(0, len(objects)):
        if cmds.attributeQuery('usedProjection', node=objects[i], exists=True) is False:
            cmds.addAttr(objects[i], longName='usedProjection', dataType="string")
        if not projections:
            cmds.deleteAttr(objects[i]+'.usedProjection')
            continue
        connected = cmds.listConnections(objects[i]+'.usedProjection', plugs=True)
        if connected:
            cmds.disconnectAttr(connected[0], objects[i]+'.usedProjection')
        cmds.connectAttr(projections[0]+'.viewName', objects[i]+'.usedProjection')
        print '\tconnect', objects[i], 'and', projections[0]

def perFrameBatchRender(frames='', camera=''):
	'''
	frames - '1, 3, 5, 8-12, 25-34'
	cameras - 'persp'
	'''
	if not frames or not camera:
		cmds.error('please specify valid camera or frames.')
	if cmds.pluginInfo('RenderMan_for_Maya', query=True, l=True) is False:
		try:
			cmds.loadPlugin('RenderMan_for_Maya')
		except:
			cmds.error('Renderman plugin failed to load')
	frames = frames.split(',')
	framesArray = []
	for i in range(0, len(frames)):
		if not re.findall('-', frames[i]) and frames[i] not in framesArray:
			framesArray.append(int(frames[i]))
		else:
			temp = frames[i].split('-')
			temp = range(int(temp[0]), int(temp[-1])+1)
			for n in range(0, len(temp)):
				if temp[n] not in framesArray:
					framesArray.append(temp[n])
	#camera setup
	camera = cmds.ls(camera, dag=True, type='camera')[0]
	cams = cmds.ls(type='camera')
	[cmds.setAttr(cams[i]+'.renderable', 0) for i in range(0, len(cams))]
	cmds.serAttr(camera+'.renderable', 1)
	#per frame batch render
	if framesArray:
		for i in range(0, len(framesArray)):
			print 'render frame:', framesArray[i]
			cmds.setAttr('defaultRenderGlobals.startFrame', l=False)
			cmds.setAttr('defaultRenderGlobals.startFrame', framesArray[i])
			cmds.setAttr('defaultRenderGlobals.endFrame', l=False)
			cmds.setAttr('defaultRenderGlobals.endFrame', framesArray[i])
			cmds.setAttr('defaultRenderGlobals.byFrameStep', l=False)
			cmds.setAttr('defaultRenderGlobals.byFrameStep', 1)
			#setup
			cmds.optionVar('rmanAlfredCrews', sv="")
			cmds.optionVar('rmanAlfredDoneCmd', sv="")
			cmds.optionVar('rmanAlfredEnvKey', sv="rms-18.0-maya-2013, prman-18.0")
			cmds.optionVar('rmanAlfredEnvKeyInitialized', iv=1)
			cmds.optionVar('rmanAlfredErrorCmd', sv="")
			cmds.optionVar('rmanAlfredExtra', sv="")
			cmds.optionVar('rmanAlfredFramesPerServer', iv=100)
			cmds.optionVar('rmanAlfredMaxProcs', iv=12)
			cmds.optionVar('rmanAlfredMinProcs', iv=1)
			cmds.optionVar('rmanAlfredPaused', iv=0)
			cmds.optionVar('rmanAlfredPriority', iv=1500)
			cmds.optionVar('rmanAlfredRenderArgs', sv="")
			cmds.optionVar('rmanAlfredService', sv="")
			cmds.optionVar('rmanAlfredSpool', iv=1)
			cmds.optionVar('rmanAlfredSpoolStyle', sv="remote rib, remote render")
			cmds.optionVar('rmanAlfredTags', sv="")
			cmds.optionVar('rmanControlsViewAutoRefresh', iv=1)
			cmds.optionVar('rmanControlsViewType', iv=0)
			cmds.optionVar('rmanNumBatchThreads', iv=0)
			#launch
			mel.eval('renderManLaunchBatchRender')		
		
#______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
#IN FUTURE__________________________________________________________________________________________
#-SHABLON
#Save characters list from animatik to txt file
#Load characters list from txt file

#-ANIMATIK
#Check geometry is not referenced
#Replace not referenced geometry to referenced geometry from props with animation saved
#Export all geometry to template
#Check and clean animatik

#SOMETHING__________________________________________________________________________________________
#remake all

#Automatik setup all

#Automatik all with closed maya
#______________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________

#Save and export position
#Save list of loaded references and export list to scene for loaded exists references
#Restore references


'''
Scripts for batch maya
'''


#hhh = cmds.ls(sl=True)[0]
#cmds.polyReduce(hhh, percentage=50, replaceOriginal=True, keepQuadsWeight=0.5, compactness=1, triangulate=0, constructionHistory=False)





# loadReference('//Server-3d/Project/UrfinJuse/assets/props/PovareshkaUrfina/maya/povareshkaUrfina_proxy.mb')

# def loadReference(targetPath):
    # def getIndex(targetName, index=0):
        # if cmds.objExists(targetName+str(index)):
            # index += 1
            # getIndex(targetName, index)
        # else:
            # print index
            # return index
    # targetNamespace = (targetPath.split('/')[-1]).split('.')[0]
    # targetGrp = cmds.objExists(targetNamespace+'_Grp') is False and targetNamespace+'_Grp' or targetNamespace+'_Grp'+str(getIndex(targetNamespace+'_Grp'))
    # targetType = ('mb' in targetPath.split('.')[-1] and 'mayaBinary' or ('ma' in targetPath.split('.')[-1] and 'mayaAscii' or False))
    # #get index for reference group name
    # if targetType is not False:
        # cmds.file(targetPath, type=targetType, namespace=targetNamespace, reference=True, groupReference=True, groupName=targetGrp)
    # return targetGrp






	#REMOVE UNUSED LINKS
	# buffer_light=cmds.listRelatives(cmds.ls(long=True, type='transform')
				# if var=='removeUn':
                    # target_Attr=cmds.getAttr(target_obj[i]+'.rman__torattr___transformBeginScript')
					# buffer_attr=target_Attr.split('; ')
					# for attr_i in range(0,len(buffer_attr)):
						# if 'RiIlluminate' in buffer_attr[attr_i]:
							# target_check=buffer_attr[attr_i].split('"')[1]
							# if target_check not in target_light:
								# pass
							# else: list_attr=list_attr+buffer_attr[attr_i]+'; '
						# else: list_attr=list_attr+buffer_attr[attr_i]+'; '
					# cmds.setAttr((target_obj[i]+'.rman__torattr___transformBeginScript'),(list_attr), type='string')



def checkLocal():
    estVal = cmds.optionVar(q="localSave")
    if estVal:
        cmds.optionVar(iv=("localSave",0))
    else:
        cmds.optionVar(iv=("localSave",1))


def cacheChars():
    import re
    import os
    import glob
    import shutil


    OSTYPE = sys.platform
    if OSTYPE == "win32":
            OSTYPE="//Server-3d/Project"
    else:
            OSTYPE="/Server-3d/Project"

    slovarik=[]
    slovarikLocalPath=[]
    pathToAssets = glob.glob(OSTYPE+'/UrfinJuse/assets/chars/*/maya/*.m[ab]')
    for cP in pathToAssets:
        name=os.path.basename(cP)
        if len(name.split("_")) <= 2 and not re.match(".*_v[0-9]{1,5}[_|\.].*",name):
            slovarik.append(cP)

    for sl in slovarik:
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        slovarikLocalPath.append(expression.sub(os.environ['HOME']+"/Project",sl))

    for slp in range(0,len(slovarikLocalPath)):
        if not os.path.exists(os.path.dirname(slovarikLocalPath[slp])):
            os.makedirs(os.path.dirname(slovarikLocalPath[slp]))
        copyDa=0
        if not os.path.exists(slovarikLocalPath[slp]):
            copyDa=1
        elif os.path.getmtime(slovarik[slp]) > os.path.getmtime(slovarikLocalPath[slp]):
            copyDa=1
        if copyDa == 1:
            print("copy: " + slovarik[slp] + " to " + slovarikLocalPath[slp])
            shutil.copyfile(slovarik[slp], slovarikLocalPath[slp])
        #else:
            #print("check: " + slovarik[slp])


def cacheScene():
    import re
    import os
    import glob
    import shutil

    OSTYPE = sys.platform
    if OSTYPE == "win32":
            OSTYPE="//Server-3d/Project"
    else:
            OSTYPE="/Server-3d/Project"

    slovarik=[]
    slovarikLocalPath=[]
    lRef=cmds.ls(type="reference")
    for lr in lRef:
        pathRef=""
        try:
            if cmds.referenceQuery(lr,il=True):
                pathRef=cmds.referenceQuery(lr,f=True,wcn=True)
        except:
            pass
        if pathRef != "":
            expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
            path = expression.sub(OSTYPE,pathRef)
            if path not in slovarik:
                slovarik.append(path)
                #print path

    for sl in slovarik:
        expression = re.compile("^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)", re.IGNORECASE)
        slovarikLocalPath.append(expression.sub(os.environ['HOME']+"/Project",sl))

    for slp in range(0,len(slovarikLocalPath)):
        if not os.path.exists(os.path.dirname(slovarikLocalPath[slp])):
            os.makedirs(os.path.dirname(slovarikLocalPath[slp]))
        copyDa=0
        if not os.path.exists(slovarikLocalPath[slp]):
            copyDa=1
        elif os.path.getmtime(slovarik[slp]) > os.path.getmtime(slovarikLocalPath[slp]):
            copyDa=1
        if copyDa == 1:
            print("copy: " + slovarik[slp] + " to " + slovarikLocalPath[slp])
            shutil.copyfile(slovarik[slp], slovarikLocalPath[slp])


