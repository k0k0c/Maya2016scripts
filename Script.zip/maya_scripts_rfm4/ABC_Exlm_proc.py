import maya.cmds as cmds
import maya.mel as mel
import re
import os

#INTERFACE COMMUNICATIONS
#Get all items from characters list
def GetObjectsFromCharListAll():
    return mel.eval("$temp=`GetLongNameAllInList`")	
#Get selected items from characters list	
def GetObjectsFromCharListSelected():
	return mel.eval("$temp=`GetLongNameSelectedInList`")	
#Get selected items from outliner	
def GeSelectedInOutLinerObjects():
	return cmds.ls(sl=True,l=True)
#Get write visible checkbox statement 	
def GetStatementAlembicSceneWriteVisibility():
    return cmds.checkBoxGrp("ABC_check_visible_control", query=True, value1=True)==True
#Get ImportExport checkbox statement !!!
def GetStatementAlembicSceneExportThenImport():    
    return cmds.checkBoxGrp("ABC_check_Imp_Exp_control", query=True, value1=True)
#Get path to Tool
def ConvertAlembicSceneFolderForMaya():    
    result=FindAlembicSceneFolder()   
    result=result.replace("/", "\\")
    return result   
#Get path from tool settings	
def UpdateAlembicSceneFolderFromMaya():
    result=cmds.textField("ABC_Exlm_PathText", query=True, text=True)    
    result=result.replace("\\", "/")    
    return result  
#Get start frame from tool settings	
def UpdateAlembicSceneTimeFramesFromMayaStart():    
    result=cmds.intFieldGrp("ABC_StartFrame", query=True, value1=True)
    return result   
#Get end frame from tool settings	
def UpdateAlembicSceneTimeFramesFromMayaEnd():    
    result=cmds.intFieldGrp("ABC_EndFrame", query=True, value1=True)
    return result    
#Get list of all file in the used directory	
def GetFileListInUsedDirectory():
	os.chdir(UpdateAlembicSceneFolderFromMaya())
	result=[]
	for i in os.listdir("."):
		if i.endswith(".abc"):
			result.append(i)
	return result	
#Change reference version from rig to render and reverse
def ChangeReferenceToRenderVersion(reference_input):
	if cmds.referenceQuery(reference_input, isNodeReferenced=True):
		reference_path=cmds.referenceQuery(reference_input, filename=True,  withoutCopyNumber=True)
		reference_node=cmds.referenceQuery(reference_input, referenceNode=True)
		if re.findall('.[a-z][a-z]$',(cmds.referenceQuery(reference_input, filename=True, shortName=True, withoutCopyNumber=True))):
			reference_name=(cmds.referenceQuery(reference_input, filename=True, shortName=True, withoutCopyNumber=True))[0:-3]
			if re.findall('_render$', reference_name):
				temp=reference_name.replace("_render",'')
				print "\n\n\n",temp
				temp=reference_path.replace(reference_name,temp)
				print "\n\n\n",temp
				if os.path.exists(temp):
					mel.eval("file -loadReference " + '"' + reference_node + '"' + ' "' + temp + '"')
				else:
					cmds.error("File not found!!! -E1R")		
			else:
				temp=reference_path.replace(reference_name,(reference_name+"_render"))
				if os.path.exists(temp):
					mel.eval("file -loadReference " + '"' + reference_node + '"' + ' "' + temp + '"')
				else:
					cmds.error("File not found!!! -E2R")
		else:
			cmds.error("File not found!!! -E3R")
#Check plugin loaded
def LoadPluginCheck(name_input):
    result=0
    if cmds.pluginInfo(name_input, query=True, loaded=True):
        cmds.loadPlugin(name_input, quiet=True)
        result=1
    return result
#Rename
def Abc_cashe_rename(input):
    childrens=[]
    childrens=cmds.listRelatives(input, allDescendents=True, fullPath=True)
    if len(childrens)>0:
        for index in range(0,(len(childrens))):
            namesBuffer=childrens[index].split("|")
            cmds.rename(childrens[index], ("cashe_"+namesBuffer[-1]))           
#"|".join(namesBuffer[0:-2])
    
	
#EXPORT
#Find folder for ABC
def FindAlembicSceneFolder():
    sceneNameFilePath=cmds.file(query=True,sn=True).split("/")
    if len(cmds.file(query=True,sn=True,shn=True).split("."))>1:
        sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[-2]
    elif cmds.file(query=True,sn=True,shn=True)!="":
        sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[0]
    else:
        sceneNameFileName="untitled"
    indexSceneFolder=-2
    for sNFP in range (0, len(sceneNameFilePath)):
        m = re.search('^ep\d{2}sc\d{2}', sceneNameFilePath[sNFP],re.IGNORECASE)        
        if m is not None:
            indexSceneFolder=sNFP
            break
    pathFolderForCache = "/".join(sceneNameFilePath[0:indexSceneFolder+1])+"/cache/alembic/"+sceneNameFileName
    if sceneNameFileName=="untitled":
        pathFolderForCache="warning:\Please_Choose_Your_Folder"
    if sceneNameFileName!="untitled":   
        if not os.path.isdir(pathFolderForCache) and pathFolderForCache!="/cache/alembic/"+sceneNameFileName:
           os.makedirs(pathFolderForCache)

    return pathFolderForCache
#Export ABC execute proc        
def exportAlembic(Mode):
    objects,startFrame,endFrame = getObjectsForExport(Mode)
    exec_ExportAlembic(objects,[startFrame,endFrame]) 
#Export ABC source	
def exec_ExportAlembic(obgects, frameRanges):
    pathFolderForCache=UpdateAlembicSceneFolderFromMaya()
    if not os.path.isdir(pathFolderForCache):
		cmds.error("!!!INVALID PATH!!!")
    nameForAlembic="AbcExport"
    for lsS in range (0, len(obgects)):
        nameForAlembicTemp = obgects[lsS].replace(":","_x_")
        nameForAlembicTemp = nameForAlembicTemp.replace("|","_z_")
        if GetStatementAlembicSceneWriteVisibility()==True:
            nameForAlembic+=" -j \"-root "+obgects[lsS]+" -fr "+str(frameRanges[0][lsS])+" "+str(frameRanges[1][lsS])+" -noNormals -writeVisibility -renderableOnly -file "+pathFolderForCache+"/"+nameForAlembicTemp[:-4]+".abc\""
        if GetStatementAlembicSceneWriteVisibility()==False:
            nameForAlembic+=" -j \"-root "+obgects[lsS]+" -fr "+str(frameRanges[0][lsS])+" "+str(frameRanges[1][lsS])+" -noNormals -renderableOnly -file "+pathFolderForCache+"/"+nameForAlembicTemp[:-4]+".abc\""
    print("\nEXPORT TO ALEMBIC: \n"+nameForAlembic+"\n")
    mel.eval(nameForAlembic)
    for ob in obgects:
        pass
        cmds.delete(ob)
	if GetStatementAlembicSceneExportThenImport() is True:
		ChangeReferenceToRenderVersion(obgects)
			
#Get objects for Export		
def getObjectsForExport(Mode):
    if Mode==1:
		lsSelectedObject=GetObjectsFromCharListSelected()
    elif Mode==2:
		lsSelectedObject=GeSelectedInOutLinerObjects()
    elif Mode==3:
		lsSelectedObject=GetObjectsFromCharListAll()
    else:
        lsSelectedObject=cmds.ls(sl=True,l=True)
    if len(lsSelectedObject)<=0:
        cmds.error("PLEASE SELECT TARGET!!!") 	
    startFrame=[]
    endFrame=[]
    if len(lsSelectedObject)>0:
        for lSO in range(0, len(lsSelectedObject)):
            duplicateObj=cmds.duplicate(lsSelectedObject[lSO],rr=True,name=lsSelectedObject[lSO].split("|")[-1]+"_xxx")
            duplicateObj = cmds.ls(duplicateObj,l=True)
            if GetStatementAlembicSceneWriteVisibility()==False:
                for ids in range(0,len(duplicateObj)):
                    if cmds.getAttr(duplicateObj[ids]+".visibility") != True:
                        cmds.setAttr(duplicateObj[ids]+".visibility",True)
            DuplicateShape = cmds.ls(duplicateObj,l=True,dag=True,ni=True,lf=True,type="mesh")
            OriginalShape = cmds.ls(lsSelectedObject[lSO],l=True,dag=True,ni=True,lf=True,type="mesh")
            for ds in range(0,len(DuplicateShape)):
                    vis1=-1
                    if cmds.getAttr(DuplicateShape[ds]+".visibility") != True:
						vis1=0
						cmds.setAttr(DuplicateShape[ds]+".visibility",True)
						cmds.setAttr(OriginalShape[ds]+".visibility",True)
                    cmds.blendShape(OriginalShape[ds],DuplicateShape[ds],o="world",w=[0,1])
                    if vis1==0:
						cmds.setAttr(DuplicateShape[ds]+".visibility",False)
						cmds.setAttr(OriginalShape[ds]+".visibility",False)
            startFrame.append(UpdateAlembicSceneTimeFramesFromMayaStart())
            endFrame.append(UpdateAlembicSceneTimeFramesFromMayaEnd())
            lsSelectedObject[lSO]=duplicateObj[0]
    else:
        cmds.error("PLEASE SELECT TARGET FOR EXPORT!!!")    
        
    return lsSelectedObject,startFrame,endFrame		

#IMPORT
#Get objects and open dialog for import ABC
def pathResolve(Mode):
    if Mode==1:
        pathsSelection=GetObjectsFromCharListSelected()
    elif Mode==2:
        pathsSelection=GeSelectedInOutLinerObjects()
    elif Mode==3:
        pathsSelection=GetObjectsFromCharListAll()
    else:
        pathsSelection=cmds.ls(sl=True,l=True)
    if len(pathsSelection)<=0:
        cmds.error("PLEASE SELECT TARGET!!!") 	
    path=[]
    nodes=[]
    if len(pathsSelection)>1:
        selectionMode=4
    else:
        selectionMode=1  
    if len(pathsSelection)>0:
        for lSO in range(0,len(pathsSelection)):
            nodes.append(pathsSelection[lSO])
            pathFolderForCache=FindAlembicSceneFolder()
            singleFilter = "Abc files (*.abc)"
            if os.path.exists(UpdateAlembicSceneFolderFromMaya()):
				path.append(cmds.fileDialog2(caption=pathsSelection[lSO], fileFilter=singleFilter, dialogStyle=1, dir=UpdateAlembicSceneFolderFromMaya(), fm=selectionMode)[0])
            else:
				path.append(cmds.fileDialog2(caption=pathsSelection[lSO], fileFilter=singleFilter, dialogStyle=1, dir=pathFolderForCache, fm=selectionMode)[0])
    else:
        cmds.error("PLEASE SELECT TARGET FOR IMPORT!!!")    
     
    return nodes,path
#	
def exec_ImportAlembic(path):
    if cmds.ls("|cache") == []:
        cmds.group(em=True,name="cache")
    ChasheRoot=[]
    for p in path:
        onlyName=p.split("/")[-1]
        groupName=onlyName.split(".")[0].replace("_z_","__").replace("_x_",":")
        if cmds.ls("|cache|"+groupName) == []:
            groupName=cmds.group(em=True,parent="|cache",name=groupName)
            
        alembicNode=mel.eval("AbcImport -fitTimeRange -rpr "+"|cache|"+groupName+" \""+p+"\"")
        # Ubiraem _xxx.
        groupNameTemp=cmds.rename(cmds.ls(groupName,dag=True,l=True)[1], cmds.ls(groupName,dag=True,l=True)[1].split("|")[-1][0:-4])
        print("\n\nTarget: ",groupName,"\n\n")
        ChasheRoot.append(cmds.ls(groupNameTemp,dag=True,l=True)[0])
    return ChasheRoot,groupName
#	
def importAlembic(Mode):
    nodes,path=pathResolve(Mode)
    Alembic,groupName=exec_ImportAlembic(path)
    schetchik=0
    for n in range(0,len(nodes)):
        nodeShapes=cmds.ls(nodes[n],l=True,dag=True,ni=True,lf=True,type="mesh")
        AlembicShapes=cmds.ls(Alembic[n],l=True,dag=True,ni=True,lf=True,type="mesh")
        lenAlembic=len(Alembic[n])
        lenNodes=len(nodes[n])
        for ns in range(0,len(nodeShapes)):
            nodeShapesDeleteNameSpace=[]
            for part in nodeShapes[ns][lenNodes:].split("|"):
            	nodeShapesDeleteNameSpace.append(part.split(":")[-1])
            nodeShapesDeleteNameSpace = "|".join(nodeShapesDeleteNameSpace)
            for ass in range(0,len(AlembicShapes)):
                nodeShapesDeleteNameSpaceTMP=nodeShapesDeleteNameSpace
                if re.findall('Deformed[0-9]*$', nodeShapesDeleteNameSpaceTMP):
                    FindDeformedTargetABC=re.findall('Deformed[0-9]*$', nodeShapesDeleteNameSpaceTMP)
                    len_nodeShapesDeleteNameSpaceTMP=len(FindDeformedTargetABC)
                    nodeShapesDeleteNameSpaceTMP=nodeShapesDeleteNameSpaceTMP[:-(len_nodeShapesDeleteNameSpaceTMP)]
                AlembicShapesTMP=AlembicShapes[ass]
                if re.findall('Deformed[0-9]*$', AlembicShapesTMP):
                    FindDeformedABC=re.findall('Deformed[0-9]*$', AlembicShapesTMP)
                    len_AlembicShapesTMP=len(FindDeformedABC[0])
                    AlembicShapesTMP=AlembicShapesTMP[:-(len_AlembicShapesTMP)]
                if nodeShapesDeleteNameSpaceTMP==AlembicShapesTMP[lenAlembic:]:
                #if nodeShapesDeleteNameSpace==AlembicShapes[ass][lenAlembic:]:
                    schetchik=schetchik+1
                    print "schetchik nodes "+str(n+1)+"("+str(len(nodes))+") shapes "+str(len(nodeShapes))+"("+str(schetchik)+")"

                    listNodesToVisibility = nodeShapes[ns].split("|")
                    for x in range(1,len(listNodesToVisibility)):
                        next = ("|").join(listNodesToVisibility[0:x])
                        cmds.setAttr(next+".visibility",True)
                    cmds.setAttr(nodeShapes[ns]+".visibility",True)

                    blNode = cmds.listConnections(nodeShapes[ns],scn=True,d=False,type="blendShape")
                    if blNode is not None:
                        cmds.connectAttr((AlembicShapes[ass]+".worldMesh[0]"),(blNode[0]+".inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget"))
                    else:
                        cmds.blendShape(AlembicShapes[ass],nodeShapes[ns],o="world",w=[0,1])                    
                    break
        cmds.setAttr(Alembic[n]+".visibility",0)
        #Abc_cashe_rename(groupName)


#BLENDSHAPES
#Create blendshapes
def createBlendShapesNode(): 
	lsSelectedObject = mel.eval("$temp=`GeometryGrp_render`")
	duplicateObj=cmds.duplicate(lsSelectedObject[0],rr=True,name=lsSelectedObject[0].split("|")[-1]+"_xxx")
	duplicateObj = cmds.ls(duplicateObj,l=True)
	DuplicateShape = cmds.ls(duplicateObj,l=True,dag=True,ni=True,lf=True,type="mesh")
	OriginalShape = cmds.ls(lsSelectedObject[0],l=True,dag=True,ni=True,lf=True,type="mesh")
	for ds in range(0,len(DuplicateShape)):
	        #print DuplicateShape[ds]
	        vis1=-1
	        if cmds.getAttr(DuplicateShape[ds]+".visibility") != True:
	            vis1=0
	            cmds.setAttr(DuplicateShape[ds]+".visibility",True)
	            cmds.setAttr(OriginalShape[ds]+".visibility",True)
	        cmds.blendShape(DuplicateShape[ds],OriginalShape[ds],o="world",w=[0,1])
	        if vis1==0:
	            cmds.setAttr(DuplicateShape[ds]+".visibility",False)
	            cmds.setAttr(OriginalShape[ds]+".visibility",False)            
	cmds.delete(duplicateObj)
		
