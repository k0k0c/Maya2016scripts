import maya.cmds as cmds
m_browninan = cmds.ls( type="brownian" )
for i in range( 0, len( m_browninan )):
	#Scale.
	m_place3dTexture = cmds.listConnections( m_browninan[i], type="place3dTexture" )
	m_scale = 1.0
	if m_place3dTexture:
		for p in range( 0, len( m_place3dTexture )):
			m_temp = cmds.getAttr( "%s.scale" % m_place3dTexture[p] )[0]
			m_scale = m_scale * (( max( m_temp ) + min( m_temp ))/2 )
	m_output = cmds.listConnections( "%s.outColor" % m_browninan[i], source=False, destination=True, plugs=True )
	if m_output:
		#Create new noise node.
		m_noise = cmds.createNode( "noise" )
		m_place2dTexture = cmds.createNode( "place2dTexture" )
		cmds.connectAttr( "%s.outUV" % m_place2dTexture, "%s.uvCoord" % m_noise )
		cmds.connectAttr( "%s.outUvFilterSize" % m_place2dTexture, "%s.uvFilterSize" % m_noise )
		#Color balance.
		m_value = cmds.getAttr( "%s.defaultColor" % m_browninan[i] )
		cmds.setAttr( "%s.defaultColor" % m_noise, m_value[0][0], m_value[0][1], m_value[0][2], type="double3" )
		m_value = cmds.getAttr( "%s.colorGain" % m_browninan[i] )
		cmds.setAttr( "%s.colorGain" % m_noise, m_value[0][0], m_value[0][1], m_value[0][2], type="double3" )
		m_value = cmds.getAttr( "%s.colorOffset" % m_browninan[i] )
		cmds.setAttr( "%s.colorOffset" % m_noise, m_value[0][0], m_value[0][1], m_value[0][2], type="double3" )
		m_value = cmds.getAttr( "%s.alphaGain" % m_browninan[i] )
		cmds.setAttr( "%s.alphaGain" % m_noise, m_value )
		m_value = cmds.getAttr( "%s.alphaOffset" % m_browninan[i] )
		cmds.setAttr( "%s.alphaOffset" % m_noise, m_value )
		m_value = cmds.getAttr( "%s.alphaIsLuminance" % m_browninan[i] )
		cmds.setAttr( "%s.alphaIsLuminance" % m_noise, m_value )
		#Effects.
		m_value = cmds.getAttr( "%s.filter" % m_browninan[i] )
		cmds.setAttr( "%s.filter" % m_noise, m_value )
		m_value = cmds.getAttr( "%s.filterOffset" % m_browninan[i] )
		cmds.setAttr( "%s.filterOffset" % m_noise, m_value )
		m_value = cmds.getAttr( "%s.invert" % m_browninan[i] )
		cmds.setAttr( "%s.invert" % m_noise, m_value )
		#Frequency.
		m_frequency = cmds.getAttr( "%s.lacunarity" % m_browninan[i] )
		cmds.setAttr( "%s.noiseU" % m_place2dTexture, m_frequency*0.001 )
		cmds.setAttr( "%s.noiseV" % m_place2dTexture, m_frequency*0.001 )
		#Depth.
		m_octave = cmds.getAttr( "%s.octaves" % m_browninan[i] )
		cmds.setAttr( "%s.depthMax" % m_noise, m_octave )
		cmds.setAttr( "%s.frequency" % m_noise, ( m_frequency*m_scale )*10.0 )
		cmds.setAttr( "%s.frequencyRatio" % m_noise, m_frequency*m_scale )
		#Contrast.
		m_value = cmds.getAttr( "%s.increment" % m_browninan[i] )
		if m_value>=0:
			m_value = 1.0 / ( m_value + 1.0 )
		else:
			m_value = ( -m_value * 5 )
		cmds.setAttr( "%s.amplitude" % m_noise, m_value )
		#Implode.
		m_value = cmds.getAttr( "%s.weight3dZ" % m_browninan[i] )
		cmds.setAttr( "%s.rotateUV" % m_place2dTexture, m_value )
		cmds.setAttr( "%s.implode" % m_noise, ( m_value - 1.0 ))
		m_value = cmds.getAttr( "%s.weight3dY" % m_browninan[i] )
		cmds.setAttr( "%s.repeatU" % m_place2dTexture, m_value )
		m_value = cmds.getAttr( "%s.weight3dX" % m_browninan[i] )
		cmds.setAttr( "%s.repeatV" % m_place2dTexture, m_value )
		cmds.setAttr( "%s.threshold" % m_noise, 0.0 )
		cmds.setAttr( "%s.inflection" % m_noise, 0 )
		cmds.setAttr( "%s.ratio" % m_noise, 0.75 )
		#Reconnect noise.
		for o in range( 0, len( m_output )):
			cmds.disconnectAttr( "%s.outColor" % m_browninan[i], m_output[o] )
			cmds.connectAttr( "%s.outColor" % m_noise, m_output[o] )