import maya.cmds as cmds
import maya.mel as mel
if cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
	import rfm.slim
	
def init_slim():
    if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
        cmds.loadPlugin("RenderMan_for_Maya")
	
	if cmds.about(b=True): 
		mel.eval("rman slim start -gui 0 -edit 0")
    if not rfm.slim.GetSlim().Running():
        rfm.slim.GetSlim().Start()

	myslim = rfm.slim.GetSlim()
	kakzhedolgo=100000000
	vottak=0
	while vottak < kakzhedolgo:
		vottak+=1
		gde=myslim.Cmd("slim GetSlimStatus")
		if gde != "":
			kakzhedolgo=vottak-1
