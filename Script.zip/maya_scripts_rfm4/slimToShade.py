import maya.cmds as cmds
import math
import maya.mel as mel
import rfm as rfm
import site
import sys
import re
import glob
import os
site.addsitedir(r'\\server-3d\Project\lib\setup\rfm400');
import slim

OSTYPE = sys.platform
if OSTYPE == "win32":
	OSTYPE="//Server-3d/Project"
else:
	OSTYPE="/Server-3d/Project"

def pathResolve(path):
    if not os.path.exists(path):
        if not os.path.exists(OSTYPE+"/"+path):
            cmds.warning("!!!! PATH RESOLVE !!!!")
            return ""
        else:
            return OSTYPE+"/"+path
    else:
        return path

    
def setAttribute(node, attr, value):
    print "setAttribute: "+str(value)+" type: "+str(type(value))+" node: "+node+" attr: "+attr
    #mat=re.match("^[0-9 \.]+$",value)
    #if cmds.objExists(value):
    if type(value) == type([]):
        #inSlotType = cmds.attributeQuery(value[1],node=value[0],at=True)
        #outSlotType = cmds.attributeQuery(attr,node=node,at=True)
        inSlotType = cmds.getAttr(value[0]+"."+value[1],typ=True)
        outSlotType = cmds.getAttr(node+"."+attr,typ=True)        
        if inSlotType == 'float3' and outSlotType == 'float':
            value[1]=cmds.attributeQuery(value[1],node=value[0],lc=True)[0]
        
        if inSlotType == 'float' and outSlotType == 'float3':
            print("value[1]: "+value[1]+" value[0]: "+value[0])
            temp=cmds.attributeQuery(attr,node=node,lc=True)[0]
            if not cmds.isConnected(value[0]+"."+value[1], node+"."+attr+"."+temp):
                print(node+"."+attr+"."+temp)
                cmds.connectAttr(value[0]+"."+value[1], node+"."+attr+"."+temp, f=True)
            temp=cmds.attributeQuery(attr,node=node,lc=True)[1]
            if not cmds.isConnected(value[0]+"."+value[1], node+"."+attr+"."+temp):
                cmds.connectAttr(value[0]+"."+value[1], node+"."+attr+"."+temp, f=True)
            temp=cmds.attributeQuery(attr,node=node,lc=True)[2]
            if not cmds.isConnected(value[0]+"."+value[1], node+"."+attr+"."+temp):
                cmds.connectAttr(value[0]+"."+value[1], node+"."+attr+"."+temp, f=True)
        else:
            if not cmds.isConnected(value[0]+"."+value[1],node+"."+attr):
                cmds.connectAttr(value[0]+"."+value[1],node+"."+attr,f=True)
    else:
        temp=value.strip().split(" ")
        #typeVar = cmds.attributeQuery(attr,node=node,at=True)
        typeVar = cmds.getAttr(node+"."+attr,typ=True)
        print("Type: "+typeVar+"")   
        
        conectList=cmds.listConnections( node+"."+attr, d=False, s=True, p=True)
        if conectList:
            cmds.disconnectAttr(conectList[0],node+"."+attr)
            
        if typeVar=="float3":
            if len(temp)==1:            
                cmds.setAttr(node+"."+attr, float(temp[0]), float(temp[0]), float(temp[0]), type="double3")
            else:
                cmds.setAttr(node+"."+attr, float(temp[0]), float(temp[1]), float(temp[2]), type="double3")
        elif typeVar=="string":
            cmds.setAttr(node+"."+attr, temp[0], type="string")
        else:
            print("cmds.setAttr("+node+"."+attr+", float("+temp[0]+"))")
            cmds.setAttr(node+"."+attr, float(temp[0]))
    
    
def getAttribute(attr):
    print "getAttribute: " + str(attr)
    rez=attr
    if type(attr) == type({}):    
        rez=DictionariesRecurce(attr,"")
    return rez
        
def multNode(val,mult,op="mult"):
    print "multNode: " + str(val) + " mult: " + str(mult)
    node=""
    nodeID=""
    if type(val) == type([]) or type(mult) == type([]):
        if type(val) == type([]):
            nodeID=val[0]+"."+val[1]
        if type(mult) == type([]):
            nodeID+=mult[0]+"."+mult[1]
            
        findAiSt = cmds.ls(type='multiplyDivide')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID+"_multNode":
                    node=AI
                    break
                
        if node=="":
            node=cmds.shadingNode('multiplyDivide',asUtility=True)
            cmds.addAttr(node,ln="SlimLinkID",dt="string")
            cmds.setAttr(node+".SlimLinkID",nodeID+"_multNode",type="string")
        
        if type(val) == type([]):    
            if not cmds.isConnected(val[0]+"."+val[1],node+".input1"):
                conectList=cmds.listConnections( node+".input1", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],node+".input1")
                #cmds.connectAttr(val[0]+"."+val[1],node+".input1",f=True)
                setAttribute(node,"input1",val)
        else:        
            setAttribute(node,"input1X",str(val))
            setAttribute(node,"input1Y",str(val))
            setAttribute(node,"input1Z",str(val))
                
        if type(mult) == type([]):
            if not cmds.isConnected(mult[0]+"."+mult[1],node+".input2"):
                conectList=cmds.listConnections( node+".input2", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],node+".input2")
                cmds.connectAttr(mult[0]+"."+mult[1],node+".input2",f=True)
        else:        
            setAttribute(node,"input2X",str(mult))
            setAttribute(node,"input2Y",str(mult))
            setAttribute(node,"input2Z",str(mult))
      
        if op=="mult":
            cmds.setAttr(node+".operation",1)
        if op=="div":
            cmds.setAttr(node+".operation",2)            
        if op=="sqrt":
            cmds.setAttr(node+".operation",3)
            
        return [node,"output"]
        
    else:
        temp=str(val).strip().split(" ")
        temp2=str(mult).strip().split(" ")
        if op=="mult":
            if len(temp)==1 and len(temp2)==1:
                return str(float(val)*float(mult))
            elif len(temp)==3 and len(temp2)==1:
                return str(float(temp[0])*float(temp2[0]))+" "+str(float(temp[1])*float(temp2[0]))+" "+str(float(temp[2])*float(temp2[0]))
            elif len(temp)==1 and len(temp2)==3:
                return str(float(temp[0])*float(temp2[0]))+" "+str(float(temp[0])*float(temp2[1]))+" "+str(float(temp[0])*float(temp2[2]))            
            elif len(temp)==3 and len(temp2)==3:
                return str(float(temp[0])*float(temp2[0]))+" "+str(float(temp[1])*float(temp2[1]))+" "+str(float(temp[2])*float(temp2[2]))            
        if op=="div":
            if len(temp)==1 and len(temp2)==1:
                return str(float(val)/float(mult))
            elif len(temp)==3 and len(temp2)==1:
                return str(float(temp[0])/float(temp2[0]))+" "+str(float(temp[1])/float(temp2[0]))+" "+str(float(temp[2])/float(temp2[0]))
            elif len(temp)==1 and len(temp2)==3:
                return str(float(temp[0])/float(temp2[0]))+" "+str(float(temp[0])/float(temp2[1]))+" "+str(float(temp[0])/float(temp2[2]))            
            elif len(temp)==3 and len(temp2)==3:
                return str(float(temp[0])/float(temp2[0]))+" "+str(float(temp[1])/float(temp2[1]))+" "+str(float(temp[2])/float(temp2[2]))            
        if op=="sqrt":
            if len(temp)==1 and len(temp2)==1:
                return str(float(val)**float(mult))
            elif len(temp)==3 and len(temp2)==1:
                return str(float(temp[0])**float(temp2[0]))+" "+str(float(temp[1])**float(temp2[0]))+" "+str(float(temp[2])**float(temp2[0]))
            elif len(temp)==1 and len(temp2)==3:
                return str(float(temp[0])**float(temp2[0]))+" "+str(float(temp[0])**float(temp2[1]))+" "+str(float(temp[0])**float(temp2[2]))            
            elif len(temp)==3 and len(temp2)==3:
                return str(float(temp[0])**float(temp2[0]))+" "+str(float(temp[1])**float(temp2[1]))+" "+str(float(temp[2])**float(temp2[2]))                            
            
def plusMinusNode(val,mult,op):
    print "plusMinusNode: " + str(val) + " mult: " + str(mult) + " op: " + str(op)
    node=""
    nodeID=""
    if type(val) == type([]) or type(mult) == type([]):
        if type(val) == type([]):
            nodeID=val[0]+"."+val[1]
        if type(mult) == type([]):
            nodeID+=mult[0]+"."+mult[1]
            
        findAiSt = cmds.ls(type='plusMinusAverage')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID+"_plusMinusNode":
                    node=AI
                    break
                
        if node=="":
            node=cmds.shadingNode('plusMinusAverage',asUtility=True)
            cmds.addAttr(node,ln="SlimLinkID",dt="string")
            cmds.setAttr(node+".SlimLinkID",nodeID+"_plusMinusNode",type="string")
        
        if type(val) == type([]):    
            if not cmds.isConnected(val[0]+"."+val[1],node+".input3D[0]"):
                conectList=cmds.listConnections( node+".input3D[0]", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],node+".input3D[0]")
                cmds.connectAttr(val[0]+"."+val[1],node+".input3D[0]",f=True)
        else:        
            temp=val.strip().split(" ")
            if len(temp)==1:            
                cmds.setAttr(node+".input3D[0].input3Dx",float(temp[0]))
                cmds.setAttr(node+".input3D[0].input3Dy",float(temp[0]))
                cmds.setAttr(node+".input3D[0].input3Dz",float(temp[0]))
            else:
                cmds.setAttr(node+".input3D[0].input3Dx",float(temp[0]))
                cmds.setAttr(node+".input3D[0].input3Dy",float(temp[1]))
                cmds.setAttr(node+".input3D[0].input3Dz",float(temp[2]))            
                        
        if type(mult) == type([]):
            if not cmds.isConnected(mult[0]+"."+mult[1],node+".input3D[1]"):
                conectList=cmds.listConnections( node+".input3D[1]", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],node+".input3D[1]")
                cmds.connectAttr(mult[0]+"."+mult[1],node+".input3D[1]",f=True)
        else:
            temp=mult.strip().split(" ")
            if len(temp)==1:    
                cmds.setAttr(node+".input3D[1].input3Dx",float(temp[0]))
                cmds.setAttr(node+".input3D[1].input3Dy",float(temp[0]))
                cmds.setAttr(node+".input3D[1].input3Dz",float(temp[0]))
            else:
                cmds.setAttr(node+".input3D[1].input3Dx",float(temp[0]))
                cmds.setAttr(node+".input3D[1].input3Dy",float(temp[1]))
                cmds.setAttr(node+".input3D[1].input3Dz",float(temp[2]))        
        if op=="-":
            cmds.setAttr(node+".operation",2)
        if op=="+":
            cmds.setAttr(node+".operation",1)            
            
        return [node,"output3D"]
        
    else:
        temp=str(val).strip().split(" ")
        temp2=str(mult).strip().split(" ")
        if op=="-":
            if len(temp)==1 and len(temp2)==1:
                return str(float(val)-float(mult))
            elif len(temp)==3 and len(temp2)==1:
                return str(float(temp[0])-float(temp2[0]))+" "+str(float(temp[1])-float(temp2[0]))+" "+str(float(temp[2])-float(temp2[0]))
            elif len(temp)==1 and len(temp2)==3:
                return str(float(temp[0])-float(temp2[0]))+" "+str(float(temp[0])-float(temp2[1]))+" "+str(float(temp[0])-float(temp2[2]))            
            elif len(temp)==3 and len(temp2)==3:
                return str(float(temp[0])-float(temp2[0]))+" "+str(float(temp[1])-float(temp2[1]))+" "+str(float(temp[2])-float(temp2[2]))                        
        else:
            if len(temp)==1 and len(temp2)==1:
                return str(float(val)+float(mult))
            elif len(temp)==3 and len(temp2)==1:
                return str(float(temp[0])+float(temp2[0]))+" "+str(float(temp[1])+float(temp2[0]))+" "+str(float(temp[2])+float(temp2[0]))
            elif len(temp)==1 and len(temp2)==3:
                return str(float(temp[0])+float(temp2[0]))+" "+str(float(temp[0])+float(temp2[1]))+" "+str(float(temp[0])+float(temp2[2]))            
            elif len(temp)==3 and len(temp2)==3:
                return str(float(temp[0])+float(temp2[0]))+" "+str(float(temp[1])+float(temp2[1]))+" "+str(float(temp[2])+float(temp2[2]))                                
            
def clampNode(val):
    print "clampNode: " + str(val)
    node=""
    if type(val) == type([]):
        nodeID=cmds.getAttr(val[0]+".SlimLinkID")
        findAiSt = cmds.ls(type='clamp')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID+"_clampNode":
                    node=AI
                    break
            
        if node=="":
            node=cmds.shadingNode('clamp',asUtility=True)
            cmds.addAttr(node,ln="SlimLinkID",dt="string")
            cmds.setAttr(node+".SlimLinkID",nodeID+"_clampNode",type="string")
            cmds.connectAttr(val[0]+"."+val[1],node+".input",f=True)
        
        cmds.setAttr(node+".maxR",1)
        cmds.setAttr(node+".maxG",1)
        cmds.setAttr(node+".maxB",1)

        return [node,"output"]
    else:
        temp=val.strip().split(" ")
        if len(temp)==1:
            return str(max(0, min(float(temp[0]), 1)))
        else:
            return str(max(0, min(float(temp[0]), 1)))+" "+str(max(0, min(float(temp[1]), 1)))+" "+str(max(0, min(float(temp[2]), 1)))

def invertNode(val):
    print "invertNode: " + str(val)
    node=""
    if type(val) == type([]):
        nodeID=cmds.getAttr(val[0]+".SlimLinkID")
        findAiSt = cmds.ls(type='reverse')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID+"_invertNode":
                    node=AI
                    break
            
        if node=="":
            node=cmds.shadingNode('reverse',asUtility=True)
            cmds.addAttr(node,ln="SlimLinkID",dt="string")
            cmds.setAttr(node+".SlimLinkID",nodeID+"_invertNode",type="string")
            cmds.connectAttr(val[0]+"."+val[1],node+".input",f=True)

        return [node,"output"]
    else:
        temp=val.strip().split(" ")
        if len(temp)==1:
            return str(1-float(temp[0]))
        else:
            return str(1-float(temp[0]))+" "+str(1-float(temp[1]))+" "+str(1-float(temp[2]))
            
def findShadepsOnSG(SG,attr,value):
    node = cmds.sets(SG,q=True)
    for sg in node:
        setAttribute(sg,attr,value)    
        
def select_slim_material():
    allSurface = cmds.ls(selection=True, dagObjects=True, long=True, transforms=True, ni=True, lf=True, shapes=True, cameras=True, lights=True,type='shadingEngine')
    for obj in allSurface:
        proverka = ""
        if mel.eval("attributeExists(\"rman__torattr___slimSurface\", \""+obj+"\")") == 1:
            proverka = cmds.getAttr(obj+".rman__torattr___slimSurface")
        if mel.eval("attributeExists(\"rman__torattr___slimEnsemble\", \""+obj+"\")") == 1:
            proverka = cmds.getAttr(obj+".rman__torattr___slimEnsemble")        
        if mel.eval("attributeExists(\"rman__torattr___slimShader\", \""+obj+"\")") == 1:        
            proverka = cmds.getAttr(obj+".rman__torattr___slimShader")    
        if proverka != "":
            print "\n"+obj+"\n"
            if not slim.GetSlim().Running():
                slim.GetSlim().Start()
            slim.GetSlim().Cmd("select_shader \""+proverka+"\"")
            break          

            
            
    
def convert_slim_material():
        
    allSurface = cmds.ls(selection=True, dagObjects=True, long=True, ni=True, lf=True, transforms=False, shapes=True, cameras=True, lights=True,type='shadingEngine')
    global slovarik
    slovarik={}
    for obj in allSurface:
        proverka = ""
        if mel.eval("attributeExists(\"rman__torattr___slimSurface\", \""+obj+"\")") == 1:
            proverka = cmds.getAttr(obj+".rman__torattr___slimSurface")
        if mel.eval("attributeExists(\"rman__torattr___slimEnsemble\", \""+obj+"\")") == 1:
            proverka = cmds.getAttr(obj+".rman__torattr___slimEnsemble")        
        #if mel.eval("attributeExists(\"rman__torattr___slimShader\", \""+obj+"\")") == 1:        
        #    proverka = cmds.getAttr(obj+".rman__torattr___slimShader")    
        if proverka != "":
            print proverka
            list=[]
            if slovarik.get(proverka):
                list=slovarik.get(proverka)
            list.append(obj)            
            slovarik[proverka]=list

    global key
    for key in slovarik.keys():
        print "\n"+key+"\n"
        
        if not slim.GetSlim().Running():
            slim.GetSlim().Start()
        dataString = slim.GetSlim().Cmd("findConnectionName \""+key+"\"")

        if dataString!="":
            myDict = eval(dataString)
            
            surfaceNode=DictionariesRecurce(myDict,"")

            SG = cmds.listConnections( surfaceNode[0]+"."+surfaceNode[1], d=True, s=False)
            print("SG list: "+str(SG))
            for cg in SG:
                if cmds.objectType(cg)=="shadingEngine":
                    SG[0]=cg
                    break
            opa=0
            if cmds.objectType(surfaceNode[0]) == 'aiStandard':
                if cmds.getAttr(surfaceNode[0]+'.opacity') != [(1.0, 1.0, 1.0)] or cmds.getAttr(surfaceNode[0]+'.Kt')!=0 or cmds.listConnections( surfaceNode[0]+'.opacity', d=False, s=True) or cmds.listConnections( surfaceNode[0]+'.Kt', d=False, s=True):
                    opa=1
            elif cmds.objectType(surfaceNode[0]) == 'layeredShader':
                for i in cmds.getAttr(surfaceNode[0]+".inputs",mi=True):
                    if cmds.getAttr(surfaceNode[0]+".inputs["+str(i)+"].transparency") != [(0.0, 0.0, 0.0)]:
                        opa=1
                    node=cmds.listConnections( surfaceNode[0]+".inputs["+str(i)+"].color", d=False, s=True)
                    if node:
                        if cmds.objectType(node[0])=='aiStandard':
                            if cmds.getAttr(node[0]+'.opacity') != [(1.0, 1.0, 1.0)] or cmds.getAttr(node[0]+'.Kt')!=0:
                                opa=1
        
            for val in slovarik.get(key):
                print "val: "+str(val)
                valSG = cmds.listConnections( val+".instObjGroups[0]", d=True, s=False)    
                print str(valSG)+" "+str(SG[0])
                if valSG != SG:
                    print SG[0]
                    cmds.sets(val,e=True,forceElement=SG[0])            
                if opa:
                    cmds.setAttr(val+'.aiOpaque',0)
                else:
                    cmds.setAttr(val+'.aiOpaque',1)
        
def DictionariesRecurce(myDict,mayaObject):
    nodeID = myDict.get('nodeID')
    nodeName = myDict.get('nodeName')
    nodeTemplate = myDict.get('nodeTemplate')
    print "nodeTemplate:"+nodeTemplate+"nodeName:"+nodeName+"nodeID:"+nodeID
    
    surfaceNode=""
    if nodeTemplate == 'GPSurface' or nodeTemplate == 'RMSGlass':
        print '\n'+nodeTemplate+'\n'
        findAiSt = cmds.ls(type='aiStandard')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode = mel.eval("createRenderNodeCB -asShader \"surfaceShader\" aiStandard \"\"")
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")

        surface_Color=getAttribute(myDict.get('NodeAtributes').get('surfaceColor'))
        surface_Kd=""
        if nodeTemplate == 'GPSurface':
            surface_Kd=multNode(getAttribute(myDict.get('NodeAtributes').get('diffuseGain')),1) #0.95 0.78
            setAttribute(surfaceNode,"diffuseRoughness",multNode(getAttribute(myDict.get('NodeAtributes').get('diffuseRoughness')),0.333))
            ######setAttribute(surfaceNode,"opacity", str(clamp(0,1.4*(1-float(temp[0])),1))+" "+str(clamp(0,1.4*(1-float(temp[1])),1))+" "+str(clamp(0,1.4*(1-float(temp[2])),1)))
            #setAttribute(surfaceNode,"opacity", clampNode(multNode(invertNode(getAttribute(myDict.get('NodeAtributes').get('transparency'))),1.4)))
            setAttribute(surfaceNode,"opacity", invertNode(getAttribute(myDict.get('NodeAtributes').get('transparency'))))

            temp=getAttribute(myDict.get('NodeAtributes').get('purity'))
            if float(temp) != 0:
                purity=""
                findAiSt = cmds.ls(type='blendColors')
                for AI in findAiSt:
                    if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                        if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                            purity=AI
                            break
            
                if purity == "":
                    purity=cmds.shadingNode('blendColors',asUtility=True)                        
                    cmds.addAttr(purity,ln="SlimLinkID",dt="string")
                    cmds.setAttr(purity+".SlimLinkID",nodeID,type="string")
                    
                #if not cmds.isConnected(purity+".outNormal",surfaceNode+".normalCamera"):
                #    cmds.connectAttr(purity+".outNormal",surfaceNode+".normalCamera",f=True)

                setAttribute(purity,"color2",surface_Color)
                setAttribute(purity,"color1","2 2 2")
                setAttribute(purity,"blender",temp)
                
                surface_Color=[purity,"output"]
                
                #conectList=cmds.listConnections( surfaceNode+".normalCamera", d=False, s=True, p=True)
                #if conectList:
                #    cmds.disconnectAttr(conectList[0],surfaceNode+".normalCamera")

            setAttribute(surfaceNode,"Kb",getAttribute(myDict.get('NodeAtributes').get('translucentColor')))
            temp=getAttribute(myDict.get('NodeAtributes').get('emission'))
            if type(temp) == type([]):
                setAttribute(surfaceNode,"emission","1")    
                setAttribute(surfaceNode,"emissionColor",temp)        
            else:
                temp2=temp.strip().split(" ")
                if len(temp2)==1 and float(temp2[0])!=0:
                    setAttribute(surfaceNode,"emission","1")    
                    setAttribute(surfaceNode,"emissionColor",temp2[0])
                elif len(temp2)==3 and (float(temp2[0])!=0 or float(temp2[1])!=0 or float(temp2[2])!=0):
                    setAttribute(surfaceNode,"emission","1")    
                    setAttribute(surfaceNode,"emissionColor",temp2[0]+" "+temp2[1]+" "+temp2[2])
                else:
                    setAttribute(surfaceNode,"emission","0")    
                    setAttribute(surfaceNode,"emissionColor","1 1 1")    
       
       
        surface_SpecularRoughness = clampNode(multNode(multNode(getAttribute(myDict.get('NodeAtributes').get('roughness')),"0.5","sqrt"),1.2658))
        #surface_SpecularRoughness = clampNode(multNode(getAttribute(myDict.get('NodeAtributes').get('roughness')),4))
        #surface_SpecularRoughness = clampNode(math.sqrt(getAttribute(myDict.get('NodeAtributes').get('roughness'))))
        surface_SpecularColor = getAttribute(myDict.get('NodeAtributes').get('specularColor'))
        setAttribute(surfaceNode,"specularRoughness",surface_SpecularRoughness)
        surface_SpecularGain=getAttribute(myDict.get('NodeAtributes').get('specularGain'))
        setAttribute(surfaceNode,"Ks",surface_SpecularGain) #setAttribute(surfaceNode,"Ks",multNode(getAttribute(myDict.get('NodeAtributes').get('specularGain')), 0.165))
        setAttribute(surfaceNode,"KsColor",surface_SpecularColor)
        setAttribute(surfaceNode,"specularFresnel","1")
        setAttribute(surfaceNode,"enableInternalReflections","0")
        
        temp=getAttribute(myDict.get('NodeAtributes').get('anisotropy'))
        if float(temp)!=0:
            setAttribute(surfaceNode,"specularBrdf","1")
            setAttribute(surfaceNode,"specularRotation","0")
            setAttribute(surfaceNode,"specularAnisotropy",str((float(temp)+1)/2))
        else:
            setAttribute(surfaceNode,"specularBrdf","0")
        
        ior=0.0
        temp=float(getAttribute(myDict.get('NodeAtributes').get('ior')))
        '''
        if temp<1.5:
            ior=0
        elif temp>=1.5 and temp<=2.5: # 0.004 0.162 -> 0.05 0.2
            ior=((temp-1.5)/1)* 0.158 + 0.004 # 0.15 + 0.05 
        elif temp>=2.5 and temp<=5: # 0.162 0.85 -> 0.2 0.5
            ior=((temp-2.5)/2.5)* 0.688 + 0.162 # 0.3 + 0.2
        elif temp>5: # >
            ior=1
        '''
        '''
        if temp>=1.1 and temp<=1.25: # 0.005 0.025
            ior=((temp-1.1)/0.15)* 0.02 + 0.005
        elif temp>=1.25 and temp<=1.5: # 0.025 0.05
            ior=((temp-1.25)/0.25)* 0.025 + 0.025
        elif temp>=1.5 and temp<=2.5: # 0.05 0.2
            ior=((temp-1.5)/1)* 0.15 + 0.05 
        elif temp>=2.5 and temp<=5: # 0.2 0.5
            ior=((temp-2.5)/2.5)* 0.3 + 0.2
        elif temp>5: # >
            ior=1
        '''
        ior=str(math.log(math.sqrt(temp),10) * 0.25)
            
        if nodeTemplate == 'GPSurface':
            temp=getAttribute(myDict.get('NodeAtributes').get('metallic'))
            ior=clampNode(plusMinusNode(multNode(ior,invertNode(temp)),multNode(temp,0.8),"+"))
            #ior=clampNode(str(ior*(1-temp)+temp*0.8))
            if temp == 1:
                ior="1"
            if temp != 0:
                #setAttribute(surfaceNode,"Kd",multNode(getAttribute(myDict.get('NodeAtributes').get('diffuseGain')),1-temp))
                #if type(surface_SpecularGain) == type("") and float(surface_SpecularGain) != 0:
                surface_Kd=multNode(surface_Kd,invertNode(temp))
            
                
        setAttribute(surfaceNode,"Ksn",ior)
        
        if nodeTemplate == 'RMSGlass':
            setAttribute(surfaceNode,"IOR",getAttribute(myDict.get('NodeAtributes').get('ior')))        
            setAttribute(surfaceNode,"refractionRoughness",surface_SpecularRoughness)
            setAttribute(surfaceNode,"Fresnel","1")
            surface_Kd="0"
            #setAttribute(surfaceNode,"Kd","0")
            setAttribute(surfaceNode,"Ks","0")
            setAttribute(surfaceNode,"Kr","1")
            setAttribute(surfaceNode,"Kt","1")
            setAttribute(surfaceNode,"KrColor",surface_SpecularColor)
            setAttribute(surfaceNode,"KtColor",surface_Color)
            temp=getAttribute(myDict.get('NodeAtributes').get('computeBeers'))
            if temp=="1":
                setAttribute(surfaceNode,"transmittance",clampNode(invertNode(multNode(getAttribute(myDict.get('NodeAtributes').get('beersUnitScale')),0.0985))))
            else:
                setAttribute(surfaceNode,"transmittance","1 1 1")
            
            
            setAttribute(surfaceNode,"FresnelUseIOR","1")
            
            setAttribute(surfaceNode,"refractionExitUseEnvironment","1")
            setAttribute(surfaceNode,"reflectionExitUseEnvironment","1")
            #setAttribute(surfaceNode,"enableRefractiveCaustics","1")

            
        if nodeTemplate == 'GPSurface':
            #'sssTraceSet': '',
            sssTint=getAttribute(myDict.get('NodeAtributes').get('sssTint'))
            sssAlbedo=getAttribute(myDict.get('NodeAtributes').get('sssAlbedo'))
            sssMix=getAttribute(myDict.get('NodeAtributes').get('sssMix'))
            sssDmfpScale=getAttribute(myDict.get('NodeAtributes').get('sssDmfpScale'))
            sssDmfp=getAttribute(myDict.get('NodeAtributes').get('sssDmfp'))
            sssUnitlen=getAttribute(myDict.get('NodeAtributes').get('sssUnitlen'))
            if sssMix == "0 0 0":
                setAttribute(surfaceNode,"KsssColor","1 1 1")
                setAttribute(surfaceNode,"Ksss","0")
                setAttribute(surfaceNode,"sssRadius", "0 0 0")
            else:
                surface_Kd=plusMinusNode(surface_Kd,multNode(surface_Kd,sssMix),"-")
                setAttribute(surfaceNode,"KsssColor",multNode(sssTint,surface_Color))
                setAttribute(surfaceNode,"Ksss",multNode(multNode("1",getAttribute(myDict.get('NodeAtributes').get('diffuseGain'))),sssMix)) # 0.72
                setAttribute(surfaceNode,"sssRadius",multNode(multNode(multNode(multNode(sssUnitlen,sssDmfpScale),sssDmfp),sssAlbedo),"2"))
            '''
            setAttribute(surfaceNode,"KsssColor",getAttribute(myDict.get('NodeAtributes').get('sssTint')))
            temp=getAttribute(myDict.get('NodeAtributes').get('sssMix'))
            #tempDiff=multNode(getAttribute(myDict.get('NodeAtributes').get('diffuseGain')),0.95)
            if type(temp) == type([]):
                #setAttribute(surfaceNode,"Ksss",multNode(temp[0],tempDiff))
                #setAttribute(surfaceNode,"Kd",clampNode(str((tempDiff-float(temp[0]))*tempDiff)))
                pass
            else:
                temp2=temp.strip().split(" ")
                if float(temp2[0])!=0 or float(temp2[1])!=0 or float(temp2[2])!=0:
                    setAttribute(surfaceNode,"Ksss",multNode(temp2[0],surface_Kd))
                    surface_Kd = clampNode(plusMinusNode(surface_Kd,multNode(temp2[0],surface_Kd),"-"))
                    pass
                else:
                    setAttribute(surfaceNode,"Ksss","0")
            
            temp = float(getAttribute(myDict.get('NodeAtributes').get('sssDmfpScale')))
            temp2 = getAttribute(myDict.get('NodeAtributes').get('sssDmfp').strip().split(" "))
            temp3 = float(getAttribute(myDict.get('NodeAtributes').get('sssUnitlen')))
            
            setAttribute(surfaceNode,"sssRadius",str(temp*float(temp2[0])*temp3)+" "+str(temp*float(temp2[1])*temp3)+" "+str(temp*float(temp2[2])*temp3))
            '''
            
            
            
        
        temp=getAttribute(myDict.get('NodeAtributes').get('enableDisplacement'))
        conectListCG=cmds.listConnections(surfaceNode+".outColor", d=True, s=False)[0]
        
        if temp=="1": # Bump
            bump=""
            findAiSt = cmds.ls(type='bump2d')
            for AI in findAiSt:
                if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                    if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                        bump=AI
                        break
        
            if bump == "":    
                bump=cmds.shadingNode('bump2d',asUtility=True)                        
                cmds.addAttr(bump,ln="SlimLinkID",dt="string")
                cmds.setAttr(bump+".SlimLinkID",nodeID,type="string")
                
            if not cmds.isConnected(bump+".outNormal",surfaceNode+".normalCamera"):
                cmds.connectAttr(bump+".outNormal",surfaceNode+".normalCamera",f=True)

            testSigned=getAttribute(myDict.get('NodeAtributes').get('vectorEncoding'))
            fileNode=getAttribute(myDict.get('NodeAtributes').get('displacementScalar'))
            
            print "fileNode: " + str(fileNode)
            if type(fileNode) == type([]):
                if testSigned=="0":
                    fileNode=plusMinusNode(multNode(fileNode,"2 2 2"),"1 1 1","-")            
                    
                setAttribute(bump,"bumpValue",fileNode)
                setAttribute(bump,"bumpDepth",multNode(getAttribute(myDict.get('NodeAtributes').get('displacementAmount')),1))
            else:
                conectList=cmds.listConnections( surfaceNode+".normalCamera", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],surfaceNode+".normalCamera")
          
        elif temp=="0": # Displacement
            disp=""
            findAiSt = cmds.ls(type='displacementShader')
            for AI in findAiSt:
                if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                    if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                        disp=AI
                        break
        
            if disp == "":    
                disp=cmds.shadingNode('displacementShader',asShader=True)                        
                cmds.addAttr(disp,ln="SlimLinkID",dt="string")
                cmds.setAttr(disp+".SlimLinkID",nodeID,type="string")

            
            cmds.setAttr(disp+".aiDisplacementPadding",1)
            
            if not cmds.isConnected(disp+".displacement",conectListCG+".displacementShader"):
                cmds.connectAttr(disp+".displacement",conectListCG+".displacementShader",f=True)

            testSigned=getAttribute(myDict.get('NodeAtributes').get('vectorEncoding'))
            fileNode=getAttribute(myDict.get('NodeAtributes').get('displacementScalar'))
            
            print "fileNode: " + str(fileNode)
            if type(fileNode) == type([]):
                if testSigned=="0":
                    fileNode=plusMinusNode(multNode(fileNode,"2 2 2"),"1 1 1","-")            
                    
                setAttribute(disp,"displacement",fileNode)
                setAttribute(disp,"scale",multNode(getAttribute(myDict.get('NodeAtributes').get('displacementAmount')),0.28))
            else:
                conectList=cmds.listConnections( conectListCG+".displacementShader", d=False, s=True, p=True)
                if conectList:
                    cmds.disconnectAttr(conectList[0],conectListCG+".displacementShader")
        else:
            conectList=cmds.listConnections( surfaceNode+".normalCamera", d=False, s=True, p=True)
            if conectList:
                cmds.disconnectAttr(conectList[0],surfaceNode+".normalCamera")
                
            conectList=cmds.listConnections( conectListCG+".displacementShader", d=False, s=True, p=True)
            if conectList:
                cmds.disconnectAttr(conectList[0],conectListCG+".displacementShader")        
            
        setAttribute(surfaceNode,"color",surface_Color)    
        setAttribute(surfaceNode,"Kd",surface_Kd)
        surfaceNode=[surfaceNode, "outColor"]
        
        if nodeTemplate == 'GPSurface':
            
            specularBlend=getAttribute(myDict.get('NodeAtributes').get('specularBlend'))
            if float(specularBlend) != 0:
                surfaceNodeAddSpec=""

                findAiSt = cmds.ls(type='aiStandard')
                for AI in findAiSt:
                    if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                        if cmds.getAttr(AI+".SlimLinkID") == nodeID + "AddSpec":
                            surfaceNodeAddSpec=AI
                            break
                    
                if surfaceNodeAddSpec=="":
                    surfaceNodeAddSpec = mel.eval("createRenderNodeCB -asShader \"surfaceShader\" aiStandard \"\"")
                    cmds.addAttr(surfaceNodeAddSpec,ln="SlimLinkID",dt="string")
                    cmds.setAttr(surfaceNodeAddSpec+".SlimLinkID",nodeID+"AddSpec",type="string")
                    cmds.addAttr(surfaceNodeAddSpec,ln="SlimLinkName",dt="string")
                    cmds.addAttr(surfaceNodeAddSpec,ln="SlimLinkTemplate",dt="string")

                if cmds.getAttr(surfaceNodeAddSpec+".SlimLinkName") != nodeName:
                    cmds.setAttr(surfaceNodeAddSpec+".SlimLinkName",nodeName,type="string")
                if cmds.getAttr(surfaceNodeAddSpec+".SlimLinkTemplate") != nodeTemplate:
                    cmds.setAttr(surfaceNodeAddSpec+".SlimLinkTemplate",nodeTemplate,type="string")
                
                setAttribute(surfaceNodeAddSpec,"Kd","0")
                setAttribute(surfaceNodeAddSpec,"emission","1")
                setAttribute(surfaceNodeAddSpec,"emissionColor",surfaceNode)
                
                setAttribute(surfaceNodeAddSpec,"specularRoughness",clampNode(multNode(multNode(getAttribute(myDict.get('NodeAtributes').get('roughnessB')),"0.5","sqrt"),1.2658)))
                setAttribute(surfaceNodeAddSpec,"Ks",multNode(getAttribute(myDict.get('NodeAtributes').get('specularGainB')),specularBlend))
                
                setAttribute(surfaceNode[0],"Ks",multNode(surface_SpecularGain,invertNode(specularBlend)))
                
                setAttribute(surfaceNodeAddSpec,"KsColor",getAttribute(myDict.get('NodeAtributes').get('specColorB')))
                setAttribute(surfaceNodeAddSpec,"specularFresnel","1")
                setAttribute(surfaceNodeAddSpec,"enableInternalReflections","0")
                
                temp=getAttribute(myDict.get('NodeAtributes').get('anisotropyB'))
                if float(temp)!=0:
                    setAttribute(surfaceNodeAddSpec,"specularBrdf","1")
                    setAttribute(surfaceNodeAddSpec,"specularRotation","0")
                    setAttribute(surfaceNodeAddSpec,"specularAnisotropy",str((float(temp)+1)/2))
                else:
                    setAttribute(surfaceNodeAddSpec,"specularBrdf","0")
                
                temp=float(getAttribute(myDict.get('NodeAtributes').get('ior')))
                ior=str(math.log(math.sqrt(temp),10) * 0.25)

                setAttribute(surfaceNodeAddSpec,"Ksn",ior)

                surfaceNode=[surfaceNodeAddSpec, "outColor"]
                


    elif nodeTemplate == 'SLBox':
        surfaceNode="0"
        
    elif nodeTemplate == 'ColorToGray':
        print '\nColorToGray\n'
        surfaceNode=DictionariesRecurce(myDict.get('NodeAtributes').get('InputColor'),"")    

    elif nodeTemplate == 'Correct':
        print '\nCorrect\n'
        surfaceNode=DictionariesRecurce(myDict.get('NodeAtributes').get('Input'),"")    
    
    elif nodeTemplate == 'SurfacePt':
        print '\nSurfacePt\n'
        temp=getAttribute(myDict.get('NodeAtributes').get('Space'))
        surfaceNode=temp
        if temp!="":
            print "\nSurfacePt temp: "+temp+"\n"
            temp1=''
            mat=re.search("\[mel",temp)
            if mat:
                temp1 = slovarik.get(key)[0]
                temp1=re.sub("\$OBJNAME",temp1,temp)
                mat=re.search("\[mel \"(?P<one>.*)\"]",temp1)
                
                temp1=re.sub("\\\\\"","\"",mat.group('one'))
                if mat.group('one')!='':
                    temp1=mel.eval(temp1)
                    surfaceNode=[temp1,"worldInverseMatrix"]
        else:
            surfaceNode=[]
        
    elif nodeTemplate == 'Projection':
        print '\nProjection\n'
        surfaceNode=""
        findAiSt = cmds.ls(type='projection')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('projection',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")

        temp=getAttribute(myDict.get('NodeAtributes').get('Qin'))
        
        cmds.setAttr(surfaceNode+".projType",3)
        cmds.setAttr(surfaceNode+".uAngle",360)

        if type(temp)==type([]):
            test=cmds.ls(temp[0]+"|Arnold")
            print "\n\ntest: "+str(test)+"\n\n"
            if test == []:
                temp[0]=cmds.group(em=True,p=temp[0],n='Arnold')
            else:
                temp[0]=test[0]
            
            cmds.setAttr(temp[0]+".scaleZ",-1)
            setAttribute(surfaceNode,"placementMatrix",temp)
        
        surfaceNode=[surfaceNode, "outColor"]        
        
    elif nodeTemplate == 'Remap':
        print '\nRemap\n'
        surfaceNode=""
        exitsBias = getAttribute(myDict.get('NodeAtributes').get('Bias'))
        exitsGain = getAttribute(myDict.get('NodeAtributes').get('Gain'))
        baisDa=0
        gainDa=0
        print "\n\n" + str(exitsBias) + "  " + str(exitsGain) + "\n\n"
        temp=exitsBias.strip().split(" ")
        if (len(temp)==1 and (type(exitsBias) != type("") or float(temp[0]) != 0.5)) or (len(temp)==3 and (type(exitsBias) != type("") or float(temp[0]) != 0.5 or float(temp[1]) != 0.5 or float(temp[2]) != 0.5)):
        #if exitsBias != "0.500 0.500 0.500":
            baisDa=1
        temp=exitsGain.strip().split(" ")            
        if (len(temp)==1 and (type(exitsGain) != type("") or float(temp[0]) != 0.5)) or (len(temp)==3 and (type(exitsGain) != type("") or float(temp[0]) != 0.5 or float(temp[1]) != 0.5 or float(temp[2]) != 0.5)):            
        #if exitsGain != "0.500 0.500 0.500":    
            gainDa=1
        
        if baisDa==0 and gainDa==0:
            return DictionariesRecurce(myDict.get('NodeAtributes').get('Input'),"")    
        else:
            findAiSt = cmds.ls(type='clamp')
            for AI in findAiSt:
                if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                    if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                        surfaceNode=AI
                        break
            
            if surfaceNode=="":
                surfaceNode=cmds.shadingNode('clamp',asUtility=True)
                cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
                cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
                cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
                cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")
            if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
                cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
            if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
                cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")

            setAttribute(surfaceNode,"maxR","1")       
            setAttribute(surfaceNode,"maxG","1")       
            setAttribute(surfaceNode,"maxB","1")       
            input=getAttribute(myDict.get('NodeAtributes').get('Input'))
            if input == None:
                input=getAttribute(myDict.get('NodeAtributes').get('input'))
                
            temp=input
            
            if baisDa == 1:
                temp=biasColor(nodeID,nodeName,nodeTemplate,exitsBias,input)
            if gainDa == 1:
                temp=gainColor(nodeID,nodeName,nodeTemplate,exitsGain,temp,surfaceNode)
            
            
            setAttribute(surfaceNode,"input",temp)       
            surfaceNode=[surfaceNode, "output"]

    elif nodeTemplate == 'FacingForward' or nodeTemplate == 'FacingDirection':
        print '\n'+nodeTemplate+'\n'
        surfaceNode=""
        multiplyDivide=""
        samplerInfo=""
        
        findAiSt = cmds.ls(type='ramp')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('ramp',asUtility=True)
            multiplyDivide=cmds.shadingNode('multiplyDivide',asUtility=True)
            samplerInfo=cmds.shadingNode('samplerInfo',asUtility=True)

            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide,ln="SlimLinkID",dt="string")
            cmds.addAttr(multiplyDivide,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(samplerInfo,ln="SlimLinkID",dt="string")
            cmds.addAttr(samplerInfo,ln="SlimLinkName",dt="string")
            cmds.addAttr(samplerInfo,ln="SlimLinkTemplate",dt="string")
        else:
            md=cmds.listConnections(surfaceNode+".vCoord", d=False, s=True)
            si=cmds.listConnections(md[0]+".input1X", d=False, s=True)
            multiplyDivide=md[0]
            samplerInfo=si[0]
        
        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(samplerInfo+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(samplerInfo+".SlimLinkTemplate",nodeTemplate,type="string")
    
        
        
        setAttribute(multiplyDivide,"operation","3")
        setAttribute(multiplyDivide,"input2X",getAttribute(myDict.get('NodeAtributes').get('Attenuation')))
        setAttribute(multiplyDivide,"input1X",[samplerInfo,"facingRatio"])
        setAttribute(surfaceNode,"vCoord",[multiplyDivide,"outputX"])
        
        mel.eval("removeMultiInstance -break true "+surfaceNode+".colorEntryList[1]")
        cmds.setAttr(surfaceNode+".colorEntryList[2].color",1,1,1)
        cmds.setAttr(surfaceNode+".colorEntryList[2].position",1)
        cmds.setAttr(surfaceNode+".colorEntryList[0].color",0,0,0)

        
        surfaceNode=[surfaceNode, "outColor"]    
        
        temp=getAttribute(myDict.get('NodeAtributes').get('Invert'))
        if float(temp)==1:
            surfaceNode=invertNode(surfaceNode)
    
        temp=getAttribute(myDict.get('NodeAtributes').get('Clamp'))
        if float(temp)==1:
            surfaceNode=clampNode(surfaceNode)
    
        
    
    elif nodeTemplate == 'LinearizesRGB':
        print '\nLinearizesRGB\n'
        #surfaceNode=DictionariesRecurce(myDict.get('NodeAtributes').get('Input'),"")
        
        surfaceNode=""
        
        findAiSt = cmds.ls(type='gammaCorrect')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('gammaCorrect',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
    
            
        temp=getAttribute(myDict.get('NodeAtributes').get('Disable'))
        if temp=="1":
            cmds.setAttr(surfaceNode+".gammaX",1)
            cmds.setAttr(surfaceNode+".gammaY",1)
            cmds.setAttr(surfaceNode+".gammaZ",1)
        else:
            cmds.setAttr(surfaceNode+".gammaX",0.4545) #0.4545
            cmds.setAttr(surfaceNode+".gammaY",0.4545)
            cmds.setAttr(surfaceNode+".gammaZ",0.4545)

        setAttribute(surfaceNode,"value",getAttribute(myDict.get('NodeAtributes').get('Input')))
        
        
        surfaceNode=[surfaceNode, "outValue"]

    elif nodeTemplate == 'Multiply':
        print '\nMultiply\n'
        
        surfaceNode=""
        
        findAiSt = cmds.ls(type='multiplyDivide')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('multiplyDivide',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
    
            
        cmds.setAttr(surfaceNode+".operation",1)
        
        inputA=getAttribute(myDict.get('NodeAtributes').get('colorA'))
        if inputA == None:
            inputA=getAttribute(myDict.get('NodeAtributes').get('floatA'))
        inputB=getAttribute(myDict.get('NodeAtributes').get('colorB'))
        if inputB == None:
            inputB=getAttribute(myDict.get('NodeAtributes').get('floatB'))
            
        setAttribute(surfaceNode,"input1",inputA)
        setAttribute(surfaceNode,"input2",inputB)
        
        surfaceNode=[surfaceNode, "output"]

    elif nodeTemplate == 'Invert':
        print '\nInvert\n'
        
        surfaceNode=""
        
        findAiSt = cmds.ls(type='reverse')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('reverse',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
    
        setAttribute(surfaceNode,"input",getAttribute(myDict.get('NodeAtributes').get('input')))
        
        surfaceNode=[surfaceNode, "output"]
        
    elif nodeTemplate == 'Clamp':
        print '\nClamp\n'
        surfaceNode=""
        findAiSt = cmds.ls(type='clamp')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('clamp',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
    
        cmds.setAttr(surfaceNode+".maxR",getAttribute(myDict.get('NodeAtributes').get('max')))
        cmds.setAttr(surfaceNode+".maxG",getAttribute(myDict.get('NodeAtributes').get('max')))
        cmds.setAttr(surfaceNode+".maxB",getAttribute(myDict.get('NodeAtributes').get('max')))
        cmds.setAttr(surfaceNode+".minR",getAttribute(myDict.get('NodeAtributes').get('min')))
        cmds.setAttr(surfaceNode+".minG",getAttribute(myDict.get('NodeAtributes').get('min')))
        cmds.setAttr(surfaceNode+".minB",getAttribute(myDict.get('NodeAtributes').get('min')))
        setAttribute(surfaceNode,"input",getAttribute(myDict.get('NodeAtributes').get('input')))
        
        surfaceNode=[surfaceNode, "output"]
        
    elif nodeTemplate == 'Noise':
        print '\nNoise\n'
        surfaceNode=""
        findAiSt = cmds.ls(type='aiNoise')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.shadingNode('aiNoise',asUtility=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
    
        setAttribute(surfaceNode,"scaleX",getAttribute(myDict.get('NodeAtributes').get('frequency')))
        setAttribute(surfaceNode,"scaleY",getAttribute(myDict.get('NodeAtributes').get('frequency')))
        setAttribute(surfaceNode,"scaleZ",getAttribute(myDict.get('NodeAtributes').get('frequency')))
        
        surfaceNode=[surfaceNode, "outValue"]        
        
    elif nodeTemplate == 'MixColors' or nodeTemplate == 'Mix':
        print "\n"+nodeTemplate+"\n"

        plusMinusAverage2=""
        multiplyDivide2=""    
        multiplyDivide3=""
        plusMinusAverage3=""
        
        
        findAiSt = cmds.ls(type='plusMinusAverage')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    plusMinusAverage3=AI
                    break
            
        if plusMinusAverage3=="":
            multiplyDivide2=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide3=cmds.shadingNode('multiplyDivide',asUtility=True)
            plusMinusAverage2=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage3=cmds.shadingNode('plusMinusAverage',asUtility=True)
            
           
            cmds.addAttr(plusMinusAverage3,ln="SlimLinkID",dt="string")
            cmds.setAttr(plusMinusAverage3+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(plusMinusAverage3,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage3,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide2,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide2,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide3,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide3,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage2,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage2,ln="SlimLinkTemplate",dt="string")
        else:
            print plusMinusAverage3
            multiplyDivide3=cmds.listConnections(plusMinusAverage3+".input3D[0]", d=False, s=True)[0]            
            multiplyDivide2=cmds.listConnections(plusMinusAverage3+".input3D[1]", d=False, s=True)[0]            
            plusMinusAverage=cmds.listConnections(multiplyDivide2+".input1", d=False, s=True)[0]            
            plusMinusAverage2=cmds.listConnections(multiplyDivide2+".input2", d=False, s=True)[0]            
            
        if cmds.getAttr(plusMinusAverage3+".SlimLinkName") != nodeName:
            cmds.setAttr(multiplyDivide2+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide3+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage2+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage3+".SlimLinkName",nodeName,type="string")
            
        if cmds.getAttr(plusMinusAverage3+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(multiplyDivide2+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide3+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage2+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage3+".SlimLinkTemplate",nodeTemplate,type="string")


        cmds.setAttr(plusMinusAverage2+".operation",2)
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dx",1)        
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dy",1)        
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dz",1)        
        
        inputA=getAttribute(myDict.get('NodeAtributes').get('ca'))
        if inputA == None:
            inputA=getAttribute(myDict.get('NodeAtributes').get('inputA'))
            
        inputB=getAttribute(myDict.get('NodeAtributes').get('cb'))
        if inputB == None:
            inputB=getAttribute(myDict.get('NodeAtributes').get('inputB'))
            
        Amount=getAttribute(myDict.get('NodeAtributes').get('pct'))
        if Amount == None:
            Amount=getAttribute(myDict.get('NodeAtributes').get('Amount'))
            
        setAttribute(plusMinusAverage2,"input3D[1].input3Dx",Amount)
        setAttribute(plusMinusAverage2,"input3D[1].input3Dy",Amount)
        setAttribute(plusMinusAverage2,"input3D[1].input3Dz",Amount)    
        
        cmds.setAttr(multiplyDivide2+".operation",1)
        setAttribute(multiplyDivide2,"input2",[plusMinusAverage2,"output3D"])
        setAttribute(multiplyDivide2,"input1",inputA)
        
        cmds.setAttr(multiplyDivide3+".operation",1)
        setAttribute(multiplyDivide3,"input1",inputB)
        setAttribute(multiplyDivide3,"input2X",Amount)
        setAttribute(multiplyDivide3,"input2Y",Amount)
        setAttribute(multiplyDivide3,"input2Z",Amount)       
                
        cmds.setAttr(plusMinusAverage3+".operation",1)
        setAttribute(plusMinusAverage3,"input3D[1]",[multiplyDivide2,"output"])
        setAttribute(plusMinusAverage3,"input3D[0]",[multiplyDivide3,"output"])
        
        
        surfaceNode=[plusMinusAverage3, "output3D"]
        
    elif nodeTemplate == 'Adjust':
        print '\nAdjust\n'

        multiplyDivide=""
        plusMinusAverage=""
        plusMinusAverage2=""
        multiplyDivide2=""    
        multiplyDivide3=""
        plusMinusAverage3=""
        multiplyDivide4=""
        plusMinusAverage4=""
        multiplyDivide5=""
        plusMinusAverage5=""
        clamp=""
        multiplyDivide6=""
        plusMinusAverage6=""
        multiplyDivide7=""
        plusMinusAverage7=""
        multiplyDivide8=""    
        
        
        findAiSt = cmds.ls(type='multiplyDivide')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    multiplyDivide8=AI
                    break
            
        if multiplyDivide8=="":
            multiplyDivide=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide2=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide3=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide4=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide5=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide6=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide7=cmds.shadingNode('multiplyDivide',asUtility=True)
            multiplyDivide8=cmds.shadingNode('multiplyDivide',asUtility=True)
            plusMinusAverage=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage2=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage3=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage4=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage5=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage6=cmds.shadingNode('plusMinusAverage',asUtility=True)
            plusMinusAverage7=cmds.shadingNode('plusMinusAverage',asUtility=True)
            clamp=cmds.shadingNode('clamp',asUtility=True)
            
           
            cmds.addAttr(multiplyDivide8,ln="SlimLinkID",dt="string")
            cmds.setAttr(multiplyDivide8+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(multiplyDivide8,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide8,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide2,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide2,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide3,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide3,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide4,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide4,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide5,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide5,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide6,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide6,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(multiplyDivide7,ln="SlimLinkName",dt="string")
            cmds.addAttr(multiplyDivide7,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage2,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage2,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage3,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage3,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage4,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage4,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage5,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage5,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage6,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage6,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(plusMinusAverage7,ln="SlimLinkName",dt="string")
            cmds.addAttr(plusMinusAverage7,ln="SlimLinkTemplate",dt="string")
            cmds.addAttr(clamp,ln="SlimLinkName",dt="string")
            cmds.addAttr(clamp,ln="SlimLinkTemplate",dt="string")
        else:
            plusMinusAverage7=cmds.listConnections(multiplyDivide8+".input1", d=False, s=True)[0]
            multiplyDivide7=cmds.listConnections(plusMinusAverage7+".input3D[1]", d=False, s=True)[0]
            multiplyDivide6=cmds.listConnections(plusMinusAverage7+".input3D[0]", d=False, s=True)[0]
            plusMinusAverage5=cmds.listConnections(multiplyDivide7+".input1", d=False, s=True)[0]
            plusMinusAverage6=cmds.listConnections(multiplyDivide7+".input2", d=False, s=True)[0]
            clamp=cmds.listConnections(multiplyDivide6+".input1", d=False, s=True)[0]            
            plusMinusAverage5=cmds.listConnections(clamp+".input", d=False, s=True)[0]            
            multiplyDivide4=cmds.listConnections(plusMinusAverage5+".input3D[0]", d=False, s=True)[0]            
            multiplyDivide5=cmds.listConnections(plusMinusAverage5+".input3D[1]", d=False, s=True)[0]            
            plusMinusAverage4=cmds.listConnections(multiplyDivide5+".input2", d=False, s=True)[0]            
            plusMinusAverage3=cmds.listConnections(multiplyDivide4+".input1", d=False, s=True)[0]            
            multiplyDivide3=cmds.listConnections(plusMinusAverage3+".input3D[0]", d=False, s=True)[0]            
            multiplyDivide2=cmds.listConnections(plusMinusAverage3+".input3D[1]", d=False, s=True)[0]            
            plusMinusAverage=cmds.listConnections(multiplyDivide2+".input1Z", d=False, s=True)[0]            
            plusMinusAverage2=cmds.listConnections(multiplyDivide2+".input2", d=False, s=True)[0]            
            multiplyDivide=cmds.listConnections(plusMinusAverage+".input3D[0].input3Dx", d=False, s=True)[0]                        
            
        if cmds.getAttr(multiplyDivide8+".SlimLinkName") != nodeName:
            cmds.setAttr(multiplyDivide8+".SlimLinkName",nodeName,type="string")            
            cmds.setAttr(multiplyDivide+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide2+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide3+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide4+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide5+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide6+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(multiplyDivide7+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage2+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage3+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage4+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage5+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage6+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(plusMinusAverage7+".SlimLinkName",nodeName,type="string")
            cmds.setAttr(clamp+".SlimLinkName",nodeName,type="string")
            
        if cmds.getAttr(multiplyDivide8+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(multiplyDivide+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide2+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide3+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide4+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide5+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide6+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide7+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(multiplyDivide8+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage2+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage3+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage4+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage5+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage6+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(plusMinusAverage7+".SlimLinkTemplate",nodeTemplate,type="string")
            cmds.setAttr(clamp+".SlimLinkTemplate",nodeTemplate,type="string")
    

        cmds.setAttr(multiplyDivide+".operation",1)
        setAttribute(multiplyDivide,"input1",getAttribute(myDict.get('NodeAtributes').get('Input')))
        cmds.setAttr(multiplyDivide+".input2X",0.2125)
        cmds.setAttr(multiplyDivide+".input2Y",0.7154)
        cmds.setAttr(multiplyDivide+".input2Z",0.0721)        
        
        cmds.setAttr(plusMinusAverage+".operation",1)
        setAttribute(plusMinusAverage,"input3D[0].input3Dx",[multiplyDivide,"outputX"])
        setAttribute(plusMinusAverage,"input3D[1].input3Dx",[multiplyDivide,"outputY"])
        setAttribute(plusMinusAverage,"input3D[2].input3Dx",[multiplyDivide,"outputZ"])

        cmds.setAttr(plusMinusAverage2+".operation",2)
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dx",1)        
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dy",1)        
        cmds.setAttr(plusMinusAverage2+".input3D[0].input3Dz",1)        
        setAttribute(plusMinusAverage2,"input3D[1].input3Dx",getAttribute(myDict.get('NodeAtributes').get('Saturation')))
        setAttribute(plusMinusAverage2,"input3D[1].input3Dy",getAttribute(myDict.get('NodeAtributes').get('Saturation')))
        setAttribute(plusMinusAverage2,"input3D[1].input3Dz",getAttribute(myDict.get('NodeAtributes').get('Saturation')))    
        
        cmds.setAttr(multiplyDivide2+".operation",1)
        setAttribute(multiplyDivide2,"input2",[plusMinusAverage2,"output3D"])
        setAttribute(multiplyDivide2,"input1X",[plusMinusAverage,"output3Dx"])
        setAttribute(multiplyDivide2,"input1Y",[plusMinusAverage,"output3Dx"])
        setAttribute(multiplyDivide2,"input1Z",[plusMinusAverage,"output3Dx"])       
        
        cmds.setAttr(multiplyDivide3+".operation",1)
        setAttribute(multiplyDivide3,"input1",getAttribute(myDict.get('NodeAtributes').get('Input')))
        setAttribute(multiplyDivide3,"input2X",getAttribute(myDict.get('NodeAtributes').get('Saturation')))
        setAttribute(multiplyDivide3,"input2Y",getAttribute(myDict.get('NodeAtributes').get('Saturation')))
        setAttribute(multiplyDivide3,"input2Z",getAttribute(myDict.get('NodeAtributes').get('Saturation')))       
                
        cmds.setAttr(plusMinusAverage3+".operation",1)
        setAttribute(plusMinusAverage3,"input3D[1]",[multiplyDivide2,"output"])
        setAttribute(plusMinusAverage3,"input3D[0]",[multiplyDivide3,"output"])
        
        cmds.setAttr(multiplyDivide4+".operation",1)
        setAttribute(multiplyDivide4,"input1",[plusMinusAverage3,"output3D"])
        setAttribute(multiplyDivide4,"input2X",getAttribute(myDict.get('NodeAtributes').get('Contrast')))
        setAttribute(multiplyDivide4,"input2Y",getAttribute(myDict.get('NodeAtributes').get('Contrast')))
        setAttribute(multiplyDivide4,"input2Z",getAttribute(myDict.get('NodeAtributes').get('Contrast')))       
        
        cmds.setAttr(plusMinusAverage4+".operation",2)
        cmds.setAttr(plusMinusAverage4+".input3D[0].input3Dx",1)        
        cmds.setAttr(plusMinusAverage4+".input3D[0].input3Dy",1)        
        cmds.setAttr(plusMinusAverage4+".input3D[0].input3Dz",1)        
        setAttribute(plusMinusAverage4,"input3D[1].input3Dx",getAttribute(myDict.get('NodeAtributes').get('Contrast')))
        setAttribute(plusMinusAverage4,"input3D[1].input3Dy",getAttribute(myDict.get('NodeAtributes').get('Contrast')))
        setAttribute(plusMinusAverage4,"input3D[1].input3Dz",getAttribute(myDict.get('NodeAtributes').get('Contrast')))        

        cmds.setAttr(multiplyDivide5+".operation",1)
        setAttribute(multiplyDivide5,"input2",[plusMinusAverage4,"output3D"])
        setAttribute(multiplyDivide5,"input1X",getAttribute(myDict.get('NodeAtributes').get('MidPoint')))
        setAttribute(multiplyDivide5,"input1Y",getAttribute(myDict.get('NodeAtributes').get('MidPoint')))
        setAttribute(multiplyDivide5,"input1Z",getAttribute(myDict.get('NodeAtributes').get('MidPoint')))       

        cmds.setAttr(plusMinusAverage5+".operation",1)
        setAttribute(plusMinusAverage5,"input3D[1]",[multiplyDivide5,"output"])
        setAttribute(plusMinusAverage5,"input3D[0]",[multiplyDivide4,"output"])        

        cmds.setAttr(clamp+".maxR",1)
        cmds.setAttr(clamp+".maxG",1)
        cmds.setAttr(clamp+".maxB",1)    
        setAttribute(clamp,"input",[plusMinusAverage5,"output3D"])        

        cmds.setAttr(multiplyDivide6+".operation",1)
        setAttribute(multiplyDivide6,"input1",[clamp,"output"])
        setAttribute(multiplyDivide6,"input2X",getAttribute(myDict.get('NodeAtributes').get('Clamp')))
        setAttribute(multiplyDivide6,"input2Y",getAttribute(myDict.get('NodeAtributes').get('Clamp')))
        setAttribute(multiplyDivide6,"input2Z",getAttribute(myDict.get('NodeAtributes').get('Clamp')))       

        cmds.setAttr(plusMinusAverage6+".operation",2)
        cmds.setAttr(plusMinusAverage6+".input3D[0].input3Dx",1)        
        cmds.setAttr(plusMinusAverage6+".input3D[0].input3Dy",1)        
        cmds.setAttr(plusMinusAverage6+".input3D[0].input3Dz",1)        
        setAttribute(plusMinusAverage6,"input3D[1].input3Dx",getAttribute(myDict.get('NodeAtributes').get('Clamp')))
        setAttribute(plusMinusAverage6,"input3D[1].input3Dy",getAttribute(myDict.get('NodeAtributes').get('Clamp')))
        setAttribute(plusMinusAverage6,"input3D[1].input3Dz",getAttribute(myDict.get('NodeAtributes').get('Clamp')))        

        cmds.setAttr(multiplyDivide7+".operation",1)
        setAttribute(multiplyDivide7,"input2",[plusMinusAverage6,"output3D"])
        setAttribute(multiplyDivide7,"input1",[plusMinusAverage5,"output3D"])
       
        cmds.setAttr(plusMinusAverage7+".operation",1)
        setAttribute(plusMinusAverage7,"input3D[1]",[multiplyDivide7,"output"])
        setAttribute(plusMinusAverage7,"input3D[0]",[multiplyDivide6,"output"])        

        cmds.setAttr(multiplyDivide8+".operation",1)
        setAttribute(multiplyDivide8,"input2",getAttribute(myDict.get('NodeAtributes').get('Tint')))
        setAttribute(multiplyDivide8,"input1",[plusMinusAverage7,"output3D"])
        
        surfaceNode=[multiplyDivide8, "output"]
        
    elif nodeTemplate == 'MayaImageFile' or nodeTemplate == 'sdMayaImageMultUVFile' or nodeTemplate == 'sdF_MayaImageMultUVFile' or nodeTemplate == 'PtexColor' or nodeTemplate == 'TextureAtlas':
        print '\n'+nodeTemplate+'\n'
        #DictionariesRecurce(myDict.get('NodeAtributes'),"")    
        #place2dTexture=""
        surfaceNode=""
        
        findAiSt = cmds.ls(type='aiImage')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    #place2dTexture = cmds.listConnections( AI+".mirrorV", d=False, s=True)
                    break
            
        if surfaceNode=="":
            surfaceNode=cmds.createNode("aiImage")
            '''surfaceNode=cmds.shadingNode('file',asTexture=True)
            place2dTexture=cmds.shadingNode('place2dTexture',asUtility=True)
            cmds.connectAttr(place2dTexture+".coverage" ,surfaceNode+".coverage",f=True)
            cmds.connectAttr(place2dTexture+".translateFrame" ,surfaceNode+".translateFrame",f=True)
            cmds.connectAttr(place2dTexture+".rotateFrame" ,surfaceNode+".rotateFrame",f=True)
            cmds.connectAttr(place2dTexture+".mirrorU" ,surfaceNode+".mirrorU",f=True)
            cmds.connectAttr(place2dTexture+".mirrorV" ,surfaceNode+".mirrorV",f=True)
            cmds.connectAttr(place2dTexture+".stagger" ,surfaceNode+".stagger",f=True)
            cmds.connectAttr(place2dTexture+".wrapU" ,surfaceNode+".wrapU",f=True)
            cmds.connectAttr(place2dTexture+".wrapV" ,surfaceNode+".wrapV",f=True)
            cmds.connectAttr(place2dTexture+".repeatUV" ,surfaceNode+".repeatUV",f=True)
            cmds.connectAttr(place2dTexture+".offset" ,surfaceNode+".offset",f=True)
            cmds.connectAttr(place2dTexture+".rotateUV" ,surfaceNode+".rotateUV",f=True)
            cmds.connectAttr(place2dTexture+".noiseUV" ,surfaceNode+".noiseUV",f=True)
            cmds.connectAttr(place2dTexture+".vertexUvOne" ,surfaceNode+".vertexUvOne",f=True)
            cmds.connectAttr(place2dTexture+".vertexUvTwo" ,surfaceNode+".vertexUvTwo",f=True)
            cmds.connectAttr(place2dTexture+".vertexUvThree" ,surfaceNode+".vertexUvThree",f=True)
            cmds.connectAttr(place2dTexture+".vertexCameraOne" ,surfaceNode+".vertexCameraOne",f=True)
            cmds.connectAttr(place2dTexture+".outUV" ,surfaceNode+".uv",f=True)
            cmds.connectAttr(place2dTexture+".outUvFilterSize" ,surfaceNode+".uvFilterSize",f=True)
            '''
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")

        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")
        
        #setAttr -type "string" file1.fileTextureName "as";
        #temp=getAttribute(myDict.get('NodeAtributes').get('File'))
        #temp=re.sub("[\'\[\]]","",temp)
        #temp=mel.eval("rman subst \"[workspace ResolvePath "+temp+"]\"")
        
        fileList=[]
        
        for k in myDict.get('NodeAtributes').keys():
            m=re.match("File",k)
            if m and myDict.get('NodeAtributes').get(k)!='':
                fileList.append(k)

        rezFile=""
        
        for fi in fileList:
            initFile=[""]
            initFile[0]=getAttribute(myDict.get('NodeAtributes').get(fi))
            initFile[0]="/".join(initFile[0].split("\\"))
        
            
            pathd=initFile[0].split("/")
            pathd=pathd[-1]
            pathd2=re.sub("MAPID_","*",pathd)
            if pathd != pathd2:
                temp1=initFile[0].split("/")
                temp2="/".join(temp1[:-1])
                #temp2=mel.eval("rman subst \"[workspace ResolvePath "+temp2+"]\"")
                temp2=pathResolve(temp2)
                initFile[0] = temp2 + '/' + re.sub("MAPID_","<udim>",pathd)
                files = glob.glob(temp2+'/'+pathd2)
                if len(files)!=0:
                    initFile=files

            print "initFile: "+str(initFile)
            for fff in initFile:
                #f=mel.eval("rman subst \"[workspace ResolvePath "+fff+"]\"")
                f=pathResolve(fff)
                if f == '':
                    f=fff
                f="/".join(f.split("\\"))
                rezFile=f
                paths="/".join(f.split("/")[:-1])
                findFile=f
                files=f.split(".")[0]+".*"
                #os.chdir(paths)
                for files in glob.glob(files):
                    if files.split(".")[-1]=="tiff" or files.split(".")[-1]=="tif" or files.split(".")[-1]=="exr":
                        print files
                        findFile=files
                        rezFile=files
                        break

                if findFile!="":
                    dsdsTemp=findFile.split("/")
                    mat=re.search("u(?P<one>[0-9]?)_v(?P<two>[0-9]?)",dsdsTemp[-1])
                    if mat:
                        if mat.group('one')!='' and mat.group('two')!='':
                            tmp=dsdsTemp[-1]
                            dsdsTemp[-1]=re.sub("\.\w*$",".tx",re.sub("u[0-9]_v[0-9]?","10"+str(int(mat.group('two'))-1)+mat.group('one'),dsdsTemp[-1]))
                            replace="-o "+"/".join(dsdsTemp)+" "
                            dsdsTemp[-1]=re.sub("\.\w*$",".tx",re.sub("u[0-9]_v[0-9]?",'<udim>',tmp))                    
                            rezFile="/".join(dsdsTemp)
                            print "replace: "+replace
                            print "rezFile: "+rezFile
                    else:
                        dsdsTemp[-1]=re.sub("\.\w*$",".tx",dsdsTemp[-1])
                        replace="-o "+"/".join(dsdsTemp)+" "
                        rezFile=findFile
                    os.system ("\"//Server-3d/Project/lib/soft/maketx.exe\" -u -oiio --filter lanczos3 --constant-color-detect --monochrome-detect "+replace+findFile)
        
        if rezFile!="":
            setAttribute(surfaceNode,"filename",rezFile)

        temp=getAttribute(myDict.get('NodeAtributes').get('Disable'))
        if temp == None:
            temp=getAttribute(myDict.get('NodeAtributes').get('Linearize'))        
        
        if temp == "1":
            gammaCorrect=""
            findAiSt = cmds.ls(type='gammaCorrect')
            for AI in findAiSt:
                if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                    if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                        gammaCorrect=AI
                        break
                        
            if gammaCorrect == "":
                gammaCorrect=cmds.shadingNode('gammaCorrect',asUtility=True)
                cmds.addAttr(gammaCorrect,ln="SlimLinkID",dt="string")
                cmds.setAttr(gammaCorrect+".SlimLinkID",nodeID,type="string")
                cmds.addAttr(gammaCorrect,ln="SlimLinkName",dt="string")
                cmds.addAttr(gammaCorrect,ln="SlimLinkTemplate",dt="string")
                
            if cmds.getAttr(gammaCorrect+".SlimLinkName") != nodeName:
                cmds.setAttr(gammaCorrect+".SlimLinkName",nodeName,type="string")
            if cmds.getAttr(gammaCorrect+".SlimLinkTemplate") != nodeTemplate:
                cmds.setAttr(gammaCorrect+".SlimLinkTemplate",nodeTemplate,type="string")

            cmds.setAttr(gammaCorrect+".gammaX",0.4545)
            cmds.setAttr(gammaCorrect+".gammaY",0.4545)
            cmds.setAttr(gammaCorrect+".gammaZ",0.4545)
            
            setAttribute(gammaCorrect,"value",[surfaceNode, "outColor"])
            surfaceNode=[gammaCorrect, "outValue"]
        else:
            surfaceNode=[surfaceNode, "outColor"]
            
       
       
        temp=getAttribute(myDict.get('NodeAtributes').get('Q'))
        if temp!="":
            setAttribute(temp[0],"image",surfaceNode)
            
            place2dTexture=""
            findAiSt = cmds.ls(type='place2dTexture')
            for AI in findAiSt:
                if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                    if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                        place2dTexture=AI
                        break
                
            if place2dTexture=="":
                place2dTexture=cmds.shadingNode('place2dTexture',asUtility=True)
                cmds.addAttr(place2dTexture,ln="SlimLinkID",dt="string")
                cmds.setAttr(place2dTexture+".SlimLinkID",nodeID,type="string")
                cmds.addAttr(place2dTexture,ln="SlimLinkName",dt="string")
                cmds.addAttr(place2dTexture,ln="SlimLinkTemplate",dt="string")
            else:
                prom=surfaceNode
                if type(surfaceNode)==type([]):
                    prom=surfaceNode[0]
                place2dTexture = cmds.listConnections( prom+".uvcoords", d=False, s=True)[0]
            
            if cmds.getAttr(place2dTexture+".SlimLinkName") != nodeName:
                cmds.setAttr(place2dTexture+".SlimLinkName",nodeName,type="string")
            if cmds.getAttr(place2dTexture+".SlimLinkTemplate") != nodeTemplate:
                cmds.setAttr(place2dTexture+".SlimLinkTemplate",nodeTemplate,type="string")

            setAttribute(surfaceNode[0],"uvcoords",[place2dTexture, "uvCoord"])
            cmds.setAttr(place2dTexture+".wrapU",0)
            cmds.setAttr(place2dTexture+".wrapV",0)
            

            temp1=getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('flipS'))
            if temp1 == "1":
                cmds.setAttr(place2dTexture+".repeatU",-1)
            
            temp1=getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('flipT'))
            if temp1 == "0":
                cmds.setAttr(place2dTexture+".repeatV",-1)


            repeatS=float(getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('repeatS')))
            repeatT=float(getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('repeatT')))
            offsetS=float(getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('offsetS')))
            offsetT=float(getAttribute(myDict.get('NodeAtributes').get('Q').get('NodeAtributes').get('offsetT')))
                
            setAttribute(place2dTexture,"coverageU",str(1/repeatS))
            setAttribute(place2dTexture,"translateFrameU",str(-1*offsetS/repeatS))
            setAttribute(place2dTexture,"coverageV",str(0.5/repeatT))
            setAttribute(place2dTexture,"translateFrameV",str(0.25-offsetT/(repeatT*2)))
                
            surfaceNode=temp
        
        exitsBias = getAttribute(myDict.get('NodeAtributes').get('ColorBias'))
        exitsGain = getAttribute(myDict.get('NodeAtributes').get('ColorGain'))
        if exitsBias != None:
            baisDa=0
            gainDa=0
            temp=exitsBias.strip().split(" ")
            if (len(temp)==1 and (type(exitsBias) != type("") or float(temp[0]) != 0.5)) or (len(temp)==3 and (type(exitsBias) != type("") or float(temp[0]) != 0.5 or float(temp[1]) != 0.5 or float(temp[2]) != 0.5)):
                baisDa=1
            temp=exitsGain.strip().split(" ")            
            if (len(temp)==1 and (type(exitsGain) != type("") or float(temp[0]) != 0.5)) or (len(temp)==3 and (type(exitsGain) != type("") or float(temp[0]) != 0.5 or float(temp[1]) != 0.5 or float(temp[2]) != 0.5)):            
                gainDa=1
            
            if baisDa!=0 or gainDa!=0:
                print 'internal remap'
                surfaceNodeRemap=""        
                findAiSt = cmds.ls(type='clamp')
                for AI in findAiSt:
                    if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                        if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                            surfaceNodeRemap=AI
                            break
                
                if surfaceNodeRemap=="":
                    surfaceNodeRemap=cmds.shadingNode('clamp',asUtility=True)
                    cmds.addAttr(surfaceNodeRemap,ln="SlimLinkID",dt="string")
                    cmds.setAttr(surfaceNodeRemap+".SlimLinkID",nodeID,type="string")
                    cmds.addAttr(surfaceNodeRemap,ln="SlimLinkName",dt="string")
                    cmds.addAttr(surfaceNodeRemap,ln="SlimLinkTemplate",dt="string")
                if cmds.getAttr(surfaceNodeRemap+".SlimLinkName") != nodeName:
                    cmds.setAttr(surfaceNodeRemap+".SlimLinkName",nodeName,type="string")
                if cmds.getAttr(surfaceNodeRemap+".SlimLinkTemplate") != nodeTemplate:
                    cmds.setAttr(surfaceNodeRemap+".SlimLinkTemplate",nodeTemplate,type="string")

                setAttribute(surfaceNodeRemap,"maxR","1")       
                setAttribute(surfaceNodeRemap,"maxG","1")       
                setAttribute(surfaceNodeRemap,"maxB","1")       
                input=surfaceNode
                temp=input
                
                if baisDa == 1:
                    temp=biasColor(nodeID,nodeName,nodeTemplate,exitsBias,input)
                if gainDa == 1:
                    temp=gainColor(nodeID,nodeName,nodeTemplate,exitsGain,temp,surfaceNodeRemap)
                
                setAttribute(surfaceNodeRemap,"input",temp)       
                surfaceNode=[surfaceNodeRemap, "output"]            
            
    
    elif nodeTemplate == 'MaterialEnsemble':        
        print '\nMaterialEnsemble\n'
        surfaceNode=""
        findAiSt = cmds.ls(type='layeredShader')
        for AI in findAiSt:
            if mel.eval("attributeExists \"SlimLinkID\" "+AI):
                if cmds.getAttr(AI+".SlimLinkID") == nodeID:
                    surfaceNode=AI
                    break
            
        if surfaceNode=="":
            surfaceNode = cmds.shadingNode('layeredShader',asShader=True)
            surfaceNodeCG = cmds.sets(renderable=True,noSurfaceShader=True,empty=True,name=surfaceNode+"CG")
            cmds.connectAttr(surfaceNode+".outColor", surfaceNodeCG+".surfaceShader",f=True)
            cmds.addAttr(surfaceNode,ln="SlimLinkID",dt="string")
            cmds.setAttr(surfaceNode+".SlimLinkID",nodeID,type="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkName",dt="string")
            cmds.addAttr(surfaceNode,ln="SlimLinkTemplate",dt="string")
        else:
            print "surfaceNode: "+surfaceNode
            for i in cmds.getAttr(surfaceNode+".inputs",mi=True):
                temppp=cmds.listConnections( surfaceNode+".inputs["+str(i)+"].color", d=False, s=True, p=True)
                if temppp:
                    cmds.disconnectAttr(temppp[0],surfaceNode+".inputs["+str(i)+"].color")
                temppp=cmds.listConnections( surfaceNode+".inputs["+str(i)+"].transparency", d=False, s=True, p=True)
                if temppp:
                    cmds.disconnectAttr(temppp[0],surfaceNode+".inputs["+str(i)+"].transparency")
                    
        if cmds.getAttr(surfaceNode+".SlimLinkName") != nodeName:
            cmds.setAttr(surfaceNode+".SlimLinkName",nodeName,type="string")
        if cmds.getAttr(surfaceNode+".SlimLinkTemplate") != nodeTemplate:
            cmds.setAttr(surfaceNode+".SlimLinkTemplate",nodeTemplate,type="string")

           
        setAttribute(surfaceNode,"inputs[0].color",getAttribute(myDict.get('NodeAtributes').get('Surface')))
        #cmds.connectAttr(getAttribute(myDict.get('NodeAtributes').get('Surface'))+".outColor",surfaceNode+".inputs[0].color",f=True)
        setAttribute(surfaceNode,"inputs[0].transparency","0 0 0")
        setAttribute(surfaceNode,"compositingFlag", "1")

        coShaders=[]
        for k in myDict.get('NodeAtributes').keys():
            m=re.match("CoShaderv",k)
            if m and myDict.get('NodeAtributes').get(k)!='':
                coShaders.append(k)
        
        #coShaders=coShaders.sort()
       
        num=1
        for cS in coShaders:
            setAttribute(surfaceNode,"inputs["+str(num)+"].color",getAttribute(myDict.get('NodeAtributes').get(cS)))
            #cmds.connectAttr(getAttribute(myDict.get('NodeAtributes').get('CoShaderv1'))+".outColor",surfaceNode+".inputs[1].color",f=True)
            setAttribute(surfaceNode,"inputs["+str(num-1)+"].transparency",getAttribute(myDict.get('NodeAtributes').get(cS).get('NodeAtributes').get('mask')))
            setAttribute(surfaceNode,"inputs["+str(num)+"].transparency","0 0 0")
            num=num+1
        
        surfaceNode=[surfaceNode, "outColor"]
    '''
    NodeAtributes = myDict.get('NodeAtributes')
    for lang in NodeAtributes:
        if type(NodeAtributes.get(lang)) == type({}):    
            #DictionariesRecurce(NodeAtributes.get(lang),"")
            #print("MIMO")
            pass
        else:
            #print(str(lang) + " = " + str(NodeAtributes.get(lang)))
            pass
    '''
    print "return: "+str(surfaceNode)
    return surfaceNode
    
