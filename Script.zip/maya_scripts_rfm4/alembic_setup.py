import rfm.slim
import maya.mel as mel
import maya.cmds as cmds
import glob
import os
import init_slim
import convertRibToGeo

def genAlembic():

    asd = mel.eval("rman workspace GetProjDir")
    fds = mel.eval("rman getvar slimPalettes")

    filesToClear = glob.glob(asd+fds+"/*")
    for fTC in filesToClear:
        try:
            os.remove(fTC)    
        except:
            print("ERROR EXEPTION REMOVE FILE: " + fTC)

    init_slim.init_slim()
    myslim = rfm.slim.GetSlim()
    ddd=myslim.Cmd("externalizeScene \""+asd+fds+"\"")



    allObjects = cmds.ls(dag=True)
    for aO in allObjects:
        if cmds.getAttr(aO+".visibility",lock=True):
            cmds.setAttr(aO+".visibility",lock=False)
        
        if  mel.eval("attributeExists(\"visibility\",\""+aO+"\")") and not mel.eval("attributeExists(\"custom_visibility\",\""+aO+"\")"):
            cmds.addAttr(aO,ln="custom_visibility",at="bool")
            cmds.setAttr(aO+".custom_visibility",keyable=True)
            cmds.setAttr(aO+".custom_visibility",cmds.getAttr(aO+".visibility"))
        cmds.setAttr(aO+".visibility", 0)

    meshObjects = cmds.ls(type="mesh",l=True)
    for mO in meshObjects:
        splitName = mO.split("|")
        lenSplitName = len(splitName)
        for lsn in range(2,lenSplitName+1):
            currentTransformSet = "|".join(splitName[:lsn])
            #print currentTransformSet
            cmds.setAttr(currentTransformSet+".visibility", 1)

        if  not mel.eval("attributeExists(\"SubDivisionMesh\",\""+mO+"\")"):
            cmds.addAttr(mO,ln="SubDivisionMesh",at="bool")
            cmds.setAttr(mO+".SubDivisionMesh",1)

    convertRibToGeo.convertRibToGeo()

    print("AbcExport -j \"-frameRange "+str(cmds.playbackOptions(q=True, ast=True))+" "+str(cmds.playbackOptions(q=True, aet=True))+" -attr doubleSided -attr custom_visibility -attrPrefix rman -noNormals -ro -uvWrite -file \\\""+asd+fds+"/archeve.abc\\\"\"")
    mel.eval("AbcExport -j \"-frameRange "+str(cmds.playbackOptions(q=True, ast=True))+" "+str(cmds.playbackOptions(q=True, aet=True))+" -attr doubleSided -attr custom_visibility -attrPrefix rman -noNormals -ro -uvWrite -file \\\""+asd+fds+"/archeve.abc\\\"\"")








def loadAlembic():

    asd = mel.eval("rman workspace GetProjDir")
    fds = mel.eval("rman getvar slimPalettes")

    init_slim.init_slim()
    myslim = rfm.slim.GetSlim()
    ddd=myslim.Cmd("externalizeScene \""+asd+fds+"\"  -load")

    print("AbcImport -mode import \""+asd+fds+"/archeve.abc\"")
    mel.eval("AbcImport -mode import \""+asd+fds+"/archeve.abc\"")

    allObjects = cmds.ls(dag=True)
    for aO in allObjects:
        if  mel.eval("attributeExists(\"visibility\",\""+aO+"\")") and mel.eval("attributeExists(\"custom_visibility\",\""+aO+"\")"):
            cmds.setAttr(aO+".visibility",cmds.getAttr(aO+".custom_visibility"))

    meshObjects = cmds.ls(type="mesh",l=True)
    for mO in meshObjects:
        if  mel.eval("attributeExists(\"rman__torattr___slimSurface\",\""+mO+"\")"):
            if  not mel.eval("attributeExists(\"cust_slimSurface\",\""+mO+"\")"):
                cmds.addAttr(mO,ln="cust_slimSurface",dt="string")

            cmds.setAttr(mO+".cust_slimSurface",cmds.getAttr(mO+".rman__torattr___slimSurface"),type="string")


def loadSlimAttributes():
    meshObjects = cmds.ls(type="mesh",l=True)
    for mO in meshObjects:
        if  mel.eval("attributeExists(\"rman__torattr___slimSurface\",\""+mO+"\")") and mel.eval("attributeExists(\"cust_slimSurface\",\""+mO+"\")"):
            cmds.setAttr(mO+".rman__torattr___slimSurface",cmds.getAttr(mO+".cust_slimSurface"),type="string")







