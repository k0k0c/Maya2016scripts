import maya.cmds as cmds
import maya.mel as mel
import re
import os

#saveAnimCurves = cmds.ls(type=["animCurveTA","animCurveTL","animCurveTU"])
#cmds.referenceQuery(saveAnimCurves[0],filename=True)
#cmds.listConnections(saveAnimCurves[0],scn=True,s=False)

def FindAlembicSceneFolder():
    sceneNameFilePath=cmds.file(query=True,sn=True).split("/")
    if len(cmds.file(query=True,sn=True,shn=True).split("."))>1:
        sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[-2]
    elif cmds.file(query=True,sn=True,shn=True)!="":
        sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[0]
    else:
        sceneNameFileName="untitled"
    indexSceneFolder=-2
    for sNFP in range (0, len(sceneNameFilePath)):
        m = re.search('^ep\d{2}sc\d{2}', sceneNameFilePath[sNFP],re.IGNORECASE)        
        if m is not None:
            indexSceneFolder=sNFP
            break
    #if indexSceneFolder==-1:
    #    indexSceneFolder=-1
        #cmds.error("Net Takoy Sceny")
    
    pathFolderForCache = "/".join(sceneNameFilePath[0:indexSceneFolder+1])+"/cache/alembic/"+sceneNameFileName
    if not os.path.isdir(pathFolderForCache) and pathFolderForCache!="/cache/alembic/"+sceneNameFileName:
       os.makedirs(pathFolderForCache)

    return pathFolderForCache
    
def exportAlembic():
    objects,startFrame,endFrame = getObjectsForExport()
    exec_ExportAlembic(objects,[startFrame,endFrame])

def getObjectsForExport():
    lsSelectedObject = cmds.ls(sl=True,l=True)
    startFrame=[]
    endFrame=[]
    if len(lsSelectedObject)>0:
        for lSO in range(0, len(lsSelectedObject)):
            duplicateObj=cmds.duplicate(lsSelectedObject[lSO],rr=True,name=lsSelectedObject[lSO].split("|")[-1]+"_xxx")
            #duplicateObj=cmds.rename(duplicateObj,lsSelectedObject[lSO]+"_xxx")
            duplicateObj = cmds.ls(duplicateObj,l=True)
            DuplicateShape = cmds.ls(duplicateObj,l=True,dag=True,ni=True,lf=True,type="mesh")
            OriginalShape = cmds.ls(lsSelectedObject[lSO],l=True,dag=True,ni=True,lf=True,type="mesh")
            for ds in range(0,len(DuplicateShape)):
                vis1=-1
                if cmds.getAttr(DuplicateShape[ds]+".visibility") != True:
                    vis1=0
                    cmds.setAttr(DuplicateShape[ds]+".visibility",True)
                    cmds.setAttr(OriginalShape[ds]+".visibility",True)
                cmds.blendShape(OriginalShape[ds],DuplicateShape[ds],o="world",w=[0,1])
                if vis1==0:
                    cmds.setAttr(DuplicateShape[ds]+".visibility",False)
                    cmds.setAttr(OriginalShape[ds]+".visibility",False)   				
            startFrame.append(cmds.playbackOptions(query=True,animationStartTime=True))
            endFrame.append(cmds.playbackOptions(query=True,animationEndTime=True))
            lsSelectedObject[lSO]=duplicateObj[0]
    else:
        cmds.error("Avtomaticheskiy export poka ne rabotatet...")    
        
    return lsSelectedObject,startFrame,endFrame

def exec_ExportAlembic(obgects, frameRanges):
    pathFolderForCache=FindAlembicSceneFolder()
    nameForAlembic="AbcExport"
    for lsS in range (0, len(obgects)):
        nameForAlembicTemp = obgects[lsS].replace(":","_x_")
        nameForAlembicTemp = nameForAlembicTemp.replace("|","_z_")
        nameForAlembic+=" -j \"-root "+obgects[lsS]+" -fr "+str(frameRanges[0][lsS])+" "+str(frameRanges[1][lsS])+" -noNormals -writeVisibility -renderableOnly -file "+pathFolderForCache+"/"+nameForAlembicTemp[:-4]+".abc\""

    print("\nEXPORT TO ALEMBIC: \n"+nameForAlembic+"\n")
    mel.eval(nameForAlembic)
    for ob in obgects:
        pass
        cmds.delete(ob)
    


        


def pathResolve():
    pathsSelection=cmds.ls(sl=True,l=True)
    path=[]
    nodes=[]
    if len(pathsSelection)>0:
        for lSO in range(0,len(pathsSelection)):
            nodes.append(pathsSelection[lSO])
            pathFolderForCache=FindAlembicSceneFolder()
            singleFilter = "Abc files (*.abc)"
            path.append(cmds.fileDialog2(caption=pathsSelection[lSO], fileFilter=singleFilter, dialogStyle=1, dir=pathFolderForCache, fm=1)[0])
    else:
        cmds.error("Avtomaticheskiy import poka ne rabotatet...")    
        '''
        #path.append(cmds.confirmDialog( title='Simlpe choose...', message='Are you sure?', button=['Yes','No'], defaultButton='Yes', cancelButton='No', dismissString='No' ))
        for filename in os.listdir(pathFolderForCache):
            if filename.endswith(".abc"):
                groupName=filename.split(".")[0].replace("_z_","__").replace("_x_",":")
                if cmds.ls("|cache|"+groupName) == []:
                    groupName=cmds.group(em=True,parent="|cache",name=groupName)
                    
                alembicNode=mel.eval("AbcImport -rpr "+"|cache|"+groupName+" \""+pathFolderForCache+"/"+filename+"\"")
                ChasheRoot.append(cmds.ls(groupName,dag=True,l=True)[1])
        '''

        
    return nodes,path


def exec_ImportAlembic(path):
    if cmds.ls("|cache") == []:
        cmds.group(em=True,name="cache")
    ChasheRoot=[]
    for p in path:
        onlyName=p.split("/")[-1]
        groupName=onlyName.split(".")[0].replace("_z_","__").replace("_x_",":")
        if cmds.ls("|cache|"+groupName) == []:
            groupName=cmds.group(em=True,parent="|cache",name=groupName)
            
        alembicNode=mel.eval("AbcImport -rpr "+"|cache|"+groupName+" \""+p+"\"")
        # Ubiraem _xxx.
        groupNameTemp=cmds.rename(cmds.ls(groupName,dag=True,l=True)[1], cmds.ls(groupName,dag=True,l=True)[1].split("|")[-1][0:-4])
        ChasheRoot.append(cmds.ls(groupNameTemp,dag=True,l=True)[0])
    return ChasheRoot
    
    

def importAlembic():
    nodes,path=pathResolve()
    Alembic=exec_ImportAlembic(path)
    schetchik=0
    for n in range(0,len(nodes)):
        nodeShapes=cmds.ls(nodes[n],l=True,dag=True,ni=True,lf=True,type="mesh")
        AlembicShapes=cmds.ls(Alembic[n],l=True,dag=True,ni=True,lf=True,type="mesh")
        lenAlembic=len(Alembic[n])
        lenNodes=len(nodes[n])
        for ns in range(0,len(nodeShapes)):
            nodeShapesDeleteNameSpace=[]
            for part in nodeShapes[ns][lenNodes:].split("|"):
            	nodeShapesDeleteNameSpace.append(part.split(":")[-1])
            nodeShapesDeleteNameSpace = "|".join(nodeShapesDeleteNameSpace)
            for ass in range(0,len(AlembicShapes)):
                nodeShapesDeleteNameSpaceTMP=nodeShapesDeleteNameSpace
                if nodeShapesDeleteNameSpaceTMP[-8:]=="Deformed":
                    nodeShapesDeleteNameSpaceTMP=nodeShapesDeleteNameSpaceTMP[:-8]
                AlembicShapesTMP=AlembicShapes[ass]
                if AlembicShapesTMP[-8:]=="Deformed":
                    AlembicShapesTMP=AlembicShapesTMP[:-8]
                if nodeShapesDeleteNameSpaceTMP==AlembicShapesTMP[lenAlembic:]:
                #if nodeShapesDeleteNameSpace==AlembicShapes[ass][lenAlembic:]:
                    schetchik=schetchik+1
                    print "schetchik nodes "+str(n+1)+"("+str(len(nodes))+") shapes "+str(len(nodeShapes))+"("+str(schetchik)+")"

                    listNodesToVisibility = nodeShapes[ns].split("|")
                    for x in range(1,len(listNodesToVisibility)):
                        next = ("|").join(listNodesToVisibility[0:x])
                        cmds.setAttr(next+".visibility",True)
                    cmds.setAttr(nodeShapes[ns]+".visibility",True)

                    blNode = cmds.listConnections(nodeShapes[ns],scn=True,d=False,type="blendShape")
                    if blNode is not None:
                        cmds.connectAttr((AlembicShapes[ass]+".worldMesh[0]"),(blNode[0]+".inputTarget[0].inputTargetGroup[0].inputTargetItem[6000].inputGeomTarget"))
                    else:
                        cmds.blendShape(AlembicShapes[ass],nodeShapes[ns],o="world",w=[0,1])                    
                    break
        cmds.setAttr(Alembic[n]+".visibility",0)



def createBlendShapesNode():
	lsSelectedObject = cmds.ls(sl=True,l=True)
	duplicateObj=cmds.duplicate(lsSelectedObject[0],rr=True,name=lsSelectedObject[0].split("|")[-1]+"_xxx")
	duplicateObj = cmds.ls(duplicateObj,l=True)
	DuplicateShape = cmds.ls(duplicateObj,l=True,dag=True,ni=True,lf=True,type="mesh")
	OriginalShape = cmds.ls(lsSelectedObject[0],l=True,dag=True,ni=True,lf=True,type="mesh")
	for ds in range(0,len(DuplicateShape)):
	        #print DuplicateShape[ds]
	        vis1=-1
	        if cmds.getAttr(DuplicateShape[ds]+".visibility") != True:
	            vis1=0
	            cmds.setAttr(DuplicateShape[ds]+".visibility",True)
	            cmds.setAttr(OriginalShape[ds]+".visibility",True)
	        cmds.blendShape(DuplicateShape[ds],OriginalShape[ds],o="world",w=[0,1])
	        if vis1==0:
	            cmds.setAttr(DuplicateShape[ds]+".visibility",False)
	            cmds.setAttr(OriginalShape[ds]+".visibility",False)            
	cmds.delete(duplicateObj)
		
#cmds.blendShape(Alembic[0],nodes[0],o="world",w=[0,1])
