import os
import re
import maya.cmds as cmds

DNCVA = 18.672
MODULUS = 25.39999962

def ml_animBounds( obj ):
    m_result = [ 0, 1 ]
    m_frames = []
    #Get nodes.
    m_obj = cmds.ls( obj, long=True )
    m_nodes = m_obj
    for i in range( 0, len( m_obj )):
        m_path = m_obj[i].split( "|" )
        for n in range( 0, len( m_path )):
            m_append = "|".join( m_path[:n] )
            if m_append:
                m_nodes.append( m_append )
    #Get keys.
    for i in range( 0, len( m_nodes )):
        m_temp = cmds.keyframe( m_nodes[i], query=True, tc=True )
        if m_temp:
            m_frames = m_frames + m_temp
    m_result = [ int( min( m_frames )), int( max( m_frames )) + 1 ]
    return m_result

def ml_listCameras():
    m_result = []
    m_cameras = cmds.ls( type="camera" )
    for i in range( 0, len( m_cameras )):
        m_transform = cmds.listRelatives( m_cameras[i], parent=True, fullPath=True )
        if m_transform:
            m_result.append( m_transform[0] )
    return m_result

def ml_animExists( obj ):
    m_result = 0
    #Get nodes.
    m_obj = cmds.ls( obj, long=True )
    m_nodes = m_obj
    for i in range( 0, len( m_obj )):
        m_path = m_obj[i].split( "|" )
        for n in range( 0, len( m_path )):
            m_append = "|".join( m_path[:n] )
            if m_append:
                m_nodes.append( m_append )
    #Get animation.
    for i in range( 0, len( m_nodes )):
        m_temp = cmds.keyframe( m_nodes[i], query=True, keyframeCount=True )
        if m_temp:
            m_result = m_result + m_temp
    return m_result

def ml_expotSt():
    ml_exportCameraToNuke( directory="", expression="root|camLeft|camRight", f=".nk", start=0, end=0, debug=True )

def ml_exportCameraToNuke( directory="", expression="", f=".nk", start=0, end=0, debug=True ):
    m_filename = cmds.file( query=True, sceneName=True ).split( "." )[0]
    m_nukename = m_filename.split( "/" )[-1]
    if directory == "":
        if re.findall( "light", m_filename, re.IGNORECASE ):
            directory = re.sub( "light/[A-z0-9_/.]+", "compose/layers/", m_filename, re.IGNORECASE )
        else:
            directory = "/".join( m_filename.split( "/" )[0:-1] )
    if expression == "":
        expression = "[Ee][Pp][0-9]+\w+[Ss][Cc]\w+[0-9]+_st"
    #Get camera.
    m_cameras = []
    m_expr = re.compile( expression )
    m_temp = ml_listCameras()
    for i in range( 0, len( m_temp )):
        if m_expr.findall( m_temp[i] ):
            m_cameras.append( m_temp[i] )
    #Export camera.
    if m_cameras:
        #Create file.nk
        m_path = os.path.join( directory, m_nukename ) + f
        m_file = file( m_path, "w" )
        #Create camera info. 
        for i in range( 0, len( m_cameras )):
            print "camera:", m_cameras[i]
            m_text = ""
            #Get animation bounds.
            if start == 0 and end == 0:
                m_keys = ml_animExists( m_cameras[i] )
                if m_keys > 0:
                    m_bounds = ml_animBounds( m_cameras[i] )
                    m_start = m_bounds[0]
                    m_end = m_bounds[-1]
                else:
                    m_start = int( cmds.playbackOptions( query=True, minTime=True ))
                    m_end = m_start + 1
            else:
                m_start = start
                m_end = end + 1
            #Get attributes.
            m_count = m_end - m_start
            m_translate = [ [], [], [] ]
            m_rotate = [ [], [], [] ]
            m_focal = []
            m_haperture = []
            m_vaperture = []
            print "bake animation:", m_cameras[i]
            m_inc = 0
            for n in range( m_start, m_end):
                m_inc = m_inc + 1
                print "frame: %s \\ %s " % ( m_inc, m_count )
                cmds.currentTime( n )
                #translate.
                m_temp = cmds.xform( m_cameras[i], q=1, ws=1, t=1 )
                m_translate[0].append( str( m_temp[0] ))
                m_translate[1].append( str( m_temp[1] ))
                m_translate[-1].append( str( m_temp[-1] ))
                #rotate.
                m_temp = cmds.xform( m_cameras[i], q=1, ws=1, ro=1 )
                m_rotate[0].append( str( m_temp[0] ))
                m_rotate[1].append( str( m_temp[1] ))
                m_rotate[-1].append( str( m_temp[-1] ))
                #focal.
                m_temp = cmds.camera( m_cameras[i], q=1, fl=1 )
                m_focal.append( str( m_temp ))
                #haperture.
                m_temp = cmds.camera( m_cameras[i], q=1, hfa=1 )*MODULUS
                m_haperture.append( str( m_temp ))
                #vaperture.
                m_temp = cmds.camera( m_cameras[i], q=1, vfa=1 )*MODULUS
                m_vaperture.append( str( m_temp ))
            #Write attributes.
            m_string = "\nCamera2 {\n inputs %s\n rot_order %s\n translate %s\n rotate %s\n focal %s\n haperture %s\n vaperture %s\n name %s\n selected %s\n xpos %s\n ypos %s\n}"
            m_inputs = "0"
            m_order = "XYZ"
            m_translate = "{{curve x%s %s} {curve x%s %s} {curve x%s %s}}" % ( m_start, " ".join( m_translate[0] ), m_start, " ".join( m_translate[1] ), m_start, " ".join( m_translate[-1] ) ) 
            m_rotate = "{{curve x%s %s} {curve x%s %s} {curve x%s %s}}" % ( m_start, " ".join( m_rotate[0] ), m_start, " ".join( m_rotate[1] ), m_start, " ".join( m_rotate[-1] ) )
            m_focal = "{{curve x%s %s}}" % ( m_start, " ".join( m_focal ))
            m_haperture = "{{curve x%s %s}}" % ( m_start, " ".join( m_haperture ))
            m_vaperture = "{{curve x%s %s}}" % ( m_start, " ".join( m_vaperture ))
            m_name = "\"%s\"" % ( m_cameras[i].split( "|" )[-1]).split( ":" )[-1]
            m_selected = "true"
            m_xpos = str( i*100 )
            m_ypos = "300"
            m_string = m_string % ( m_inputs, m_order, m_translate, m_rotate, m_focal, m_haperture, m_vaperture, m_name, m_selected, m_xpos, m_ypos )
            if debug is True:
                print m_string
            m_text = m_text + m_string
            #Write camera to .nk.
            m_file.write( m_text )
        print "File saved to:", m_path
        m_file.close()
		
#import ml_exportCameraToNuke; ml_exportCameraToNuke.ml_expotSt() 		