import site
import codecs
import glob
import re
import sys, os, shutil
import re
import maya.cmds as cmds
import maya.mel as mel
if not cmds.pluginInfo( "RenderMan_for_Maya", query=True, loaded=True ):
	cmds.loadPlugin( "RenderMan_for_Maya" )
import rfm.rlf2maya as rlf2maya
import rfm.passes
import rfm.slim
import rfm.tractor
import rfm	
import math
import time



def findContainedReferences(fileww):
    filesFoundSoFar=[]
    filesFoundSoFar.append(fileww)
    nestedReferencesFromFile =  cmds.file(fileww,q=True,r=True,wcn=True)
        
    if len(nestedReferencesFromFile):
        for eachFile in  nestedReferencesFromFile:
            EachFileReferences = findContainedReferences(eachFile)
            filesFoundSoFar = EachFileReferences + filesFoundSoFar

    return  filesFoundSoFar

def findAllReferences():
    allReferences=[]    
    topLevelReferences=cmds.file(q=True,r=True,wcn=True)
    for eachReference in topLevelReferences:
        nestedReferencesForEachFile=findContainedReferences(eachReference)
        allReferences = allReferences + nestedReferencesForEachFile
    return allReferences

def getProjectFromFile(path):
    print("asdfasdfasdf\n")
    pathSplit = path.replace("\\","/").split("/")
    indexSlash=0
    expressionProject = re.compile("Project", re.IGNORECASE)
    for pS in pathSplit:
        if expressionProject.match(pS):
            break
        indexSlash=indexSlash+1
         
    OSTYPERE = sys.platform
    if OSTYPERE == "win32":
            OSTYPERE = "//renderServer/Project"
    else:
            OSTYPERE = "/renderServer/Project"
    ''' 
    OSTYPERE = sys.platform
    if OSTYPERE == "win32":
            OSTYPERE = "//Server-3d/Project"
    else:
            OSTYPERE = "/Server-3d/Project"
    ''' 
    fff=re.compile('^(/Server-3d/Project)|(/mnt/server-3d)|(P:)|(/home/.*/Project)|(D:/Work/Project)|(//Server-3d/Project)', re.IGNORECASE)
    rezzz = fff.sub(OSTYPERE,"/".join(pathSplit[:indexSlash+5]))

    if not os.path.exists(rezzz):
        os.makedirs(rezzz)
    print("make path: "+rezzz)
        
    return rezzz


def runFunctionFromSelectFiles(processArglist=["-batch","-proj","","-command","\"%D(script)\"","-file",""],scriptString="",environmentKeyLE="",jobPriorityLE=1500,jobServerAttrubutesLE="",jobListTask=[],startPausedCB=False):
            #self.processArglist[4]="\"%D(script)\""
            dirmapseval = mel.eval("rman workspace GetDirMaps rib")
            dirmapseval=dirmapseval.replace("[", "")
            dirmapseval=dirmapseval.replace("]", "")
            dirmapseval=dirmapseval.replace("\"", "")
            dirmapseval=dirmapseval[:-1].split(" ")
            dirmaps = "\n    {{mayabatch} {maya} nfs}\n"
            for i in range(0,len(dirmapseval)/3):
                dirmaps+="\t{{"
                dirmaps+=dirmapseval[i*3+1]
                dirmaps+="} {"
                dirmaps+=dirmapseval[i*3+2]
                dirmaps+="} "
                dirmaps+=dirmapseval[i*3]
                dirmaps+="}\n"    

            dirmaps+="\t{{script} {"+scriptString+"} unc}\n\t{{script} {"+scriptString+"} nfs}\n"
            
                    
    
            getDataDir=mel.eval("rmanGetDataDir")
            getDataDir += '/.alfredMayaScripts'
            if not os.path.exists(getDataDir):
                os.makedirs(getDataDir)
                                            
            currentTime = time.strftime('%a, %d %b %Y %H:%M:%S +0000', time.gmtime())
            fnm = ''
            sceneNameFile3=cmds.file(query=True, sn=True, shn=True)        
            if sceneNameFile3 == "":
                sceneNameFile3="untitled.ma"
            fnm = getDataDir.replace('\\', '/') + '/'+sceneNameFile3.split(".")[0]+'_' + str(time.time()).split(".")[0] + '.alf'
            print "file to write: "+fnm
            jobFile = open(fnm, 'w')
      

            jobFile.write('##AlfredToDo 3.0\n\n')
            jobFile.write('Job -title {' + fnm.split("/")[-1].split(".")[0] + '}')
            jobFile.write(' -comment {#Generated: ' + str(currentTime)+ '        ' + scriptString + '}')        
            jobFile.write(' -dirmaps {' + dirmaps + '}')        
            jobFile.write(' -envkey {'+environmentKeyLE+'}')        
            jobFile.write(' -pbias ' + str(jobPriorityLE) + '')
            jobFile.write(' -crews {}')        
            jobFile.write(' -tags {}')
            jobFile.write(' -service {' + jobServerAttrubutesLE + '}')
            jobFile.write(' -whendone {}')
            jobFile.write(' -whenerror {}')
            jobFile.write(' -serialsubtasks 1 -subtasks {\n')
       
            jobFile.write('\tTask -title {Job} -serialsubtasks 0 -subtasks {\n')
            
    
            cmdtail = '-tags {intensive} -service {mayaBatch}' 
                    
            for i in range(0,len(jobListTask)):
                    currentTesk = str(jobListTask[i])
                    processArglist[2]="\"%D("+getProjectFromFile(currentTesk)+")\""
                    processArglist[6]="\"%D("+currentTesk+")\""
    
                    title = 'File num:' + str(i+1)
            
                    jobFile.write('\t\tTask -title {' + title + '} -cmds {\n')
                    print " ".join(processArglist)
                    jobFile.write( '\t\t\tRemoteCmd {%D(mayabatch) '+ " ".join(processArglist) + '} ' + cmdtail + '\n')
                    jobFile.write('\t\t}\n')        
        
            jobFile.write('\t}')
            #jobFile.write(' -cleanup {\n')
            #jobFile.write('\t\tFile delete "' + fnm + '"\n')
            #jobFile.write('\t}\n')
            jobFile.write('}\n')
            jobFile.close()
            print "file write: "+fnm
            
            opts=[]
            if startPausedCB:
                opts.append("'--paused'")
            opts.append("'--priority=" + str(jobPriorityLE) + "'")
            opts.append("'--engine=" + mel.eval("rman getPref TractorEngine") + "'")
            if mel.eval("rman getPref TractorUser") != "":
                opts.append("'--user=" + mel.eval("rman getPref TractorUser") + "'")
            opts.append("'" + fnm + "'")                                
            
            print("tractor spool: ["+",".join(opts)+"]")
            
            rfm.tractor.Spool(eval("["+",".join(opts)+"]"))
            if not os.path.exists(getDataDir):
                os.makedirs(getDataDir)                
            #ddd=['--priority=1','--engine=192.168.0.155:80','/home/Yago/Project/default/renderman/untitled/data/.alfredMayaScripts/untitled_1407228966.alf']
            #ddd=['--priority=1','--engine=192.168.0.155:80','/home/Yago/Project/default/renderman/untitled/data/.alfredMayaScripts/untitled_1407236834.alf']
            #rfm.tractor.Spool(ddd)
            if os.path.exists(fnm):
                try:
                    #os.remove(fnm)    
                    pass
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + fnm)



def rmanSpoolRemoteRIBRemoteRender(server="LinuxFarm",frames="",priority="100",batchContext="$JOBDATETIME",cmdTags="",environ="rms-18.0-maya-2013 prman-18.0",rendererArg="",doneCom="",errorCom="",crews="",extra="",fPS=5,lRB=False,stPaused=False,cropWondowLE1=0,cropWondowLE2=0,cropWondowLE3=0,cropWondowLE4=0,rezolutionCombobox=0,loadSTCamerasLable=False,selectCamerasLabel=False,startMainCamera=True,startStereoCameras=False,customDisplayLable=False,customDisplayLE=False,customDisplayLE2=False,reuseShadowMapsLabel=False,reuseShadowMapsCombobox=0,reuseSSLabel=False,reuseSSCombobox=0,reuseShaveRibsLabel=False,reuseShaveRibsCB=True,shadingRateScaleLE=1,directLightSamplesScaleLE=1,shutterAngleScaleLE=1,statisticOutputLable=False,statisticOutputLE=False,disableAllShaveCB=False,disableAllLightsCB=False,disableAllShadersCB=False,disableRayTracingCB=False,sceneAutoCleanCB=False,saveOrExportCB=False,loadProxyReferenceCB=False,motionBlurLabel=False,motionBlurCB=False,motionBlurCB2=False,shutterAngleSB=80,motionBlurTypeCombobox="frame",shutterTimingCombobox="frameOpen",shutterOpeningSB1=0,shutterOpeningSB2=1,dofLabel=False,dofCB=False,dofCB2=5,dofSB3=5.6,dofSB4=1,shadingRateCB=False,shadingRateSB=1,motionFactorCB=False,motionFactorSB=1,focusFactorCB=False,focusFactorSB=1,pixelSampelsLabel=True,pixelSampelsSB=3,pixelSampelsSB2=3,filterCB=False,filter1SB=4,filter2SB=4,filterCombobox="separable-catmull-rom",ribFormatCB=False,ribFormatCombobox="binary",ribFormatCombobox2="gzip",lazyCB=False,lazyCB1=False,lazyCB2=False,permanentState=False,setPomnyChtoBezRendera=0):
    print "rmanSpoolRemoteRIBRemoteRender(server="+str(server)+",frames="+str(frames)+",priority="+str(priority)+",batchContext="+str(batchContext)+",cmdTags="+str(cmdTags)+",environ="+str(environ)+",rendererArg="+str(rendererArg)+",doneCom="+str(doneCom)+",errorCom="+str(errorCom)+",crews="+str(crews)+",extra="+str(extra)+",fPS="+str(fPS)+",lRB="+str(lRB)+",stPaused="+str(stPaused)+",cropWondowLE1="+str(cropWondowLE1)+",cropWondowLE2="+str(cropWondowLE2)+",cropWondowLE3="+str(cropWondowLE3)+",cropWondowLE4="+str(cropWondowLE4)+",rezolutionCombobox="+str(rezolutionCombobox)+",loadSTCamerasLable="+str(loadSTCamerasLable)+",selectCamerasLabel="+str(selectCamerasLabel)+",startMainCamera="+str(startMainCamera)+",startStereoCameras="+str(startStereoCameras)+",customDisplayLable="+str(customDisplayLable)+",customDisplayLE="+str(customDisplayLE)+",reuseShadowMapsLabel="+str(reuseShadowMapsLabel)+",reuseShadowMapsCombobox="+str(reuseShadowMapsCombobox)+",reuseSSLabel="+str(reuseSSLabel)+",reuseSSCombobox="+str(reuseSSCombobox)+",reuseShaveRibsLabel="+str(reuseShaveRibsLabel)+",reuseShaveRibsCB="+str(reuseShaveRibsCB)+",shadingRateScaleLE="+str(shadingRateScaleLE)+",directLightSamplesScaleLE="+str(directLightSamplesScaleLE)+",shutterAngleScaleLE="+str(shutterAngleScaleLE)+",statisticOutputLable="+str(statisticOutputLable)+",statisticOutputLE="+str(statisticOutputLE)+",disableAllShaveCB="+str(disableAllShaveCB)+",disableAllLightsCB="+str(disableAllLightsCB)+",disableAllShadersCB="+str(disableAllShadersCB)+",disableRayTracingCB="+str(disableRayTracingCB)+",sceneAutoCleanCB="+str(sceneAutoCleanCB)+",saveOrExportCB="+str(saveOrExportCB)+",loadProxyReferenceCB="+str(loadProxyReferenceCB)+",motionBlurLabel="+str(motionBlurLabel)+",motionBlurCB="+str(motionBlurCB)+",motionBlurCB2="+str(motionBlurCB2)+",shutterAngleSB="+str(shutterAngleSB)+",motionBlurTypeCombobox="+str(motionBlurTypeCombobox)+",shutterTimingCombobox="+str(shutterTimingCombobox)+",shutterOpeningSB1="+str(shutterOpeningSB1)+",shutterOpeningSB2="+str(shutterOpeningSB2)+",dofLabel="+str(dofLabel)+",dofCB="+str(dofCB)+",dofCB2="+str(dofCB2)+",dofSB3="+str(dofSB3)+",dofSB4="+str(dofSB4)+",shadingRateCB="+str(shadingRateCB)+",shadingRateSB="+str(shadingRateSB)+",motionFactorCB="+str(motionFactorCB)+",motionFactorSB="+str(motionFactorSB)+",focusFactorCB="+str(focusFactorCB)+",focusFactorSB="+str(focusFactorSB)+",pixelSampelsLabel="+str(pixelSampelsLabel)+",pixelSampelsSB="+str(pixelSampelsSB)+",pixelSampelsSB2="+str(pixelSampelsSB2)+",filterCB="+str(filterCB)+",filter1SB="+str(filter1SB)+",filter2SB="+str(filter2SB)+",filterCombobox="+str(filterCombobox)+",ribFormatCB="+str(ribFormatCB)+",ribFormatCombobox="+str(ribFormatCombobox)+",ribFormatCombobox2="+str(ribFormatCombobox2)+",lazyCB="+str(lazyCB)+",lazyCB1="+str(lazyCB1)+",lazyCB2="+str(lazyCB2)+",permanentState="+str(permanentState)+",setPomnyChtoBezRendera="+str(setPomnyChtoBezRendera)+")"
    print("rSRRIBRR(1/10): start")
    if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
        cmds.loadPlugin("RenderMan_for_Maya")

    for rm in cmds.ls(type=["unknown"]):
        try:
            #print("rSRRIBRR(1/10) autoClean delete: "+rm)
            cmds.delete(rm)
        except:
            pass

    for i in cmds.ls(type="RenderMan"):
        da=0
        if re.search("oldrman",i):
            da=1
        if re.search(":",i):
            try:
                if not cmds.referenceQuery(i,inr=True):
                    da=1
            except:
                pass
        if da:
            print "delete RenderMan node: "+ i
            try:
                cmds.delete(i)
            except:
                pass

    if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
        cmds.loadPlugin("RenderMan_for_Maya")

    if mel.eval("currentRenderer") != "renderMan":
        mel.eval("setCurrentRenderer renderMan")     

    if not cmds.objExists("rmanFinalGlobals"):
        mel.eval("rmanCreateGlobals()")

    settings = rfm.passes.GetDefaultSettings()
    globalsSettings=rfm.passes.GetGlobals()
    if sceneAutoCleanCB:
        rfm.passes.Update()
        globalsSettings=rfm.passes.GetGlobals()
        cmds.undoInfo(state=True)
        for i in cmds.ls(type="mesh"):
            if re.match(".*CT.*",i):
                cmds.sets(i, forceElement="initialShadingGroup")



        for iP in cmds.ls(type="imagePlane"):
            cmds.setAttr(iP+".visibility",0)
    


        vyborCamery=""
        prioritetCamera=""
        for cam in cmds.ls(type="camera"):
            print "camera: "+cam
            cameraUsed = False
            if re.search("[e|E][p|P][0-9]{2}[s|S][c|C](([0-9]{2})|([0-9]Shape[0-9])|(Shape[0-9]{2}))",cam):
                if cmds.listConnections( cam, type="shot" ):
                    prioritetCamera = cam
                if cmds.referenceQuery( cam, isNodeReferenced=True ):
                    rfilename = cmds.referenceQuery( cam, filename=True )
                    if not re.findall("props|chars|sets",rfilename):
                        cameraUsed = True
                else:
                    cameraUsed = True
            if cameraUsed is True:
                print("rSRRIBRR(1/10) set camera: "+cam)
                vyborCamery=cam
                #cmds.setAttr(cam+".renderable",1)    
            else:
                pass
                #cmds.setAttr(cam+".renderable",0)    

            cmds.setAttr(cam+".renderable",0)    

        if vyborCamery != "":
            if prioritetCamera == "":
                print("rSRRIBRR(1/10) set camera: "+vyborCamery)
                cmds.setAttr(vyborCamery+".renderable",1)
            else:
                print("rSRRIBRR(1/10) set camera: "+prioritetCamera)
                cmds.setAttr(prioritetCamera+".renderable",1)

        cmds.setAttr("defaultRenderGlobals.animation", 1)
        cmds.setAttr("defaultRenderGlobals.pff", 1)
        cmds.setAttr("defaultRenderGlobals.peie", 1)
        cmds.setAttr("defaultRenderGlobals.animationRange", 0)
        cmds.setAttr("defaultRenderGlobals.extensionPadding", 4)
        cmds.setAttr("defaultRenderGlobals.outFormatControl", 0)
        cmds.setAttr("defaultRenderGlobals.putFrameBeforeExt", 1)
        cmds.setAttr("defaultRenderGlobals.imageFormat", 3)
        cmds.setAttr("defaultRenderGlobals.enableDefaultLight", 1)
        cmds.setAttr("defaultRenderGlobals.startFrame", l=False)
        cmds.setAttr("defaultRenderGlobals.startFrame", cmds.playbackOptions(q=True, ast=True))
        cmds.setAttr("defaultRenderGlobals.endFrame", l=False)
        cmds.setAttr("defaultRenderGlobals.endFrame", cmds.playbackOptions(q=True, aet=True))

        cmds.setAttr("defaultResolution.lockDeviceAspectRatio", 0)
        cmds.setAttr("defaultResolution.deviceAspectRatio", 2.387)
        cmds.setAttr("defaultResolution.pixelAspect", 1)
        cmds.setAttr("defaultResolution.width", 2048)
        cmds.setAttr("defaultResolution.height", 858)

        globalsSettings.SetAttr("rman__riopt__Format_resolution0",2048)
        globalsSettings.SetAttr("rman__riopt__Format_resolution1",858)
        globalsSettings.SetAttr("rman__riopt__Format_pixelaspectratio",1)

        rfm.passes.Update()
        finalPassDefaultsDisplay = rfm.passes.GetPassDefaults("Final").GetPrimaryDisplay()
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_type","tiff")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_quantize","0 255 0 255")    
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_dither","0.5")    
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filter","gaussian")
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filterwidth0",2)
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_filterwidth1",2)
        finalPassDefaultsDisplay.SetAttr("rman__riopt__Display_exposure1",3.2)


        allReferences=findAllReferences()   
        allReferencescharReferences=[]
        for aR in allReferences:
            if re.search("assets/chars",aR):
                allReferencescharReferences.append(aR)

        listShapes=[]
        for aRR in allReferencescharReferences:
            listShapes = listShapes + cmds.ls(cmds.referenceQuery(aRR,n=True,dp=True),s=True,ni=True)

        for lS in listShapes:
            if cmds.objectType(lS) == "mesh":
                cmds.setAttr(lS+".castsShadows",1)
                cmds.setAttr(lS+".receiveShadows",1)
                cmds.setAttr(lS+".motionBlur",1)
                cmds.setAttr(lS+".primaryVisibility",1)
                cmds.setAttr(lS+".smoothShading",1)
                cmds.setAttr(lS+".visibleInReflections",1)
                cmds.setAttr(lS+".visibleInRefractions",1)
                cmds.setAttr(lS+".doubleSided",1)


        '''
        global debugPy

        try:
            debugPy
        except NameError:
            debugPy=0
        else:
            pass


        OSTYPERS = sys.platform
        if OSTYPERS == "win32":
                OSTYPERS="//renderServer/Project/"
        else:
                OSTYPERS="/renderServer/Project/"

        OSTYPE3D = sys.platform
        if OSTYPE3D == "win32":
                OSTYPE3D="//Server-3d/Project/"
        else:
                OSTYPE3D="/Server-3d/Project/"

        expressionUrfin = re.compile("^UrfinJuse", re.IGNORECASE)
        expressionServer3d = re.compile("^/{1,2}Server-3d/Project/", re.IGNORECASE)
        expressionServerRender = re.compile("^/{1,2}renderServer/Project/", re.IGNORECASE)
        expressionDirectoryPath = re.compile("^(/Server-3d/Project/)|(/mnt/server-3d/)|(P:/)|(/home/.*/Project/)|(D:/Work/Project/)|(//Server-3d/Project/)", re.IGNORECASE)


        def checkFilesOnServer(files,namespaces=[]):
            paths = []
            for i in range(0,len(files)):
                fullName=""
                if expressionUrfin.match(files[i]):
                    fullName=OSTYPE3D+files[i]
                elif expressionServer3d.match(files[i]):
                    fullName = expressionDirectoryPath.sub(OSTYPE3D,files[i])
                elif expressionServerRender.match(files[i]):
                    continue
                else:
                    if len(namespaces): print("ERROR COPY FILE("+namespaces[i]+"): " + files[i])
                    else: print("ERROR COPY FILE: " + files[i])
                    continue

                if fullName!="":
                    pathd=re.sub("MAPID_","*",fullName)
                    pathd=re.sub("<udim>","*",pathd)
                    if fullName != pathd:
                        temp2=["/".join(pathd.split("/")[:-1])]
                        filesss = glob.glob(temp2[0]+'/'+pathd.split("/")[-1])        
                        for f in filesss:
                            if f not in paths:
                                paths.append(f)
                            
                    elif os.path.exists(fullName):
                        if fullName not in paths:
                            paths.append(fullName)
            
                    else:     
                        if len(namespaces): print("ERROR COPY FILE("+namespaces[i]+"): " + files[i])
                        else: print("ERROR COPY FILE: " + files[i])
            
            return paths



        print "\n\n"
        if not rfm.slim.GetSlim().Running():
            rfm.slim.GetSlim().Start()
            myslim = rfm.slim.GetSlim()
            
            kakzhedolgo=100000000
            vottak=0
            while vottak < kakzhedolgo:
                vottak+=1
                gde=myslim.Cmd("slim GetSlimStatus")
                if gde != "":
                    kakzhedolgo=vottak-1

        myslim = rfm.slim.GetSlim()
        ddd=myslim.Cmd("listAllTexturePath")


        expressionSlim = re.compile("\} \{", re.IGNORECASE)
        ddd=expressionSlim.sub(",",ddd)
        ddd="["+ddd[1:-1]+"]"
        #listTexurePaths = eval(ddd)
        listTexurePathsTemp = eval(ddd)

        listTexurePaths=[]
        listNamspacePaths=[]
        for i in listTexurePathsTemp:
            listTexurePaths.append(i[0])
            listNamspacePaths.append(i[1])

        paths = checkFilesOnServer(listTexurePaths,listNamspacePaths)
        #paths = checkFilesOnServer(listTexurePaths)
        ollLen=len(paths)
        print "\n\n"
        for i in range(0,ollLen):         
            dirName="/".join(paths[i].split("/")[:-1])
            dirNameServer=expressionDirectoryPath.sub(OSTYPERS,dirName)
            fullNameServer=expressionDirectoryPath.sub(OSTYPERS,paths[i])
            
            if not os.path.exists(dirNameServer):
                os.makedirs(dirNameServer)
          
            if debugPy: print "chek texture: "+paths[i]+" to " +fullNameServer
            if os.path.exists(fullNameServer) and int(os.path.getmtime(paths[i])) == int(os.path.getmtime(fullNameServer)):
                continue

            print str(int(100.0/ollLen*(i+1)))+"%    copy texture "+paths[i]
            if os.path.exists(fullNameServer):
                try:
                    os.remove(fullNameServer)    
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + fullNameServer)
            try:
                shutil.copy2(paths[i],fullNameServer)
            except:
                print("ERROR EXEPTION COPY FILES: " + paths[i] + " to " + fullNameServer)     
                 

        print "\n\n"
        paths = []
        ribs = cmds.ls( type='RenderManArchive' )
        for i in ribs:
            paths.append(cmds.getAttr(i+'.filename'))

        paths=checkFilesOnServer(paths)
        print "\n\n"
        ollLen=len(paths)
        for i in range(0, ollLen):
            shaderDir = paths[i].split('.')[0]
            root = expressionDirectoryPath.sub(OSTYPERS,shaderDir)
            root = '/'.join(( root ).split( '/' )[:-1] ) + '/'
            newRibFile = root + (paths[i].split('/')[-1])
            newShaderDir = root + (shaderDir).split('/')[-1]
            if debugPy: print "chek archive: "+paths[i]+" to " +newRibFile
                
            if not os.path.exists(root):
                os.makedirs(root)
            if os.path.exists(newRibFile) and int(os.path.getmtime(paths[i])) == int(os.path.getmtime(newRibFile)):
                continue
            
            print str(int(100.0/ollLen*(i+1)))+"%    copy archives "+paths[i]+"   "+newRibFile
            if os.path.exists(newRibFile):
                try:
                    os.remove(newRibFile)
                except:
                    print("ERROR EXEPTION REMOVE FILE: " + newRibFile)
            try:
                shutil.copy2(paths[i],newRibFile)
            except:
                print("ERROR EXEPTION COPY FILES: " + paths[i] + " to " + newRibFile)                    

            if os.path.exists(shaderDir):
                if os.path.exists(newShaderDir):
                    srcFiles = os.listdir(shaderDir)
                    dstFiles = os.listdir(newShaderDir)
                    srcDate = 0
                    dstDate = 0
                    for n in range(0,len(srcFiles)):
                        srcDate+=int((os.stat(shaderDir+'/'+srcFiles[n])).st_mtime)
                    for n in range(0,len(dstFiles)):
                        dstDate+=int((os.stat(newShaderDir+'/'+dstFiles[n])).st_mtime)
                    if srcDate>dstDate or len(srcFiles)>len(dstFiles):
                        try:
                            shutil.rmtree(newShaderDir)
                        except:
                            print("ERROR EXEPTION REMOVE TREE: " + newShaderDir)
                    else:
                        continue
                
                if debugPy: print str(int(100.0/ollLen*(i+1)))+"%    copy archives "+shaderDir
                try:
                    shutil.copytree(shaderDir,newShaderDir)
                except:
                    print("ERROR EXEPTION COPY FILES: " + shaderDir + " to " + newShaderDir)        

        '''










    if loadProxyReferenceCB:
        exp = re.compile("\_*proxy\.", re.IGNORECASE)
        for ii in findAllReferences():
            if cmds.referenceQuery(ii,il=True):
                if re.search("/referenceParts/",ii):
                    if exp.search(os.path.basename(ii)):
                        #print "proxy: "+ii
                        origPath=os.path.dirname(ii)+"/"+exp.sub(".",os.path.basename(ii))
                        if os.path.exists(origPath):
                            #print "orig: "+origPath
                            #origPath="/Server-3d/Project/UrfinJuse/assets/sets/UchastokUrfina/maya/referenceParts/ground.ma"
                            refNode=cmds.referenceQuery(ii,rfn=True)
                            ff=cmds.listConnections(refNode+".proxyMsg",d=True,s=False)
                            if type(ff)==type([]):
                                ff=cmds.listConnections(ff[0]+".proxyList",d=True,s=False)
                                tag2=""
                                for f in ff:
                                        if mel.eval("attributeExists(\"proxyTag\",\""+f+"\")"):
                                                tag = cmds.getAttr(f+".proxyTag")
                                                if tag=="original":
                                                        tag2=f
                                                        break
                                print tag2
                                mel.eval("proxySwitch \""+tag2+"\"")
                        else:
                            print "net takogo orig: "+origPath

    rfm.passes.Update()
    settings = rfm.passes.GetDefaultSettings()
    globalsSettings=rfm.passes.GetGlobals()

    if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
        cmds.loadPlugin("RenderMan_for_Maya")

    if mel.eval("currentRenderer") != "renderMan":
        mel.eval("setCurrentRenderer renderMan")     

    if not cmds.objExists("rmanFinalGlobals"):
        mel.eval("rmanCreateGlobals()")


    tmpDefaultRenderGlobalsAnimation=cmds.getAttr("defaultRenderGlobals.animation")
    cmds.setAttr("defaultRenderGlobals.animation",1)
    tmpDefaultRenderGlobalsExtensionPadding=cmds.getAttr("defaultRenderGlobals.extensionPadding")
    cmds.setAttr("defaultRenderGlobals.extensionPadding",4)
    tmpDefaultRenderGlobalsPff=cmds.getAttr("defaultRenderGlobals.pff")    
    cmds.setAttr("defaultRenderGlobals.pff", 1)
    tmpDefaultRenderGlobalsRmanBatchSceneCtx=cmds.optionVar(q="rmanBatchSceneCtx")
    cmds.optionVar(stringValue=("rmanBatchSceneCtx",str(batchContext)))

    print("rSRRIBRR(2/10)")
    if loadSTCamerasLable:
        path="/".join(cmds.file(query=True, sn=True).split("\\"))
        rez=re.search(".*/scenes/\w*/\w*/",path)
        if rez:
            #print rez.group(0)
            rezPath=rez.group(0)+"light/"
            if os.path.exists(rezPath):
                #findFile = glob.glob(rezPath+"*_st.*")
                findFile = glob.glob(rezPath+rez.group(0).split("/")[-2]+"_st.*")
                if len(findFile):
                    findFile="/".join(findFile[0].split("\\"))
                    allReferences=findAllReferences()   
                    nezagruzhen=1
                    for aR in allReferences:
                        if "/".join(aR.split("\\")) == findFile:
                            nezagruzhen=0
                            break
                    if nezagruzhen:
                        extenshen="mayaBinary"
                        if findFile.split(".")[-1]=="ma": extenshen="mayaAscii"                
                        cmds.file( findFile, type=extenshen, options="v=0", reference=True, namespace=findFile.split("/")[-1].split(".")[0])
                    
                    listCams=[]
                    for nodes in cmds.referenceQuery(findFile,n=True):
                        if re.search("camLeftShape|camRightShape",nodes):
                            listCams.append(nodes)

                    for cam in cmds.ls(type="camera"):
                        print "camera: "+cam
                        cameraUsed = False
                        if cam in listCams:
                            if cmds.referenceQuery( cam, isNodeReferenced=True ):
                                rfilename = cmds.referenceQuery( cam, filename=True )
                                if not re.findall("props|chars|sets",rfilename):
                                    cameraUsed = True
                            else:
                                cameraUsed = True
                        if cameraUsed is True:
                            print("rSRRIBRR(1/10) set camera: "+cam)
                            cmds.setAttr(cam+".renderable",1)
                        else:
                            cmds.setAttr(cam+".renderable",0)

    print("rSRRIBRR(2/10)")
    if cropWondowLE1!=0 or cropWondowLE2!=0 or cropWondowLE3!=0 or cropWondowLE4!=0:
        if not re.search("-crop",rendererArg):
            rendererArg=rendererArg+" -crop "+str(cropWondowLE1)+" "+str(cropWondowLE2)+" "+str(cropWondowLE3)+" "+str(cropWondowLE4)

    defaultResolutionWidth=globalsSettings.GetAttr("rman__riopt__Format_resolution0")
    defaultResolutionHeight=globalsSettings.GetAttr("rman__riopt__Format_resolution1")

    if rezolutionCombobox!=0:
        if rezolutionCombobox==1:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",512)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",214)
        elif rezolutionCombobox==2:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",1024)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",428)
        elif rezolutionCombobox==3:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",2048)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",858)
        elif rezolutionCombobox==4:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",2100)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",858)
        elif rezolutionCombobox==5:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",4096)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",1716)
            
            
    print("rSRRIBRR(3/10)")

    listOfShadowPasses=[]
    if reuseShadowMapsLabel:
        allPasses=rfm.passes.GetPasses()
        for ap in allPasses:
            if re.search("Shadow",ap.GetClass()):
                listOfShadowPasses.append([ap.GetLabel()])
                listOfShadowPasses[-1].append(ap.GetReuse())
                listOfShadowPasses[-1].append(ap.IsEnabled())
                if reuseShadowMapsCombobox == 0:
                    ap.Enable()
                    ap.SetReuse(0)
                elif reuseShadowMapsCombobox == 1:
                    ap.Enable()
                    ap.SetReuse(1)
                elif reuseShadowMapsCombobox == 2:
                    ap.Disable()
                    ap.SetReuse(1)                                    
   
    listOfSSPasses=[]
    if reuseSSLabel:
        allPasses=rfm.passes.GetPasses()
        for ap in allPasses:
            if re.search("SS",ap.GetClass()):
                listOfSSPasses.append([ap.GetLabel()])
                listOfSSPasses[-1].append(ap.GetReuse())
                listOfSSPasses[-1].append(ap.IsEnabled())
                if reuseSSCombobox == 0:
                    ap.Enable()
                    ap.SetReuse(0)
                elif reuseSSCombobox == 1:
                    ap.Enable()
                    ap.SetReuse(1)
                elif reuseSSCombobox == 2:
                    ap.Disable()
                    ap.SetReuse(1)                                    

    print("rSRRIBRR(31/10)")
    renderManGlobalsShadingRate=globalsSettings.GetAttr("rman__riattr___ShadingRate")
    globalsSettings.SetAttr("rman__riattr___ShadingRate", renderManGlobalsShadingRate*shadingRateScaleLE)
    if shadingRateCB:
        globalsSettings.SetAttr("rman__riattr___ShadingRate", shadingRateSB*shadingRateScaleLE)

    if motionFactorCB:
        globalsSettings.SetAttr("rman__riattr___MotionFactor", motionFactorSB)

    if focusFactorCB:
        globalsSettings.SetAttr("rman__riattr___FocusFactor", focusFactorSB)



    print("rSRRIBRR(32/10)")
    renderManGlobalsDirectlightingsamples=globalsSettings.GetAttr("rman__riopt__shading_directlightingsamples")
    globalsSettings.SetAttr("rman__riopt__shading_directlightingsamples", renderManGlobalsDirectlightingsamples*directLightSamplesScaleLE)
    print("rSRRIBRR(33/10)")
    if not mel.eval("attributeExists(\"shaveWriteRib\", \"perspShape\")"):
        cmds.addAttr("perspShape",at="bool",ln="shaveWriteRib")
    if not mel.eval("attributeExists(\"buildIfNotExists\", \"perspShape\")"):
        cmds.addAttr("perspShape",at="bool",ln="buildIfNotExists")
        cmds.setAttr("perspShape.buildIfNotExists",1)            

    print("rSRRIBRR(34/10)")
    shaveWriteRib = cmds.getAttr("perspShape.shaveWriteRib")
    if reuseShaveRibsLabel:
        if reuseShaveRibsCB:    
            cmds.setAttr("perspShape.shaveWriteRib",0)
        else:
            cmds.setAttr("perspShape.shaveWriteRib",1)            


    print("rSRRIBRR(35/10)")
    renderManGlobalsShutterAngle=globalsSettings.GetAttr("rman__toropt___shutterAngle")
    globalsSettings.SetAttr("rman__toropt___shutterAngle", renderManGlobalsShutterAngle*shutterAngleScaleLE)
    estMotionBlur=0
    estCameraBlur=0
    mbType="frame"
    shutterOpeningSB1Save=0
    shutterOpeningSB2Save=1
    shutterTimingComboboxSave="frameOpen"
    if motionBlurLabel:
        print("rSRRIBRR(351/10)")
        estMotionBlur=globalsSettings.GetAttr("rman__torattr___motionBlur")
        estCameraBlur=globalsSettings.GetAttr("rman__torattr___cameraBlur")
        shutterOpeningSB1Save=globalsSettings.GetAttr("rman__riopt__camera_shutteropening0")
        shutterOpeningSB2Save=globalsSettings.GetAttr("rman__riopt__Camera_shutteropening1")
        print("rSRRIBRR(352/10)")
        if motionBlurCB:
            globalsSettings.SetAttr("rman__torattr___motionBlur",1)
        else:
            globalsSettings.SetAttr("rman__torattr___motionBlur",0)
        if motionBlurCB2:
            globalsSettings.SetAttr("rman__torattr___cameraBlur",1)
        else:
            globalsSettings.SetAttr("rman__torattr___cameraBlur",0)
        print("rSRRIBRR(353/10)")
        globalsSettings.SetAttr("rman__toropt___shutterAngle", shutterAngleSB)
        mbType=globalsSettings.GetAttr("rman__toropt___motionBlurType")
        print("rSRRIBRR(354/10)")
        globalsSettings.SetAttr("rman__toropt___motionBlurType", motionBlurTypeCombobox)
        shutterTimingComboboxSave=globalsSettings.GetAttr("rman__toropt___shutterTiming")
        print("rSRRIBRR(355/10)")
        globalsSettings.SetAttr("rman__toropt___shutterTiming",shutterTimingCombobox)
        if not mel.eval("attributeExists(\"centr\", \"perspShape\")"):
            cmds.addAttr("perspShape",at="bool",ln="centr")
        if shutterTimingCombobox == "frameCenter":
            cmds.setAttr("perspShape.centr",1)            
        else:
            cmds.setAttr("perspShape.centr",0)                       

        print("rSRRIBRR(3551/10):"+str(shutterTimingCombobox))
        print("rSRRIBRR(356/10):"+str(shutterOpeningSB1))
        print("rSRRIBRR(357/10):"+str(shutterOpeningSB2))
        globalsSettings.SetAttr("rman__riopt__Camera_shutteropening0",shutterOpeningSB1)
        globalsSettings.SetAttr("rman__riopt__Camera_shutteropening1",shutterOpeningSB2)

    if renderManGlobalsShutterAngle != globalsSettings.GetAttr("rman__toropt___shutterAngle"): 
        if cmds.pluginInfo("shaveNode",query=True,l=True):
            if cmds.ls(type="shaveHair") != []:    
                if not cmds.objExists("shaveGlobals"):
                    mel.eval("shaveGlobalsEditor")
                cmds.setAttr("shaveGlobals.ribBlurShutterCloseOffset", globalsSettings.GetAttr("rman__toropt___shutterAngle")/360.0)
                cmds.setAttr("perspShape.shaveWriteRib",1)            

    print("rSRRIBRR(36/10)")
    renderManGlobalsStatisticOutputLE=""
    if statisticOutputLable:
        renderManGlobalsStatisticOutputLE=globalsSettings.GetAttr("rman__riopt__statistics_endofframe")
        if statisticOutputLE:
            globalsSettings.SetAttr("rman__riopt__statistics_endofframe",1)
        else:
            globalsSettings.SetAttr("rman__riopt__statistics_endofframe",0)
        globalsSettings.SetAttr("rman__riopt__statistics_xmlfilename", "[AssetRef -fullpath 1 -cls rmanstat]",type="string")


    print("rSRRIBRR(4/10)")

    disabledShaveNodes=[]
    if disableAllShaveCB:
        if cmds.pluginInfo("shaveNode",query=True,l=True):
            for shave in cmds.ls(type="shaveHair"):    
                if cmds.getAttr(shave+".active"):
                    cmds.setAttr(shave+".active",0)
                    disabledShaveNodes.append(shave)

    disabledLights=[]
    if disableAllLightsCB:
        allLights=cmds.ls(type=["RMSGeoAreaLight","RMSAreaLight","RMSEnvLight","RMSGILight","RMSGIPtcLight","RMSPointLight","directionalLight","pointLight","spotLight","areaLight"])
        for aL in allLights:
            if cmds.getAttr(cmds.listRelatives(aL,parent=True)[0]+".visibility"):
                cmds.setAttr(cmds.listRelatives(aL,parent=True)[0]+".visibility",0)
                disabledLights.append(cmds.listRelatives(aL,parent=True)[0])


    estEmmitShaders=0
    emmitRaven=1
    if disableAllShadersCB:
        if mel.eval("attributeExists(\"rman__torattr___outputSurfaceShaders\",\"rmanFinalGlobals\")"):
            estEmmitShaders=1
            emmitRaven=mel.eval("rmanGetAttr rmanFinalGlobals rman__torattr___outputSurfaceShaders")
            mel.eval("rmanSetAttr rmanFinalGlobals rman__torattr___outputSurfaceShaders 0")
        else:
            mel.eval("rmanAddAttr rmanFinalGlobals rman__torattr___outputSurfaceShaders 0")

    rayTracing=globalsSettings.GetAttr("rman__torattr___rayTracing")
    if disableRayTracingCB:
        globalsSettings.SetAttr("rman__torattr___rayTracing", 0)
    else:
        globalsSettings.SetAttr("rman__torattr___rayTracing", 1)



    listOfCamerasAndParemetrs=[]
    if dofLabel:
        for cam in cmds.ls(type="camera"):
            if cmds.getAttr(cam+".renderable"):
                listOfCamerasAndParemetrs.append([cam])
                listOfCamerasAndParemetrs[-1].append(cmds.getAttr(cam+".depthOfField"))
                listOfCamerasAndParemetrs[-1].append(cmds.getAttr(cam+".focusDistance"))
                listOfCamerasAndParemetrs[-1].append(cmds.getAttr(cam+".fStop"))
                listOfCamerasAndParemetrs[-1].append(cmds.getAttr(cam+".focusRegionScale"))
                if dofCB:
                    cmds.setAttr(cam+".depthOfField",1)
                else:
                    cmds.setAttr(cam+".depthOfField",0)
                cmds.setAttr(cam+".focusDistance",dofCB2)
                cmds.setAttr(cam+".fStop",dofSB3)
                cmds.setAttr(cam+".focusRegionScale",dofSB4)



    
    pixelSampelsSave1=3
    pixelSampelsSave2=3
    if pixelSampelsLabel:
        pixelSampelsSave1=globalsSettings.GetAttr("rman__riopt___PixelSamples0")
        pixelSampelsSave2=globalsSettings.GetAttr("rman__riopt___PixelSamples1")
        globalsSettings.SetAttr("rman__riopt___PixelSamples0",pixelSampelsSB)
        globalsSettings.SetAttr("rman__riopt___PixelSamples1",pixelSampelsSB2)


    print("rSRRIBRR(5/10) resolution: "+str(cmds.getAttr("defaultResolution.width")))


    listOfPassFilters=[]
    if filterCB:
        passes=rfm.passes.GetPasses("Final")
        for pas in range(0,len(passes)):
            dispList=passes[pas].GetDisplayList()
            for disp in range(0,len(dispList)):
                #print passes[pas].GetLabel()+" Display: "+dispList[disp].GetLabel()+" Filters: "+dispList[disp].GetAttr("rman__riopt__Display_filter")+" size: "+str(dispList[disp].GetAttr("rman__riopt__Display_filterwidth0"))+" "+str(dispList[disp].GetAttr("rman__riopt__Display_filterwidth0"))
                listOfPassFilters.append([passes[pas].GetLabel()])
                listOfPassFilters[-1].append(dispList[disp].GetID())        
                listOfPassFilters[-1].append(dispList[disp].GetAttr("rman__riopt__Display_filter"))
                listOfPassFilters[-1].append(dispList[disp].GetAttr("rman__riopt__Display_filterwidth0"))
                listOfPassFilters[-1].append(dispList[disp].GetAttr("rman__riopt__Display_filterwidth1"))
                dispList[disp].SetAttr("rman__riopt__Display_filter",filterCombobox)
                dispList[disp].SetAttr("rman__riopt__Display_filterwidth0",filter1SB)
                dispList[disp].SetAttr("rman__riopt__Display_filterwidth1",filter2SB)


    ribFormatComboboxSave=""
    ribFormatCombobox2Save=""
    if ribFormatCB:
        ribFormatComboboxSave=globalsSettings.GetAttr("rman__riopt__rib_format")
        ribFormatCombobox2Save=globalsSettings.GetAttr("rman__riopt__rib_compression")
        globalsSettings.SetAttr("rman__riopt__rib_format",ribFormatCombobox)
        globalsSettings.SetAttr("rman__riopt__rib_compression",ribFormatCombobox2)

    lazyCB1Save=0
    lazyCB2Save=0
    if lazyCB:
        lazyCB1Save=globalsSettings.GetAttr("rman__toropt___lazyRender")
        lazyCB2Save=globalsSettings.GetAttr("rman__toropt___lazyRibGen")
        if lazyCB1:
            globalsSettings.SetAttr("rman__toropt___lazyRender",1)
        else:
            globalsSettings.SetAttr("rman__toropt___lazyRender",0)
        if lazyCB2:
            globalsSettings.SetAttr("rman__toropt___lazyRibGen",1)
        else:
            globalsSettings.SetAttr("rman__toropt___lazyRibGen",0)


    passesLeftToDisable=[]
    passesRightToDisable=[]
    if selectCamerasLabel:
        rfm.passes.Update()
        passes=rfm.passes.GetPasses("Final")
        for pas in range(0,len(passes)):
            rez=re.search("Left",passes[pas].GetLabel())
            if rez:
                passesLeftToDisable.append([passes[pas].GetLabel()])
                passesLeftToDisable[-1].append(passes[pas].IsEnabled())
                if startMainCamera: passes[pas].Enable()
                else: passes[pas].Disable()
            rez=re.search("Right",passes[pas].GetLabel())
            if rez:
                passesRightToDisable.append([passes[pas].GetLabel()])
                passesRightToDisable[-1].append(passes[pas].IsEnabled())
                if startStereoCameras: passes[pas].Enable()
                else: passes[pas].Disable()

    disabledDisplays=[]
    disabledCustomFinalPassesList=[]
    if customDisplayLable:
        rfm.passes.Update()
        passes=rfm.passes.GetPasses("Final")
        for pas in range(0,len(passes)):
            dispList=passes[pas].GetDisplayList()
            for disp in range(0,len(dispList)):
                #print passes[pas].GetLabel()+" "+dispList[disp].GetLabel()
                if dispList[disp].GetLabel() != "rgba":
                    disabledDisplays.append([passes[pas].GetLabel()])
                    disabledDisplays[-1].append(dispList[disp].GetID())
                    disabledDisplays[-1].append(dispList[disp].IsEnabled())        

        for pas in range(0,len(passes)):
            dispList=passes[pas].GetDisplayList()
            for disp in range(0,len(dispList)):
                #print passes[pas].GetLabel()+" "+dispList[disp].GetLabel()
                if dispList[disp].GetLabel() != "rgba":
                    if customDisplayLE: dispList[disp].Enable() 
                    else: dispList[disp].Disable()

        for pas in range(0,len(passes)):
            if passes[pas].IsExplicit():
                disabledCustomFinalPassesList.append([passes[pas].GetLabel()])
                disabledCustomFinalPassesList[-1].append(passes[pas].IsEnabled())
                if customDisplayLE2: passes[pas].Enable() 
                else: passes[pas].Disable()


    if sceneAutoCleanCB:
        light = cmds.pointLight()
        for cam in cmds.ls(type="camera"):
            if cmds.getAttr(cam+".renderable"):
                cmds.parentConstraint( cmds.listRelatives(cam,parent=True)[0], cmds.listRelatives(light,parent=True)[0], maintainOffset=False, weight=1 )
                break


    if not setPomnyChtoBezRendera:
        '''
        sceneNameFile=cmds.file(query=True, sn=True, shn=True)
        rezScene=mel.eval("rman workspace GetProjDir")+"tmp/"+sceneNameFile
            
        if not os.path.exists(os.path.dirname(rezScene)):
            os.makedirs(os.path.dirname(rezScene))

        filetype = cmds.file(q=True,type=True)
        cmds.file(rename=rezScene)
        cmds.file(type=filetype[0],save=True)

        '''
        print("rSRRIBRR(6/10) sceneName: "+cmds.file(query=True, sn=True))
        
        ctxWasOpen = mel.eval("rman ctxIsOpen")
        melScript = cmds.getAttr("defaultRenderGlobals.preMel")
        if melScript:
            melScript=melScript.replace("\"","\\\"")
            if melScript != "":
                mel.eval("eval(\""+melScript+"\")")

        print("rSRRIBRR(6/11)")

        if not os.path.exists(mel.eval("rmanGetDataDir")):
            os.makedirs(mel.eval("rmanGetDataDir"))
        
        bctx=mel.eval("rmanBeginBatchContext(1)")
        if not ctxWasOpen:
            mel.eval("rman ctxOpen")

        print("rSRRIBRR(6/12)")

        id = str(int(mel.eval("getpid")))+str(int(mel.eval("floor(`rand 1000`)")))
        scriptFile = mel.eval("rmanGetDataDir") +"/spool_"+id+".alf"
        
        print("rSRRIBRR(6/12/1)")
        if not ctxWasOpen:
            mel.eval("rman ctxClose")
        
        print("rSRRIBRR(6/12/2)")
        spoolScript(scriptFile,frames,priority,server,cmdTags,environ,rendererArg,doneCom,errorCom,crews,extra,str(fPS),saveOrExportCB)
        print("rSRRIBRR(6/12/3)")
        mel.eval("rmanEndBatchContext(\""+bctx+"\")")

        print("rSRRIBRR(6/13)")

        if not ctxWasOpen:
            mel.eval("rman ctxClose")
            
        melScript = cmds.getAttr("defaultRenderGlobals.postMel")
        if melScript:
            melScript=melScript.replace("\"","\\\"")
            if melScript != "":
                mel.eval("eval(\""+melScript+"\")")

        print("rSRRIBRR(6/14)")


   



    if not permanentState:
        cmds.setAttr("defaultRenderGlobals.animation",tmpDefaultRenderGlobalsAnimation)
        cmds.setAttr("defaultRenderGlobals.extensionPadding",tmpDefaultRenderGlobalsExtensionPadding)
        cmds.setAttr("defaultRenderGlobals.pff", tmpDefaultRenderGlobalsPff)
        cmds.optionVar(stringValue=("rmanBatchSceneCtx",str(tmpDefaultRenderGlobalsRmanBatchSceneCtx)))

        if rezolutionCombobox!=0:
            globalsSettings.SetAttr("rman__riopt__Format_resolution0",defaultResolutionWidth)
            globalsSettings.SetAttr("rman__riopt__Format_resolution1",defaultResolutionHeight)
        

        if reuseShadowMapsLabel:
            rfm.passes.Update()
            for pas in range(0,len(listOfShadowPasses)):
                shadowPass = rfm.passes.GetPass(listOfShadowPasses[pas][0])
                shadowPass.SetReuse(listOfShadowPasses[pas][1])
                if listOfShadowPasses[pas][2]:
                    shadowPass.Enable()
                else:
                    shadowPass.Disable()
                        
        
        if reuseSSLabel:
            rfm.passes.Update()
            for pas in range(0,len(listOfSSPasses)):
                SSPass = rfm.passes.GetPass(listOfSSPasses[pas][0])
                SSPass.SetReuse(listOfSSPasses[pas][1])
                if listOfSSPasses[pas][2]:
                    SSPass.Enable()
                else:
                    SSPass.Disable()

        globalsSettings.SetAttr("rman__riattr___ShadingRate", renderManGlobalsShadingRate)
        globalsSettings.SetAttr("rman__riopt__shading_directlightingsamples", renderManGlobalsDirectlightingsamples)



        if motionBlurLabel:
            globalsSettings.SetAttr("rman__torattr___motionBlur", estMotionBlur)
            globalsSettings.SetAttr("rman__torattr___cameraBlur", estCameraBlur)
            globalsSettings.SetAttr("rman__toropt___motionBlurType",mbType)
            globalsSettings.SetAttr("rman__toropt___shutterTiming",shutterTimingComboboxSave)
            if not mel.eval("attributeExists(\"centr\", \"perspShape\")"):
                cmds.addAttr("perspShape",at="bool",ln="centr")
            if shutterTimingComboboxSave == "frameCenter":
                cmds.setAttr("perspShape.centr",1)            
            else:
                cmds.setAttr("perspShape.centr",0)                       
            globalsSettings.SetAttr("rman__riopt__Camera_shutteropening0",shutterOpeningSB1Save)
            globalsSettings.SetAttr("rman__riopt__Camera_shutteropening1",shutterOpeningSB2Save)

        if renderManGlobalsShutterAngle != globalsSettings.GetAttr("rman__toropt___shutterAngle"):
            globalsSettings.SetAttr("rman__toropt___shutterAngle", renderManGlobalsShutterAngle)
            if cmds.pluginInfo("shaveNode",query=True,l=True):
                if cmds.ls(type="shaveHair") != []:    
                    if not cmds.objExists("shaveGlobals"):
                        mel.eval("shaveGlobalsEditor")
                    cmds.setAttr("shaveGlobals.ribBlurShutterCloseOffset", renderManGlobalsShutterAngle/360.0)

        cmds.setAttr("perspShape.shaveWriteRib",shaveWriteRib)            

        if statisticOutputLable:
            globalsSettings.SetAttr("rman__riopt__statistics_endofframe", renderManGlobalsStatisticOutputLE)

        print("rSRRIBRR(7/10)")

        if disableAllShaveCB:
            if cmds.pluginInfo("shaveNode",query=True,l=True):
                for shave in disabledShaveNodes:
                    cmds.setAttr(shave+".active",1)


        if disableAllLightsCB:
            for aL in disabledLights:
                cmds.setAttr(aL+".visibility",1)



        estEmmitShaders=0
        emmitRaven=1
        if disableAllShadersCB:
            if estEmmitShaders:
                mel.eval("rmanSetAttr rmanFinalGlobals rman__torattr___outputSurfaceShaders "+emmitRaven)
            else:
                mel.eval("rmanDelAttr rmanFinalGlobals rman__torattr___outputSurfaceShaders")


        globalsSettings.SetAttr("rman__torattr___rayTracing", rayTracing)



        if dofLabel:
            for i in range(0,len(listOfCamerasAndParemetrs)):
                cmds.setAttr(listOfCamerasAndParemetrs[i][0]+".depthOfField",listOfCamerasAndParemetrs[i][1])
                cmds.setAttr(listOfCamerasAndParemetrs[i][0]+".focusDistance",listOfCamerasAndParemetrs[i][2])
                cmds.setAttr(listOfCamerasAndParemetrs[i][0]+".fStop",listOfCamerasAndParemetrs[i][3])
                cmds.setAttr(listOfCamerasAndParemetrs[i][0]+".focusRegionScale",listOfCamerasAndParemetrs[i][4])

        

        print("rSRRIBRR(8/10)")

        
        if pixelSampelsLabel:
            globalsSettings.SetAttr("rman__riopt___PixelSamples0",pixelSampelsSave1)
            globalsSettings.SetAttr("rman__riopt___PixelSamples1",pixelSampelsSave2)

        if filterCB:
            for dis in range(0,len(listOfPassFilters)):
                if listOfPassFilters[dis][2]!='': rfm.passes.GetPass(listOfPassFilters[dis][0]).GetDisplay(listOfPassFilters[dis][1]).SetAttr("rman__riopt__Display_filter",listOfPassFilters[dis][2])
                if listOfPassFilters[dis][3]!='': rfm.passes.GetPass(listOfPassFilters[dis][0]).GetDisplay(listOfPassFilters[dis][1]).SetAttr("rman__riopt__Display_filterwidth0",listOfPassFilters[dis][3])
                if listOfPassFilters[dis][4]!='': rfm.passes.GetPass(listOfPassFilters[dis][0]).GetDisplay(listOfPassFilters[dis][1]).SetAttr("rman__riopt__Display_filterwidth1",listOfPassFilters[dis][4])    


        print("rSRRIBRR(9/10)")

        if ribFormatCB:
            globalsSettings.SetAttr("rman__riopt__rib_format",ribFormatComboboxSave)
            globalsSettings.SetAttr("rman__riopt__rib_compression",ribFormatCombobox2Save)


        if lazyCB:
            globalsSettings.SetAttr("rman__toropt___lazyRender",lazyCB1Save)
            globalsSettings.SetAttr("rman__toropt___lazyRibGen",lazyCB2Save)


        if selectCamerasLabel:
            rfm.passes.Update()   
            for pas in range(0,len(passesLeftToDisable)):
                if passesLeftToDisable[pas][1]:
                    rfm.passes.GetPass(passesLeftToDisable[pas][0]).Enable()
                else:
                    rfm.passes.GetPass(passesLeftToDisable[pas][0]).Disable()        
            for pas in range(0,len(passesRightToDisable)):
                if passesRightToDisable[pas][1]:
                    rfm.passes.GetPass(passesRightToDisable[pas][0]).Enable()
                else:
                    rfm.passes.GetPass(passesRightToDisable[pas][0]).Disable()        
        
        if customDisplayLable:
            for dis in range(0,len(disabledDisplays)):
                passs=rfm.passes.GetPass(disabledDisplays[dis][0])
                display=passs.GetDisplay(disabledDisplays[dis][1])
                if disabledDisplays[dis][2] == 1:
                    display.Enable()
                else:
                    display.Disable()

            for pas in range(0,len(disabledCustomFinalPassesList)):
                if disabledCustomFinalPassesList[pas][1]:
                    rfm.passes.GetPass(disabledCustomFinalPassesList[pas][0]).Enable()
                else:
                    rfm.passes.GetPass(disabledCustomFinalPassesList[pas][0]).Disable()        


    if not setPomnyChtoBezRendera:
        if lRB:
            localQueue = mel.eval("rman getPref LocalQueueLaunchPath")
            print("local spool: "+scriptFile)
            if cmds.about(nt=True):
                os.system("start "+localQueue+" "+scriptFile)
            elif cmds.about(mac=True):
                localQueue = localQueue + ".app"
                os.system("open -a "+localQueue+" "+scriptFile+" &")
            else:
                os.system(localQueue+" "+scriptFile+" &")
        else:            
            opts=[]
            if stPaused:
                opts.append("'--paused'")
            opts.append("'--priority=" + str(priority) + "'")
            opts.append("'--engine=" + mel.eval("rman getPref TractorEngine") + "'")
            if mel.eval("rman getPref TractorUser") != "":
                opts.append("'--user=" + mel.eval("rman getPref TractorUser") + "'")
            opts.append("'" + scriptFile + "'")                                
            print("tractor spool: ["+",".join(opts)+"]")
            rfm.tractor.Spool(eval("["+",".join(opts)+"]"))
            #rfm.tractor.Spool(['--priority=1500', '--engine=192.168.254.250:80', '/renderServer/Project/UrfinJuse/assets/props/test/renderman/test_0811181933/data/spool_8154794.alf'])


def spoolScript(scriptFile,framesss="",pbias="1",service="",tags="",envKey="",rargs="",donecmd="",errcmd="",crews="",extra="",chunk="",saveOrExport=""):
    #print("spoolScript: scriptFile: "+str(scriptFile)+" pbias: "+str(pbias)+" service: "+str(service)+" tags: "+str(tags)+" envKey: "+str(envKey)+" rargs: "+str(rargs)+" donecmd: "+str(donecmd)+" errcmd: "+str(errcmd)+" crews: "+str(crews)+" extra: "+str(extra)+" chunk: "+str(chunk)+"\n")
    getDataDir=mel.eval("rmanGetDataDir")
    if not os.path.exists(getDataDir):
        os.makedirs(getDataDir)
    
    ctxWasOpen = mel.eval("rman ctxIsOpen")
    if not ctxWasOpen:
        mel.eval("rman ctxOpen -rib")
    
    jobFile = open(scriptFile, 'w')
    if jobFile is None:
        cmds.error( "Could not open Alfred script file: " + scriptFile)
        return
    
    dirmapseval = mel.eval("rman workspace GetDirMaps rib")
    dirmapseval=dirmapseval.replace("[", "")
    dirmapseval=dirmapseval.replace("]", "")
    dirmapseval=dirmapseval.replace("\"", "")
    dirmapseval=dirmapseval[:-1].split(" ")
    dirmaps = "\n    {{mayabatch} {maya} NFS}\n"
    for i in range(0,len(dirmapseval)/3):
        dirmaps+="    {{"
        dirmaps+=dirmapseval[i*3+1]
        dirmaps+="} {"
        dirmaps+=dirmapseval[i*3+2]
        dirmaps+="} "
        dirmaps+=dirmapseval[i*3]
        dirmaps+="}\n"    

    jobFile.write('##AlfredToDo 3.0\n\n')
    jobFile.write('Job -title {' + mel.eval("rman getvar \"STAGE\"") + '}')
    jobFile.write(' -comment {#Created for '+mel.eval('rman getvar USER')+' by RenderMan for Maya '+mel.eval('rman getversion') + '}')        
    jobFile.write(' -dirmaps {' + dirmaps + '}')        
    jobFile.write(' -envkey {'+envKey+'}')
    jobFile.write(' -pbias ' + str(pbias) )
    jobFile.write(' -crews {' + crews + '}')        
    jobFile.write(' -tags {' + tags + '}')
    jobFile.write(' -service {' + service + '}')
    jobFile.write(' -whendone {' + donecmd + '}')
    jobFile.write(' -whenerror {' + errcmd + '} ')
    jobFile.write(extra+' -serialsubtasks 1 -subtasks {\n')
    
    script=genRPSAlfredScript(framesss,int(chunk),rargs,saveOrExport)
    jobCleanupScript=genJobCleanupScript()
    
    jobFile.write(script)
    jobFile.write("}")            
    jobFile.write(jobCleanupScript)
    jobFile.write("\n")                        
    jobFile.close()
    
    if not ctxWasOpen:
        mel.eval("rman ctxClose")




def genRPSAlfredScript(framesss,chunk,rargs,saveOrExport):
    #print("genRPSAlfredScript: chunk: "+str(chunk)+" rargs: "+str(rargs)+"\n")
    scene = mel.eval("rmanGetSceneName")
    scenefile = mel.eval("rmanGetSceneFile")
    if not mel.eval("attributeExists(\"spoolingSceneName\", \"renderManGlobals\")"):
        cmds.addAttr("renderManGlobals",dt="string",ln="spoolingSceneName")
    
    cmds.setAttr("renderManGlobals.spoolingSceneName", scenefile,type="string")
    mel.eval("rmanSetGlobalAttr \"limits:threads\" 0")
    
    id = "pid" + str(mel.eval("getpid")) + "_" + str(mel.eval("rman timestamp"))
    scenedir = mel.eval("workspace -q -fre renderScenes")
    if scenedir == "":
        scenedir = mel.eval("workspace -q -fre renderScenes")
    
    scenedir = mel.eval("workspace -q -rootDirectory")+"renderman/" + scenedir
    
    if not os.path.exists(scenedir):
        os.makedirs(scenedir)
    
    tmpFileName = scenedir + "/" + "_"+scene + "_" + id
    filetype = cmds.file(q=True,type=True)
    filetype[0] = "mayaAscii"
	#YAGO
    print("save file: "+tmpFileName+"  "+filetype[0])
    if saveOrExport:
        tmpFileName = cmds.file(tmpFileName,type=filetype[0],ea=True,pr=True)
    else:
        tmpFileName = cmds.file(tmpFileName,type=filetype[0],ea=True)
    cmds.deleteAttr("renderManGlobals.spoolingSceneName")
    tmpFileName=tmpFileName.replace("\\","/")
    fpattr = mel.eval("rmanGetAttrName \"ribFullPaths\"")
    globals = mel.eval("rmanGetGlobals")
    fullpaths = 0
    if mel.eval("attributeExists \""+fpattr+"\" \""+ globals+"\""):
        fullpaths = cmds.getAttr(globals + "." + fpattr)
    
    renderCmd = mel.eval("rman getPref RemoteRenderCmd")
    
    if rargs != "":
        renderCmd += " " + rargs
    
    renderSvc = mel.eval("rman getPref RemoteRenderSvc")
    shoCmd = mel.eval("rman getPref ShoCmd")
    
    scriptStr = "  Task -title {Job} -serialsubtasks 1 -subtasks {\n"
    #cmds.editRenderLayerGlobals(currentRenderLayer="defaultRenderLayer")
    
    framesL=[]
    if framesss == "":
        print "1"
        anim = cmds.getAttr("defaultRenderGlobals.animation")
        start = int(cmds.getAttr("defaultRenderGlobals.startFrame"))
        end = int(cmds.getAttr("defaultRenderGlobals.endFrame"))
        by = int(cmds.getAttr("defaultRenderGlobals.byFrameStep"))
        if anim and end > start:
            print "2"
            if by == 0: by = 1            
            if by != 1: chunk=1
            tmpChunk=0
            framesL.append([])
            print "3"
            for i in range(start,end+1,by):
                if tmpChunk >= chunk:
                    tmpChunk=0
                    framesL.append([i])
                else:            
                    framesL[-1].append(i)
                tmpChunk=tmpChunk+1
        else:
            framesL.append([start])
    else:
        #framesL=[]        
        framesList=[]
        #framesss="10-34,34,35,20-10,342,1-15"
        listcommas=str(framesss).split(",")
        print("listcommas: "+str(listcommas))   
        for fX in range(0,len(listcommas)):
            listminusss=listcommas[fX].split("-")
            if type(listminusss)==type([]) and len(listminusss)==2:
                if len(listminusss[0])== 0 or len(listminusss[1])==0:
                    cmds.error("ne pravilno vvedeny diapazony!!!\n"+framesss)
                    #return
                if int(listminusss[0])<int(listminusss[1]):
                    for y in range(int(listminusss[0]),int(listminusss[1])+1):            
                        framesList.append(y)  
                elif int(listminusss[0])>int(listminusss[1]):
                    for y in range(int(listminusss[1]),int(listminusss[0])+1):            
                        framesList.append(y)  
            else:
                framesList.append(int(listminusss[0]))  
        myHash = set(framesList)
        myHash = list(myHash)            
        print("myHash: "+str(myHash))    
        
        framesL.append([])
        tmpChunk=0
        for i in myHash:
            if tmpChunk >= chunk:
                tmpChunk=0
                framesL.append([i])
            else:
                if len(framesL[-1]) and i-framesL[-1][-1] != 1:
                    tmpChunk=0
                    framesL.append([i])
                else:
                    framesL[-1].append(i)
            tmpChunk=tmpChunk+1
    
    
    
    print("framesL: "+str(framesL))
    
    scriptStr += "\n    Task -title { Preflight} -serialsubtasks 1 -subtasks {\n"
    scriptStr += genGenribTask( 1, framesL[0][0], framesL[-1][-1], tmpFileName)
    scriptStr += genExtRenderTask( 1, 0, fullpaths, renderCmd,  renderSvc, shoCmd)
    scriptStr += "    }\n"
     
    title = " "
    if framesL[0][0] != framesL[-1][-1]:
        title += "Frames " + str(int(framesL[0][0])) + "-" + str(int(framesL[-1][-1]))
    else:
        title += "Frame " + str(int(framesL[0][0]))
    scriptStr += "\n    Task -title {" + title + "} -serialsubtasks 0 -subtasks {\n"
        
    for fL in framesL:
        title = " "
        if fL[0]!=fL[-1]:
            title += "Frames " + str(int(fL[0])) + "-" + str(int(fL[-1]))
        else:
            title += "Frame " + str(int(fL[0]))
        scriptStr += "\n    Task -title {" + title + "} -serialsubtasks 1 -subtasks {\n"
        scriptStr += genGenribTask(2, fL[0], fL[-1], tmpFileName)
        if fL[0]!=fL[-1]:
            scriptStr += "      Task -title {Render  " + str(int(fL[0])) + "-" + str(int(fL[-1])) + "} -serialsubtasks 0 -subtasks {\n"
        for f in fL:
            scriptStr += genExtRenderTask(0, f, fullpaths, renderCmd, renderSvc, shoCmd)
            scriptStr += genFrameCleanupScript(f)
            scriptStr += "\n";
        if fL[0]!=fL[-1]:
            scriptStr += "\n      }\n"
        scriptStr += "    }\n"
        
    scriptStr += "    }\n"
    scriptStr += "\n  } -cleanup {\n"
    scriptStr += "   }\n"
    
    return scriptStr
        


def genGenribTask(jpf, start, end, sceneFile):
    proj = mel.eval("workspace -q -fn").replace("\\","/")
    scriptStr = ""
    if jpf == 1:
        scriptStr += "      Task -title {Generate RIB Preflight} -cmds {\n"
        e = start
    elif start != end:
        scriptStr += "      Task -title {Generate RIB " + str(int(start)) + "-" + str(int(end)) +"} -cmds {\n"
    else:
        scriptStr += "      Task -title {Generate RIB " + str(int(start))+"} -cmds {\n"
        e = start
    
    ribgenSvc = mel.eval("rman getPref RIBGenSvc")
    mayabatchPref = mel.eval("rman getPref mayabatchLaunchPath")
    mayabatch = "mayabatch"
    if mayabatchPref != "":
        mayabatch = mayabatchPref
    serviceTag = " -service {"+ribgenSvc+"}"
            
    scriptStr += "        RemoteCmd {"+mayabatch+" "
    scriptStr += "-proj \"%D("+proj+")\" -command \"renderManBatchGenRibForLayer 0 "+str(int(start))+" "+str(int(end))+" "+str(int(jpf))+"\" -file \"%D("+sceneFile+")\"} -tags {intensive}"+serviceTag+"\n"
    scriptStr += "      }\n"
    return scriptStr

def genExtRenderTask( isPreflight, frame, fullpaths, renderCmd, renderSvc, shoCmd):
    scriptStr = ""
    if isPreflight:
        if fullpaths:
            ribfile = mel.eval("rman ctxGetRibFile -preflight -fullpath  -validate 1")
        else:
            ribfile = mel.eval("rman ctxGetRibFile -preflight -validate 1")
        scriptStr += "      Task -title {Render Preflight } -cmds {\n"
    else:
        if fullpaths:
            ribfile = mel.eval("rman ctxGetRibFile -frame "+str(int(frame))+" -fullpath -validate 1")
        else:
            ribfile = mel.eval("rman ctxGetRibFile -frame "+str(int(frame))+" -validate 1")
        scriptStr += "      Task -title {Render Frame "+str(int(frame))+"} -cmds {\n"
    
    execdir = mel.eval("rman workspace GetProdDir")
    if execdir == "":
        execdir = mel.eval("rman workspace GetRootDir")
    execdir = execdir.replace("\\","/")
    
    scriptStr += "        RemoteCmd {"+renderCmd+" -cwd \"%D(" + execdir +")\" \"%D(" + ribfile + ")\"} -service {"+renderSvc+"}"
    scriptStr += "\n      }"
    scriptStr += genPreviewChaser(int(isPreflight), int(frame), int(frame), 1, shoCmd)
    
    return scriptStr


def genPreviewChaser(isPreflight,start,end,by,shoCmd):
    #print("genPreviewChaser: isPreflight: "+str(isPreflight)+" anim: "+str(anim)+" start: "+str(start)+" end: "+str(end)+" by: "+str(by)+" shoCmd: "+str(shoCmd)+"\n")
    scriptStr = ""
    ctxIsOpen = mel.eval("rman ctxIsOpen")
    if ctxIsOpen:
        #print "genPreviewChaser open"
        tasks = mel.eval("rman ctxGetTasks")
        imgfiles=[]
        k=0
        l=0
        #print "genPreviewChaser open "+str(tasks)                            
        for j in tasks:
            imgfile="";
            if isPreflight:
                imgfile = mel.eval("rman ctxGetImageFile \""+str(j)+"\" -preflight -fullpath")
                if len(imgfile):
                    imgfiles.append(imgfile)
                    k=k+1
            else:
                l=start
                while l<=end:
                    imgfile = mel.eval("rman ctxGetImageFile \""+str(j)+"\" -frame "+str(int(l))+" -fullpath")
                    if len(imgfile):
                        imgfiles.append(imgfile)
                        k=k+1
                    l=l+by 
        #print "genPreviewChaser open "+str(len(imgfiles))                    
        if len(imgfiles):
            scriptStr += " -preview {"+shoCmd+" "
            for j in imgfiles:
                scriptStr += "\""+str(j)+"\"" + " "
            scriptStr += "}"
    else:
        #print "genPreviewChaser else"
        imageDir = mel.eval("rmanGetImageDir()").replace("\\","/")
        imageName = mel.eval("rmanGetImageName(0)")
        imageName = mel.eval("substituteAllString "+imageName+" \"0\" \"@\"")
        scriptStr += " -preview {\n"
        scriptStr += "        fcheck "
        if start != end:
            scriptStr += "-n " + str(int(start)) + " " + str(int(end)) + " " + str(int(by)) + " "
        scriptStr += imageDir + "/" + imageName + ""
        scriptStr += "}"

    return scriptStr
 


def genJobCleanupScript():
    #print("genJobCleanupScript\n")
    taskStr=""
    indent = "    "
    jdc = mel.eval("rmanGetDataCleanupJob")
    jtc = mel.eval("rmanGetTextureCleanupJob")
    jrc = mel.eval("rmanGetRibCleanupJob")
    jsc = mel.eval("rmanGetShaderCleanup")
        
    renderSvc = mel.eval("rman getPref RemoteRenderSvc")
    
    if jdc or jtc or jrc or jsc:
        globals = mel.eval("rmanGetGlobals")
        referenceFrame = cmds.getAttr(globals+".rman__torattr___referenceFrame")
        frames=[]
        frames.append("job")
        frames.append(referenceFrame)
        
        taskStr += " -cleanup {\n"
        for i in frames:
            frameArg = ""
            if i != "job":
                frameArg = " -frame "+str(i)
            
            if jdc:
                dir = mel.eval("rman ctxGetDataDir"+frameArg)
                if not os.path.exists(dir):
                    os.makedirs(dir)
                if dir != "":
                    taskStr += indent+"    RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                    taskStr += " -service {" + renderSvc +"}"
                taskStr += "\n"
            if jtc:
                dir = mel.eval("rman ctxGetTextureDir"+frameArg)
                if not os.path.exists(dir):
                    os.makedirs(dir)
                if dir != "":
                    taskStr += indent+"    RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                    taskStr += " -service {" + renderSvc + "}\n"
                taskStr += "\n"
            if jrc:
                dir = mel.eval("rman ctxGetRibDir"+frameArg)
                if not os.path.exists(dir):
                    os.makedirs(dir)
                if dir != "":
                    taskStr += indent+"    RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                    taskStr += " -service {" + renderSvc + "}\n"
                taskStr += "\n"
            if jsc:
                dir = mel.eval("rman ctxGetShaderDir"+frameArg)
                if not os.path.exists(dir):
                    os.makedirs(dir)
                if dir != "":
                    taskStr += indent+"    RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                    taskStr += " -service {" + renderSvc + "}\n"
                taskStr += "\n"
        
        taskStr += "}\n"
        
    return taskStr


def genFrameCleanupScript(frame):
    #print("genFrameCleanupScript: frame: "+str(frame)+"\n")
    taskStr=""
    indent = "    "
    fdc = mel.eval("rmanGetDataCleanupFrame")
    ftc = mel.eval("rmanGetTextureCleanupFrame")
    frc = mel.eval("rmanGetRibCleanupFrame")
    renderSvc = mel.eval("rman getPref RemoteRenderSvc")
    if fdc or ftc or frc:
        taskStr += " -cleanup {\n"
        if fdc:
            dir = mel.eval("rman ctxGetDataDir -frame "+str(frame))
            if not os.path.exists(dir):
                os.makedirs(dir)
            if dir != "":
                taskStr += "            RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                taskStr += " -service {"+renderSvc+"}"
            taskStr+="\n"
        if ftc:
            dir = mel.eval("rman ctxGetTextureDir -frame "+ str(frame) )
            if not os.path.exists(dir):
                os.makedirs(dir)
            if dir != "":
                taskStr += "            RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                taskStr += " -service {"+renderSvc+"}"
            taskStr+="\n"
        if frc:
            dir = mel.eval("rman ctxGetRibDir -frame "+ str(frame) )
            if not os.path.exists(dir):
                os.makedirs(dir)
            if dir != "":
                taskStr += "            RemoteCmd {Alfred} -msg {File delete \"%D("+dir+")\"}"
                taskStr += " -service {"+renderSvc+"}"
            taskStr+="\n"
        
        taskStr+="}\n"
        
    return taskStr

def sendScriptToTractor( jobTitle="untitled", environmentKeyLE="", jobPriorityLE=1500, jobServerAttrubutesLE="", jobScriptTasks=[], startPausedCB=False ):
    processArglist = ["-batch","-command","\"%D()\""]
    dirmapseval = mel.eval("rman workspace GetDirMaps rib")
    dirmapseval = dirmapseval.replace("[", "")
    dirmapseval = dirmapseval.replace("]", "")
    dirmapseval = dirmapseval.replace("\"", "")
    dirmapseval = dirmapseval[:-1].split(" ")
    dirmaps = "\n    {{mayabatch} {maya} nfs}\n"
    for i in range(0,len( dirmapseval )/3 ):
        dirmaps += "\t{{"
        dirmaps += dirmapseval[i*3+1]
        dirmaps += "} {"
        dirmaps += dirmapseval[i*3+2]
        dirmaps += "} "
        dirmaps += dirmapseval[i*3]
        dirmaps += "}\n"
    for i in range( 0, len( jobScriptTasks )):
        dirmaps += (("\t{{script%s} {"+jobScriptTasks[i]+"} unc}\n\t{{script%s} {"+jobScriptTasks[i]+"} nfs}\n") % ( i, i ))
    getDataDir = mel.eval("rmanGetDataDir")
    getDataDir += "/.alfredMayaScripts"
    if not os.path.exists(getDataDir):
        os.makedirs(getDataDir)
    currentTime = time.strftime( "%a, %d %b %Y %H:%M:%S +0000", time.gmtime())
    fnm = getDataDir.replace("\\", "/") + "/" + jobTitle + "_" + str(time.time()).split(".")[0] + ".alf"
    jobFile = open(fnm, "w")
    jobFile.write( "##AlfredToDo 3.0\n\n" )
    jobFile.write( "Job -title {" + fnm.split("/")[-1].split(".")[0] + "}" )
    jobFile.write( " -comment {#Generated: " + str( currentTime ) + "        " + ( ";".join( jobScriptTasks )) + "}" )        
    jobFile.write( " -dirmaps {" + dirmaps + "}" )        
    jobFile.write( " -envkey {" + environmentKeyLE + "}" )        
    jobFile.write( " -pbias " + str(jobPriorityLE) + "" )
    jobFile.write( " -crews {}" )        
    jobFile.write( " -tags {}" )
    jobFile.write( " -service {" + jobServerAttrubutesLE + "}" )
    jobFile.write( " -whendone {}" )
    jobFile.write( " -whenerror {}" )
    jobFile.write( " -serialsubtasks 1 -subtasks {\n" )
    jobFile.write( "\tTask -title {Job} -serialsubtasks 0 -subtasks {\n" )
    cmdtail = "-tags {intensive} -service {mayaBatch}" 
    for i in range( 0, len( jobScriptTasks )):
        title = "File num:" + str(i+1)
        jobFile.write( "\t\tTask -title {" + title + "} -cmds {\n" )
        processArglist[2] = "\"%D(script" + str(i) + ")\""
        joinedArgs = " ".join( processArglist )
        print joinedArgs
        jobFile.write( "\t\t\tRemoteCmd {%D(mayabatch) "+ joinedArgs + "} " + cmdtail + "\n" )
        jobFile.write( "\t\t}\n" )
    jobFile.write( "\t}" )
    jobFile.write( "}\n" )
    jobFile.close()
    #shutil.copy( fnm, "D:/spoolTestAlfred.alf" )
    print "file write: " + fnm
    opts = []
    if startPausedCB:
        opts.append( "\"--paused\"" )
    opts.append( "\"--priority=" + str( jobPriorityLE ) + "\"")
    opts.append( "\"--engine=" + mel.eval( "rman getPref TractorEngine" ) + "\"" )
    if mel.eval( "rman getPref TractorUser") != "":
        opts.append( "\"--user=" + mel.eval("rman getPref TractorUser" ) + "\"" )
    opts.append( "\"" + fnm + "\"" )                                
    print( "tractor spool: ["+",".join( opts )+"]" )
    rfm.tractor.Spool( eval( "["+",".join( opts )+"]" ))
    if not os.path.exists( getDataDir ):
        os.makedirs( getDataDir )                
    if os.path.exists(fnm):
        try:
            os.remove(fnm)    
        except:
            print( "ERROR EXEPTION REMOVE FILE: " + fnm )
