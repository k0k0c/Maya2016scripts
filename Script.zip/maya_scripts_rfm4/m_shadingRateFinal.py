import maya.cmds as cmds
import maya.mel as mel
import re

def m_shadingRateFinal():
	m_sel = cmds.ls( sl=True )
	for i in range( 0, len( m_sel )):
		if cmds.attributeQuery( "rman__torattr___transformBeginScript", n=m_sel[i], exists=True ):
			m_regexp = re.compile( "if\(`rman getvar CLASS` == [\\\"]+Final[\\\"]+\) \{RiShadingRate [0-9.]+;\}" )
			m_strBaseVal = cmds.getAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i] )
			m_strVal = m_regexp.findall( m_strBaseVal )
			m_strVal = m_strVal and m_strVal[0] or ""
			m_strShRate = re.findall( "RiShadingRate [0-9.]+", m_strVal )
			m_strShRate = m_strShRate and m_strShRate[0] or ""
			m_floatShRate = re.findall( "[0-9.]+", m_strShRate )
			m_floatShRate = m_floatShRate and float( m_floatShRate[0] ) or 5.0
			m_floatShRate = m_floatShRate / 2
			if m_floatShRate < 0.1:
				if m_floatShRate < 0.06:
					m_floatShRate = 1.0
				else:
					m_floatShRate = 0.1
				print "Shading rate %s" % m_floatShRate
			#Setup values.
			if m_strVal == "":
				cmds.setAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i], "%s; %s" % ( m_strBaseVal, "if(`rman getvar CLASS` == \"Final\") {RiShadingRate 1.0;}" ), type="string" )
				print "Add shading rate to: %s" % m_sel[i]
			elif m_strVal != "" and m_strShRate != 0:
				m_strValue_new = re.sub( "RiShadingRate [0-9.]+", "RiShadingRate %s" % m_floatShRate, m_strVal )
				m_strBaseVal = m_regexp.sub( m_strValue_new, m_strBaseVal )
				cmds.setAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i], m_strBaseVal, type="string" )
				print "Set shading rate to: %s" % m_sel[i]
			else:
				cmds.error( "Please check: %s !" % m_sel[i] )
		else:
			mel.eval( 'rmanAddAttr %s rman__torattr___transformBeginScript (\"if(`rman getvar CLASS` == \\"Final\\") {RiShadingRate 1.0;}\")' % m_sel[i] )
	return m_sel
	
def m_shadingRatePass( passName="", add=False, remove=False, delete=False, set=False ):
	m_args = [ add, remove, delete, set ]
	m_args = [ m_args[i] for i in range( 0, len( m_args )) if m_args[i] is True ]
	if len( m_args ) >1:
		cmds.error( "Please specify one argument." )
	elif len( m_args ) == 1:
		pass
	else:
		add = True
	m_sel = cmds.ls( sl=True )
	for i in range( 0, len( m_sel )):
		if cmds.attributeQuery( "rman__torattr___transformBeginScript", n=m_sel[i], exists=True ):
			m_str = "if\(`rman getvar CLASS` == [\\\"]+%s[\\\"]+\) \{RiShadingRate [0-9.]+;\}" % passName
			m_regexp = re.compile( "{0}|[ ;]+{0}|{0}[ ;]+".format( m_str ) )
			m_strBaseVal = cmds.getAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i] )
			m_strVal = m_regexp.findall( m_strBaseVal )
			m_strVal = m_strVal and m_strVal[0] or ""
			if delete is False:
				m_strShRate = re.findall( "RiShadingRate [0-9.]+", m_strVal )
				m_strShRate = m_strShRate and m_strShRate[0] or ""
				m_floatShRate = re.findall( "[0-9.]+", m_strShRate )
				m_floatShRate = m_floatShRate and float( m_floatShRate[0] ) or 5.0
				if set is False:
					if add is True:
						if m_floatShRate < 1.0:
							m_floatShRate = m_floatShRate * 2.0
						else:
							m_floatShRate = m_floatShRate + 1.0
						if m_floatShRate > 5.0:
							m_floatShRate = 1.0
					elif remove is True:
						m_floatShRate = m_floatShRate / 2
						if m_floatShRate < 0.1:
							if m_floatShRate < 0.06:
								m_floatShRate = 1.0
							else:
								m_floatShRate = 0.1
				else:
					m_floatShRate = set
				print "Shading rate %s" % m_floatShRate
				#Setup values.
				if m_strVal == "":
					cmds.setAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i], "%s; %s" % ( m_strBaseVal, "if(`rman getvar CLASS` == \"%s\") {RiShadingRate 1.0;}" % passName ), type="string" )
					print "Add shading rate to: %s" % m_sel[i]
				elif m_strVal != "" and m_strShRate != 0:
					m_strValue_new = re.sub( "RiShadingRate [0-9.]+", "RiShadingRate %s" % m_floatShRate, m_strVal )
					m_strBaseVal = m_regexp.sub( m_strValue_new, m_strBaseVal )
					cmds.setAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i], m_strBaseVal, type="string" )
					print "Set shading rate to: %s" % m_sel[i]
				else:
					cmds.error( "Please check: %s !" % m_sel[i] )
			else:
				m_strBaseVal = m_regexp.sub( "", m_strBaseVal )
				cmds.setAttr( "%s.rman__torattr___transformBeginScript" % m_sel[i], m_strBaseVal, type="string" )
				print "Remove shading rate from: %s" % m_sel[i]
				if not re.findall( "[A-z0-9._]+", m_strBaseVal, re.IGNORECASE ):
					cmds.deleteAttr( m_sel[i], at='rman__torattr___transformBeginScript' )
		else:
			if delete is False:
				mel.eval( 'rmanAddAttr %s rman__torattr___transformBeginScript (\"if(`rman getvar CLASS` == \\"%s\\") {RiShadingRate 1.0;}\")' % ( m_sel[i], passName ))
	return m_sel