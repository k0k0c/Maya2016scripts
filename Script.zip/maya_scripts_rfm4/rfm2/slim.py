#
#  slim.py  $Revision: #1 $  $Date: 2014/02/07 $
#   facilities for attaching and querying Slim-shader attachments
#
# ------------------------------------------------------------------------------
#
# Copyright (c) 2010 Pixar Animation Studios. All rights reserved.
#
# The information in this file is provided for the exclusive use of the
# software licensees of Pixar.  It is UNPUBLISHED PROPRIETARY SOURCE CODE
# of Pixar Animation Studios; the contents of this file may not be disclosed
# to third parties, copied or duplicated in any form, in whole or in part,
# without the prior written permission of Pixar Animation Studios.
# Use of copyright notice is precautionary and does not imply publication.
#
# PIXAR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
# ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT
# SHALL PIXAR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES
# OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
# ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
# SOFTWARE.
#
# Pixar
# 1200 Park Ave
# Emeryville CA 94608
#
# ------------------------------------------------------------------------------
import maya.mel as mel
import maya.cmds
import rfm

""" rfm's Slim module, revision $Revision: #1 $

    This module implements RfM/Slim functionality including Slim IPC
    and RfM/Maya binding of Slim entities.

"""

s_slim = None
def GetSlim():
    global s_slim
    if not s_slim:
        s_slim = Slim()
    return s_slim

class Slim(object):
    """ This class embodies Slim operations for use within RfM.

        Start Slim:  obj.Start()
        Stop Slim:  obj.Stop();
        Send Slim a message:  obj.Msg("your message")
        Query Slim State:  obj.Cmd("your query") (returns string result)
    """

    # -------------------------------------------------------------
    # The Slim binding slots are represented in the maya scene as 
    # dynamic string attributes associated with DAG and ShadingEngine nodes.
    # These values represent the names of the attributes and must agree
    # with the RfM plugin names.
    k_Ensemble = "rman__torattr___slimEnsemble"
    k_Surface = "rman__torattr___slimSurface"
    k_Displacement = "rman__torattr___slimDisplacement"
    k_Atmosphere = "rman__torattr___slimAtmosphere"
    k_Interior = "rman__torattr___slimInterior"
    k_Exterior = "rman__torattr___slimExterior"
    k_AreaLight = "rman__torattr___slimAreaLight"
    k_Light = "rman__torattr___slimLight"
    k_Shader = "rman__torattr___slimShader"
    k_Imager = "rman__torattr___slimImager"
    k_PixelSampleImager = "rman__torattr___slimPixelSampleImager"
    k_RIBBox = "rman__torattr___slimRIBBox"
    k_BindingStrength = "rman__torattr___shaderBindingStrength"

    k_Invalid = "_invalid_"
    k_KnownSlots = [k_Ensemble, k_Surface, k_Displacement, 
                    k_Interior, k_Atmosphere, k_Exterior,
                    k_Light, k_AreaLight, k_Shader, k_RIBBox,
                    k_Imager, k_PixelSampleImager]
    k_KnownSlotSet = set(k_KnownSlots)
    k_MultiSlots = [k_Light, k_Shader, k_AreaLight, k_RIBBox]

    # SlimAttrMap: maps user's names for slim slots to maya lingo
    k_SlimAttrMap = {
        "ensemble": k_Ensemble,
        "surface": k_Surface,
        "coshader": k_Shader,
        "displacement": k_Displacement,
        "light": k_Light,
        "arealight": k_AreaLight,
        "atmosphere": k_Atmosphere,
        "interior": k_Interior,
        "exterior": k_Exterior,
        "imager": k_Imager,
        "pixelsampleimager": k_PixelSampleImager,
        "ribbox": k_RIBBox,
        "strength": k_BindingStrength
    }
    # SlimAttrInvMap: maps maya's names for slim slots to user lingo
    k_SlimAttrInvMap = {
        k_Ensemble: "ensemble",
        k_Surface: "surface",
        k_Shader: "coshader",
        k_Displacement: "displacement",
        k_Light: "light",
        k_AreaLight: "arealight",
        k_Atmosphere: "atmosphere",
        k_Interior: "interior",
        k_Exterior: "exterior",
        k_Imager: "imager",
        k_PixelSampleImager: "pixelsampleimager",
        k_RIBBox: "ribbox",
        k_BindingStrength: "strength",
    }
    # SlimSlotPrecedenceMap: characterizes the conflict-resolution associated
    #   with slot semantic ambiguities. When an attachment is requested,
    #   we explicitly detach bindings at the associated slots.
    k_SlimSlotPrecedenceMap = {
        k_Ensemble: [k_Surface, k_Displacement],
        k_Surface: [k_Ensemble],
        k_Displacement: [k_Ensemble]
    }

    # The binding strength determines whether slim shading at
    # a particular node in the DAG will "win" over more leafward
    # nodes. 

    # -------------------------------------------------------------
    def __init__(self):
        pass

    def Running(self):
        return mel.eval("rman slim isconnected")

    def Start(self):
        mel.eval("rman slim start")

    def Stop(self):
        mel.eval("rman slim stop")
    
    def Msg(self, msg):
        mel.eval("rman slim message %s" % msg)

    def Cmd(self, cmd):
        return mel.eval("rman slim command %s" % cmd)

    def IsMultiSlot(self, slot):
        return slot in self.k_MultiSlots

    def UnbindFromSelection(self, appId, appSlot,
                            shapesOnly=False, masterLayerOnly=False):
        """Unbinds an appearance id from the appearance slots from
           objects associated with the current selection.
        """
        sel = maya.cmds.ls(selection=True, long=True, flatten=True)
        # nb: we ignore shapesOnly - since mixed-attachments modes
        # might produce un-detachable situations.
        if len(sel):
            self.UnbindFromObjects(sel, appId, appSlots=[appSlot], 
                                   masterLayerOnly=masterLayerOnly)

    def UnbindById(self, appId=None, appSlots=[k_Surface], 
                    masterLayerOnly=False):
        """Unbinds an appearance id from the appearance slots from all 
            objects in the scene.
        """
        if not appId: return
        olist = self.GetAssociatedObjects(appId, appSlots, False)
        if len(olist):
            self.UnbindFromObjects(olist, appId, appSlots, 
                                masterLayerOnly=masterLayerOnly)

    def BindToSelection(self, appId=None, appSlot=k_Surface, 
                        bindingStrength=None, 
                        shapesOnly=False, 
                        masterLayerOnly=False):
        """Bind a Slim appearance to the binding slot of the selected objects.
            
           Available binding slots:
                Slim.k_Ensemble
                Slim.k_Surface
                Slim.k_Displacement
                Slim.k_Interior
                Slim.k_Atmosphere
                Slim.k_Shader
                Slim.k_AreaLight
                Slim.k_Light  - binds only to light-shape nodes.
                Slim.k_Imager - binds only to camera-shape nodes.
                Slim.k_PixelSampleImager - binds only to camera-shape nodes.
                Slim.k_RIBBox 
        """
        if bindingStrength == None:
            slot = self.getMayaSlotAttr(appSlot)
            if slot in [self.k_Shader, self.k_RIBBox]:
                # default strength differs, 0 is the default
                # binding strength for maya-bound shaders and we
                # want to ensure that these can be used with
                # maya-bound shaders.
                bindingStrength = 0
            else:
                bindingStrength = 1
        sel = maya.cmds.ls(selection=True, long=True, flatten=True)
        if shapesOnly:
            sel = self.getShapesFromObjlist(sel)
        num = 0
        if sel and len(sel):
            num = self.BindToObjects(sel, appId, appSlot, bindingStrength,
                                     masterLayerOnly=masterLayerOnly)
        if not num:
            rfm.Log(rfm.WARNING, "No Slim bindings apply for these operands")

    def BindToObjects(self, objList=[], appId=None, appSlot=k_Surface, 
                            bindingStrength=1, 
                            setMultiSlot=False,
                            masterLayerOnly=False):
        """Bind a Slim appearance to the binding slot of a list of objects.
Returns the number of successful bindings applied.
            
           Available binding slots:
                Slim.k_Ensemble
                Slim.k_Surface
                Slim.k_Displacement
                Slim.k_Interior
                Slim.k_Atmosphere
                Slim.k_Shader
                Slim.k_AreaLight
                Slim.k_Light - binds only to light-shape nodes.
                Slim.k_Imager - binds only to camera-shape nodes.
                Slim.k_PixelSampleImager - binds only to camera-shape nodes.
                Slim.k_RIBBox 
        """
        num = 0
        if len(objList) == 0 or appId == None:
            return num
        slot = self.getMayaSlotAttr(appSlot)
        if masterLayerOnly:
            addLayerOverride = False
        else:
            addLayerOverride = not self.isDefaultRenderLayer()
        for o in objList:
            (oo, addstrength, multi) = self.getBinding(o, slot)
            if not oo: continue
            num = num + 1 # accumulate statistics
            if addstrength:
                attrRef = "%s.%s" % (oo, self.k_BindingStrength)
                if not maya.cmds.objExists(attrRef):
                    # currently we only change the binding strength if
                    # one isn't already available
                    maya.cmds.addAttr(oo, ln=self.k_BindingStrength, 
                                          at="short", defaultValue=1)
                    if addLayerOverride:
                        self.addLayerOverride(attrRef) 
                    maya.cmds.setAttr(attrRef, bindingStrength)
                else:
                    if maya.cmds.getAttr(attrRef) == 0 and \
                       slot == self.k_Surface:
                        maya.cmds.warning(attrRef + "is set to 0. " \
                            "Surface shader will not render unless > 0.")

            attrRef = "%s.%s" % (oo, slot)
            if not maya.cmds.objExists(attrRef):
                maya.cmds.addAttr(oo, ln=slot, dt="string")

            if multi and not setMultiSlot:
                old = maya.cmds.getAttr(attrRef)
                if not old or not appId in old:
                    if not old or old == "":
                        newid = appId
                    else:
                        newid = "%s,%s" % (old, appId)
                    if addLayerOverride:
                        self.addLayerOverride(attrRef) 
                    maya.cmds.setAttr(attrRef, newid, typ="string")
            else:
                if addLayerOverride:
                    self.addLayerOverride(attrRef) 
                maya.cmds.setAttr(attrRef, appId, typ="string")

        if slot in self.k_SlimSlotPrecedenceMap:
            self.UnbindFromObjects(objList, "<all>",
                                   self.k_SlimSlotPrecedenceMap[slot])
        return num


    def UnbindFromObjects(self, objList=[], appId=None, appSlots=[k_Surface],
                          masterLayerOnly=False):
        """ Unbinds the appId from objList. Behavior differs slightly for 
            multislots. The meta-id "<all>" can be provided
            to request deletion of all ids from the specified slots.
        """
        if len(objList) == 0 or appId == None:
            return
        isDefaultLayer = self.isDefaultRenderLayer()
        if masterLayerOnly:
            addLayerOverride = False;
        else:
            addLayerOverride = not isDefaultLayer
        for slot in appSlots:
            slot = self.getMayaSlotAttr(slot)
            multi = self.IsMultiSlot(slot) 
            for o in objList:
                (oo, addstrength, multi) = self.getBinding(o, slot)
                if not oo: continue
                attrRef = "%s.%s" % (oo, slot)
                if not maya.cmds.objExists(attrRef):
                    continue
                val = maya.cmds.getAttr(attrRef)
                if appId == "<all>" or appId == None:
                    okayToDelete = True
                elif not appId in val:
                    continue
                else:
                    okayToDelete = False
                    if not multi:
                        okayToDelete = True
                    else:
                        m = val.split(",")
                        m.remove(appId)
                        if len(m) > 0:
                            val = ",".join(m)
                            if addLayerOverride:
                                self.addLayerOverride(attrRef)
                            maya.cmds.setAttr(attrRef, val, typ="string")
                        else:
                            okayToDelete = True
                if okayToDelete:
                    if self.attributeHasLayerOverride(attrRef):
                        if isDefaultLayer:
                            maya.cmds.setAttr(attrRef,"",type="string")
                        else:
                            self.removeLayerOverride(attrRef)
                    else:
                        if addLayerOverride:
                            self.addLayerOverride(attrRef)
                            maya.cmds.setAttr(attrRef,"",type="string")
                        else:
                            maya.cmds.deleteAttr(attrRef)
                            dynAttr = maya.cmds.deleteAttr(oo, q=True)
                            if dynAttr and \
                               not len(set(dynAttr) & self.k_KnownSlotSet):
                                attrRef = "%s.%s" % (oo, self.k_BindingStrength)
                                if maya.cmds.objExists(attrRef):
                                    maya.cmds.deleteAttr(attrRef)

    def SelectBoundNodes(self, appId="", appName="", appSlots=None):
        """ Selects the maya nodes associated with the name and/or id provided.

            The optional appSlots argument allows you to reduce the search
            associated with the appId argument.  It can either be a string 
            or a list of strings indicating which slots to search.

            When selecting by appName, we simply search for shadingEngine
            nodes of that name.
        """
        maya.cmds.select(None, r=True) # clear selection
        nmlist = []
        if appName:  # select by name, nodes in the scene...
            o = maya.cmds.ls(appName)
            if o and len(o):
                for cnx in maya.cmds.listConnections(o[0], s=1):
                    if maya.cmds.nodeType(cnx) == "shadingEngine":
                        nmlist.append(cnx)
                        maya.cmds.select(nmlist, r=False)
        if appId:
            nmlist = self.GetAssociatedObjects(appId, appSlots, False)
            if nmlist and len(nmlist):
                maya.cmds.select(nmlist, r=False)

    def GetAssociatedObjects(self, appId, appSlots=None, updateSelection=True):
        """ Returns the objects which have the provided appId assigned.

            The optional appSlots argument allows you to reduce the search.
            It can either be a string or a list of strings indicating which
            slots to search.
        """
        olist = self.getPotentialAttachmentSites()
        if appSlots == None:
            slotlist = self.k_KnownSlots
        else:
            if not hasattr(appSlots, "extend"):  # quacks like a list
                appSlots = [appSlots]
            slotlist = [self.getMayaSlotAttr(s) for s in appSlots]
        result = []
        for o in olist:
            try:
                for slot in slotlist:
                    (oo, addstrength, multi) = self.getBinding(o, slot)
                    if not oo: continue
                    attrRef = "%s.%s" % (oo, slot)
                    if maya.cmds.objExists(attrRef):
                        nodes = maya.cmds.ls( attrRef )
                        for node in nodes:
                            attrValue =  maya.cmds.getAttr(node)
                            if attrValue and appId in attrValue:
                                result.append(oo)
                                raise StopIteration; # slotlist
            except StopIteration:
                pass
        if updateSelection:
            maya.cmds.select(olist)
        return result

    def SelectionChangedEvent(self):
        """ Invoked when the maya selection is changed.

            Returns a string comprised of opaque appearances IDs suitable
            for consumption by Slim.
        """
        if self.Running():
            result = " ".join(self.GetSelectedAppearances())
        else:
            result = ""
        return result
            
    def GetSelectedAppearances(self):
        """ Invokes GetAssociatedAppearances on the current selection.
        """
        sel = maya.cmds.ls(selection=True)
        return self.GetAssociatedAppearances(sel);

    #
    # format of a slim-binding file
    # {
    #   "_Header": {
    #       "version": 1,
    #       "created": "date",
    #       "creator": "rfm version",
    #       "author": "user"
    #       "contents": ["RfMSlimBindings", "SlimAppearances"]
    #   },
    #   "RfMSlimBindings": {
    #       "objpath1": {
    #           "strength": 0,
    #           "slotnm1": "appearancid(s)",
    #           "slotnm1": "appearancid(s)"
    #       }
    #   }
    #   "SlimAppearances": ["id1", "id2", ...]
    # }
    #
    # where appearanceid(s) is a single comma separated string when
    # a multislot appearance is involved.
    #
    def ExportBindings(self, filename):
        """ Exports a json file table of Slim bindings. This file can
        be used to rebind Slim appearances via the ImportBindings method.
        """
        try:
            import json
        except:
            raise Exception("ExportBindings requires json module (python 2.6)")

        try:
            import getpass
            import time

            file = open(filename, "w")

        except:
            rfm.Error("Can't export bindings to " % filename)

        body = {}
        header = {}
        bindings = {}
        appearances = {}
        strengthkey = self.k_SlimAttrInvMap[self.k_BindingStrength] 
        objlist = self.getPotentialAttachmentSites()
        for o in objlist:
            for slot in self.k_KnownSlots:
                (oo, addstrength, multi) = self.getBinding(o, slot)
                if not oo: continue
                attrRef = "%s.%s" % (oo, slot)
                if not maya.cmds.objExists(attrRef):
                    continue
                attrval = maya.cmds.getAttr(attrRef)
                if not attrval or not len(attrval):
                    continue
                if not oo in bindings:
                    bindings[oo] = {}
                    anm = "%s.%s" % (oo, self.k_BindingStrength)
                    if maya.cmds.objExists(anm):
                        bindings[oo][strengthkey] = maya.cmds.getAttr(anm)
                bindings[oo][self.k_SlimAttrInvMap[slot]] = attrval
                if multi:
                    for id in attrval.split(","):
                        appearances[id] = True
                else:
                    id = attrval
                    appearances[id] = True
        body["_Header"] = header
        body["RfMSlimBindings"] = bindings
        body["SlimAppearances"] = appearances.keys(); # list
        header["version"] = "Pixar's RfM %s" % mel.eval("rman getversion")
        header["created"] = time.asctime()
        header["author"] = getpass.getuser()
        header["contents"] = "RfMSlimBindings"
        header["context"] = maya.cmds.file(q=True, sceneName=True)
        json.dump(body, file, indent=1)
        file.close()
        rfm.Notice("Slim bindings written to: %s" % filename)

    def ImportBindings(self, filename, namespace=None):
        """ Imports a json file previously exported wiht ExportBindings.
        During import we apply
        """
        try:
            import json
            file = open(filename, "r")
        except:
            raise Exception("ImportBindings requires json module (python 2.6)")
        body = json.load(file)
        file.close()

        if not "_Header" in body or \
           not body["_Header"]["contents"] == "RfMSlimBindings":
            raise Exception("JSON file doesn't include RfMSlimBindings")

        missing = []
        bindings = body["RfMSlimBindings"]
        strengthkey = self.k_SlimAttrInvMap[self.k_BindingStrength] 
        for objnm in bindings:
            if maya.cmds.objExists(objnm):
                binding = bindings[objnm]
                try: 
                    strength = binding[strengthkey]
                except:
                    strength = 1 # default
                for attrnm in binding:
                    if attrnm != strengthkey:
                        attrval = binding[attrnm]
                        self.BindToObjects([objnm], attrval, attrnm, strength,
                                          setMultiSlot=True)
            else:
                missing.append(objnm)
        if len(missing):
            rfm.Warning("ImportBindings couldn't finding these objects: %s" %
                        missing)

    def ClearBindings(self, masterLayerOnly=False):
        """ClearBindings deletes all slim bindings on the current render layer.
           If you wish to only clear bindings in the masterLayer, issue:
           slim.ClearBindings(masterLayerOnly=True)
        """
        objlist = self.getPotentialAttachmentSites()
        self.UnbindFromObjects(objlist, "<all>", self.k_KnownSlots,
                                masterLayerOnly=masterLayerOnly);

    def RemapBindings(self, mappingtable):
        # mapping table is a string delivered from slim of the form
        # olduniqueID1=newuniqueID1 olduniqueID2=newuniqueID2
        remapped = {}
        for pair in mappingtable.split(' '):
            (oldid, newid) = pair.split('=')
            remapped[oldid] = newid

        # now we search & replace these id's wherever we encounter them
        # in the scene.
        notremapped = {}
        objlist = self.getPotentialAttachmentSites()
        count = 0
        for o in objlist:
            for slot in self.k_KnownSlots:
                (oo, addstrength, multi) = self.getBinding(o, slot)
                if not oo: continue
                attrRef = "%s.%s" % (oo, slot)
                if not maya.cmds.objExists(attrRef):
                    continue
                attrval = maya.cmds.getAttr(attrRef)
                if not attrval or not len(attrval):
                    continue
                if multi:
                    newval = []
                    for id in attrval.split(","):
                        try:
                            newid = remapped[id]
                            count += 1
                        except:
                            newid = id
                            notremapped[id] = True
                        newval.append(newid)
                    maya.cmds.setAttr(attrRef, ",".join(newval), typ="string")
                else:
                    oldid = attrval
                    try:
                        newid = remapped[oldid]
                        count += 1
                    except:
                        newid = oldid
                        notremapped[oldid] = True
                    maya.cmds.setAttr(attrRef, newid, type="string")
        rfm.Log(rfm.NOTICE, "%d Slim bindings remapped" % count)
        if len(notremapped):
            rfm.Log(rfm.WARNING, "These Slim bindings weren't found (%s)" % 
                                                            notremapped.keys())

    def GetAssociatedAppearances(self, objlist):
        """ Returns a list of opaque appearance IDs assocated with objlist.
        """
        found = {}
        applist = []
        if objlist and len(objlist):
            for o in objlist:
                for slot in self.k_KnownSlots:
                    (oo, addstrength, multi) = self.getBinding(o, slot)
                    if not oo: continue
                    attrRef = "%s.%s" % (oo, slot)
                    if not maya.cmds.objExists(attrRef):
                        continue
                    attrval = maya.cmds.getAttr(attrRef)
                    if not attrval or not len(attrval):
                        continue
                    for id in attrval.split(","):
                        if not id in found:
                            found[id] = True
                            applist.append(id)
        return applist

    def getMayaSlotAttr(self, appSlot):
        if not appSlot in self.k_KnownSlots:
            if appSlot in self.k_SlimAttrMap:
                appSlot = self.k_SlimAttrMap[appSlot]
            else:
                raise Exception("invalid shader slot %s" % appSlot)
        return appSlot

    def getPotentialAttachmentSites(self):
        """
        Returns the entire list of nodes in the scene whose type is 
        compatible with Slim binding.
        """
        olist = maya.cmds.ls(transforms=True, shapes=True, 
                            cameras=True, lights=True,
                            type='shadingEngine')
        return olist

    def getShapesFromObjlist(self, objlist):
        """
        Returns a list of shape and shadingEngine nodes implied by objlist.
        Intermediate transforms are converted to a list of all shapes
        and this list is culled according to whether the object is
        visible and renderable.  Better approximations of maya's binding 
        behavior can be achieved by binding shaders at maya's intermediate 
        transform nodes, but this can confuse users and workgroups.  If 
        precise maya binding semantics are required, it's always possible 
        to bind to shadingEngine nodes, but we leave this to the user.
        """
        result = []
        shapes = []
        for obj in objlist:
            objtypes = maya.cmds.nodeType(obj, inherited=True)
            if "shadingEngine" in objtypes:
                result.append(obj)
            elif "shape" in objtypes:
                shapes.append(obj)
            elif "transform" in objtypes:
                shapes.extend(maya.cmds.listRelatives(obj,
                                                    path=True,
                                                    allDescendents=True,
                                                    type="shape"))
        # now weed-out intermediate and non-renderable shapes
        for s in shapes:
            if maya.cmds.getAttr(s+".io"):
                # we're intermediate
                continue
            if None == maya.cmds.listSets(t=1, o=s):
                nodeTypeOutput =  maya.cmds.nodeType(s,inherited=True)
                if not "curveShape" in nodeTypeOutput and \
                    "geometryShape" in nodeTypeOutput:
                    # we're not a member of any renderable set (shading engine)
                    continue
                # else we might be a light or camera shape...
            result.append(s);
        result = list(set(result)) # eliminate duplicates
        return result

    def getBinding(self, obj, slot):
        """
        Returns a tuple (obj, addstrength, multi), where obj is None if the 
        provided obj isn't a valid binding for the slot.

        Currently we enforce the notion that lights shaders must be
        bound at light-shape nodes and that only a single light shader
        is bound there.
        """
        nodeTypes = maya.cmds.nodeType(obj, inherited=True)
        isShape = "shape" in nodeTypes
        shape = None
        if isShape:
            shape = obj
        elif "transform" in nodeTypes:
            # search immediate children for shapes, if so it's a special
            # transform, equated with a shape, conveying the shape's semantics
            shapes = maya.cmds.listRelatives(obj, path=True, shapes=True)
            if shapes:
                for shapeIter in shapes:
                    nodeTypes = maya.cmds.nodeType(shapeIter, inherited=True)
                    if nodeTypes == None:
                        continue
                    if 'shape' in nodeTypes:
                        shape = shapeIter
                        break
        elif "shadingEngine" in nodeTypes:
            # this is okay, but currently has no special treatment
            pass
        else:
            # not gonna assign here
            return (None, False, False)

        isLight = False
        isCamera = False
        if shape:
            if "light" in nodeTypes:
                isLight = True
            elif "camera" in nodeTypes:
                isCamera = True

        multi = self.IsMultiSlot(slot)
        if isLight:
            # only allow light and coshader bindings to lights
            if slot in [self.k_Light, self.k_Shader, self.k_AreaLight]:
                obj = shape
                if slot == self.k_Light:
                    multi = False
            else:
                obj = None
            addStrength = False
        elif isCamera:
            # only allow imager and coshader bindings to camera
            if slot in [self.k_Imager, self.k_PixelSampleImager, self.k_Shader]:
                obj = shape
            else:
                obj = None
            addStrength = False
        else:
            addStrength = not isShape
        return (obj, addStrength, multi)

    def isDefaultRenderLayer(self):
        """ Tests the current render layer to see if it is the default layer
        """
        renderlayer = maya.cmds.editRenderLayerGlobals(query=True, 
                                                       currentRenderLayer=True)
        return renderlayer == "defaultRenderLayer"
        
    def addLayerOverride(self, attrRef): 
        """ Add a render layer override for attribute
        """
        maya.cmds.editRenderLayerAdjustment(attrRef)

    def removeLayerOverride(self, attrRef):
        """ Removes overrides when attempting to unbind from and renderlayer
            override
        """
        maya.cmds.editRenderLayerAdjustment(attrRef,remove=True)

    def attributeHasLayerOverride(self, attrRef): 
        """ Checks to see if the attribute is in the layer overide list
        """
        layerAdjustments = maya.cmds.listConnections(attrRef)
        if layerAdjustments:
            currentRenderLayer = \
                    maya.cmds.editRenderLayerGlobals( query=True, currentRenderLayer=True )
            if currentRenderLayer in layerAdjustments:
                return True
        return False
        
