import time
import sys
import os
import re
import maya.cmds as cmds
import maya.mel as mel
cmds.loadPlugin('RenderMan_for_Maya')

#Get arguments
arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
pathToProxy = arguments[0]
pathToProxy = '\\' in pathToProxy and '/'.join(pathToProxy.split('\\')) or pathToProxy
pathToRib = arguments[1]

def openTargetFile(pathToScene, pathToRib):
    #startTime = 
    #endTime =
    #stepFrame = 
    cmds.file(pathToScene, force=True, open=True)
    nodes = cmds.ls('root', dag=True, long=True, type=['mesh', 'gpuCache', 'locator', 'RenderManArchive'])
    if nodes:
        if nodes:
            target = ''
            for i in range(0, len(nodes)):
                if cmds.attributeQuery('rman__torattr___invis', node=nodes[i], exists=True):
                    cmds.deleteAttr(nodes[i]+'.rman__torattr___invis')                    
                if cmds.attributeQuery('rman__param___draFile', node=nodes[i], exists=True):
                    cmds.deleteAttr(nodes[i]+'.rman__param___draFile')
                if cmds.attributeQuery('rman__torattr___preShapeScript', node=nodes[i], exists=True):
                    if cmds.getAttr(nodes[i]+'.rman__torattr___preShapeScript') == "rmanOutputDelayedReadArchives":
                        cmds.setAttr(nodes[i]+'.rman__torattr___preShapeScript', '', type='string')
                if cmds.attributeQuery('rman__param___draUseSequenceNumber', node=nodes[i], exists=True):
                    cmds.deleteAttr(nodes[i]+'.rman__param___draUseSequenceNumber')
                if cmds.nodeType(nodes[i]) == 'RenderManArchive':
                    target = nodes[i]
                else:
                    mel.eval('rmanAddAttr "'+nodes[i]+'" rman__torattr___invis ("");')
            if target != '':
                cmds.setAttr(target+'.filename', pathToRib, type="string")
                cmds.file(force=True, save=True)
            elif target == '':
                ribArchive = cmds.createNode('RenderManArchive', parent=cmds.ls(nodes[i], long=True)[0].split('|')[-2])
                cmds.setAttr(ribArchive+'.filename', pathToRib, type="string")
                cmds.file(force=True, save=True)
    return pathToRib

openTargetFile(pathToProxy, pathToRib)
print pathToRib
