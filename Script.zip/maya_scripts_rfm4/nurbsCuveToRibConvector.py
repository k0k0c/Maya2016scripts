def chekProject( numPoints ):
    import maya.cmds as cmds
    import maya.mel as mel
    import maya.OpenMaya as OpenMaya
    
    sel = OpenMaya.MSelectionList()
    OpenMaya.MGlobal.getActiveSelectionList(sel)
    print sel
    iter = OpenMaya.MItSelectionList(sel)
    dagNodeFn = OpenMaya.MFnDagNode()
    point = OpenMaya.MPoint()    
    f = open('C:/furData.txt', 'w')
    f.write("%-20d %d\n" % (0,numPoints))
    #a=[]
    numCurves=0
    while not iter.isDone():
        item = OpenMaya.MDagPath()
        component = OpenMaya.MObject()
        iter.getDagPath( item, component )
        shapeNumber=0
        print(item.fullPathName() + " <...> " + str(item.childCount()))
        dagIterator = OpenMaya.MItDag()
        dagIterator.reset(item, OpenMaya.MItDag.kDepthFirst, OpenMaya.MFn.kNurbsCurve)
        while not dagIterator.isDone():
            dagMObject = dagIterator.currentItem()
            dagNodeFn.setObject(dagMObject)
            name = dagNodeFn.name()
            print name + ' (' + dagMObject.apiTypeStr() + ')'
            if dagMObject.hasFn(OpenMaya.MFn.kNurbsCurve):
                numCurves=numCurves+1
                
                MFnc = OpenMaya.MFnNurbsCurve(dagMObject)
                startDomainVal = OpenMaya.MScriptUtil()
                startDomainVal.createFromDouble(0.0)
                startDomainPtr =  startDomainVal.asDoublePtr()
                endDomainVal = OpenMaya.MScriptUtil()
                endDomainVal.createFromDouble(0.0)
                endDomainPtr =  endDomainVal.asDoublePtr()
                MFnc.getKnotDomain(startDomainPtr, endDomainPtr)
                startDomain = OpenMaya.MScriptUtil.getDouble(startDomainPtr)
                endDomain = OpenMaya.MScriptUtil.getDouble(endDomainPtr)
                #print("Point domain: ",startDomain," and ",endDomain)
                
                pointParam = OpenMaya.MPoint()    
                stepDomain = endDomain/numPoints
                for i in range(0,numPoints+1):
                    MFnc.getPointAtParam(stepDomain*i,pointParam,OpenMaya.MSpace.kObject)
                    #print "Parametric param:",stepDomain*i,"x:",pointParam.x,"y:",pointParam.y,"z:",pointParam.z
                    f.write("%f %f %f " % (pointParam.x,pointParam.y,pointParam.z))
                    #b=[pointParam.x,pointParam.y,pointParam.z]
                    #a.append(b)
                f.write("\n")                    
                                    
                    
                #curverIterator = OpenMaya.MItCurveCV(dagMObject)
                #while not curverIterator.isDone():        
                    #point=curverIterator.position(OpenMaya.MSpace.kObject)
                    #print "x:",point.x,"y:",point.y,"z:",point.z
                    #curverIterator.next()
                
                                   
            dagIterator.next()    
            
        iter.next()
    f.seek(0)
    f.write("%-20d %d\n" % (numCurves,numPoints+1))
    #n=0
    #for _a in a:
    #    f.write("%f %f %f " % (_a[0],_a[1],_a[2]))
    #    n=n+1
    #    if n==numPoints+1:
    #        n=0
    #        f.write("\n")
    f.close()

chekProject(3)


#Procedural "DynamicLoad" ["C:/furDSO" "3.0" ] [-30 30 -30 30 -30 30]