import maya.cmds as cmds
import os
import re

def check( rfn ):
    """
    Check current reference.
    """
    pass

def proxyManager( rfn, force=False ):
    """
    Get proxy manager node from current reference.
    """
    pm = cmds.listConnections( rfn, type="proxyManager" )
    if pm:
        return pm[0]
    elif force is True:
        m_name = cmds.referenceQuery( rfn, filename=True ).split( "/" )[-1].split( "." )[0]
        pm = cmds.createNode( "proxyManager", name=m_name )
        cmds.connectAttr( "%s.activeProxy" % pm, "%s.proxyList[0]" % pm )
        cmds.connectAttr( "%s.proxyList[0]" % pm, "%s.proxyMsg" % rfn )
        cmds.connectAttr( "%s.proxyMsg" % rfn, "%s.sharedEditsOwner" % pm )
        return pm
    else:
        return None

def proxyList( rfn ):
    """
    List all used proxy for current reference. 
    """
    pm = proxyManager( rfn )
    if pm:
        m_connections = cmds.listConnections( "%s.proxyList" % pm, type="reference" )
        return m_connections
    else:
        return None

def getActive( rfn ):
    """
    Get active reference for current reference.
    """
    pm = proxyManager( rfn )
    m_list = cmds.listConnections( "%s.activeProxy" % pm, plugs=True )
    if m_list:
        m_list = cmds.listConnections( m_list, source=False, destination=True )
        if m_list:
            return m_list[0]
        else:
            return None
    else: 
        return None

def add( rfn, m_path ):
    """
    Add proxy to current reference.
    """
    #Get last unused proxy attribute for current reference.
    pm = proxyManager( rfn, force=True )
    pm_list = cmds.listAttr( "%s.proxyList" % pm, multi=True )
    print re.findall( "\[([0-9]+)\]", pm_list[-1] ),pm_list
    pm_proxy = "proxyList[%s]" % ( int( re.findall( "\[([0-9]+)\]", pm_list[-1] )[0] ) + 1 )
    #Get information about new reference.
    m_type = m_path.split( "." )[-1]
    m_type = m_type == "mb" and "mayaBinary" or m_type == "ma" and "mayaAscii"
    m_namespace = cmds.file( cmds.referenceQuery( rfn, filename=True ), query=True, namespace=True )
    #Load reference.
    m_reference = cmds.file( m_path, reference=True, mergeNamespacesOnClash=True, type=m_type, options="v=0;", namespace=m_namespace, loadReferenceDepth="none" )
    m_reference = cmds.referenceQuery( m_reference, rfn=True )
    #Attach loaded reference as proxy.
    cmds.connectAttr( "%s.%s" % ( pm, pm_proxy ), "%s.proxyMsg" % m_reference )
    return m_reference
    
def switch( rfn_src, rfn_dst ):
    """
    Switch current reference to another existing proxy.
    """
    pm = proxyManager( rfn_src )
    if pm:
        #Search target reference in proxy manager node.
        m_proxy = cmds.listConnections( "%s.proxyList" % pm, type="reference", connections=True, source=False, destination=True )
        for i in range( 0, len( m_proxy )):
            if m_proxy[i] == rfn_dst:
                #Setup proxy manager.
                cleanProxyManager( rfn_src )
                cmds.connectAttr( "%s.activeProxy" % pm, m_proxy[i-1] )
                cmds.file( loadReference=rfn_dst )
                return rfn_dst
    else:
        print "Proxy manager for %s is not exists" % rfn_src
        return None

def cleanProxyManager( rfn ):
    pm = proxyManager( rfn )
    if pm:
        m_proxy = cmds.listConnections( "%s.proxyList" % pm, type="reference", source=False, destination=True )
        if m_proxy:
            for i in range( 0, len( m_proxy )):
                cmds.file( unloadReference=m_proxy[i] )
        m_proxy = cmds.listConnections( "%s.activeProxy" % pm, plugs=True )
        if m_proxy:
            for i in range( 0, len( m_proxy )):
                cmds.disconnectAttr( "%s.activeProxy" % pm, m_proxy[i] )
        return True
    return False
            

def switchNext( rfn ):
    """
    Switch current reference to next existing proxy.
    """
    pm = proxyManager( rfn )
    if pm:
        rfn = getActive( rfn )
        m_proxy = cmds.listConnections( "%s.proxyList" % pm, type="reference", source=False, destination=True, connections=True )
        if m_proxy:
            for i in range( 0, len( m_proxy )):
                if m_proxy[i] == rfn:
                    cleanProxyManager( rfn )
                    print "\n", m_proxy[i]
                    print m_proxy[i-3]
                    cmds.connectAttr( "%s.activeProxy" % pm, m_proxy[i-3] )
                    cmds.file( loadReference=m_proxy[i-2] )
                    return m_proxy[i-3]
        else:
            return None
    else:
        return None
    
def combine( rfn_src, rfn_dst ):
    """
    Add to current reference another existing reference as proxy.
    """
    pass

def findProxy( rfn, expr, ignore=False ):
    """
    List all proxy finded by regular expression for current reference. 
    """
    m_result = []
    m_expr = re.compile( expr )
    m_proxy = proxyList( rfn )
    if m_proxy:
        for i in range( 0, len( m_proxy )):
            m_filename = cmds.referenceQuery( m_proxy[i], filename=True )
            if ignore is False and m_expr.findall( m_filename ) or ignore is True and not m_expr.findall( m_filename ):
                m_result.append( m_proxy[i] )
    return m_result
    
    