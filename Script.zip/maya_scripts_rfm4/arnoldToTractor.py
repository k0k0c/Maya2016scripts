import site
site.addsitedir(r'\\server-3d\Project\lib\soft\Python26\Lib\site-packages')

import re
from PyQt4 import QtCore
from PyQt4 import QtGui


import os
import commands
import shutil
import sys
import time
import sys
import maya.cmds as cmds
import maya.mel as mel
import socket
import select
import struct
import errno
import platform
import optparse
import datetime
import getpass
import ConfigParser

TrFileRevisionDate = "$DateTime: 2009/04/23 17:17:43 $"

class TrHttpRPC (object):

    def __init__(self, host, port=80, logger=None,
                apphdrs={}, urlprefix="/Tractor/", timeout=30.0):

        self.host = host
        self.port = port
        self.logger = logger
        self.appheaders = apphdrs
        self.urlprefix = urlprefix
        self.timeout = timeout

        if port <= 0:
            h,c,p = host.partition(':')
            if p:
                self.host = h
                self.port = int(p)

        # embrace and extend errno values
        if not hasattr(errno, "WSAECONNRESET"):
            errno.WSAECONNRESET = 10054
        if not hasattr(errno, "WSAECONNREFUSED"):
            errno.WSAECONNREFUSED = 10061


    def Transaction (self, tractorverb, formdata, parseCtxName=None,
                        xheaders={}, analyzer=None):
        """
        Make an HTTP request and retrieve the reply from the server.
        An implementation using a few high-level methods from the
        urllib2 module is also possible, however it is many times
        slower than this implementation, and pulls in modules that
        are not always available (e.g. when running in maya's python).
        """
        outdata = None
        errcode = 0
        s = None

        try:
            # like:  http://tractor-engine:80/Tractor/task?q=nextcmd&...
            # we use POST when making changes to the destination (REST)
            req = "POST " + self.urlprefix + tractorverb + " HTTP/1.0\r\n"
            for h in self.appheaders:
                req += h + ": " + self.appheaders[h] + "\r\n"
            for h in xheaders:
                req += h + ": " + xheaders[h] + "\r\n"

            t = ""
            if formdata:
                t = formdata.strip()
                if t and "Content-Type: " not in req:
                    req += "Content-Type: application/x-www-form-urlencoded\r\n"

            req += "Content-Length: %d\r\n" % len(t)
            req += "\r\n"  # end of http headers
            req += t

            # error checking?  why be a pessimist?
            # that's why we have exceptions!

            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect( (self.host, self.port) )
            s.sendall(req)

            mustTimeWait = False

            t = ""  # build up the reply text
            while 1:
                r,w,x = select.select([s], [], [], self.timeout)
                if r:
                    if 0 == len(r):
                        self.Debug("time-out waiting for http reply")
                        mustTimeWait = True
                        break
                    else:
                        r = s.recv(4096)
                if not r:
                    break
                else:
                    t += r

            # Attempt to reduce descriptors held in TIME_WAIT on the
            # engine by dismantling this request socket immediately
            # if we've received an answer.  Usually the close() call
            # returns immediately (no lingering close), but the socket
            # persists in TIME_WAIT in the background for some seconds.
            # Instead, we force it to dismantle early by turning ON
            # linger-on-close() but setting the timeout to zero seconds.
            #
            if not mustTimeWait:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER,
                                 struct.pack('ii', 1, 0))
            s.close()

            if t and len(t):
                n = t.find("\r\n\r\n")
                h = t[0:n] # headers

                n += 4
                outdata = t[n:].strip()  # body, or error msg, no CRLF

                n = h.find(' ') + 1
                e = h.find(' ', n)
                errcode = int( h[n:e] )

                if errcode == 200:
                    errcode = 0

                    # expecting a json dict?  parse it
                    if outdata and parseCtxName:
                        try:
                            outdata = self.parseJSON(outdata)

                        except Exception:
                            errcode = -1
                            self.Debug("json parse:\n" + outdata)
                            outdata = "parse %s: %s" % \
                                        (parseCtxName, self.Xmsg())

                if analyzer:
                    analyzer( h )

            else:
                outdata = "no data received"
                errcode = -1

        except Exception, e:
            if e[0] in (errno.ECONNREFUSED, errno.WSAECONNREFUSED):
                outdata = "connection refused"
                errcode = e[0]
            elif e[0] in (errno.ECONNRESET, errno.WSAECONNRESET):
                outdata = "connection dropped"
                errcode = e[0]
            else:
                errcode = -1
                outdata = "http transaction: " + self.Xmsg()

        return (errcode, outdata)


    def parseJSON(self, json):
        #
        # A simpleminded "converter" from inbound json to python dicts.
        #
        # Expect a JSON object, which of course also happens to be the
        # same format as a python dictionary:
        #  { "user": "yoda", "jid": 123, ..., "cmdline": "prman ..." }
        #
        # NOTE: python eval() will *fail* on strings ending in CRLF (\r\n),
        # they must be stripped!  (by our caller, if necessary)
        #
        # We add local variables to stand in for the three JSON
        # "native" types that aren't available in python, however
        # these types aren't expected to appear in tractor data.
        #
        null = None
        true = True
        false = False

        return eval( json )


    def Debug (self, txt):
        if self.logger:
            self.logger.debug(txt)

    def Xmsg (self):
        if self.logger and hasattr(self.logger, 'Xcpt'):
            return self.logger.Xcpt()
        else:
            errclass, excobj = sys.exc_info()[:2]
            return "%s - %s" % (errclass.__name__, str(excobj))

## ------------------------------------------------------------- ##

def trAbsPath (path):
    '''
    Generate a canonical path for tractor.  This is an absolute path
    with backslashes flipped forward.  Backslashes have been known to
    cause problems as they flow through system, especially in the 
    Safari javascript interpreter.
    '''
    return os.path.abspath( path ).replace('\\', '/')

## ------------------------------------------------------------- ##

def jobSpool (jobfile, options):
    '''
    Transfer the given job (alfred script) to the central job queue.
    '''

    if options.ribspool:
        alfdata = options.ribjobtxt
    else:
        # usual case, read the alfred jobfile
        f = open(jobfile, "rb")
        alfdata = f.read()
        f.close()

    hdrs = {
        'Content-Type':         'application/tractor-spool',
        'X-Tractor-User':       options.uname,
        'X-Tractor-Spoolhost':  options.hname,
        'X-Tractor-Dir':        options.jobcwd,
        'X-Tractor-Jobfile':    trAbsPath(jobfile),
        'X-Tractor-Priority':   str(options.priority)
    }

    return TrHttpRPC(options.mtdhost,0).Transaction("spool",alfdata,None,hdrs)

## ------------------------------------------------------------- ##

def jobDelete (options):
    '''
    Request that a job be deleted from the tractor queue
    '''
    sjid = str( options.jdel_id )

    q = "queue?q=jdelete&jid=" + sjid
    q += "&user=" + options.user
    q += "&hnm=" + options.hname

    rc, msg = TrHttpRPC(options.mtdhost,0).Transaction(q)

    if 0 == rc:
        print "J" + sjid + " delete OK"
    else:
        print msg

    return rc

## ------------------------------------------------------------ ##

##
## Spool function. This code is taken from 
## the Tractor blade's tractor-spool.py script, with a couple
## of the options removed (Ex: -rib).
##

def Spool (argv):
    '''
    tractor-spool - main - examine options, connect to engine, transfer job
    '''
    appName =        "tractor-spool"
    appVersion =     "TRACTOR_VERSION"
    appProductDate = "TRACTOR_BUILD_DATE"
    appDir = os.path.dirname(os.getenv("HOME"))
    
    defaultMtd  = "tractor-engine:80"

    spoolhost = socket.gethostname().split('.')[0] # options can override
    user = getpass.getuser()

    # ------ # 

    if not appProductDate[0].isdigit():
        appProductDate = " ".join(TrFileRevisionDate.split()[1:3])
        appVersion = "dev"

    appBuild = "%s %s (%s)" % (appName, appVersion, appProductDate)

    optparser = optparse.OptionParser(version=appBuild,
                                      usage="%prog [options] JOBFILE...\n"
                                        "%prog [options] --rib RIBFILE...\n"
                                        "%prog [options] --jdelete JOB_ID" )

    optparser.add_option("--priority", dest="priority",
            type="float", default=1.0,
            help="priority of the new job")

    optparser.add_option("--engine", dest="mtdhost",
            type="string", default=defaultMtd,
            help="hostname[:port] of the master tractor daemon, "
                 "default is '"+defaultMtd+"' - usually a DNS alias")

    optparser.add_option("--hname", dest="hname",
            type="string", default=spoolhost,
            help="the origin hostname for this job, used to find the "
                 "'home blade' that will run 'local' Cmds; default is "
                 "the locally-derived hostname")

    optparser.add_option("--user", dest="uname",
            type="string", default=user,
            help="alternate job owner, default is user spooling the job")

    optparser.add_option("--jobcwd", dest="jobcwd",
            type="string", default=trAbsPath(os.getcwd()),
            help="blades will attempt to chdir to the specified directory "
                 "when launching commands from this job; default is simply "
                 "the cwd at time when tractor-spool is run")

    optparser.add_option("--nrm", dest="ribspool",
            action="store_const", const="nrm",
            help="a variant of --rib, above, that causes the generated "
                 "tractor job to use netrender on the local blade rather "
                 "than direct rendering with prman on a blade; used when "
                 "the named RIBfile is not accessible from the remote "
                 "blades directly")

    optparser.add_option("--skey", dest="ribservice",
            type="string", default="pixarRender",
            help="used with --rib to change the service key used to "
                 "select matching blades, default: pixarRender")

    optparser.add_option("--jdelete", dest="jdel_id",
            type="string", default=None,
            help="delete the requested job from the queue")

    optparser.set_defaults(loglevel=1)
    optparser.add_option("-v",
            action="store_const", const=2, dest="loglevel",
            help="verbose status")
    optparser.add_option("-q",
            action="store_const", const=0, dest="loglevel",
            help="quiet, no status")

    optparser.add_option("--paused", dest="paused",
            action="store_true", default=False,
            help="submit job in paused mode")

    rc = 0
    xcpt = None

    try:
        options, jobfiles = optparser.parse_args( argv )

        if options.jdel_id:
            if len(jobfiles) > 0:
                optparser.error("too many arguments for jdelete")
                return 1
            else:
                return jobDelete(options)

        if 0 == len(jobfiles):
            optparser.error("no job script specified")
            return 1

        if options.loglevel > 1:
            print "%s\nCopyright (c) 2007-%d Pixar. All rights reserved." \
                    % (appBuild, datetime.datetime.now().year)

        if options.mtdhost != defaultMtd:
            h,n,p = options.mtdhost.partition(":")
            if not p:
                options.mtdhost = h + ':80'

        # paused starting is represented by a negative priority
        # decremented by one. This allows a zero priority to pause
        if options.paused:
            try:
                options.priority = str( -float( options.priority ) -1 )
            except Exception:
                options.priority = "-2"

        #
        # now spool new jobs
        #
        for filename in jobfiles:
            rc, xcpt = jobSpool(filename, options)
            if rc:
                break

    except KeyboardInterrupt:
        xcpt = "received keyboard interrupt"

    except SystemExit, e:
        rc = e

    except:
        errclass, excobj = sys.exc_info()[:2]
        xcpt = "job spool: %s - %s" % (errclass.__name__, str(excobj))
        rc = 1

    if xcpt:
        print >>sys.stderr,xcpt

    return rc


class TractorDialog(QtGui.QDialog):
    def __init__(self, parent=None):
        #QtGui.QDialog.__init__(self, parent)
        super(TractorDialog, self).__init__(parent)
        msgBox=QtGui.QMessageBox()
        msgBox.setWindowTitle("Hey!!!!")
        msgBox.setText("You save your scene?")
        msgBox.setStandardButtons(QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
        msgBox.setDefaultButton(QtGui.QMessageBox.Yes)
        ret = msgBox.exec_()
        if ret == QtGui.QMessageBox.Yes:
            self.setGeometry(500, 300, 250, 110)
            
            sceneNameFilePath=cmds.file(query=True,sn=True).split("/")
            if len(cmds.file(query=True,sn=True,shn=True).split("."))>1:
                sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[-2]
            elif cmds.file(query=True,sn=True,shn=True)!="":
                sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[0]
            else:
                sceneNameFileName="untitled"

            
            self.setWindowTitle("ArnoldToTractor - " + sceneNameFileName)
            
            self.oneLayout = QtGui.QGridLayout()
            
            self.PausedLabel = QtGui.QLabel("Start Paused: ")
            self.PausedCheckBox = QtGui.QCheckBox()
            self.oneLayout.addWidget(self.PausedLabel, 0, 0)
            self.oneLayout.addWidget(self.PausedCheckBox, 0, 1)
    
            self.ThreadsLabel = QtGui.QLabel("Threads: ")
            self.ThreadsLineEdit = QtGui.QLineEdit("0")
            self.oneLayout.addWidget(self.ThreadsLabel, 1, 0)
            self.oneLayout.addWidget(self.ThreadsLineEdit, 1, 1)
    
            self.JPLabel = QtGui.QLabel("Job Priority: ")
            self.JPLineEdit = QtGui.QLineEdit("1440")
            self.JPLineEdit.setInputMask("9999999")
            self.oneLayout.addWidget(self.JPLabel, 2, 0)
            self.oneLayout.addWidget(self.JPLineEdit, 2, 1)
    
            self.JP2Label = QtGui.QLabel("Job Server Attr: ")
            self.JP2LineEdit = QtGui.QLineEdit("LinuxFarm")
            self.oneLayout.addWidget(self.JP2Label, 3, 0)
            self.oneLayout.addWidget(self.JP2LineEdit, 3, 1)
    
            self.JP3Label = QtGui.QLabel("Environment Key: ")
            self.JP3LineEdit = QtGui.QLineEdit("arnold")
            self.oneLayout.addWidget(self.JP3Label, 4, 0)
            self.oneLayout.addWidget(self.JP3LineEdit, 4, 1)
    
            self.JP4Label = QtGui.QLabel("First Frame: ")
    
            self.JP4LineEdit = QtGui.QLineEdit("1")

            #frameStart=cmds.playbackOptions(query=True,animationStartTime=True)
            #frameEnd=cmds.playbackOptions(query=True,animationEndTime=True)
            frameStart=cmds.getAttr("defaultRenderGlobals.startFrame")
            frameEnd=cmds.getAttr("defaultRenderGlobals.endFrame")
            
            self.JP4LineEdit.setText(str(int(frameStart)))
            self.JP4LineEdit.setInputMask("9999999")
            self.oneLayout.addWidget(self.JP4Label, 5, 0)
            self.oneLayout.addWidget(self.JP4LineEdit, 5, 1)
    
            self.JP5Label = QtGui.QLabel("Last Frame: ")
            self.JP5LineEdit = QtGui.QLineEdit("100")
            self.JP5LineEdit.setText(str(int(frameEnd)))
            self.JP5LineEdit.setInputMask("9999999")
            self.oneLayout.addWidget(self.JP5Label, 6, 0)
            self.oneLayout.addWidget(self.JP5LineEdit, 6, 1)
    
            self.JP6Label = QtGui.QLabel("Frame Packet: ")
            self.JP6LineEdit = QtGui.QLineEdit("10")
            self.JP6LineEdit.setInputMask("9999999")
            self.oneLayout.addWidget(self.JP6Label, 7, 0)
            self.oneLayout.addWidget(self.JP6LineEdit, 7, 1)
    
            self.buttonLayout = QtGui.QHBoxLayout()
            self.startButton = QtGui.QPushButton('Start', self)
            self.startButton.clicked.connect(self.writeAlfredScript)
            self.cancelButton = QtGui.QPushButton('Cancel', self)
            self.cancelButton.clicked.connect(self.accept)
            self.buttonLayout.addWidget(self.startButton)
            self.buttonLayout.addWidget(self.cancelButton)
            self.oneLayout.addLayout(self.buttonLayout, 8, 1)
    
    
            '''
            button = QtGui.QPushButton('Change Font...', self)
            button.setFocusPolicy(QtCore.Qt.NoFocus)
            vbox.addWidget(button)
            self.connect(button, QtCore.SIGNAL('clicked()'), self.showDialog)
    
            self.label = QtGui.QLabel("This is some Sample Text", self)
            self.label.move(130, 20)
            hbox.addWidget(self.label, 1)
            '''
            self.setLayout(self.oneLayout)
            self.show()

    def writeAlfredScript(self):
        
        sceneNameFilePath=cmds.file(query=True,sn=True).split("/")
        if len(cmds.file(query=True,sn=True,shn=True).split("."))>1:
            sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[-2]
        elif cmds.file(query=True,sn=True,shn=True)!="":
            sceneNameFileName = cmds.file(query=True,sn=True,shn=True).split(".")[0]
        else:
            sceneNameFileName="untitled"
        indexSceneFolder=-2
        for sNFP in range (0, len(sceneNameFilePath)):
            m = re.search('^ep\d{2}sc\d{2}', sceneNameFilePath[sNFP],re.IGNORECASE)        
            if m is not None:
                indexSceneFolder=sNFP
                break
                
                
        timeScript = str(int(time.time()))        
        pathFolderForCache = "/".join(sceneNameFilePath[0:indexSceneFolder+1])+"/arnold/"+sceneNameFileName+"_"+timeScript

        if not os.path.exists(pathFolderForCache):
            os.makedirs(pathFolderForCache)

        fullPathASS = pathFolderForCache+"/ass"
        if not os.path.exists(fullPathASS):
            os.makedirs(fullPathASS)
        
        fullPathImage = pathFolderForCache+"/images"
        if not os.path.exists(fullPathImage):
            os.makedirs(fullPathImage)
        
        extFrame = mel.eval("getImfImageType()")            
        if extFrame == 'maya':
            extFrame='exr'
        print("extFrame: "+extFrame)
        
        fullPathASS = pathFolderForCache+"/ass"
        fullPathASSName=fullPathASS+"/"+sceneNameFileName+".ass"
        
        pathToFile = pathFolderForCache+'/TractorScript_'+timeScript+'.alf'
        currentTime = time.strftime('%a, %d %b %Y %H:%M:%S +0000', time.gmtime())

        entries = ""
        entriesImages = ""
        
        fullPathSplit=cmds.file(query=True,sn=True).split("/")
        fullPathSplitSplit=fullPathSplit[-1].split(".")
        fullPathSplitSplit[0]=fullPathSplitSplit[0]+"_"+timeScript
        fullPathSplitSplit = ".".join(fullPathSplitSplit)
        fullPathRez = pathFolderForCache+"/"+fullPathSplitSplit


        shutil.copyfile(cmds.file(query=True,sn=True),fullPathRez)

        cameras=cmds.ls(type="camera")
        cameraMain=''
        for cam in cameras:
            renderLi = cmds.getAttr(cam+".renderable")
            if renderLi == 1:
                cameraMain=cam
                break
        
        f = open(pathToFile, 'w')
        f.write('##AlfredToDo 3.0\n\n')
        f.write('##\n')
        f.write('## Generated: ' + str(currentTime) +'\n')
        f.write('## Arnold File: ' + fullPathRez + '\n')
        f.write('##\n\n')

        dirmaps='-dirmaps {\
            {{mayabatch} {maya} NFS}\
            {{//Server-3d/Project} {/Server-3d/Project} NFS}\
            {{/mnt/server-3d} {//Server-3d/Project} UNC}\
            {{P:} {//Server-3d/Project} UNC}\
            {{P:} {/Server-3d/Project} NFS}\
            {{//server-3d/Project} {/Server-3d/Project} NFS}\
            {{//server-3d/project} {/Server-3d/Project} NFS}\
            {{//SERVER-3D/Project} {/Server-3d/Project} NFS}\
            {{/server-3d/Project} {//Server-3d/Project} UNC}\
            {{/Server-3d/Project} {//Server-3d/Project} UNC}\
            {{/SERVER-3D/Project} {//Server-3d/Project} UNC}\
            {{//renderServer/Project} {/renderServer/Project} NFS}\
            {{R:} {//renderServer/Project} UNC}\
            {{R:} {/renderServer/Project} NFS}\
            {{//RenderServer/Project} {/renderServer/Project} NFS}\
            {{//renderServer/project} {/renderServer/Project} NFS}\
            {{//RENDERSERVER/Project} {/renderServer/Project} NFS}\
            {{//renderserver/Project} {/renderServer/Project} NFS}\
            {{/renderServer/Project} {//renderServer/Project} UNC}\
            {{/RenderServer/Project} {//renderServer/Project} UNC}\
            {{/RENDERSERVER/Project} {//renderServer/Project} UNC}\
            {{/renderserver/Project} {//renderServer/Project} UNC}\
        }'

        f.write('Job -title {'+fullPathRez.split("/")[-1]+'} -pbias 1.0 -tags { } -service {'+self.JP2LineEdit.text()+'} -crews {} '+dirmaps+' -envkey {'+self.JP3LineEdit.text()+'}')
        f.write(' -whendone {} -whenerror {}  -subtasks { \n\tTask -title {Job} -serialsubtasks 0 -subtasks {\n')

        start=int(self.JP4LineEdit.text())
        finish=int(self.JP5LineEdit.text())
        packet=int(self.JP6LineEdit.text())

        extensionPadding=cmds.getAttr("defaultRenderGlobals.extensionPadding")
        pathToShaders='C:/solidangle/mtoadeploy'
        if sys.platform != "win32":
            pathToShaders='/home/solidangle/mtoa'


        for i in range(start,(finish+packet),packet):
            vse=0
            if (i+packet)>finish: 
                startFrame=i
                endFrame=finish
                vse=1
            else: 
                startFrame=i
                endFrame=i+packet-1


            f.write('\t\tTask -title {Frames '+str(startFrame)+' - '+str(endFrame)+' }  -serialsubtasks 1 -subtasks {\n')

            f.write('\t\t\tTask -title {RibGen frames '+str(startFrame)+' - '+str(endFrame)+'} -cmds {\n')
            f.write('\t\t\t\tRemoteCmd {%D(mayabatch) -batch -proj \"'+pathFolderForCache+'\" -command arnoldExport(\"'+fullPathASSName+'\",'+str(startFrame)+','+str(endFrame)+',\"'+cameraMain+'\",\"'+pathFolderForCache+'/images'+'\") -file \"%D('+str(fullPathRez)+')\"} -service {'+self.JP2LineEdit.text()+'}\n')            
            f.write('\t\t\t}\n')

            f.write('\t\t\tTask -title {Render '+str(startFrame)+' - '+str(endFrame)+' }  -serialsubtasks 0 -subtasks {\n')

            for j in range(startFrame,endFrame+1):
                f.write('\t\t\t\tTask -title {Render frame '+str(j)+'} -cmds {\n')
                f.write('\t\t\t\t\tRemoteCmd {kick -l '+pathToShaders+'/2013/shaders -dw -dp -nokeypress -nstdin -o '+fullPathImage+"/"+sceneNameFileName+"."+str(j).zfill(extensionPadding)+"."+extFrame+' -i '+fullPathASSName.split(".")[0]+"."+str(j).zfill(extensionPadding)+"."+fullPathASSName.split(".")[1]+'} -service {'+self.JP2LineEdit.text()+'}\n')
                f.write('\t\t\t\t} -preview {prView \"'+fullPathImage+"/"+sceneNameFileName+"."+str(j).zfill(extensionPadding)+"."+extFrame+'\"}\n')

            f.write('\t\t\t}\n')    
            f.write('\t\t}\n')    
            
            if vse: break
      
        f.write('\t\t} -cleanup {\n')
        f.write('\t\t\t RemoteCmd {Alfred} -msg {File delete "%D('+pathToFile+')"} \n')
        f.write('\t\t\t RemoteCmd {Alfred} -msg {File delete "%D('+fullPathRez+')"} \n')
        f.write('\t\t}\n}\n')
        f.close()

        args = []
        args.append('--engine=192.168.254.250:80')
        if self.PausedCheckBox.checkState():
            args.append('--paused')
        args.append('--priority='+self.JPLineEdit.text())
        args.append(pathToFile)
        
        Spool(args)

        self.accept()




