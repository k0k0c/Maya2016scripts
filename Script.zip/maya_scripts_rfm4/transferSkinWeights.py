def transferSkinWeights(source='', target='', nurbsSamples=20, cleanUp=True):
    '''
    This procedure transfer weights from source mesh to target mesh
    source - source node with skinCluster in history
    target - target node
    nurbsSamples - nurbs influence samples
    EXAMPLE:
        transferSkinWeights(source='topotunBodyHead_geo', target='topotunBodyHead_geo1', nurbsSamples=20, cleanUp=True)
    '''
    import maya.cmds as cmds
    def removeUnusedInfluenceSkinClusters(skinClusterUsed=''):
        for i in range(0, len(skinClusterUsed)):
            influences = cmds.skinCluster(skinClusterUsed,query=True, inf=True)
            weightInfluences = cmds.skinCluster(skinClusterUsed, query=True, wi=True)
            nodeState = cmds.getAttr(skinClusterUsed+'.nodeState')
            cmds.setAttr((skinClusterUsed+'.nodeState'), 1)
            for j in range(0, len(influences)):
                if influences[j] not in weightInfluences:
                    cmds.skinCluster(skinClusterUsed, edit=True, ri=influences[j])
            cmds.setAttr((skinClusterUsed+'.nodeState'), nodeState)        
    def transfer(source, target, skinClustersSource, joints, influences, maxInfluences, nurbs, nurbsSamples):
        skinClusterNode = cmds.skinCluster(joints, target, influence=True, maximumInfluences=maxInfluences, dropoffRate=4, polySmoothness=0, nurbsSamples=nurbsSamples, lockWeights=False, weight=0)[0]
        for i in range(0, len(nurbs)):
            try:
                cmds.skinCluster(skinClusterNode, edit=True, useGeometry=True, addInfluence=nurbs[i])
            except:
                print 'Already attached: ', nurbs[i] 
        if cmds.getAttr(skinClustersSource+'.useComponents'):
            cmds.setAttr((skinClusterNode+'.useComponents'), 1)
        cmds.copySkinWeights(sourceSkin=skinClustersSource, destinationSkin=skinClusterNode, noMirror=True, surfaceAssociation='closestPoint', influenceAssociation='oneToOne')
        return skinClusterNode
    skinClustersSource = cmds.ls(cmds.listHistory(source, pdo=True), type='skinCluster')
    skinClustersTarget = cmds.ls(cmds.listHistory(target, pdo=True), type='skinCluster')
    if skinClustersTarget:
        cmds.delete(skinClustersTarget)
    if skinClustersSource:
        skinClustersSource = skinClustersSource[0]
        influences = cmds.skinCluster(skinClustersSource, query=True, weightedInfluence=True)
        joints = cmds.ls(influences, type='joint')
        nurbs = list(set(influences).difference(list(set(influences).difference(joints))))
        maxInfluences = cmds.skinCluster(skinClustersSource, q=True, mi=True)
        skinClusterNode = transfer(source, target, skinClustersSource, joints, influences, maxInfluences, nurbs, nurbsSamples)
        if cleanUp is True:
            removeUnusedInfluenceSkinClusters(skinClusterUsed=skinClusterNode)
    else:
        cmds.warning('Source node "'+str(source)+'" not contain skinCluster in history')