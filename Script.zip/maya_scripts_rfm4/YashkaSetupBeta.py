import site
import codecs
import glob
import re
import sys, os, shutil
import chekProject
import re
from PyQt4 import QtCore, QtGui
import socket
import MySQLdb as mb
import sip
import maya.cmds as cmds
import melnik_setup
import maya.mel as mel
import rfm.rlf2maya as rlf2maya
import rfm.passes
import maya.OpenMayaUI as mui
import sip
import math
import time
import rfm.tractor
import sendToRender

globaljobBatchContextLE=""

OSTYPE = sys.platform
if OSTYPE == "win32":
        OSTYPE="//Server-3d/Project"
else:
        OSTYPE="/Server-3d/Project"

sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm3')
sys.path.append(OSTYPE+'/lib/setup/maya/maya_scripts_rfm4')

#ddd=['1641', '1642', '1643', '1644', '1645', '1646', '1647', '1648', '1649', '1650', '1651', '1652', '1653', '1654', '1655', '1656', '1657', '1658', '1659', '1660', '1661', '1662', '1663', '1664', '1665', '1666', '1667', '1668', '1669', '1670', '1671', '1672', '1673', '1674', '1675', '1676', '1677', '1678', '1679', '1680', '1681', '1682', '1683', '1684', '1685', '1686', '1687', '1688', '1689', '1690', '1691', '1692', '1693', '1694', '1695', '1696', '1697', '1698', '1699', '1700', '1701', '1702', '1703', '1704', '1705', '1706', '1707', '1708', '1709', '1710', '1711', '1712', '1713', '1714', '1715', '1716', '1717', '1718', '1719', '1720', '1721', '1722', '1723', '1724', '1725', '1726', '1727', '1728', '1729', '1730', '1731', '1732', '1733', '1734', '1735', '1736', '1737', '1738', '1739', '1740', '1741', '1742', '1743', '1744', '1745', '1746', '1747', '1748', '1749', '1750', '1751', '1752', '1753', '1754', '1755', '1756', '1757', '1758', '1759', '1760', '1761', '1762', '1763', '1764', '1765', '1766', '1767', '1768', '1769', '1770', '1771', '1772', '1773', '1774', '1775', '1776', '1777', '1778', '1779', '1780', '1781', '1782', '1783', '1784', '1785', '1786', '1787', '1788', '1789', '1790', '1791', '1792', '1793', '1794', '1795', '1796', '1797', '1798', '1799', '1800', '1801', '1802', '1803', '1804', '1805', '1806', '1807', '1808', '1809', '1810', '1811', '1812', '1813', '1814', '1815', '1816', '1817', '1818', '1819', '1820', '1821', '1822', '1823', '1824', '1825', '1826', '1827', '1828', '1829']
#collectFrames(ddd)

def collectFrames(listFrames):
    #print str(listFrames)
    rez="["
    lastNum=-1
    currentNumber=-1
    for ch in range(len(listFrames)):
        if listFrames[ch].isdigit(): currentNumber=int(listFrames[ch])
        elif listFrames[ch] == "":
            return ""
        else:
            return "." + listFrames[ch]
        #print "currentNumber: "+str(currentNumber)+" lastNum: "+str(lastNum)+" rez[-1] "+rez[-1]
        if rez[-1] == "[":
            rez = rez + str(currentNumber)
        elif rez[-1] == "]":
            rez=rez + "[" + str(currentNumber)
        else:
            if currentNumber-lastNum==1:
                if len(listFrames)>ch+1:
                    if rez[-1]==".":
                        pass
                    elif int(listFrames[ch+1]) - currentNumber != 1:
                        rez=rez+","+str(currentNumber)     
                    else:
                        rez=rez+".."
                else:
                    if rez[-1]==".":
                        rez=rez+str(currentNumber)
                    else:
                        rez=rez+","+str(currentNumber)
            else:
                if  rez[-1]==".":
                    rez=rez+str(lastNum)+"]["+str(currentNumber)
                else:
                    rez=rez+"]["+str(currentNumber)
                #rez=rez+str(lastNum)+"]["+str(currentNumber)
        lastNum=currentNumber
    
    return rez+"]"


def getMayaWindow():
    ptr = mui.MQtUtil.mainWindow()
    return sip.wrapinstance(long(ptr), QtCore.QObject)


class Window(QtGui.QDialog):
    def __init__(self, parent=getMayaWindow()):
        super(Window, self).__init__(parent)
        if not cmds.pluginInfo("RenderMan_for_Maya",query=True,l=True):
            cmds.loadPlugin("RenderMan_for_Maya")

        if mel.eval("currentRenderer") != "renderMan":
            mel.eval("setCurrentRenderer renderMan")     

        if not cmds.objExists("rmanFinalGlobals"):
            mel.eval("rmanCreateGlobals()")
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setSpacing(0)
        self.mainLayout.setContentsMargins(3,3,3,3)
        self.tabWidget = QtGui.QTabWidget()
        self.tabWidget.setStyleSheet("QTabWidget{background: rgb(68,68,68);}")
        self.lGW=lightGroupsWidget()
        self.tabWidget.addTab(self.lGW, "Light groups")
        self.wLB=WindowListBatch()
        self.tabWidget.addTab(self.wLB, "Batch file processing")
        self.wBR=WindowBatchRender()
        self.tabWidget.addTab(self.wBR, "Batch Render")
        self.mainLayout.addWidget(self.tabWidget)        
        self.wFC=WindowFurCache()
        self.tabWidget.addTab(self.wFC, "RenderMan Cache")
        self.wRS=WindowRenderSetup()
        self.tabWidget.addTab(self.wRS, "Render Setup")
        
        self.wBR.ContextChanged.connect(self.wFC.contextChangedSlot)        
        
        self.setLayout(self.mainLayout)
        self.readSettings()
        self.setWindowTitle('Yashka')

    def readSettings(self):
        print "Yashka readSettings"
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("YashkaDialog")        
        pos = settings.value("posMayaApp", QtCore.QPoint(200, 200)).toPoint()
        self.move(pos)        
        size = settings.value("sizeMayaApp", QtCore.QSize(400, 400)).toSize()
        self.resize(size)
        pos = settings.value("tabWidget", "0").toInt()
        self.tabWidget.setCurrentIndex(pos[0])
        settings.endGroup()
    
    def writeSettings(self):
        print "Yashka writeSettings"
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("YashkaDialog")
        settings.setValue("posMayaApp", self.pos())
        settings.setValue("sizeMayaApp", self.size())
        settings.setValue("tabWidget", self.tabWidget.currentIndex())
        settings.setValue("globaljobBatchContextLE", globaljobBatchContextLE)        
        
        settings.endGroup()              

    def closeEvent(self, event):
        self.writeSettings()
        self.wLB.writeSettings()
        self.wBR.writeSettings()
        self.wFC.writeSettings()        
        self.wRS.writeSettings()        
        event.accept()



class WindowRenderSetup(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowRenderSetup, self).__init__(parent)
        self.mainLayout = QtGui.QGridLayout()
        self.mainLayout.setContentsMargins(2,2,2,2)        


        self.setAllMeshToLamberParamLabel = QtGui.QLabel("set all mesh to Lambert")
        self.setAllMeshToLamberParam = QtGui.QCheckBox()
        self.deletaUnknownNodesParamLabel = QtGui.QLabel("delete unknown nodes")
        self.deletaUnknownNodesParam = QtGui.QCheckBox()
        self.deleteColotSetsParamLabel = QtGui.QLabel("delete color sets")
        self.deleteColotSetsParam = QtGui.QCheckBox()
        self.defaultPRmanNodesCheckParamLabel = QtGui.QLabel("check plugin load")
        self.defaultPRmanNodesCheckParam = QtGui.QCheckBox()
        self.imageSequenceParamLabel = QtGui.QLabel("hide image sequence")
        self.imageSequenceParam = QtGui.QCheckBox()
        self.startEndSequenceParamLabel = QtGui.QLabel("set start end animation")
        self.startEndSequenceParam = QtGui.QCheckBox()
        self.imageSizeParamLabel = QtGui.QLabel("set image width height")
        self.imageSizeParam = QtGui.QCheckBox()
        self.commonRenderParamLabel = QtGui.QLabel("common render parametrs")
        self.commonRenderParam = QtGui.QCheckBox()
        self.motionBlurParamLabel = QtGui.QLabel("set motion blur")
        self.motionBlurParam = QtGui.QCheckBox()
        self.setFinalPassParamLabel = QtGui.QLabel("set final pass parametrs")
        self.setFinalPassParam = QtGui.QCheckBox()
        self.setCustomDisplayParamLabel = QtGui.QLabel("create custom display")
        self.setCustomDisplayParam = QtGui.QCheckBox()
        self.setCustomLightGroupsLabel = QtGui.QLabel("check light groups")
        self.setCustomLightGroupsParam = QtGui.QCheckBox()
        self.setShadowSSParamLabel = QtGui.QLabel("set shadow and ss default pass")
        self.setShadowSSParam = QtGui.QCheckBox()
        self.setupShaveParamLabel = QtGui.QLabel("setup shave")
        self.setupShaveParam = QtGui.QCheckBox()
        self.creataLightGroupParamLabel = QtGui.QLabel("create light groups")
        self.creataLightGroupParam = QtGui.QCheckBox()
        self.chekTexureDataParamLabel = QtGui.QLabel("check texture data")
        self.chekTexureDataParam = QtGui.QCheckBox()
        self.chekArchiveDataParamLabel = QtGui.QLabel("check archive data")
        self.chekArchiveDataParam = QtGui.QCheckBox()
        self.repareLightListParamLabel = QtGui.QLabel("repare light list links")
        self.repareLightListParam = QtGui.QCheckBox()
        self.slimMasksParamLabel = QtGui.QLabel("create mask pass")
        self.slimMasksParam = QtGui.QCheckBox()
        self.hideImagePlaneParamLabel = QtGui.QLabel("hide image plane")
        self.hideImagePlaneParam = QtGui.QCheckBox()
        self.autoCreateStereoPassesParamLabel = QtGui.QLabel("auto dublicate stereo passes")
        self.autoCreateStereoPassesParam = QtGui.QCheckBox()
        self.motionFactorParamLabel = QtGui.QLabel("set motion factor on pers")
        self.motionFactorParam = QtGui.QCheckBox()
        self.setupButton=QtGui.QPushButton("Render Setup")
        self.setupButton.released.connect(self.setupButtonSlot)


        self.mainLayout.addWidget(self.setAllMeshToLamberParamLabel,0,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setAllMeshToLamberParam,0,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.deletaUnknownNodesParamLabel,1,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.deletaUnknownNodesParam,1,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.deleteColotSetsParamLabel,2,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.deleteColotSetsParam,2,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.defaultPRmanNodesCheckParamLabel,3,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.defaultPRmanNodesCheckParam,3,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.imageSequenceParamLabel,4,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.imageSequenceParam,4,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.startEndSequenceParamLabel,5,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.startEndSequenceParam,5,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.imageSizeParamLabel,6,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.imageSizeParam,6,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.commonRenderParamLabel,7,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.commonRenderParam,7,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.motionBlurParamLabel,8,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.motionBlurParam,8,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setFinalPassParamLabel,9,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setFinalPassParam,9,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setCustomDisplayParamLabel,10,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setCustomDisplayParam,10,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setCustomLightGroupsLabel,11,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setCustomLightGroupsParam,11,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setShadowSSParamLabel,12,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setShadowSSParam,12,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setupShaveParamLabel,13,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setupShaveParam,13,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.creataLightGroupParamLabel,14,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.creataLightGroupParam,14,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.chekTexureDataParamLabel,15,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.chekTexureDataParam,15,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.chekArchiveDataParamLabel,16,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.chekArchiveDataParam,16,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.repareLightListParamLabel,17,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.repareLightListParam,17,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.slimMasksParamLabel,18,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.slimMasksParam,18,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.hideImagePlaneParamLabel,19,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.hideImagePlaneParam,19,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.autoCreateStereoPassesParamLabel,20,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.autoCreateStereoPassesParam,20,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.motionFactorParamLabel,21,0,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.motionFactorParam,21,1,QtCore.Qt.AlignHCenter)
        self.mainLayout.addWidget(self.setupButton,22,0,1,2)
        self.mainLayout.setRowStretch(23,1) 

        #self.mainLayout.insertStretch(100)
        self.readSettings()
        self.setLayout(self.mainLayout)

    def setupButtonSlot(self):
        import renderSetup
        reload(renderSetup)
        renderSetup.setup(self.setAllMeshToLamberParam.isChecked(), self.deletaUnknownNodesParam.isChecked(), self.deleteColotSetsParam.isChecked(), self.defaultPRmanNodesCheckParam.isChecked(), self.imageSequenceParam.isChecked(), self.startEndSequenceParam.isChecked(), self.imageSizeParam.isChecked(), self.commonRenderParam.isChecked(), self.motionBlurParam.isChecked(), self.setFinalPassParam.isChecked(), self.setCustomDisplayParam.isChecked(), self.setCustomLightGroupsParam.isChecked(), self.setShadowSSParam.isChecked(), self.setupShaveParam.isChecked(), self.creataLightGroupParam.isChecked(), self.chekTexureDataParam.isChecked(), self.chekArchiveDataParam.isChecked(), self.repareLightListParam.isChecked(), self.slimMasksParam.isChecked(), self.hideImagePlaneParam.isChecked(), self.autoCreateStereoPassesParam.isChecked(), self.motionFactorParam.isChecked())



    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("RenderSetup")        

        chekStat = settings.value("setAllMeshToLamberParam", "1").toInt()
        if chekStat[0] == 0: self.setAllMeshToLamberParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setAllMeshToLamberParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("deletaUnknownNodesParam", "1").toInt()
        if chekStat[0] == 0: self.deletaUnknownNodesParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.deletaUnknownNodesParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("deleteColotSetsParam", "1").toInt()
        if chekStat[0] == 0: self.deleteColotSetsParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.deleteColotSetsParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("defaultPRmanNodesCheckParam", "1").toInt()
        if chekStat[0] == 0: self.defaultPRmanNodesCheckParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.defaultPRmanNodesCheckParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("imageSequenceParam", "1").toInt()
        if chekStat[0] == 0: self.imageSequenceParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.imageSequenceParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("startEndSequenceParam", "1").toInt()
        if chekStat[0] == 0: self.startEndSequenceParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.startEndSequenceParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("imageSizeParam", "1").toInt()
        if chekStat[0] == 0: self.imageSizeParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.imageSizeParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("commonRenderParam", "1").toInt()
        if chekStat[0] == 0: self.commonRenderParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.commonRenderParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("motionBlurParam", "1").toInt()
        if chekStat[0] == 0: self.motionBlurParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.motionBlurParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("setFinalPassParam", "1").toInt()
        if chekStat[0] == 0: self.setFinalPassParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setFinalPassParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("setCustomDisplayParam", "1").toInt()
        if chekStat[0] == 0: self.setCustomDisplayParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setCustomDisplayParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("setCustomLightGroupsParam", "1").toInt()
        if chekStat[0] == 0: self.setCustomLightGroupsParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setCustomLightGroupsParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("setShadowSSParam", "1").toInt()
        if chekStat[0] == 0: self.setShadowSSParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setShadowSSParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("setupShaveParam", "1").toInt()
        if chekStat[0] == 0: self.setupShaveParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.setupShaveParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("creataLightGroupParam", "1").toInt()
        if chekStat[0] == 0: self.creataLightGroupParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.creataLightGroupParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("chekTexureDataParam", "1").toInt()
        if chekStat[0] == 0: self.chekTexureDataParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.chekTexureDataParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("chekArchiveDataParam", "1").toInt()
        if chekStat[0] == 0: self.chekArchiveDataParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.chekArchiveDataParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("repareLightListParam", "1").toInt()
        if chekStat[0] == 0: self.repareLightListParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.repareLightListParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("slimMasksParam", "1").toInt()
        if chekStat[0] == 0: self.slimMasksParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.slimMasksParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("hideImagePlaneParam", "1").toInt()
        if chekStat[0] == 0: self.hideImagePlaneParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.hideImagePlaneParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("autoCreateStereoPassesParam", "1").toInt()
        if chekStat[0] == 0: self.autoCreateStereoPassesParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.autoCreateStereoPassesParam.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("motionFactorParam", "1").toInt()
        if chekStat[0] == 0: self.motionFactorParam.setCheckState(QtCore.Qt.Unchecked)
        else: self.motionFactorParam.setCheckState(QtCore.Qt.Checked)


        settings.endGroup()
    
    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("RenderSetup")



        chekStat = 0
        if self.motionFactorParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("motionFactorParam", chekStat)        
        chekStat = 0
        if self.autoCreateStereoPassesParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("autoCreateStereoPassesParam", chekStat)        
        chekStat = 0
        if self.hideImagePlaneParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("hideImagePlaneParam", chekStat)        
        chekStat = 0
        if self.slimMasksParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("slimMasksParam", chekStat)        
        chekStat = 0
        if self.repareLightListParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("repareLightListParam", chekStat)        
        chekStat = 0
        if self.chekArchiveDataParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("chekArchiveDataParam", chekStat)        
        chekStat = 0
        if self.chekTexureDataParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("chekTexureDataParam", chekStat)        
        chekStat = 0
        if self.creataLightGroupParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("creataLightGroupParam", chekStat)        
        chekStat = 0
        if self.setupShaveParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setupShaveParam", chekStat)        
        chekStat = 0
        if self.setShadowSSParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setShadowSSParam", chekStat)        
        chekStat = 0
        if self.setCustomDisplayParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setCustomDisplayParam", chekStat)        
        chekStat = 0
        if self.setCustomLightGroupsParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setCustomLightGroupsParam", chekStat)        
        chekStat = 0
        if self.setFinalPassParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setFinalPassParam", chekStat)        
        chekStat = 0
        if self.motionBlurParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("motionBlurParam", chekStat)        
        chekStat = 0
        if self.commonRenderParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("commonRenderParam", chekStat)        
        chekStat = 0
        if self.imageSizeParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("imageSizeParam", chekStat)        
        chekStat = 0
        if self.startEndSequenceParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("startEndSequenceParam", chekStat)        
        chekStat = 0
        if self.imageSequenceParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("imageSequenceParam", chekStat)        
        chekStat = 0
        if self.defaultPRmanNodesCheckParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("defaultPRmanNodesCheckParam", chekStat)        
        chekStat = 0
        if self.deleteColotSetsParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("deleteColotSetsParam", chekStat)        
        chekStat = 0
        if self.deletaUnknownNodesParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("deletaUnknownNodesParam", chekStat)        
        chekStat = 0
        if self.setAllMeshToLamberParam.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("setAllMeshToLamberParam", chekStat)        
        

        settings.endGroup()


class WindowFurCache(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowFurCache, self).__init__(parent)
        self.mainLayout = QtGui.QVBoxLayout()
        self.mainLayout.setContentsMargins(2,2,2,2)        

        self.mainConvertLayout = QtGui.QVBoxLayout()
        self.mainConvertLayout.setContentsMargins(2,2,2,2)          
        self.mainLayout.addLayout(self.mainConvertLayout)
        

        self.mainSettingsConvert = QtGui.QGroupBox(" Common settings ")
        self.mainSettingsConvertLayout = QtGui.QVBoxLayout()
        self.mainSettingsConvertLayout.setContentsMargins(3,3,3,3)        


        self.FuurConvertLayout = QtGui.QHBoxLayout()
        self.FuurConvertLayout.setContentsMargins(2,2,2,2)        
        self.readFromCache = QtGui.QCheckBox("Fur read from cache")
        self.readFromCache.setCheckState(QtCore.Qt.Checked)                
        self.cacheIfNotExists = QtGui.QCheckBox("Fur cache if not exists")
        self.cacheIfNotExists.setCheckState(QtCore.Qt.Checked)                
        self.FuurConvertLayout.addWidget(self.readFromCache)
        self.FuurConvertLayout.addWidget(self.cacheIfNotExists)


        self.FolderConvertLayout = QtGui.QHBoxLayout()
        self.FolderConvertLayout2 = QtGui.QHBoxLayout()
        self.FolderConvertLayout.setContentsMargins(2,2,2,2)        
        self.FolderConvertLayout2.setContentsMargins(2,2,2,2)        
        self.FolderLabel=QtGui.QLabel("Source: ")
        self.FramesLabel=QtGui.QLabel("Frames: ")
        self.framesLE=QtGui.QLineEdit()
        self.rx=QtCore.QRegExp("[0-9\-\,]*");
        self.regExpValidator=QtGui.QRegExpValidator(self.rx,self)
        self.framesLE.setValidator(self.regExpValidator)
                 
        self.framesSaveBuffer=[]
        self.framesLE.textChanged.connect(self.framesChangedSlot)
        
        
        self.TargetLabel=QtGui.QLabel("Target: ")
        self.copyButton=QtGui.QPushButton("Copy")
        self.copyButton.released.connect(self.copyButtonSlot)
        self.LabelOverwrite=QtGui.QLabel("Replace: ")        
        self.overwriteCB=QtGui.QCheckBox()        
                

        self.mainSettingsConvertLayout.addLayout(self.FuurConvertLayout)
        self.mainSettingsConvertLayout.addLayout(self.FolderConvertLayout)
        self.mainSettingsConvertLayout.addLayout(self.FolderConvertLayout2)
        self.mainSettingsConvert.setLayout(self.mainSettingsConvertLayout)
        self.mainConvertLayout.addWidget(self.mainSettingsConvert)    




        self.sceneNodeConvert = QtGui.QGroupBox(" Cache selected scene node ")        
        self.sceneNodeConvertLayout = QtGui.QVBoxLayout()       
        self.sceneNodeConvertLayout.setContentsMargins(5,5,5,5)        
                
        self.treeView = QtGui.QTreeView()
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setIndentation(0)        
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)

        self.cacheSetPreset=QtGui.QPushButton("set Preset")
        self.cacheSetPreset.released.connect(self.setPreset)
        
        self.sceneNodeConvertLayout.addWidget(self.treeView)
        self.sceneNodeConvertLayout.addWidget(self.cacheSetPreset)                
        self.sceneNodeConvert.setLayout(self.sceneNodeConvertLayout)
        

        self.fileCacheConvert = QtGui.QGroupBox(" Rib folder  ")
        self.fileCacheConvertLayout = QtGui.QVBoxLayout()       
        self.fileCacheConvertLayout.setContentsMargins(5,5,5,5)        

        
        self.listView = QtGui.QTreeView()
        self.listView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = listDelegate()
        self.listView.setItemDelegate(self.delegate)
        self.listView.setIndentation(0)
        self.listView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.listView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.listView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.listModel = QtGui.QStandardItemModel()
        self.listView.setModel(self.listModel)
        self.listView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.listView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.listView.setHeaderHidden(True)
        self.listView.setMinimumWidth(300)

        self.listViewButtonLayout = QtGui.QHBoxLayout()
        self.refreshButton=QtGui.QPushButton("Refresh List")
        self.refreshButton.released.connect(self.loadFilesData)
        self.deleteSelectedButton=QtGui.QPushButton("Delete selected")
        self.deleteSelectedButton.released.connect(self.deleteSelectedSlot)
        self.deleteAllButton=QtGui.QPushButton("Delete All")
        self.deleteAllButton.released.connect(self.deleteAllSlot)        
        
        self.listViewButtonLayout.addWidget(self.refreshButton)
        self.listViewButtonLayout.addWidget(self.deleteSelectedButton)        
        self.listViewButtonLayout.addWidget(self.deleteAllButton)                
        
        self.fileCacheConvertLayout.addWidget(self.listView)
        self.fileCacheConvertLayout.addLayout(self.listViewButtonLayout)        
        self.fileCacheConvert.setLayout(self.fileCacheConvertLayout)


        self.mainConvertLayout.addWidget(self.fileCacheConvert)                    

                
        self.shadowsCacheConvert = QtGui.QGroupBox(" Data folder  ")                
        self.shadowsCacheConvertLayout = QtGui.QVBoxLayout()       
        self.shadowsCacheConvertLayout.setContentsMargins(5,5,5,5)        

        
        self.shadowsView = QtGui.QTreeView()
        self.shadowsView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.shadowsView.setItemDelegate(self.delegate)
        self.shadowsView.setIndentation(0)
        self.shadowsView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.shadowsView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.shadowsView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.shadowsModel = QtGui.QStandardItemModel()
        self.shadowsView.setModel(self.shadowsModel)
        self.shadowsView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.shadowsView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.shadowsView.setHeaderHidden(True)
        self.shadowsView.setMinimumWidth(300)

        self.shadowsViewButtonLayout = QtGui.QHBoxLayout()
        self.shadowsButton=QtGui.QPushButton("Refresh List")
        self.shadowsButton.released.connect(self.shadowsFilesData)
        self.shadowsSelectedButton=QtGui.QPushButton("Delete selected")
        self.shadowsSelectedButton.released.connect(self.shadowsSelectedSlot)
        self.shadowsAllButton=QtGui.QPushButton("Delete All")
        self.shadowsAllButton.released.connect(self.shadowsAllSlot)        
        
        self.shadowsViewButtonLayout.addWidget(self.shadowsButton)
        self.shadowsViewButtonLayout.addWidget(self.shadowsSelectedButton)        
        self.shadowsViewButtonLayout.addWidget(self.shadowsAllButton)                
        
        self.shadowsCacheConvertLayout.addWidget(self.shadowsView)
        self.shadowsCacheConvertLayout.addLayout(self.shadowsViewButtonLayout)        
        self.shadowsCacheConvert.setLayout(self.shadowsCacheConvertLayout)


        self.mainConvertLayout.addWidget(self.shadowsCacheConvert)                    


        self.ptcCacheConvert = QtGui.QGroupBox(" Shader folder  ")                
        self.ptcCacheConvertLayout = QtGui.QVBoxLayout()       
        self.ptcCacheConvertLayout.setContentsMargins(5,5,5,5)        

        
        self.ptcView = QtGui.QTreeView()
        self.ptcView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.ptcView.setItemDelegate(self.delegate)
        self.ptcView.setIndentation(0)
        self.ptcView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.ptcView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.ptcView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.ptcModel = QtGui.QStandardItemModel()
        self.ptcView.setModel(self.ptcModel)
        self.ptcView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.ptcView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.ptcView.setHeaderHidden(True)
        self.ptcView.setMinimumWidth(300)

        self.ptcViewButtonLayout = QtGui.QHBoxLayout()
        self.ptcButton=QtGui.QPushButton("Refresh List")
        self.ptcButton.released.connect(self.ptcFilesData)
        self.ptcSelectedButton=QtGui.QPushButton("Delete selected")
        self.ptcSelectedButton.released.connect(self.ptcSelectedSlot)
        self.ptcAllButton=QtGui.QPushButton("Delete All")
        self.ptcAllButton.released.connect(self.ptcAllSlot)        
        
        self.ptcViewButtonLayout.addWidget(self.ptcButton)
        self.ptcViewButtonLayout.addWidget(self.ptcSelectedButton)        
        self.ptcViewButtonLayout.addWidget(self.ptcAllButton)                
        
        self.ptcCacheConvertLayout.addWidget(self.ptcView)
        self.ptcCacheConvertLayout.addLayout(self.ptcViewButtonLayout)        
        self.ptcCacheConvert.setLayout(self.ptcCacheConvertLayout)

        self.mainConvertLayout.addWidget(self.ptcCacheConvert)                    

        
        self.mainLayout.insertStretch(100)
        
        self.readSettings()
        self.readFromCache.stateChanged.connect(self.readFromCacheSlot)        
        self.cacheIfNotExists.stateChanged.connect(self.cacheIfNotExistsSlot)        
        
        self.setLayout(self.mainLayout)
        self.shadowsButton.released.connect(self.shadowsFilesData)
        self.shadowsSelectedButton=QtGui.QPushButton("Delete selected")
        self.shadowsSelectedButton.released.connect(self.shadowsSelectedSlot)
        self.shadowsAllButton=QtGui.QPushButton("Delete All")
        self.shadowsAllButton.released.connect(self.shadowsAllSlot)        
        

        self.FolderCombobox = QtGui.QComboBox()
        self.TargetCombobox = QtGui.QComboBox()

                
        self.FolderCombobox.currentIndexChanged.connect(self.delayedLoad)        
        self.FolderQlistNames = QtCore.QStringList()
        projctDir=mel.eval("rman workspace GetProjDir")
        paths=glob.glob(projctDir+'renderman/*')        
        for path in paths:
            if os.path.isdir(path):
                self.FolderQlistNames.append(path.replace("\\","/").split("/")[-1])
        self.FolderCombobox.addItems(self.FolderQlistNames)
        self.TargetCombobox.addItems(self.FolderQlistNames)


        
        self.FolderConvertLayout.addWidget(self.FolderLabel)
        self.FolderConvertLayout.addWidget(self.FolderCombobox)        
        self.FolderConvertLayout.addWidget(self.FramesLabel)
        self.FolderConvertLayout.addWidget(self.framesLE)        
                
        self.FolderConvertLayout.insertStretch(100)        
        self.FolderConvertLayout2.addWidget(self.TargetLabel)
        self.FolderConvertLayout2.addWidget(self.TargetCombobox)
        self.FolderConvertLayout2.insertStretch(100)         
        self.FolderConvertLayout2.addWidget(self.LabelOverwrite)
        self.FolderConvertLayout2.addWidget(self.overwriteCB)        
        self.FolderConvertLayout2.addWidget(self.copyButton)
   
    def framesChangedSlot(self):
        self.framesSaveBuffer=[]
        framesList=[]
        framesss=self.framesLE.text()
        listcommas=str(framesss).split(",")
        print("listcommas: "+str(listcommas))   
        for fX in range(0,len(listcommas)):
            listminusss=listcommas[fX].split("-")
            if type(listminusss)==type([]) and len(listminusss)==2:
                if len(listminusss[0])== 0 or len(listminusss[1])==0:
                    cmds.error("ne pravilno vvedeny diapazony!!!\n"+framesss)
                    #return
                if int(listminusss[0])<int(listminusss[1]):
                    for y in range(int(listminusss[0]),int(listminusss[1])+1):            
                        framesList.append(y)  
                elif int(listminusss[0])>int(listminusss[1]):
                    for y in range(int(listminusss[1]),int(listminusss[0])+1):            
                        framesList.append(y)  
            else:
                framesList.append(int(listminusss[0]))  
        myHash = set(framesList)
        myHash = list(myHash)
        self.framesSaveBuffer=myHash
        print self.framesSaveBuffer



    def loadAllData(self):
        self.ptcFilesData()
        self.shadowsFilesData()
        self.loadFilesData()
        
    def contextChangedSlot(self):
        #print "contextChangedSlot"
        self.cboxChange()
        
    def delayedLoad(self):
        #print "delayedLoad"
        self.FolderCombobox.currentIndexChanged.disconnect(self.delayedLoad)
        self.FolderCombobox.currentIndexChanged.connect(self.currentLoad)        
        self.cboxChange()

    def cboxChange(self):
        global globaljobBatchContextLE
        stage=mel.eval("rman getvar STAGE")
        contexLine=globaljobBatchContextLE
        currentScene=str(stage)+"_"+str(contexLine)        
        if str(contexLine)=="":
            currentScene=str(stage)        
        my_index=self.FolderCombobox.findText(currentScene)
        if my_index == -1:
            self.FolderCombobox.currentIndexChanged.disconnect(self.currentLoad)        
            self.FolderCombobox.insertItem(0,currentScene)
            self.TargetCombobox.insertItem(0,currentScene)
            self.FolderCombobox.currentIndexChanged.connect(self.currentLoad)                    
            self.FolderCombobox.setCurrentIndex(0)
        else:
            print "index: :"+str(my_index)+ " " + currentScene
            self.FolderCombobox.setCurrentIndex(my_index)

    def currentLoad(self,ind):
        print "currentLoad: "+str(ind)
        self.loadAllData()
    
    def copyButtonSlot(self):
        listOfRezPaths=[]
        folderFolder=str(self.FolderCombobox.currentText())
        targetFolder=str(self.TargetCombobox.currentText())
        listToFiles=[]
        for i in self.ptcView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/shaders"
            paths=glob.glob(projDir+'/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                            
                    listOfRezPaths.append(path)

        listToFiles=[]
        for i in self.shadowsView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/data"                
            paths=glob.glob(projDir+'/*/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                            
                    listOfRezPaths.append(path)
                
        listToFiles=[]
        for i in self.listView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/rib"                                    
            paths=glob.glob(projDir+'/*/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                            
                    listOfRezPaths.append(path)
                
        for lorp in listOfRezPaths:
            targetPath=re.sub(folderFolder,targetFolder,lorp)
            if targetPath!=folderFolder:
                if self.overwriteCB.isChecked():
                    if os.path.exists(targetPath):
                        try:
                            os.remove(targetPath)    
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + lorp)
                    try:
                        if not os.path.exists(os.path.dirname(targetPath)):
                            os.makedirs(os.path.dirname(targetPath))
                        print lorp                            
                        shutil.copy2(lorp,targetPath)
                    except:
                        print("ERROR EXEPTION COPY FILES: " + lorp + " to " + targetPath)     
                else:
                    if not os.path.exists(targetPath):
                        try:
                            if not os.path.exists(os.path.dirname(targetPath)):
                                os.makedirs(os.path.dirname(targetPath))                        
                            print lorp                                
                            shutil.copy2(lorp,targetPath)
                        except:
                            print("ERROR EXEPTION COPY FILES: " + lorp + " to " + targetPath)     
                

                
                
    def ptcFilesData(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/shaders"
        #print "projDir: "+projDir
        paths=glob.glob(projDir+'/*')
        arraynames=[]
        arrayextensions=[]        
        arrayindex=[]
        arrayreal=[]
        arraylabel=[]
        for path in paths:
            base=os.path.basename(path)
            zv = re.sub("[0-9]{4}\.","*.",base)
            cyfry=""
            mach=re.search("[0-9]{4}\.",base)
            if mach:
                cyfry=mach.group(0)[:-1]
            if zv not in arraynames:
                arraynames.append(zv)
                arrayindex.append([cyfry])                            
            else:
                arrayindex[arraynames.index(zv)].append(cyfry)
                                
        for ar in range(len(arrayindex)):
            arrayindex[ar].sort()
            arraylabel.append(collectFrames(arrayindex[ar]))    

        self.ptcModel.clear()
        parentItem = self.ptcModel.invisibleRootItem()        
        for an in range(len(arraynames)):
            item = QtGui.QStandardItem(arraynames[an]+"  "+arraylabel[an])
            item.setData(arraynames[an],QtCore.Qt.UserRole)
            parentItem.appendRow(item)

    def ptcSelectedSlot(self):
        listToFiles=[]
        for i in self.ptcView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        
        print str(listToFiles)    
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/shaders"
            paths=glob.glob(projDir+'/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                            
                    if os.path.exists(path):
                        try:
                            print path
                            os.remove(path)    
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.ptcFilesData()

    def ptcAllSlot(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/shaders"        
        paths=glob.glob(projDir+'/*')
        for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                        
                    if os.path.exists(path):
                        try:
                            print path                                    
                            os.remove(path)
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.ptcFilesData()

    def shadowsFilesData(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/data"
        #print "projDir: "+projDir
        paths=glob.glob(projDir+'/*/*')
        arraynames=[]
        arrayextensions=[]        
        arrayindex=[]
        arrayreal=[]
        arraylabel=[]
        for path in paths:
            base=os.path.basename(path)
            zv = re.sub("[0-9]{4}\.","*.",base)
            cyfry=""
            mach=re.search("[0-9]{4}\.",base)
            if mach:
                cyfry=mach.group(0)[:-1]
            if zv not in arraynames:
                arraynames.append(zv)
                arrayindex.append([cyfry])                            
            else:
                arrayindex[arraynames.index(zv)].append(cyfry)
                                
        for ar in range(len(arrayindex)):
            arrayindex[ar].sort()
            arraylabel.append(collectFrames(arrayindex[ar]))    

        self.shadowsModel.clear()
        parentItem = self.shadowsModel.invisibleRootItem()        
        for an in range(len(arraynames)):
            item = QtGui.QStandardItem(arraynames[an]+"  "+arraylabel[an])
            item.setData(arraynames[an],QtCore.Qt.UserRole)
            parentItem.appendRow(item)

        
    def shadowsSelectedSlot(self):
        listToFiles=[]
        for i in self.shadowsView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        
        print str(listToFiles)    
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/data"                
            paths=glob.glob(projDir+'/*/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                            
                    if os.path.exists(path):
                        try:
                            print path                        
                            os.remove(path)    
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.shadowsFilesData()

    def shadowsAllSlot(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/data"                        
        paths=glob.glob(projDir+'/*/*')
        for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:                        
                    if os.path.exists(path):
                        try:
                            print path
                            os.remove(path)
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.shadowsFilesData()

    def loadFilesData(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/rib"
        #print "projDir: "+projDir
        paths=glob.glob(projDir+'/*/*')
        arraynames=[]
        arrayextensions=[]        
        arrayindex=[]
        arrayreal=[]
        arraylabel=[]
        for path in paths:
            base=os.path.basename(path)
            zv = re.sub("[0-9]{4}\.","*.",base)
            cyfry=""
            mach=re.search("[0-9]{4}\.",base)
            if mach:
                cyfry=mach.group(0)[:-1]
            if zv not in arraynames:
                arraynames.append(zv)
                arrayindex.append([cyfry])                            
            else:
                arrayindex[arraynames.index(zv)].append(cyfry)
                
        for ar in range(len(arrayindex)):
            arrayindex[ar].sort()
            arraylabel.append(collectFrames(arrayindex[ar]))    

        self.listModel.clear()
        parentItem = self.listModel.invisibleRootItem()        
        for an in range(len(arraynames)):
            item = QtGui.QStandardItem(arraynames[an]+"  "+arraylabel[an])
            item.setData(arraynames[an],QtCore.Qt.UserRole)
            parentItem.appendRow(item)
                    

    def deleteSelectedSlot(self):
        listToFiles=[]
        for i in self.listView.selectionModel().selectedRows():
            listToFiles.append(str(i.data(QtCore.Qt.UserRole).toString()))
        
        print str(listToFiles)    
        for i in range(0,len(listToFiles)):
            projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/rib"                                    
            paths=glob.glob(projDir+'/*/'+listToFiles[i])
            for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:
                    if os.path.exists(path):
                        try:
                            print path
                            os.remove(path)    
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.loadFilesData()
    
    def deleteAllSlot(self):
        projDir=mel.eval("rman workspace GetProjDir")+"renderman/"+str(self.FolderCombobox.currentText())+"/rib"                                    
        paths=glob.glob(projDir+'/*/*')
        for path in paths:
                da=1
                if self.framesSaveBuffer != []:
                    mach=re.search("[0-9]{4}\.",path)
                    if mach:
                        cyfry=int(mach.group(0)[:-1])
                        if cyfry not in self.framesSaveBuffer:
                            da=0
                    else:
                        da=0
                if da:            
                    if os.path.exists(path):
                        try:
                            print path
                            os.remove(path)
                        except:
                            print("ERROR EXEPTION REMOVE FILE: " + path)
        self.loadFilesData()
        
        
    def setPreset(self):
        self.parent().parent().parent().wLB.batchLineEdit.setText(("python(\"import sendToRender; reload(sendToRender); sendToRender.rmanSpoolRemoteRIBRemoteRender(\\\\\\\""+self.jobServerAttrubutesLE.text()+"\\\\\\\",\\\\\\\""+self.framesLE.text()+"\\\\\\\","+str(self.jobPriorityLE.value())+",\\\\\\\""+self.jobBatchContextLE.text()+"\\\\\\\",\\\\\\\""+self.jobCmdTagsLE.text()+"\\\\\\\",\\\\\\\""+self.environmentKeyLE.text()+"\\\\\\\",\\\\\\\""+self.rendererArgumentsLE.text()+"\\\\\\\",\\\\\\\""+self.jobDoneCommandLE.text()+"\\\\\\\",\\\\\\\""+self.jobErrorCommandLE.text()+"\\\\\\\",\\\\\\\""+self.crewsLE.text()+"\\\\\\\",\\\\\\\""+self.extraJobOptionsLE.text()+"\\\\\\\","+str(self.framesPerServerLE.value())+","+str(self.localRB.isChecked())+","+str(self.startPausedCB.isChecked())+","+str(self.cropWondowLE1.value())+","+str(self.cropWondowLE2.value())+","+str(self.cropWondowLE3.value())+","+str(self.cropWondowLE4.value())+","+str(self.rezolutionCombobox.currentIndex())+","+str(self.loadSTCamerasLable.isChecked())+","+str(self.selectCamerasLabel.isChecked())+","+str(self.startMainCamera.isChecked())+","+str(self.startStereoCameras.isChecked())+","+str(self.customDisplayLable.isChecked())+","+str(self.customDisplayLE.isChecked())+","+str(self.customDisplayLE2.isChecked())+","+str(self.reuseShadowMapsLabel.isChecked())+","+str(self.reuseShadowMapsCombobox.currentIndex())+","+str(self.reuseSSLabel.isChecked())+","+str(self.reuseSSCombobox.currentIndex())+","+str(self.reuseShaveRibsLabel.isChecked())+","+str(self.reuseShaveRibsCB.isChecked())+","+str(self.shadingRateScaleLE.value())+","+str(self.directLightSamplesScaleLE.value())+","+str(self.shutterAngleScaleLE.value())+","+str(self.statisticOutputLable.isChecked())+","+str(self.statisticOutputLE.isChecked())+","+str(self.disableAllShaveCB.isChecked())+","+str(self.disableAllLightsCB.isChecked())+","+str(self.disableAllShadersCB.isChecked())+","+str(self.disableRayTracingCB.isChecked())+","+str(self.sceneAutoCleanCB.isChecked())+","+str(self.loadProxyReferenceCB.isChecked())+","+str(self.motionBlurLabel.isChecked())+","+str(self.motionBlurCB.isChecked())+","+str(self.motionBlurCB2.isChecked())+","+str(self.shutterAngleSB.value())+",\\\\\\\""+str(self.motionBlurTypeCombobox.currentText())+"\\\\\\\",\\\\\\\""+str(self.shutterTimingCombobox.currentText())+"\\\\\\\","+str(self.shutterOpeningSB1.value())+","+str(self.shutterOpeningSB2.value())+","+str(self.dofLabel.isChecked())+","+str(self.dofCB.isChecked())+","+str(self.dofCB2.value())+","+str(self.dofSB3.value())+","+str(self.dofSB4.value())+","+str(self.shadingRateCB.isChecked())+","+str(self.shadingRateSB.value())+","+str(self.pixelSampelsLabel.isChecked())+","+str(self.pixelSampelsSB.value())+","+str(self.pixelSampelsSB2.value())+","+str(self.filterCB.isChecked())+","+str(self.filter1SB.value())+","+str(self.filter2SB.value())+",\\\\\\\""+str(self.filterCombobox.currentText())+"\\\\\\\","+str(self.ribFormatCB.isChecked())+",\\\\\\\""+str(self.ribFormatCombobox.currentText())+"\\\\\\\",\\\\\\\""+str(self.ribFormatCombobox2.currentText())+"\\\\\\\","+str(self.lazyCB.isChecked())+","+str(self.lazyCB1.isChecked())+","+str(self.lazyCB2.isChecked())+")\")").replace("$","\\$"))

    def readFromCacheSlot(self):        
        if not mel.eval("attributeExists(\"shaveWriteRib\", \"perspShape\")"):
            cmds.addAttr("perspShape",at="bool",ln="shaveWriteRib")
        if self.readFromCache.checkState()==QtCore.Qt.Unchecked:    
            cmds.setAttr("perspShape.shaveWriteRib",1)
        else:
            cmds.setAttr("perspShape.shaveWriteRib",0)            
            
            
    def cacheIfNotExistsSlot(self):            
        if not mel.eval("attributeExists(\"buildIfNotExists\", \"perspShape\")"):
            cmds.addAttr("perspShape",at="bool",ln="buildIfNotExists")
        if self.cacheIfNotExists.checkState()==QtCore.Qt.Unchecked:    
            cmds.setAttr("perspShape.buildIfNotExists",0)
        else:
            cmds.setAttr("perspShape.buildIfNotExists",1)            
            
                           
    def loadSceneData(self):
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()        
        if cmds.pluginInfo("shaveNode",query=True,l=True):
            nodes=cmds.ls(type="shaveHair")
            for n in nodes:
                item = QtGui.QStandardItem(n)
                parentItem.appendRow(item)

        
        
    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("WindowFurCache")
       
        chekStat=[0]
        if mel.eval("attributeExists(\"shaveWriteRib\", \"perspShape\")"):
            chekStat[0]=not cmds.getAttr("perspShape.shaveWriteRib")
        else:
            chekStat = settings.value("readFromCache", "1").toInt()
        if chekStat[0] == 0: self.readFromCache.setCheckState(QtCore.Qt.Unchecked)
        else: self.readFromCache.setCheckState(QtCore.Qt.Checked)

        if mel.eval("attributeExists(\"buildIfNotExists\", \"perspShape\")"):
            chekStat[0]=cmds.getAttr("perspShape.buildIfNotExists")
        else:
            chekStat = settings.value("cacheIfNotExists", "1").toInt()
        if chekStat[0] == 0: self.cacheIfNotExists.setCheckState(QtCore.Qt.Unchecked)
        else: self.cacheIfNotExists.setCheckState(QtCore.Qt.Checked)
                
        settings.endGroup()            
    
    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("WindowFurCache")
        
        chekStat = 0
        if self.readFromCache.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("readFromCache", chekStat)        

        chekStat = 0
        if self.cacheIfNotExists.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("cacheIfNotExists", chekStat)        

        settings.endGroup()              



class mySpinBox(QtGui.QSpinBox):
    def __init__(self, parent=getMayaWindow()):
        super(mySpinBox, self).__init__(parent)

    def wheelEvent(self,event):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QSpinBox.wheelEvent(self,event)


class myDoubleSpinBox(QtGui.QDoubleSpinBox):
    def __init__(self, parent=getMayaWindow()):
        super(myDoubleSpinBox, self).__init__(parent)

    def wheelEvent(self,event):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QDoubleSpinBox.wheelEvent(self,event)

class myComboBox(QtGui.QComboBox):
    def __init__(self, parent=getMayaWindow()):
        super(myComboBox, self).__init__(parent)

    def wheelEvent(self,event):
        if not self.hasFocus():
            event.ignore()
        else: 
            QtGui.QComboBox.wheelEvent(self,event)

class WindowBatchRender(QtGui.QWidget):
    
    ContextChanged = QtCore.pyqtSignal()
    
    def __init__(self, parent=getMayaWindow()):
        super(WindowBatchRender, self).__init__(parent)
        
        self.mainLayout = QtGui.QVBoxLayout()
        
        self.mainConvertLayout = QtGui.QVBoxLayout()
        
        
        self.mainScrollArea = QtGui.QScrollArea()
        self.mainScrollArea.setWidgetResizable(True)
        self.mainScrollArea.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mainConvert = QtGui.QGroupBox(" Main ")
        self.renderOptionsLayout = QtGui.QGridLayout()
        self.mainConvert.setLayout(self.renderOptionsLayout)

        self.customConvert = QtGui.QGroupBox(" Custom ")
        self.customConvertLayout = QtGui.QGridLayout()
        self.customConvert.setLayout(self.customConvertLayout)        
        
        self.customButtonsLayout = QtGui.QHBoxLayout()
        
        
        self.localRB = QtGui.QRadioButton("local")
        self.tractorRB = QtGui.QRadioButton("tractor")

        self.startPausedLable=QtGui.QLabel("Start paused: ")
        self.startPausedCB=QtGui.QCheckBox()

        self.jobBatchContextLabel=QtGui.QLabel("Batch Context: ")
        self.jobBatchContextLE=QtGui.QLineEdit()
        self.jobBatchContextLE.editingFinished.connect(self.textChangedSlot)
       
        
        
        self.framesPerServerLabel=QtGui.QLabel("Frames per Server: ")
        self.framesPerServerLE=mySpinBox()
        self.framesPerServerLE.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.framesPerServerLE.setRange(0,10000)
        self.intValidator=QtGui.QIntValidator()        
        self.doubleValidator=QtGui.QDoubleValidator()        
        #self.framesPerServerLE.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)        
        
        self.jobPriorityLable=QtGui.QLabel("Job Priority: ")
        self.jobPriorityLE=mySpinBox()
        self.jobPriorityLE.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.jobPriorityLE.setRange(0,1000000)
        #self.jobPriorityLE.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)        
        
        self.framesLable=QtGui.QLabel("Frames: ")
        self.framesLE=QtGui.QLineEdit("")
        self.rx=QtCore.QRegExp("[0-9\-\,]*");
        self.regExpValidator=QtGui.QRegExpValidator(self.rx,self)
        self.framesLE.setValidator(self.regExpValidator)
        
        self.jobServerAttrubutesLable=QtGui.QLabel("Job Server Attributes: ")
        self.jobServerAttrubutesLE=QtGui.QLineEdit()

        self.jobCmdTagsLable=QtGui.QLabel("Job Cmd Tags: ")
        self.jobCmdTagsLE=QtGui.QLineEdit()
        
        self.environmentKeyLable=QtGui.QLabel("Environment Key: ")
        self.environmentKeyLE=QtGui.QLineEdit()
        
        self.rendererArgumentsLable=QtGui.QLabel("Renderer Arguments: ")
        self.rendererArgumentsLE=QtGui.QLineEdit()

        self.jobDoneCommandLable=QtGui.QLabel("Job Done Command: ")
        self.jobDoneCommandLE=QtGui.QLineEdit()

        self.jobErrorCommandLable=QtGui.QLabel("Job Error Command: ")
        self.jobErrorCommandLE=QtGui.QLineEdit()
        
        self.crewsLable=QtGui.QLabel("Crews: ")
        self.crewsLE=QtGui.QLineEdit()
        
        self.extraJobOptionsLable=QtGui.QLabel("Extra Job Options: ")
        self.extraJobOptionsLE=QtGui.QLineEdit()






        self.cropWondowLable=QtGui.QLabel("Crop Window: ")
        self.cropWondowLE1=myDoubleSpinBox()
        self.cropWondowLE1.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.cropWondowLE1.setRange(0,10000)
        self.cropWondowLE2=myDoubleSpinBox()
        self.cropWondowLE2.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.cropWondowLE2.setRange(0,10000)
        self.cropWondowLE3=myDoubleSpinBox()
        self.cropWondowLE3.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.cropWondowLE3.setRange(0,10000)
        self.cropWondowLE4=myDoubleSpinBox()
        self.cropWondowLE4.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.cropWondowLE4.setRange(0,10000)


        self.cropWondowButtons=QtGui.QWidget()
        self.cropWondowButtonsLayout=QtGui.QGridLayout()
        self.cropWondowButtonsLayout.setContentsMargins(0,0,0,0)
        self.cropWondowButtons.setLayout(self.cropWondowButtonsLayout)
        self.cropWondowButtonsLayout.addWidget(self.cropWondowLE1,0,0)
        self.cropWondowButtonsLayout.addWidget(self.cropWondowLE2,0,1)
        self.cropWondowButtonsLayout.addWidget(self.cropWondowLE3,1,0)
        self.cropWondowButtonsLayout.addWidget(self.cropWondowLE4,1,1)        
        
        
        self.rezolutionComboboxLabel = QtGui.QLabel("Image size:")       
        self.rezolutionCombobox = myComboBox()
        self.rezolutionCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.rezolutionQlistNames = QtCore.QStringList()
        self.rezolutionQlistNames.append("from globals")
        self.rezolutionQlistNames.append("Urfin 0.5K")        
        self.rezolutionQlistNames.append("Urfin 1K")        
        self.rezolutionQlistNames.append("Urfin 2K")
        self.rezolutionQlistNames.append("Urfin 2K Stereo")
        self.rezolutionQlistNames.append("Urfin 4K")        
        self.rezolutionCombobox.addItems(self.rezolutionQlistNames)



        self.loadSTCamerasL=QtGui.QLabel("Load ST cams file:")
        self.loadSTCamerasLable=QtGui.QCheckBox()
        self.loadSTCamerasLable.setCheckState(QtCore.Qt.Checked)
                
        self.selectCamerasLabel = QtGui.QCheckBox("Override cameras:")
        self.selectCamerasL2=QtGui.QLabel("select: ")
        self.startMainCamera=QtGui.QCheckBox("Left")
        self.startStereoCameras=QtGui.QCheckBox("Right")
        self.selectCamerasLabel.stateChanged.connect(self.selectCamerasLabelEnable)        
        self.selectCamerasLabel.setCheckState(QtCore.Qt.Checked)                
        

        self.startCameraWidget=QtGui.QWidget()
        self.startCameraLayout=QtGui.QHBoxLayout()
        self.startCameraLayout.setContentsMargins(0,0,0,0)
        self.startCameraWidget.setLayout(self.startCameraLayout)


        self.startCameraLayout.addWidget(self.selectCamerasLabel,1)
        self.startCameraLayout.addWidget(self.selectCamerasL2)
        self.startCameraLayout.addWidget(self.startMainCamera)
        self.startCameraLayout.addWidget(self.startStereoCameras,3)
        

        self.customDisplayLable=QtGui.QCheckBox("Override custom:")
        self.customDisplayL2=QtGui.QLabel("display channels:")
        self.customDisplayLE=QtGui.QCheckBox()                           
        self.customDisplayL3=QtGui.QLabel("Final passes:")
        self.customDisplayLE2=QtGui.QCheckBox()                           
        self.customDisplayLable.stateChanged.connect(self.customDisplayLableEnable)
        self.customDisplayLable.setCheckState(QtCore.Qt.Checked)
                
        self.customDisplayButtons2=QtGui.QWidget()
        self.customDisplayLayout2=QtGui.QHBoxLayout()
        self.customDisplayLayout2.setContentsMargins(0,0,0,0)
        self.customDisplayButtons2.setLayout(self.customDisplayLayout2)

        self.customDisplayLayout2.addWidget(self.customDisplayL2,1)
        self.customDisplayLayout2.addWidget(self.customDisplayLE,1)
        self.customDisplayLayout2.addWidget(self.customDisplayL3,1)
        self.customDisplayLayout2.addWidget(self.customDisplayLE2,3)

        self.reuseShadowMapsLabel = QtGui.QCheckBox("Override shadow:")
        self.reuseShadowMapsL2=QtGui.QLabel("passes: ")
        self.reuseShadowMapsCombobox = myComboBox()
        self.reuseShadowMapsCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.reuseShadowMapslistNames = QtCore.QStringList()
        self.reuseShadowMapslistNames.append("Compute")
        self.reuseShadowMapslistNames.append("Reuse")        
        self.reuseShadowMapslistNames.append("Disable")        
        self.reuseShadowMapsCombobox.addItems(self.reuseShadowMapslistNames)
        self.reuseShadowMapsLabel.stateChanged.connect(self.reuseShadowMapsLabelEnable)        
        self.reuseShadowMapsLabel.setCheckState(QtCore.Qt.Checked)        

        self.reuseShadowMapsButtons2=QtGui.QWidget()
        self.reuseShadowMapsLayout2=QtGui.QHBoxLayout()
        self.reuseShadowMapsLayout2.setContentsMargins(0,0,0,0)
        self.reuseShadowMapsButtons2.setLayout(self.reuseShadowMapsLayout2)

        self.reuseShadowMapsLayout2.addWidget(self.reuseShadowMapsLabel,1)
        self.reuseShadowMapsLayout2.addWidget(self.reuseShadowMapsL2)
        self.reuseShadowMapsLayout2.addWidget(self.reuseShadowMapsCombobox,3)


        self.reuseSSLabel = QtGui.QCheckBox("Override SSS:")
        self.reuseSSL2=QtGui.QLabel("passes: ")
        self.reuseSSCombobox = myComboBox()
        self.reuseSSCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.reuseSSlistNames = QtCore.QStringList()
        self.reuseSSlistNames.append("Compute")
        self.reuseSSlistNames.append("Reuse")        
        self.reuseSSlistNames.append("Disable")        
        self.reuseSSCombobox.addItems(self.reuseSSlistNames)
        self.reuseSSLabel.stateChanged.connect(self.reuseSSEnable)        
        self.reuseSSLabel.setCheckState(QtCore.Qt.Checked)        

        self.reuseSSButtons2=QtGui.QWidget()
        self.reuseSSLayout2=QtGui.QHBoxLayout()
        self.reuseSSLayout2.setContentsMargins(0,0,0,0)
        self.reuseSSButtons2.setLayout(self.reuseSSLayout2)

        self.reuseSSLayout2.addWidget(self.reuseSSLabel,1)
        self.reuseSSLayout2.addWidget(self.reuseSSL2)
        self.reuseSSLayout2.addWidget(self.reuseSSCombobox,3)



        
        self.reuseShaveRibsLabel = QtGui.QCheckBox("Over shave ribs:")
        self.reuseShaveRibsL2=QtGui.QLabel("reuse: ")
        self.reuseShaveRibsCB=QtGui.QCheckBox()
        self.reuseShaveRibsCB.stateChanged.connect(self.shaveWriteRibSlot)        
        self.reuseShaveRibsLabel.stateChanged.connect(self.reuseShaveRibsLabelEnable)        
        self.reuseShaveRibsLabel.setCheckState(QtCore.Qt.Checked)        

        self.reuseShaveRibsButtons2=QtGui.QWidget()
        self.reuseShaveRibsLayout2=QtGui.QHBoxLayout()
        self.reuseShaveRibsLayout2.setContentsMargins(0,0,0,0)
        self.reuseShaveRibsButtons2.setLayout(self.reuseShaveRibsLayout2)

        self.reuseShaveRibsLayout2.addWidget(self.reuseShaveRibsLabel,1)
        self.reuseShaveRibsLayout2.addWidget(self.reuseShaveRibsL2)
        self.reuseShaveRibsLayout2.addWidget(self.reuseShaveRibsCB,3)


        self.shadingRateCB=QtGui.QCheckBox("Over shading rate:")
        self.shadingRateSB=myDoubleSpinBox()
        self.shadingRateSB.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shadingRateSB.setRange(0,1000)
        self.shadingRateSB.setValue(1)
        self.shadingRateScaleLable=QtGui.QLabel("Shading rate scale:")
        self.shadingRateScaleLE=myDoubleSpinBox()
        self.shadingRateScaleLE.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shadingRateScaleLE.setRange(0,100)
        self.shadingRateCB.stateChanged.connect(self.shadingRateSlot)        
        self.shadingRateCB.setCheckState(QtCore.Qt.Checked)        

        self.filterCB=QtGui.QCheckBox("Override Filter:")
        self.filter1SB=myDoubleSpinBox()
        self.filter1SB.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.filter1SB.setRange(0,10)
        self.filter1SB.setValue(1)
        self.filter2SB=myDoubleSpinBox()
        self.filter2SB.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.filter2SB.setRange(0,10)
        self.filter2SB.setValue(1)
        self.filterCombobox = myComboBox()
        self.filterCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.filterlistNames = QtCore.QStringList()
        self.filterlistNames.append("box")
        self.filterlistNames.append("triangle")
        self.filterlistNames.append("catmull-rom")
        self.filterlistNames.append("sinc")
        self.filterlistNames.append("gaussian")
        self.filterlistNames.append("mitchell")
        self.filterlistNames.append("separable-catmull-rom")
        self.filterlistNames.append("blackman-harris")
        self.filterCombobox.addItems(self.filterlistNames)
        self.filterCombobox.setMinimumWidth(10)
        self.filterButtons=QtGui.QWidget()
        self.filterLayout=QtGui.QHBoxLayout()
        self.filterLayout.setContentsMargins(0,0,0,0)
        self.filterButtons.setLayout(self.filterLayout)

        self.filterLayout.addWidget(self.filter1SB)
        self.filterLayout.addWidget(self.filter2SB)
        self.filterLayout.addWidget(self.filterCombobox)
        self.filterCB.stateChanged.connect(self.filterSlot)        
        self.filterCB.setCheckState(QtCore.Qt.Checked)        

        self.ribFormatCB=QtGui.QCheckBox("Over Rib Format:")
        self.ribFormatCombobox = myComboBox()
        self.ribFormatCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.ribFormatlistNames = QtCore.QStringList()
        self.ribFormatlistNames.append("binary")
        self.ribFormatlistNames.append("ascii")
        self.ribFormatCombobox.addItems(self.ribFormatlistNames)
        self.ribFormatCombobox.setMinimumWidth(10)
        self.ribFormatCombobox2 = myComboBox()
        self.ribFormatCombobox2.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.ribFormatlistNames2 = QtCore.QStringList()
        self.ribFormatlistNames2.append("gzip")
        self.ribFormatlistNames2.append("none")
        self.ribFormatCombobox2.addItems(self.ribFormatlistNames2)
        self.ribFormatCombobox2.setMinimumWidth(10)
        self.ribFormatButtons=QtGui.QWidget()
        self.ribFormatLayout=QtGui.QHBoxLayout()
        self.ribFormatLayout.setContentsMargins(0,0,0,0)
        self.ribFormatButtons.setLayout(self.ribFormatLayout)

        self.ribFormatLayout.addWidget(self.ribFormatCombobox)
        self.ribFormatLayout.addWidget(self.ribFormatCombobox2)
        self.ribFormatCB.stateChanged.connect(self.ribFormatSlot)        
        self.ribFormatCB.setCheckState(QtCore.Qt.Checked)        


        self.lazyCB=QtGui.QCheckBox("Over Lazy Render:")
        self.lazyLabel=QtGui.QLabel("image:")
        self.lazyCB1 = QtGui.QCheckBox()
        self.lazyLabel1=QtGui.QLabel("rib:")
        self.lazyCB2 = QtGui.QCheckBox()
        self.lazyButtons=QtGui.QWidget()
        self.lazyLayout=QtGui.QHBoxLayout()
        self.lazyLayout.setContentsMargins(0,0,0,0)
        self.lazyButtons.setLayout(self.lazyLayout)

        self.lazyLayout.addWidget(self.lazyLabel)
        self.lazyLayout.addWidget(self.lazyCB1)
        self.lazyLayout.addWidget(self.lazyLabel1)
        self.lazyLayout.addWidget(self.lazyCB2)
        self.lazyCB.stateChanged.connect(self.lazySlot)        
        self.lazyCB.setCheckState(QtCore.Qt.Checked)        


        self.pixelSampelsLabel = QtGui.QCheckBox("Over pixel samp:")
        self.pixelSampelsButtons=QtGui.QWidget()
        self.pixelSampelsLayout=QtGui.QHBoxLayout()
        self.pixelSampelsLayout.setContentsMargins(0,0,0,0)
        self.pixelSampelsButtons.setLayout(self.pixelSampelsLayout)
        self.pixelSampelsSB=mySpinBox()
        self.pixelSampelsSB.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.pixelSampelsSB.setRange(0,90)
        self.pixelSampelsSB2=mySpinBox()
        self.pixelSampelsSB2.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.pixelSampelsSB2.setRange(0,90)

        self.pixelSampelsLayout.addWidget(self.pixelSampelsSB)
        self.pixelSampelsLayout.addWidget(self.pixelSampelsSB2)
        self.pixelSampelsLabel.stateChanged.connect(self.pixelSamplesSlot)        
        self.pixelSampelsLabel.setCheckState(QtCore.Qt.Checked)        


        self.directLightSamplesScaleLable=QtGui.QLabel("Direct lig samp scale:")
        self.directLightSamplesScaleLE=myDoubleSpinBox()                        
        self.directLightSamplesScaleLE.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.directLightSamplesScaleLE.setRange(0,9000)
                
        self.shutterAngleScaleLable=QtGui.QLabel("Shutter Ang scale:")
        self.shutterAngleScaleLE=myDoubleSpinBox()                        
        self.shutterAngleScaleLE.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shutterAngleScaleLE.setRange(0,100)

        self.statisticOutputLable=QtGui.QCheckBox("Override statistic:")
        self.statisticOutputL2=QtGui.QLabel("output:")
        self.statisticOutputLE=QtGui.QCheckBox()                           
        self.statisticOutputLable.stateChanged.connect(self.statisticOutputLableEnable)
        self.statisticOutputLable.setCheckState(QtCore.Qt.Checked)
                
        self.statisticOutputButtons2=QtGui.QWidget()
        self.statisticOutputLayout2=QtGui.QHBoxLayout()
        self.statisticOutputLayout2.setContentsMargins(0,0,0,0)
        self.statisticOutputButtons2.setLayout(self.statisticOutputLayout2)

        self.statisticOutputLayout2.addWidget(self.statisticOutputLable,1)
        self.statisticOutputLayout2.addWidget(self.statisticOutputL2)
        self.statisticOutputLayout2.addWidget(self.statisticOutputLE,3)



        self.disableAllShaveLable=QtGui.QLabel("Disable all shave:")
        self.disableAllShaveCB=QtGui.QCheckBox()                           
        
        self.disableAllLightsLable=QtGui.QLabel("Disable all lights:")
        self.disableAllLightsCB=QtGui.QCheckBox()                           

        self.disableAllShadersLable=QtGui.QLabel("Disable all shaders:")
        self.disableAllShadersCB=QtGui.QCheckBox()                           

        self.disableRayTracingLable=QtGui.QLabel("Disable raytracing:")
        self.disableRayTracingCB=QtGui.QCheckBox()                           

        self.sceneAutoCleanLable=QtGui.QLabel("Scene auto setup:")
        self.sceneAutoCleanCB=QtGui.QCheckBox()                           

        self.loadProxyReferenceLable=QtGui.QLabel("auto load proxy reference:")
        self.loadProxyReferenceCB=QtGui.QCheckBox()                           



        self.motionBlurLabel = QtGui.QCheckBox("Override MB:")
        self.motionBlurL2=QtGui.QLabel("MB: ")
        self.motionBlurCB=QtGui.QCheckBox()
        self.motionBlurL3=QtGui.QLabel("Cam Bl: ")
        self.motionBlurCB2=QtGui.QCheckBox()
        self.shutterAngleLabel=QtGui.QLabel("Shut Ang:")
        self.shutterAngleSB=myDoubleSpinBox()
        self.shutterAngleSB.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shutterAngleSB.setValue(80)
        self.shutterAngleSB.setRange(0,360)

        self.motionBlurTypeLabel = QtGui.QLabel("Type:")       
        self.motionBlurTypeCombobox = myComboBox()
        self.motionBlurTypeCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.motionBlurTypelistNames = QtCore.QStringList()
        self.motionBlurTypelistNames.append("frame")
        self.motionBlurTypelistNames.append("subframe")
        self.shutterOpeningLabel=QtGui.QLabel("Shut open:")
        self.shutterOpeningSB1=myDoubleSpinBox()
        self.shutterOpeningSB1.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shutterOpeningSB1.setValue(0.35)
        self.shutterOpeningSB1.setRange(0,1)
        self.shutterOpeningLabel2=QtGui.QLabel("Shut close:")
        self.shutterOpeningSB2=myDoubleSpinBox()
        self.shutterOpeningSB2.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shutterOpeningSB2.setValue(0.65)
        self.shutterOpeningSB2.setRange(0,1)
        self.shutterTimingLabel=QtGui.QLabel("Shut timing:")
        self.shutterTimingCombobox = myComboBox()
        self.shutterTimingCombobox.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.shutterTiminglistNames = QtCore.QStringList()
        self.shutterTiminglistNames.append("frameOpen")
        self.shutterTiminglistNames.append("frameCenter")
        self.shutterTiminglistNames.append("frameClose")
        self.motionBlurTypeCombobox.addItems(self.motionBlurTypelistNames)
        self.shutterTimingCombobox.addItems(self.shutterTiminglistNames)


        self.motionBlurLabel.stateChanged.connect(self.motionBlurLabelEnable)        
        self.motionBlurL2.setEnabled(False)
        self.motionBlurCB.setEnabled(False)
        self.motionBlurL3.setEnabled(False)
        self.motionBlurCB2.setEnabled(False)
        self.shutterAngleLabel.setEnabled(False)
        self.shutterAngleSB.setEnabled(False)
        self.motionBlurTypeLabel.setEnabled(False)
        self.motionBlurTypeCombobox.setEnabled(False)
        self.shutterOpeningLabel.setEnabled(False)
        self.shutterOpeningLabel2.setEnabled(False)
        self.shutterOpeningSB1.setEnabled(False)
        self.shutterOpeningSB2.setEnabled(False)
        self.shutterTimingLabel.setEnabled(False)
        self.shutterTimingCombobox.setEnabled(False)

        self.motionBlurButtons2=QtGui.QWidget()
        self.motionBlurLayout2=QtGui.QGridLayout()
        self.motionBlurLayout2.setContentsMargins(0,0,0,0)
        self.motionBlurButtons2.setLayout(self.motionBlurLayout2)


        self.motionBlurLayout2.addWidget(self.motionBlurLabel,0,0,2,1)
        self.motionBlurLayout2.addWidget(self.motionBlurL2,0,1)
        self.motionBlurLayout2.addWidget(self.motionBlurCB,0,2)
        self.motionBlurLayout2.addWidget(self.motionBlurL3,0,3)
        self.motionBlurLayout2.addWidget(self.motionBlurCB2,0,4)
        self.motionBlurLayout2.addWidget(self.shutterAngleLabel,1,1)
        self.motionBlurLayout2.addWidget(self.shutterAngleSB,1,2)
        self.motionBlurLayout2.addWidget(self.motionBlurTypeLabel,1,3)
        self.motionBlurLayout2.addWidget(self.motionBlurTypeCombobox,1,4)
        self.motionBlurLayout2.addWidget(self.shutterOpeningLabel,2,1)
        self.motionBlurLayout2.addWidget(self.shutterOpeningSB1,2,2)
        self.motionBlurLayout2.addWidget(self.shutterOpeningLabel2,2,3)
        self.motionBlurLayout2.addWidget(self.shutterOpeningSB2,2,4)
        self.motionBlurLayout2.addWidget(self.shutterTimingLabel,3,1)
        self.motionBlurLayout2.addWidget(self.shutterTimingCombobox,3,2)

        self.dofLabel = QtGui.QCheckBox("Override DOF:")
        self.dofL2=QtGui.QLabel("Dof:")
        self.dofCB=QtGui.QCheckBox()
        self.dofL3=QtGui.QLabel("F Dist:")
        self.dofCB2=myDoubleSpinBox()
        self.dofCB2.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.dofCB2.setRange(0,10000)
        self.dofCB2.setValue(5)
        self.dofL4=QtGui.QLabel("F Stop:")
        self.dofSB3=myDoubleSpinBox()
        self.dofSB3.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.dofSB3.setRange(0,900)
        self.dofSB3.setValue(5.6)
        self.dofL5=QtGui.QLabel("F Reg Scale:")
        self.dofSB4=myDoubleSpinBox()
        self.dofSB4.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.dofSB4.setRange(0,100)
        self.dofSB4.setValue(1)
        self.dofLabel.stateChanged.connect(self.dofLabelEnable)        
        self.dofL2.setEnabled(False)
        self.dofCB.setEnabled(False)
        self.dofL3.setEnabled(False)
        self.dofCB2.setEnabled(False)
        self.dofL4.setEnabled(False)
        self.dofSB3.setEnabled(False)
        self.dofL5.setEnabled(False)
        self.dofSB4.setEnabled(False)

        self.motionBlurLayout2.addWidget(self.dofLabel,4,0,2,1)
        self.motionBlurLayout2.addWidget(self.dofL2,4,1)
        self.motionBlurLayout2.addWidget(self.dofCB,4,2)
        self.motionBlurLayout2.addWidget(self.dofL3,4,3)
        self.motionBlurLayout2.addWidget(self.dofCB2,4,4)
        self.motionBlurLayout2.addWidget(self.dofL4,5,1)
        self.motionBlurLayout2.addWidget(self.dofSB3,5,2)
        self.motionBlurLayout2.addWidget(self.dofL5,5,3)
        self.motionBlurLayout2.addWidget(self.dofSB4,5,4)



        self.startRenderTractor=QtGui.QPushButton("START")
        self.startRenderTractor.released.connect(self.rmanSpoolRemoteRIBRemoteRenderSlot)
        
        self.resetRenderTractor=QtGui.QPushButton("reset")
        self.resetRenderTractor.released.connect(self.resetRenderTractorInterface)

        self.playblastRenderTractor=QtGui.QPushButton("playblast")
        self.playblastRenderTractor.released.connect(self.setRenderTractorInterfaceAnimation)

        self.startSetPreset=QtGui.QPushButton("set Preset")
        self.startSetPreset.released.connect(self.setPreset)
        


        self.renderOptionsLayout.addWidget(self.localRB,0,0)
        self.renderOptionsLayout.addWidget(self.tractorRB,0,1)
        self.renderOptionsLayout.addWidget(self.startPausedLable,1,0)
        self.renderOptionsLayout.addWidget(self.startPausedCB,1,1)
        self.renderOptionsLayout.addWidget(self.jobBatchContextLabel,2,0)
        self.renderOptionsLayout.addWidget(self.jobBatchContextLE,2,1)
        self.renderOptionsLayout.addWidget(self.framesPerServerLabel,3,0)                        
        self.renderOptionsLayout.addWidget(self.framesPerServerLE,3,1)
        self.renderOptionsLayout.addWidget(self.jobPriorityLable,4,0)
        self.renderOptionsLayout.addWidget(self.jobPriorityLE,4,1)
        self.renderOptionsLayout.addWidget(self.jobServerAttrubutesLable,5,0)
        self.renderOptionsLayout.addWidget(self.jobServerAttrubutesLE,5,1)
        self.renderOptionsLayout.addWidget(self.jobCmdTagsLable,6,0)
        self.renderOptionsLayout.addWidget(self.jobCmdTagsLE,6,1)
        self.renderOptionsLayout.addWidget(self.environmentKeyLable,7,0)
        self.renderOptionsLayout.addWidget(self.environmentKeyLE,7,1)
        self.renderOptionsLayout.addWidget(self.rendererArgumentsLable,8,0)
        self.renderOptionsLayout.addWidget(self.rendererArgumentsLE,8,1)
        self.renderOptionsLayout.addWidget(self.jobDoneCommandLable,9,0)
        self.renderOptionsLayout.addWidget(self.jobDoneCommandLE,9,1)
        self.renderOptionsLayout.addWidget(self.jobErrorCommandLable,10,0)
        self.renderOptionsLayout.addWidget(self.jobErrorCommandLE,10,1)
        self.renderOptionsLayout.addWidget(self.crewsLable,11,0)
        self.renderOptionsLayout.addWidget(self.crewsLE,11,1)
        self.renderOptionsLayout.addWidget(self.extraJobOptionsLable,12,0)
        self.renderOptionsLayout.addWidget(self.extraJobOptionsLE,12,1)
        
        
        self.customConvertLayout.addWidget(self.framesLable,0,0)
        self.customConvertLayout.addWidget(self.framesLE,0,1)
        self.customConvertLayout.addWidget(self.cropWondowLable,1,0)
        self.customConvertLayout.addWidget(self.cropWondowButtons,1,1)
        self.customConvertLayout.addWidget(self.rezolutionComboboxLabel,2,0)
        self.customConvertLayout.addWidget(self.rezolutionCombobox,2,1)

        self.customConvertLayout.addWidget(self.loadSTCamerasL,3,0)
        self.customConvertLayout.addWidget(self.loadSTCamerasLable,3,1)

        self.customConvertLayout.addWidget(self.selectCamerasLabel,4,0)
        self.customConvertLayout.addWidget(self.startCameraWidget,4,1)

        self.customConvertLayout.addWidget(self.customDisplayLable,5,0)
        self.customConvertLayout.addWidget(self.customDisplayButtons2,5,1)

        self.customConvertLayout.addWidget(self.reuseShadowMapsLabel,6,0)
        self.customConvertLayout.addWidget(self.reuseShadowMapsButtons2,6,1)

        self.customConvertLayout.addWidget(self.reuseSSLabel,7,0)
        self.customConvertLayout.addWidget(self.reuseSSButtons2,7,1)

        self.customConvertLayout.addWidget(self.reuseShaveRibsLabel,8,0)
        self.customConvertLayout.addWidget(self.reuseShaveRibsButtons2,8,1)

        self.customConvertLayout.addWidget(self.shadingRateCB,9,0)
        self.customConvertLayout.addWidget(self.shadingRateSB,9,1)
        
        self.customConvertLayout.addWidget(self.ribFormatCB,10,0)
        self.customConvertLayout.addWidget(self.ribFormatButtons,10,1)

        self.customConvertLayout.addWidget(self.lazyCB,11,0)
        self.customConvertLayout.addWidget(self.lazyButtons,11,1)

        self.customConvertLayout.addWidget(self.filterCB,12,0)
        self.customConvertLayout.addWidget(self.filterButtons,12,1)

        self.customConvertLayout.addWidget(self.pixelSampelsLabel,13,0)
        self.customConvertLayout.addWidget(self.pixelSampelsButtons,13,1)

        self.customConvertLayout.addWidget(self.shadingRateScaleLable,14,0)
        self.customConvertLayout.addWidget(self.shadingRateScaleLE,14,1)
        self.customConvertLayout.addWidget(self.directLightSamplesScaleLable,15,0)
        self.customConvertLayout.addWidget(self.directLightSamplesScaleLE,15,1)
        self.customConvertLayout.addWidget(self.shutterAngleScaleLable,16,0)
        self.customConvertLayout.addWidget(self.shutterAngleScaleLE,16,1)
        self.customConvertLayout.addWidget(self.statisticOutputLable,17,0)
        self.customConvertLayout.addWidget(self.statisticOutputButtons2,17,1)

        
        self.customConvertLayout.addWidget(self.disableAllShaveLable,18,0)
        self.customConvertLayout.addWidget(self.disableAllShaveCB,18,1)
        self.customConvertLayout.addWidget(self.disableAllLightsLable,19,0)
        self.customConvertLayout.addWidget(self.disableAllLightsCB,19,1)
        self.customConvertLayout.addWidget(self.disableAllShadersLable,20,0)
        self.customConvertLayout.addWidget(self.disableAllShadersCB,20,1)
        self.customConvertLayout.addWidget(self.disableRayTracingLable,21,0)
        self.customConvertLayout.addWidget(self.disableRayTracingCB,21,1)
        self.customConvertLayout.addWidget(self.sceneAutoCleanLable,22,0)
        self.customConvertLayout.addWidget(self.sceneAutoCleanCB,22,1)
        self.customConvertLayout.addWidget(self.loadProxyReferenceLable,23,0)
        self.customConvertLayout.addWidget(self.loadProxyReferenceCB,23,1)
        
        self.customConvertLayout.addWidget(self.motionBlurButtons2,24,0,2,2)

        
        #self.renderOptionsLayout.addWidget(self.comboButtons,22,1,QtCore.Qt.AlignRight)
        
        self.customButtonsLayout.addWidget(self.startSetPreset)
        self.customButtonsLayout.addWidget(self.resetRenderTractor)
        self.customButtonsLayout.addWidget(self.playblastRenderTractor)
        self.customButtonsLayout.addWidget(self.startRenderTractor)
        
        

        self.mainWidget=QtGui.QWidget()
        self.mainWidgetLayout=QtGui.QVBoxLayout()
        self.mainWidgetLayout.setContentsMargins(4,4,4,4)
        self.mainWidget.setLayout(self.mainWidgetLayout)

        self.mainWidgetLayout.addWidget(self.mainConvert)
        self.mainWidgetLayout.addWidget(self.customConvert)
        self.mainWidget.setFocusPolicy(QtCore.Qt.NoFocus)
        self.mainScrollArea.setWidget(self.mainWidget)

        self.mainConvertLayout.addWidget(self.mainScrollArea)
        self.mainConvertLayout.addLayout(self.customButtonsLayout)        
        
        self.mainLayout.addLayout(self.mainConvertLayout)
        self.readSettings()
        self.setLayout(self.mainLayout)

    def shadingRateSlot(self):
        if self.shadingRateCB.checkState()==QtCore.Qt.Unchecked:
            self.shadingRateSB.setEnabled(False)
        else:
            self.shadingRateSB.setEnabled(True)

    def ribFormatSlot(self):
        if self.ribFormatCB.checkState()==QtCore.Qt.Unchecked:
            self.ribFormatCombobox.setEnabled(False)
            self.ribFormatCombobox2.setEnabled(False)
        else:
            self.ribFormatCombobox.setEnabled(True)
            self.ribFormatCombobox2.setEnabled(True)

    def lazySlot(self):
        if self.lazyCB.checkState()==QtCore.Qt.Unchecked:
            self.lazyCB1.setEnabled(False)
            self.lazyCB2.setEnabled(False)
            self.lazyLabel.setEnabled(False)
            self.lazyLabel1.setEnabled(False)
        else:
            self.lazyCB1.setEnabled(True)
            self.lazyCB2.setEnabled(True)
            self.lazyLabel.setEnabled(True)
            self.lazyLabel1.setEnabled(True)

    def filterSlot(self):
        if self.filterCB.checkState()==QtCore.Qt.Unchecked:
            self.filter1SB.setEnabled(False)
            self.filter2SB.setEnabled(False)
            self.filterCB.setEnabled(False)
            self.filterCombobox.setEnabled(False)
        else:
            self.filter1SB.setEnabled(True)
            self.filter2SB.setEnabled(True)
            self.filterCB.setEnabled(True)
            self.filterCombobox.setEnabled(True)

    def pixelSamplesSlot(self):
        if self.pixelSampelsLabel.checkState()==QtCore.Qt.Unchecked:
            self.pixelSampelsSB.setEnabled(False)
            self.pixelSampelsSB2.setEnabled(False)
        else:
            self.pixelSampelsSB.setEnabled(True)
            self.pixelSampelsSB2.setEnabled(True)

    def textChangedSlot(self):
        print "textChangedSlot"
        global globaljobBatchContextLE
        globaljobBatchContextLE=self.jobBatchContextLE.text()
        self.ContextChanged.emit()
        
    def reuseShaveRibsLabelEnable(self):
        if self.reuseShaveRibsLabel.checkState()==QtCore.Qt.Unchecked:
            self.reuseShaveRibsCB.setEnabled(False)
            self.reuseShaveRibsL2.setEnabled(False)
        else:
            self.reuseShaveRibsCB.setEnabled(True)
            self.reuseShaveRibsL2.setEnabled(True)


    def shaveWriteRibSlot(self, daIliNet):
        print daIliNet
        if not mel.eval("attributeExists(\"shaveWriteRib\", \"perspShape\")"):
            cmds.addAttr("perspShape",at="bool",ln="shaveWriteRib")
        if not mel.eval("attributeExists(\"buildIfNotExists\", \"perspShape\")"):
            cmds.addAttr("perspShape",at="bool",ln="buildIfNotExists")
            cmds.setAttr("perspShape.buildIfNotExists",1)
            
    def selectCamerasLabelEnable(self):
        if self.selectCamerasLabel.checkState()==QtCore.Qt.Unchecked:
            self.selectCamerasL2.setEnabled(False)
            self.startMainCamera.setEnabled(False)
            self.startStereoCameras.setEnabled(False)            
        else:
            self.selectCamerasL2.setEnabled(True)
            self.startMainCamera.setEnabled(True)
            self.startStereoCameras.setEnabled(True)


    def customDisplayLableEnable(self):
        if self.customDisplayLable.checkState()==QtCore.Qt.Unchecked:
            self.customDisplayL2.setEnabled(False)
            self.customDisplayLE.setEnabled(False)
            self.customDisplayL3.setEnabled(False)
            self.customDisplayLE2.setEnabled(False)
        else:
            self.customDisplayL2.setEnabled(True)
            self.customDisplayLE.setEnabled(True)
            self.customDisplayL3.setEnabled(True)
            self.customDisplayLE2.setEnabled(True)


    def reuseShadowMapsLabelEnable(self):
        if self.reuseShadowMapsLabel.checkState()==QtCore.Qt.Unchecked:
            self.reuseShadowMapsCombobox.setEnabled(False)
            self.reuseShadowMapsL2.setEnabled(False)
        else:
            self.reuseShadowMapsCombobox.setEnabled(True)
            self.reuseShadowMapsL2.setEnabled(True)
            
    def reuseSSEnable(self):
        if self.reuseSSLabel.checkState()==QtCore.Qt.Unchecked:
            self.reuseSSCombobox.setEnabled(False)
            self.reuseSSL2.setEnabled(False)
        else:
            self.reuseSSCombobox.setEnabled(True)
            self.reuseSSL2.setEnabled(True)

    def statisticOutputLableEnable(self):
        if self.statisticOutputLable.checkState()==QtCore.Qt.Unchecked:
            self.statisticOutputL2.setEnabled(False)
            self.statisticOutputLE.setEnabled(False)
        else:
            self.statisticOutputL2.setEnabled(True)
            self.statisticOutputLE.setEnabled(True)

    def motionBlurLabelEnable(self):
        if self.motionBlurLabel.checkState()==QtCore.Qt.Unchecked:
            self.motionBlurL2.setEnabled(False)
            self.motionBlurCB.setEnabled(False)
            self.motionBlurL3.setEnabled(False)
            self.motionBlurCB2.setEnabled(False)
            self.shutterAngleLabel.setEnabled(False)
            self.shutterAngleSB.setEnabled(False)
            self.motionBlurTypeLabel.setEnabled(False)
            self.motionBlurTypeCombobox.setEnabled(False)
            self.shutterOpeningSB1.setEnabled(False)
            self.shutterOpeningSB2.setEnabled(False)
            self.shutterTimingLabel.setEnabled(False)
            self.shutterTimingCombobox.setEnabled(False)
            self.shutterOpeningLabel.setEnabled(False)
            self.shutterOpeningLabel2.setEnabled(False)
        else:
            self.motionBlurL2.setEnabled(True)
            self.motionBlurCB.setEnabled(True)
            self.motionBlurL3.setEnabled(True)
            self.motionBlurCB2.setEnabled(True)
            self.shutterAngleLabel.setEnabled(True)
            self.shutterAngleSB.setEnabled(True)
            self.motionBlurTypeLabel.setEnabled(True)
            self.motionBlurTypeCombobox.setEnabled(True)
            self.shutterOpeningSB1.setEnabled(True)
            self.shutterOpeningSB2.setEnabled(True)
            self.shutterTimingLabel.setEnabled(True)
            self.shutterTimingCombobox.setEnabled(True)
            self.shutterOpeningLabel.setEnabled(True)
            self.shutterOpeningLabel2.setEnabled(True)





    def dofLabelEnable(self):
        if self.dofLabel.checkState()==QtCore.Qt.Unchecked:
            self.dofL2.setEnabled(False)
            self.dofCB.setEnabled(False)
            self.dofL3.setEnabled(False)
            self.dofCB2.setEnabled(False)
            self.dofL4.setEnabled(False)
            self.dofSB3.setEnabled(False)
            self.dofL5.setEnabled(False)
            self.dofSB4.setEnabled(False)
        else:
            self.dofL2.setEnabled(True)
            self.dofCB.setEnabled(True)
            self.dofL3.setEnabled(True)
            self.dofCB2.setEnabled(True)
            self.dofL4.setEnabled(True)
            self.dofSB3.setEnabled(True)
            self.dofL5.setEnabled(True)
            self.dofSB4.setEnabled(True)



    def setPreset(self):
        self.parent().parent().parent().wLB.batchLineEdit.setText(("python(\"import sendToRender; reload(sendToRender); sendToRender.rmanSpoolRemoteRIBRemoteRender(\\\\\\\""+self.jobServerAttrubutesLE.text()+"\\\\\\\",\\\\\\\""+self.framesLE.text()+"\\\\\\\","+str(self.jobPriorityLE.value())+",\\\\\\\""+self.jobBatchContextLE.text()+"\\\\\\\",\\\\\\\""+self.jobCmdTagsLE.text()+"\\\\\\\",\\\\\\\""+self.environmentKeyLE.text()+"\\\\\\\",\\\\\\\""+self.rendererArgumentsLE.text()+"\\\\\\\",\\\\\\\""+self.jobDoneCommandLE.text()+"\\\\\\\",\\\\\\\""+self.jobErrorCommandLE.text()+"\\\\\\\",\\\\\\\""+self.crewsLE.text()+"\\\\\\\",\\\\\\\""+self.extraJobOptionsLE.text()+"\\\\\\\","+str(self.framesPerServerLE.value())+","+str(self.localRB.isChecked())+","+str(self.startPausedCB.isChecked())+","+str(self.cropWondowLE1.value())+","+str(self.cropWondowLE2.value())+","+str(self.cropWondowLE3.value())+","+str(self.cropWondowLE4.value())+","+str(self.rezolutionCombobox.currentIndex())+","+str(self.loadSTCamerasLable.isChecked())+","+str(self.selectCamerasLabel.isChecked())+","+str(self.startMainCamera.isChecked())+","+str(self.startStereoCameras.isChecked())+","+str(self.customDisplayLable.isChecked())+","+str(self.customDisplayLE.isChecked())+","+str(self.customDisplayLE2.isChecked())+","+str(self.reuseShadowMapsLabel.isChecked())+","+str(self.reuseShadowMapsCombobox.currentIndex())+","+str(self.reuseSSLabel.isChecked())+","+str(self.reuseSSCombobox.currentIndex())+","+str(self.reuseShaveRibsLabel.isChecked())+","+str(self.reuseShaveRibsCB.isChecked())+","+str(self.shadingRateScaleLE.value())+","+str(self.directLightSamplesScaleLE.value())+","+str(self.shutterAngleScaleLE.value())+","+str(self.statisticOutputLable.isChecked())+","+str(self.statisticOutputLE.isChecked())+","+str(self.disableAllShaveCB.isChecked())+","+str(self.disableAllLightsCB.isChecked())+","+str(self.disableAllShadersCB.isChecked())+","+str(self.disableRayTracingCB.isChecked())+","+str(self.sceneAutoCleanCB.isChecked())+","+str(self.loadProxyReferenceCB.isChecked())+","+str(self.motionBlurLabel.isChecked())+","+str(self.motionBlurCB.isChecked())+","+str(self.motionBlurCB2.isChecked())+","+str(self.shutterAngleSB.value())+",\\\\\\\""+str(self.motionBlurTypeCombobox.currentText())+"\\\\\\\",\\\\\\\""+str(self.shutterTimingCombobox.currentText())+"\\\\\\\","+str(self.shutterOpeningSB1.value())+","+str(self.shutterOpeningSB2.value())+","+str(self.dofLabel.isChecked())+","+str(self.dofCB.isChecked())+","+str(self.dofCB2.value())+","+str(self.dofSB3.value())+","+str(self.dofSB4.value())+","+str(self.shadingRateCB.isChecked())+","+str(self.shadingRateSB.value())+","+str(self.pixelSampelsLabel.isChecked())+","+str(self.pixelSampelsSB.value())+","+str(self.pixelSampelsSB2.value())+","+str(self.filterCB.isChecked())+","+str(self.filter1SB.value())+","+str(self.filter2SB.value())+",\\\\\\\""+str(self.filterCombobox.currentText())+"\\\\\\\","+str(self.ribFormatCB.isChecked())+",\\\\\\\""+str(self.ribFormatCombobox.currentText())+"\\\\\\\",\\\\\\\""+str(self.ribFormatCombobox2.currentText())+"\\\\\\\","+str(self.lazyCB.isChecked())+","+str(self.lazyCB1.isChecked())+","+str(self.lazyCB2.isChecked())+")\")").replace("$","\\$"))
        


    def resetRenderTractorInterface(self):
        self.localRB.setChecked(False)
        self.tractorRB.setChecked(True)
        self.startPausedCB.setChecked(False)
        self.jobBatchContextLE.setText("$JOBDATETIME")
        self.framesPerServerLE.setValue(5)
        self.jobPriorityLE.setValue(100)
        
        self.jobServerAttrubutesLE.setText("LinuxFarm")
        self.jobCmdTagsLE.setText("")
        self.environmentKeyLE.setText("rms-18.0-maya-2013 prman-18.0")
        self.rendererArgumentsLE.setText("")
        self.jobDoneCommandLE.setText("")
        self.jobErrorCommandLE.setText("")
        self.crewsLE.setText("")
        self.extraJobOptionsLE.setText("")
        self.framesLE.setText("")

        self.cropWondowLE1.setValue(0)
        self.cropWondowLE2.setValue(0)
        self.cropWondowLE3.setValue(0)
        self.cropWondowLE4.setValue(0)

        self.rezolutionCombobox.setCurrentIndex(0)

        self.loadSTCamerasLable.setChecked(False)

        self.selectCamerasLabel.setChecked(False)
        self.startMainCamera.setChecked(True)
        self.startStereoCameras.setChecked(False)
        
        self.customDisplayLable.setChecked(False)
        self.customDisplayLE.setChecked(False)
        self.customDisplayLE2.setChecked(False)

        self.reuseShadowMapsLabel.setChecked(False)
        self.reuseShadowMapsCombobox.setCurrentIndex(0)
        self.reuseSSLabel.setChecked(False)
        self.reuseSSCombobox.setCurrentIndex(0)
        self.reuseShaveRibsLabel.setChecked(False)
        self.reuseShaveRibsCB.setChecked(False)
        self.shadingRateScaleLE.setValue(1)
        self.directLightSamplesScaleLE.setValue(1)
        self.shutterAngleScaleLE.setValue(1)
        self.statisticOutputLable.setChecked(False)
        self.statisticOutputLE.setChecked(False)
   
        
        self.disableAllShaveCB.setChecked(False)
        self.disableAllLightsCB.setChecked(False)
        self.disableAllShadersCB.setChecked(False)
        self.disableRayTracingCB.setChecked(False)
        self.sceneAutoCleanCB.setChecked(False)
        self.loadProxyReferenceCB.setChecked(False)
        self.motionBlurLabel.setChecked(False)
        self.motionBlurCB.setChecked(False)
        self.motionBlurCB2.setChecked(False)
        self.shutterAngleSB.setValue(80)
        self.motionBlurTypeCombobox.setCurrentIndex(1)
        self.shutterTimingCombobox.setCurrentIndex(0)
        self.shutterOpeningSB1.setValue(0.35)
        self.shutterOpeningSB2.setValue(0.65)
        self.dofLabel.setChecked(False)
        self.dofCB.setChecked(False)
        self.dofCB2.setValue(5)
        self.dofSB3.setValue(5.6)
        self.dofSB4.setValue(1)

        self.shadingRateCB.setChecked(False)
        self.shadingRateSB.setValue(1)
        self.pixelSampelsLabel.setChecked(False)
        self.pixelSampelsSB.setValue(3)
        self.pixelSampelsSB2.setValue(3)

        self.filterCB.setChecked(False)
        self.filter1SB.setValue(4)
        self.filter2SB.setValue(4)
        self.filterCombobox.setCurrentIndex(4)

        self.ribFormatCB.setChecked(False)
        self.ribFormatCombobox.setCurrentIndex(0)
        self.ribFormatCombobox2.setCurrentIndex(0)

        self.lazyCB.setChecked(False)
        self.lazyCB1.setChecked(False)
        self.lazyCB2.setChecked(False)
        
    def setRenderTractorInterfaceAnimation(self):
        self.localRB.setChecked(False)
        self.tractorRB.setChecked(True)
        self.startPausedCB.setChecked(False)
        self.jobBatchContextLE.setText("playblast")
        self.framesPerServerLE.setValue(5)
        self.jobPriorityLE.setValue(1400)
        
        self.jobServerAttrubutesLE.setText("")
        self.jobCmdTagsLE.setText("")
        self.environmentKeyLE.setText("rms-18.0-maya-2013 prman-18.0")
        self.rendererArgumentsLE.setText("")
        self.jobDoneCommandLE.setText("")
        self.jobErrorCommandLE.setText("")
        self.crewsLE.setText("")
        self.extraJobOptionsLE.setText("")
        self.framesLE.setText("")

        self.cropWondowLE1.setValue(0)
        self.cropWondowLE2.setValue(0)
        self.cropWondowLE3.setValue(0)
        self.cropWondowLE4.setValue(0)

        self.rezolutionCombobox.setCurrentIndex(0)

        self.loadSTCamerasLable.setChecked(False)

        self.selectCamerasLabel.setChecked(True)
        self.startMainCamera.setChecked(True)
        self.startStereoCameras.setChecked(False)
        
        self.customDisplayLable.setChecked(True)
        self.customDisplayLE.setChecked(False)
        self.customDisplayLE2.setChecked(False)

        self.reuseShadowMapsLabel.setChecked(True)
        self.reuseShadowMapsCombobox.setCurrentIndex(2)
        self.reuseSSLabel.setChecked(True)
        self.reuseSSCombobox.setCurrentIndex(2)
        self.reuseShaveRibsLabel.setChecked(False)
        self.reuseShaveRibsCB.setChecked(False)
        self.shadingRateScaleLE.setValue(1)
        self.directLightSamplesScaleLE.setValue(1)
        self.shutterAngleScaleLE.setValue(1)
        self.statisticOutputLable.setChecked(False)
        self.statisticOutputLE.setChecked(False)
   
        
        self.disableAllShaveCB.setChecked(True)
        self.disableAllLightsCB.setChecked(True)
        self.disableAllShadersCB.setChecked(False)
        self.disableRayTracingCB.setChecked(True)
        self.sceneAutoCleanCB.setChecked(True)
        self.loadProxyReferenceCB.setChecked(True)
        self.motionBlurLabel.setChecked(True)
        self.motionBlurCB.setChecked(True)
        self.motionBlurCB2.setChecked(True)
        self.shutterAngleSB.setValue(80)
        self.motionBlurTypeCombobox.setCurrentIndex(1)
        self.shutterTimingCombobox.setCurrentIndex(0)
        self.shutterOpeningSB1.setValue(0.35)
        self.shutterOpeningSB2.setValue(0.65)
        self.dofLabel.setChecked(False)
        self.dofCB.setChecked(False)
        self.dofCB2.setValue(5)
        self.dofSB3.setValue(5.6)
        self.dofSB4.setValue(1)

        self.shadingRateCB.setChecked(True)
        self.shadingRateSB.setValue(1)
        self.pixelSampelsLabel.setChecked(True)
        self.pixelSampelsSB.setValue(9)
        self.pixelSampelsSB2.setValue(9)

        self.filterCB.setChecked(False)
        self.filter1SB.setValue(4)
        self.filter2SB.setValue(4)
        self.filterCombobox.setCurrentIndex(4)

        self.ribFormatCB.setChecked(False)
        self.ribFormatCombobox.setCurrentIndex(0)
        self.ribFormatCombobox2.setCurrentIndex(0)

        self.lazyCB.setChecked(False)
        self.lazyCB1.setChecked(False)
        self.lazyCB2.setChecked(False)

    def rmanSpoolRemoteRIBRemoteRenderSlot(self):
        if self.framesPerServerLE.value() == 0:
            self.framesPerServerLE.setValue(5)
        reload(sendToRender)
        sendToRender.rmanSpoolRemoteRIBRemoteRender(self.jobServerAttrubutesLE.text(),self.framesLE.text(),self.jobPriorityLE.value(),self.jobBatchContextLE.text(),self.jobCmdTagsLE.text(),self.environmentKeyLE.text(),self.rendererArgumentsLE.text(),self.jobDoneCommandLE.text(),self.jobErrorCommandLE.text(),self.crewsLE.text(),self.extraJobOptionsLE.text(),self.framesPerServerLE.value(),self.localRB.isChecked(),self.startPausedCB.isChecked(),self.cropWondowLE1.value(),self.cropWondowLE2.value(),self.cropWondowLE3.value(),self.cropWondowLE4.value(),self.rezolutionCombobox.currentIndex(),self.loadSTCamerasLable.isChecked(),self.selectCamerasLabel.isChecked(),self.startMainCamera.isChecked(),self.startStereoCameras.isChecked(),self.customDisplayLable.isChecked(),self.customDisplayLE.isChecked(),self.customDisplayLE2.isChecked(),self.reuseShadowMapsLabel.isChecked(),self.reuseShadowMapsCombobox.currentIndex(),self.reuseSSLabel.isChecked(),self.reuseSSCombobox.currentIndex(),self.reuseShaveRibsLabel.isChecked(),self.reuseShaveRibsCB.isChecked(),self.shadingRateScaleLE.value(),self.directLightSamplesScaleLE.value(),self.shutterAngleScaleLE.value(),self.statisticOutputLable.isChecked(),self.statisticOutputLE.isChecked(),self.disableAllShaveCB.isChecked(),self.disableAllLightsCB.isChecked(),self.disableAllShadersCB.isChecked(),self.disableRayTracingCB.isChecked(),self.sceneAutoCleanCB.isChecked(),self.loadProxyReferenceCB.isChecked(),self.motionBlurLabel.isChecked(),self.motionBlurCB.isChecked(),self.motionBlurCB2.isChecked(),self.shutterAngleSB.value(),self.motionBlurTypeCombobox.currentText(),self.shutterTimingCombobox.currentText(),self.shutterOpeningSB1.value(),self.shutterOpeningSB2.value(),self.dofLabel.isChecked(),self.dofCB.isChecked(),self.dofCB2.value(),self.dofSB3.value(),self.dofSB4.value(),self.shadingRateCB.isChecked(),self.shadingRateSB.value(),self.pixelSampelsLabel.isChecked(),self.pixelSampelsSB.value(),self.pixelSampelsSB2.value(),self.filterCB.isChecked(),self.filter1SB.value(),self.filter2SB.value(),self.filterCombobox.currentText(),self.ribFormatCB.isChecked(),self.ribFormatCombobox.currentText(),self.ribFormatCombobox2.currentText(),self.lazyCB.isChecked(),self.lazyCB1.isChecked(),self.lazyCB2.isChecked())






    def readSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("sendToTractor")
        if settings.value("localOrTractor", False).toBool():
            self.localRB.setChecked(True)
            self.tractorRB.setChecked(False)
        else:
            self.localRB.setChecked(False)
            self.tractorRB.setChecked(True)
        
                       
        self.jobPriorityLE.setValue(settings.value("jobPriorityLE", 100).toInt()[0])
        self.jobServerAttrubutesLE.setText(settings.value("jobServerAttrubutesLE", "LinuxFarm").toString())
        self.environmentKeyLE.setText(settings.value("environmentKeyLE", "rms-18.0-maya-2013 prman-18.0").toString())
        
        self.jobBatchContextLE.setText(settings.value("jobBatchContextLE", "$JOBDATETIME").toString())
        global globaljobBatchContextLE
        globaljobBatchContextLE=str(settings.value("jobBatchContextLE", "$JOBDATETIME").toString())
        
        self.framesPerServerLE.setValue(settings.value("framesPerServerLE", 5).toInt()[0])
        self.framesLE.setText(settings.value("framesLE", "").toString())
        self.jobCmdTagsLE.setText(settings.value("jobCmdTagsLE", "").toString())
        self.rendererArgumentsLE.setText(settings.value("rendererArgumentsLE", "").toString())
        self.jobDoneCommandLE.setText(settings.value("jobDoneCommandLE", "").toString())
        self.jobErrorCommandLE.setText(settings.value("jobErrorCommandLE", "").toString())
        self.crewsLE.setText(settings.value("crewsLE", "").toString())    
        self.extraJobOptionsLE.setText(settings.value("extraJobOptionsLE", "").toString())
        
        chekStat = settings.value("startPausedCB", "0").toInt()
        if chekStat[0] == 0: self.startPausedCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.startPausedCB.setCheckState(QtCore.Qt.Checked)
        
        self.cropWondowLE1.setValue(settings.value("cropWondowLE1", 0).toDouble()[0])
        self.cropWondowLE2.setValue(settings.value("cropWondowLE2", 0).toDouble()[0])
        self.cropWondowLE3.setValue(settings.value("cropWondowLE3", 0).toDouble()[0])
        self.cropWondowLE4.setValue(settings.value("cropWondowLE4", 0).toDouble()[0])
        self.rezolutionCombobox.setCurrentIndex(settings.value("rezolutionCombobox", 0).toInt()[0])
        self.shadingRateScaleLE.setValue(settings.value("shadingRateScaleLE", 1).toDouble()[0])
        self.directLightSamplesScaleLE.setValue(settings.value("directLightSamplesScaleLE", 1).toDouble()[0])
        self.shutterAngleScaleLE.setValue(settings.value("shutterAngleScaleLE", 1).toDouble()[0])
        
        chekStat = settings.value("startMainCamera", "1").toInt()
        if chekStat[0] == 0: self.startMainCamera.setCheckState(QtCore.Qt.Unchecked)
        else: self.startMainCamera.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("startStereoCameras", "0").toInt()
        if chekStat[0] == 0: self.startStereoCameras.setCheckState(QtCore.Qt.Unchecked)
        else: self.startStereoCameras.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("customDisplayLable", "0").toInt()
        if chekStat[0] == 0: self.customDisplayLable.setCheckState(QtCore.Qt.Unchecked)
        else: self.customDisplayLable.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("customDisplayLE", "0").toInt()
        if chekStat[0] == 0: self.customDisplayLE.setCheckState(QtCore.Qt.Unchecked)
        else: self.customDisplayLE.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("customDisplayLE2", "0").toInt()
        if chekStat[0] == 0: self.customDisplayLE2.setCheckState(QtCore.Qt.Unchecked)
        else: self.customDisplayLE2.setCheckState(QtCore.Qt.Checked)

        self.reuseShadowMapsCombobox.setCurrentIndex(settings.value("reuseShadowMapsCombobox", 0).toInt()[0])

        self.reuseSSCombobox.setCurrentIndex(settings.value("reuseSSCombobox", 0).toInt()[0])
        
        chekStat = settings.value("reuseShaveRibsCB", "1").toInt()
        if chekStat[0] == 0: self.reuseShaveRibsCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.reuseShaveRibsCB.setCheckState(QtCore.Qt.Checked)        
        
        chekStat = settings.value("statisticOutputLE", "0").toInt()
        if chekStat[0] == 0: self.statisticOutputLE.setCheckState(QtCore.Qt.Unchecked)
        else: self.statisticOutputLE.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("loadSTCamerasLable", "0").toInt()
        if chekStat[0] == 0: self.loadSTCamerasLable.setCheckState(QtCore.Qt.Unchecked)
        else: self.loadSTCamerasLable.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("selectCamerasLabel", "0").toInt()
        if chekStat[0] == 0: self.selectCamerasLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.selectCamerasLabel.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("reuseShadowMapsLabel", "0").toInt()
        if chekStat[0] == 0: self.reuseShadowMapsLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.reuseShadowMapsLabel.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("reuseSSLabel", "0").toInt()
        if chekStat[0] == 0: self.reuseSSLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.reuseSSLabel.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("reuseShaveRibsLabel", "0").toInt()
        if chekStat[0] == 0: self.reuseShaveRibsLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.reuseShaveRibsLabel.setCheckState(QtCore.Qt.Checked)
                
        chekStat = settings.value("statisticOutputLable", "0").toInt()
        if chekStat[0] == 0: self.statisticOutputLable.setCheckState(QtCore.Qt.Unchecked)
        else: self.statisticOutputLable.setCheckState(QtCore.Qt.Checked)
                



        chekStat = settings.value("disableAllShaveCB", "0").toInt()
        if chekStat[0] == 0: self.disableAllShaveCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.disableAllShaveCB.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("disableAllLightsCB", "0").toInt()
        if chekStat[0] == 0: self.disableAllLightsCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.disableAllLightsCB.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("disableAllShadersCB", "0").toInt()
        if chekStat[0] == 0: self.disableAllShadersCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.disableAllShadersCB.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("disableRayTracingCB", "0").toInt()
        if chekStat[0] == 0: self.disableRayTracingCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.disableRayTracingCB.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("sceneAutoCleanCB", "0").toInt()
        if chekStat[0] == 0: self.sceneAutoCleanCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.sceneAutoCleanCB.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("loadProxyReferenceCB", "0").toInt()
        if chekStat[0] == 0: self.loadProxyReferenceCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.loadProxyReferenceCB.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("motionBlurLabel", "0").toInt()
        if chekStat[0] == 0: self.motionBlurLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.motionBlurLabel.setCheckState(QtCore.Qt.Checked)
        
        chekStat = settings.value("motionBlurCB", "0").toInt()
        if chekStat[0] == 0: self.motionBlurCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.motionBlurCB.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("motionBlurCB2", "0").toInt()
        if chekStat[0] == 0: self.motionBlurCB2.setCheckState(QtCore.Qt.Unchecked)
        else: self.motionBlurCB2.setCheckState(QtCore.Qt.Checked)
    
        self.shutterAngleSB.setValue(settings.value("shutterAngleSB", 80).toInt()[0])

        self.motionBlurTypeCombobox.setCurrentIndex(settings.value("motionBlurTypeCombobox", 1).toInt()[0])

        self.shutterTimingCombobox.setCurrentIndex(settings.value("shutterTimingCombobox", 0).toInt()[0])

        self.shutterOpeningSB1.setValue(settings.value("shutterOpeningSB1", 0.35).toDouble()[0])
        self.shutterOpeningSB2.setValue(settings.value("shutterOpeningSB2", 0.65).toDouble()[0])

        chekStat = settings.value("dofLabel", "0").toInt()
        if chekStat[0] == 0: self.dofLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.dofLabel.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("dofCB", "0").toInt()
        if chekStat[0] == 0: self.dofCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.dofCB.setCheckState(QtCore.Qt.Checked)

        self.dofCB2.setValue(settings.value("dofCB2", 5).toDouble()[0])
        self.dofSB3.setValue(settings.value("dofSB3", 5.6).toDouble()[0])
        self.dofSB4.setValue(settings.value("dofSB4", 1).toDouble()[0])



        chekStat = settings.value("shadingRateCB", "0").toInt()
        if chekStat[0] == 0: self.shadingRateCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.shadingRateCB.setCheckState(QtCore.Qt.Checked)

        chekStat = settings.value("pixelSampelsLabel", "0").toInt()
        if chekStat[0] == 0: self.pixelSampelsLabel.setCheckState(QtCore.Qt.Unchecked)
        else: self.pixelSampelsLabel.setCheckState(QtCore.Qt.Checked)

        self.shadingRateSB.setValue(settings.value("shadingRateSB", 1).toDouble()[0])
        self.pixelSampelsSB.setValue(settings.value("pixelSampelsSB", 3).toInt()[0])
        self.pixelSampelsSB2.setValue(settings.value("pixelSampelsSB2", 3).toInt()[0])

        chekStat = settings.value("filterCB", "0").toInt()
        if chekStat[0] == 0: self.filterCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.filterCB.setCheckState(QtCore.Qt.Checked)

        self.filter1SB.setValue(settings.value("filter1SB", 4).toInt()[0])
        self.filter2SB.setValue(settings.value("filter2SB", 4).toInt()[0])

        self.filterCombobox.setCurrentIndex(settings.value("filterCombobox", 4).toInt()[0])

        chekStat = settings.value("ribFormatCB", "0").toInt()
        if chekStat[0] == 0: self.ribFormatCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.ribFormatCB.setCheckState(QtCore.Qt.Checked)

        self.ribFormatCombobox.setCurrentIndex(settings.value("ribFormatCombobox", 0).toInt()[0])
        self.ribFormatCombobox2.setCurrentIndex(settings.value("ribFormatCombobox2", 0).toInt()[0])

        chekStat = settings.value("lazyCB", "0").toInt()
        if chekStat[0] == 0: self.lazyCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.lazyCB.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("lazyCB1", "0").toInt()
        if chekStat[0] == 0: self.lazyCB1.setCheckState(QtCore.Qt.Unchecked)
        else: self.lazyCB1.setCheckState(QtCore.Qt.Checked)
        chekStat = settings.value("lazyCB2", "0").toInt()
        if chekStat[0] == 0: self.lazyCB2.setCheckState(QtCore.Qt.Unchecked)
        else: self.lazyCB2.setCheckState(QtCore.Qt.Checked)

        settings.endGroup()            
    
    def writeSettings(self):
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("sendToTractor")
        settings.setValue("localOrTractor", self.localRB.isChecked())
        settings.setValue("jobPriorityLE", self.jobPriorityLE.value())
        settings.setValue("jobServerAttrubutesLE", self.jobServerAttrubutesLE.text())
        settings.setValue("environmentKeyLE", self.environmentKeyLE.text())                
        
        settings.setValue("jobBatchContextLE", self.jobBatchContextLE.text())
        settings.setValue("framesPerServerLE", self.framesPerServerLE.value())                
        settings.setValue("framesLE", self.framesLE.text())                
        settings.setValue("jobCmdTagsLE", self.jobCmdTagsLE.text())                
        settings.setValue("rendererArgumentsLE", self.rendererArgumentsLE.text())                
        settings.setValue("jobDoneCommandLE", self.jobDoneCommandLE.text())                
        settings.setValue("jobErrorCommandLE", self.jobErrorCommandLE.text())                
        settings.setValue("crewsLE", self.crewsLE.text())                
        settings.setValue("extraJobOptionsLE", self.extraJobOptionsLE.text())                
        
        chekStat = 0
        if self.startPausedCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("startPausedCB", chekStat)        
        
        settings.setValue("cropWondowLE1", self.cropWondowLE1.value())                        
        settings.setValue("cropWondowLE2", self.cropWondowLE2.value())                
        settings.setValue("cropWondowLE3", self.cropWondowLE3.value())                
        settings.setValue("cropWondowLE4", self.cropWondowLE4.value())                
        settings.setValue("rezolutionCombobox", self.rezolutionCombobox.currentIndex())                
        settings.setValue("shadingRateScaleLE", self.shadingRateScaleLE.value())                                                        
        settings.setValue("directLightSamplesScaleLE", self.directLightSamplesScaleLE.value())                
        settings.setValue("shutterAngleScaleLE", self.shutterAngleScaleLE.value())                                

        chekStat = 0
        if self.startMainCamera.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("startMainCamera", chekStat)        

        chekStat = 0
        if self.startStereoCameras.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("startStereoCameras", chekStat)        

        chekStat = 0
        if self.customDisplayLable.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("customDisplayLable", chekStat)        

        chekStat = 0
        if self.customDisplayLE.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("customDisplayLE", chekStat)        

        chekStat = 0
        if self.customDisplayLE2.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("customDisplayLE2", chekStat)        

        settings.setValue("reuseShadowMapsCombobox", self.reuseShadowMapsCombobox.currentIndex())                

        settings.setValue("reuseSSCombobox", self.reuseSSCombobox.currentIndex())                

        chekStat = 0
        if self.reuseShaveRibsCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("reuseShaveRibsCB", chekStat)        
                
        chekStat = 0
        if self.statisticOutputLE.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("statisticOutputLE", chekStat)        


        chekStat = 0
        if self.loadSTCamerasLable.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("loadSTCamerasLable", chekStat)        

        chekStat = 0
        if self.selectCamerasLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("selectCamerasLabel", chekStat)        

        chekStat = 0
        if self.reuseShadowMapsLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("reuseShadowMapsLabel", chekStat)        

        chekStat = 0
        if self.reuseSSLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("reuseSSLabel", chekStat)        

        chekStat = 0
        if self.reuseShaveRibsLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("reuseShaveRibsLabel", chekStat)        
        
        chekStat = 0
        if self.statisticOutputLable.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("statisticOutputLable", chekStat)        
        
       





        chekStat = 0
        if self.disableAllShaveCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("disableAllShaveCB", chekStat)        
        
        chekStat = 0
        if self.disableAllLightsCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("disableAllLightsCB", chekStat)        
        
        chekStat = 0
        if self.disableAllShadersCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("disableAllShadersCB", chekStat)        
        
        chekStat = 0
        if self.disableRayTracingCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("disableRayTracingCB", chekStat)        
        
        chekStat = 0
        if self.sceneAutoCleanCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("sceneAutoCleanCB", chekStat)        
        
        chekStat = 0
        if self.loadProxyReferenceCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("loadProxyReferenceCB", chekStat)        

        chekStat = 0
        if self.motionBlurLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("motionBlurLabel", chekStat)        
        
        chekStat = 0
        if self.motionBlurCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("motionBlurCB", chekStat)        
        
        chekStat = 0
        if self.motionBlurCB2.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("motionBlurCB2", chekStat)        
        
        settings.setValue("shutterAngleSB", self.shutterAngleSB.value())                        

        settings.setValue("motionBlurTypeCombobox", self.motionBlurTypeCombobox.currentIndex())                
        settings.setValue("shutterTimingCombobox", self.shutterTimingCombobox.currentIndex())                

        settings.setValue("shutterOpeningSB1", self.shutterOpeningSB1.value())                        
        settings.setValue("shutterOpeningSB2", self.shutterOpeningSB2.value())                        

        chekStat = 0
        if self.dofLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("dofLabel", chekStat)        
        
        chekStat = 0
        if self.dofCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("dofCB", chekStat)        
        
        settings.setValue("dofCB2", self.dofCB2.value())                        
        settings.setValue("dofSB3", self.dofSB3.value())                        
        settings.setValue("dofSB4", self.dofSB4.value())                        

                                        
        chekStat = 0
        if self.shadingRateCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("shadingRateCB", chekStat)        
        
        chekStat = 0
        if self.pixelSampelsLabel.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("pixelSampelsLabel", chekStat)        
        
        settings.setValue("shadingRateSB", self.shadingRateSB.value())                        
        settings.setValue("pixelSampelsSB", self.pixelSampelsSB.value())                        
        settings.setValue("pixelSampelsSB2", self.pixelSampelsSB2.value())                        

        chekStat = 0
        if self.filterCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("filterCB", chekStat)        

        settings.setValue("filter1SB", self.filter1SB.value())                        
        settings.setValue("filter2SB", self.filter2SB.value())                        

        self.filterCombobox.setCurrentIndex(settings.value("filterCombobox", 4).toInt()[0])

        chekStat = 0
        if self.ribFormatCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("ribFormatCB", chekStat)        

        self.ribFormatCombobox.setCurrentIndex(settings.value("ribFormatCombobox", 0).toInt()[0])
        self.ribFormatCombobox2.setCurrentIndex(settings.value("ribFormatCombobox2", 0).toInt()[0])

        chekStat = 0
        if self.lazyCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("lazyCB", chekStat)        
        chekStat = 0
        if self.lazyCB1.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("lazyCB1", chekStat)        
        chekStat = 0
        if self.lazyCB2.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("lazyCB2", chekStat)        

        settings.endGroup()              
     
        
            
class lightGroupsWidget(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(lightGroupsWidget, self).__init__(parent)
  
        self.mainLayout = QtGui.QVBoxLayout()
        
        self.groupBoxSpotConvert = QtGui.QGroupBox(" Spot Convert: ")
        self.spotLayout = QtGui.QHBoxLayout()
        self.convertSpin = QtGui.QSpinBox()
        self.convertSpin.setRange(0,10000)
        self.convertSpin.setValue(50)
        self.convertCombobox = QtGui.QComboBox()
        self.convertComboboxList = QtCore.QStringList()
        self.convertComboboxList.append("128")
        self.convertComboboxList.append("256")        
        self.convertComboboxList.append("512")
        self.convertComboboxList.append("1024")        
        self.convertComboboxList.append("2048")
        self.convertComboboxList.append("4096")        
        self.convertComboboxList.append("8192")
        self.convertComboboxList.append("16384")      
        self.convertCombobox.addItems(self.convertComboboxList)
        self.convertCombobox.setCurrentIndex(2)                
        self.convertButton = QtGui.QPushButton("Convert")
        self.convertButton.released.connect(self.convertSpot)
        self.spotLayout.addWidget(self.convertSpin)
        self.spotLayout.addWidget(self.convertCombobox)
        self.spotLayout.addWidget(self.convertButton)        
        self.groupBoxSpotConvert.setLayout(self.spotLayout)
        
        
        self.groupBoxLightGroups = QtGui.QGroupBox(" Light Groups: ")
        self.oneLayout = QtGui.QHBoxLayout()
        self.numGroupsSpin = QtGui.QSpinBox()
        self.numGroupsSpin.setRange(0,10000)
        self.setButton = QtGui.QPushButton("Set")
        self.setButton.released.connect(self.setLightGroups)
        self.deleteButton = QtGui.QPushButton("Delete")
        self.deleteButton.released.connect(self.deleteLightGroups)
        self.oneLayout.addWidget(self.numGroupsSpin)
        self.oneLayout.addWidget(self.setButton)
        self.oneLayout.addWidget(self.deleteButton)
        self.groupBoxLightGroups.setLayout(self.oneLayout)

        self.groupBoxSetLights = QtGui.QGroupBox(" Set Lights: ")
        
        self.lightsButton = QtGui.QPushButton("None")
        self.lightsButton.released.connect(self.setLight)        
        self.selectButton = QtGui.QPushButton("select")
        self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)        
        self.selectButton.setProperty("ssss","None")        
        self.selectButton.released.connect(self.selectLight)                
        self.LayoutButtons = QtGui.QHBoxLayout()
        self.LayoutButtons.addWidget(self.lightsButton)
        self.LayoutButtons.addWidget(self.selectButton)
        
                            
        self.LayoutSetLights = QtGui.QVBoxLayout()
        self.LayoutSetLights.addLayout(self.LayoutButtons)
        
        
        self.groupBoxSetLights.setLayout(self.LayoutSetLights)
        
        #get exsists buttons
        #rfm.passes.Update()
        Finals = rfm.passes.GetPasses("Final")
        arrayButtomNames=[]    
        if Finals != []:
            for i in Finals[0].GetChannelList():    
                m=re.search(".*use_(?P<set>lightset.*)",i.GetName())
                if m is not None:
                    arrayButtomNames.append(m.group("set"))
        
            for i in arrayButtomNames:
                    self.lightsButton = QtGui.QPushButton(i)
                    self.lightsButton.released.connect(self.setLight)
                    self.selectButton = QtGui.QPushButton("select")
                    self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                        
                    self.selectButton.setProperty("ssss",i)
                    self.selectButton.released.connect(self.selectLight)                
                    self.LayoutButtons = QtGui.QHBoxLayout()
                    self.LayoutButtons.addWidget(self.lightsButton)
                    self.LayoutButtons.addWidget(self.selectButton)
                    self.LayoutSetLights.addLayout(self.LayoutButtons)
        
        
        self.mainLayout.addWidget(self.groupBoxSpotConvert)        
        self.mainLayout.addWidget(self.groupBoxLightGroups)
        self.mainLayout.addWidget(self.groupBoxSetLights)        
        self.mainLayout.addWidget(self.groupBoxSetLights)        
        self.mainLayout.insertStretch(100)
        
        self.setLayout(self.mainLayout)
      


    def getTargetIntensityByDistance(distance, intensity, decayRate):
        if decayRate == 0:
            return intensity
        elif decayRate == 1:
            return (intensity/distance)
        elif decayRate == 2:
            return (intensity/(distance**2))  
        elif decayRate == 3:
            return (intensity/(distance**3))
            
    def getBaseIntensityByTargetIntensity(saveDistance, intensity):
            #print saveDistance
            #print intensity
            return math.log(intensity*(saveDistance**2), 2)
          
    def convertSpot(self):
        convertSpotToRMS(self.convertSpin.value(),self.convertCombobox.currentText()+" "+self.convertCombobox.currentText())
        


    def convertSpotToRMS(dist,resolution):
        lights = cmds.ls(sl=True, dag=True, type='transform')
        lights = [lights[i] for i in range(0, len(lights)) if cmds.ls(lights[i], dag=True, leaf=True, type='spotLight')]
        if lights:
            for i in range(0, len(lights)):
                #get old attributes
                light = lights[i]
                intensity = cmds.getAttr(light + '.intensity')
                decayRate = cmds.getAttr(light + '.decayRate')
                #coneAngle = cmds.getAttr(light + '.coneAngle')
                #penumbraAngle = cmds.getAttr(light + '.penumbraAngle')
                #dropoff = cmds.getAttr(light + '.dropoff')
                emitDiffuse = cmds.getAttr(light + '.emitDiffuse')
                emitSpecular = cmds.getAttr(light + '.emitSpecular')
                lightColor = cmds.getAttr(light + '.color')[0];
                shadowColor = cmds.getAttr(light + '.shadowColor')[0]
                shadowUsed = cmds.getAttr(light + '.useDepthMapShadows')
                targetIntensity = self.getTargetIntensityByDistance(dist, intensity, decayRate)
                #create new lights
                rmsLight=cmds.shadingNode("RMSGeoAreaLight",asLight=True)
                rmsLight=cmds.rename(rmsLight,light+"_GEO")
                rmsLight=cmds.parent(rmsLight,light)[0]
    
                cmds.setAttr(rmsLight+".tx",0)
                cmds.setAttr(rmsLight+".ty",0)
                cmds.setAttr(rmsLight+".tz",0)
                cmds.setAttr(rmsLight+".rx",0)
                cmds.setAttr(rmsLight+".ry",0)
                cmds.setAttr(rmsLight+".rz",0)
                cmds.setAttr(rmsLight+".sx",1)
                cmds.setAttr(rmsLight+".sy",1)
                cmds.setAttr(rmsLight+".sz",1)
                kudaParent="|".join(cmds.ls(light,l=True)[0].split("|")[:-1])
                if kudaParent!="":
                    rmsLight=cmds.parent(rmsLight,kudaParent)[0]
                else:                
                    rmsLight=cmds.parent(rmsLight,world=True)[0]
                rmsLightShape = cmds.ls(rmsLight, dag=True, type='RMSGeoAreaLight')[0]
                #cmds.setAttr((rmsLightShape + '.shape'), 'spot', type='string')
                #cmds.setAttr(rmsLightShape + '.coneangle', coneAngle)
                #cmds.setAttr(rmsLightShape + '.distributionAngle', coneAngle)
                #cmds.setAttr(rmsLightShape + '.penumbraangle', penumbraAngle)
                cmds.setAttr(rmsLightShape + '.areaNormalize', 1)
                #cmds.setAttr(rmsLightShape + '.penumbraexponent', dropoff)
                cmds.setAttr(rmsLightShape + '.temperature', -1)
                cmds.setAttr(rmsLightShape + '.lightcolor', lightColor[0], lightColor[1], lightColor[2], type='double3')
                cmds.setAttr(rmsLightShape + '.diffAmount', emitDiffuse, emitDiffuse, emitDiffuse, type='double3')
                cmds.setAttr(rmsLightShape + '.specAmount', emitSpecular, emitSpecular, emitSpecular, type='double3')
                cmds.setAttr(rmsLightShape + '.shadowColor', shadowColor[0], shadowColor[1], shadowColor[2], type='double3')
                cmds.setAttr(rmsLightShape + '.intensity', self.getBaseIntensityByTargetIntensity(dist, targetIntensity))
                if shadowUsed == 1:
                    cmds.setAttr(rmsLightShape + '.traceShadows', 0)
                    areaShadowPass=""
                    rfm.passes.Update()
                    shadowsPasses = rfm.passes.GetPasses("AreaShadow")
                    for i in shadowsPasses:
                        if i.GetID() == "AreaShadoW"+light:
                            areaShadowPass=i
                    if areaShadowPass == "":
                        areaShadowPass = rfm.passes.CreatePass("AreaShadow")
                        areaShadowPass.Rename(light+"_AreaShadoW")
    
                    areaShadowPass.SetAttr("rman__riopt__Format_resolution", resolution)                    
                    shadowPass = areaShadowPass.GetID()
    
                    cameraShadow = cmds.camera(hfa=1.4, vfa=1.4, n=(light+"_SHADOW"))[0]
                    cameraShadow=cmds.parent(cameraShadow, rmsLight)[0]
                    cmds.setAttr(cameraShadow+'.translate', 0, 0, 0)
                    cmds.setAttr(cameraShadow+'.rotate', 0, 0, 0)
                    cmds.connectAttr(cmds.ls(cameraShadow, dag=True, type='camera')[0]+'.message', shadowPass+'.rman__torattr___camera', f=True)
                    cmds.connectAttr(shadowPass+'.message', rmsLightShape+'.shadowname', f=True)
                    cmds.setAttr(cameraShadow+".visibility", 0)
                else:
                    cmds.setAttr(rmsLightShape + '.traceShadows', 0)
                cmds.setAttr(light+".visibility", 0)
    
                cmds.select(rmsLight)
    
        else:
            cmds.warning("Vydelite StopLight")


        
    def setLightGroups(self):
            #install                            
            self.deleteLightGroups()
            for i in range(0, self.numGroupsSpin.value()):
                if i == 0:
                    self.lightsButton = QtGui.QPushButton("lightset")
                    self.lightsButton.released.connect(self.setLight)
                    self.selectButton = QtGui.QPushButton("select")
                    self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                            
                    self.selectButton.setProperty("ssss","lightset")
                    self.selectButton.released.connect(self.selectLight)                
                    self.LayoutButtons = QtGui.QHBoxLayout()
                    self.LayoutButtons.addWidget(self.lightsButton)
                    self.LayoutButtons.addWidget(self.selectButton)
                else:                
                    self.lightsButton = QtGui.QPushButton("lightset"+str(i))            
                    self.lightsButton.released.connect(self.setLight)                    
                    self.selectButton = QtGui.QPushButton("select")
                    self.selectButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)                            
                    self.selectButton.setProperty("ssss","lightset"+str(i))                    
                    self.selectButton.released.connect(self.selectLight)                
                    self.LayoutButtons = QtGui.QHBoxLayout()
                    self.LayoutButtons.addWidget(self.lightsButton)
                    self.LayoutButtons.addWidget(self.selectButton)
                    
                self.LayoutSetLights.addLayout(self.LayoutButtons)
                
            rfm.passes.Update()
            Finals = rfm.passes.GetPasses("Final")
            spinNUM=self.numGroupsSpin.value()

            SECONDARY_OUTPUTS = []
            
            for i in range(0,spinNUM):
                num = str(i)
                if num == "0":
                    num=""
                SECONDARY_OUTPUTS.append("color GroupedDiffuse_lightset"+num)
                SECONDARY_OUTPUTS.append("color GroupedSpecular_lightset"+num)
                Finals[0].AddChannel("color GroupedDiffuse_lightset"+num)
                Finals[0].AddChannel("color GroupedSpecular_lightset"+num)
                
            SECONDARY_OUTPUTS.append("float a")


            if SECONDARY_OUTPUTS != []:
                display = Finals[0].AddDisplay(SECONDARY_OUTPUTS)
                display.SetDspyID("LightGroups")    
                cmds.setAttr("renderManGlobals.rman__torattr___defaultRiOptionsScript", "RiOption \"user\" \"int lightGroupsNum\" "+str(spinNUM)+";",type="string")
                display.SetAttr("rman__riopt__Display_type","openexr")  
                display.SetAttr("rman__riopt__Display_quantize","0 0 0 0")    
                display.SetAttr("rman__riopt__Display_dither","0")    
                display.AddAttr("rman__riopt__Display_exrcompression")
                display.SetAttr("rman__riopt__Display_exrcompression","zip")
                display.AddAttr("rman__riopt__Display_exrpixeltype")
                display.SetAttr("rman__riopt__Display_exrpixeltype","half")
                display.AddAttr("rman__riopt__Display_autocrop")
                display.SetAttr("rman__riopt__Display_autocrop","true")
                display.AddAttr("rman__riopt__Display_filter")
                display.SetAttr("rman__riopt__Display_filter","gaussian")
                display.AddAttr("rman__riopt__Display_filterwidth")
                display.SetAttr("rman__riopt__Display_filterwidth0",2)
                display.SetAttr("rman__riopt__Display_filterwidth1",2)
                #display.Update()
                #Finals[0].Update()
                #rfm.passes.Update()
                #PassManager=rfm.passes.GetPassManager()
                #PassManager.Update()                


    def deleteLightGroups(self):
            #remove
            '''for i in reversed(range(self.LayoutSetLights.count())): 
                if i > 0:
                    child = self.LayoutSetLights.takeAt(i)
                    child.widget().deleteLater()
            '''
            while self.LayoutSetLights.count() > 1:
                d=self.LayoutSetLights.takeAt(1)
                while d.count():
                    ds=d.takeAt(0)
                    ds.widget().deleteLater()
                d.deleteLater()                    
                    
            rfm.passes.Update()
            Finals = rfm.passes.GetPasses("Final")
            for i in Finals[0].GetDisplayList():
                if i.GetLabel() == "LightGroups":
                    Finals[0].DeleteDisplay(i)
                
            for i in Finals[0].GetChannelList():    
                m=re.match("(GroupedDiffuse.*)|(GroupedSpecular.*)",i.GetName())
                if m is not None:
                    Finals[0].DeleteChannel(i)
     
            cmds.setAttr("renderManGlobals.rman__torattr___defaultRiOptionsScript", "",type="string")       
            #Finals[0].Update()
            #rfm.passes.Update()
            #PassManager=rfm.passes.GetPassManager()
            #PassManager.Update()


    def setLight(self):
        sender = self.sender()
        nameLightGroup=sender.text()
        #print(nameLightGroup)
        
        if nameLightGroup == "None":
            nameLightGroup=""
        for i in cmds.ls(sl=True,dag=True,s=True):
            #print(i)
            if cmds.nodeType(i) == "RMSGeoAreaLight" or cmds.nodeType(i) == "RMSEnvLight":
                cmds.setAttr(i+".__group",nameLightGroup,type="string")


    def selectLight(self):
        sender = self.sender()
        nameLightGroup=sender.property("ssss").toString()
        if nameLightGroup == "None":
            nameLightGroup=""
            
        cmds.select(clear=True)
        for i in cmds.ls(type=["RMSGeoAreaLight","RMSEnvLight"]):
                if cmds.getAttr(i+".__group") == nameLightGroup:
                    cmds.select("|".join(cmds.ls(i,l=True)[0].split("|")[:-1]),add=True)
                    










def pathConvert(path):
    if OSTYPE == "//Server-3d/Project":
        if path.capitalize()[:18] == "/Server-3d/Project":
            path = "//Server-3d/Project" + path[18:]
    else:
        if path.capitalize()[:19] == "//server-3d/project":
            path = "/Server-3d/Project" + path[19:]
    return path


class SpinBoxDelegate(QtGui.QItemDelegate):
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        return QtCore.QSize(100,20)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        col = QtGui.QColor(index.model().data(index,QtCore.Qt.BackgroundColorRole))
        if col.name() == "#000000":
            col = option.palette.window().color()
        gradient.setColorAt(0.05, option.palette.base().color())
        gradient.setColorAt(0.051, col)
        gradient.setColorAt(0.95, col)
        gradient.setColorAt(0.951, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)
        text = index.model().data(index,QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+2,option.rect.width(),option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft,text)
        
        users = index.model().data(index,QtCore.Qt.UserRole+4).toString()
        if users == "-1":
            brush = QtGui.QBrush(QtGui.QColor(10,170,10))
            painter.setPen(QtCore.Qt.NoPen)
            painter.setBrush(brush)
            painter.drawEllipse(option.rect.x()+option.rect.width()-0.375*option.rect.height(),option.rect.y()+0.375*option.rect.height(),0.25*option.rect.height(),0.25*option.rect.height());
        elif users != "":
            painter.drawText( option.rect.x(),option.rect.y()+2,option.rect.width()-5,option.rect.height(),QtCore.Qt.AlignTop|QtCore.Qt.AlignRight,users)
            
            
                
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();


class listDelegate(QtGui.QItemDelegate):
    def __init__(self, parent=None):
        super(listDelegate, self).__init__(parent)
        self.mult = 1
                            
    def createEditor(self, parent, option, index):
        editor = QtGui.QSpinBox(parent)
        editor.setMinimum(0)
        editor.setMaximum(100)

        return editor

    def setEditorData(self, spinBox, index):
        value = index.model().data(index, QtCore.Qt.EditRole)

        spinBox.setValue(value)

    def setModelData(self, spinBox, model, index):
        spinBox.interpretText()
        value = spinBox.value()

        model.setData(index, value, QtCore.Qt.EditRole)

    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)

    def sizeHint(self, option, index):
        '''
        #print "resize"
        #print(str(option.rect.width())+"  "+str(option.rect.height()))
        myFont = QtGui.QFont("Tahoma")
        myFont.setPixelSize(11)
        myFontMetrics = QtGui.QFontMetrics(myFont)
        mySize = myFontMetrics.boundingRect(0,0, 260, 0,(QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), index.data(QtCore.Qt.DisplayRole).toString())
        #print(index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize))        
        return QtCore.QSize(mySize.width(),mySize.height()+40)
        '''
        return QtCore.QSize(100,20)
        
        #mySize = myFontMetrics.boundingRect(option.rect,QtCore.Qt.TextExpandTabs|QtCore.Qt.TextWordWrap,index.data(QtCore.Qt.DisplayRole).toString(),10)
        #mySize = myFontMetrics.size(QtCore.Qt.TextExpandTabs, index.data(QtCore.Qt.DisplayRole).toString())
        #print(str(mySize.width())+"  "+str(mySize.height()+50))        
        #return QtCore.QSize(mySize.width(),mySize.height()+50)
        #return index.data(QtCore.Qt.UserRole+5).toSize()*self.mult

    def paint(self, painter, option, index):
        #print painter.font().pixelSize() 
        #print "paint"
        #self.sizeHint(option, index)
        #self.emmit.sizeHintChanged(index)
        painter.save()
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        newMetr = QtGui.QFontMetrics(painter.font())
        heit = newMetr.height()+2

            
        gradient = QtGui.QLinearGradient(option.rect.x()+option.rect.width()/2, option.rect.y(), option.rect.x()+option.rect.width()/2, option.rect.y()+option.rect.height())
        gradient.setColorAt(0.01, option.palette.base().color())
        gradient.setColorAt(0.02, option.palette.window().color())
        gradient.setColorAt(0.98,option.palette.window().color())
        gradient.setColorAt(0.99, option.palette.base().color())
        brush = QtGui.QBrush(gradient)
        painter.fillRect(option.rect,brush)

   
    
        painter.setCompositionMode(QtGui.QPainter.CompositionMode_SourceOver)
        
        #ccc = QtGui.QFont(painter.font())
        #ccc.setBold(True)
        #painter.setFont(ccc)

        colr = QtGui.QBrush(option.palette.highlight())        
        painter.setBrush(colr)
        text = index.data(QtCore.Qt.DisplayRole).toString()
        painter.drawText( option.rect.x()+5,option.rect.y()+5,option.rect.width(),option.rect.height(), (QtCore.Qt.TextWordWrap|QtCore.Qt.AlignTop|QtCore.Qt.AlignLeft), text)

        painter.setPen(QtCore.Qt.black)
        painter.drawLine(option.rect.x(),option.rect.y(),option.rect.x()+option.rect.width(),option.rect.y())
        
        if option.state & QtGui.QStyle.State_Selected:
            colr = QtGui.QBrush(option.palette.highlight())
            ccc = QtGui.QColor(colr.color())
            ccc.setAlphaF(.2)
            colr.setColor(ccc)
            painter.fillRect(option.rect, colr)
        painter.restore();


class WindowListBatch(QtGui.QWidget):
    def __init__(self, parent=getMayaWindow()):
        super(WindowListBatch, self).__init__(parent)
        #widget = QtGui.QDialog()

        self.conn = mb.connect(host="192.168.0.7",user="root",passwd="12345",port=3306,db = "mel", use_unicode=True)
        self.conn.set_character_set("utf8")
        self.cursor = self.conn.cursor()
        self.parentAssetId="-1"
        self.bigAssetName=""
        self.bigAssetPath=""
        self.indType=""        
        self.GlobalRootPath=""
        self.lastSelectedAssetPath=-1
        self.scriptString  = ""
        self.jobListTask = []                
        
        OSTYPE = sys.platform
        if OSTYPE == "win32":
            self.mayaExecPath="\"C:/Program Files/Autodesk/Maya2013/bin/mayabatch\""
        else:
            self.mayaExecPath="/usr/autodesk/maya2013-x64/bin/maya"
            
            
        self.oneLabel = QtGui.QLabel("Project: ")
        self.oneLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.cursor.execute("select id, name from projects")
        row = self.cursor.fetchall()
        self.conn.commit()
        self.oneCombobox = QtGui.QComboBox()
        self.qlistNames = QtCore.QStringList()
        self.qlistIds = QtCore.QStringList()
        for r in row:
            self.qlistNames.append(r[1])
        self.oneCombobox.addItems(self.qlistNames)
        
        n=0
        for r in row:
            self.oneCombobox.setItemData(n,r[0])
            n=n+1
        #print self.oneCombobox.count()

        self.selectedAssetPath = ""
        self.selectedAssetName = ""
        self.selectedAssetType = ""
        self.rezChild=""
        self.rezParent=""

        self.fourLabel = QtGui.QLabel("Type: ")
        self.fourLabel.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.fourCombobox = QtGui.QComboBox()
        self.fourQlistNames = QtCore.QStringList()
        self.fourQlistNames.append("All")
        self.fourQlistNames.append("chars")        
        self.fourQlistNames.append("props")        
        self.fourQlistNames.append("sets")
        self.fourQlistNames.append("scenes")

       
        self.fourCombobox.addItems(self.fourQlistNames)

        self.twoLabel = QtGui.QLabel("Name: ")
        self.twoLineEdit = QtGui.QLineEdit()
        self.twoLineEdit.setText("%")        
        self.twoLineEdit.returnPressed.connect(self.findText)
        self.twoPushButton = QtGui.QPushButton("Find")
        self.twoPushButton.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.twoPushButton.released.connect(self.findText)

        
        self.process = QtCore.QProcess()
        self.process.finished.connect(self.finishedSlot)
        #self.process.readyReadStandardError.connect(self.readyReadStandardErrorSlot)
        #self.process.readyReadStandardOutput.connect(self.readyReadStandardOutputSlot)
        self.process.error.connect(self.errorSlot)
        self.process.stateChanged.connect(self.stateChangedSlot)
        self.process.readyRead.connect(self.processReadyReadSlot)        
        self.process.setProcessChannelMode(QtCore.QProcess.MergedChannels);
        self.processArglist=QtCore.QStringList()
        self.processArglist.append("-batch")
        self.processArglist.append("-proj")
        self.processArglist.append("")
        self.processArglist.append("-command")
        self.processArglist.append("")
        self.processArglist.append("-file")
        self.processArglist.append("")

        
       
        self.treeView = QtGui.QTreeView()
        self.treeView.connect(self.treeView, QtCore.SIGNAL("expanded(const QModelIndex &)"), self.activeTreeCellExpanded)
        self.treeView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = SpinBoxDelegate()
        self.treeView.setItemDelegate(self.delegate)
        self.treeView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.treeView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        self.treeModel = QtGui.QStandardItemModel()
        self.treeView.setModel(self.treeModel)
        self.treeView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.treeView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.treeView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.treeView.setHeaderHidden(True)


        self.listView = QtGui.QTreeView()
        self.listView.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.delegate = listDelegate()
        self.listView.setItemDelegate(self.delegate)
        self.listView.setIndentation(0)
        self.listView.setSelectionMode(QtGui.QTreeView.ExtendedSelection)
        self.listView.setHorizontalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)
        self.listView.setVerticalScrollMode(QtGui.QAbstractItemView.ScrollPerPixel)

        
        self.listModel = QtGui.QStandardItemModel()
        self.listView.setModel(self.listModel)
        self.listView.setSelectionBehavior(QtGui.QTreeView.SelectRows)
        self.listView.setFocusPolicy(QtCore.Qt.NoFocus)
        self.listView.setHeaderHidden(True)
        self.listView.setMinimumWidth(300)

        

        self.addFrom = QtGui.QLabel("Add From:")
        self.okButt = QtGui.QPushButton("Add from list")
        self.okButt.released.connect(self.addListFile)
        self.okButt1 = QtGui.QPushButton("Outliner")
        self.okButt1.released.connect(self.addOutliner)
        self.okButt2 = QtGui.QPushButton("Ref Editor")
        self.okButt2.released.connect(self.addReferenceEditor)
        self.okButt4 = QtGui.QPushButton("Cur Scene")
        self.okButt4.released.connect(self.addCurrentScene)
        self.okButt3 = QtGui.QPushButton("Rem Selected")
        self.okButt3.released.connect(self.removeSelected)
        
        #self.addFrom2 = QtGui.QLabel("Remove From:")
        #self.reButt = QtGui.QPushButton("Remove from list")
        #self.reButt.released.connect(self.saveFile)
        #self.reButt1 = QtGui.QPushButton("Outliner")
        #self.reButt1.released.connect(self.saveFile)
        #self.reButt2 = QtGui.QPushButton("Reference Editor")
        #self.reButt2.released.connect(self.saveFile)


        self.batchLineEdit = QtGui.QLineEdit()
        self.batchButtStart = QtGui.QPushButton("Start")
        self.batchButtStart.released.connect(self.batchButtStartSlot)        
        self.batchButtStart.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)
        self.batchButtCan = QtGui.QPushButton("Stop")
        self.batchButtCan.setSizePolicy(QtGui.QSizePolicy.Maximum,QtGui.QSizePolicy.Maximum)        
        self.batchButtCan.released.connect(self.batchButtCanSlot)        
        self.batchTextEdit = QtGui.QTextEdit("")
        #self.batchTextEdit.setSizePolicy(QtGui.QSizePolicy.Minimum,QtGui.QSizePolicy.Minimum)
        self.presetsLabel = QtGui.QLabel("Presets: ")
        self.makeProxyBut = QtGui.QPushButton("Make Proxy")
        self.makeProxyBut.released.connect(self.setForProxy)
        self.makeCheckBut = QtGui.QPushButton("Check props")
        self.makeCheckBut.released.connect(self.setForCheckProps)
        self.makeRenderBut = QtGui.QPushButton("Check Render")
        self.makeRenderBut.released.connect(self.setForRender)


        self.localRB = QtGui.QRadioButton("local")
        self.localRB.toggled.connect(self.setLocalTractor)
        self.tractorRB = QtGui.QRadioButton("tractor")

        self.startPausedLable=QtGui.QLabel("Start paused: ")
        self.startPausedCB=QtGui.QCheckBox()
        self.jobPriorityLable=QtGui.QLabel("Job Priority: ")
        self.jobPriorityLE=QtGui.QSpinBox()
        self.jobPriorityLE.setRange(0,1000000)
        self.intValidator=QtGui.QIntValidator()

        
        self.jobServerAttrubutesLable=QtGui.QLabel("Job Server Attributes: ")
        self.jobServerAttrubutesLE=QtGui.QLineEdit()
        self.environmentKeyLable=QtGui.QLabel("Environment Key: ")
        self.environmentKeyLE=QtGui.QLineEdit()


        self.mainLayout = QtGui.QVBoxLayout()
        self.splitter = QtGui.QSplitter(self)
        self.splitter.setFrameStyle(QtGui.QFrame.NoFrame or QtGui.QFrame.Sunken)
        self.splitter.setOrientation(QtCore.Qt.Vertical)
        self.groupBoxFind = QtGui.QGroupBox(" Set Files ")
        self.LayoutFindMain = QtGui.QVBoxLayout()        
        self.twoLayout = QtGui.QHBoxLayout()
        self.LayoutFind = QtGui.QHBoxLayout()
        self.qwsa = QtGui.QWidget()
        self.qwsaLayout = QtGui.QVBoxLayout(self.qwsa)
        self.HBLayout = QtGui.QVBoxLayout()                                
        self.HBLayoutButton2 = QtGui.QHBoxLayout()

        self.batchTractor = QtGui.QWidget()
        self.batchTractorLayout = QtGui.QVBoxLayout(self.batchTractor)
       
        self.splitter2 = QtGui.QSplitter(self)
        self.splitter2.setFrameStyle(QtGui.QFrame.NoFrame or QtGui.QFrame.Sunken)
        self.splitter2.setOrientation(QtCore.Qt.Vertical)
        self.groupBoxSendToBatch = QtGui.QGroupBox(" Batch work")
        self.sendToBatchLayout = QtGui.QVBoxLayout()        
        self.sendToBatchlocalTractor = QtGui.QHBoxLayout()                        
        self.sendToBatchStringLayout = QtGui.QHBoxLayout()
        self.sendToBatchPresetsLayout = QtGui.QHBoxLayout()        
        self.stretchLayout = QtGui.QVBoxLayout()

        self.tractorLayoutWidget = QtGui.QWidget()
        self.tractorLayout = QtGui.QGridLayout(self.tractorLayoutWidget)
          

        
                
        self.LayoutFindMain.setContentsMargins(5,5,5,5)
        self.sendToBatchLayout.setContentsMargins(5,5,5,5)
        
        self.mainLayout.addWidget(self.splitter2)
        self.splitter.addWidget(self.groupBoxFind)
        self.splitter.addWidget(self.qwsa)
        self.splitter2.addWidget(self.splitter)        
        self.splitter2.addWidget(self.groupBoxSendToBatch)

        self.LayoutFindMain.addLayout(self.LayoutFind)
        self.LayoutFindMain.addLayout(self.twoLayout)        
        self.LayoutFindMain.addWidget(self.treeView)    


        self.LayoutFind.addWidget(self.oneLabel)
        self.LayoutFind.addWidget(self.oneCombobox)
        self.LayoutFind.insertStretch(10)        
        self.LayoutFind.addWidget(self.fourLabel)
        self.LayoutFind.addWidget(self.fourCombobox)
        
        self.twoLayout.addWidget(self.twoLabel)
        self.twoLayout.addWidget(self.twoLineEdit)                        
        self.twoLayout.addWidget(self.twoPushButton)                        
        self.twoLayout.addWidget(self.okButt)                        

        self.tractorLayout.addWidget(self.startPausedLable,0,0)
        self.tractorLayout.addWidget(self.startPausedCB,0,1)                
        self.tractorLayout.addWidget(self.jobPriorityLable,0,2)
        self.tractorLayout.addWidget(self.jobPriorityLE,0,3)                        
        self.tractorLayout.addWidget(self.jobServerAttrubutesLable,1,0)
        self.tractorLayout.addWidget(self.jobServerAttrubutesLE,1,1)                
        self.tractorLayout.addWidget(self.environmentKeyLable,1,2)
        self.tractorLayout.addWidget(self.environmentKeyLE,1,3)                        
        self.tractorLayout.setRowStretch(2,100)
        self.tractorLayout.setContentsMargins(0,0,0,0)
                                
        self.qwsaLayout.addWidget(self.listView)
  
        self.qwsaLayout.addLayout(self.HBLayoutButton2)          
        self.HBLayoutButton2.addWidget(self.addFrom)        
        self.HBLayoutButton2.addWidget(self.okButt1)
        self.HBLayoutButton2.addWidget(self.okButt2)
        self.HBLayoutButton2.addWidget(self.okButt4)
        self.HBLayoutButton2.insertStretch(10)
        self.HBLayoutButton2.addWidget(self.okButt3)

        self.groupBoxFind.setLayout(self.LayoutFindMain)
        self.groupBoxSendToBatch.setLayout(self.sendToBatchLayout)
        self.sendToBatchLayout.addLayout(self.sendToBatchStringLayout)
        self.sendToBatchLayout.addLayout(self.sendToBatchPresetsLayout)
        self.sendToBatchLayout.addLayout(self.sendToBatchlocalTractor)        
        self.sendToBatchLayout.addWidget(self.batchTextEdit)
        self.sendToBatchLayout.addWidget(self.tractorLayoutWidget)

        self.sendToBatchlocalTractor.addWidget(self.localRB)
        self.sendToBatchlocalTractor.addWidget(self.tractorRB)
        self.sendToBatchStringLayout.addWidget(self.batchLineEdit,12)
        self.sendToBatchStringLayout.addWidget(self.batchButtStart)
        self.sendToBatchStringLayout.addWidget(self.batchButtCan)
        self.sendToBatchPresetsLayout.addWidget(self.presetsLabel)
        self.sendToBatchPresetsLayout.addWidget(self.makeProxyBut)
        self.sendToBatchPresetsLayout.addWidget(self.makeCheckBut)
        self.sendToBatchPresetsLayout.addWidget(self.makeRenderBut)
        
        self.mainLayout.setContentsMargins(8,8,8,8)
        self.qwsaLayout.setContentsMargins(3,3,3,3)
        
                
        self.setLayout(self.mainLayout)
        self.resize(350, 550)
        self.localRB.setChecked(True)        
        self.readSettings()
        #if self.initVariables() != 1:
        #    self.findText()
        self.findText()

    def setLocalTractor(self,a):
        self.batchTextEdit.setVisible(a)
        self.tractorLayoutWidget.setVisible(not a)
        self.batchButtCan.setVisible(a)

        
    def finishedSlot(self,d,v):
        self.batchTextEdit.append("<span style='color:#f2dc48;'>finishedSlot("+str(QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toAscii().data())+"): </span>"+str(self.processArglist[6]))
        if len(self.jobListTask):
            currentTesk = str(self.jobListTask.pop())
            self.processArglist[2]=sendToRender.getProjectFromFile(currentTesk)
            self.processArglist[6]=currentTesk
            #self.process.close()
            self.batchTextEdit.append("<span style='color:#f2dc48;'>Starting("+str(QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toAscii().data())+"): </span>\n"+self.mayaExecPath+" "+str(self.processArglist[0])+" "+str(self.processArglist[1])+" "+str(self.processArglist[2])+" "+str(self.processArglist[3])+" "+str(self.processArglist[4])+" "+str(self.processArglist[5])+" "+str(self.processArglist[6]))                    
            self.process.start(self.mayaExecPath,self.processArglist)        

            
    def readyReadStandardErrorSlot(self):
        self.batchTextEdit.append(self.process.readAllStandardError().data().strip())

    
    def readyReadStandardOutputSlot(self):
        self.batchTextEdit.append(self.process.readAllStandardOutput().data().strip())

    def processReadyReadSlot(self):
        '''
        inss=QtCore.QTextStream(self.process)
        inss.setCodec("UTF-8");
        strIn = str(inss.readAll()).strip();
        self.batchTextEdit.append(strIn)
        '''
        self.batchTextEdit.append(self.process.readAll().data().strip())
        
        
    def errorSlot(self):    
        self.batchTextEdit.append("<span style='color:#ee4f53;'>error</span>")

        
    def stateChangedSlot(self,v):
        if QtCore.QProcess.NotRunning == v:
            #self.batchTextEdit.append("<span style='color:#f2dc48;'>stateChanged:NotRunning</span>"+str(self.processArglist[6]))
            pass
        elif QtCore.QProcess.Starting == v:
            #self.batchTextEdit.append("<span style='color:#f2dc48;'>Starting("+str(QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toAscii().data())+"): </span>"+str(self.processArglist[6]))            
            pass
        elif QtCore.QProcess.Running == v:
            #self.batchTextEdit.append("<span style='color:#c96aff;'>stateChanged:Running</span>")
            pass

            
    def batchButtStartSlot(self):
        self.scriptString  = self.batchLineEdit.text()
        #self.scriptString=self.scriptString.replace("\\","\\\\")
        self.jobListTask = []
        itemList = self.listModel.invisibleRootItem()
        for i in range(0,itemList.rowCount()):
            nextItemList = itemList.child(i,0)
            self.jobListTask.append(nextItemList.data(QtCore.Qt.DisplayRole).toString())
       
        if len(self.jobListTask) and self.scriptString != "":
            if self.localRB.isChecked():
                    self.jobListTask.reverse()
                    #self.scriptString="\""+self.scriptString.replace("\"","\\\'")+"\"" 
                    self.processArglist[4]=self.scriptString
                    
                    currentTesk = str(self.jobListTask.pop())
                    self.processArglist[2]=sendToRender.getProjectFromFile(currentTesk)
                    self.processArglist[6]=currentTesk
                    self.batchTextEdit.setHtml("<span style='color:#f2dc48;'>Starting("+str(QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toAscii().data())+"): </span>\n"+self.mayaExecPath+" "+str(self.processArglist[0])+" "+str(self.processArglist[1])+" "+str(self.processArglist[2])+" "+str(self.processArglist[3])+" "+str(self.processArglist[4])+" "+str(self.processArglist[5])+" "+str(self.processArglist[6]))                    
                    self.process.start(self.mayaExecPath,self.processArglist)
            else:
                sendToRender.runFunctionFromSelectFiles(["-batch","-proj","","-command","\"%D(script)\"","-file",""],self.scriptString,self.environmentKeyLE.text(),self.jobPriorityLE.value(),self.jobServerAttrubutesLE.text(),self.jobListTask,self.startPausedCB.isChecked())


    def batchButtCanSlot(self):
        self.jobListTask = []
        self.process.close()
        #self.process.kill()
        self.batchTextEdit.append("<span style='color:#ee4f53;'>stop</span>")

    def setForProxy(self):
        self.batchLineEdit.setText("python(\"import ml_makeProxy; ml_makeProxy.ml_makeProxy()\")")
		
    def setForCheckProps(self):
	self.batchLineEdit.setText("python(\"import ml_slim; ml_slim.ml_setup()\")")
	
    def setForRender(self):
        self.batchLineEdit.setText("python(\"import sendToRender; reload(sendToRender); sendToRender.rmanSpoolRemoteRIBRemoteRender(server=\\\\\\\"\\\\\\\",frames=\\\\\\\"\\\\\\\")\")")	

    def addListFile(self):
        for i in self.treeView.selectionModel().selectedRows(): 
            print(" 1:"+str(i.data(QtCore.Qt.DisplayRole).toString())+"    2:"+str(i.data(QtCore.Qt.UserRole).toString())+"    3:"+str(i.data(QtCore.Qt.UserRole+1).toString())+"    4:"+str(i.data(QtCore.Qt.UserRole+2).toString())+"    5:"+str(i.data(QtCore.Qt.UserRole+3).toString())+"    6:"+str(i.data(QtCore.Qt.UserRole+4).toString()))
            filePathToProcessStr=str(i.data(QtCore.Qt.UserRole+1).toString())
            if str(i.data(QtCore.Qt.UserRole+2).toString()) != "":
                fileNameToProcessStr=str(i.data(QtCore.Qt.DisplayRole).toString().split(".")[0])
                if i.data(QtCore.Qt.UserRole+3).toString() !="":
                    if i.data(QtCore.Qt.UserRole+3).toString() != "5":
                        filePathToProcessStr = filePathToProcessStr+"/"+fileNameToProcessStr+"/maya/"
                    else:
                        filePathToProcessStr = filePathToProcessStr+"/"+fileNameToProcessStr+"/"
                                                       
                    dir = QtCore.QDir(filePathToProcessStr)
                    strList = dir.entryInfoList(QtCore.QDir.Files)
                    for iu in strList:
                        print("file: " + filePathToProcessStr+fileNameToProcessStr)
                        if iu.baseName().toLower() == fileNameToProcessStr.lower():
                            filePathToProcessStr=str(iu.filePath())
                            fileNameToProcessStr=str(iu.baseName())
                            break
    
                elif i.data(QtCore.Qt.UserRole+33).toString() != "":
                    eeeNew = i
                    eeePast = i
                    while eeeNew.row() != -1:
                        eeePast = eeeNew
                        eeeNew = eeeNew.parent()
                    filePathToProcessStr = str(i.data(QtCore.Qt.UserRole+2).toString())
                    fileNameToProcessStr = eeePast.data(QtCore.Qt.DisplayRole).toString() + "_" + fileNameToProcessStr
    
                    dir = QtCore.QDir(filePathToProcessStr)
                    strList = dir.entryInfoList(QtCore.QDir.Files)
                    for iu in strList:
                        if iu.baseName().toLower()==fileNameToProcessStr.toLower():
                            filePathToProcessStr=str(iu.filePath())
                            fileNameToProcessStr=str(iu.baseName())
                            break
                    

                print("filePathToProcessStr: "+filePathToProcessStr)
                self.chekAddFile(filePathToProcessStr)


    def addReferenceEditor(self):
        windowList=cmds.lsUI(windows=True)
        estOknoRefov=0
        for wl in windowList:
            if re.match(".*referenceEditorPanel.*",wl):
                estOknoRefov=1
                break

        listReferencecNode = mel.eval("global string $gReferenceEditorPanel; sceneEditor -q -selectReference $gReferenceEditorPanel;")
        for i in listReferencecNode:
            fileName=cmds.referenceQuery(i,wcn=True,f=True)
            print("fileName reference editor: "+fileName)
            self.chekAddFile(fileName)
            
            
    def addOutliner(self):
        lsPath=cmds.ls(sl=True)
        for i in lsPath:
            fileName=cmds.referenceQuery(i,wcn=True,f=True)
            print("fileName outliner: "+fileName)
            self.chekAddFile(fileName)
        
        
    def addCurrentScene(self):
        fileName=cmds.file(query=True, sn=True)
        self.chekAddFile(fileName)
            
    def chekAddFile(self, fileName):
        print("fileName: "+fileName)
        fi = QtCore.QFileInfo(fileName)
        if fi.isFile():
            doIt = 1            
            itemList = self.listModel.invisibleRootItem()
            for i in range(0,itemList.rowCount()):
                nextItemList = itemList.child(i,0)
                if fileName.lower() == nextItemList.data(QtCore.Qt.DisplayRole).toString().toLower():
                    doIt = 0
                    break
            if doIt:
                item = QtGui.QStandardItem(fileName)
                serifFont=QtGui.QFont()
                serifFont.setBold(True)
                item.setFont(serifFont)
                itemList.appendRow(item)
        

    def removeSelected(self):
        listToFiles=[]
        for i in self.listView.selectionModel().selectedRows():
            listToFiles.append(i.data(QtCore.Qt.DisplayRole).toString())
        
        for i in range(0,len(listToFiles)):
            itemList = self.listModel.invisibleRootItem()
            for ii in range(0,itemList.rowCount()):
                nextItemList = itemList.child(ii,0)                
                if listToFiles[i].toLower() == nextItemList.data(QtCore.Qt.DisplayRole).toString().toLower():
                    self.listModel.takeRow(nextItemList.row())
                    break
        
         
        
    def findNameFile(self):
            sceneNameFile3=cmds.file(query=True, sn=True)        
            str2=sceneNameFile3.split(".")
            str4=str2[0].replace("\\","/").split("/")
            str3=re.split('_v[0-9]{1,4}(?=_|$)', str4[-1],re.I)
            str5=str3[0].split("_")
            rez=str5[0]
            if len(str5)>1:
            	for i in range(1,len(str5)-1):
            		rez = rez + "_" + str5[i]
            	if str4[-2] != str5[-1] and str4[-3] != str5[-1]:
            		rez = rez + "_" + str5[-1]
            return rez            		        
            		

    def initVariables(self):
        strrr=""
        self.mayaSceneName = cmds.file(query=True, sceneName=True)
        #print self.mayaSceneName
        #print self.GlobalRootPath
        m = re.search(str(self.GlobalRootPath)+"(?P<first_name>.*)",self.mayaSceneName,re.I)
        if m is None:
            print "None1"
        else:
            strrr = m.group("first_name")
            strProject=strrr.replace("\\","/").split("/")[0]
            projectIndex = self.qlistNames.indexOf(strProject)
            self.oneCombobox.setCurrentIndex(projectIndex)
            #print strrr
            m = re.search(strProject+"/assets/(?P<first_name>.*)",strrr,re.I)
            if m is None:
                m = re.search(strProject+"/scenes/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None3"
                else:    
                    strrr=m.group("first_name")
                    strTypes=strrr.replace("\\","/").split("/")[0]
                    m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                    if m is None:
                        print "None4"
                    else:
                        strrr=m.group("first_name")
                        strrr=strrr.replace("\\","/").split("/")[0]
                        self.twoLineEdit.setText(strrr)
                        #print strrr
                        self.findText()
                        item = self.treeModel.invisibleRootItem().child(0,0)
                        self.treeView.expand(self.treeModel.indexFromItem(item))
                        return 1
            else:    
                strrr=m.group("first_name")
                strTypes=strrr.replace("\\","/").split("/")[0]
                m = re.search(strTypes+"/(?P<first_name>.*)",strrr,re.I)
                if m is None:
                    print "None2"
                else:
                    strrr=m.group("first_name")
                    strrr=strrr.replace("\\","/").split("/")[0]
                    self.twoLineEdit.setText(strrr)
                    #print strrr
                    self.findText()
                    item = self.treeModel.invisibleRootItem().child(0,0)
                    self.treeView.expand(self.treeModel.indexFromItem(item))
                    return 1


            


    def activeTreeCellExpanded(self, index):
        #print("activeTreeCellExpanded: ")
        typeId = index.data(QtCore.Qt.UserRole+3).toString()
        if index.parent().row() == -1 and typeId!="5":
            #print("expanded: "+index.child(0,0).data().toString())            
            item = self.treeModel.itemFromIndex(index)
            rootPath = item.child(0,0).data(QtCore.Qt.DisplayRole).toString()+"/"+index.data().toString()+"/maya"
            #print("rootPath: "+rootPath)            
            dir = QtCore.QDir(rootPath)
            myStr="*.ma,*.mb"
            filters= myStr.split(",")
            dir.setNameFilters(filters)
            strList = dir.entryList()
            #item.removeRow(0)
            for i in range(0,len(strList)):
                child = QtGui.QStandardItem(strList[i])
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+1)
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+2)                
                item.setChild(i,child)
            dir.setPath(rootPath+"/work/anm")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("anm")
                childItem.setData(rootPath+"/work/anm",QtCore.Qt.UserRole+2)
                childItem.setData("3",QtCore.Qt.UserRole+33)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/anm/"+strList[i],QtCore.Qt.UserRole+1)
                    child.setData(rootPath+"/work/anm/"+strList[i],QtCore.Qt.UserRole+2)
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/work/dyn")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("dyn")
                childItem.setData(rootPath+"/work/dyn",QtCore.Qt.UserRole+2)                
                childItem.setData("3",QtCore.Qt.UserRole+33)
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/dyn/"+strList[i],QtCore.Qt.UserRole+1)                    
                    child.setData(rootPath+"/work/dyn/"+strList[i],QtCore.Qt.UserRole+2)                                        
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/work/map")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("map")
                childItem.setData(rootPath+"/work/map",QtCore.Qt.UserRole+2)
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/map/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/work/map/"+strList[i],QtCore.Qt.UserRole+2)                                                 
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/fur")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("fur")
                childItem.setData(rootPath+"/work/fur",QtCore.Qt.UserRole+2)
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/fur/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/work/fur/"+strList[i],QtCore.Qt.UserRole+2)                                                 
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/shd")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("shd")
                childItem.setData(rootPath+"/work/shd",QtCore.Qt.UserRole+2)                                
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/shd/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/shd/"+strList[i],QtCore.Qt.UserRole+2)                                                                                
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/light")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("light")
                childItem.setData(rootPath+"/work/light",QtCore.Qt.UserRole+2)                                
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/light/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/light/"+strList[i],QtCore.Qt.UserRole+2)                                                                                
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
            dir.setPath(rootPath+"/work/tex")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("tex")
                childItem.setData(rootPath+"/work/tex",QtCore.Qt.UserRole+2)                                
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/work/tex/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/work/tex/"+strList[i],QtCore.Qt.UserRole+2)                                                                                
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)               
            dir.setPath(rootPath+"/work/mod")
            strListRig = dir.entryList()
            dir.setPath(rootPath+"/work/mod/geo")
            strListHed = dir.entryList()
            dir.setPath(rootPath+"/work/mod/shape")
            strListScl = dir.entryList()
            dir.setPath(rootPath+"/work/mod/tpl")
            strListDev = dir.entryList()
            if len(strListRig) is not 0 or len(strListHed) is not 0 or len(strListScl) is not 0:                        
                childItemRig = QtGui.QStandardItem("mod")
                childItemRig.setData(rootPath+"/work/mod",QtCore.Qt.UserRole+2)                                
                childItemRig.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItemRig)
                if len(strListRig) is not 0:
                    for i in range(0,len(strListRig)):                
                        child = QtGui.QStandardItem(strListRig[i])
                        child.setData(rootPath+"/work/mod/"+strListRig[i],QtCore.Qt.UserRole+1)                                                                                                                                                        
                        child.setData(rootPath+"/work/mod/"+strListRig[i],QtCore.Qt.UserRole+2)                                                                                                                                                                                
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                        
                        childItemRig.setChild(i,child)             
                if len(strListHed) is not 0:
                    childItem = QtGui.QStandardItem("geo")
                    childItem.setData(rootPath+"/work/mod/geo",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListHed)):                
                        child = QtGui.QStandardItem(strListHed[i])
                        child.setData(rootPath+"/work/mod/geo/"+strListHed[i],QtCore.Qt.UserRole+1)                                                                                                                                                                                
                        child.setData(rootPath+"/work/mod/geo/"+strListHed[i],QtCore.Qt.UserRole+2)                                                                                                                                                                                                        
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListScl) is not 0:
                    childItem = QtGui.QStandardItem("shape")
                    childItem.setData(rootPath+"/work/mod/shape",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListScl)):                
                        child = QtGui.QStandardItem(strListScl[i])
                        child.setData(rootPath+"/work/mod/shape/"+strListScl[i],QtCore.Qt.UserRole+1)                                            
                        child.setData(rootPath+"/work/mod/shape/"+strListScl[i],QtCore.Qt.UserRole+2)                                                                    
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListDev) is not 0:
                    childItem = QtGui.QStandardItem("tpl")
                    childItem.setData(rootPath+"/work/mod/tpl",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListDev)):                
                        child = QtGui.QStandardItem(strListDev[i])
                        child.setData(rootPath+"/work/mod/tpl/"+strListDev[i],QtCore.Qt.UserRole+1)                                              
                        child.setData(rootPath+"/work/mod/tpl/"+strListDev[i],QtCore.Qt.UserRole+2)                         
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                              
            dir.setPath(rootPath+"/work/rig")
            strListRig = dir.entryList()
            dir.setPath(rootPath+"/work/rig/face")
            strListHed = dir.entryList()
            dir.setPath(rootPath+"/work/rig/sceleton")
            strListScl = dir.entryList()
            dir.setPath(rootPath+"/work/rig/dev")
            strListDev = dir.entryList()
            if len(strListRig) is not 0 or len(strListHed) is not 0 or len(strListScl) is not 0:                        
                childItemRig = QtGui.QStandardItem("rig")
                childItemRig.setData(rootPath+"/work/rig",QtCore.Qt.UserRole+2)                                
                childItemRig.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItemRig)
                if len(strListRig) is not 0:
                    for i in range(0,len(strListRig)):                
                        child = QtGui.QStandardItem(strListRig[i])
                        child.setData(rootPath+"/work/rig/"+strListRig[i],QtCore.Qt.UserRole+1)                                                  
                        child.setData(rootPath+"/work/rig/"+strListRig[i],QtCore.Qt.UserRole+2)                           
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItemRig.setChild(i,child)             
                if len(strListHed) is not 0:
                    childItem = QtGui.QStandardItem("face")
                    childItem.setData(rootPath+"/work/rig/face",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListHed)):                
                        child = QtGui.QStandardItem(strListHed[i])
                        child.setData(rootPath+"/work/rig/face/"+strListHed[i],QtCore.Qt.UserRole+1)                                             
                        child.setData(rootPath+"/work/rig/face/"+strListHed[i],QtCore.Qt.UserRole+2)                                                                     
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListScl) is not 0:
                    childItem = QtGui.QStandardItem("sceleton")
                    childItem.setData(rootPath+"/work/rig/sceleton",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListScl)):                
                        child = QtGui.QStandardItem(strListScl[i])
                        child.setData(rootPath+"/work/rig/sceleton/"+strListScl[i],QtCore.Qt.UserRole+1)                                         
                        child.setData(rootPath+"/work/rig/sceleton/"+strListScl[i],QtCore.Qt.UserRole+2)                                                                 
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                               
                if len(strListDev) is not 0:
                    childItem = QtGui.QStandardItem("dev")
                    childItem.setData(rootPath+"/work/rig/dev",QtCore.Qt.UserRole+2)                                
                    childItem.setData("3",QtCore.Qt.UserRole+33)                    
                    childItemRig.setChild(childItemRig.rowCount(),childItem)
                    for i in range(0,len(strListDev)):                
                        child = QtGui.QStandardItem(strListDev[i])
                        child.setData(rootPath+"/work/rig/dev/"+strListDev[i],QtCore.Qt.UserRole+1)                                              
                        child.setData(rootPath+"/work/rig/dev/"+strListDev[i],QtCore.Qt.UserRole+2)                            
                        child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                                                
                        childItem.setChild(i,child)                            
                        
                           
        elif index.parent().row() == -1 and typeId == "5":            
            item = self.treeModel.itemFromIndex(index)
            rootPath = index.data(QtCore.Qt.UserRole+1).toString()+"/"+index.data().toString()                
            #print("rootPath: "+rootPath)            
            dir = QtCore.QDir(rootPath)
            myStr="*.ma,*.mb"
            filters= myStr.split(",")
            dir.setNameFilters(filters)
            strList = dir.entryList()
            #if item.child(0,0).data(QtCore.Qt.DisplayRole).toString()==item.data(QtCore.Qt.UserRole+1).toString():
            #    item.removeRow(0)
            while item.takeRow(0) != []:
                pass                
            '''for i in range(0,len(strList)):
                child = QtGui.QStandardItem(strList[i])
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+1)
                child.setData(rootPath+"/"+strList[i],QtCore.Qt.UserRole+2)                
                item.setChild(i,child)
                '''
            dir.setPath(rootPath+"/tmplate")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("tmplate")
                childItem.setData(rootPath+"/tmplate",QtCore.Qt.UserRole+2)                                
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/tmplate/"+strList[i],QtCore.Qt.UserRole+1)                                                            
                    child.setData(rootPath+"/tmplate/"+strList[i],QtCore.Qt.UserRole+2)                                                                                
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child) 
            dir.setPath(rootPath+"/anm")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("anm")
                childItem.setData(rootPath+"/anm",QtCore.Qt.UserRole+2)
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/anm/"+strList[i],QtCore.Qt.UserRole+1)
                    child.setData(rootPath+"/anm/"+strList[i],QtCore.Qt.UserRole+2)
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/dyn")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("dyn")
                childItem.setData(rootPath+"/dyn",QtCore.Qt.UserRole+2)                
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/dyn/"+strList[i],QtCore.Qt.UserRole+1)                    
                    child.setData(rootPath+"/dyn/"+strList[i],QtCore.Qt.UserRole+2)                                        
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)
                    childItem.setChild(i,child)
            dir.setPath(rootPath+"/light")
            strList = dir.entryList()
            if len(strList) is not 0:
                childItem = QtGui.QStandardItem("light")
                childItem.setData(rootPath+"/light",QtCore.Qt.UserRole+2)
                childItem.setData("3",QtCore.Qt.UserRole+33)                
                item.setChild(item.rowCount(),childItem)
                for i in range(0,len(strList)):                
                    child = QtGui.QStandardItem(strList[i])
                    child.setData(rootPath+"/light/"+strList[i],QtCore.Qt.UserRole+1)                             
                    child.setData(rootPath+"/light/"+strList[i],QtCore.Qt.UserRole+2)                                                 
                    child.setData(QtGui.QApplication.style().standardPalette().light(),QtCore.Qt.BackgroundColorRole)                    
                    childItem.setChild(i,child)                                        
                                      
            
        
    def findText(self):   
        #twoLineEdit = self.sender()
        fingTextLine = self.twoLineEdit.text()

        rezTESET=""
        for t in str(fingTextLine):
            rezTESET=rezTESET+"["+t.upper()+t.lower()+"]"
            
        self.treeModel.clear()
        parentItem = self.treeModel.invisibleRootItem()        

        REALROOTOFFILES=OSTYPE

        slovarik={}
        if self.fourCombobox.currentText()!="All":
            mun=1
            if self.fourCombobox.currentText()=="props":    
                mun=3
                propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*'+rezTESET+'*')
                for epSc in propsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]            
            elif self.fourCombobox.currentText()=="sets":    
                mun=4
                setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*'+rezTESET+'*')
                for epSc in setsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]
            elif self.fourCombobox.currentText()=="scenes":    
                mun=5
                scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*'+rezTESET+'*')
                for epSc in scenesPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]                
            else:
                charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*'+rezTESET+'*')
                for epSc in charsPath:
                    epSc=epSc.replace("\\","/")
                    temp=epSc.split("/")
                    pppth=pathConvert(epSc)
                    if os.path.isdir(pppth):                    
                        slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
            
            self.cursor.execute("select ar.id, ar.name, ar.path, atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and atypes_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),mun,"%"+fingTextLine+"%",))
        else:
            propsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/props/*' + rezTESET + '*')
            for epSc in propsPath:
                epSc=epSc.replace("\\","/")            
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),3]
            setsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/sets/*' + rezTESET + '*')
            for epSc in setsPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),4]
            scenesPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/scenes/*/*' + rezTESET + '*')
            for epSc in scenesPath:
                epSc=epSc.replace("\\","/")                        
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                                
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),5]
            charsPath = glob.glob(REALROOTOFFILES+'/'+str(self.oneCombobox.currentText())+'/assets/chars/*' + rezTESET + '*')
            for epSc in charsPath:
                epSc=epSc.replace("\\","/")            
                temp=epSc.split("/")
                pppth=pathConvert(epSc)
                if os.path.isdir(pppth):                           
                    slovarik[pppth]=[-1,temp[-1],"/".join(temp[:-1]),1]
            self.cursor.execute("select ar.id, ar.name, ar.path, atypes_id from assets as ar, assets_has_projects as ahp where ar.id=ar.parent and ar.id = ahp.assets_id and ahp.projects_id = %s and ar.name like %s",(self.oneCombobox.itemData(self.oneCombobox.currentIndex()).toString(),"%"+fingTextLine+"%",))
            
        row = self.cursor.fetchall()
        self.conn.commit()
        print("PROJECT: "+str(self.oneCombobox.currentText()))
        print(str(slovarik))
        #if self.fiveCombobox.currentText() == "Network":        
        for x in row:
            if os.path.isdir(pathConvert(str(x[2]+"/"+x[1]))) and pathConvert(str(x[2]+"/"+x[1])) in slovarik.keys():
                slovarik[pathConvert(str(x[2]+"/"+x[1]))]=[x[0],x[1],x[2],x[3]]

        liist=slovarik.values()
        liist=sorted(liist, key=lambda t: t[1].lower())
        #print(str(slovarik))
                
        testString="MAYA::CHEKLIST"
        for x in liist:
            #print(x)
            testString+="::"+x[1]
            item = QtGui.QStandardItem(x[1])
            serifFont=QtGui.QFont()
            serifFont.setBold(True)
            item.setFont(serifFont)
            child = QtGui.QStandardItem(pathConvert(x[2]))
            item.setData(x[1],QtCore.Qt.DisplayRole)
            item.setData(x[0],QtCore.Qt.UserRole)
            item.setData(pathConvert(x[2]),QtCore.Qt.UserRole+1)            
            item.setData(x[1],QtCore.Qt.UserRole+2)            
            item.setData(x[3],QtCore.Qt.UserRole+3)
            item.setData("",QtCore.Qt.UserRole+4)            
            item.setChild(0,child)
            parentItem.appendRow(item)
        melnik_setup.sendMessage(testString)

                
    def readSettings(self):
        print("readSettingssss")
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")        
        self.curProject = settings.value("project", "1").toInt()
        self.oneCombobox.setCurrentIndex(self.curProject[0])    
        self.curType = settings.value("type", "1").toInt()
        self.fourCombobox.setCurrentIndex(self.curType[0])        
        self.splitter.restoreState(settings.value("OpenSplitter").toByteArray())
        self.splitter2.restoreState(settings.value("OpenSplitter2").toByteArray())        

        if settings.value("localOrTractor", True).toBool():
            self.localRB.setChecked(True)
            self.tractorRB.setChecked(False)
        else:
            self.localRB.setChecked(False)
            self.tractorRB.setChecked(True)
        
        
                       
        self.jobPriorityLE.setValue(settings.value("jobPriorityLE", 1500).toInt()[0])
        self.jobServerAttrubutesLE.setText(settings.value("jobServerAttrubutesLE", "").toString())
        #self.environmentKeyLE.setText(settings.value("environmentKeyLE", "maya-2013").toString())
        self.environmentKeyLE.setText("maya2013")
        
        chekStat = settings.value("startPausedCB", "0").toInt()
        if chekStat[0] == 0: self.startPausedCB.setCheckState(QtCore.Qt.Unchecked)
        else: self.startPausedCB.setCheckState(QtCore.Qt.Checked)

        self.twoLineEdit.setText(codecs.encode(settings.value("findString", "%").toString(), 'utf-8'))
        self.batchLineEdit.setText(codecs.encode(settings.value("batchLineEdit", "").toString(), 'utf-8'))
        
        settings.endGroup()            
        settings.beginGroup("Path")
        self.GlobalRootPath = settings.value("GlobalRootPath", OSTYPE+"/").toString()
        settings.endGroup()
    
    def writeSettings(self):
        print("writeSettingssss")
        settings = QtCore.QSettings("Melnitsa Soft", "Yago")
        settings.beginGroup("mayaSaveDialog")
        settings.setValue("project", self.oneCombobox.currentIndex())
        settings.setValue("findString", self.twoLineEdit.text())
        settings.setValue("type", self.fourCombobox.currentIndex())        
        settings.setValue("localOrTractor", self.localRB.isChecked())
        settings.setValue("OpenSplitter", self.splitter.saveState())
        settings.setValue("OpenSplitter2", self.splitter2.saveState())        
        
        settings.setValue("batchLineEdit", self.batchLineEdit.text())
        
        settings.setValue("jobPriorityLE", self.jobPriorityLE.value())
        settings.setValue("jobServerAttrubutesLE", self.jobServerAttrubutesLE.text())
        settings.setValue("environmentKeyLE", self.environmentKeyLE.text())                
        chekStat = 0
        if self.startPausedCB.checkState() == QtCore.Qt.Checked: chekStat = 1
        settings.setValue("startPausedCB", chekStat)        
        
        
        settings.endGroup()              



#mOd = Window()
#mOd.show()
