import maya.cmds as cmds
def convertRibToGeo():

	def getRibCommand( rib_path, bound_b ):
	
		root_dir = ( rib_path.split( '/Project/' )[-1] ).split( '.' )[0] + '/'
		root_proj = ( rib_path.split( '/' )[-1] ).split( '.' )[0] + '.job.rib'
		result = 'RiProcedural DelayedReadArchive "' + rib_path.split( '/Project/' )[-1] + '!' + root_dir + root_proj + '" ' + bound_b + '; RiAttribute "visibility" "int camera" 0 "int diffuse" 0 "int specular" 0 "int transmission" 0;'
		return result
		
	def getMaxBbLenght( obj ):

		bb = { 'min':cmds.getAttr(obj+'.boundingBoxMin')[0], 'max':cmds.getAttr(obj+'.boundingBoxMax')[0] }
		zyx = { 'x':bb['max'][0] - bb['min'][0], 'y':bb['max'][1] - bb['min'][1], 'z':bb['max'][2] - bb['min'][2] }
		key = { zyx['x'] >= zyx['y'] and zyx['x'] >= zyx['z']:'x', zyx['y'] >= zyx['x'] and zyx['y'] >= zyx['z']:'y', zyx['z'] >= zyx['x'] and zyx['z'] >= zyx['y']:'z' }
		return zyx[ key[ True ] ]/2

	ribArchives = cmds.ls( type='RenderManArchive' )
	for i in range( 0, len( ribArchives ) ):
		ribs_tr = cmds.listRelatives( ribArchives[i], parent=True )[0]
		ribs_trChilds = cmds.listRelatives( ribs_tr, children=True )
		if '_x_BBRib' not in str( ribs_trChilds ):
			ribs_zip = cmds.getAttr( ribArchives[i] + '.filename' )
			bound_b = cmds.getAttr( ribArchives[i] + '.boundingBoxMax' )[0] + cmds.getAttr( ribArchives[i] + '.boundingBoxMin' )[0]
			bound_b = [ str( bound_b[n] ) for n in range( 0, len( bound_b )) ]
			bound_b = ' '.join( bound_b )
			ribs_path = getRibCommand( ribs_zip, bound_b )
			bb_tr = cmds.polyCube( width=1, height=1, depth=1, subdivisionsX=1, subdivisionsY=1, subdivisionsZ=1, axis=[ 0, 1, 0 ], constructionHistory=0, name= ( ribs_tr + '_x_BBRib' ) )[0]
			bb_sh = cmds.ls( bb_tr, dag=True, type='mesh' )[0]
			bb_len = getMaxBbLenght( ribs_tr )
			cmds.setAttr( bb_tr + '.s', bb_len, bb_len, bb_len )
			cmds.makeIdentity( bb_tr, apply=True, t=0, r=0, s=1, n=0 )
			cmds.parent( bb_sh, ribs_tr, add=True, shape=True )
			cmds.delete( bb_tr )
			cmds.attributeQuery( 'rman__torattr___preShapeScript', n=bb_sh, exists=True ) is False and cmds.addAttr( bb_sh, longName='rman__torattr___preShapeScript', dataType="string" )
			cmds.setAttr( bb_sh + '.rman__torattr___preShapeScript', ribs_path, type='string' )
			[ cmds.setAttr( ribs_trChilds[n] + '.visibility', 0 ) for n in range( 0, len( ribs_trChilds ) ) ]
			cmds.setAttr( bb_sh + '.visibility', 1 )
		else:
			[ cmds.setAttr( ribs_trChilds[n] + '.visibility', 1 ) for n in range( 0, len( ribs_trChilds )) if '_x_BBRib' not in ribs_trChilds[n] ]
			bboxRib = [ ribs_trChilds[n] for n in range( 0, len( ribs_trChilds )) if '_x_BBRib' in ribs_trChilds[n] ]
			cmds.delete( bboxRib )
