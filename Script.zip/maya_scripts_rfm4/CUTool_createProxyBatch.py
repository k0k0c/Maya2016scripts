import sys
import os
import re
import maya.cmds as cmds
import maya.mel as mel
cmds.loadPlugin('AbcExport')
cmds.loadPlugin('RenderMan_for_Maya')
print 'Initialize proxy creator...'


def scenario():
    '''
    execute script
    '''
    #Get arguments
    arguments = (str('{0}'.format(sys.argv[4]))).split(' ')
    if arguments:
        #path to proxy
        pathToProxy = arguments[0]; print '\npath to new proxy:', pathToProxy
        #optimize geometry
        optimizeGeometry = arguments[4]; print '\nreduce geometry:', optimizeGeometry
        optimizeGeometryValue = arguments[5]; print '\nreduce value:', optimizeGeometryValue 
        #create gpu cache
        gpuCacheUsage = arguments[2]; print '\nexport gpu cache:', gpuCacheUsage
        gpuCacheTreshold = arguments[3]; print '\ngpu cache treshold:', gpuCacheTreshold
        #create controls
        createControlsVar = arguments[1]; print '\ncreate controls:', createControls
        #rib archive
        ribArchivePath = len(arguments) > 6 and arguments[6] or ''
        #open scene
        openScene(path=pathToProxy)
    else:
        return 'Invalid arguments!'
    #optimize
    if 'True' in optimizeGeometry:
        reduceSceneGeometry(reduceValue=int(optimizeGeometryValue)) 
    #gpuCache
    if 'True' in gpuCacheUsage:
        gpuCachePath = '/'.join(pathToProxy.split('/')[0:-1]) + '/' + (pathToProxy.split('/')[-1]).split('.')[0]
        gpuCacheProc(exportCache=True, treshold=gpuCacheTreshold, filePath=gpuCachePath)
        gpuCacheProc(importCache=True, filePath=gpuCachePath)
    #create controls
    if 'True' in createControlsVar:
        createControls()
    if 'False' in createControlsVar:
        objects = cmds.ls(type='transform')
        objects = [objects[i] for i in range(0, len(objects)) if cmds.ls(objects[i], dag=True, leaf=True, type='gpuCache')]
        cmds.rename(objects[0], 'general_CT')
        cmds.group('general_CT', n='root')
    rmanAddArchiveControl(name='root', path=ribArchivePath)
    cmds.delete(all=True, constructionHistory=True); print '\ndelete all history.\n'
    cmds.bakePartialHistory(all=True)
    cmds.file(force=True, save=True); print '\nsave scene.\n'
    print 'End.'
        

def openScene(path=''):
    '''
    path = path to opening file
    '''
    if path != '':
        try:
            cmds.file(path, force=True, open=True)
        except:
            cmds.error('File is corrupted')

def gpuCacheProc(importCache='', exportCache='', treshold=40000, filePath=''):
    '''
    import:
        importCache = if True import cpu cache to scene
        filePath = path to gpu cache
    export:
        exportCache = if True export all meshes to cache
        treshold = vertices treshold
        filePath = path to export gpu cache
    '''
    treshold = str(treshold)
    print 'path to gpu cache', filePath + '.abc'
    #check flags
    if importCache is True and exportCache is True or importCache is False and exportCache is False:
        return 'Please specify one flag import or export!'    
    #import cache    
    if exportCache is True:
        #get objects
        nodes = cmds.ls(type='transform')
        if nodes:
            nodes = [nodes[i] for i in range(0, len(nodes)) if cmds.ls(nodes[i], dag=True, leaf=True, type=('mesh', 'gpuCache'))]
            nodes = cmds.group(nodes, n='root')
            cmds.rename(nodes, 'root')
            mel.eval('gpuCache -optimize -optimizationThreshold '+treshold+' -directory "'+'/'.join(filePath.split('/')[0:-1]) +'/" -fileName "'+filePath.split('/')[-1]  +'" |root;')
            return filePath
    #export cache    
    elif importCache is True:
        cmds.delete(cmds.ls())
        gpuNode = cmds.createNode('gpuCache')
        cmds.setAttr(gpuNode+".cacheFileName", filePath+'.abc', type="string")
        return gpuNode

def reduceSceneGeometry(reduceValue=50, onlyCombine=False):
    '''
    reduceValue = reduce all geometry by this value
    onlyCombine = if True only combine all mesh and clear history
    _____________________________________
    Example:
    reduceSceneGeometry(onlyCombine=True) 
    reduceSceneGeometry(reduceValue=50) 
    '''
    meshes = cmds.ls(type='mesh')
    nonManifold = [meshes[i] for i in range(0, len(meshes)) if cmds.polyInfo(meshes[i], nonManifoldVertices=True)]
    manifold = [meshes[i] for i in range(0, len(meshes)) if not cmds.polyInfo(meshes[i], nonManifoldVertices=True)]
    def getReduceValue(x, y):
        var = [x <= 100, x <= 250 and x > 100, x <= 500 and x > 250, x <= 1000 and x > 500, x <= 1500 and x > 1000, x <= 3000 and x > 1500, x <= 5000 and x > 3000, x <= 10000 and x > 5000, x <= 100000 and x > 10000, x <= 1000000 and x > 100000, x > 1000000]
        result = [10, 15, 30, 45, 50, 65, 70, 85, 90, 95, 100][var.index(True)]
        result = y < result and y or result
        return result
    for i in range(0, len(manifold)):
        try:
            polyCount = cmds.polyEvaluate(manifold[i], triangle=True)
            expectedValue = getReduceValue(polyCount, reduceValue)
            cmds.polyReduce(manifold[i], percentage=expectedValue, uvWeights=0, colorWeights=0, keepQuadsWeight=1, keepBorder=0, keepMapBorder=0, keepOriginalVertices=0, keepHardEdge=0, compactness=0, triangulate=1, replaceOriginal=1, cachingReduce=1, constructionHistory=False)
            cmds.delete(all=True, constructionHistory=True)
        except:
            print 'Mesh is corrupted'
    cmds.delete(all=True, constructionHistory=True)
    return (cmds.ls(type='mesh'))
    
def createControls():
    '''
    create nurbs controls
    '''
    def getBoundingBoxMax(objectName=''):
        '''
        get max bounding box lenght
        objectName = object name
        '''
        bbMin = cmds.getAttr(objectName+'.boundingBoxMin')[0]
        bbMax = cmds.getAttr(objectName+'.boundingBoxMax')[0]
        xLenght = bbMax[0] - bbMin[0]
        yLenght = bbMax[1] - bbMin[1]
        zLenght = bbMax[2] - bbMin[2]
        if xLenght >= yLenght and xLenght >= zLenght:
            return xLenght
        if yLenght >= xLenght and yLenght >= zLenght:
            return yLenght
        if zLenght >= xLenght and zLenght >= yLenght:
            return zLenght       
    #get all transforms
    objects = cmds.ls(dag=True, leaf=True, shapes=True, long=True)
    objects = [objects[i] for i in range(0, len(objects)) if cmds.nodeType(objects[i]) == 'mesh' or cmds.nodeType(objects[i]) == 'gpuCache']
    objects = [cmds.listRelatives(objects[i], parent=True, fullPath=True)[0] for i in range(0, len(objects))]
    objects = cmds.rename(objects[0], 'general_CT')
    #create controls
    curveControl = mel.eval('curve -d 1 -p -0.268644 -0.00173434 -0.465283 -p -0.109172 -0.00173434 -0.465283 -p -0.0605789 0.0138506 -0.442918 -p 0.060579 0.0138506 -0.442918 -p 0.109172 -0.00173434 -0.465283 -p 0.268644 -0.00173434 -0.465283 -p 0.34838 -0.00173434 -0.327176 -p 0.353308 0.0138506 -0.27391 -p 0.413887 0.0138506 -0.168985 -p 0.457553 -0.00173434 -0.138084 -p 0.537288 -0.00173434 2.27005e-005 -p 0.457552 -0.00173434 0.138129 -p 0.413887 0.0138506 0.16903 -p 0.353308 0.0138506 0.273956 -p 0.34838 -0.00173434 0.327221 -p 0.268644 -0.00173434 0.465328 -p 0.109172 -0.00173434 0.465328 -p 0.0605789 0.0138506 0.442963 -p -0.0605789 0.0138506 0.442963 -p -0.109172 -0.00173434 0.465328 -p -0.268644 -0.00173434 0.465328 -p -0.34838 -0.00173434 0.327221 -p -0.353308 0.0138506 0.273956 -p -0.413887 0.0138506 0.16903 -p -0.457552 -0.00173434 0.138129 -p -0.537288 -0.00173434 2.26111e-005 -p -0.457552 -0.00173434 -0.138084 -p -0.413887 0.0138506 -0.168985 -p -0.353308 0.0138506 -0.27391 -p -0.34838 -0.00173434 -0.327176 -p -0.268644 -0.00173434 -0.465283 -k 0 -k 1 -k 2 -k 3 -k 4 -k 5 -k 6 -k 7 -k 8 -k 9 -k 10 -k 11 -k 12 -k 13 -k 14 -k 15 -k 16 -k 17 -k 18 -k 19 -k 20 -k 21 -k 22 -k 23 -k 24 -k 25 -k 26 -k 27 -k 28 -k 29 -k 30 ;')
    curveControl = cmds.rename(curveControl, 'general_Curve')
    #create hierachy
    groupName = cmds.group(objects, n='rig')
    groupName = cmds.group(groupName, n='root')
    #setup control
    scaleMulti = getBoundingBoxMax(objectName=objects)
    cmds.setAttr(curveControl+'.scaleX', (scaleMulti*1.2))
    cmds.setAttr(curveControl+'.scaleY', (scaleMulti*1.2))
    cmds.setAttr(curveControl+'.scaleZ', (scaleMulti*1.2))
    cmds.makeIdentity(curveControl, apply=True, t=1, r=1, s=1, n=0)
    curveShape = cmds.ls(curveControl, dag=True, s=True)
    cmds.parent(curveShape, objects, add=True, shape=True)
    cmds.delete(curveControl)
    cmds.xform('general_CT', ws=True, a=True, zeroTransformPivots=True) 

def rmanAddArchiveControl(name='', path=''):
    '''
    This procedure add rib archive control.
    name - node name
    path - path to rib archive
    '''
    name = cmds.ls(name, long=True, dag=True, leaf=True, type=('mesh', 'gpuCache'))
    tParent = [name[i].split('|')[-2] for i in range(0, len(name))][0]
    ribNode = cmds.createNode('RenderManArchive', n='rootRibArchive', parent=tParent)
    cmds.setAttr(ribNode+'.filename', path, type='string')

#start from here
scenario()







